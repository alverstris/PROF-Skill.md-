# D007 hints: destination preservation

**PASS.** All 39 source expressions preserve complete mathematical structure and inline/display type in the supplied actual-live capture. Every source math slot was aligned in article order and independently parsed; the result is not a count-only check.

Source SHA-256: `d80b7cad63ec6b575b0d567dd4f4213ec4ea77b1ff61525f479859651a659a0c`  
Capture SHA-256: `6058813811cef859390ed19d69718edc3ee81f72f4f10d99407043f4e298302e`  
Observed: `2026-10-11T22:38:46.628Z`  
Actual article: https://github.com/alverstris/PROF-Skill.md-/blob/4765d39aa399a0a1ff09223cae21b15ce6c7f720/runs/y1-reader-20261008/iterations/007/published-r29-20261011/teaching/hints.md

The entire nonmath prose, including mathematical-slot positions, matches after only markup and whitespace normalization (1,871 normalized characters). All 9 textual link labels and resolved immutable hrefs match. The 6 source anchor IDs retain GitHub's expected `user-content-` prefix. Image alt-text count: 0; all match. No explicit renderer error or raw math-code slot is present.

`math-preservation.json` contains every expression's source line/type/LaTeX, complete actual MathML, independent source and actual structures, comparison hashes, all normalized prose, links, anchors and image records. Relative hrefs are resolved against this exact immutable article URL; this does not certify click/navigation behavior. Root separately owns the observed GitHub SPA loading issue and visual geometry.

Comparator v3 SHA-256: `9db7b8cb2707ef597b148faaa143447e5e4248a685dca6bb928213653e8db9da`. It extends preserved v2 only for observed D007 function/symbol tokens, binomial notation, named/id anchor markup and URL resolution. A binomial keeps its parentheses and a zero-line stack distinct from an ordinary fraction. Unknown constructs still fail explicitly. No algebraic simplification, omitted operand or changed delimiter is normalized away.

Frozen teaching files, earlier comparator versions and GitHub were not changed. Scope is destination preservation only, never scientific or SASIS review.
