# D007 lesson: destination preservation

**PASS.** All 200 source expressions preserve complete mathematical structure and inline/display type in the supplied actual-live capture. Every source math slot was aligned in article order and independently parsed; the result is not a count-only check.

Source SHA-256: `fd7a5dc52b8c143c8ba392b494ac879ad2722b0231dd21b3dadb50d0eedd988d`  
Capture SHA-256: `f10dbac71f1d92d0c87b77551ffd240937e66c592d2aa62c4409a62aa5d94ca9`  
Observed: `2026-10-11T22:37:22.353Z`  
Actual article: https://github.com/alverstris/PROF-Skill.md-/blob/4765d39aa399a0a1ff09223cae21b15ce6c7f720/runs/y1-reader-20261008/iterations/007/published-r29-20261011/teaching/lesson.md

The entire nonmath prose, including mathematical-slot positions, matches after only markup and whitespace normalization (15,873 normalized characters). All 17 textual link labels and resolved immutable hrefs match. The 13 source anchor IDs retain GitHub's expected `user-content-` prefix. Image alt-text count: 1; all match. No explicit renderer error or raw math-code slot is present.

`math-preservation.json` contains every expression's source line/type/LaTeX, complete actual MathML, independent source and actual structures, comparison hashes, all normalized prose, links, anchors and image records. Relative hrefs are resolved against this exact immutable article URL; this does not certify click/navigation behavior. Root separately owns the observed GitHub SPA loading issue and visual geometry.

Comparator v3 SHA-256: `9db7b8cb2707ef597b148faaa143447e5e4248a685dca6bb928213653e8db9da`. It extends preserved v2 only for observed D007 function/symbol tokens, binomial notation, named/id anchor markup and URL resolution. A binomial keeps its parentheses and a zero-line stack distinct from an ordinary fraction. Unknown constructs still fail explicitly. No algebraic simplification, omitted operand or changed delimiter is normalized away.

Frozen teaching files, earlier comparator versions and GitHub were not changed. Scope is destination preservation only, never scientific or SASIS review.
