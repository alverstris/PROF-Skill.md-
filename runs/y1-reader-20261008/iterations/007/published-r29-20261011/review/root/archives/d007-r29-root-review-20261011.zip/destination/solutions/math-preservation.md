# D007 solutions: destination preservation

**PASS.** All 69 source expressions preserve complete mathematical structure and inline/display type in the supplied actual-live capture. Every source math slot was aligned in article order and independently parsed; the result is not a count-only check.

Source SHA-256: `3716815362b8d3c4240fffeb8cc5e95dd524939a99c9d6c0b9a189976ae035de`  
Capture SHA-256: `a08cb5423dc77e02afb4f4ff36fce5e3671326dac318b05a34574afa115867e4`  
Observed: `2026-10-11T22:40:15.673Z`  
Actual article: https://github.com/alverstris/PROF-Skill.md-/blob/4765d39aa399a0a1ff09223cae21b15ce6c7f720/runs/y1-reader-20261008/iterations/007/published-r29-20261011/teaching/solutions.md

The entire nonmath prose, including mathematical-slot positions, matches after only markup and whitespace normalization (4,702 normalized characters). All 15 textual link labels and resolved immutable hrefs match. The 6 source anchor IDs retain GitHub's expected `user-content-` prefix. Image alt-text count: 0; all match. No explicit renderer error or raw math-code slot is present.

`math-preservation.json` contains every expression's source line/type/LaTeX, complete actual MathML, independent source and actual structures, comparison hashes, all normalized prose, links, anchors and image records. Relative hrefs are resolved against this exact immutable article URL; this does not certify click/navigation behavior. Root separately owns the observed GitHub SPA loading issue and visual geometry.

Comparator v3 SHA-256: `9db7b8cb2707ef597b148faaa143447e5e4248a685dca6bb928213653e8db9da`. It extends preserved v2 only for observed D007 function/symbol tokens, binomial notation, named/id anchor markup and URL resolution. A binomial keeps its parentheses and a zero-line stack distinct from an ordinary fraction. Unknown constructs still fail explicitly. No algebraic simplification, omitted operand or changed delimiter is normalized away.

Frozen teaching files, earlier comparator versions and GitHub were not changed. Scope is destination preservation only, never scientific or SASIS review.
