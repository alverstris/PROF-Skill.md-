# Restricted destination-preservation comparator v3

Use for frozen-source versus actual-live GitHub DOM preservation only. Never use it as scientific, pedagogical, SASIS, visual-geometry or browser-navigation acceptance. It performs no browser/network/GitHub operations.

```sh
python compare_destination_preservation_v3.py \
  --source /absolute/path/to/frozen/file.md \
  --capture /absolute/path/to/rendered-dom.json \
  --source-sha256 EXPECTED_64_HEX_SOURCE_HASH \
  --output-dir /absolute/path/to/new/review-output
```

Python 3 standard library only; do not run with `-O`. Input/capture requirements and explicit failure behavior are inherited from v2. Capture requires full `articleHTML`, ordered native `math` array, immutable `/blob/<40-hex-commit>/` URL and observation timestamp. All source mathematical slots must map to article slots; all embedded MathML must exactly match the array. An existing output JSON is never overwritten. Exit 0 means all supported preservation checks pass, 1 means recorded preservation failure, and 2 means unsupported/invalid input needing inspection.

V3 adds only observed D007 forms: sinh/cosh/tan/sec/arcsin/arctan function tokens, ne/pm symbols, and binom. A binomial becomes visible parentheses around a distinct zero-line stack with separately preserved upper/lower arguments; ordinary fractions retain a different node. The inspected MathML delimiter sizing/OPEN/CLOSE wrappers are explicitly allowlisted. Source named/id anchors are stripped only as non-visible markup and checked against exact GitHub user-content-prefixed IDs. Source-relative and captured root-relative hrefs are resolved against the same immutable article URL before exact comparison; raw hrefs are also retained. This does not certify navigation success.

The v2 scope/limits remain. Unknown TeX commands, mathematical syntax, MathML tags/attributes/values or source-slot alignment fail explicitly. Algebraic equivalence never substitutes for a faithful rendering. Layout whitespace/wrappers and known equivalent symbols may be normalized; visible operands, delimiters, operators, root/fraction/script arguments, sum bounds and supported table cells may not be dropped. Raw or explicit-error mathematical slots remain failed even if source text survives. Operatorname/cases/standalone double-dollar rendering are not silently added as supported constructions.

Verified on all three frozen D007 r29 files at commit 4765d39aa399a0a1ff09223cae21b15ce6c7f720: 200 lesson, 39 hints and 69 solution expressions, all 308 structure/type matches; complete prose, 41 textual links, 25 anchors and one alt-text match. The recovered solutions capture filename is recorded in provenance. The three complete actual documents exercise every new v3 mathematical form. Root's separate observed SPA navigation loading issue is outside these preservation results.

V2 and its archive remain unchanged. This archive contains the exact v3 comparator, this README, provenance and a SHA-256 manifest. Frozen teaching files were never edited, and no GitHub writes occurred.
