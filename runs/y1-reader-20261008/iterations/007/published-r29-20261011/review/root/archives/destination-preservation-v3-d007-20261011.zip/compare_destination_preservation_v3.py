#!/usr/bin/env python3
"""Restricted D017/D018/D007-derived preservation comparator v3. See README.md. Never a scientific/SASIS evaluator."""
import sys
try:
 import re,json,hashlib,html,xml.etree.ElementTree as ET
 from pathlib import Path
 from html.parser import HTMLParser
 from collections import Counter
 import difflib
 import argparse,sys
 from urllib.parse import urljoin
 cli=argparse.ArgumentParser(description="Restricted source-to-live-DOM preservation QA only; never SASIS or scientific validation.")
 cli.add_argument('--source',required=True,type=Path)
 cli.add_argument('--capture',required=True,type=Path)
 cli.add_argument('--source-sha256',required=True)
 cli.add_argument('--output-dir',required=True,type=Path)
 args=cli.parse_args()
 if sys.flags.optimize:
  raise ValueError("Optimized Python disables parser assertions; run without -O")
 SRC=args.source.resolve();DOM=args.capture.resolve();OUT=args.output_dir.resolve()
 EXPECTED=args.source_sha256.lower()
 if not re.fullmatch(r'[0-9a-f]{64}',EXPECTED):
  raise ValueError("--source-sha256 must contain exactly 64 hexadecimal characters")
 if hashlib.sha256(SRC.read_bytes()).hexdigest()!=EXPECTED:
  raise ValueError("Frozen source SHA-256 mismatch")
 if (OUT/'math-preservation.json').exists():
  raise ValueError("Refusing to overwrite an existing math-preservation.json; select a new output directory")
 if (OUT/'math-preservation.json') in (SRC,DOM):
  raise ValueError("Output would overwrite an input")
 source=SRC.read_text();dom=json.loads(DOM.read_text())
 if not re.search(r'/blob/[0-9a-f]{40}/',dom['url']):
  raise ValueError("Capture URL must identify an immutable full Git commit")
 PAT=re.compile(r'```math\s*\n(.*?)\n```|\$`(.*?)`\$',re.S)
 exprs=[{'ordinal':i+1,'type':'display' if m.group(1) is not None else 'inline','source_line':source.count('\n',0,m.start())+1,'source_latex':m.group(1) if m.group(1) is not None else m.group(2)} for i,m in enumerate(PAT.finditer(source))]
 residual=PAT.sub('',source)
 if '$' in residual or '`' in residual or re.search(r'\\(?:\[|\]|\(|\))',residual):
  raise ValueError("Unsupported or malformed source math/code delimiter remains outside recognized expressions")
 if not exprs:
  raise ValueError("No supported mathematical expressions found; manual inspection required")
 SLOT_PAT=re.compile(r'<math-renderer\b.*?</math-renderer>|<pre\b[^>]*\blang="math"[^>]*>.*?</pre>',re.S)
 slots=[m.group() for m in SLOT_PAT.finditer(dom['articleHTML'])]
 if len(exprs)!=len(slots):
  raise ValueError(f"Source-expression/article-slot count differs: source={len(exprs)} slots={len(slots)}; manual alignment required")
 embedded=re.findall(r'<math(?:\s[^>]*)?>.*?</math>',dom['articleHTML'],re.S)
 if embedded!=[m['mathML'] for m in dom['math']]:
  raise ValueError("Article MathML does not exactly equal the capture math array")
 # A separate restricted TeX parser: no renderer is used to compute expectations.
 MAP={'int':'∫','sum':'∑','sin':'sin','cos':'cos','lim':'lim','to':'→','Delta':'Δ','pi':'π','lt':'<','le':'≤','ge':'≥','approx':'≈','gt':'>','ln':'ln','varepsilon':'ε','infty':'∞','theta':'θ','cdot':'⋅','sinh':'sinh','cosh':'cosh','tan':'tan','sec':'sec','arcsin':'arcsin','arctan':'arctan','ne':'≠','pm':'±'}
 CHAR={'-':'−','*':'∗'}
 def sym(s): return ['symbol',CHAR.get(s,s)]
 class Tex:
  def __init__(self,s): self.s=s;self.i=0
  def skip(self):
   while self.i<len(self.s) and self.s[self.i].isspace(): self.i+=1
  def seq(self,until=None):
   out=[]
   while True:
    self.skip()
    if self.i==len(self.s):
     assert until is None, ('unclosed',until,self.s)
     return out
    if until and self.s.startswith(until,self.i): self.i+=len(until);return out
    atom=self.atom()
    while True:
     self.skip()
     if self.i>=len(self.s) or self.s[self.i] not in "_^'":break
     op=self.s[self.i];self.i+=1
     arg=[sym('′')] if op=="'" else self.atom(single=True)
     if len(atom)==1 and atom[0][0]=='scripts':
      node=atom[0]
     else: node=['scripts',atom,[],[]]
     at=2 if op=='_' else 3
     if op=="'" and node[at]==[sym('′')]:node[at]+=arg
     else:
      assert not node[at],('duplicate or unsupported script',self.s)
      node[at]=arg
     atom=[node]
    out.extend(atom)
  def atom(self,single=False):
   self.skip()
   if self.i>=len(self.s):raise ValueError('Missing TeX atom')
   c=self.s[self.i];self.i+=1
   if c=='{':return self.seq('}')
   if c=='\\':
    m=re.match(r'[a-zA-Z]+|.',self.s[self.i:])
    if m is None:raise ValueError('Incomplete TeX command')
    cmd=m.group();self.i+=len(cmd)
    if cmd in [',','qquad','quad',' ']:return []
    if cmd=='sqrt':return [['square_root',self.atom(single=True)]]
    if cmd in MAP:return [sym(MAP[cmd])]
    if cmd=='binom':return [sym('('),['binomial_stack',self.atom(single=True),self.atom(single=True)],sym(')')]
    if cmd=='frac':return [['fraction',self.atom(single=True),self.atom(single=True)]]
    if cmd=='text':
     self.skip();assert self.s[self.i]=='{';end=self.s.index('}',self.i+1);t=self.s[self.i+1:end];self.i=end+1
     if any(c in t for c in '{}\\'):raise ValueError('Unsupported nested or escaped TeX text')
     return [['text',t]]
    if cmd=='left':
     self.skip();left=self.s[self.i];self.i+=1
     mid=self.seq('\\right');self.skip();right=self.s[self.i];self.i+=1
     if left not in '([|.' or right not in ')]|.':raise ValueError('Unsupported TeX delimiter')
     return ([] if left=='.' else [sym(left)])+mid+([] if right=='.' else [sym(right)])
    raise AssertionError(('unsupported command',cmd,self.s))
   if c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-=*/()[]|,.<>':
    raise ValueError(('Unsupported literal TeX token',c,self.s))
   if c.isdigit() and not single:
    start=self.i-1
    number=re.match(r'[0-9]+(?:\.[0-9]+)?',self.s[start:]).group()
    self.i=start+len(number)
    return [sym(v) for v in number]
   return [sym(c)]
 def tex_parse(s):
  if s.startswith('\\begin{aligned}'):
   assert s.endswith('\\end{aligned}')
   body=s[len('\\begin{aligned}'):-len('\\end{aligned}')]
   rows=body.split('\\\\')
   if any(len(row.split('&'))!=2 for row in rows):raise ValueError('Only two-column aligned rows are supported')
   return [['table',[[Tex(cell).seq() for cell in row.split('&')] for row in rows]]]
  return Tex(s).seq()
 def tag(e):return e.tag.split('}')[-1]
 MATHML_ATTRIBUTES={'mo': {'data-mjx-alternate': ['1'], 'stretchy': ['false', 'true'], 'data-mjx-texclass': ['CLOSE', 'NONE', 'OP', 'OPEN', 'ORD'], 'movablelimits': ['true'], 'accent': ['false'], 'fence': ['true'], 'symmetric': ['true']}, 'mspace': {'width': ['0.167em', '1em', '2em']}, 'mrow': {'data-mjx-texclass': ['INNER', 'ORD', 'OPEN', 'CLOSE']}, 'math': {'display': ['block']}, 'mi': {'mathvariant': ['normal']}, 'mtable': {'displaystyle': ['true'], 'columnalign': ['right left'], 'columnspacing': ['0em'], 'rowspacing': ['3pt']}, 'mtd': {'style': ['text-align: left;', 'text-align: right;']}}
 MATHML_ATTRIBUTES['mo']['minsize']=['2.047em']
 MATHML_ATTRIBUTES['mo']['maxsize']=['2.047em']
 MATHML_ATTRIBUTES['mfrac']={'linethickness':['0']}
 def validate_mathml(e):
  for node in e.iter():
   t=tag(node)
   for name,value in node.attrib.items():
    if value not in MATHML_ATTRIBUTES.get(t,{}).get(name,[]):
     raise ValueError(('Unsupported MathML attribute',t,name,value))
   arities={'mfrac':2,'msub':2,'msup':2,'msubsup':3,'munder':2,'munderover':3}
   if t in arities and len(node)!=arities[t]:raise ValueError(('Invalid MathML child count',t))
   if t in ['mi','mo','mn','mtext','mspace'] and len(node):raise ValueError(('Unexpected token children',t))
   if t=='mtable' and any(tag(c)!='mtr' for c in node):raise ValueError('Unsupported MathML table child')
   if t=='mtr' and (len(node)!=2 or any(tag(c)!='mtd' for c in node)):
    raise ValueError('Only two-cell MathML aligned rows are supported')
   if t=='mn' and not re.fullmatch(r'[0-9]+(?:\.[0-9]+)?\.?',node.text or ''):raise ValueError('Only integer/decimal MathML numeral tokens with optional terminal period are supported')
 def mparse(e):
  t=tag(e);cs=list(e);value=e.text or ''
  if t in ['mi','mo','mn']:
   if not value or value=='\u2061':return []
   if t=='mn': return [sym(c) for c in value]
   if value=='″':return [sym('′'),sym('′')]
   return [sym(value)]
  if t=='mtext':return [] if not value.strip() else [['text',value]]
  if t in ['math','mrow','mstyle','mtd']:return [a for c in cs for a in mparse(c)]
  if t=='mspace':return []
  if t=='msqrt':return [['square_root',[a for c in cs for a in mparse(c)]]]
  if t=='mfrac':return [[('binomial_stack' if e.attrib.get('linethickness')=='0' else 'fraction'),mparse(cs[0]),mparse(cs[1])]]
  if t in ['msub','msup','msubsup','munder','munderover']:
   base=mparse(cs[0]);sub=[];sup=[]
   if t in ['msub','munder']:sub=mparse(cs[1])
   elif t=='msup':sup=mparse(cs[1])
   else:sub=mparse(cs[1]);sup=mparse(cs[2])
   return [['scripts',base,sub,sup]]
  if t=='mtable':return [['table',[[mparse(c) for c in row] for row in cs]]]
  raise AssertionError(('unexpected mathml',t))
 def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
 def count_nodes(nodes):
  c=Counter()
  def walk(n):
   if not isinstance(n,list) or not n:return
   if isinstance(n[0],str):
    c[n[0]]+=1
    if n[0]=='scripts':
     if n[2]:c['subscript_or_lower_bound']+=1
     if n[3]:c['superscript_or_upper_bound']+=1
     if n[1]==[sym('∫')]:c['integral_with_bounds']+=1
     if n[1]==[sym('∑')]:c['sum_with_bounds']+=1
    if n[0]=='symbol' and n[1]=='∫':c['integral_symbol']+=1
    for a in n[1:]:walk(a)
   else:
    for a in n:walk(a)
  walk(nodes);return dict(c)
 records=[]
 native_index=0
 for ex,slot in zip(exprs,slots):
  native=re.search(r'<math(?:\s[^>]*)?>.*?</math>',slot,re.S)
  slot_type='display' if ('js-display-math' in slot or slot.startswith('<pre')) else 'inline'
  if native is None:
   status='render_error' if 'flash-error' in slot else 'raw_math_code_in_capture'
   raw=re.search(r'<pre[^>]*>(.*?)</pre>',slot,re.S).group(1)
   raw=html.unescape(re.sub(r'<[^>]*>','',raw)).strip()
   if status=='render_error':
    delim='$$' if slot_type=='display' else '$'
    if not(raw.startswith(delim) and raw.endswith(delim)):raise ValueError('Unexpected math error fallback format')
    raw=raw[len(delim):-len(delim)]
   if raw.strip()!=ex['source_latex'].strip():raise ValueError(('Raw math/source slot mismatch',ex['ordinal']))
   records.append({**ex,'captured_ordinal':None,'actual_type':slot_type,'mathml_type':None,'slot_type_match':slot_type==ex['type'],'types_match':False,'structural_match':False,'status':status,'source_canonical':None,'actual_canonical':None,'source_canonical_sha256':None,'actual_canonical_sha256':None,'structure_counts':{},'actual_mathml':None,'actual_slot_html':slot,'raw_source_text_match':True,'actual_raw_math':raw,'failure_reason':'No actual MathML in this captured slot. Source text surviving in an error/raw-code fallback is not rendered-math preservation.'})
   continue
  actual=dom['math'][native_index];native_index+=1
  if actual['ordinal']!=native_index or actual['mathML']!=native.group():raise ValueError('Native MathML array/slot order mismatch')
  expected=tex_parse(ex['source_latex']);xml=ET.fromstring(actual['mathML'].replace('&nbsp;','&#160;'));validate_mathml(xml);observed=mparse(xml)
  if actual['display'] not in ['js-inline-math','js-display-math']:raise ValueError('Unsupported MathML display type')
  typ='display' if actual['display']=='js-display-math' else 'inline'
  mathmltyp='display' if xml.attrib.get('display')=='block' else 'inline'
  records.append({**ex,'captured_ordinal':actual['ordinal'],'actual_type':typ,'mathml_type':mathmltyp,'types_match':ex['type']==typ==mathmltyp,'structural_match':expected==observed,'status':'preserved' if expected==observed else 'structural_mismatch','source_canonical':expected,'actual_canonical':observed,'source_canonical_sha256':digest(expected),'actual_canonical_sha256':digest(observed),'structure_counts':count_nodes(expected),'actual_mathml':actual['mathML'],'actual_slot_html':slot})
 if native_index!=len(dom['math']):raise ValueError('Not all captured native MathML was consumed')
 # Complete text comparison with stable placeholders protecting inline positions.
 # Images' alt text is separate from visible body text; anchors have no visible text.
 idx=iter(range(1,len(exprs)+1))
 source_prose=PAT.sub(lambda m:f'⟦M{next(idx):03d}⟧',source)
 source_prose=re.sub(r'</?(?:details|summary)>',' ',source_prose)
 source_alts=re.findall(r'!\[([^\]]*)\]\(([^)]*)\)',source_prose)
 source_prose=re.sub(r'!\[([^\]]*)\]\(([^)]*)\)',' ',source_prose)
 source_links=re.findall(r'\[([^\]]*)\]\(([^)]*)\)',source_prose)
 source_prose=re.sub(r'\[([^\]]*)\]\(([^)]*)\)',lambda m:m.group(1),source_prose)
 source_prose=re.sub(r'<a\s+(?:name|id)="[^"]*">\s*</a>',' ',source_prose)
 class DOMProse(HTMLParser):
  def __init__(self):super().__init__(convert_charrefs=True);self.parts=[];self.mathdepth=0;self.i=0;self.link=None;self.links=[];self.alts=[];self.ol=[];self.pieces=[];self.current=[]
  def handle_starttag(self,t,attrs):
   a=dict(attrs)
   if t=='math-renderer':self.mathdepth+=1;self.i+=1;self.parts.append(f'⟦M{self.i:03d}⟧');return
   if self.mathdepth:return
   if t in ['p','ol','li','div','article','details','summary']:self.parts.append(' ')
   if t=='ol':self.ol.append(int(a.get('start',1)))
   if t=='li' and self.ol:self.parts.append(str(self.ol[-1])+'. ');self.ol[-1]+=1
   if t=='a' and 'href'in a:self.link={'label':'','href':a['href']}
   if t=='img':self.alts.append({'alt':a.get('alt',''),'src':a.get('src','')})
  def handle_endtag(self,t):
   if t=='math-renderer':self.mathdepth-=1;return
   if self.mathdepth:return
   if t in ['p','ol','li','div','article','details','summary']:self.parts.append(' ')
   if t=='ol':self.ol.pop()
   if t=='a' and self.link is not None:self.links.append(self.link);self.link=None
  def handle_data(self,v):
   if self.mathdepth:return
   self.parts.append(v)
   if self.link is not None:self.link['label']+=v
 slot_ids=iter(range(1,len(slots)+1))
 marked_article=SLOT_PAT.sub(lambda m:f'⟦M{next(slot_ids):03d}⟧',dom['articleHTML'])
 parser=DOMProse();parser.feed(marked_article);parser.i=len(slots)
 def norm(s):return ' '.join(s.split())
 sp=norm(source_prose);ap=norm(''.join(parser.parts))
 image_wrapper_links=[a for a in parser.links if not norm(a['label'])]
 text_links=[a for a in parser.links if norm(a['label'])]
 links=[{'ordinal':i+1,'source_label':s[0],'source_href':s[1],'actual_label':a['label'],'actual_href':a['href'],'label_match':norm(s[0])==norm(a['label']),'href_raw_match':s[1]==a['href'],'source_resolved_href':urljoin(dom['url'],s[1]),'actual_resolved_href':urljoin(dom['url'],a['href']),'href_match':urljoin(dom['url'],s[1])==urljoin(dom['url'],a['href'])} for i,(s,a) in enumerate(zip(source_links,text_links))]
 images=[{'ordinal':i+1,'source_alt':s[0],'actual_alt':a['alt'],'alt_match':s[0]==a['alt']} for i,(s,a) in enumerate(zip(source_alts,parser.alts))]
 report={'scope':'Frozen source-to-live-GitHub destination preservation only; no scientific or SASIS verdict.','source_path':str(SRC),'source_sha256':EXPECTED,'capture_path':str(DOM),'capture_sha256':hashlib.sha256(DOM.read_bytes()).hexdigest(),'live_url':dom['url'],'observed_at':dom['observedAt'],'method':'Independent restricted-TeX parser compared to actual MathML tree, one expression at a time in document order. Canonical sequences preserve all symbols and visible delimiters, fractions, script attachment and sub/sup operands, integral/sum bounds and aligned rows/cells. Normalize TeX symbol spellings, MathML wrappers, spacing, U+2061 function-application marker and empty layout cells only. Contiguous source numerals retain script attachment to the whole numeral; numeral content is stored as digit tokens on both sides. Unbraced fraction/script arguments consume one TeX atom. Prose replaces each math expression with the same ordinal marker and compares the entire ordered body after only markup and whitespace normalization; list markers recovered from ol starts; image alt text and link labels compared independently.','counts':{'source_expressions':len(exprs),'captured_expressions':len(dom['math']),'article_expressions':parser.i,'source_types':dict(Counter(e['type'] for e in exprs)),'actual_types':dict(Counter('display' if a['display']=='js-display-math' else 'inline' for a in dom['math'])),'article_slot_types':dict(Counter(r['actual_type'] for r in records)),'record_statuses':dict(Counter(r['status'] for r in records)),'matched_structures':sum(r['structural_match'] for r in records),'matched_types':sum(r['types_match'] for r in records),'source_links':len(source_links),'actual_text_links':len(text_links),'actual_image_wrapper_links':len(image_wrapper_links),'source_images':len(source_alts),'actual_images':len(parser.alts)},'math_records':records,'prose':{'match':sp==ap,'normalization':'Whitespace collapsed; Markdown/HTML markup removed; ordered-list markers reconstructed from HTML starts; math replaced by positional ordinal markers; image alt text checked separately. No case, punctuation, wording, order or typographic quote normalization.','source_normalized':sp,'actual_normalized':ap,'source_sha256':hashlib.sha256(sp.encode()).hexdigest(),'actual_sha256':hashlib.sha256(ap.encode()).hexdigest(),'diff':list(difflib.unified_diff(sp.split(),ap.split(),fromfile='source',tofile='actual',lineterm='')) if sp!=ap else []},'links':links,'image_wrapper_links':image_wrapper_links,'images':images,'limitations':'Uses root-provided actual-live DOM capture, not an independently repeated navigation. Does not establish visual geometry, clipping, link navigation or scientific correctness. Source and capture are immutable review inputs; no frozen-file modifications or GitHub writes.'}
 source_anchor_ids=re.findall(r'<a\s+(?:id|name)="([^"]+)">\s*</a>',source)
 actual_anchor_ids=re.findall(r'<a\s+(?:id|name)="([^"]+)">\s*</a>',dom['articleHTML'])
 expected_anchor_ids=['user-content-'+anchor for anchor in source_anchor_ids]
 anchor_match=expected_anchor_ids==actual_anchor_ids
 report['anchors']={'source_ids':source_anchor_ids,'expected_github_ids':expected_anchor_ids,'actual_ids':actual_anchor_ids,'match':anchor_match}
 report['method']+=' v3 adds only D007-demonstrated sinh/cosh/tan/sec/arcsin/arctan function tokens, ne/pm symbols and binomial notation. The binomial retains visible parentheses and a separate zero-line stack node, never an ordinary fraction. Named/id HTML anchors are markup; GitHub user-content anchor prefixes are checked explicitly. Source-relative and captured root-relative hrefs are resolved against the same immutable article URL before exact URL comparison; no navigation behavior is inferred.'
 report['article_mathml_array_check']={'embedded_mathml_count':len(embedded),'all_exact_strings_equal_to_math_array':True}
 report['counts']['source_normalized_prose_characters']=len(sp)
 report['captured_error_summary']={'capture_reported_errors':dom.get('errors'),'actual_flash_error_slots':sum(r['status']=='render_error' for r in records),'raw_math_code_slots':sum(r['status']=='raw_math_code_in_capture' for r in records)}
 report['disclosures']={'source_count':len(re.findall(r'<details>',source)),'captured_open_count':len(re.findall(r'<details\b[^>]*\bopen(?:=|\s|>)',dom['articleHTML']))}
 report['method']+=' v2 aligns every source expression to an article slot, including explicit error and raw-code slots. Missing MathML is always a failed record. Math slots are replaced by ordinal markers solely for the separate nonmath prose comparison; fallback/error text is fully recorded in the failed math records. Demonstrated v2 additions: square roots, decimal numeric tokens, double prime as two primes, gt/ln/varepsilon/infty/theta/cdot, quad and escaped-space layout, and disclosure markup. Operatorname and cases are not treated as preserved: their captured slots have no MathML, and source text is compared exactly as failed fallback evidence. Unrecognized constructs in actual mathematical rendering still fail explicitly.'
 aggregate=Counter()
 for r in records:aggregate.update(r['structure_counts'])
 report['aggregate_structure_counts']=dict(aggregate)
 checks={
  'anchors':anchor_match,
  'counts':len(exprs)==len(dom['math'])==parser.i,
  'math_structures_and_types':all(r['structural_match'] and r['types_match'] for r in records),
  'prose':sp==ap,
  'text_links':len(source_links)==len(text_links) and all(r['label_match'] and r['href_match'] for r in links),
  'image_alts':len(source_alts)==len(parser.alts) and all(r['alt_match'] for r in images)
 }
 report['checks']=checks
 report['verdict']='PASS' if all(checks.values()) else 'FAIL'
 OUT.mkdir(parents=True,exist_ok=True)
 (OUT/'math-preservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report['counts'],indent=2));print('prose',sp==ap);print('links',all(x['label_match'] and x['href_match'] for x in links));print('images',all(x['alt_match'] for x in images))
 for r in records:
  if not(r['structural_match'] and r['types_match']):print('MISMATCH',r['ordinal'],r['source_latex'],json.dumps(r['source_canonical'],ensure_ascii=False),json.dumps(r['actual_canonical'],ensure_ascii=False))
 if sp!=ap:print('\n'.join(report['prose']['diff'][:150]))

 print("PRESERVATION",report["verdict"])
 raise SystemExit(0 if all(checks.values()) else 1)
except (AssertionError,ValueError,KeyError,IndexError,TypeError) as exc:
 print(f"UNSUPPORTED OR INVALID INPUT: {exc}",file=sys.stderr)
 raise SystemExit(2)
