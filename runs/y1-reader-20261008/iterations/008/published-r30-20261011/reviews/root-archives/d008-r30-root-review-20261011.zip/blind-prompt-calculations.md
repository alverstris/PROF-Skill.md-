D008 root prompt-only calculations before teaching access

Input: author/exercise-prompts.txt in d008-clean-r30-20261011, SHA256 4e1a9174104dd053bd5ff29bb3fdbdaa4081ea27c35d0f81c3b138153d607742. Root has read this prompt packet and the technical reviewer's original-source preparation, but has not accessed D008 r30 teaching, figures, hints, solutions or the reviewer's exercise answers. This is an independent prompt check, not SASIS or a full baseline reading claim.

E1: f(4)=2 and f'(4)=1/(2 sqrt(4))=1/4. Thus L(x)=2+(x-4)/4. With displacement h=0.04, L(4.04)=2.01. At the basepoint L(4)=2. Replacing x-4 by x would give 3 at x=4 and fail value matching.

E2: exp(3x)=1+3x+O(x^2); with u=-2x and exponent -1/2, (1-2x)^(-1/2)=1+x+O(x^2). Their product is 1+4x+O(x^2), so g(0)=1 and g'(0)=4. The real domain is x<1/2, and both substituted inputs 3x and -2x tend to zero near the basepoint. The 3x^2 cross product alone omits the quadratic contributions of both factors.

E3: set u=3x. Then ln(1+3x)/x=3 ln(1+u)/u, whose limit is 3 times the derivative of ln at 1, hence 3. Domain x>-1/3 and x is nonzero during the quotient limit. A numerical approximation with unspecified error does not imply the error vanishes after division by x; the derivative definition establishes exactly the needed ratio limit.

E4: f(0)=0, f'(0)=1, f''(0)=-1, giving Q(x)=x-x^2/2. At x=-0.1, Q=-0.105; the linear estimate is -0.1. Against the supplied reference, their absolute errors are respectively 0.0003605157 and 0.0053605157. Negative second derivative supplies the negative squared correction on either side. For sine, f''(0)=-sin(0)=0, so its degree-at-most-two Taylor polynomial is just x.

E5: exp(3x)=1+3x+(9/2)x^2+O(x^3); (1-2x)^(-1/2)=1+x+(3/2)x^2+O(x^3). The quadratic coefficient is 9/2 from the first factor, 3 from the product of the linear terms, and 3/2 from the second factor: total 9. Thus Q_g(x)=1+4x+9x^2 and g''(0)=18. Independently, (ln g)'=3+1/(1-2x), giving value 4 at zero; its derivative there is 2, so g''(0)/g(0)=4^2+2=18. Cubic products are beyond retained degree two and are omitted as error, not set equal to zero. g=Q_g+O(x^3) locally, not an exact polynomial identity.

E6: epsilon=(0.02)^2=0.0004. First order gives 1000(1+epsilon/2)=1000.2 seconds. Second order adds 1000(3/8)epsilon^2=0.00006 seconds, giving 1000.20006 seconds. Errors against the provided rounded model value are 0.000060020007 seconds and 0.000000020007 seconds. Only the latter is below 0.00001 seconds. The rounded reference precision is much finer than this decision margin. The epsilon term is already (v/c)^2; the epsilon^2 term is (v/c)^4. Neglected gravity is one sufficient reason the specified special-relativistic model alone is not a complete GPS clock calculation.

E7: for h=x-a, matching value and slope gives L=f(a)+f'(a)h. Matching the second derivative of a polynomial A+Bh+Ch^2 gives 2C=f''(a), hence Q=f(a)+f'(a)h+f''(a)h^2/2. With a=2 and h=0.03, L=5 and Q=5-3(0.03)^2=4.9973. The -0.0027 correction reflects downward curvature at the stationary basepoint. A zero second derivative permits a zero quadratic coefficient, as for sine at zero. Continuous second derivative gives local o(h^2) remainder but the provided derivative data alone give no numerical tolerance or usable interval bound. Improvement at every input is not guaranteed: for example the smooth f(x)=x^2-100x^3 at basepoint zero has L=0 and Q=x^2, but at x=0.01 the exact value is zero, so L is more accurate there. This counterexample is an independent check of the universal claim, not an added learner task.

These calculations remain withheld from the fresh author until its complete freeze. The separate technical reviewer independently solves the same prompts without these notes.
