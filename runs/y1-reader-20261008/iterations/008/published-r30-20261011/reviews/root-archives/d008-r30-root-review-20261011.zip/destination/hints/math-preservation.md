# D008 hints: destination preservation

**PASS.** All 18 source expressions preserve complete mathematical structure and inline/display type in the actual capture. All source slots and native MathML were checked in order, independently of matching node counts.

Source SHA-256: `ad229ad84a93b7715a9d2104b82520bb3087959adfb09770eab85ad6b55efa28`  
Capture SHA-256: `b4c496ace0c95997405170e18025f784c79b0135317e81ea93fd64d63087320e`  
Observed: `2026-10-11T23:15:07.069Z`  
Actual article: https://github.com/alverstris/PROF-Skill.md-/blob/663311ba27f25206ed868ce9bbfd016447528ef3/runs/y1-reader-20261008/iterations/008/published-r30-20261011/teaching/hints.md#e1

The entire nonmath prose matches after markup/whitespace normalization (1,995 characters), including every math-slot position. The expected prose is also identical to the independently saved pre-capture inventory. All 12 textual labels and resolved immutable hrefs match, as do all 7 source anchors with GitHub's expected prefix. Image alt-text count: 0; all match. No mathematical error or raw-code slot is present.

The JSON records every source expression, complete actual MathML, independently derived canonical structures and checks, complete normalized prose, links, anchors and alt texts. V4 explicitly retains upright units/subscript labels and the distinct long/ordinary arrows and epsilon/varepsilon glyphs. Only observed nonbreaking-space/space equivalence within math text is added for textual whitespace; words, case and boundary spaces remain intact.

V4 SHA-256: `7466be19fe2073d2b8de4f8bc9e1a20209245741a466cb048ab7295eb303d6df`. Frozen files, v3 and older QA versions are unchanged. No GitHub write or browser operation occurred. Scope is destination preservation only, never source-science or SASIS evaluation. Href/anchor preservation does not establish successful clicks or correct fragment viewport placement; root owns that separate investigation.
