# D008 practice: destination preservation

**PASS.** All 36 source expressions preserve complete mathematical structure and inline/display type in the actual capture. All source slots and native MathML were checked in order, independently of matching node counts.

Source SHA-256: `54df8ad37c8c48d71e41a8dd4e64d4581d85e5871fdc3bc254d35437917a2b88`  
Capture SHA-256: `c27fd7986827c4cc62c6c5dcf550387060a552ef3f83c8a3c54ad534e7a27ba2`  
Observed: `2026-10-11T23:13:41.517Z`  
Actual article: https://github.com/alverstris/PROF-Skill.md-/blob/663311ba27f25206ed868ce9bbfd016447528ef3/runs/y1-reader-20261008/iterations/008/published-r30-20261011/teaching/practice.md

The entire nonmath prose matches after markup/whitespace normalization (3,779 characters), including every math-slot position. The expected prose is also identical to the independently saved pre-capture inventory. All 20 textual labels and resolved immutable hrefs match, as do all 7 source anchors with GitHub's expected prefix. Image alt-text count: 0; all match. No mathematical error or raw-code slot is present.

The JSON records every source expression, complete actual MathML, independently derived canonical structures and checks, complete normalized prose, links, anchors and alt texts. V4 explicitly retains upright units/subscript labels and the distinct long/ordinary arrows and epsilon/varepsilon glyphs. Only observed nonbreaking-space/space equivalence within math text is added for textual whitespace; words, case and boundary spaces remain intact.

V4 SHA-256: `7466be19fe2073d2b8de4f8bc9e1a20209245741a466cb048ab7295eb303d6df`. Frozen files, v3 and older QA versions are unchanged. No GitHub write or browser operation occurred. Scope is destination preservation only, never source-science or SASIS evaluation. Href/anchor preservation does not establish successful clicks or correct fragment viewport placement; root owns that separate investigation.
