# D008 solutions: destination preservation

**PASS.** All 99 source expressions preserve complete mathematical structure and inline/display type in the actual capture. All source slots and native MathML were checked in order, independently of matching node counts.

Source SHA-256: `4e8992f37dbfe5fd81b62d315b16cb3f62344a786077c34e4811cd7b46e13c44`  
Capture SHA-256: `f282b653c77c910eca4a439f36cf5adc19319648bf53d906a42c05fd02c32e9e`  
Observed: `2026-10-11T23:16:13.107Z`  
Actual article: https://github.com/alverstris/PROF-Skill.md-/blob/663311ba27f25206ed868ce9bbfd016447528ef3/runs/y1-reader-20261008/iterations/008/published-r30-20261011/teaching/solutions.md#e7

The entire nonmath prose matches after markup/whitespace normalization (6,012 characters), including every math-slot position. The expected prose is also identical to the independently saved pre-capture inventory. All 12 textual labels and resolved immutable hrefs match, as do all 7 source anchors with GitHub's expected prefix. Image alt-text count: 0; all match. No mathematical error or raw-code slot is present.

The JSON records every source expression, complete actual MathML, independently derived canonical structures and checks, complete normalized prose, links, anchors and alt texts. V4 explicitly retains upright units/subscript labels and the distinct long/ordinary arrows and epsilon/varepsilon glyphs. Only observed nonbreaking-space/space equivalence within math text is added for textual whitespace; words, case and boundary spaces remain intact.

V4 SHA-256: `7466be19fe2073d2b8de4f8bc9e1a20209245741a466cb048ab7295eb303d6df`. Frozen files, v3 and older QA versions are unchanged. No GitHub write or browser operation occurred. Scope is destination preservation only, never source-science or SASIS evaluation. Href/anchor preservation does not establish successful clicks or correct fragment viewport placement; root owns that separate investigation.
