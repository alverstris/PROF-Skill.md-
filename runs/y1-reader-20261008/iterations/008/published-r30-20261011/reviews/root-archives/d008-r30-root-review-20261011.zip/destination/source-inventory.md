# D008 r30 independent frozen-source inventory

The supplied freeze manifest SHA-256 is verified exactly: `1ef03ca02f165f136deddb767deb40483f92661d7da42717bb415156a59c8f61`. All seven teaching files match their frozen byte counts and SHA-256 values. No destination verdict is made before actual capture comparison.

| File | Lines | Expressions | Inline / display | Text links | Anchors | Images |
|---|---:|---:|---:|---:|---:|---:|
| lesson | 274 | 136 | 107 / 29 | 16 | 0 | 3 |
| practice | 64 | 36 | 35 / 1 | 20 | 7 | 0 |
| hints | 54 | 18 | 18 / 0 | 12 | 7 | 0 |
| solutions | 163 | 99 | 83 / 16 | 12 | 7 | 0 |
| Total | 555 | 289 | 243 / 46 | 60 | 21 | 3 |

Every source expression is recorded in order with line number, type and exact LaTeX. The full normalized nonmath prose and paragraph sequence are recorded independently for all four documents, with labels and mathematical positions preserved. All link hrefs/labels, anchor IDs and image paths/alt texts are included. No unaccounted math/code delimiter remains outside the inventoried expressions.

Source forms requiring actual-DOM inspection before any v4 extension include `longrightarrow`, `ll`, `epsilon`, `times`, and `mathrm` (units and subscript labels). Existing text nodes with boundary spaces also need exact comparison against their observed MathML forms. V3 remains unchanged: `9db7b8cb2707ef597b148faaa143447e5e4248a685dca6bb928213653e8db9da`.

This is source-to-destination preservation preparation only, not source-mathematics, physical-model or SASIS review. Frozen teaching files, figures and GitHub were not modified.
