# Restricted destination-preservation comparator v4

Use only for frozen Markdown versus supplied actual-live GitHub DOM preservation. Never treat this tool as source-mathematics, science, teaching, SASIS, visual-geometry or navigation acceptance. It does not operate a browser, access the network or write to GitHub.

```sh
python compare_destination_preservation_v4.py \
  --source /absolute/path/to/frozen/file.md \
  --capture /absolute/path/to/rendered-dom.json \
  --source-sha256 EXPECTED_64_HEX_SOURCE_HASH \
  --output-dir /absolute/path/to/new/review-output
```

Python 3 standard library only; no `-O`. Input/output and fail-closed behavior are inherited from v3. The capture requires full articleHTML, ordered math array, observedAt and an immutable `/blob/<40-hex-commit>/` URL. The source hash must match; all source slots must map, and embedded MathML must exactly equal the array. Existing output JSON is never overwritten. Exit 0: supported preservation checks pass; 1: recorded mismatch; 2: unsupported/invalid input requiring inspection.

V4 adds only D008-observed forms: longrightarrow→U+27F6, ll→U+226A, epsilon→U+03F5 and times→U+00D7; braced alphabetic mathrm runs with optional slash-separated words; and nonbreaking-space to ordinary-space equivalence inside nonempty mathematical text. Upright words/units are distinct canonical nodes. Actual single-letter upright tokens must carry an explicit normal variant; longer upright tokens use the observed multi-letter default with data-mjx-auto-op=false. The unit slash remains an operator. No nested commands, numeric/math operators other than the demonstrated unit slash, or unbraced mathrm form are silently accepted. Unknown MathML attributes/tags remain errors.

Text words, case and boundary spaces stay intact; only the observed NBSP representation changes. Long and ordinary arrows remain different tokens. Epsilon and varepsilon remain different glyphs. No algebraic transformation or inferred missing operand is allowed. V3's explicit binomial/anchor/relative-href treatment and v2's explicit raw/error-slot failures are unchanged. Href/anchor equality does not establish clicking or fragment placement.

Verification: all four frozen D008 r30 articles at immutable 663311ba27f25206ed868ce9bbfd016447528ef3 were fully compared: 136 lesson, 36 practice, 18 hints, 99 solutions; 289 structure/type matches. Full prose matched, including exact equality with the independent pre-capture source inventory; 60 textual links, 21 anchor IDs and three alt texts matched. Every new v4 form occurred in these complete comparisons. Root's separate live fragment-navigation investigation is outside this result.

This archive holds the exact v4 script, this README, provenance and hashes. V3 and its separate archive, all frozen teaching/figure files and GitHub remain unchanged.
