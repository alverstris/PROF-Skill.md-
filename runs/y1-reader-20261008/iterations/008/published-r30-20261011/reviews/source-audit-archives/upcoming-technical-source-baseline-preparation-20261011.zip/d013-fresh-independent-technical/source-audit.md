# D013 independent technical preparation: original-source audit

Status: source preparation complete; no fresh prompt solution or teaching review has begun.

## Role, access and limits

This is an independent technical review preparation record, not a SASIS report. The assigned original source is MIT 18.01 Fall 2006, Lecture 14, **Mean Value Theorem and Inequalities**, stable ID `mit-18-01-fall-2006-L14`. The complete assigned portion is all five PDF pages, including the cover and all three figures.

I read `source-identity.json`, `SHA256SUMS`, and every complete original per-page text file, and visually inspected all five complete original page PNGs. I also opened the original PDF programmatically, inspected its metadata, extracted each entire page afresh, and compared fresh full-page renders with the supplied images. I did not browse or fetch the URL. Accordingly, the verified identity is the supplied local original packet, not a newly retrieved remote copy. The identity record exposes provenance paths, but none of those paths was opened.

I have not read the optional full student baseline, any prior generated teaching, queue or history, held source audit, reviewer report, author record, or diagnosis. I have not received or read the applicable finalized PROF package or fresh prompts. No teaching materials, answers or solutions for the forthcoming generation have been accessed. This records actual access restrictions and actions; it does not claim technical isolation, a sealed execution environment, or memory erasure. Filesystem access is shared. No author has been contacted with these findings.

The present report is a source audit, not a verdict on unreceived work. Prompt-only independent solution sealing and a full review of every frozen teaching constituent remain pending. The source files were not modified.

## Identity and direct checks

- Original PDF: `lec14.pdf`; 634448 bytes; 5 pages; SHA-256 `67d74be87119ab367516c8a80cc710664e48059bc1184c7042846556b3c0a609`.
- All 12 entries in the supplied `SHA256SUMS` passed verification: PDF, identity record, five PNGs and five text files.
- The source identity record SHA-256 is `e7338da7f306f0e7f677a9ba59a4f4af7544ff54ad1901ac60d57843ee0289f8`.
- Every full PNG is 918 by 1188 pixels, identical in RGB pixels to a fresh PyMuPDF render of its PDF page at scale 1.5.
- Every full per-page text file is byte-identical to fresh PyMuPDF literal text extraction. Page text sizes are 183, 1024, 990, 1278 and 1002 bytes, respectively.
- PDF page numbers are one greater than printed lecture page numbers after the cover: PDF 2 = printed 1, through PDF 5 = printed 4.

## Exhaustive source coverage map

| PDF page | Complete contents read and visually checked | Mathematical coverage and figure meaning |
|---|---|---|
| 1 | MIT OpenCourseWare cover, course number and title, Fall 2006, source and terms URLs. | Bibliographic cover; no mathematical content. |
| 2 / printed 1 | Lecture title; MVT hypotheses and equation; secant/tangent distinction; Figure 1; parallel-line geometric proof sketch; nondifferentiability warning using absolute value. | For a<b, continuity on [a,b] and differentiability on (a,b) imply some c strictly inside with f'(c)=(f(b)-f(a))/(b-a). Figure 1 shows an increasing secant between a and b, a matching parallel tangent at c, and the upward translation of a lower parallel line. The curve has other turns; the local tangent at c matches the overall secant, not necessarily an endpoint tangent. |
| 3 / printed 2 | Figure 2 and its caption; Boston–Chicago interpretation; 1000-mile, 3-hour data and formula; two equivalent increment formulas; endpoint renamed x; c-dependence sentence; first-order linear approximation. | Figure 2 shows |x| on an interval crossing 0 with unequal-magnitude endpoints: the secant has positive slope below 1; a parallel line lifted from below first touches the corner. Travel gives 1000/3 in miles per hour under appropriate differentiable scalar motion modeling. Exact MVT increment equals f'(c) times interval length. In the displayed x-version, x>a. Linearization uses f'(a) and is approximate near a. |
| 4 / printed 3 | Exact versus approximate discussion; Figure 3 with a, x, tangent formula and error arrow; all three derivative-sign consequences; stated increasing/decreasing definitions; proof of increasing case; explicit omission of decreasing proof; proof of constant case; local-derivative/global-behavior explanation. | Figure 3 is a convex-looking sample in which the tangent at a lies below the graph at x. It is an illustration of error, not a universal claim about tangent position. MVT converts the sign of f' on an interval into a sign for every ordered finite difference. The decreasing definition has a source typo, detailed below. |
| 5 / printed 4 | Inequalities heading; use of positive derivative; three listed exponential facts; assumption e^x>0; f1=e^x-1 proof; f2=e^x-(1+x) proof; quadratic and cubic extensions; displayed infinite exponential series and explicit later-Taylor-series deferral. | The proof ladder is based on each remainder vanishing at 0 and its derivative equaling the previous positive remainder for x>0. Positivity of e^x is assumed. The finite lower bounds are established for x>0. The infinite-series equality is a preview rather than a consequence proved by the finite inequalities. |

## Independent mathematical verification

### 1. MVT, geometry and hypotheses

The theorem as boxed is correct for a<b. It requires continuity on the closed interval and differentiability on the open interval; it does not require endpoint derivatives or continuity of the derivative. The conclusion is existential: at least one interior c works. It does not identify c, guarantee uniqueness, or claim every interior c works.

A complete justification behind the moving-parallel-line picture is: let m=(f(b)-f(a))/(b-a) and g(t)=f(t)-[f(a)+m(t-a)]. Then g is continuous on [a,b], differentiable on (a,b), and g(a)=g(b)=0. If g is identically zero, every interior point has g'=0. Otherwise a strictly positive maximum or strictly negative minimum occurs inside the interval, by the extreme value theorem and equal zero endpoint values. At that interior extremum, differentiability gives g'(c)=0, hence f'(c)=m. The source's picture is a geometric sketch; without this interior-extremum argument, a bare instruction to slide a line does not by itself justify the interior-contact requirement.

For f(t)=|t| with a=-A<0<b=B, where A,B>0, the secant slope is m=(B-A)/(A+B), strictly between -1 and 1. Away from 0, f' is -1 or 1, and at 0 it does not exist. Therefore no c in (a,b) satisfies the MVT conclusion. This verifies the intended counterexample and Figure 2. The absence of differentiability permits failure; a failed hypothesis never by itself proves failure of the conclusion for every function.

The source says the line touches |x| at 0 “no matter what its slope is.” Literally unrestricted, that statement is false. For the relevant secant slope on an interval straddling 0, |m|<1 and the first contact is indeed the vertex. At m=1 or -1, an entire ray lies along a supporting line. For |m|>1, a line on the whole real graph is not a supporting lower line, and on a finite interval the first contact can be an endpoint. The valid lesson needs the secant-slope/interval qualification.

### 2. Motion interpretation

Given f continuous on [0,3], differentiable on (0,3), f(0)=0 miles and f(3)=1000 miles, MVT gives f'(c)=1000/3 miles per hour for some c in (0,3). The value is exactly 333 1/3 mph.

The derivative of a one-dimensional position is signed velocity. It is speed when the scalar describes cumulative distance traveled, or when motion is modeled along a route in the positive direction. Euclidean distance from Boston along an arbitrary curved route is not generally a coordinate whose derivative equals physical speed. A clear teaching version should state its scalar-distance or one-dimensional motion assumption, and retain the continuity/differentiability conditions; endpoint travel data alone do not supply those conditions.

### 3. Equivalent forms and approximation

Multiplying the MVT equality by b-a gives f(b)-f(a)=f'(c)(b-a) and f(b)=f(a)+f'(c)(b-a). Replacing b by x yields the exact formula f(x)=f(a)+f'(c)(x-a). The source writes a<c<x, so this display assumes x>a. If x<a, a valid c instead lies in (x,a). At x=a the equality f(x)=f(a) is trivial, but there is no nonempty interval to which that MVT assertion applies.

The exact formula uses an unspecified c that can depend on f and both endpoints, whereas local linearization uses the known slope f'(a). If f is differentiable at a, f(x)=f(a)+f'(a)(x-a)+o(x-a). The source illustration shows a particular nonzero error and cannot justify a universal sign of error. If a future explanation argues that f'(c) must be close to f'(a) merely because c is close to a, that argument needs derivative continuity at a; differentiability alone supports linearization through the definition, not necessarily through continuity of f'.

### 4. Derivative sign and global consequences

On an interval where MVT applies to each pair a<b, a positive derivative implies f(b)-f(a)=f'(c)(b-a)>0. A negative derivative gives a negative difference, and an identically zero derivative gives zero difference. Thus the conclusions are strict increase, strict decrease, and constancy, respectively.

The domain must be an interval (or the conclusion must be restricted to each interval component). For example, f(x)=0 on (-infinity,0) and f(x)=1 on (0,infinity) has derivative zero everywhere in its disconnected domain but is not constant on that domain. When including endpoints of a closed interval, continuity at those endpoints remains required.

The source's decreasing definition repeats f(a)<f(b); this is an actual visible source typo, not an extraction error. The correct strict definition is a<b implies f(a)>f(b). The source's stated derivative-negative conclusion is otherwise correct. Its decreasing proof is omitted; filling it by replacing a positive product with a negative product is straightforward. The increasing and constant proofs shown are correct under the interval hypotheses.

The converses need care: strict increase does not force f'>0 everywhere (x^3 is strictly increasing and has derivative zero at 0). A nonnegative derivative implies nondecrease, but this weak version is an extension beyond the three explicitly listed source claims.

### 5. Exponential inequality ladder and its domain

Take e^x>0 and (e^x)'=e^x as available prerequisites. Let F1(x)=e^x-1. Then F1(0)=0 and F1'(x)=e^x>0, so for x>0, F1(x)>0 and e^x>1. Let F2(x)=e^x-(1+x). Then F2(0)=0 and F2'(x)=F1(x)>0 for x>0, giving e^x>1+x there. The source leaves F2(0)=0 implicit, but it is essential to this argument.

For F3(x)=e^x-(1+x+x^2/2), F3(0)=0 and F3'(x)=F2(x)>0 for x>0, giving the quadratic lower bound. For F4(x)=e^x-(1+x+x^2/2+x^3/3!), F4(0)=0 and F4'(x)=F3(x)>0 for x>0, giving the cubic lower bound. More generally, R_n(x)=e^x-sum_{k=0}^n x^k/k! has R_n(0)=0 and R_n'=R_{n-1}; the same induction proves R_n(x)>0 for all x>0 and integers n>=0.

At x=0 each of these finite comparisons is equality, so any unqualified strict inequality that includes 0 is false. The source's initial item e^x>1+x and some following displays omit the domain even though the proof explicitly works with x>0. A faithful corrected treatment should consistently write x>0 for this proof ladder, and distinguish equality at 0. Independently, e^x>1+x also holds for x<0: F1(x)<0 there, so F2 decreases as x approaches 0 and F2(x)>F2(0)=0. That extension is true but not the source's stated proof scope. The quadratic lower bound is not valid for all negative x; at x=-1, e^(-1)<1/2, whereas 1-1+1/2=1/2.

The infinite identity e^x=sum_{k=0}^infinity x^k/k! is mathematically true for real x, but the finite lower-bound induction does not show that its error tends to zero. The source explicitly postpones the relevant Taylor-series development. A teaching packet must preserve that proof status, or actually supply a valid convergence/remainder argument before using equality. It must not suggest that successively adding positive terms and remaining below e^x establishes the limit equals e^x.

## Source issues to track during the future full teaching review

1. Correct the visible strict-decreasing definition sign on PDF page 4.
2. Keep the x>0 domain and x=0 equality explicit for the exponential lower-bound ladder; do not universalize the quadratic claim to negative x.
3. Qualify the absolute-value supporting-line statement by the relevant secant slope and interval crossing the corner.
4. Make the interval and regularity assumptions operational in theorem applications, global derivative-sign arguments and the travel model.
5. Separate the exact existential c-form from linear approximation, and avoid uniqueness or endpoint claims about c.
6. Preserve the infinite-series equality as a preview unless a convergence proof is added.

These are source-reading findings and mathematical verification notes, not findings against any unreceived generated packet. No completeness or accuracy verdict for fresh teaching is issued.

## Remaining work

- Receive the applicable latest PROF instructions and finalized fresh prompts under the staged access protocol.
- Independently solve every finalized prompt before accessing any teaching, guidance, worked solution or answer material; record and hash those solutions.
- After full freeze and authorization to proceed, read every frozen teaching constituent in full, inspect every rendered page and figure, verify the exact prompts and supplied answers, and report source coverage, mathematics, assumptions and any residual issues precisely.
- Disclose actual reading scope and access limitations throughout. No SASIS simulation or learner-result claim is made by this reviewer.
