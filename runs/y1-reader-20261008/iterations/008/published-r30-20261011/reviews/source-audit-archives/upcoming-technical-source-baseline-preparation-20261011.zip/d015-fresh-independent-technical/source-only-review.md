# D015 independent technical preparation: original source only

Status: source preparation complete; finalized-prompt solving and frozen-teaching review have not begun.

## Scope, access, and identity

The assigned original is MIT 18.01 Fall 2006, Lecture 16, “Differential Equations and Separation of Variables,” stable ID `mit-18-01-fall-2006-L16`. The local PDF has 5 PDF pages (the OCW cover plus printed lecture pages 1–4), 645,960 bytes, and SHA256 `cdf0e899a0f0dd5a57ca1069a5c039c08b9efb84ef6d416f3dce038939564d23`.

I read the complete `source-identity.json`, `SHA256SUMS`, and all five literal page-text files. I visually inspected all five full-page PNGs, including all three figures and the exam-review block. I inspected PDF metadata and independently checked that each page text is byte-identical to fresh extraction and each PNG is pixel-identical to a fresh 1.8-scale PDF render. Every entry in the original `SHA256SUMS` verified. `source-verification.json` records the checks.

Identity verification here means agreement with the supplied local identity record and exact original packet. I did not fetch the official URL or independently attest to external retrieval provenance. The identity record itself includes paths and identity-only provenance from earlier workflow locations; those referenced files were not opened.

I have accessed no earlier generated teaching, queue/history, held source audits, reviewer reports, author records, or diagnoses. I have not read the optional full student baseline at this preparatory stage. I have not received or read the applicable finalized PROF package or finalized prompt set. I have accessed no teaching generation for D015. This is an access-scope disclosure, not a claim of technical isolation or memory erasure. I am acting as technical reviewer, not SASIS. No browser or GitHub action was taken. No original file was changed. Findings are withheld from authors pending the complete teaching freeze.

## Complete source coverage

| PDF / printed page | Read and inspected content | Technical assessment |
|---|---|---|
| 1 / cover | OCW identification, course and term, citation/terms URL | Administrative identity; no mathematics. |
| 2 / 1 | Title; ODE heading; Example 1 `y'=f(x)` and indefinite integration; Example 2 `(d/dx+x)y=0`, operator aside, `y'=-xy`, separation, logarithm and exponentiation, signed parameter, restoration of zero solution, initial values `y(0)=1` and `y(0)=a` | Main solution and initial-value claims correct. Division by `y` temporarily excludes zero. The source does restore `a=0`. The indefinite integral in Example 1 represents the family of antiderivatives; a displayed `+C` is pedagogically useful if a particular antiderivative is written. |
| 3 / 2 | Figure 1 Gaussian with peak `(0,1)`; general separated equation `y'=f(x)g(y)`; `h=1/g`; implicit antiderivative relation; inverse expression; identification of `f,F,g,h,H` for Example 2 | Figure matches the Gaussian qualitatively. General method needs nonzero-denominator and inverse-branch qualifications. The displayed `f(x)=x` is a genuine sign error; it must be `-x` when `g(y)=y` and `F(x)=-x^2/2`. |
| 4 / 3 | Example 3: tangent slope twice origin-ray slope; Figure 2 black curve/ray, marked point, red tangent; separation, logarithms, exponentiation, family `y=ax^2`; positive/negative/zero example parameters | Derivation correct for `x≠0`, restoring `a=0` separately after division. The `a=-2` row reads `y=-2y^2` in the actual page, a genuine variable typo; it must be `y=-2x^2`. The ODE is undefined at `x=0`. |
| 5 / 4 | Example 4 orthogonal trajectories; negative reciprocal slope; integration; ellipse relation and semiaxis ratio; Figure 3 parabolas and ellipses; explicit square-root branches; full Exam Review list and reference to review sheet | Ellipse computation and ratio correct for `c>0`. Reciprocal-slope and single-valued-branch restrictions matter. Exam list contains linear/quadratic approximation, curve sketching, extrema, related rates, antiderivatives/separation, and MVT. The external review sheet is referenced but is not in the assigned original; no contents of it were assumed. |

## Independently checked mathematics

### Direct antiderivatives and Gaussian family

If `F'=f`, then `y=F+C` gives `y'=f`. Conversely, on an interval any two antiderivatives differ by a constant.

The operator equation is algebraically `y'+xy=0`. On an interval where `y≠0`, division and integration give

`ln|y|=-x^2/2+C`, hence `y=A exp(-x^2/2)` with `A≠0`.

Substituting the candidate directly gives `y'=-x A exp(-x^2/2)=-xy` for every real `A`, including zero. Thus the final family legitimately includes zero, although exponentiating a finite integration constant alone never produces `A=0`. At `x=0`, `y(0)=A`; therefore the stated initial values give the stated family members. An independent completeness check is `(exp(x^2/2)y)'=exp(x^2/2)(y'+xy)=0`, valid without dividing by `y`. The family is defined for all real `x`.

For `A=1`, the function is positive, even, has value 1 at zero, increases for `x<0`, decreases for `x>0`, and tends to zero toward either end. These properties match Figure 1. No normalization as a probability density is claimed or needed.

The source’s quantum-mechanical naming aside was read. I checked its displayed operator algebra, but did not independently research physical conventions or normalization of the term “annihilation operator”; this is outside the calculus assessment and no external research was authorized for this stage.

### General separation and implicit/inverse forms

For `y'=f(x)g(y)`, the division step is valid only on a region where `g(y)≠0`. Set `H'=1/g` and `F'=f` there. The chain rule gives

`d[H(y(x))-F(x)]/dx = y'/g(y)-f(x)=0`,

so `H(y)=F(x)+C`. This is the primary implicit form. An explicit `y=H^{-1}(F(x)+C)` requires an invertible branch of `H` and requires the argument to lie in that branch’s range. Under the usual assumption that `g` is continuous and nonzero on a connected `y`-interval, `H'` has a fixed nonzero sign there, giving such a monotone branch. The source’s `H(y)=ln|y|` is not one-to-one on all nonzero real numbers: positive and negative branches must be treated separately.

Every root `b` of `g` must be checked in the original equation; `y≡b` is a constant solution wherever the right-hand side is defined. The implicit formula after division alone cannot be advertised as all solutions without these checks. For an unrestricted general `g`, additional existence/uniqueness assumptions would be needed to assert that all solutions are either a single nonzero branch or an equilibrium; non-Lipschitz equations can have solutions that join at an equilibrium. This advanced possibility is a boundary on broad claims, not an extra source topic that must be taught in this introductory lecture.

For Example 2, a consistent choice is `f(x)=-x`, `F(x)=-x^2/2`, `g(y)=y`, `h(y)=1/y`, `H(y)=ln|y|`. The source’s printed `f(x)=x` contradicts both `F'=f` and the original ODE.

### Geometric slope condition and parabola family

The origin-to-point ray has slope `y/x` only for `x≠0`; twice this slope is `2y/x`. For nonzero `y`, separation gives `dy/y=2 dx/x`, so `ln|y|=2ln|x|+C` and `|y|=exp(C)x^2`. A fixed sign gives `y=ax^2`, with the zero member checked directly. Differentiating confirms `2ax=2(ax^2)/x` for `x≠0` and every real `a`.

An independent completeness check on any interval excluding zero is `(y/x^2)'=(xy'-2y)/x^3=0`. Such a connected interval lies in either `x>0` or `x<0`. Constants may differ on separate connected components; the ODE does not impose an equation at zero. Each polynomial graph extends smoothly through zero, but that does not make it a solution of the displayed quotient ODE on an interval containing zero. At the origin itself the ray to `(0,0)` does not specify a ray direction.

The listed members for `a=1,2,-1,0,100` are correct. For `a=-2`, `y=-2x^2` is the intended member. The printed `y=-2y^2` is an equation in `y` alone (`y=0` or `y=-1/2`), not the claimed parabola.

Figure 2 was inspected as a schematic: the point, dashed ray and red tangent encode the stated geometric relationship. I did not use measured pixel slopes to establish the exact factor of two; the equation and derivative check establish it.

### Orthogonal trajectories, ellipses, and domains

At a crossing where both slopes are finite and nonzero, perpendicularity gives product `-1`, so the orthogonal slope to `2y/x` is `-x/(2y)`. The reciprocal step assumes the relevant denominators are nonzero. Separating the latter equation without dividing by `x` gives `y dy=-(x/2)dx`, hence

`y^2/2=-x^2/4+c`, or `x^2/4+y^2/2=c`.

For `c>0`, the semiaxes are `a_x=2√c`, `a_y=√(2c)`, so `a_x/a_y=√2`. For `c=0`, the locus is only the origin; for `c<0`, there is no real locus. Therefore “family of ellipses” requires `c>0`.

The explicit branches are `y=±√(2c-x^2/2)=±√(2(c-x^2/4))`. Real values require `|x|≤2√c`; differentiable nonzero-`y` graph solutions of `y'=-x/(2y)` occur on the open interval `|x|<2√c` (or subintervals). The complete ellipse requires both branches and has vertical tangents at its two `x`-axis endpoints; no finite `dy/dx` exists there. The smooth implicit ellipse is a larger geometric object than either graph solution branch.

The tangent vector `(2y,-x)` to an ellipse is perpendicular to the parabola tangent vector `(1,2y/x)` at a shared point with `x≠0`, since their dot product is zero. This remains a useful geometric argument at `y=0`: the only member of the parabola family meeting an ellipse on the `x`-axis is `a=0`, the `x`-axis itself, with a horizontal tangent; the ellipse tangent is vertical. At `x=0,y≠0`, an ellipse has no intersection with any finite-parameter parabola `y=ax^2`, so no family-crossing assertion is needed there. A nondegenerate ellipse never contains the common parabola point `(0,0)`.

Figure 3 conveys the intended two families and their crossings. No equal visual axis scale is labelled, so I do not infer semiaxis ratios or exact Euclidean angles from its pixel geometry. The precise ratio and orthogonality are verified algebraically above.

## Material source corrections and qualifications to check later

1. Correct the original printed sign error `f(x)=x` to `f(x)=-x` in the Gaussian example, or use a different explicitly consistent factorization.
2. Correct the original printed member `y=-2y^2` to `y=-2x^2`.
3. Explain or enforce the nonzero condition before division and check the excluded constant solutions in the original ODE.
4. Treat `H^{-1}` as branch-dependent; do not invert `ln|y|` globally without selecting a sign branch.
5. Keep the domain `x≠0` attached to the geometric quotient ODE; distinguish polynomial extension from satisfying an undefined ODE at zero.
6. Qualify the ellipse family by `c>0`, recognize the two explicit branches, and distinguish graph-slope restrictions from complete implicit curves.
7. Use the negative-reciprocal slope rule where it is defined and handle horizontal/vertical tangent cases geometrically when claimed.

## Pending stages and limits

No pass/fail verdict is made about any teaching or finalized prompt, because none has been received or accessed. No student-model simulation has occurred. The latest applicable PROF package, finalized prompts, and any requested baseline reading remain pending. Independent prompt solutions must be written and sealed before teaching access. After the root confirms a complete teaching freeze and grants the intended access, every frozen teaching constituent must be reviewed; this source note alone cannot stand in for that review.
