# D018 independent technical baseline preparation

Status: ENTIRE EXACT BASELINE READ THROUGH ACTUAL EOF. This is additional preparation, separate from the unchanged original-source preparation. No exact future exercises have been supplied or solved; no frozen teaching has been accessed; no acceptance decision or SASIS attempt is made.

## Verified identity and actual contiguous access

- Exact authorized file: `/workspace/scratch/f9c0b7fc7e76/d007-clean-r29-20261011/inputs/student-baseline.txt`.
- Length: 247840 original bytes, 246945 UTF-8 characters, 1377 LF characters. Original CR/LF sequences were preserved during reads; these byte coordinates refer to the unmodified file.
- SHA256 before and after the full read: `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`, matching the assigned identity.
- Read all content personally as eight sequential, contiguous tool outputs. Every output displayed its entire requested range; no output reported truncation. Some boundaries fell within a word or formula; the immediately succeeding output resumed at the exact next byte. The eight primary ranges have no gaps or overlaps and cover all 247840 bytes.
- Completed the cover, all Mathematics, all Further Mathematics including selected Statistics and Mechanics, all Physics, and all Chemistry through CH-REF and the final line referring to `research-verification.txt`. That referenced file was not opened. Other external links are baseline provenance only and were not followed.

| Read sequence | Raw byte range, start included/end excluded | Bytes | Returned tool-output chunk |
|---:|---|---:|---|
| 1 | [0, 24000) | 24000 | `e82437` |
| 2 | [24000, 56000) | 32000 | `f29f66` |
| 3 | [56000, 88000) | 32000 | `96cedb` |
| 4 | [88000, 120000) | 32000 | `e8f088` |
| 5 | [120000, 152000) | 32000 | `4ff26d` |
| 6 | [152000, 184000) | 32000 | `21c67e` |
| 7 | [184000, 216000) | 32000 | `8dcdf7` |
| 8 | [216000, 247840) | 31840 | `13ae0d` |

The per-range SHA256, exact beginning/ending fragments, line coordinates, section boundaries and EOF record are preserved in `baseline-access.json`. This records actual model-visible access, not a substitute summary or an inference from a successful file read alone. A later targeted `rg` search supplied line locations after the complete primary pass.

## Governing availability rules actually read

The cover (lines 4–12) grants the complete four-subject operational inventory for Mathematics A H240; Further Mathematics A H245 Pure Core Y540/Y541 plus Statistics Y542 and Mechanics Y543; Physics A H556; and Chemistry A H432. It excludes MEI, Discrete and Additional Pure options. The subjects jointly form one input, so a relevant rule in Further Mathematics or Physics must not be withheld just because the Mathematics-only section says it is excluded from H240.

Course completion is a competence assumption, not evidence of a particular student's measured mastery. Use actual supplied definitions, conditions and formulae. Cross-subject deductions are allowed when their steps and premises are shown. Exclusion from an assessment syllabus does not forbid a derivation from supplied premises. A familiar name does not grant an unstated university theorem. Needed lookup values must be available in the permitted input or notes; links do not import their contents.

These are records of the declared student baseline. This reviewer remains the technical reviewer, not SASIS, and has not simulated or certified a student's success.

## Relevant D018 prerequisites and boundaries

Line references below are physical LF line numbers in the exact baseline, rather than rewritten or normalized copies. Topic names and FM identifiers are the durable conceptual references.

| Relevant knowledge | Actual availability in the full baseline | Consequence for D018 review |
|---|---|---|
| Signed arithmetic, powers of ten, standard form, rounding, significant figures, ordinary estimation | Mathematics prior arithmetic, line 28; Chemistry CH-01.01, including line 818 | A 200-digit interval and the arithmetic/rounding of the prime-density approximation are within the declared toolkit |
| Domains, intervals, identities, implications and valid equation operations | Mathematics language and algebra sections near the beginning | Check admissible intervals and distinguish equality, approximation, and a contextual model; no new university fact is needed just to recognize a contradiction |
| Counterexamples and proof reasoning | Mathematics “Proof and mathematical work” | A correct admissible counterexample can disprove the source's sine-integral equation or a broad assertion; examples alone cannot prove unrestricted statements |
| Limits as derivatives; difference quotient | Mathematics differentiation, lines 136–146 | The derivative definition in the FTC 2 proof is already available |
| Elementary exponential/trigonometric/logarithmic derivatives | Mathematics differentiation, lines 146–158 | Differentiating Gaussian/Fresnel-related expressions and the derivative of ln x does not require teaching every elementary derivative again |
| Sum, constant-multiple, product, quotient and chain rules | Mathematics differentiation, lines 158–164 | Once an accumulation derivative is established, a variable endpoint can be handled by an explicit composition/chain-rule derivation |
| Sign of derivative; stationary points; concavity; inflection | Mathematics differentiation, lines 166–170 | Qualitative sketches of integral-defined functions can follow by f' and f'' signs, including erf monotonicity and concavity |
| Antiderivative family, additive constant and initial condition | Mathematics integration, line 178 | The distinction between one normalized accumulation function and a family F+C has substantial prior support |
| FTC endpoint evaluation | Mathematics integration, line 178 | The evaluation form called FTC 1 in D018 is explicitly baseline knowledge for suitably continuous integrands |
| Rectangle-sum interpretation | Mathematics integration, line 178 | A Riemann-sum interpretation is available in ordinary well-behaved cases; formal epsilon-delta analysis is not thereby imported |
| Power, reciprocal, exponential, sine and cosine antiderivatives | Mathematics integration, lines 180–188 | Correcting the source's sine/cosine mismatch uses explicit prior formulae |
| Linearity, reverse-chain integration, substitution and integration by parts | Mathematics integration, lines 190–200 | Bounds and variables must be transformed consistently; substitutions can support further deductions |
| Signed definite integrals and nonnegative geometric area | Mathematics integration, line 202 | Signed accumulation and positive geometric area should be distinguished, without treating the distinction as an entirely new mathematical operation |
| Numerical trapezia and monotone endpoint rectangles | Mathematics numerical methods, lines 222–232 | A slowly varying or monotone integrand can be approximated/bounded using available numerical/area reasoning, with a stated direction and limitations |
| Real logarithms and exponential inverses; laws; monotonicity | Mathematics “Exponentials and logarithms,” before differentiation | Positive real domains and logarithm laws are available; D018's L(x) preview does not require pretending the learner has never met ln x |
| Average value of an integrand | Further Mathematics FM30, line 415 | The average-value expression in the FTC 2 proof is explicitly supplied |
| Improper integrals, infinity and interior singularities | FM28, line 411 | The need to split at an interior singularity and require both one-sided integrals is already available; cancellation of divergent parts cannot be silently accepted |
| Maclaurin construction and standard real e, sin, cos series | FM27, line 409 | Some series-based explorations can use this grant, but arbitrary interchange of an infinite series with an integral and general remainder/convergence theorems are not granted |
| Probability densities, normalization, CDF as integral, derivative relation | FM42, line 441 | There is prior context for accumulation and the density/CDF relationship. Its “at differentiable points” clause alone does not establish general FTC differentiability for every continuous signed integrand |
| Full normal density for arbitrary positive sigma | FM44, line 445; normal symmetry and standardization also in Mathematics | Gaussian normalization can be derived from this baseline with shown steps; see below |
| Model assumptions and evidence limits | Mathematics proof/modelling paragraph; Physics measurement/evidence and Chemistry CH-11 | Replacing a prime-count problem by an integral model still needs a supplied density claim. A numerical candidate count alone cannot establish a security theorem |
| Physical rate/area reasoning | Physics motion/graph sections; FM58 work and FM61 impulse | Familiar physical examples can illustrate accumulated change if variables, units, signs and models are stated |
| Whole Chemistry section | CH-00 through CH-REF read in full | Supports ordinary quantitative modelling, logarithms, rate signs and evidence reasoning, but supplies no additional special-function theorem or prime-counting/cryptography rule |

The complete baseline contains no statement of the Mean Value Theorem under that name, no general theorem licensing parameter differentiation under an integral sign, no prime-number theorem, and no standard Bessel J0 definition or normalization. These cannot be treated as pre-taught named rules merely because the reviewer knows them. The source can recall or state MVT, but teaching that uses its precise hypothesis-to-conclusion step should make that step accessible. Antiderivative constants and the already granted FTC evaluation supply related routes; the absence of a named MVT statement does not mean that every constant-difference argument is impossible from permitted premises.

Formal epsilon-delta analysis is explicitly outside Mathematics A's supplied scope (line 339); Further Mathematics FM69 (line 497) does not add a general analysis course. The source-only report's rigorous supremum estimate is a reviewer justification, not automatic student prerequisite availability. A future teaching explanation may introduce and justify an elementary continuity/squeeze argument without assuming an untaught formalism.

## Important legitimate deductions for this lecture

### Variable endpoints after FTC 2

The general chain rule is already supplied. If fresh teaching establishes `A(u)=∫_a^u f(t)dt` and `A'(u)=f(u)` under appropriate continuity, then setting `H(x)=A(g(x))` and applying the baseline chain rule gives `H'(x)=f(g(x))g'(x)`. This is an explicit deduction using two available premises, not a need for an independently memorized variable-limit theorem. With lower and upper limits depending on x, subtraction of two such accumulation functions yields the corresponding difference of endpoint terms once additivity/orientation is established. The actual prompt must still state domains and differentiability adequately.

### Gaussian normalization and the error-function limit

The source-only preparation correctly said that FTC 2 by itself does not prove the error-function limit. After reading the entire baseline, a legitimate additional route is now identifiable.

FM44 grants the normal density for every positive sigma, and FM42 grants density normalization. Choose mean 0 and variance 1/2, so sigma=1/sqrt(2). Its supplied density simplifies to

`p(t)=exp(-t^2)/sqrt(π)`.

Normalization gives `∫_(-∞)^∞ exp(-t^2)dt=sqrt(π)`. The integrand is even, so symmetry, substitution and the improper-integral interpretation give `∫_0^∞ exp(-t^2)dt=sqrt(π)/2`. With D018's definition of erf, its positive-infinity limit is therefore 1. This route uses the full baseline; it does not need a double integral, polar coordinates in a plane integral, or an outside Gaussian-integral fact. If it is relevant to an exact future prompt, the route should be shown rather than merely assumed.

Similarly, with the standard normal CDF Phi and substitution `u=sqrt(2)t`, `erf(x)=2 Phi(sqrt(2)x)-1` can be derived. It need not be memorized. Numerical values of Phi beyond supplied percentiles would still need permitted numerical data or an allowed calculation method; the analytical relationship is not a full lookup table.

### Source errors and prerequisites must remain distinct

The source's trigonometric inconsistency, prime digit interval error, logarithm-bound typo, declared one-significant-figure rounding issue and Bessel normalization issue remain source-level technical findings. The baseline read does not alter those mathematical facts. It does change what can fairly be assumed or derived when assessing explanations: for example, signed integration, the chain rule, improper-integral handling, average values and the normal density are positively available in the combined baseline.

A later review must consider the exact exercise, its wording and supplied teaching, rather than convert a source omission into an automatic defect or import a reviewer-only special-function fact as student knowledge.

## Preserved source seal and remaining sequence

The source-only report and input manifest were checked after this full baseline pass and remain byte-for-byte unchanged:

- `source-preparation.md`: SHA256 `cd17b50ca1cec4e98024138e00dc81dabab551d733df0f223929247639855294`.
- `source-input-manifest.json`: SHA256 `70b61fa9088f1455d90b7111e3b343a6655cf7a98576f4c52c667c5e8e9c166f`.

The original report's “baseline not yet read” statement accurately records its earlier phase; this separate addendum records the later authorized full read without rewriting that history. No original source or baseline file was modified.

The shared workspace does not enforce isolation, and no memory-erasure claim is made. Actual new content access in this phase was confined to the one authorized baseline, plus rehashing the already-read source-preparation records. No author was contacted, no prior teaching/review/history file was opened, and no browser or GitHub action occurred.

Await the latest applicable PROF instructions and exact finalized prompts. Solve those exact prompts and seal the solution record before receiving/opening the complete frozen teaching. Root continues to own sequencing. No SASIS work has occurred.
