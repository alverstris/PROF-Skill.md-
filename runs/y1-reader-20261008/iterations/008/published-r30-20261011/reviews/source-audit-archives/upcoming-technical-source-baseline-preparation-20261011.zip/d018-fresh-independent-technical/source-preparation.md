# D018 source-only technical preparation

Status: ORIGINAL SOURCE PREPARATION COMPLETE. Exact finalized exercise prompts, independent prompt solutions, their pre-teaching seal, and frozen-teaching review are still pending. This is not a teaching acceptance, an exercise adjudication, or a SASIS report.

## Access and provenance

- Assigned role: independent technical reviewer preparing for a fresh D018 generation, under root-controlled sequencing.
- Original material: MIT 18.01 Single Variable Calculus, Fall 2006, Lecture 20, “Second Fundamental Theorem.” The PDF has five physical pages: a cover, followed by lecture pages numbered 1–4.
- Source directory: `/workspace/scratch/f9c0b7fc7e76/original-inputs/D018`.
- Read the entire `source-identity.json`, all five literal `lec20-pXX.txt` files, the PDF metadata and a fresh full PDF text extraction. Inspected every supplied whole PNG page, pages 01–05, through the image viewer. The fresh `pdftotext -layout` extraction matched each of the five supplied page-text files byte for byte.
- PDF SHA256: `711e84263db3b675c39d18aa1951a55a4f026783732924324b6578913360c990`, matching the source identity record. PDF size 388432 bytes; `pdfinfo` reports five pages.
- No student baseline has been read at this stage. The permitted baseline is optional and was not needed for original-source mathematical checks.
- No earlier generated teaching, held audits, queue/history, reviewer reports, author records, diagnoses, or finalized future prompts have been accessed in this preparation. No browser or GitHub actions occurred. Original files were not modified.
- Read the PDF skill as workflow guidance for inspection. The applicable updated PROF package has not yet been supplied. No claim is made that this workspace enforces technical isolation or that model memory was erased. The access boundary here is procedural and limited to the actions recorded above; tools and files may remain available in the shared workspace.
- This report is held reviewer preparation. Findings have not been sent to an author. Root may receive status; substantive author contact must wait until the complete teaching freeze.

## Complete source coverage

Locations below distinguish physical PDF pages from printed lecture-page numbers.

| Physical page | Printed page | Content read and visually inspected | Technical disposition |
|---|---:|---|---|
| 1 | Cover | MIT OpenCourseWare identity, course and term, citation/terms reference | Identity/context; no mathematical claims |
| 2 | 1 | FTC 1 evaluation statement and endpoint notation; existence of antiderivatives for continuous functions; Gaussian integral defining a new function; list of other non-elementary examples; FTC 2 statement; geometric increment/difference-quotient argument | Central results correct with interval, continuity and signed/oriented-area qualifications below |
| 3 | 2 | Figure 1 with area from a to x and added strip; average-value proof of FTC 2; deduction of FTC 1 using equal derivatives and MVT; antiderivative-versus-integral example begun with sine/cosine | Proof structure correct; trigonometric example has a genuine inconsistency |
| 4 | 3 | Continuation with F(x)=sin x+21; additive constants cancel; normalized error function and its positive-infinity limit; Figure 2; logarithmic integral from 2; prime-count motivation and cryptography prose; proposed count over 10^200 to 10^201; logarithm endpoint estimates | Error function correct; trigonometric integrand erroneous; prime digit interval off by one; domain and model/security qualifications needed |
| 5 | 4 | One-significant-figure logarithm estimate; displayed prime-count arithmetic and security inference; Fresnel C and S definitions; Bessel J0 integral; C' homework answer; preview L(x)=integral from 1 to x of 1/t; constant-integrand footnote | Fresnel derivative and constant-integrand rule correct; logarithm interval typo, rounding issue, Bessel normalization error, and security overclaim require correction |

## Independent mathematical checks

### 1. FTC 2 and accumulation functions

A safe complete statement is: let f be continuous on an interval I and let a be in I. Define A(x)=∫_a^x f(t) dt using oriented integrals. Then A(a)=0, and A'(x)=f(x) at interior points of I, with the corresponding one-sided derivative at endpoints. No elementary antiderivative formula is required to define A.

The exact increment is

`A(x+h)-A(x) = ∫_x^(x+h) f(t) dt`.

For any nonzero h with the segment in I,

`|(A(x+h)-A(x))/h - f(x)| <= sup_{t between x and x+h} |f(t)-f(x)|`.

Continuity at x makes the right side tend to zero. This proves both positive-h and negative-h limits, and applies equally when f is negative. The source's “average value on x <= t <= x+Δx” wording and positive strip figure directly address Δx>0; the written proof needs oriented limits or reversed endpoints for Δx<0. An informal approximation sign alone is not the logical justification for passage to the derivative.

Figure 1 correctly depicts positive f, x>a and positive h. Ordinary unsigned area under the graph is insufficient as a general definition: use signed accumulation and oriented limits for negative values of f or x<a. An integral-defined function need not itself be positive or increasing; its derivative has the sign of f.

The Gaussian example `A(x)=∫_0^x exp(-t^2)dt` is defined for every real x and satisfies `A'(x)=exp(-x^2)`, `A(0)=0`. A prime on A is not a derivative with respect to the dummy integration variable t. The source does not prove non-elementarity, nor does FTC 2 establish non-elementarity; it establishes existence and the derivative.

Domain qualifications in the example list: `sqrt(x) exp(-x^2)` is a real-valued continuous integrand for x>=0; its standard real-domain antiderivative statement uses that domain. `sin(x)/x` is undefined at zero as printed, but has continuous extension 1 at zero. One can work on an interval avoiding zero, or explicitly use the extension before integrating across zero. `sin(x^2)` and `cos(x^2)` are continuous on all of R.

### 2. FTC 1, constants and the source's sine/cosine mistake

For continuous f on [a,b] and an antiderivative F, define G(x)=∫_a^x f(t)dt. FTC 2 gives G'=f, so (F-G)'=0 in the interior. By the Mean Value Theorem, F-G is constant on the interval. Since G(a)=0,

`∫_a^b f(t)dt = G(b)-G(a) = F(b)-F(a)`.

This also explains why all antiderivatives `G+c` give the same endpoint difference. The constant-derivative argument is an interval statement; on disconnected domains different components may have different constants. The notation “indefinite integral evaluated at endpoints” means choose one antiderivative and subtract its endpoint values, not two independent arbitrary constants.

The source's specific trigonometric example is internally inconsistent:

- Physical p3, final remark, says `f(x)=sin x`, then correctly computes `G(x)=∫_0^x cos t dt=sin x`.
- Physical p4, top, correctly says `F(x)=sin x+21` and `F'(x)=cos x`, but writes `∫_a^b sin x dx = sin b-sin a`.

The minimal consistent correction is to use `f=cos` in the remark and `cos x` in the definite integral. Then G=sin x, F=sin x+21, and ∫cos=sin b-sin a are all correct. Alternatively, a consistently sine-based example would use G(x)=1-cos x and an F with derivative sin x. These alternatives must not be mixed.

A decisive counterexample to the printed sine integral is a=0,b=π: its true value is 2, whereas the source's right side is sin π-sin 0=0.

### 3. Error function and Figure 2

The printed definition `erf(x)=(2/sqrt(π))∫_0^x exp(-t^2)dt` is correct. FTC 2 yields

`erf'(x) = (2/sqrt(π)) exp(-x^2) > 0`,

`erf''(x) = -(4x/sqrt(π)) exp(-x^2)`.

Consequently erf(0)=0, the function is odd, increases everywhere, is concave up for negative x and concave down for positive x, and has an inflection at zero. Figure 2 is qualitatively consistent with these facts and with limiting heights -1 and 1. It contains no numerical axis markings to interpret as measured values.

The stated limit erf(x)->1 as x->+infinity uses the additional Gaussian integral fact ∫_0^infinity exp(-t^2)dt=sqrt(π)/2. It does not follow from FTC 2 alone and is not proved in this lecture. Its negative-infinity counterpart is -1 by oddness. This limit may be quoted as source-provided context, not claimed as a result already established by the local FTC argument.

### 4. Logarithmic integral: domain, density model and exact integral bounds

For the printed ordinary integral `Li(x)=∫_2^x 1/ln(t)dt`, a natural domain is x>1. On this domain `Li'(x)=1/ln x`, `Li(2)=0`, and Li increases. For 1<x<2 the oriented integral is negative. At t=1, the integrand is singular; the ordinary improper integral to that point diverges, and an integral crossing it is not defined by this displayed proper-integral formula. A principal-value variant would be an extra definition, not implicit here.

The integral is an approximation/model for prime counts, not an exact count or a consequence of FTC. The source's basepoint-2 normalization differs by a constant from other logarithmic-integral conventions. For counts on a large interval, the model is the difference Li(B)-Li(A)=∫_A^B 1/ln t dt. No theorem about prime counting or its error is proved in the source.

Digit correction: 200-digit positive integers satisfy `10^199 <= n < 10^200`. The source instead integrates over `[10^200,10^201]`, whose interior represents 201-digit integers. Powers of ten at these endpoints are not prime, so endpoint-inclusion conventions do not fix the one-digit error.

Independent endpoint logarithms are:

- 199 ln 10 = 458.2144335058151;
- 200 ln 10 = 460.51701859880916;
- 201 ln 10 = 462.81960369180325.

The source's intermediate 460 and about 462 are coarse approximations obtained using ln 10≈2.3. Replacing the logarithm by 500 is a legitimate one-significant-figure simplification over either of the two enormous intervals above, but not a precise denominator.

The top line of physical p5 says `ln t≈500 for 200 <= t <= 10^201`. Its lower bound is a separate typo: at t=200, ln t≈5.298, not 500. For the printed integral that lower bound should be `10^200`; if correcting to the actual 200-digit interval, both bounds change to `10^199` and `10^200`.

For A>1, reciprocal-log monotonicity supplies rigorous bounds on the integral model:

`(B-A)/ln B <= ∫_A^B dt/ln t <= (B-A)/ln A`.

For the source's `[10^200,10^201]` interval, the bounds are

`1.9446021577757542 * 10^198 <= integral <= 1.9543251685646332 * 10^198`.

The source's constant-denominator calculation is exactly

`(10^201-10^200)/500 = 9*10^200/500 = 1.8*10^198`.

Thus `10^198` describes an order of magnitude, not the correct one-significant-figure rounding; the latter is `2*10^198`.

For the actual 200-digit interval `[10^199,10^200]`, the corresponding bounds are

`1.9543251685646332 * 10^197 <= integral <= 1.9641458980549076 * 10^197`.

Using 500 gives `1.8*10^197`, or `2*10^197` to one significant figure. These are estimates of the prime-count model; the displayed inequalities bound the integral, not the actual number of primes without a separate prime-counting error theorem.

The footnote's constant-integrand identity `∫_a^b c dx = c(b-a)` is correct, including oriented limits. Its ordinary rectangle-area explanation assumes nonnegative height and forward orientation; the algebra is more general.

### 5. Cryptography prose: inference not justified

The claims that a message can “only” be decoded with a secret prime and that the sheer number of possible primes makes a bank account secure are oversimplified. Even in a setting involving secret primes, counting candidates alone does not establish the difficulty of recovering a secret or the security of a protocol. A teaching document may retain the historical motivation, but must not present the candidate count as a proof of modern security or a current key-size recommendation. No external security guidance has been sought or supplied here; this assessment concerns the logical gap in the source's inference.

### 6. Fresnel functions, Bessel normalization and logarithm preview

The displayed Fresnel convention is

`C(x)=∫_0^x cos(t^2)dt`, `S(x)=∫_0^x sin(t^2)dt`.

These are valid definitions for every real x; they use the source's unscaled convention. FTC 2 gives `C'(x)=cos(x^2)` and `S'(x)=sin(x^2)`. The source's homework answer for C' is correct. The factor 2x belongs to differentiating cos(x^2) itself, hence to `C''(x)=-2x sin(x^2)`, not to C'. A variable upper endpoint g(x) would require a chain-rule factor g'(x), but that extension is not stated in this source and cannot automatically be treated as previously taught.

The Bessel formula on physical p5 is printed as

`J0(x) = (1/(2π))∫_0^π cos(x sin θ)dθ`.

This is half the standard normalized Bessel J0. At x=0 the displayed right side equals π/(2π)=1/2, whereas the standard J0 normalization is J0(0)=1. With limits 0 to π, the correcting factor is 1/π. Equivalently, one may retain 1/(2π) and integrate over a full 0-to-2π period. Expanding the printed integrand gives the printed function `1/2 - x^2/8 + x^4/128 - ...`, exactly half the normalized series `1 - x^2/4 + x^4/64 - ...`.

This example also has a different integral structure: its limits are fixed and x occurs inside the integrand. FTC 2 alone does not justify differentiating this parameter-dependent integral by substituting x into the integrand at an endpoint. Differentiation under the integral sign would be an additional result. One should not silently use the displayed Bessel function as another direct FTC 2 upper-limit example.

The preview `L(x)=∫_1^x dt/t` is defined as a proper real integral for x>0, satisfies L(1)=0 and L'(x)=1/x, and equals ln x on that domain. Extending the integral across zero would be invalid. The source explicitly postpones its first-principles development to the next lecture; properties of logarithms beyond this preview are not part of this source's proved material.

## Source-derived review boundaries for the future stage

This lecture directly supports: continuous-integrand accumulation functions; FTC 2 and its geometric/average-value justification; FTC 1 via FTC 2 and MVT; constants and basepoint normalization; differentiating the given simple upper-limit Gaussian/Fresnel examples; and interpreting several integral-defined special functions. It also presents the prime-density integral as an application of replacing a slowly varying integrand by a constant.

The lecture does not prove: non-elementarity of the listed antiderivatives; the Gaussian improper integral; a prime-counting theorem or its error bound; any cryptographic security theorem; the general variable-limit chain-rule formula; parameter differentiation under the Bessel integral; or the first-principles logarithm laws postponed to the next lecture. Such material could be developed in fresh teaching, but it needs its own explanation and prerequisites rather than being silently attributed to this packet.

A future prompt set must be read exactly and solved independently before any frozen teaching is opened. Any necessary domain, orientation, correction or additional prerequisite should be attached to the exact relevant prompt. These source-preparation findings do not substitute for exact prompt solutions.

## Next authorized step

Wait for the current applicable PROF instructions and finalized prompts from root. Record the exact files and hashes received; solve the exact prompts using only then-authorized materials; seal that solution record before opening teaching. After root identifies the complete frozen teaching, inspect all of that exact frozen artifact and report its mathematical correctness and prompt/solution alignment. Do not contact the author with findings before that freeze. Do not perform SASIS.
