from pathlib import Path
import sys,json,hashlib
root=Path("/workspace/scratch/f9c0b7fc7e76/original-inputs/D116")
r=Path(__file__).parent
role,prefix,done_lo,done_hi,next_lo,next_hi=sys.argv[1:]
for n in range(int(done_lo),int(done_hi)+1):
 for ext,log in [("txt","read-events.jsonl"),("png","view-events.jsonl")]:
  p=root/role/f"{prefix}-p{n:02d}.{ext}";b=p.read_bytes()
  d={"source":str(p),"sha256":hashlib.sha256(b).hexdigest(),"status":"actually read complete bounded output" if ext=="txt" else "actually inspected complete original image"}
  if ext=="txt": d.update(start_byte=0,end_byte_exclusive=len(b))
  else: d.update(detail="original")
  with (r/log).open("a") as f:f.write(json.dumps(d)+"\n")
for n in range(int(next_lo),int(next_hi)+1):
 p=root/role/f"{prefix}-p{n:02d}.txt"
 print("\nFILE "+str(p)+"\n"+p.read_text())
