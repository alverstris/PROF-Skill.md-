# D117 independent technical preparation

Status: original-source preparation complete. This is a technical dossier, not teaching, a teaching assessment, an acceptance decision, or a SASIS claim.

The only subject inputs used were `original-inputs/D117/**` and `d013-clean-r34-20261012/inputs/student-baseline.txt`. No installed/current PROF, teaching, old reports, queues, other cases, other agents' findings, browser sources, or GitHub content was consulted. No GitHub mutation was made. Semantic findings remain withheld from the parent until the parent announces that fresh whole teaching is frozen.

The original identity assigns MIT 8.02T Spring 2005 session 20, “Hour 1 Faraday’s Law Hour 2 Faraday’s Law: Applications”: the whole Chapter 10, the whole 42-slide presentation, and the whole 8-page PRS document. No chapter portion was silently omitted. Chapter PDF page 1 is the contents page; subsequent printed page numbers are one less than PDF page numbers.

Actual reading is recorded in `read-log.json`: all 1,323 identity lines, the whole 247,840-byte baseline in 21 contiguous bounded intervals, all 82 page TXT files, and all 82 original-resolution page PNGs. An initial truncated identity output was recovered by four bounded reads; a truncated image-output attempt for presentation pages 13–16 was recovered by re-viewing all four. Unseen output was not credited. Hashing was performed in addition to actual reading and viewing.

`source-coverage.md` maps the entire supplied scope. `calculations.md` contains independently derived answers and checks for the original worked examples, conceptual questions, additional problems, presentation group prompts and PRS. `baseline-to-demands.md` distinguishes assumed baseline competence, supplied new statements, and bridges that still require explanation. `INPUT_SHA256SUMS` fingerprints all three PDFs, all 164 page derivatives, the identity and the baseline. `SHA256SUMS` and `SEAL.json` bind this dossier without circular self-hashing.

The baseline SHA256 is `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. The identity SHA256 is `a498cfc2b39587839e1a7cb18230cf6da6513a89c4e4f62e59d93971b7ed7d30`.

No laboratory manual, demonstration movie, external applet, completed experimental observation, measured data, or apparatus protocol was supplied in this assigned packet. Slide links and still images are evidence of what was referenced, not evidence that those materials were read or experiments performed.
