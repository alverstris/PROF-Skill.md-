# Independent technical calculations

These results were derived from the original geometry and premises. Published answer pages were read as assigned source, then checked against the derivations. PDF page numbers below are one-based. Symbols B, l, v, R used as magnitudes are nonnegative. A signed normal and its right-hand positive contour are specified before using a signed emf. Unless an original problem supplies a capacitor, the elementary circuit model neglects self-inductance and uses total circuit resistance R; the consequences of that idealization are not experimental findings.

## 1. Shared sign, integral and energy checks

For a planar uniform field, flux per turn is Φ=B·A=BA cosθ, where θ is measured from the chosen area normal, not from the plane. Positive circulation is the right-hand circulation about that normal. Linkage is NΦ for N identical turns; emf is −d(NΦ)/dt. For constant N:

`emf = −N[A cosθ B' + B cosθ A' − BA sinθ θ']`.

For nonuniform field, partition the surface into small patches, sum B_normal ΔA, and take the limit. In the supplied straight-wire geometries this reduces to a single-variable strip integral, not an unexplained multidimensional integration exercise. Similarly, ∮E·ds sums tangential field times directed small path length. It is not generally a difference of endpoint electrostatic potentials.

With upward normal and positive CCW viewed from above:

| External flux change | Sign of dΦ/dt | Current in resistive loop | Induced field |
|---|---:|---|---|
| Upward magnitude increasing | + | CW | Down |
| Upward magnitude decreasing | − | CCW | Up |
| Downward magnitude increasing | − | CCW | Up |
| Downward magnitude decreasing | + | CW | Down |

The induced field opposes the change, and can point in the same direction as the external field. Emf can exist without a closed conducting circuit or measurable conduction current. Translation alone does not guarantee flux change.

Units: Wb=T m²=V s; dΦ/dt is volts; Blv is T m²/s=V; emf/R is amperes; IlB is newtons; emf²/R is watts. The drag coefficient k=B²l²/R has units kg/s, so m/k is seconds and force/k is m/s. The wire coefficient μ0 I l has units Wb and its logarithm must have a dimensionless argument. Field E from r B' has units V/m. Every exponential argument below is dimensionless.

## 2. Chapter exposition and worked physical mechanisms (PDF 2–17)

### Moving rod and rail circuit

The open vertical rod moves right in into-page B. For positive charges, v×B points up. Top a becomes positive, bottom b negative; the electrostatic field points down. At equilibrium qE=qvB, so E=vB and Va−Vb=Blv. Magnetic force does no work on a charge's total velocity; energy extracted in a closed circuit comes from the external mechanical agent.

For the right-hand sliding rod closing the left resistor circuit, choose out-of-page normal: Φ=−Blx, emf=+Blv. The current is CCW, up the moving rod, of magnitude Blv/R. The magnetic rod force is left, B²l²v/R. Constant speed requires equal external rightward force; the net force is zero. External power is Fv=B²l²v²/R=I²R. With external force removed, `m dv/dt=−(B²l²/R)v`; separation gives `v=v0 exp(−t/τ)`, τ=mR/(B²l²). Limits v(0)=v0 and v(∞)=0, and d(mv²/2)/dt=−I²R, independently check the sign. Distance travelled approaches v0τ.

For a moving/deforming conductor the magnetic part of emf is the directed sum ∮(u×B)·ds, using local conductor velocity u. It cannot be replaced by the same nonzero velocity on stationary rails. The stationary-contour electric law and the motional contribution require distinct explanations.

### Induced electric field inside and outside a circular field region

Let inward B(t)>0 occupy radius R, and choose CCW positive. For a concentric test circle radius r, Φ=−π min(r²,R²)B. Symmetry makes E tangential and constant around the circle, so

`2πr Eθ = π min(r²,R²) B'`.

Thus `Eθ=(r/2)B'` for r≤R and `Eθ=R² B'/(2r)` for r≥R. Increasing inward B produces CCW E. The expressions agree at R, vanish at r=0, and decay as 1/r outside. E can be nonzero where the local B is zero because the contour surrounds changing flux. This result depends on cylindrical symmetry; Faraday's law alone determines circulation, not the entire pointwise field in arbitrary geometry.

### Rotating generator and eddy currents

Choose initial normal parallel to B, θ=ωt. Per-turn flux is BA cosωt, linkage NBA cosωt, and emf=NBAω sinωt. For a resistive load, signed I=emf/R and P=emf I=emf²/R. The source expression containing both |emf| and signed sine must be read with that correction. Emf is zero at flux extrema and largest in magnitude when flux is zero. The magnetic torque opposes rotation; its magnitude is N|I|AB|sinθ|. External power τext ω equals emf²/R. The torque expression follows from the force couple and lever arm, or from the supplied magnetic moment μ=NIA; that moment is not silently assumed from the baseline.

For a metal slab leaving a bounded into-page B region, the relevant local current loops reinforce the diminishing inward flux. The part in the field experiences opposing drag; work becomes Joule heat. Cuts/lamination obstruct closed current paths. Decreasing R at a fixed flux-change rate increases current; a cooled copper ring's temperature dependence of resistance is an additional material premise, not a quantitative law established by the supplied still photograph. A jumping ring requires a growing field and a spatially varying field that can supply net upward force, not merely a uniform B and a torque.

The appendix frame comparison is useful at low speeds to link electric and magnetic descriptions of the same apparatus. It does not justify claiming exact equality of three-force between arbitrary inertial frames.

## 3. All six solved examples (10.9)

### 10.9.1 Rectangular loop next to a wire (PDF 18–19)

The upward source current produces into-page B on the loop's right-hand side. For near edge s, width w and parallel length l, the supplied straight-wire law gives B(r)=μ0 Is/(2πr), using Is for source current to distinguish it from induced current. Choose into-page normal:

`Φ = ∫s^(s+w) [μ0 Is/(2πr)] l dr = μ0 Is l/(2π) ln[(s+w)/s]`.

With Is=a+bt, `emf=−μ0 b l/(2π) ln[(s+w)/s]`. Negative into-positive circulation means CCW for b>0. Current magnitude is |emf|/R if resistance R is specified. Flux tends to zero as w→0; its logarithm is dimensionless.

### 10.9.2 Square compressed into a rhombus (PDF 19–20)

The side length remains l and the internal obtuse angle is θ; area is l²sinθ, not l²cosθ. Inward flux falls from Bl² to Bl²sinθ. The mean emf magnitude is Bl²(1−sinθ)/Δt, hence mean current magnitude `Bl²(1−sinθ)/(RΔt)`, CW. This is an interval average; no compression law is supplied from which to infer instantaneous I(t).

### 10.9.3 Sliding bar between two circuits (PDF 20–21)

The bar moves left in into-page B; v×B points down, making the bottom positive. Each resistor carries upward current `Ij=Blv/Rj`, j=1,2. The left loop current is CW and the right loop current CCW; the common bar carries their sum downward. Magnetic force on the bar is right:

`FB=B²l²v(1/R1+1/R2)`.

External leftward force maintains speed; total heat and external power are `B²l²v²(1/R1+1/R2)`. The loops do not have cancelling bar currents.

### 10.9.4 Rod parallel to a straight wire (PDF 21–22)

The source current points left; at the rod above it B is into-page. The rod moves upward, giving v×B left, so the left end is at higher potential. Field is constant along this rod because its distance r from the wire is constant along its length l. Therefore `|emf|=μ0 Is l v/(2πr)`. A logarithm would be inappropriate here; that belongs to a rod/area spanning different distances from the wire.

### 10.9.5 Circular loop with changing B (PDF 22–23)

For radius a and inward B=B0+bt, choose inward normal: Φ=πa²(B0+bt), emf=−πa²b. For b>0 current is CCW, magnitude πa²b/R, and heat rate is `(πa²b)²/R`. Constant B0 affects flux but not emf.

### 10.9.6 Loop translating away from a wire (PDF 23–24)

Source current points left; loop above the wire has into-page flux. Its horizontal length is l, vertical width w, near distance r, and r'=v>0. With inward normal:

`Φ=μ0 Is l/(2π) ln[(r+w)/r]`;

`emf=−μ0 Is l v/(2π)[1/(r+w)−1/r]=μ0 Is l v w/[2πr(r+w)]`.

Current is CW, upward through the left resistor. The alternative calculation is the near rod motional emf minus the smaller far rod contribution. This confirms both the difference of reciprocals and the sign. As r increases, the magnitude falls.

## 4. All four conceptual questions (10.10, PDF 25)

1. The magnet falls S-first in the picture. Upward flux through the horizontal loop first increases, then decreases. With CCW-from-above positive, induced current has a negative pulse followed by a positive pulse, passing zero at a flux extremum. An exact waveform is not supplied. Free fall does not imply constant speed or time-symmetric pulses; magnetic back-reaction may also alter the motion.
2. Upper loop A has CCW current viewed from above and produces upward flux at lower loop B. If IA decreases, B's induced current is CCW and the loops attract. If IA increases, B's induced current is CW and the loops repel. A spatially varying mutual field supplies the net force; a uniform-field torque formula alone cannot establish translation.
3. An equatorial emf in a conducting shell is determined by the changing flux through the equatorial disk. For a changing uniform field normal to that disk it exists; “time-varying B” without direction/spatial specification is not sufficient. A field parallel to that disk can give zero equatorial flux and circulation. Zero net flux through a closed spherical surface is a different statement and does not forbid a nonzero loop emf.
4. A rigid loop translating entirely within a uniform constant B with fixed area and orientation has constant flux and zero net emf. Local magnetic forces and charge separation need not vanish. Entering/leaving a bounded field or moving through nonuniform B changes this conclusion.

## 5. All eleven additional problems and their subparts (10.11)

### 10.11.1 Battery-driven sliding bar (PDF 26)

The battery top plate is positive; the current in the left bar initially points down, with B out of page, so the bar accelerates left. Let v≥0 mean leftward speed. Motional emf opposes the battery:

`I=(emf_battery−Blv)/R`, `m v'=Bl I`.

The first-order equation is `v'+v/τ=emf_battery/(Blτ)`, τ=mR/(B²l²). With v(0)=0:

`v(t)=emf_battery/(Bl)[1−exp(−t/τ)]`.

The initial acceleration is Bl emf_battery/(mR); terminal current is zero. The result uses an ideal maintained battery emf and ignores self-inductance.

### 10.11.2 Sliding bar on wedges (PDF 26–27)

There is an original contradiction: prose B is vertically downward, arrows in the diagram upward. Taking the prose, downward motion along the slope gives current a→b. Taking the arrows instead gives b→a. Both yield the same opposing magnetic force and magnitudes below.

Only B cosθ is normal to the slope. For instantaneous downslope speed v, `|emf|=Blv cosθ`, `I=Blv cosθ/R`. Magnetic force on the horizontal bar has magnitude IlB, lies horizontally, and has upslope component IlB cosθ. Thus

`m v'=mg sinθ−(B²l² cos²θ/R)v`.

(b) `v_terminal=mgR sinθ/(B²l²cos²θ)`.

(c) `I_terminal=mg tanθ/(Bl)` with the direction above.

(d) `P_heat=I_terminal²R=m²g²R sin²θ/(B²l²cos²θ)`.

(e) Gravity power `mg v_terminal sinθ` equals that same expression.

The two factors of cosθ have different origins: projected swept flux and force projection. For θ=0 there is no gravity-driven motion; as θ→π/2 the braking tends to zero and there is no finite terminal speed for the ideal vertical limit. R is used as total loop resistance despite the picture drawing a resistor separately from the prose's bar resistance.

### 10.11.3 RC circuit in changing B (PDF 27)

Inward B magnitude decreases at rate α>0. The emf drives a CW circulation with magnitude ε0=απr². At the bottom gap CW motion approaches plate b from the right, so b becomes positive and a negative; b is at higher potential. For an initially uncharged ideal capacitor and a ramp maintained sufficiently long, `q_max=Cε0=Cαπr²`. From `R dq/dt+q/C=ε0`, `q(t)=Cε0[1−exp(−t/RC)]`. If the finite original B ramp stops earlier, the attained charge is smaller; the phrase maximum presumes the usual sustained-drive limiting value. Initially charged states are not specified.

Charges separate because the changing flux creates circulating electric field, with accumulating capacitor charge providing an opposing electrostatic field. It is not a magnetic force on stationary charges. The local capacitor voltage can be defined even though a global path-independent potential cannot represent the entire induced E field.

### 10.11.4 Bar pulled by hanging mass (PDF 27–28)

The horizontal bar moves towards the pulley in upward B. From v×B, bar current is b→a, magnitude `I=Blv/R`. Set k=B²l²/R. With tension T, `m v'=T−kv`, and for hanging mass M, `M v'=Mg−T`. Both bodies accelerate at the same speed rate, so

`(m+M)v'=Mg−kv`;

`v(t)=MgR/(B²l²)[1−exp(−B²l²t/((m+M)R))]`.

Initial acceleration Mg/(m+M) and limiting speed Mg/k check the inclusion of both inertias. Using m alone in the time constant is incorrect.

### 10.11.5 Rotating rod (PDF 28)

At radius r, v=ωr, perpendicular to B, so magnetic force magnitude is qBωr. In the pictured CCW rotation with B into-page, positive charges are driven radially inward. Electrostatic E therefore points radially outward with magnitude Bωr at equilibrium. With tip at r=l and pivot O:

`V_tip−V_O=−∫0^l Bωr dr=−Bωl²/2`.

The requested positive ΔV=Bωl²/2 is a magnitude, or V_O−V_tip. The speed varies along the rod; using the tip speed over the whole length gives a factor-of-two error.

### 10.11.6 Rectangular loop crossing bounded field (PDF 28)

Image dimensions: l=0.10 m vertical, w=0.080 m horizontal, field-region width L=0.40 m. Speed v=0.020 m/s, B=2.0 T inward, R=2.0 Ω. The front enters at t=0, the rear enters at 4 s, the front exits at 20 s, and the rear exits at 24 s. Choose inward normal, positive CW.

| Time interval (s) | Inward flux (Wb) | Signed emf (V) | Signed current (A) / direction |
|---|---|---:|---|
| 0<t<4 | 0.004 t | −0.004 | −0.002, CCW |
| 4<t<20 | 0.016 | 0 | 0 |
| 20<t<24 | 0.004(24−t) | +0.004 | +0.002, CW |
| t>24 | 0 | 0 | 0 |

Before entry all are zero. These expressions determine the requested graphs including units and transition times. Flux is continuous with corners; the ideal emf/current have steps, not impulses. At exactly a corner the classical derivative is not defined; one-sided values suffice.

### 10.11.7 Magnet through coil at constant speed (PDF 29)

North enters first from the left. Positive CW current seen from the left corresponds to rightward normal. For the usual coaxial symmetric bar magnet, Φ is a positive hump, maximum at t=0 and approaching zero far before/after. `I=−Φ'/R`: negative (CCW from left) before the centre, zero at the centre, positive (CW from left) after. With symmetric magnet geometry and constant speed the qualitative hump is even and current odd; do not assign an unsupported amplitude or detailed shape.

Just before entry the magnet is repelled left; just after exit it is attracted left. Both forces oppose rightward motion. The external pulling agent supplies the heat dissipated in the stationary loop. Constant speed means this work is not drawn from a decreasing kinetic energy of the magnet.

### 10.11.8 AC generator (PDF 29–30)

Use original-page coordinates X right along the rotation axis, Y up, Z out. The left observer looks along +X; their screen-right direction is +Z, so B=−Z appears leftward. CCW rotation to that observer has angular velocity −X. Shortly after t=0 the top edge has moved towards −Z and the bottom towards +Z: in that view the loop's edge tilts upper-left/lower-right. Since flux along the initial B direction is decreasing, current reinforces it. The upper-left long conductor carries current away from the left observer (+X, a cross), and the lower-right conductor towards the observer (−X, a dot). This supplies the requested sketch's orientation information without confusing the viewing plane with the original page.

With initial normal parallel to B, θ=2πft. Per-turn `Φ=abB cos(2πft)`; total linkage is N times this. `emf=2πfNabB sin(2πft)`, with peak ε0=2πfNabB. For ε0=120 V, f=60 s⁻¹ and B=.40 T, `Nab=0.7957747155 m² turn`. One design is N=100, a=b=0.0892062 m. This is a voltage/geometry design only; wire resistance, current rating, heat and mechanical construction are not specified. 120 V is the stated peak, not RMS.

### 10.11.9 Time-varying field graph (PDF 30–31)

The positive contour is CCW, matching out-of-page positive Bz; r=.50 m, R=20 Ω. `emf=−πr² dBz/dt`. Graph slopes are +2.5 T/s on 0–2 s, 0 on 2–4 s, and −1.25 T/s on 4–8 s.

| Time interval (s) | Signed emf (V) | Signed current (A) | Through bottom resistor | Heat rate (W) |
|---|---:|---:|---|---:|
| 0<t<2 | −5π/8 ≈ −1.96350 | −π/32 ≈ −0.0981748 | Right to left | 5π²/256 ≈ .192766 |
| 2<t<4 | 0 | 0 | None | 0 |
| 4<t<8 | +5π/16 ≈ +.981748 | +π/64 ≈ +.0490874 | Left to right | 5π²/1024 ≈ .0481914 |
| t>8 | 0 | 0 | None | 0 |

Emf/current plots are signed horizontal levels, with graph transitions at 0,2,4,8 s. The power plot is always nonnegative. Source partial answers list magnitudes and round the first power to 192 mW; direct calculation is approximately193 mW to three significant figures. These are ideal step discontinuities, not delta-function impulses.

### 10.11.10 Tilted square leaving field (PDF 31)

The square side is l, horizontal diagonal D=√2 l. At t=0 the right vertex touches the vertical boundary while the square is entirely inside. Let d=vt measure penetration beyond the boundary. The cut height is `h=2d` for 0<d<D/2 and `h=2(D−d)` for D/2<d<D. The remaining area is `l²−d²` in the first interval and `(D−d)²` in the second. Thus `−dA_inside/dt=vh`.

Emf magnitude is Bvh and external power at constant speed is `P=emf²/R=B²v²h²/R`:

`P(t)=4B²v⁴t²/R` for 0<t<l/(√2v);

`P(t)=4B²v²(√2l−vt)²/R` for l/(√2v)<t<√2l/v;

`P(t)=0` after √2l/v.

It begins and ends at zero and peaks at `2B²v²l²/R`. Decreasing inward flux gives CW current. External pulling force has magnitude P/v and points right; the magnetic drag points left. Treating the cut width as a constant l would miss the geometry.

### 10.11.11 Falling loop (PDF 31–32)

The source axes are B=+B i (out of page), width to +j (right), vertical +k (up), and velocity −v k. As the loop exits below, outward flux decreases. Current is CCW viewed on the page, with `|emf|=Bwv` and `I=Bwv/R`. The top horizontal segment, still in B, carries current −j, so `I(−w j)×(B i)=+IBw k`: upward. Side forces cancel horizontally and the bottom is outside B. Thus `FB=B²w²v/R` upward.

At terminal speed `mg=B²w²v_terminal/R`, hence `v_terminal=mgR/(B²w²)`. Gravity power `mg v_terminal=m²g²R/(B²w²)=I_terminal²R`, proving the requested equality. This terminal balance applies only during partial overlap. A finite-height field/loop may not allow time to attain it; after complete exit there is no induced current in the elementary model and free fall resumes.

## 6. Presentation group prompts and PRS

Presentation 6–7: a solenoid with n turns per unit original length is bent into a torus of major radius R, so N=2πRn. On the original axis, now the circle r=R, symmetry and supplied magnetostatic Ampère law give `B 2πR=μ0NI`, hence `B=μ0nI`. More generally inside the ideal torus `B(r)=μ0NI/(2πr)`. The tube radius a does not enter the central value; approximating all interior points by that value would additionally require a≪R. Winding arrows, not the formula's unsigned I, determine direction. Page 7 inner crosses/outer dots give clockwise B in its section; page 5 has the reverse winding.

Presentation 27: as the magnet approaches the cooled copper ring, changing flux drives current, which makes a field opposing the approach. Mechanical work is dissipated as heat. If cooling lowers R while the imposed flux-change rate is held fixed, current increases; the actual free-fall speed and hence induced emf respond dynamically. The still and statement do not specify a resistance-temperature curve, quantitative force, or experiment result beyond the described slowdown.

Presentation 30, all five prompts: rightward bar in into-page B gives CCW current, magnetic force left, emf magnitude Blv, current Blv/R, and supplied power B²l²v²/R. If “resultant force” means the total force while velocity is constant, it is zero; the external force is right and balances magnetic drag. The left resistor carries current down, the rod up.

PRS 1/2: current is CCW from above, dipole upward. Resolve the diverging upward field into upward and radially outward components. The upward component gives radial forces that cancel; the outward component with tangential CCW current gives downward forces all around the loop. In a local cylindrical basis, `e_phi × (Br e_r + Bz e_z)=−Br e_z+Bz e_r`. Thus option 2, down. A moment aligned with B does not imply zero force in this nonuniform field; it only makes the simplest torque vanish.

PRS 3/4: upward flux increasing requires downward induced field, hence CW from above, option 1.

PRS 5/6: upward flux decreasing requires upward induced field, hence CCW from above, option 2.

PRS 7/8: below the magnet the field is upward and radially inward; as the loop moves down its upward flux falls. CCW current maintains upward field. With Br<0 the axial contribution −I Br is upward; radial forces cancel. Thus option 1, up. This also agrees with attraction toward the upper magnet and resistance to downward separation.

The source's technology slides name multiple applications but provide no quantitative tasks for detector, GFI, stovetop, speaker or guitar. The pickup diagram supports a qualitative chain: vibrating magnetic string changes coil flux, causing an emf signal. It does not supply a complete circuit model or justify fitting the displayed illustrative waveform.
