# Complete source coverage

Every PDF page listed below had its entire TXT read and its whole PNG inspected through `view_image` with `detail=original`. Per-file hashes and actual read/view records are in `read-log.json`. This table describes content coverage, not a substitute for that log.

## Chapter 10, PDF pages 1–32

| PDF pages | Supplied content and inspected visual evidence | Independent technical coverage |
|---|---|---|
| 1 | Contents, all sections through 10.11.11 | Scope includes contents, appendix, conceptual and additional problems |
| 2 | Moving/stationary magnet and galvanometer, three relative-motion cases | Changing flux, no universal “motion implies current” rule |
| 3–4 | Flux integral, surface normal, Faraday law, changing B/area/angle drawings | Orientation convention and product derivative |
| 5–6 | Right-hand contour convention and four increasing/decreasing field cases | Four-case direction table |
| 7 | Moving open rod, charge separation, magnet approaching a loop | Motional force, electrostatic balance and terminal voltage |
| 8–9 | Sliding right-hand bar, rails, resistor, drag and exponential slowdown | Signed emf, current, magnetic/external/net force, power and ODE |
| 10–12 | Stationary loop with changing B, concentric inside/outside circles | Nonconservative E, symmetry and enclosed field area |
| 12–13 | AC generator, coil torque and mechanical power | Phase, signed current, torque and energy |
| 14 | Slab leaving bounded B; eddy-current loops | Opposing drag and disrupted current paths |
| 15 | Summary equations | Conditions and sign conventions checked |
| 16 | Appendix frame comparison | Low-speed qualitative frame argument; no general equality-of-forces claim |
| 17 | Problem-solving strategy | Operational geometry → flux → emf → circuit → force checks |
| 18–19 | 10.9.1 rectangular loop next to upward-current straight wire | Strip integral, logarithm and current direction |
| 19–20 | 10.9.2 square compressed to rhombus, obtuse angle shown | Area and average current |
| 20–21 | 10.9.3 moving bar between two resistor loops | Branch currents, total bar current and power |
| 21–22 | 10.9.4 rod parallel to wire, moving away | Field uniform along rod; voltage endpoints |
| 22–23 | 10.9.5 stationary circular loop in linearly increasing into-page B | Signed flux/emf, current, dissipation |
| 23–24 | 10.9.6 rectangular loop moving away from wire | Nonuniform flux derivative and near/far-edge check |
| 25 | 10.10.1–4, falling S-first magnet, two coaxial loops, shell and translating loop | Four complete conceptual responses |
| 26 | 10.11.1 battery-bar circuit; 10.11.2 wedge geometry and conflicting field arrows | Battery/back-emf ODE; both wedge direction interpretations |
| 27 | Wedge parts d/e; 10.11.3 capacitor plates; 10.11.4 pulley and mass | Work/heat equality; capacitor charge/polarity; coupled masses |
| 28 | Pulley part b; rotating rod; rectangular loop and 40 cm field region | ODE, radial integration, piecewise overlap graphs |
| 29 | Magnet through loop; generator setup | Signed qualitative graphs, force, energy, rotation convention |
| 30 | Generator figure/subparts; circular loop and quantitative Bz trapezoid | Generator design and endpoint directions; graph slopes/signs |
| 31 | Bz graph parts b–d; tilted square; falling-loop setup | Signed emf/current/power levels; triangular cuts; terminal condition |
| 32 | Falling-loop diagram and parts a–e | Vector signs, braking, terminal speed and power equality |

## Presentation, pages 1–42

| Pages | Supplied content | Coverage |
|---|---|---|
| 1–4 | Session title, prior dipole force, PRS cue, Ampère title | Prior-topic claims not silently treated as baseline |
| 5 | Four Ampère geometries and field/current pictures | Symmetry, oriented current; torus winding direction checked |
| 6–7 | Solenoid bent to torus group question and Ampère contour hints | N=2πRn; central B=μ0nI; separate winding arrows on page 7 |
| 8 | Faraday/Maxwell title with missing-Ampère-term caveat | Magnetostatic scope acknowledged |
| 9–13 | Falling magnet and jumping ring demo titles/photos | Qualitative induction, cooling premise and nonuniform-field force; no unseen movie claim |
| 14–16 | Induction demo, magnet/galvanometer image, visualization still | Flux change; field-line “hung up” language treated as heuristic |
| 17–22 | Faraday repetitions, emf integral, flux normal, Lenz picture | Operational integral and sign conventions, potential distinction |
| 23–26 | PRS cue, Faraday, three ways to vary flux | Product derivative and role of normal-angle |
| 27–28 | Falling cooled-ring discussion and moving-loop PRS cue | Qualitative mechanism; PRS force independently derived |
| 29–31 | Vary-B/area examples; sliding-rod group question | All five questions answered; ambiguous “resultant force” resolved |
| 32–33 | Face-on/edge-on coils, applet stills/link | Flux extrema versus emf extrema; no unseen applet behavior inferred |
| 34–35 | Four integral Maxwell statements, incomplete Ampère acknowledged | Closed surface versus contour and static Ampère distinction |
| 36–38 | Application heading, DC motor pictures, AC generator slip rings/formula | Torque versus emf, cos/sin phase and mechanical energy |
| 39–40 | Speaker link; detector link, stovetop and GFI names | Only topic references supplied; exact devices/protocols not supplied |
| 41–42 | Magnetic pickup/string diagram and guitar demo title | Moving string changes pickup flux; no measured waveform fit claimed |

## PRS, pages 1–8

| Question / answer pages | Visual facts | Independently derived result |
|---|---|---|
| 1 / 2 | Upward dipole; upward field diverging radially outward; front current right | Option 2, downward net magnetic force |
| 3 / 4 | Upward B increasing; viewing convention from top | Option 1, clockwise |
| 5 / 6 | Upward B decreasing; same viewing convention | Option 2, counterclockwise |
| 7 / 8 | Loop below magnet moving down; upward/inward field and CCW current | Option 1, upward magnetic force |

## Diagram and wording qualifications

- Chapter 10.11.2 prose says vertically downward B; Figure 10.11.2 draws upward arrows. This reverses bar current, but not braking speed or dissipated power. Both interpretations are retained explicitly.
- Chapter 10.11.6 supplies the 40 cm field-region width in the image, not extracted prose. It is essential to the 20 s exit-start time.
- Chapter 10.11.9 gives unsigned partial answer values; the stated positive contour and graph determine the signed answers. The first nonzero emf is negative.
- Chapter 10.11.5 gives a positive potential-difference magnitude without endpoint order. For the pictured rotation/field, the pivot is at higher potential.
- Chapter generator equation 10.4.4 mixes `I=|emf|/R` with a signed sine expression. Signed current is emf/R; current magnitude is |emf|/R.
- Presentation page 30 asks for “resultant force” while prescribing constant velocity. Magnetic resultant is left; total resultant including the pulling force is zero.
- The torus arrows on presentation page 7 reverse the winding shown on page 5. The magnitude calculation is unaffected; directions must follow each actual figure.
- Appendix 10.7 points to section 10.4 for induced electric fields, though that discussion is section 10.3. Its equal-force argument is a low-speed heuristic, not a general relativistic transformation law.

No page was excluded as merely repetition, an answer page, optional review, or an application heading. No linked site, animation or lab manual was added to the subject evidence.
