from pathlib import Path
import json,sys,hashlib
root=Path(__file__).parent;items=json.loads((root/'required-pages.json').read_text())
notes=json.loads(sys.stdin.read())
with (root/'view-log.jsonl').open('a') as f:
 for k,note in notes.items():
  i=int(k);d=items[i];p=Path('original-inputs/D118')/d['image_file'];f.write(json.dumps(dict(page_index=i,path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),dimensions=d['image_dimensions'],detail='original',actual_view=True,observation=note))+'\n')
