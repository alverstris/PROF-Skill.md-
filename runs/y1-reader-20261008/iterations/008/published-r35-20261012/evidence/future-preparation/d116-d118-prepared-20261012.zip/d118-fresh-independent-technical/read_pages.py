from pathlib import Path
import json,sys,hashlib
root=Path(__file__).parent
pending=root/'pending-pages.json'
if pending.exists():
 with (root/'read-log.jsonl').open('a') as f:
  for rec in json.loads(pending.read_text()): rec.update(actual_read=True,truncated=False);f.write(json.dumps(rec)+'\n')
 pending.unlink()
items=json.loads((root/'required-pages.json').read_text());ids=[int(x) for x in sys.argv[1:]];out=[];records=[]
for i in ids:
 d=items[i];p=Path('original-inputs/D118')/d['text_file'];b=p.read_bytes();s=b.decode();out.append(f'PAGE_INDEX {i} PATH {p} CHARS [0,{len(s)})\n'+s);records.append(dict(path=str(p),kind='page_text',char_start=0,char_end_exclusive=len(s),source_chars=len(s),source_bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),page_index=i))
assert sum(len(s) for s in out)<=12000
print('\n'.join(out));pending.write_text(json.dumps(records))
