from pathlib import Path
import sys,json,hashlib
root=Path(__file__).parent
pending=root/'pending-read.json'
if pending.exists():
 with (root/'read-log.jsonl').open('a') as f:
  rec=json.loads(pending.read_text());rec.update(actual_read=True,truncated=False);f.write(json.dumps(rec)+'\n')
 pending.unlink()
p=Path(sys.argv[1]);start=int(sys.argv[2]);end=int(sys.argv[3]);b=p.read_bytes();s=b.decode('utf-8');end=min(end,len(s))
rec=dict(path=str(p),kind='text',char_start=start,char_end_exclusive=end,byte_start=len(s[:start].encode()),byte_end_exclusive=len(s[:end].encode()),source_chars=len(s),source_bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert end-start<=12000
print(json.dumps(rec));print(s[start:end]);pending.write_text(json.dumps(rec))
