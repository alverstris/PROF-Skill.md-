from pathlib import Path
import hashlib, json, math
from PIL import Image

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
D = ROOT / 'd118-fresh-independent-technical'
S = ROOT / 'original-inputs/D118'
BASE = ROOT / 'd013-clean-r34-20261012/inputs/student-baseline.txt'
sha = lambda b: hashlib.sha256(b).hexdigest()
identity = json.loads((S / 'source-identity.json').read_text())
pages = json.loads((D / 'required-pages.json').read_text())
reads = [json.loads(x) for x in (D / 'read-log.jsonl').read_text().splitlines()]
views = [json.loads(x) for x in (D / 'view-log.jsonl').read_text().splitlines()]
assert not list(D.glob('pending-*.json')), 'Uncommitted read log'
assert len(pages) == 81
assert all(x['actual_read'] and not x['truncated'] for x in reads)
assert all(x['actual_view'] and x['detail'] == 'original' for x in views)

def interval_check(entries, key0, key1, total):
    intervals = sorted((x[key0], x[key1]) for x in entries)
    pos = 0
    for start, end in intervals:
        assert start == pos and end > start, (pos,start,end)
        pos = end
    assert pos == total, (pos,total)
    return intervals

meta_reads = [x for x in reads if x['path'] == 'original-inputs/D118/source-identity.json']
baseline_reads = [x for x in reads if x['path'] == str(BASE.relative_to(ROOT))]
text_reads = [x for x in reads if x['kind'] == 'page_text']
assert len(meta_reads) == 7 and len(baseline_reads) == 21 and len(text_reads) == 81
meta_bytes = (S / 'source-identity.json').read_bytes()
baseline_bytes = BASE.read_bytes()
assert len(baseline_bytes) == 247840
assert sha(baseline_bytes) == '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
meta_intervals = interval_check(meta_reads,'char_start','char_end_exclusive',len(meta_bytes.decode('utf8')))
baseline_char_intervals = interval_check(baseline_reads,'char_start','char_end_exclusive',len(baseline_bytes.decode('utf8')))
baseline_byte_intervals = interval_check(baseline_reads,'byte_start','byte_end_exclusive',len(baseline_bytes))
assert all(x['sha256']==sha(meta_bytes) for x in meta_reads)
assert all(x['sha256']==sha(baseline_bytes) for x in baseline_reads)
assert {x['page_index'] for x in text_reads} == set(range(81))
assert len(views)==81 and {x['page_index'] for x in views} == set(range(81))

manifest = []
def add(path, role, expected=None):
    raw=path.read_bytes()
    digest=sha(raw)
    if expected: assert digest==expected, str(path)
    item={'path':str(path.relative_to(ROOT)),'role':role,'bytes':len(raw),'sha256':digest}
    manifest.append(item)
    return item
add(S/'source-identity.json','source_identity')
add(BASE,'complete_baseline')
asset_coverage=[]
for asset in identity['assets']:
    entry=add(S/asset['local_pdf'],'original_pdf',asset['sha256'])
    assert entry['bytes']==asset['bytes']
    required=asset.get('required_pdf_pages',list(range(1,asset['page_count']+1)))
    ranges=asset.get('assigned_ranges',[{'sections':'entire asset','pdf_page_range':[min(required),max(required)],'start_boundary':'PDF beginning','end_boundary':'PDF end'}])
    asset_coverage.append({'role':asset['role'],'chapter':asset.get('chapter'),'pdf':asset['local_pdf'],'assigned_ranges':ranges,'required_pdf_pages':required})
for i,p in enumerate(pages):
    t=next(x for x in text_reads if x['page_index']==i)
    v=next(x for x in views if x['page_index']==i)
    ti=add(S/p['text_file'],'actually_read_page_text',p['text_sha256'])
    vi=add(S/p['image_file'],'actually_viewed_page_image',p['image_sha256'])
    assert t['sha256']==ti['sha256'] and v['sha256']==vi['sha256']
    assert t['char_start']==0 and t['char_end_exclusive']==len((S/p['text_file']).read_bytes().decode('utf8'))
    with Image.open(S/p['image_file']) as im:
        assert list(im.size)==p['image_dimensions']==v['dimensions']
    assert t['path']==ti['path'] and v['path']==vi['path']
assert len(manifest)==168
(D/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
coverage={
 'case':'D118','subject_source_policy':'original D118 plus complete designated baseline only',
 'source_identity_sha256':sha(meta_bytes),'source_identity_chars':len(meta_bytes.decode('utf8')),
 'source_identity_actual_read_intervals':meta_intervals,
 'baseline_sha256':sha(baseline_bytes),'baseline_bytes':len(baseline_bytes),'baseline_chars':len(baseline_bytes.decode('utf8')),
 'baseline_actual_read_char_intervals':baseline_char_intervals,'baseline_actual_read_byte_intervals':baseline_byte_intervals,
 'all_four_subjects_read':True,'both_further_maths_options_read':True,
 'required_text_pages':81,'actually_read_complete_text_pages':81,
 'required_image_pages':81,'actually_viewed_original_resolution_pages':81,
 'source_pdf_hashes_verified':4,'input_manifest_files':168,
 'assets':asset_coverage,'truncation_status':'All counted reads/views untruncated; abandoned oversized visual response recovered completely; see provenance.txt',
 'chapter11_scope':'Section11.1 only; full PDF page5 viewed/read; portion at/after heading11.2 excluded from demand scope',
 'evidence_status':'Independent preparation; no teaching acceptance, generation assessment, or SASIS conclusion',
 'semantic_disclosure_to_root':'withheld pending explicit whole-teaching freeze'
}
(D/'source-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
numeric={
 'generator_required_Nab_m2_turn':120/(2*math.pi*60*.4),
 'generator_square_side_m_for_100turns':math.sqrt(120/(2*math.pi*60*.4*100)),
 'Bgraph_first_emf_V':-5*math.pi/8,'Bgraph_second_emf_V':5*math.pi/16,
 'Bgraph_first_current_A':-math.pi/32,'Bgraph_second_current_A':math.pi/64,
 'Bgraph_first_power_W':5*math.pi**2/256,'Bgraph_second_power_W':5*math.pi**2/1024,
 'entry_emf_V':2*.10*.02,'entry_current_A':2*.10*.02/2,
 'entry_power_W':(2*.10*.02)**2/2,'entry_breaks_s':[.08/.02,.40/.02,.48/.02],
 'transmission_low_I_A':120000/240,'transmission_low_loss_W':(120000/240)**2*.40,
 'transmission_high_I_A':120000/24000,'transmission_high_loss_W':(120000/24000)**2*.40,
}
(D/'arithmetic-check.json').write_text(json.dumps(numeric,indent=2)+'\n')
bound=[]
for p in sorted(D.rglob('*')):
    if p.is_file() and p.name not in {'SHA256SUMS','SEAL'}:
        bound.append(f'{sha(p.read_bytes())}  {p.relative_to(D).as_posix()}')
(D/'SHA256SUMS').write_text('\n'.join(bound)+'\n')
manifest_digest=sha((D/'SHA256SUMS').read_bytes())
seal={'case':'D118','type':'fresh-independent-technical-preparation','file_manifest_sha256':manifest_digest,'bound_file_count':len(bound),'baseline_sha256':sha(baseline_bytes),'text_pages':81,'original_image_pages':81,'semantic_release':'withheld_pending_whole_teaching_freeze','acceptance_claim':False}
(D/'SEAL').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'verified':True,'read_entries':len(reads),'view_entries':len(views),'input_files':len(manifest),'bound_files':len(bound),'SHA256SUMS':manifest_digest,'SEAL':sha((D/'SEAL').read_bytes())},indent=2))
