"""Reproducible numeric spot checks for D025; analytical proofs are in the report.

Only Python's standard library is used. This script reads no source file and
does not consult a CAS, web service, prior audit, teaching, or prompt packet.
"""
import json
import math


def derivative(f, x):
    h = 1e-5 * max(1.0, abs(x))
    return (f(x - 2*h) - 8*f(x - h) + 8*f(x + h) - f(x + 2*h)) / (12*h)


def simpson(f, lo, hi, n=4000):
    h = (hi-lo)/n
    return h/3 * (f(lo)+f(hi)+sum((4 if i%2 else 2)*f(lo+i*h) for i in range(1,n)))


checks = []
def check(label, observed, expected, tolerance=2e-8):
    residual = observed-expected
    passed = abs(residual) <= tolerance*max(1.0, abs(expected))
    checks.append(dict(label=label, observed=observed, expected=expected,
                       residual=residual, relative_scale_tolerance=tolerance, passed=passed))
    assert passed, label


for a in [0.5, 1.0, 2.0, 3.0]:
    A = lambda x: a*a/2*math.asin(x/a)+x/2*math.sqrt(a*a-x*x)
    for q in [-0.75, -0.5, 0, 0.5, 0.75]:
        x = q*a
        check(f"area derivative a={a} x/a={q}", derivative(A,x), math.sqrt(a*a-x*x))
        check(f"area quadrature a={a} x/a={q}", simpson(lambda t:math.sqrt(a*a-t*t),0,x), A(x))
    check(f"area positive endpoint a={a}", A(a), math.pi*a*a/4)
    check(f"area negative endpoint a={a}", A(-a), -math.pi*a*a/4)
    check(f"figure 3 area a={a} x=a/2", A(a/2), math.pi*a*a/12+math.sqrt(3)*a*a/8)

for u in [0.15,0.5,1.0]:
    bad = lambda z: z/4+math.sin(z)*math.cos(z)/2
    check(f"u/4 error derivative residual u={u}", derivative(bad,u)-math.cos(u)**2,-0.25)
    primitive = lambda z: math.log(abs(1/math.cos(z)+math.tan(z)))
    sec = 1/math.cos(u)
    check(f"sec primitive u={u}", derivative(primitive,u),sec)
    check(f"stray factor 2 residual u={u}", derivative(primitive,u)-2*sec,-sec)

for x in [-10,-5,-4.5,0.5,1,6]:
    F = lambda z: math.log(abs(z+2+math.sqrt(z*z+4*z)))
    check(f"completed-square primitive x={x}", derivative(F,x),1/math.sqrt(x*x+4*x))

for x in [-3,-1,0,2,4]:
    G = lambda z: math.log(abs(z-1))+3*math.log(abs(z+2))
    target = (4*x-1)/(x*x+x-2)
    check(f"rational recombination x={x}",1/(x-1)+3/(x+2),target)
    check(f"rational primitive x={x}",derivative(G,x),target)

for x in [-3,-0.5,0,1,5]:
    H = lambda z: math.log(z+math.sqrt(z*z+1))
    check(f"table sqrt(x^2+1) x={x}",derivative(H,x),1/math.sqrt(x*x+1))
for x in [-4,-2,2,4]:
    H = lambda z: math.log(abs(z+math.sqrt(z*z-1)))
    check(f"table sqrt(x^2-1) x={x}",derivative(H,x),1/math.sqrt(x*x-1))
for x in [-0.8,-0.2,0,0.4,0.8]:
    check(f"table sqrt(1-x^2) x={x}",derivative(math.asin,x),1/math.sqrt(1-x*x))

negative_argument = -5+2+math.sqrt(25-20)
assert negative_argument < 0
print(json.dumps({
    "method": "Analytical derivations in technical-review.md; finite differences and Simpson quadrature here are corroborating spot checks only.",
    "checks": checks,
    "passed_count": len(checks),
    "counterexample": {"x": -5, "source_log_argument": negative_argument,
                        "consequence": "Printed logarithm has a negative argument on the second real component."},
    "limits": "Floating-point finite samples do not prove identities; no quadrature across singular endpoints is attempted."
}, indent=2))
