# D025 original-only technical review

Status: original-source technical review complete; no current PROF, final prompt packet, new teaching, or student response assessed. This record is preparation for a later D025 iteration, not an iteration outcome. Physical PDF page numbers are used below; physical pages 2-6 carry printed lecture pages 1-5.

The primary input is MIT 18.01, Fall 2006, Lecture 28, *Integration by Inverse Substitution; Completing the Square*, six PDF pages, 874671 bytes, SHA-256 `e7c53d2b79d75aa14e619dc42751ce731e08b58f93952a45ef698ea7c86b7e4b`. All six supplied full-page PNGs and all six TXT files were inspected. The PDF was independently extracted with `pdftotext -layout` and its complete output was read. The identity JSON was read and checked; its URLs, cache paths, ancestry paths, and references were not followed.

The complete four-subject baseline was read, including its cover, all Mathematics, all FM01-FM71 Further Mathematics entries, all Physics sections 1-8, and all Chemistry CH-00 through CH-REF text. Its exact bytes are 247840 and its SHA-256 is `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. The baseline is an allowed-premise inventory, not a second lecture or an assertion of measured mastery. This task does not independently certify every scientific assertion in the baseline.

## Findings

| ID | Source location | Verified issue and consequence |
|---|---|---|
| D025-E1 | PDF p3, first equality after "And finally" | The bracket contains `u/4 + (1/2) sin u cos u`. Its first term must be `u/2`. The following expression and final answer have the correct arcsine coefficient. The displayed equality chain is internally false as printed. |
| D025-E2 | PDF p5, integral immediately after the triangle ratios | The left side is `integral 2 sec u du` but the right side is one logarithm. The extra 2 must be removed to continue the p4 calculation. If retained, the logarithm needs coefficient 2, which would no longer represent the original x integral. |
| D025-D1 | PDF pp4-5, secant substitution and final logarithm | The worked triangle and cancellations silently use `x>0`, `v=x+2>2`, and `0<u<pi/2`. The original real integrand also exists for `x<-4`. As printed, `ln(x+2+sqrt(x^2+4x))` is not real there. A full real-domain primitive uses absolute value, with separate constants on the two components. |
| D025-N1 | PDF p4, standalone differential | `dv=2 sec u tan u` is missing `du`; the next displayed integral includes it correctly. |
| D025-N2 | PDF p6, displayed teaser integral | The expression `integral (4x-1)/(x^2+x-2)=???` omits `dx`. The intended variable is nevertheless clear from context. |

E1 and E2 are visible in the PDF and PNGs, not merely extraction defects. Missing absolute values in the recalled secant primitive are the same branch issue as D1, rather than a distinct independent coefficient error. The source's stated arcsine final answer, completed-square identity, and rational-function algebra are correct on their proper domains.

## Exhaustive page and claim coverage

### PDF p1: cover

Read all cover and attribution text. There are no mathematical examples or figures. MIT OpenCourseWare, 18.01 Single Variable Calculus, and Fall 2006 match the stated identity; the linked terms page was not opened.

### PDF p2: semicircle, Figure 1, inverse substitution

Take `a>0` for a circle radius. The upper semicircle is `y=sqrt(a^2-t^2)` for `-a<=t<=a`. Figure 1 depicts `0<x<a`, with the region between the verticals `t=0` and `t=x`, the horizontal diameter, and the circular arc shaded. Its positive area is therefore exactly

`A(x)=integral_0^x sqrt(a^2-t^2) dt`.

For negative `x`, this same integral is signed and negative, rather than the ordinary positive area to the left of the origin. The final formula extends to those signed integrals, but the displayed shaded-area interpretation is the positive-x case.

Use `t=a sin u` on `-pi/2<=u<=pi/2`, so `dt=a cos u du` and `cos u>=0`. The identities `a^2-t^2=a^2(1-sin^2 u)=a^2 cos^2 u` are exact, and on this selected branch `sqrt(a^2-t^2)=a cos u`. Without the branch choice the square root is `a|cos u|`. The text's endpoints `-a <-> -pi/2` and `a <-> pi/2` correctly describe the branch; its use of `x` in that line is a harmless switch from the dummy variable `t` to a generic coordinate. Those are branch endpoints, not the actual 0-to-x integration limits.

The product of radical and differential is `a^2 cos^2 u du`, with both factors of `a` necessary. The identity `cos^2 u=(1+cos(2u))/2` and primitive `a^2[u/2+sin(2u)/4]+C` are correct: differentiation yields `a^2[1/2+cos(2u)/2]=a^2 cos^2 u`. Transforming the actual limits gives `u=0` and `u=arcsin(x/a)`. The identities `sin(2u)/4=(1/2)sin u cos u` and `sin(arcsin(x/a))=x/a` are correct on `|x|<=a`.

### PDF p3: Figure 2, back-substitution, final area, geometric check

Figure 2 has hypotenuse `a`, opposite side `x`, adjacent side `sqrt(a^2-x^2)`, a right-angle mark, and angle `u` in the acute corner. Its Pythagorean and trigonometric ratios are correct for `0<x<a`. Its caption means `cos u=sqrt(a^2-x^2)/a`; the radical does not include the division by `a`. For negative x an unsigned right-triangle leg cannot literally have length x; the cosine formula still follows from the principal arcsine range and `cos^2 u=1-sin^2 u`. Endpoints are degenerate triangles but continuous limits of the result.

The first bracket after "And finally" has error E1. Correctly substituting the p2 primitive gives

`A(x)=a^2[u/2+(1/2)sin u cos u]_0^arcsin(x/a)`

`=(a^2/2)arcsin(x/a)+(x/2)sqrt(a^2-x^2)`.

The lower-end value is zero. The source's second expression and final displayed answer match this result. Write `r=sqrt(a^2-x^2)>0` in the interior. Direct differentiation gives

`A'(x)=a^2/(2r)+r/2-x^2/(2r)=r`.

The branch identity `d(arcsin(x/a))/dx=1/r` uses `a>0`. Since `A(0)=0`, this derivative check determines the integral. Boundary checks are `A(a)=pi*a^2/4`, `A(-a)=-pi*a^2/4`, and full semicircle area `A(a)-A(-a)=pi*a^2/2`. The erroneous `u/4` expression is smaller by `a^2 u/4`, and its u derivative differs from the required integrand by `-a^2/4`; this discrepancy cannot be absorbed into a constant.

The source's sector area `a^2 u/2` follows from radians, and the triangle area is `x*r/2`; both are correct. These refer to Figure 3 on the next physical page. The prose assertion that a complicated answer necessarily requires a complicated route is rhetoric, not a valid complexity theorem. The nearby geometric decomposition itself gives a short independent check. No proof of unavoidable complexity is claimed by this review.

### PDF p4: Figure 3, substitution table, completing the square

Figure 3's sector runs from the positive vertical radius to the radius ending at `(x,r)`. Thus its marked angle is `u=arcsin(x/a)`, not the angle of that radius measured from the positive horizontal axis. The remaining triangle has base x and height r. The two shaded pieces exactly partition Figure 1's region with no positive-area overlap or gap. Figure 2 is a rotated right triangle expressing the same ratios, so the two angle conventions are consistent. At `x=a/2`, `u=pi/6`: sector area `pi*a^2/12`, triangle area `sqrt(3)*a^2/8`, agreeing with the integral.

All three rows of the substitution table are valid with branch and domain conditions:

| Original integrand | Branch sufficient for the displayed method | Resulting integrand and independent primitive check |
|---|---|---|
| `1/sqrt(x^2+1)` | `x=tan u`, `-pi/2<u<pi/2`; all real x | `sqrt(1+tan^2 u)=sec u>0`, `dx=sec^2 u du`, so `sec u du`; primitive `ln(x+sqrt(x^2+1))`, whose derivative is `1/sqrt(x^2+1)` and whose log argument is positive. |
| `1/sqrt(x^2-1)` | `x=sec u`, `0<u<pi/2` for x>1; `pi<u<3pi/2` also covers x<-1 with tan u positive | `sqrt(sec^2 u-1)=tan u>0`, `dx=sec u tan u du`, so `sec u du`; primitive `ln|x+sqrt(x^2-1)|`, derivative `1/sqrt(x^2-1)` on both components, with independent constants. Other u branches require retaining `|tan u|`. |
| `1/sqrt(1-x^2)` | `x=sin u`, `-pi/2<u<pi/2`; `|x|<1` | `sqrt(1-sin^2 u)=cos u>0` and `dx=cos u du`, leaving `du`; primitive `arcsin x`, derivative `1/sqrt(1-x^2)`. |

The identities printed in the table (`tan^2+1=sec^2`, `sec^2-1=tan^2`, and `1-sin^2=cos^2`) are all exact on their usual trigonometric domains. Endpoints where the denominator is zero are excluded from these ordinary integrands. The table is a menu of methods, not a statement that arbitrary branch choices allow sign removal.

For the next example, `x^2+4x=(x+2)^2-4` follows by expansion. `v=x+2` has `dv=dx`, yielding `integral dv/sqrt(v^2-4)`. The real domain is `x<-4` or `x>0`, equivalently `v<-2` or `v>2`. The displayed route chooses `v=2 sec u`; correctly `dv=2 sec u tan u du`. On `v>2`, choose `0<u<pi/2`: `sqrt(v^2-4)=2 tan u`, so the numerator's factor 2 cancels and the transformed integral is `integral sec u du`. This proves both the cancellation and why E2 is erroneous. The standalone line lacking du is N1; the integral line itself is correct on this branch.

### PDF p5: recalled secant primitive, Figure 4, logarithm, rational teaser

The general real primitive is `integral sec u du=ln|sec u+tan u|+C` on a continuous secant branch. Indeed

`d(ln|sec u+tan u|)/du=(sec u tan u+sec^2 u)/(sec u+tan u)=sec u`.

The denominator is nonzero wherever secant is defined because `(sec u+tan u)(sec u-tan u)=1`. On the worked acute branch the log argument is positive, so omission of absolute value is locally valid. This also verifies the source's recall without assuming a memorised secant-integral rule.

For Figure 4, `v>2` makes the sides `2`, `sqrt(v^2-4)`, and `v` positive and Pythagorean. The hypotenuse is v and the adjacent side to u is 2, so `cos u=2/v`, `sec u=v/2`, and `tan u=sqrt(v^2-4)/2`, exactly as printed. The figure does not establish these signed relations for negative v.

After removing E2's stray factor 2, the primitive is

`ln(v/2+sqrt(v^2-4)/2)+C = ln(v+sqrt(v^2-4))-ln 2+C`

on `v>2`. Absorbing `-ln 2` into a new integration constant is correct. Returning to x gives the printed final result on x>0. To check its full real extension, let `r=sqrt(x^2+4x)>0`, `v=x+2`, and `h=v+r`. Since `v^2-r^2=4`, h is never zero on either real component, and

`h'=1+v/r=(r+v)/r=h/r`.

Consequently `d ln|h|/dx=h'/h=1/r`. For `x<-4`, v is negative and `r<|v|`, so h is negative. Thus the full answer is

`ln|x+2+sqrt(x^2+4x)|+C_-` for x<-4,

`ln|x+2+sqrt(x^2+4x)|+C_+` for x>0.

The constants need not agree across the disconnected domain. No real value exists for the original denominator on `-4<x<0`; at x=-4 and x=0 it is zero. A finite endpoint limit of a primitive does not make the integrand defined there. No definite improper integral is assigned by this lecture example.

The rational-function definition `P(x)/Q(x)` requires polynomials P,Q with Q not the zero polynomial, and excludes inputs where Q(x)=0. The source's announcement about integrating all rational functions is a prospective method claim; this packet does not contain the next lecture or a worked general decomposition algorithm. FM22 supplies appropriate partial-fraction structures, but nothing in this review certifies the contents of an unseen subsequent lecture.

The displayed example `integral [1/(x-1)+3/(x+2)] dx=ln|x-1|+3ln|x+2|+C` is correct for x not equal to 1 or -2, on each connected interval. Differentiate each logarithm to obtain the displayed integrand. A separate integration constant can be chosen on each of `(-infinity,-2)`, `(-2,1)`, and `(1,infinity)`.

### PDF p6: rational algebra and unanswered integral

The numerator recombination is `x+2+3(x-1)=4x-1`; the common denominator is `(x-1)(x+2)=x^2+x-2`. Therefore the displayed rational identity is correct for x not equal to -2 or 1. There is no cancellation extending the domain: the numerator equals -9 at -2 and 3 at 1. Coefficient comparison independently gives `A+B=4` and `2A-B=-1`, hence `A=1,B=3` in the decomposition `A/(x-1)+B/(x+2)`. The teaser integral therefore has the already verified logarithmic primitive. The displayed integral's missing dx is N2. This calculation is an original-source verification, not an answer to any later final prompt packet.

## Baseline correspondence and limits

The Mathematics section explicitly supplies completing the square, domains and inverse functions, `sqrt(z^2)=|z|`, right-triangle ratios, principal inverse-trigonometric ranges, double-angle identities, radians and sector area, circle and triangle geometry, logarithm laws, differentiation including reciprocal trigonometric functions, substitution with transformed bounds, the fundamental theorem, signed versus geometric area, and partial fractions. These are actual usable premises, rather than inferred familiarity with topic names.

Further Mathematics FM24-FM29 supply hyperbolic/inverse-hyperbolic methods, principal inverse-trigonometric derivatives, radical integrals, real-domain checks, and specifically `ln|x+sqrt(x^2-a^2)|` on either component with separate constants. FM22 covers extended partial fractions. Thus branch/absolute-value reasoning and a hyperbolic alternative are available from the stated baseline; the particular source derivation still needs its own coefficient and domain correctness checked. The secant primitive can be verified or derived using the supplied derivative and log rules, as shown above. Nothing here relies on an unseen preceding lecture.

All Physics and Chemistry content was also read. Physics reinforces signed graph areas, units, triangle components, and distinctions between mathematical and physical models. Chemistry includes rate/tangent and integrated-area contexts but contributes no extra premise needed for these lecture calculations. No university theorem was silently imported from those topic labels. Their practical, spectral, statistical, quantum, and thermodynamic scope limits were read; none is needed to repair a trig substitution. This review does not equate baseline completion with demonstrated learner mastery.

A subsidiary original-only mathematical check was independently delegated for the same D025 source packet. Its result agreed with the source issues already inspected and calculated here. It did not read the baseline or any parent output. Its report is retained separately; this main review's baseline-read claim belongs to the main reviewer, not to the child.

No external lookup, author contact, browser session, repository write, setting change, current PROF read, prior audit read, other corpus input read, teaching read, or prompt/solution packet read was performed. The access record discloses one initial filename-only inventory beyond the exact baseline file; no such extra file contents were read or used. This is an instruction boundary, not a technical isolation guarantee.

The future currently published full PROF plus final-prompt-only packet has not been received or opened. Stop after this seal. Solving and sealing that future packet must precede any new frozen-teaching access. No teaching verdict, student trial result, or future prompt solution is implied by this original-only record.
