# Complete baseline actual-text reading record

Original path: `/workspace/scratch/f9c0b7fc7e76/d008-clean-r31-20261011/inputs/student-baseline.txt`

Original byte count: 247840. SHA-256: `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`.

The original bytes have mixed CR/CRLF sequences. Line references below count LF delimiters exactly as the `sed -n` read commands did: 1,377 complete LF-delimited lines, with the final newline included. Python generic `splitlines()` counts 2,561 pieces due to the extra CR characters; that is not the numbering used for the read spans. UTF-8 decoding gives 246,945 characters.

Every successful span below was displayed and semantically read as actual text. No search hits, headings-only pass, other-agent summary, or programmatic hash was substituted for reading. One initial 221-440 display truncated; the two successful recovery spans fully replaced it for coverage accounting.

| LF line range | Raw byte range, start inclusive/end exclusive | Bytes | Subject coverage |
|---|---|---:|---|
| 1-220 | 0-27855 | 27855 | Cover and Mathematics through Newton-Raphson formula |
| 221-330 | 27855-46307 | 18452 | Mathematics numerical-method continuation, vectors, statistics and mechanics through connected bodies |
| 331-440 | 46307-71643 | 25336 | Mathematics ending; Further Mathematics FM01-FM41 |
| 441-550 | 71643-97365 | 25722 | Further Mathematics FM42-FM71; Physics opening through uncertainty definitions |
| 551-660 | 97365-119971 | 22606 | Physics uncertainty/practical competence, motion/materials, circuits/waves through standing waves |
| 661-770 | 119971-146053 | 26082 | Physics photons, thermal/orbital models, cosmology, fields, nuclear physics and imaging opening |
| 771-880 | 146053-163638 | 17585 | Physics imaging ending and scope; Chemistry CH-META through ionic bonding |
| 881-990 | 163638-179177 | 15539 | Chemistry covalent bonding, structure, inorganic and transition-metal chemistry through CH-04 heading |
| 991-1100 | 179177-197184 | 18007 | Chemistry rates/equilibrium, acid-base and enthalpy through CH-06.02 heading |
| 1101-1210 | 197184-215136 | 17952 | Chemistry lattice cycles, entropy/Gibbs, electrochemistry, organic structures/mechanisms through carbonyl addition |
| 1211-1320 | 215136-234800 | 19664 | Chemistry aromatic substitution, organic transformations/synthesis, analysis/spectroscopy and practical opening |
| 1321-1377 | 234800-247840 | 13040 | Chemistry practical methods, scope limits and all final references |

The raw spans are consecutive, disjoint and together reproduce all 247,840 original bytes. Per-span exact hashes are in `access-evidence.json`.

Directly relevant grants and limits were recorded in `independent-source-solutions.md`; all four subject sections were read even where their facts were not needed for partial fractions. No referenced external specification or verification record was opened.
