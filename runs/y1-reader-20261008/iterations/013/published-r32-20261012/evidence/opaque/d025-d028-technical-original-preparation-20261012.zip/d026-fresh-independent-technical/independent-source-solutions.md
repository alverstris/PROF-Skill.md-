# D026 independent technical preparation — SOURCE ONLY

Status: PREPARED ONLY. This is an independently solved original-source record, sealed before any D026 teaching generation was admitted. It is not a review or acceptance of a current generation. Withhold this file and its substantive findings from future teaching authors.

## Admitted evidence and boundaries

The only subject inputs read were the complete 247,840-byte four-subject baseline at `/workspace/scratch/f9c0b7fc7e76/d008-clean-r31-20261011/inputs/student-baseline.txt` and the exact original-source directory `/workspace/scratch/f9c0b7fc7e76/original-inputs/D026/`. The original PDF is `lec29.pdf`, 149,696 bytes, SHA-256 `e3fbda25f5094d4d8cc1e519ff389c7bef954a47f38dae4062d484205bad9dcc`. The baseline SHA-256 is `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`.

All four supplied page text files and all four full-page PNGs were read. The original PDF was independently opened through `pdfinfo` and all-page `pdftotext -layout`; PDF pages 3 and 4 were additionally rendered directly at greater resolution to resolve typesetting details. The complete baseline was read as actual text, not through a keyword search or a compressed summary. Exact coverage and hashes are in the associated evidence files.

The PDF contains a cover followed by three numbered teaching pages. Its printed page 1 is PDF page 2, printed page 2 is PDF page 3, and printed page 3 is PDF page 4. The source-identity JSON identifies MIT 18.01, Fall 2006, Lecture 29, Partial fractions. The JSON's historical metadata and links were inspected as metadata only: their linked or named files were not opened. No external identity or bachelor-year evidence was separately retrieved at this stage.

No teaching generation, old or new teaching file, PROF file, review, audit, queue, other agent's findings, browser source, GitHub repository, or broader directory was inspected. No external writes were made. The operative published PROF, final-prompt-only packet, and complete frozen generation remain unadmitted. This record must remain intact when those later inputs are admitted.

## Complete source coverage

| PDF page | Printed page | Actual content and independently reviewed claims |
|---|---:|---|
| 1 | unnumbered cover | MIT OpenCourseWare attribution, course name, Fall 2006, citation/terms URL. No mathematical problem or figure. |
| 2 | 1 | Rational-function definition; first two-term logarithmic integral; recombination to `(4x−1)/(x²+x−2)`; factorization; undetermined coefficients; coefficient comparison; cover-up for A. |
| 3 | 2 | Cover-up for B and struck-through visual shorthand; proper/distinct-factor qualification; repeated-factor decomposition and B, C, A calculations; final repeated-factor identity; real irreducible quadratic example and A1. |
| 4 | 3 | Quadratic-example C1 and B1 substitutions; mixed logarithmic/arctangent primitive; tenth power of a linear factor; tenth power of `x²+1`; tangent substitution yielding `cos^18 u`; reference to prior lecture methods. |

There are no coordinate plots, geometric diagrams, tables, experimental figures, or hidden figure-dependent quantities. The sole diagram-like visual is the cover-up strike-through notation on PDF page 3; its meaning is analyzed below. Display layout, superscripts, fraction bars, minus signs, absolute values, and page numbering were visually checked because the text extraction alone cannot disambiguate them reliably.

## Independent mathematical solutions

### S1. Rational functions, recombination, and the first integral

A rational expression `P(x)/Q(x)` is defined at real x only when `Q(x) ≠ 0`; Q must not be the zero polynomial. For this example the forbidden values are x=1 and x=−2.

Direct expansion gives

`(x−1)(x+2) = x²+x−2`,

and

`(x+2)+3(x−1) = 4x−1`.

Therefore

`1/(x−1)+3/(x+2) = (4x−1)/(x²+x−2)`

on the common domain. Termwise antiderivatives are

`F(x)=ln|x−1|+3 ln|x+2|+C`.

Differentiation returns the two fractions and then the recombined rational expression. Constants can be chosen separately on each connected interval `(-∞,−2)`, `(−2,1)`, `(1,∞)`. The source's first integral, recombination and initial factorization are correct.

### S2. Undetermined coefficients and the simple cover-up method

Write

`(4x−1)/[(x−1)(x+2)] = A/(x−1)+B/(x+2)`.

Clearing the entire denominator gives the polynomial identity

`4x−1 = A(x+2)+B(x−1) = (A+B)x+(2A−B)`.

Coefficient comparison yields `A+B=4`, `2A−B=−1`; addition gives `3A=3`, so A=1 and B=3. This proves rather than guesses both coefficients.

For cover-up, multiplying by x−1 first produces

`(4x−1)/(x+2) = A+B(x−1)/(x+2)`.

For x near 1, the remaining denominators are nonzero; taking x→1 gives A=3/3=1. Multiplying by x+2 and taking x→−2 gives

`B=[4(−2)−1]/(−2−1)=−9/(−3)=3`.

These are limits of canceled expressions, or evaluations of the cleared polynomial identity. They are not evaluations of the original rational expression at a pole.

More generally, when the proper rational part has denominator `Q(x)=c ∏(x−r_j)` with distinct real roots, the coefficient of `1/(x−r_i)` is

`A_i=P(r_i)/[c ∏_{j≠i}(r_i−r_j)]`.

This follows by multiplying the decomposition by x−r_i and taking the limit. The leading scalar c must remain. If an unnormalized factor `a x+b` is used as a denominator, multiply by that exact factor and evaluate at `−b/a`; do not silently change the coefficient's normalization.

The source's phrase about distinct factors is understood here as distinct linear factors for this real-root cover-up rule. Pairwise distinct irreducible quadratics are also distinct factors but do not supply real roots at which this simple substitution can recover their linear numerators. The degree condition is that of the proper rational part. If `deg P ≥ deg Q`, the baseline permits polynomial division first; the source does not work an improper example.

The source's statements that solving several simultaneous equations can be slow, and that cover-up is faster or can be done mentally, describe practical convenience, not a mathematical prohibition or a universal complexity guarantee.

### S3. Repeated linear factor

The original problem is

`R(x)=(x²+2)/[(x−1)²(x+2)]`, x≠1,−2.

The complete proposed form is

`R(x)=A/(x−1)+B/(x−1)²+C/(x+2)`.

Both powers of x−1 are needed in the general form. Clearing all denominators gives

`x²+2=A(x−1)(x+2)+B(x+2)+C(x−1)²`.

At x=1: `3=3B`, so B=1.

At x=−2: `6=9C`, so C=2/3.

At x=0: `2=−2A+2B+C=−2A+8/3`, so A=1/3.

Thus

`R(x)=1/[3(x−1)]+1/(x−1)²+2/[3(x+2)]`.

An independent recombination verifies the numerator:

`(1/3)(x−1)(x+2)+(x+2)+(2/3)(x−1)²=x²+2`.

The precise multiplication for the B limit is

`(x²+2)/(x+2)=B+A(x−1)+C(x−1)²/(x+2)`.

The last two terms approach zero as x→1. It is unnecessary and potentially misleading to regard every factor denoted by the source's word “stuff” as bounded: before expansion it can include A/(x−1), which is unbounded, although its product with `(x−1)²` tends to zero. Showing the canceled expression resolves this fully.

The precise multiplication for C is

`(x²+2)/(x−1)²=C+A(x+2)/(x−1)+B(x+2)/(x−1)²`.

As x→−2 the last two terms vanish and C=6/9=2/3.

The source says that cover-up cannot evaluate A. This is correct for the elementary multiply-and-evaluate rule it has described: multiplying by x−1 leaves B/(x−1), which is singular at 1. It is not a claim that every extension of cover-up, such as differentiating the fully canceled expression, is impossible. The source's selected ordinary substitution x=0 is sufficient and appropriate.

The source asks for and obtains a decomposition here, not an explicitly finished primitive. As an independent consequence, the corresponding primitive is

`(1/3)ln|x−1|−1/(x−1)+(2/3)ln|x+2|+K`.

Its derivative gives the decomposition above. The integration constant K is distinct from the source's coefficient C, and may differ among the three domain intervals.

There are two visibly printed defects in the intermediate source work, recorded in the qualifications below. They do not alter the intended problem or its correct final coefficients.

### S4. Irreducible quadratic and its integral

For

`S(x)=1/[(x²+1)(x−1)]`,

the real domain is x≠1 because `x²+1>0` for every real x. The quadratic has no real roots; its discriminant is −4. It factors over the complex numbers as `(x−i)(x+i)`, consistent with the baseline's complex-number rules, but complex arithmetic is unnecessary for the real decomposition.

Use

`S(x)=A1/(x−1)+(B1 x+C1)/(x²+1)`.

The numerator over the irreducible quadratic has degree less than two. Clearing denominators gives

`1=A1(x²+1)+(B1 x+C1)(x−1)`

`=(A1+B1)x²+(C1−B1)x+(A1−C1)`.

Therefore `A1+B1=0`, `C1−B1=0`, `A1−C1=1`. These yield

`A1=1/2`, `B1=−1/2`, `C1=−1/2`.

Independently reproducing the source's substitution route: cancellation/evaluation at x=1 gives A1=1/2. At x=0, `−1=−1/2+C1`, so C1=−1/2. At x=−1,

`−1/4=−1/4+(−B1−1/2)/2`,

hence `0=(−B1−1/2)/2=−(B1+1/2)/2` and B1=−1/2. The source's displayed intermediate factored sign is incorrect; its final coefficient is correct.

The decomposition is

`S(x)=1/[2(x−1)]−x/[2(x²+1)]−1/[2(x²+1)]`.

Termwise integration gives

`G(x)=(1/2)ln|x−1|−(1/4)ln(x²+1)−(1/2)arctan x+K`.

For the second term, set v=x²+1 so `dv=2x dx`. The required extra factor 1/2 explains the coefficient −1/4. The inverse tangent term uses `d(arctan x)/dx=1/(1+x²)`. Differentiating G returns the preceding decomposition, and clearing its denominator returns numerator 1. The source's final primitive is correct. Its absolute-value bars around x²+1 are harmless but redundant for real x. `tan^−1 x` here means inverse tangent, not reciprocal tangent. Constants may differ on `(-∞,1)` and `(1,∞)`.

For the source instruction to choose any x other than 0 or 1 after finding C1: x=1 is forbidden; x=0 cannot determine B1 because it multiplies B1 by zero. Every other real x has nonzero x and an allowed denominator, so the remaining linear equation can determine B1.

### S5. Tenth power of a linear factor

For x≠1,

`∫(x−1)^−10 dx=−(1/9)(x−1)^−9+K`.

Use v=x−1, dv=dx, and the power rule with exponent −10. Differentiating the result gives `−(1/9)(−9)(x−1)^−10=(x−1)^−10`. This example needs no decomposition. The source result is correct; the two intervals separated by x=1 may have different constants.

### S6. Tenth power of an irreducible quadratic — transformation and full independent evaluation

The original integral is

`I10=∫dx/(1+x²)^10`,

with all real x allowed. Choose `u=arctan x ∈ (−π/2,π/2)`, so x=tan u is one-to-one, cos u>0, and `dx=sec²u du`. Then

`dx/(1+x²)^10=sec²u du/(sec²u)^10=sec^−18u du=cos^18u du`.

The exponent is 18, not 20: the differential cancels one of the ten factors of sec². The substitution and displayed transformed integral in the source are correct. No square root or absolute-value choice is needed in that displayed algebra; the branch choice makes the inverse substitution explicit.

The source stops here and says earlier lecture methods can finish the even cosine power. Those earlier lectures were not admitted or consulted. The complete baseline already supplies substitution, integration by parts, trigonometric identities, integer binomial expansion and Euler/De Moivre formulae, so a completion can be derived within the permitted premises.

One independent completion uses the finite identity

`cos^18 u = 2^−18 [C(18,9)+2 Σ_{j=0}^8 C(18,j) cos((18−2j)u)]`.

To derive it, write `cos u=(e^(iu)+e^(−iu))/2`, expand the eighteenth power by the integer binomial theorem, and pair opposite exponents using Euler's relation. This is a finite algebraic identity, with no convergence assumption. Termwise integration then gives the explicit answer

`I10=2^−18 [C(18,9) arctan x + Σ_{j=0}^8 C(18,j)/(9−j) sin((18−2j)arctan x)] +K`.

The factor `1/(9−j)` arises from the factor 2 in the paired cosine term divided by its angular coefficient `18−2j`. Since `C(18,9)=48620`, the arctangent coefficient is `12155/65536`.

A separate rational-arctangent form can be obtained without complex notation. Put `In=∫(1+x²)^−n dx`. Direct differentiation gives

`d[x/(1+x²)^(n−1)]/dx = 2(n−1)/(1+x²)^n − (2n−3)/(1+x²)^(n−1)`.

Therefore, for integers n≥2,

`In=x/[2(n−1)(1+x²)^(n−1)] + [(2n−3)/(2n−2)] I(n−1)`,

starting with `I1=arctan x`. This recurrence is derived here from the supplied differentiation rules; a memorized reduction formula is not being presumed. For n=10 the fully evaluated answer is

`I10=(12155/65536)arctan x+x Σ_{k=1}^9 c_k/(1+x²)^k+K`,

with the exact coefficients

| k | c_k |
|---:|---:|
| 1 | 12155/65536 |
| 2 | 12155/98304 |
| 3 | 2431/24576 |
| 4 | 2431/28672 |
| 5 | 2431/32256 |
| 6 | 1105/16128 |
| 7 | 85/1344 |
| 8 | 17/288 |
| 9 | 1/18 |

The recurrence proves that differentiating this expression yields `(1+x²)^−10`; an additional exact symbolic check is recorded separately. Either explicit expression is a complete independent solution. Providing both here is a reviewer cross-check, not a requirement that a future lesson print both.

## Source qualifications and defects that must remain visible to a later review

| ID | Location | Observation | Mathematically correct interpretation |
|---|---|---|---|
| Q1 | PDF 2, rational definition | The definition as a ratio omits a written domain condition. | Q is not the zero polynomial; evaluate only where Q(x)≠0. Cancellation preserves original excluded inputs. |
| Q2 | PDF 2–3, pole substitutions | Source informally says set x equal to the root after multiplication. | Evaluate the canceled expression by its limit, or evaluate the cleared polynomial identity. Never substitute into the original undefined expression. |
| Q3 | PDF 3, distinct-factor sentence | “Distinct factors” is broader literally than the demonstrated real-root method. | Elementary scalar cover-up determines constants at distinct linear factors; irreducible quadratic numerators need further equations. Properness applies before decomposition, or after a polynomial division. |
| E1 | PDF 3, first B extraction line | The source visibly prints `(x²+1)/(x+2)`, while the problem and next substitution use x²+2. This is present in the original render, not merely a text-extraction artifact. | The numerator must remain x²+2. With the printed +1, the limit would be 2/3 rather than the stated B=1. |
| E2 | PDF 3, first C extraction line | The exponent 2 is typeset on the right of the whole displayed fraction at numerator height, while the displayed denominator is `(x−1)`. The high-resolution original render confirms the misplaced superscript. | The intended expression is `(x²+2)/(x−1)²`, as the next substitution and final identity confirm. It must not be read or reproduced as a squared quotient, which gives 4 at x=−2 rather than 2/3. |
| Q4 | PDF 3, “stuff” in B line | The unnamed remainder before multiplication can include a singular term. | Expand as `A(x−1)+C(x−1)²/(x+2)` to show the vanishing limit; boundedness of an unspecified factor is not the reason. |
| Q5 | PDF 3, cannot use cover-up for A | A scope statement about the simple rule, not every generalized technique. | Plain multiplication/evaluation cannot isolate the lower-order repeated-pole coefficient; use an admissible ordinary x or coefficient comparison. |
| E3 | PDF 4, B1 at x=−1 | The middle expression visibly reads `0=−(B1−1/2)/2` but the final result is B1=−1/2. The former would imply B1=+1/2. | Correct middle expression: `0=(−B1−1/2)/2=−(B1+1/2)/2`. Initial equation and final coefficients are correct. |
| Q6 | PDF 4, logarithm/inverse tangent | Absolute values around x²+1 are redundant; inverse tangent notation can be misread. | x²+1>0; use ln(x²+1). `tan^−1` means arctan in this integral. |
| Q7 | PDF 4, final line | The lecture invokes methods from two lectures earlier but provides no worked completion. | The displayed target is correctly `∫cos^18u du`; a standalone explanation can derive its completion from permitted baseline premises. No unadmitted earlier lecture was consulted for this review. |

E1, E2 and E3 are original-source intermediate display defects, not errors in the independently solved final decompositions/primitive. This stage cannot decide whether a future generation reproduces or repairs them, because no generation has been read.

## Baseline premises and transfer boundaries

The full four-subject baseline was read, including the Chemistry ending and references, rather than only the relevant mathematics. The directly useful premises are:

* Mathematics: expression versus identity, admissible domain, preservation of exclusions on cancellation, polynomial division, factor theorem, simultaneous equations, coefficient comparison, elementary partial fractions including a squared linear factor, logarithms, powers, trigonometric identities and principal inverse domains, differentiation, reverse chain rule, substitution, integration by parts, and checking by differentiation.
* Further Mathematics FM22: explicit extended partial fractions, polynomial division for an improper fraction, successive powers for repeated factors, and linear numerators over quadratics. This means the form of the quadratic example is already granted, not an unstated university operation.
* Further Mathematics FM29: derivative of arctan and the real inverse-trigonometric/substitution rules, with domains. This directly supplies the inverse-tangent primitive.
* Further Mathematics FM02–FM08 and the Mathematics integer binomial theorem: complex arithmetic, Euler/De Moivre, finite expansions. These justify the optional finite cosine-power expansion, without importing complex analysis.
* Further Mathematics FM28 and ordinary domain rules: disconnected-domain antiderivatives and improper integrals must not be conflated; no cancellation through divergent singularities is legitimate. This lecture asks for indefinite primitives, so no improper integral is being assigned a value.

Physics and Chemistry add general model/domain, sign, unit and evidence discipline, but supply no extra theorem needed to solve these pure rational-function examples. Reading them does not authorize outside subject premises. The baseline expressly grants curriculum-based usable competence, not measured mastery, and permits shown deductions beyond memorized assessment methods. In particular, integration reduction formulae are not granted by Mathematics A alone, but the recurrence above is independently derived from the provided derivative rules. There is no need to presume an unlisted reduction formula or previously read lecture.

No question in the original needs a numerical table, an external calculator, chemical/physical reference constants, spectra, empirical parameters, or a diagram measurement. All results above are exact.

## Deferred stages

1. Admit the complete operative published PROF and final-prompt-only packet only when root explicitly supplies them. Record their identity, exact hashes and reading coverage without altering this seal.
2. Admit the complete frozen generation only after this source-solution record is sealed. Compare every generated assertion, example, question, answer and visual against the original-source solution and the full operative criteria.
3. Make any acceptance decision only for that particular admitted frozen generation. No current-generation acceptance, student trial, or PROF compliance claim is made here.

This record is a source-only technical preparation checkpoint. Its contents must not be used to brief a future author before that author's generation is frozen.
