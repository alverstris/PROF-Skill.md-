"""Exact coefficient checks of the already-written D026 independent solutions.

Uses only Python standard-library integer/fraction arithmetic. No teaching
input or external source is read. Domains are reviewed in the hand solutions.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb
import json

# Polynomial tuples store ascending powers with exact rational coefficients.
def norm(p):
    p=list(map(F,p))
    while len(p)>1 and p[-1]==0: p.pop()
    return tuple(p)
def add(a,b):
    return norm([(a[k] if k<len(a) else 0)+(b[k] if k<len(b) else 0) for k in range(max(len(a),len(b)))])
def scale(q,a): return norm([F(q)*v for v in a])
def sub(a,b): return add(a,scale(-1,b))
def mul(a,b):
    out=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): out[i+j]+=x*y
    return norm(out)
def power(a,n):
    out=(F(1),)
    for _ in range(n): out=mul(out,a)
    return out
def derivative(a): return norm([i*a[i] for i in range(1,len(a))] or [0])
def value(a,x):
    out=F(0)
    for v in reversed(a): out=out*x+v
    return out

checks={}
def identity(name,residual):
    residual=norm(residual)
    ok=residual==(F(0),)
    checks[name]={'polynomial_residual_coefficients':[str(v) for v in residual],'passed':ok}
    assert ok,(name,residual)
def value_check(name,actual,expected):
    actual,expected=F(actual),F(expected)
    checks[name]={'actual':str(actual),'expected':str(expected),'passed':actual==expected}
    assert actual==expected,(name,actual,expected)

one=(F(1),)
x=(F(0),F(1))
lin1=(-F(1),F(1))
lin2=(F(2),F(1))
quad=(F(1),F(0),F(1))
x2=(F(0),F(0),F(1))
first_num=(-F(1),F(4))
repeat_num=(F(2),F(0),F(1))
identity('quadratic_factorization',sub(mul(lin1,lin2),(-1*F(2),F(1),F(1))))
identity('simple_fraction_common_numerator',sub(add(lin2,scale(3,lin1)),first_num))
value_check('simple_coverup_A',value(first_num,F(1))/value(lin2,F(1)),1)
value_check('simple_coverup_B',value(first_num,F(-2))/value(lin1,F(-2)),3)

A,B,C=F(1,3),F(1),F(2,3)
repeat_actual=add(add(scale(A,mul(lin1,lin2)),scale(B,lin2)),scale(C,power(lin1,2)))
identity('repeated_fraction_common_numerator',sub(repeat_actual,repeat_num))
value_check('repeated_coverup_B',value(repeat_num,F(1))/value(lin2,F(1)),1)
value_check('repeated_coverup_C',value(repeat_num,F(-2))/value(power(lin1,2),F(-2)),F(2,3))
value_check('repeated_ordinary_substitution_x0',-A+B+C/F(2),1)
value_check('repeated_primitive_power_coefficient',F(-1)*F(-1),1)

A1,B1,C1=F(1,2),-F(1,2),-F(1,2)
quad_actual=add(scale(A1,quad),mul((C1,B1),lin1))
identity('irreducible_fraction_common_numerator',sub(quad_actual,one))
# The derivative of the primitive has these explicit numerator contributions.
quad_primitive_num=add(add(scale(F(1,2),quad),scale(-F(1,2),mul(x,lin1))),scale(-F(1,2),lin1))
identity('irreducible_primitive_common_numerator',sub(quad_primitive_num,one))
value_check('irreducible_xminus1_equation',-F(1,4)+(-B1-F(1,2))/2,-F(1,4))
value_check('linear_tenth_primitive_chain_coefficient',-F(1,9)*(-9),1)

# Verify each derived reduction identity by clearing its positive denominator.
for n in range(2,11):
    lhs= sub(quad,scale(2*(n-1),x2))
    rhs= sub(scale(2*(n-1),one),scale(2*n-3,quad))
    identity('quadratic_reduction_derivative_n'+str(n),sub(lhs,rhs))

# The explicit table is independently transcribed from the hand-written answer.
c0=F(12155,65536)
coefs={1:F(12155,65536),2:F(12155,98304),3:F(2431,24576),4:F(2431,28672),5:F(2431,32256),6:F(1105,16128),7:F(85,1344),8:F(17,288),9:F(1,18)}
# Multiply the differentiated primitive by (1+x^2)^10.
num=scale(c0,power(quad,9))
for k,ck in coefs.items():
    term=mul((F(1),F(0),F(1-2*k)),power(quad,9-k))
    num=add(num,scale(ck,term))
identity('quadratic_tenth_complete_primitive_derivative_numerator',sub(num,one))

# T_m(cos u)=cos(mu), derived by the baseline cosine addition formula.
T={0:one,1:x}
for m in range(2,19): T[m]=sub(scale(2,mul(x,T[m-1])),T[m-2])
cosine_num=scale(comb(18,9),one)
for j in range(9): cosine_num=add(cosine_num,scale(2*comb(18,j),T[18-2*j]))
identity('cosine_eighteenth_finite_identity',sub(scale(F(1,2**18),cosine_num),power(x,18)))
value_check('cosine_integral_arctangent_coefficient',F(comb(18,9),2**18),c0)
for j in range(9):
    value_check('cosine_antiderivative_angular_factor_j'+str(j),F(1,9-j)*(18-2*j),2)

value_check('source_E1_printed_numerator_limit',F(1+1,1+2),F(2,3))
value_check('source_E2_squared_quotient_if_read_literally',F((-2)**2+2,-2-1)**2,4)
value_check('source_E3_printed_middle_rhs_at_correct_B1',-(B1-F(1,2))/2,F(1,2))

out={'purpose':'exact arithmetic and polynomial verification of independently derived source-only solutions','method':'Python standard library Fraction, integer binomial coefficients, and displayed polynomial algebra; no CAS or external package needed','tooling_note':'An initial optional SymPy import failed because SymPy is not installed. No checks ran in that attempt. This self-contained arithmetic checker replaces it.','all_checks_passed':all(v['passed'] for v in checks.values()),'check_count':len(checks),'checks':checks,'I10_coefficients':{'0':str(c0),**{str(k):str(v) for k,v in coefs.items()}},'domain_caveat':'Log-absolute-value derivatives use the baseline off-zero derivative rule. Domain and connected-component arguments are in the hand solution. A polynomial identity does not restore excluded rational inputs.','not_generation_acceptance':True}
Path(__file__).with_name('verification-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'check_count':len(checks),'all_checks_passed':out['all_checks_passed'],'not_generation_acceptance':True}))
