"""Arithmetic checks for the source-only D027 preparation.

No external sources or libraries. General proofs are in technical-preparation.md.
This script is evaluator arithmetic, not an assessment run by a student.
"""
from fractions import Fraction
from math import factorial, log
from pathlib import Path
import json


def recurrence_coefficients(n):
    return [(-1) ** (n - j) * factorial(n) // factorial(j)
            for j in range(n + 1)]


results = []
for n in range(13):
    p = recurrence_coefficients(n)
    derivative_sum = [p[j] + ((j + 1) * p[j + 1] if j < n else 0)
                      for j in range(n + 1)]
    expected = [0] * n + [1]
    assert derivative_sum == expected
    results.append({"n": n, "P_coefficients_ascending": p,
                    "P_plus_derivative": derivative_sum, "passed": True})

N = 24
q_polynomial_part = sum((Fraction(2 ** k - 1, k * factorial(k))
                        for k in range(1, N + 1)), Fraction(0))
tail_bound = (Fraction(2 ** (N + 1), factorial(N + 1)) /
              (1 - Fraction(2, N + 2)))
assert tail_bound < Fraction(24, 10 ** 19)
output = {
    "status": "checks_passed",
    "scope": "arithmetic supplement to independent written derivations",
    "recurrence_identity_checks": results,
    "definite_exponential_integral": {
        "integral": "integral_1^2 exp(x)/x dx",
        "N": N,
        "exact_finite_expression": "ln(2) + polynomial_sum_numerator/polynomial_sum_denominator",
        "polynomial_sum_numerator": q_polynomial_part.numerator,
        "polynomial_sum_denominator": q_polynomial_part.denominator,
        "approximation_float": log(2) + float(q_polynomial_part),
        "analytic_tail_bound_numerator": tail_bound.numerator,
        "analytic_tail_bound_denominator": tail_bound.denominator,
        "analytic_tail_bound_float": float(tail_bound),
        "rounding_note": "The tail bound controls truncation of the exact finite expression; ordinary floating-point rounding is additional."
    },
    "unrestricted_proofs": {
        "recurrences": "Arbitrary-n coefficient cancellation in technical-preparation.md, not inferred solely from finite checks.",
        "parameter_integral": "For each real a choose a nonnegative integer m>=a; integrand >=1/m! on [1,infinity). Written proof covers all real a.",
        "arclength": "Symbolic derivatives, endpoint substitutions, and limit calculations are given in the written preparation."
    },
    "is_student_trial": False,
    "is_current_generation_acceptance": False
}
destination = Path(__file__).resolve().parent / "independent-checks-results.json"
destination.write_text(json.dumps(output, indent=2) + "\n")
print(json.dumps({"status": output["status"],
                  "Q_approximation": output["definite_exponential_integral"]["approximation_float"],
                  "tail_bound": float(tail_bound)}, indent=2))
