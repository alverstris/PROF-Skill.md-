# D027: independent original-source technical preparation

Status: SOURCE-ONLY PREPARATION SEALED BEFORE ANY PROF, FINAL PROMPT, OR NEW TEACHING ADMISSION. This is not an acceptance decision, student trial, teaching review, or claim about any current generation. Findings are restricted to the evaluator until the later full teaching freeze.

## Authority, inputs, and actual reading

The only subject-content inputs used were the assigned original MIT 18.01 Fall 2006 Lecture 30 PDF and its nine supplied page texts/PNGs, and the complete assigned four-subject student baseline. No external sources, browser, network, current or old teaching, PROF text, reports, queue, findings, other-agent work, or metadata ancestry were read. The source directory was inventoried; its `source-identity.json` filename was visible but its contents were not opened. No locator from metadata was followed.

Original PDF: `/workspace/scratch/f9c0b7fc7e76/original-inputs/D027/lec30.pdf`, 1,481,979 bytes, SHA-256 `e33d3476478c0d0d1b26e6487ec4fb66544c12fc7b20941e5ef9c4c93dd8a8a1`.

Baseline: `/workspace/scratch/f9c0b7fc7e76/d008-clean-r31-20261011/inputs/student-baseline.txt`, 247,840 bytes, 1,377 LF-delimited lines, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`.

All baseline lines were actually displayed and read in fourteen consecutive, non-overlapping bounded chunks: 1–100, 101–200, 201–300, 301–400, 401–500, 501–600, 601–700, 701–800, 801–900, 901–1000, 1001–1100, 1101–1200, 1201–1300, and 1301–1377. This covers the cover/instructions, Mathematics, Further Mathematics, Physics, and Chemistry, including final reference and scope paragraphs. No referenced research file or URL was opened. The baseline ledger records raw-byte chunk hashes and exact coverage.

Every source page text was displayed and read. Every full PNG, including the cover, was visually inspected at original image detail. Visual inspection resolved superscripts, radicals, the positive exponential in the improper integral, diagram orientation, and typographical defects that plain extraction alone could obscure. PDF page numbers below include the cover; printed lecture page numbers are one smaller.

## Full source inventory and coverage

| PDF page | Printed page | All content covered |
|---|---:|---|
| 1 | — | MIT OpenCourseWare cover, 18.01 Single Variable Calculus, Fall 2006, citation/terms URLs; no calculation or figure. URLs are provenance text, not extra inputs. |
| 2 | 1 | Lecture title; product-rule derivation of integration by parts; Example 1, integral of arctangent; start of definite-integral derivation. |
| 3 | 2 | FTC boundary evaluation; differential notation; Example 2, logarithm and repaired derivative guess; Example 3, log-power recurrence; start of Example 4, exponential times a power. |
| 4 | 3 | Example 4 recurrence; two “impossible” assertions; exact definite integral on [1,2]; numerical-evaluation discussion; printed parameter family with upper limit infinity. |
| 5 | 4 | Arc-length motivation; Figure 1 curve and differential segment; Figure 2 local right triangle; differential length expression; path integral from P0 to P1. |
| 6 | 5 | Figure 3 increasing-x endpoints a,b; graph arc-length formula; Example 5 unit circle; full-circle Figure 4 and its incorrect example-number caption. |
| 7 | 6 | Figure 5 selected upper-right circle arc; square-root branch; chain-rule derivative; every square/radical simplification; inverse-sine integral and sin(s)=a. |
| 8 | 7 | Figure 6 unit-radius geometry and angle; Example 6 constant radius versus variable parameter; circle elimination; t=0 and t=pi/2 coordinates; increasing-parameter orientation. |
| 9 | 8 | Figure 7 circle endpoints/direction; Example 7 ellipse equation and substitution; Figure 8 ellipse endpoints/direction; parameter differentials and circle arc-length simplification. |

No source assessment questions are separately labelled. Every numbered example, all eight numbered figures, both unevaluated integrands, and the parameter family are nevertheless solved or explicitly qualified below.

## Baseline premises and limits

The complete baseline is one combined input; the following are the particular premises used in this technical solution.

| Baseline location | Operational permission relevant here |
|---|---|
| Mathematics, lines 27–35, 48–76 | Arithmetic, domains, implications, powers/roots, algebra, function/inverse distinctions, circles, and parameter restrictions. In particular sqrt(z^2)=abs(z). |
| Mathematics, lines 101–127 | Unit-circle coordinates, exact trig values, radians and circle length r theta, inverse-trig branches, sin^2+cos^2=1, and ordinary trigonometric identities. |
| Mathematics, lines 129–174 | Log/exponential domains, derivatives, product and chain rules, rates, and parametric differentiation. |
| Mathematics, lines 178–201 | Antiderivatives with constants, FTC, rectangle-sum interpretation, standard primitives, consistent substitution, integration by parts, repeated parts, and the logarithm primitive. |
| Mathematics, line 203 | Signed definite integrals versus nonnegative geometric quantities. |
| Mathematics, numerical-method section | Trapezium/rectangle numerical approximation, with appropriate assumptions. |
| Mathematics, line 341 | Integration reduction formulae are not pre-granted as a memorised topic; valid derivation from earlier premises is allowed. |
| Further Mathematics, FM01, line 357 | Induction with a base and arbitrary-integer step, if proving a whole recurrence family. |
| Further Mathematics, FM27, line 409 | The real exponential series, allowing a direct positive-term bound; no unprovided general remainder theorem is presumed. |
| Further Mathematics, FM28, line 411 | Improper integrals must be finite-limit integrals followed by a limit; endpoint divergence cannot be cancelled away. |
| Further Mathematics, FM29, line 413 | Derivatives of principal inverse trigonometric functions and the inverse-sine primitive with real domains. |
| Further Mathematics, FM30/FM31/FM66 | Consistent parametric differentials, polar-circle geometry, and speed versus signed velocity. |
| Physics and Chemistry, complete sections | Fully read. Their substantive physical/chemical premises are not needed for these mathematical calculations. Their availability does not import additional university integration or non-elementarity theory. |

Thus integration by parts, its repeated use, the log integral, circle geometry, and parametric algebra are already usable. These notes may consolidate them. A named or general reduction formula must be derived, as done below. The general graph/parametric arc-length rule is new source teaching; the special circle relation s=r theta is already baseline knowledge. Neither baseline nor source supplies a proof system for deciding whether an arbitrary antiderivative is elementary. No such proof is silently imported.

## 1. Integration by parts and notation: pages 2–3

Take differentiable functions u(x),v(x) with enough regularity for the indicated integrals; u,v continuously differentiable on a finite interval is a sufficient working condition. Product rule gives

`(uv)' = u'v + uv'`, hence `uv' = (uv)' - u'v`.

Integrating gives `integral u v' dx = uv - integral v u' dx`, with one arbitrary final constant for an indefinite answer. This is equality of antiderivative families, not a demand that independently chosen constants on both sides already match. The derivative of the right side is `u'v+uv'-vu'=uv'`, providing a direct verification.

For a finite interval [a,b], FTC gives

`integral_a^b u v' dx = u(b)v(b)-u(a)v(a) - integral_a^b v u' dx`.

The source boundary notation `uv|_a^b` means that difference. The same limits apply to the remaining integral. For an improper endpoint, first use finite bounds and then establish the limits of the resulting expressions; finite-interval parts does not justify discarding a boundary term at infinity.

The alternative notation is `du=u' dx`, `dv=v' dx`, so `u dv=u v' dx` and `v du=v u' dx`. It changes notation, not the method. Choose u so that its derivative helps, and dv with an accessible primitive v. A lone integrand can be viewed as a product with 1.

### Example 1: integral of arctangent

Here `tan^{-1} x` means principal arctangent, not reciprocal tangent. Set `u=atan x`, `dv=dx`; then `du=dx/(1+x^2)` and `v=x`.

`integral atan(x) dx = x atan(x) - integral x/(1+x^2) dx`.

For the remaining integral, set `w=1+x^2`, `dw=2x dx`, giving `(1/2)ln(1+x^2)`. Therefore

`A(x)=x atan(x) - (1/2)ln(1+x^2) + C`, for every real x.

The source's absolute value around `1+x^2` is harmless but unnecessary because that quantity is strictly positive. Verification:

`A' = atan x + x/(1+x^2) - x/(1+x^2) = atan x`.

There is no excluded real x and no undetermined branch of arctangent in this real convention.

### Example 2: integral of logarithm and repaired guess

For x>0, set `u=ln x`, `dv=dx`, so `du=dx/x`, `v=x`:

`integral ln(x) dx = x ln x - integral 1 dx = x ln x - x + C`.

The “advanced guessing” calculation is exactly the product rule: `(x ln x)'=ln x+1`; subtracting x removes the unwanted 1. Differentiation verifies `(x ln x-x)'=ln x`. This source result is for `ln x`, so x>0. A separate extension to `ln|x|` on a negative interval would require that different integrand to be explicitly stated; no extension is needed here.

## 2. Reduction formulae: pages 3–4

### Example 3: powers of logarithm

Let `I_n=integral (ln x)^n dx` on x>0. For finite termination, take n to be a nonnegative integer. For n>=1 choose `u=(ln x)^n`, `dv=dx`. Then `du=n(ln x)^(n-1) dx/x`, `v=x`, so cancellation of x gives

`I_n = x(ln x)^n - n I_(n-1)`.

The base is `I_0=x+C`. Reducing the index by one n times terminates at this base. For consistently chosen primitives, with only one final free constant,

`I_n = x sum_(k=0)^n [(-1)^k n!/(n-k)! (ln x)^(n-k)] + C`.

Examples completing the source's ellipsis:

`I_1=x(ln x-1)+C`;

`I_2=x[(ln x)^2-2ln x+2]+C`;

`I_3=x[(ln x)^3-3(ln x)^2+6ln x-6]+C`.

Let `P_n(z)=sum_(j=0)^n (-1)^(n-j)n! z^j/j!`. Coefficients of every power below n in `P_n+P_n'` cancel because `(-1)^(n-j)n!/j! + (-1)^(n-j-1)n!/j! =0`; the coefficient of z^n is 1. Thus `P_n+P_n'=z^n` for arbitrary nonnegative integer n. Differentiating `x P_n(ln x)` gives exactly `(ln x)^n`. This proves the whole finite formula, not merely a set of numerical cases.

For a definite variant with 0<A<B, the same derivation yields

`integral_A^B (ln x)^n dx = [x(ln x)^n]_A^B - n integral_A^B (ln x)^(n-1) dx`.

Its base is B-A. This derived variant clarifies how boundaries and constants are handled; it is not an additional source exercise.

The source visibly prints `v'=dx; v=x` in this example. That is a notation defect, not an alternative derivative rule. The consistent statement is `v'=1` or `dv=dx`. The following calculation clearly uses that choice.

The recurrence can also be valid for other exponents on an interval where powers and derivatives are real and defined, but finite termination is not then assured. For noninteger n, domains of powers of negative `ln x` require care. For negative n, x=1 may be singular. None of those wider cases is licensed by the source's bare instruction to keep reducing n.

### Example 4: powers times exponential

For `J_n=integral x^n e^x dx` with nonnegative integer n, choose `u=x^n`, `dv=e^x dx`; then `du=n x^(n-1) dx`, `v=e^x`. Consequently

`J_n=x^n e^x - n J_(n-1)`, with base `J_0=e^x+C`.

Repeated substitution gives

`J_n=e^x sum_(k=0)^n [(-1)^k n!/(n-k)! x^(n-k)] + C = e^x P_n(x)+C`.

For example `J_1=e^x(x-1)+C`, `J_2=e^x(x^2-2x+2)+C`, and `J_3=e^x(x^3-3x^2+6x-6)+C`. The same exact identity `P_n+P_n'=x^n` proves the derivative is `x^n e^x`. Integer powers are polynomials, so this covers every real x. General noninteger powers need their real domains specified and do not generally terminate under this reduction. A finite-interval variant retains the boundary term `[x^n e^x]_A^B`.

## 3. Unevaluated integrals and the printed parameter family: page 4

### The word “impossible” needs a mathematical qualification

The source calls both `integral (atan x)^2 dx` and `integral e^x/x dx` impossible. Read literally as absence of an antiderivative or any evaluable integral, that is false. The first integrand is continuous on all real x; the second is continuous on each of x>0 and x<0. FTC therefore constructs primitives:

`H(x)=integral_0^x (atan t)^2 dt`, all real x;

`E_+(x)=integral_1^x e^t/t dt`, x>0;

`E_-(x)=integral_(-1)^x e^t/t dt`, x<0.

Each derivative is its stated integrand. A separate arbitrary constant is allowed on each disconnected domain of e^x/x. No primitive across x=0 is asserted.

Independently applying parts to the squared-arctangent example gives, with theta=atan x,

`integral (atan x)^2 dx = x theta^2 - 2 integral [x atan x/(1+x^2)] dx`.

A second parts step yields a verified exact representation

`x theta^2 - theta ln(1+x^2) - 2 integral_0^theta ln(cos t) dt + C`.

Here theta lies in (-pi/2,pi/2), so cos(t)>0 on the integration path. Differentiating the first term gives `theta^2+2x theta/(1+x^2)`. The second gives `-ln(1+x^2)/(1+x^2)-2x theta/(1+x^2)`. The integral term gives `-2ln(cos theta)/(1+x^2)=ln(1+x^2)/(1+x^2)`. The unwanted terms cancel. This independently shows precisely where straightforward parts leaves a different integral.

The appropriate intended topic is lack of an elementary closed-form antiderivative. The source asserts this informally but does not prove it. Neither source nor baseline supplies a theorem capable of establishing those non-elementarity claims. They are therefore recorded as source assertions with a proof gap, not as independently proved technical facts or prior student knowledge. Failure of one attempted method alone would not prove them.

### The definite integral from 1 to 2

`Q=integral_1^2 e^x/x dx` is a complete exact specification of a finite real number: its integrand is continuous on that compact interval. It is not necessary to name a new special function to specify Q. It is a suitable exact answer when the requested quantity is that definite integral and no particular numerical precision is required.

A source-only numerical route follows from the baseline exponential series. The N-term finite approximation integrates to

`Q_N=ln 2 + sum_(k=1)^N (2^k-1)/(k k!)`.

For 1<=x<=2, terms after degree N have first term at most `2^(N+1)/(N+1)!` and successive ratios at most `2/(N+2)`. Their sum is at most

`B_N = [2^(N+1)/(N+1)!]/[1-2/(N+2)]`, for N>=1.

After division by x>=1 and integration over an interval of length 1, `0 < Q-Q_N <= B_N`. This is an explicit finite-polynomial approximation and geometric tail bound derived from permitted premises, without an imported general Taylor remainder or unqualified exchange of infinite operations. For N=24, B_N is below 2.4e-18. A numerical evaluation gives Q approximately 3.05911653964595. The verification script records the finite-sum value and tail bound; its floating-point rounding is distinct from the analytic tail bound.

The lecture's broader claim that one can “always” evaluate a set-up integral numerically requires convergence and an appropriately well-posed numerical task. The very next displayed improper integral provides a counterexample to treating all such quantities as finite.

### The printed F(a) diverges for every real a

Both the text and full-page PNG show the positive exponential:

`F(a)=integral_1^infinity e^x/x^a dx`.

It must not silently become e^(-x), and the upper endpoint must not silently become finite. For any fixed real a, choose a nonnegative integer m>=a. For x>=1, the baseline exponential series has nonnegative terms and gives `e^x >= x^m/m!`. Hence

`e^x/x^a >= x^(m-a)/m! >= 1/m!`.

For R>1,

`integral_1^R e^x/x^a dx >= (R-1)/m!`,

which grows without bound as R tends to infinity. Thus the displayed improper integral diverges to positive infinity for every real a; there is no finite real-valued dependence on a to study in that displayed family. This conclusion uses an explicit lower bound and the baseline definition of an improper integral. No memorised “exponential beats a power” theorem is needed.

For completeness, parts with finite R gives the valid identity

`F_R(a)=e^R/R^a-e+a F_R(a+1)`,

where `F_R(a)=integral_1^R e^x/x^a dx`. This does not become a finite recurrence at infinity: its upper boundary term does not vanish, and all displayed F values diverge. Expressions that subtract separate infinities are not justified. A negative exponential would be a different mathematical input; author intention is not recoverable from the allowed source, and no replacement is made.

## 4. Graph arc length and Figures 1–3: pages 5–6

Figure 1 shows a graph y=f(x), axes x,y, a short curve segment ds, and horizontal/vertical changes dx,dy. Figure 2 magnifies the local right triangle with positive side lengths labelled dx,dy and hypotenuse ds. A finite straight chord has length `sqrt((Delta x)^2+(Delta y)^2)`. The finite curved piece is not exactly that straight hypotenuse. For a smooth graph, shrinking the pieces motivates the tangent/length element

`ds=sqrt(dx^2+dy^2)=sqrt(1+(dy/dx)^2) |dx|`.

The absolute value is material: length is nonnegative. In an integral with x increasing from a to b, a<b, it is represented by

`L=integral_a^b sqrt(1+[f'(x)]^2) dx`.

A sufficient ordinary setting is a continuously differentiable graph on [a,b]. The lecture's differential picture motivates the rule; it is not a proof that arbitrary curves, discontinuities, corners, or vertical tangencies automatically satisfy a single unqualified graph formula. Piecewise smooth pieces can be handled separately, and an endpoint singularity needs its limiting argument. Local derivative approximation plus increasingly fine chord sums explains the formula's construction; a full general convergence theorem is not supplied by the source or silently granted by the baseline.

Figure 3 explicitly has P0 above x=a and P1 above x=b with a<b. The curve is increasing in the drawing, but the length formula does not require f to increase: the squared slope also handles decreasing graphs. The path notation `integral_(P0)^(P1) ds` denotes the nonnegative length along the selected curve, then becomes the displayed x integral. It is not an ordinary signed area integral of f(x). Reversing traversal does not negate geometric length; one must reorder graph integration limits or use an appropriate increasing path parameter.

The source algebra divides `(ds)^2=(dx)^2+(dy)^2` by `(dx)^2` to obtain `1+(dy/dx)^2`. This describes a graph coordinate with available derivative, not a licence to divide by a zero horizontal tangent displacement on an arbitrary parametrisation. The nonnegative square root and increasing-x convention explain the source's final form without an absolute value. There is no quantitative function supplied in Figures 1–3, so no numerical length can or should be inferred from their drawings.

## 5. Example 5, unit circle, and Figures 4–6: pages 6–8

Figure 4 is the unit circle `x^2+y^2=1` about the origin. Its caption says “Example 1”; the surrounding heading correctly calls this Example 5. This is a caption-reference defect, with no change to the equation. The whole circle is not one graph y=f(x). The next page selects its upper branch.

Figure 5 selects the first-quadrant arc from (0,1) to `(a,sqrt(1-a^2))`, shown as a thick arc, with a dashed vertical line to the x-axis. Its displayed geometry is 0<a<1; the natural degenerate/end extensions are 0<=a<=1. Here a is a horizontal coordinate on a unit circle, not the radius a introduced later.

On the upper semicircle,

`y=sqrt(1-x^2)`, for -1<=x<=1;

`y'=(1/2)(1-x^2)^(-1/2)(-2x)=-x/sqrt(1-x^2)`, for -1<x<1.

Every source simplification then follows:

`1+(y')^2=1+x^2/(1-x^2)=[1-x^2+x^2]/(1-x^2)=1/(1-x^2)`;

`sqrt(1+(y')^2)=1/sqrt(1-x^2)`, positive on -1<x<1.

Therefore, for 0<=a<1,

`s=integral_0^a dx/sqrt(1-x^2) = asin(a)-asin(0)=asin(a)`.

The principal inverse sine gives `s in [0,pi/2)` and `sin(s)=a`. At a=0, s=0. At a=1, the graph derivative is unbounded and the integral is improper, but

`lim_(b->1-) integral_0^b dx/sqrt(1-x^2) = lim_(b->1-) asin(b)=pi/2`.

This finite endpoint value is justified by the limit rather than direct application of a C1-on-closed-interval formula. At a outside [0,1], the pictured arc and formula as a positive length no longer apply without specifying a new arc. In particular, a negative a makes the oriented integral from 0 to a negative; the upper-left arc length would be `abs(asin a)`. Values |a|>1 have no real point on this unit-circle graph.

Figure 6 draws the radius to the endpoint with length 1, the horizontal leg a, and the top arc marked s. The angle measured from the positive vertical radius toward that endpoint has opposite side a and hypotenuse 1, so its sine is a. Since the radius is 1, the baseline circle relation arc length=radius times angle makes the numerical angle in radians equal to s. This agrees with the integral. If one instead uses the conventional polar angle phi from the positive x-axis, then `phi=pi/2-s`; confusing those two angles would reverse the trigonometric relation.

The figure is a geometrical explanation of the principal range and units. The red arc marking is not additional numerical data and does not assert two traversals.

## 6. Parametric equations, Examples 6–7, and Figures 7–8: pages 8–9

### Example 6: circle

The equations are `x=a cos t`, `y=a sin t`. The symbol t varies and a is constant. For the positive-radius first-quadrant drawing, take a>0. Substituting gives

`x^2+y^2=a^2 cos^2 t+a^2 sin^2 t=a^2`.

At t=0, `(x,y)=(a,0)`. At t=pi/2, `(x,y)=(0,a)`. For 0<t<pi/2, x,y are positive, x decreases, and y increases because `x'=-a sin t<0`, `y'=a cos t>0`. Thus increasing t from 0 to pi/2 traces the first-quadrant quarter circle counterclockwise, as Figure 7's arrow shows.

Eliminating t identifies the circle equation but does not retain parameter interval, travel direction, speed, or repeated traversals. For unrestricted real t, the full circle is traced periodically; t in [0,2pi] traces it once, with coincident first and last point. The source specifies the quarter interval, so the figure is a quarter circle, not an entire circle traversed in that interval.

If a=0 the curve is a single point and no quarter-circle direction remains. If a<0 the radius is abs(a), and the interval [0,pi/2] traces a third-quadrant quarter circle, still counterclockwise; it does not give the pictured positive-axis endpoints. These cases explain why a>0 is the natural assumption for the diagram and the final length expression.

### Example 7: ellipse

The equations are `x=2 sin t`, `y=cos t`. Direct substitution gives

`x^2/4+y^2=(2 sin t)^2/4+(cos t)^2=sin^2 t+cos^2 t=1`.

The full locus is centred at the origin with horizontal semiaxis 2 and vertical semiaxis 1. Figure 8 displays its first-quadrant part, with `(0,1)` at t=0 and `(2,0)` at t=pi/2. For 0<t<pi/2, `x'=2cos t>0` and `y'=-sin t<0`: motion is rightwards and downwards. The initial velocity is `(2,0)` and the final velocity is `(0,-1)`. This is clockwise traversal, consistent with the arrow. The full ellipse is traced clockwise once over [0,2pi], and repeats for unrestricted t. The Cartesian equation alone would not supply the clockwise direction.

There is no ellipse-perimeter calculation in the source. The final arc-length calculation on this page is expressly labelled for Example 6, the circle. It must not be attached to Example 7 merely because it follows the ellipse figure.

### Circle arc length in the parameter

For a smooth parameterised path, the local Pythagorean element is

`ds=sqrt((dx/dt)^2+(dy/dt)^2) |dt|`.

For increasing t on [alpha,beta], alpha<beta, length is the integral of that nonnegative speed with respect to t. Substituting the circle derivatives gives

`sqrt((-a sin t)^2+(a cos t)^2)=sqrt(a^2)=abs(a)`.

Thus the general local expression is `ds=abs(a)|dt|`. For a>0 and forward parameter integration, the source's `ds=a dt` is correct. In that convention the quarter-circle length is

`integral_0^(pi/2) a dt=a pi/2`,

and the full-circle length over one 2pi period is 2pi a. These checks agree with the baseline circumference and radius-times-angle rules. A repeated parameter interval counts repeated travel; it need not be the length of the distinct image set.

As a separation check, the ellipse would instead have speed `sqrt(4cos^2 t+sin^2 t)`, not a constant a. The source does not evaluate its length, and no such result is imported.

## Qualification register

| ID | Source location | Qualification or correction established independently |
|---|---|---|
| Q01 | Page 3, Example 3 | Printed `v'=dx` must be `v'=1` or `dv=dx`. |
| Q02 | Pages 3–4, recurrences | Finite termination requires a nonnegative integer index and a stated base case; one final integration constant suffices. More general exponents need domain restrictions. |
| Q03 | Page 4, “impossible” integrals | Continuous integrands do have primitives on their domains. Non-elementarity is an unproved source assertion, not an independently established fact under the allowed premises. |
| Q04 | Page 4, computer evaluation | Numerical evaluation as a finite value requires convergence and adequate data/precision; setup alone does not ensure this. |
| Q05 | Page 4, F(a) | The printed positive-exponential integral diverges to +infinity for every real a. It must not be silently repaired into a different family. |
| Q06 | Pages 5–6, ds and figures | Finite chord length is an approximation to curved length; the differential formula uses smoothness. Generally ds has abs(dx); the source uses increasing x. |
| Q07 | Page 6, Figure 4 | Caption says Example 1; the surrounding source numbers the circle Example 5. |
| Q08 | Pages 7–8, unit-circle arc | Upper branch, a in [0,1], principal inverse sine, radians, and the angle measured from the vertical are needed for the pictured result. At a=1 use an improper endpoint limit. |
| Q09 | Pages 8–9, circle parameter | a is a new radius parameter; a>0 and increasing t match the figure and ds=a dt. Generally sqrt(a^2)=abs(a). a=0 is degenerate. |
| Q10 | Page 9, ellipse/final formula | Ellipse orientation is clockwise; final ds=a dt concerns Example 6 only. Parameter elimination loses traversal information. |

## Verification and seal meaning

All displayed source equations were reconstructed above from the actual pages and checked by algebra, derivative, endpoint substitution, or explicit limiting argument. The recurrence family has an arbitrary-n cancellation proof, the printed improper family has an arbitrary-real-a lower-bound proof, and all figure claims are tied to their labelled coordinates rather than inferred image scale. The auxiliary arithmetic script checks exact recurrence coefficients and computes the finite-sum numerical approximation; it does not replace those general proofs or count as a student trial.

The source-only preparation is complete at this stage. Its known limitation is deliberate: the informal non-elementarity assertions and a general arc-length convergence theorem cannot be proved solely by citing a theorem absent from both permitted inputs. They are marked accurately rather than invented. No inaccessible input was substituted, no screenshot or baseline line was omitted, and no current-generation acceptance claim is made. Later admission of PROF, a final-prompt-only packet, or frozen teaching must be logged separately and must not retroactively change this seal.
