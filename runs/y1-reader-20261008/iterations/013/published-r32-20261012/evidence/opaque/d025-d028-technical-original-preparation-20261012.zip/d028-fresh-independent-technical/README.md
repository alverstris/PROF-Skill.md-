# D028 sealed source-only preparation

This directory contains the independent original-source technical preparation for MIT 18.01 Lecture 31, Parametric Equations, Arclength, Surface Area.

- `source-only-technical-preparation.md`: complete calculations, figures, assumptions, qualifications, baseline mapping, and original-source discrepancy record.
- `source-coverage.csv`: page-by-page claim and figure coverage, including the cover.
- `access-and-baseline-record.json`: authorized inputs, byte hashes, actual baseline reading intervals, full-page visual coverage, and excluded access.
- `verification.json`: algebraic/numerical verification record. Numerical quadrature is evaluator-only verification, not a newly assumed student method.
- `verify-calculations.py`: reproducible independent computational checks of derived expressions.
- `SHA256SUMS`: sealed payload checksums.
- `seal.json`: source-only stage state, embargo, exclusions, and digest of the payload checksum manifest.

All 1,377 baseline lines, all five source text files, and all five full PNGs were inspected. The lecture PDF and baseline matched the exact assigned identities. The PDF has a cover followed by printed lecture pages 1–4.

The stage is preparation only. No current or old teaching artifact, report, queue, findings, PROF, final-prompt packet, or whole frozen new teaching was inspected. There is no acceptance verdict or student-trial claim. These findings are withheld from future authors pending the coordinator's full-teaching freeze. Subsequent admitted stages must preserve this source-only seal and record their own access and conclusions separately.
