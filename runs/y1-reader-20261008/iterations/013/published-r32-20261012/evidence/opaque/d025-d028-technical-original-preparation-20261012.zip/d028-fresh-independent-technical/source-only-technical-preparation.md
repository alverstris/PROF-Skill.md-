# D028 independent technical preparation — sealed source-only stage

Status: completed source-only technical preparation on 2026-10-12. This record is not a review or acceptance of any current generation, teaching document, prompt packet, student response, or PROF implementation. No such material has been admitted or inspected. Findings remain embargoed from future authors until the coordinator records the full teaching freeze.

The only subject-content inputs were the five-page original `lec31.pdf`, its five supplied full-page PNGs and five supplied text files, and the complete four-subject student baseline. The source identity was independently checked: 980,981 bytes; SHA-256 `bb9c961070896a4290b78aa35cdfcd794cb7ac87318f40c7fdb86f4f2332a85e`. The baseline was independently checked: 247,840 bytes, 1,377 LF-delimited lines; SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`.

PDF page numbers below include the cover. Printed lecture pages 1–4 are PDF pages 2–5. All five full PNGs were directly viewed at original 1224 × 1584 resolution. All five text files were read in full. All baseline lines were directly read in the bounded intervals recorded in `access-and-baseline-record.json`. Source URLs were visible provenance only: none was opened. `source-identity.json` was listed by filename during the exact authorized directory inventory but was not opened or followed.

## Source calculation 1: the parametric curve and its length

The stipulated curve is

\[
x=t^2,\qquad y=t^3,\qquad 0\le t\le1.
\]

The restrictions give \(0\le x\le1\), \(0\le y\le1\), and traversal from \((0,0)\) to \((1,1)\), without retracing. Since \(t\ge0\), \(t=\sqrt{x}\), so

\[
y=x^{3/2},\qquad 0\le x\le1.
\]

Equivalently, \(x^3=y^2\) together with \(y\ge0\) selects \(y=\sqrt{x^3}\). If solving for the other coordinate, \(x=y^{2/3}\). The original page prints **\(y=x^{2/3}\)**. This is a definite source error, visible in the full page-2 PNG and present in the page-2 text, rather than an OCR-only error. For example, \(t=1/2\) gives \((x,y)=(1/4,1/8)\); the printed Cartesian equation fails there. The subsequent lecture calculations use the correct original parameterization and do not inherit this exponent error.

The curve has \(dy/dx=3t/2=(3/2)\sqrt{x}\) for \(t>0\). The graph has a horizontal one-sided tangent at the origin, obtained directly from \(y=x^{3/2}\) or its difference quotient; the formula \((dy/dt)/(dx/dt)\) is not evaluated as \(0/0\) there. Its positive increasing slope agrees qualitatively with Figure 1. The curve is smooth as a graph on its interval even though its selected parameterization has zero velocity at its initial endpoint.

For a small finite parameter interval, the endpoint chord has length

\[
\sqrt{(\Delta x)^2+(\Delta y)^2}.
\]

The infinitesimal right triangle in Figure 1 represents the first-order limit of these chords. Its \(ds\) is the curve-length increment, with horizontal \(dx\) and vertical \(dy\). One must not assert that a finite curved arc is exactly its chord. For a continuously differentiable parameterization traversed with increasing \(t\), the resulting speed formula is

\[
ds=\sqrt{x'(t)^2+y'(t)^2}\,dt.
\]

The same formula follows from the baseline's componentwise velocity, two-dimensional speed, and distance as the integral of speed. A finite zero-speed endpoint does not invalidate this integrable formula. For a general orientation-independent differential, write \(ds=\sqrt{x'^2+y'^2}|dt|\). A parameterized path that retraces an arc counts that arc again in its traveled length.

Here

\[
dx=2t\,dt,\quad dy=3t^2\,dt,\quad
(ds)^2=(4t^2+9t^4)(dt)^2,
\]

and

\[
\sqrt{4t^2+9t^4}=|t|\sqrt{4+9t^2}=t\sqrt{4+9t^2}
\]

because \(t\ge0\) on the stipulated interval. Thus

\[
L=\int_0^1t\sqrt{4+9t^2}\,dt.
\]

Put \(w=4+9t^2\), so \(dw=18t\,dt\) and the limits become 4 and 13:

\[
L=\frac1{18}\int_4^{13}w^{1/2}\,dw
=\frac{13^{3/2}-4^{3/2}}{27}
=\frac{13\sqrt{13}-8}{27}
\approx1.43970987337155.
\]

Differentiating \((4+9t^2)^{3/2}/27\) recovers \(t\sqrt{4+9t^2}\). An independent graph-coordinate calculation gives

\[
L=\int_0^1\sqrt{1+\tfrac94x}\,dx
=\frac{(4+9x)^{3/2}}{27}\Big|_0^1,
\]

the same result. In particular \(L>\sqrt2\), as required for this nonstraight curve joining endpoints at distance \(\sqrt2\).

The source's remark that numerical methods can be used is operationally sound for these finite, continuous integrands. Such numerical calculation approximates the integral; it is not a promise of an exact closed form, or of successful computation for arbitrary pathological input. The baseline provides a trapezium method. Evaluator-only numerical quadrature below is a check, not an additional student premise.

## Source calculation 2: the surface of revolution

Figure 2 has a nonnegative height \(y\) above the \(x\)-axis between two axial positions \(a,b\). A point at height \(y\) rotates along a circle of radius \(y\), hence circumference \(2\pi y\). A narrow sloping strip of width \(ds\) therefore contributes, to first order,

\[
dA=2\pi y\,ds,
\qquad A=\int 2\pi y\,ds.
\]

This is a lateral surface area, not the area under the curve and not a volume. The use of slant width \(ds\), rather than axial width \(dx\), is consequential. One derivation is to approximate the generating curve with short straight segments: revolving one segment produces a cone frustum with lateral area \(\pi(r_1+r_2)\ell\), which tends to \(2\pi y\,ds\). The frustum expression follows from subtracting the areas of two similar conical sectors: a cone with slant length \(s\) and base radius \(r\) unfolds to a sector of radius \(s\), arc length \(2\pi r\), and area \(\pi rs\). For a frustum, similarity then gives \(\pi(r_1+r_2)\ell\). These are derivations from the baseline's sector area/circumference/similarity rules; the frustum formula itself need not be presumed pre-taught.

The domain qualifications for the displayed source formula are: one complete rotation about the \(x\)-axis; nonnegative \(y\) so \(y\) is the radial distance; sufficient piecewise smoothness for length/area integration; and a generating arc producing the intended surface once. More generally the distance to the axis is \(|y|\). If a parameterization or generating branch covers the same surface repeatedly, the direct integral counts repeated coverage. Reversing parameter orientation must not make geometric area negative. No end disks are included unless separately requested. These issues do not obstruct the stipulated monotone nonnegative curve.

For the source's Example 2, \(y=t^3\ge0\), and the previously calculated \(ds=t\sqrt{4+9t^2}\,dt\) gives

\[
A=2\pi\int_0^1t^4\sqrt{4+9t^2}\,dt.
\]

Figure 3 represents this finite, flaring trumpet surface: it starts at the origin and ends at \(x=1\) with radius 1. Its lower visible boundary and dashed rear arcs depict rotation of the single upper generating curve; they are not an instruction to integrate upper and lower generating curves separately. No end cap is drawn or requested. If a closing disk at \(x=1\) were explicitly requested, that would add \(\pi\), but it is outside the lecture's requested lateral area.

Let

\[
I=\int t^4\sqrt{4+9t^2}\,dt.
\]

The source temporarily drops the constant \(2\pi\). With its substitution

\[
t=\frac23\tan u,\quad dt=\frac23\sec^2u\,du,
\]

choose \(u=\arctan(3t/2)\) on \([0,\arctan(3/2)]\). This is contained in \([0,\pi/2)\), so \(\sec u>0\) and

\[
\sqrt{4+9t^2}=2\sqrt{1+\tan^2u}=2\sec u.
\]

Without that branch choice the square root is \(2|\sec u|\). Combining the factors gives

\[
I=\left(\frac23\right)^5\int \tan^4u(2\sec u)\sec^2u\,du
=\frac{64}{243}\int(\sec^7u-2\sec^5u+\sec^3u)\,du.
\]

Every coefficient in the source's displayed substitution is correct. For the definite integral, use the new endpoints above, or return fully to \(t\) before inserting 0 and 1. The source explicitly stops at this trigonometric integral and does not supply a final exact value. Its statement that the integral is doable can nevertheless be independently completed as follows.

Write \(J_n=\int\sec^n u\,du\). Integration by parts, taking \(\sec^{n-2}u\) and \(\sec^2u\,du\), gives

\[
J_n=\frac{\sec^{n-2}u\tan u}{n-1}
+\frac{n-2}{n-1}J_{n-2}.
\]

This recurrence is derived here, not imported as assumed baseline knowledge. The initial integral is \(J_1=\ln(\sec u+\tan u)\) on the chosen branch, verified by differentiating. Applying the recurrence at \(n=3,5,7\) yields

\[
J_7-2J_5+J_3
=\frac16\sec^5u\tan u-\frac7{24}\sec^3u\tan u
+\frac1{16}\sec u\tan u+\frac1{16}\ln(\sec u+\tan u).
\]

For \(D=4+9t^2\), back substitution produces a convenient primitive

\[
F(t)=\frac{t\sqrt D(81t^4+9t^2-6)}{486}
+\frac4{243}\operatorname{arsinh}\!\left(\frac{3t}{2}\right).
\]

The baseline supplies \(\operatorname{arsinh}z=\ln(z+\sqrt{z^2+1})\), so the logarithmic form is equally available. The lower endpoint gives \(F(0)=0\). The upper endpoint gives

\[
\int_0^1t^4\sqrt{4+9t^2}\,dt
=\frac{14\sqrt{13}}{81}
+\frac4{243}\ln\left(\frac{3+\sqrt{13}}2\right)
\approx0.6428485861672263.
\]

Restoring \(2\pi\), the independently completed lateral surface area is

\[
\boxed{A=\frac{28\pi\sqrt{13}}{81}
+\frac{8\pi}{243}\ln\left(\frac{3+\sqrt{13}}2\right)}
\approx4.039136791347087.
\]

This boxed exact result is an independent completion, **not a result printed by the original source**. To verify it algebraically, let \(P=81t^4+9t^2-6\). On differentiating \(F\), its numerator over \(486\sqrt D\) is

\[
(D+9t^2)P+tDP'+24
=4374t^6+1944t^4
=486t^4D.
\]

Therefore \(F'=t^4\sqrt D\) exactly. The derived recurrence uses only integration by parts and the baseline's trigonometric/derivative rules. It is not necessary to introduce any outside special-function theory.

## Source calculation 3: the unit sphere and spherical band

The generating curve is the **upper semicircle in the plane**,

\[
y=\sqrt{1-x^2},\qquad -1\le x\le1.
\]

The source's phrase about the “top half of the sphere” must be read in this generating-curve sense. Rotating this upper semicircle once around the \(x\)-axis gives the entire sphere. It does not require doubling its resulting area. Figure 4 shows the outer peel between planes \(x=a\) and \(x=b\), rotated through \(2\pi\); the caption expressly excludes the insides. The pictured \(a,b\) are on the positive side, but the algebra applies whenever \(-1\le a\le b\le1\). The width \(b-a\) is axial width, not curved meridian length. The unlabelled depth axis in the drawing is perspective context.

The source invokes a result from the previous lecture. No previous lecture has been admitted; here is the independent derivation. On \(-1<x<1\),

\[
y'=-\frac{x}{\sqrt{1-x^2}},\qquad
ds=\sqrt{1+(y')^2}\,dx
=\frac{dx}{\sqrt{1-x^2}}
\]

for increasing \(x\). Hence, first for interior endpoints,

\[
A=\int_a^b2\pi y\,ds
=\int_a^b2\pi\sqrt{1-x^2}\frac{dx}{\sqrt{1-x^2}}
=\boxed{2\pi(b-a)}.
\]

The factor \(y\) decreases near the pole while the slant factor \(ds/dx\) increases; their product is 1. Equal axial-width bands consequently have equal area. The derivative form is singular at \(x=\pm1\); the intermediate quotient is not evaluated there as ordinary division by zero. To include an endpoint pole, compute on an interior interval and take the corresponding one-sided limit. The simplified area integrand has the finite continuous value \(2\pi\), so the limits exist.

A second derivation avoids a singular derivative entirely: take \(x=\sin\theta\), \(y=\cos\theta\), with \(-\pi/2\le\theta\le\pi/2\). Its speed is \(\sqrt{\cos^2\theta+\sin^2\theta}=1\), and the area between the stated axial planes is

\[
2\pi\int_{\arcsin a}^{\arcsin b}\cos\theta\,d\theta
=2\pi(b-a).
\]

Both derivations respect the one-traversal and nonnegative-radius conditions.

The special cases printed in the source are correct:

- Whole sphere: \(a=-1,b=1\) gives \(4\pi\) square units.
- Curved hemisphere: \(a=0,b=1\) gives \(2\pi\) square units.

The hemisphere statement concerns only curved surface. A closed hemisphere including its equatorial unit disk would have \(3\pi\), a different request. The whole-sphere numerical result was already supplied in the baseline's elementary geometry; the source contributes its calculus derivation and band-area property. \(a=b\) gives the consistent degenerate value 0. Reversed endpoints should not be used to report a negative geometric surface area.

## Baseline-to-source boundary

The whole combined baseline was read, not merely searched for matches. The operational dependencies are concentrated in Mathematics, Further Mathematics, and the Physics geometry/rate statements. Chemistry supplies no additional mathematical or physical premise required by this particular lecture. Its full section still forms part of the inspected starting input.

| Baseline location (LF line numbers) | Available premise | Consequence for this source |
|---|---|---|
| 28–34, 46, 60 | Pythagoras, signed domains, standard areas, powers, modulus | Correct elimination; select \(y\ge0\); use \(\sqrt{t^2}=|t|\); check radius and units. |
| 68–72 | Coordinate distance, circle equation, parameter elimination with restrictions and direction | Interpret the curve, endpoints, one traversal, and semicircle. |
| 101–122 | Radians, sector area, reciprocal trig, \(1+\tan^2=\sec^2\) and angle identities | Rotation circumference; derive cone/frustum strip; perform the tangent substitution with a checked branch. |
| 136–174 | Derivative definition, power/chain/product rules, parametric derivative and nonzero-denominator condition | Differentiate both coordinates; derive circle \(y'\); do not use \(0/0\) at the starting endpoint. |
| 176–203 | Antiderivatives, FTC, integral as sums, substitution with limits, integration by parts, signed area/distance | Evaluate length; derive secant recurrence if finishing the optional exact trumpet integral; keep geometric areas nonnegative. |
| 211–227 | Numerical approximation and trapezium formula | Numerically approximate the displayed finite integrals if analytic completion is not requested. |
| 231–235, 297, 306–312 | Component vector magnitude, componentwise velocity, two-dimensional speed, distance vs displacement | Explicitly derive parametric length as the integral of speed. The formula need not be assumed as an unexplained new name. |
| 403–407 (FM24–26) | Hyperbolic definitions/calculus and inverse-hyperbolic logarithmic form | Express and independently differentiate the completed trumpet primitive. |
| 411–413 (FM28–29) | Improper integrals, one-sided limits, inverse trigonometric derivatives, trig/hyperbolic substitution with domains | Handle poles of the sphere's graph-coordinate arclength factor; choose appropriate transformed bounds. |
| 415 (FM30) | Disk/washer volumes of revolution | Distinguish already available volume calculus from the source's new lateral-area construction. A volume formula alone is not a surface-area formula. |
| 417 (FM31) | Explicit warning against repeated tracing in polar area | Reinforces multiplicity caution; no general arbitrary surface-integral formalism is thereby granted. |
| 527, 594, 684 | Circumference/cylinder/sphere geometry, speed-area reasoning, circular arc-length | Independent known geometry and physical distance reasoning cross-check the calculus. |

The supplied baseline does not explicitly grant an arbitrary surface-area-of-revolution integration formula, general field surface integrals, or a memorized secant-power reduction formula. The lecture must establish the \(2\pi y\,ds\) construction for the former; the latter reduction can be derived from the supplied integration-by-parts rule if a complete exact integral is actually required. The original explicitly stops before that exact completion, so a future assessment requiring it would need a fair route from the available premises, not a claim that the lecture printed the answer.

## Source qualifications and definite discrepancy

1. Definite original error: PDF page 2 prints \(y=x^{2/3}\); the stipulated curve is \(y=x^{3/2}\). Both the visual and text evidence agree on what is printed.
2. \(\sqrt{t^2}=t\) is valid here because the parameter interval is nonnegative; this is not a universal algebraic simplification.
3. Figure 1's right triangle is a local/limiting relation. Its finite chord is not exactly its finite curved arc.
4. The surface formula uses distance to the specified axis, one rotation, one intended surface coverage, and lateral area without unrequested end caps. Signed coordinates or reversed traversal must not create negative area.
5. The tangent substitution needs a branch with positive secant; the stated interval supplies one. Definite bounds must be transformed consistently.
6. The exact trumpet integral is intentionally unfinished in the lecture; its completion above is independent analysis.
7. The sphere calculation uses a planar upper semicircle as generator. The resulting full sphere is not doubled. The band formula requires admissible ordered axial bounds.
8. Endpoint poles require limits or a nonsingular circle parameterization before extending the interior graph formula.
9. Numerical approximation for these well-behaved finite integrals is available; exact equality is not established by a decimal alone.

No claim in this record evaluates a current teaching generation. There are no admitted final assessment prompts, no student trial, and no current acceptance decision. Subsequent stages must use separately admitted inputs and preserve this source-only seal.
