"""Evaluator-only arithmetic verification; no external or subject-content reads."""
import json
import math


def simpson(function, panels):
    """Numerical cross-check only; Simpson's rule is not a baseline grant."""
    h = 1 / panels
    return h / 3 * (
        function(0) + function(1)
        + 4 * sum(function(i * h) for i in range(1, panels, 2))
        + 2 * sum(function(i * h) for i in range(2, panels, 2))
    )


def add_polynomials(*polynomials):
    size = max(map(len, polynomials))
    return [sum(p[i] if i < len(p) else 0 for p in polynomials)
            for i in range(size)]


def multiply_polynomials(p, q):
    result = [0] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            result[i + j] += a * b
    return result


D = [4, 0, 9]
P = [-6, 0, 9, 0, 81]
P_prime = [i * P[i] for i in range(1, len(P))]
derived_numerator = add_polynomials(
    multiply_polynomials([4, 0, 18], P),
    multiply_polynomials([0] + D, P_prime),
    [24],
)
target_numerator = multiply_polynomials([0, 0, 0, 0, 486], D)
assert derived_numerator == target_numerator

length = (13 * math.sqrt(13) - 8) / 27
integral = 14 * math.sqrt(13) / 81 + 4 * math.asinh(1.5) / 243
area = 2 * math.pi * integral
checks = []
for panels in (100, 1000):
    numeric_length = simpson(lambda t: t * math.sqrt(4 + 9*t*t), panels)
    numeric_integral = simpson(lambda t: t**4 * math.sqrt(4 + 9*t*t), panels)
    checks.append({
        "panels": panels,
        "length": numeric_length,
        "integral_without_2pi": numeric_integral,
        "surface_area": 2 * math.pi * numeric_integral,
        "length_absolute_error": abs(numeric_length - length),
        "surface_area_absolute_error": abs(2 * math.pi * numeric_integral - area),
    })

assert checks[-1]["length_absolute_error"] < 1e-11
assert checks[-1]["surface_area_absolute_error"] < 1e-10
assert length > math.sqrt(2)
print(json.dumps({
    "role": "Evaluator-only verification of independently derived source calculations",
    "subject_content_inputs_in_this_script": [],
    "symbolic_check": {
        "polynomial_coefficient_order": "constant through degree six",
        "trumpet_primitive_derivative_numerator": derived_numerator,
        "required_486_t4_D": target_numerator,
        "exact_integer_equality": derived_numerator == target_numerator,
    },
    "length_exact_expression": "(13*sqrt(13)-8)/27",
    "length_numeric": length,
    "trumpet_integral_exact_expression": "14*sqrt(13)/81 + 4*asinh(3/2)/243",
    "trumpet_integral_numeric": integral,
    "trumpet_area_exact_expression": "28*pi*sqrt(13)/81 + 8*pi*ln((3+sqrt(13))/2)/243",
    "trumpet_area_numeric": area,
    "quadrature": checks,
    "quadrature_scope": "Simpson quadrature is an evaluator-only independent approximation, not assumed student knowledge, not a subject-content source, and not the proof of the exact integral.",
    "sphere_band_result": "2*pi*(b-a), -1 <= a <= b <= 1; curved surface only",
    "sphere_total_area": "4*pi",
    "hemisphere_curved_area": "2*pi",
    "student_trial_performed": False,
    "current_generation_acceptance_claim": False,
}, indent=2))
