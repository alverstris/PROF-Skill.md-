# D030 original-only technical seal

Prepared independently for future D030 work. The authorized original PDF/page derivatives and the complete four-subject baseline are the only subject inputs.

- `technical-dossier.md`: independent solutions of examples 0–10, theorem/domain checks, all remaining source claims, visual coverage and findings.
- `baseline-read-record.md`: actual full-baseline reading, bounded ranges and explicit truncation repairs.
- `coverage.tsv`: page-by-page source-unit accounting.
- `input-manifest.json`: exact authorized inputs, byte counts, SHA-256 hashes and verification against supplied identity metadata.
- `access-log.json`: actual access sequence and exclusions; bounded baseline-range byte hashes.
- `SHA256SUMS`: sealed output hashes, excluding the seal file itself.
- `seal.json`: seal creation time, input/output scope and manifest hash.

Confidentiality of staging: withhold the substantive findings from a future author until the full new teaching artifact is frozen. Nothing in this folder is a current teaching acceptance, student trial, PROF review or final-prompt solution. None of those later inputs was opened. This stage used no browser, network, GitHub writes, queue, ancestry-path search, broad folder search or other-agent content. URLs inside admitted originals were read only as text.
