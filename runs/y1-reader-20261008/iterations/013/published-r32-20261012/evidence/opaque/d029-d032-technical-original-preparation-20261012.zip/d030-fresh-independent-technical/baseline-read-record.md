# D030 baseline actual-read record

Only the exact authorized `student-baseline.txt` was read. All references below use physical LF line numbering as used by `sed`, not the larger universal-newline line count caused by embedded CR sequences.

The file has 247840 bytes, 1377 LF terminators, a final LF, and SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. The final `sed` range reached and included the actual end at line 1377. No text beyond the file was inferred.

| Actual displayed range | Read outcome | Semantic coverage |
|---|---|---|
| 1–350, first attempt | Tool reported a middle truncation; this attempt alone is not counted as a full read. | Initial cover and Mathematics pass. |
| 1–175 | Fully displayed and read. | Cover; Mathematics arithmetic, logic, algebra, functions, sequences, trigonometry, exponentials/logarithms, differentiation. |
| 176–350 | Fully displayed and read. | Mathematics integration, ODEs, numerical methods, vectors, probability, tests and mechanics; Further Mathematics heading. Repairs the earlier truncation. |
| 351–525 | Tool reported a middle truncation spanning part of FM38–FM46; all displayed portions were read. | Further Mathematics Pure Core, Statistics, Mechanics; Physics identity and initial reference data. |
| 420–465 | Fully displayed and read; repair overlaps the whole omitted FM38–FM46 region. | FM33–FM54, including every full omitted probability/statistics paragraph. Together with the displayed parts of 351–525, supplies a complete read of that whole range. |
| 526–675 | Fully displayed and read. | Physics geometry, measurement, uncertainty, practicals, forces, motion, energy, materials, circuits, waves, photons, beginning thermal physics. |
| 676–825 | Fully displayed and read. | Remaining Physics thermal/gas, circular/SHM/gravity, astrophysics, capacitors/fields, nuclear/imaging, declared scope; Chemistry identity and initial quantities/atoms. |
| 826–975 | Fully displayed and read. | Chemistry isotopes, formulae/moles, electron structures, bonding, shapes, inorganic/transition chemistry; table continues into next range. |
| 976–1125 | Fully displayed and read. | Continuation of transition table; rates, equilibrium, acid/base/buffers, enthalpy, cycles, entropy/Gibbs. |
| 1126–1275 | Fully displayed and read. | Gibbs sign table; electrochemistry, organic representation/mechanisms, full reaction toolkit, synthesis, initial analysis tests. |
| 1276–1425 requested, actual 1276–1377 | Fully displayed and read through EOF. | Chromatography, spectra, NMR, practical methods, scope/transfer limits and official-reference list. |

The physical-line section headings are Mathematics at 17, Further Mathematics at 346, Physics at 506, Chemistry at 791. Every section was read, including material not directly needed for D030. There was no keyword-only or topic-selection substitute for that read.

Baseline consequences for this source: ordinary algebra, trigonometric differentiation and foundational small-angle limits are supplied; FM27 real Maclaurin expansions are supplied with their stated restrictions. General L’Hôpital is not stated. Physics and Chemistry were checked for cross-subject premises and grant no additional L’Hôpital theorem. The complete inventory, rather than only topic labels or narrower Mathematics exclusions, controlled that conclusion.

This record describes actual displayed reading and repairs, not an assertion that hashing alone constitutes semantic reading. Per-input and per-range byte hashes are in the JSON records. Exact wall-clock times were not captured for individual earlier reads; their order and scopes are recorded without inventing timestamps.
