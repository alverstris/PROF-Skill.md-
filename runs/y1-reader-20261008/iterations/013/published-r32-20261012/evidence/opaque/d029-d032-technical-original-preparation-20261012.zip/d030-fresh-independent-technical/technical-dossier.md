# D030 — independent original-only technical dossier

Stage: original source and complete four-subject baseline only. This is a mathematical source dossier, not a review or acceptance of any teaching artifact. No PROF, final-prompt packet, current/old teaching, review, source audit, author history, queue, other-agent findings, web page, or external research was consulted. Findings are to remain withheld from a future author until the whole new teaching artifact is frozen.

## Admitted inputs and actual reading

The source is MIT 18.01, Fall 2006, Lecture 34, *Indeterminate Forms — L’Hôpital’s Rule*, stable identity `mit-18-01-fall-2006-L34`, material `D030`. The authorized `lec34.pdf` is 221757 bytes, SHA-256 `dafe6f8f1936ee5a0d2a617d82993e85f0dce42a501118c6e26eaac80481f407`. Its five supplied page texts and all five whole-page PNGs, including the OCW cover, were actually read. Page numbers below mean PDF page; printed teaching-page numbers are one smaller. All formulas referred to below were checked in the images, not inferred from OCR alone.

The complete authorized `student-baseline.txt` is 247840 bytes, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. Mathematics, Further Mathematics, Physics and Chemistry were all actually read. The file has 1377 LF-terminated physical lines; embedded CR sequences produce 2561 lines under Python universal-newline `splitlines()`. Read ranges in the separate record are physical LF line numbers. Initial output truncations were explicitly repaired, not counted as complete reads.

No additional source exercises, figures, graphs, or diagrams occur in the five-page packet. There are eleven numbered examples, 0–10, and an easy-rule derivation plus growth/form-transformation claims. The cover has identification and terms links, no mathematical task. Those links and identity-file URLs were not opened.

## Baseline relevant to the mathematics

The baseline already supplies rational factorisation and cancellation with excluded zeros, function domains, sign/inequality reasoning, powers and roots, radians and exact trigonometric values, angle-addition and double-angle identities, small-angle approximations, exponential/logarithmic inverses and differentiation, the derivative as a difference-quotient limit, and product/quotient/chain rules. Mathematics explicitly supplies `sin h/h → 1` and `(cos h−1)/h → 0` when deriving the trigonometric derivatives. They may therefore be used here as prior premises; using L’Hôpital to re-evaluate them is not a new independent foundational proof of those derivatives.

Further Mathematics FM27 supplies the real Maclaurin expansions for exponential, sine and cosine, and the indicated logarithmic/binomial expansions with their validity ranges. It does not grant a general remainder theorem or convergence proof. FM28 supplies one-sided treatment of improper integrals; that does not by itself state the L’Hôpital theorem. General L’Hôpital hypotheses, the derivative-ratio implication and its one-sided/infinite-endpoint variants are not operationally supplied by any of the four baseline sections. They need an explicit mathematical statement in any self-contained treatment that relies on the rule. Physics and Chemistry supply relevant familiarity with rates, exponentials, logarithms, domains and model conditions, but no additional L’Hôpital premise. This is a source/baseline inventory, not a verdict about an unseen teaching artifact.

## Correct mathematical rule and scope

For a finite endpoint `a`, the source’s easy derivation is valid if `f` and `g` are differentiable at `a`, `f(a)=g(a)=0`, and `g′(a)≠0`. For `x≠a`,

`f(x)/g(x) = [(f(x)−f(a))/(x−a)] / [(g(x)−g(a))/(x−a)]`.

The numerator difference quotient tends to `f′(a)` and the denominator one to the nonzero number `g′(a)`. The denominator quotient, and hence `g(x)`, is therefore nonzero sufficiently near `a` with `x≠a`; the quotient limit is `f′(a)/g′(a)`. Differentiability implies the needed continuity at `a`. Merely knowing `f(a)=g(a)=0` is insufficient. The conclusion concerns a limit; it does not define the original ratio at its excluded endpoint. The condition `g′(a)≠0` belongs to this easy version, not to every general L’Hôpital application: Example 5 has `g′(0)=0`.

A sufficient general version relevant to every example is: on an appropriate one-sided interval approaching a finite endpoint, or on an appropriate tail approaching `+∞` or `−∞`, let `f,g` be differentiable with `g′(x)≠0` (and the original quotient defined). Assume `f,g → 0`, or that both tend to signed infinities in magnitude. If `f′(x)/g′(x)` tends to an extended real limit `L` along that same approach, then `f(x)/g(x) → L`. Two-sided finite-endpoint conclusions require matching conclusions from both sides. The functions need not be defined at a finite excluded endpoint. Infinity here describes unbounded limiting behaviour, not a real number substituted into arithmetic.

Each repeated application needs a fresh check of the current numerator and denominator limits, differentiability, nonzero denominator derivative, and the eventual derivative-ratio limit. It is not differentiation of a quotient: replace the numerator and denominator separately by derivatives. Failure of the derivative-ratio limit does not prove that the original limit fails; the implication has no general converse. For example, independently constructed `f(x)=x+x²sin(1/x²)`, `g(x)=x`, `x→0`, gives `f/g=1+x sin(1/x²)→1`, but `f′/g′=1+2x sin(1/x²)−(2/x)cos(1/x²)` has no limit. This counterexample is an independent check of scope, not a source exercise.

The source does not actually state this complete general theorem: it derives the easy case, announces the full rule, then illustrates cases and extends the permitted forms/endpoints informally. The hypotheses above are an independent mathematical clarification, not a transcription of an absent source statement.

## Independent solutions of all eleven examples

### Example 0 — PDF page 2

Problem: `lim(x→1) (x³−1)/(x²−1)`.

Original real domain excludes `x=±1`; in a sufficiently small punctured neighbourhood of `1`, cancellation of `x−1` is valid:

`(x³−1)/(x²−1) = (x²+x+1)/(x+1) → 3/2`.

Independently differentiating `f=x³−1`, `g=x²−1` gives `f′=3x²`, `g′=2x`; `f′(1)=3`, `g′(1)=2≠0`, so the easy rule also gives `3/2`. The printed line `f(x)=x³=1` is a source typo; it must be `f(x)=x³−1`. This typo is visible in the page image. The factorisation, derivative values and stated final answer are otherwise correct.

### Example 1 — PDF page 3

Problem: `lim(x→1) (x¹⁵−1)/(x³−1)`.

Both numerator and denominator tend to zero. `g′=3x²≠0` near `1`, and the derivative ratio is `15x¹⁴/(3x²)=5x¹²→5`. Thus the answer is `5`.

Independent exact check: `x¹⁵−1=(x³−1)(x¹²+x⁹+x⁶+x³+1)`; for `x≠1` the ratio is the latter five-term polynomial and tends to `5`.

The stated linear approximations are correct: with `h=x−1`, the binomial expansions give `(1+h)¹⁵−1=15h+105h²+…+h¹⁵` and `(1+h)³−1=3h+3h²+h³`. After cancelling the nonzero `h`, the remaining quotient tends to `15/3`. This also supplies a precise basis for the approximation argument. The displayed slope/intercept data `a=1`, `b=f(1)=0`, `m=f′(1)=15` are correct.

### Example 2 — PDF page 3

Problem: `lim(x→0) sin(3x)/x`, with angles in radians and `x≠0`.

The form is `0/0`. Numerator derivative is `3cos(3x)` by the chain rule, denominator derivative is `1`, giving the derivative-ratio limit `3`. The answer is `3`.

Independent check from the explicitly supplied baseline limit: write the ratio as `3[sin(3x)/(3x)]`, which tends to `3`. It is also exactly the difference quotient of `sin(3x)` at zero, since `sin(0)=0`. The source’s derivative interpretation and evaluated derivative are correct. This exercise is legitimate use of already known trigonometric derivatives; it cannot simultaneously be used as a noncircular foundational derivation of those same derivatives from no earlier sine limit.

### Example 3 — PDF page 3

Problem: `lim(x→π/4) [sin x−cos x]/[x−π/4]`, in radians.

The numerator at `π/4` is `0`, denominator tends to `0`, and denominator derivative is `1`. The derivative ratio is `cos x+sin x`, whose limit is `1/√2+1/√2=√2`. Thus the answer is `√2`.

Independent check: put `h=x−π/4`; the addition formulas give `sin(π/4+h)−cos(π/4+h)=√2 sin h`. Divide by `h≠0` and use `sin h/h→1`. The displayed `f`, `f′` and derivative value are all correct.

### Example 4 — PDF page 3

Problem: `lim(x→0) (cos x−1)/x`, in radians.

The correct derivative quotient is `−sin x / 1`, so the answer is `0`. The easy derivative-definition check gives the same value `cos′(0)=−sin0=0`.

Independent trigonometric check: `cos x−1=−2sin²(x/2)`, hence the ratio is `−(x/2)[sin(x/2)/(x/2)]²→0`.

The source instead prints `lim(−sin x/x)=0` after the purported differentiation. This is not an OCR defect: the image retains `x` in the denominator. That displayed intermediate limit is actually `−1`, not `0`. The original problem’s final value is right but the written equality is wrong; replace the intermediate denominator by `1`.

### Example 5 — PDF page 4

Problem: `lim(x→0) (cos x−1)/x²`, in radians, `x≠0`.

First form: `0/0`; denominator derivative `2x` is nonzero on each punctured side. First derivative quotient `−sin x/(2x)` remains `0/0`. A second application is legitimate: its denominator derivative is `2`, and the next quotient `−cos x/2→−1/2`. Therefore the answer is `−1/2`.

Independent check: the exact identity gives `(cos x−1)/x² = −(1/2)[sin(x/2)/(x/2)]²→−1/2`. This avoids relying on an unspecified error estimate for a quadratic approximation. The source’s approximation `cos x≈1−x²/2` and resulting value agree with the baseline and the exact check. The repeated original expression at the start of the displayed equality chain is harmless duplication.

### Example 6 — PDF page 4

Problem as printed: the two-sided `lim(x→0) sin x/x²`.

Independent evaluation: `sin x/x²=[sin x/x](1/x)` and the first factor tends to `1` and is positive sufficiently near zero. Thus

- `lim(x→0+) sin x/x²=+∞`;
- `lim(x→0−) sin x/x²=−∞`;
- the two-sided limit does not exist, even as a single extended-real limit.

The first derivative quotient is `cos x/(2x)`. On the right it tends to `+∞`; on the left it tends to `−∞`. The first L’Hôpital application is therefore valid separately on each side, with the original `0/0` form and `g′=2x≠0`. Its derivative-ratio limit does not exist two-sided, so the displayed two-sided equality cannot itself be justified by the two-sided theorem.

Applying the rule again would be invalid: in `cos x/(2x)`, the numerator tends to `1`, not zero or infinity, and the denominator tends to zero. Differentiating anyway gives `−sin x/2→0`, but this value has no justified connection to the original limit. The source is intentionally exposing that misuse; that lesson is correct. Its shorthand `1/0` is a form diagnostic, not an equality to a defined number or to the nonexistent two-sided limit. Its linear-approximation statement about the right-hand approach is correct, but a complete answer to the printed problem must also give the left-hand behaviour and two-sided nonexistence.

### Example 7 — PDF page 4

Problem: `lim(x→+∞) e^(ax)/x`, with fixed `a>0`.

The form is `+∞/+∞`. The denominator derivative is `1`, and the derivative quotient `a e^(ax)` tends to `+∞`. Thus the ratio tends to `+∞`: the exponential dominates `x` in the ratio sense.

Independent bound from the supplied exponential series: for `x>0`, all terms are nonnegative and `e^(ax)≥a²x²/2`, so `e^(ax)/x≥a²x/2→+∞`. This checks the conclusion without assuming the L’Hôpital theorem. The restriction `a>0` matters: for `a=0` or `a<0`, this ratio tends instead to `0` as `x→+∞`, and the original form is not `∞/∞`.

### Example 8 — PDF pages 4–5

Problem: `lim(x→+∞) e^(ax)/x¹⁰`, with the same fixed `a>0`.

After `k` differentiations, for `0≤k≤10`, the numerator is `a^k e^(ax)` and the denominator is `[10!/(10−k)!]x^(10−k)`. For each of the first ten applications (`k=0,…,9`), both current functions tend to `+∞` and the next denominator derivative is nonzero for `x>0`. At `k=10` the ratio is `a¹⁰e^(ax)/10!→+∞`. Stop there; the denominator is now constant. Thus the original limit is `+∞`.

The printed second derivative numerator is `c²e^(ax)`, with an undefined `c`, visibly present in the page image. It should be `a²e^(ax)`. The derivative progression and final numerator `a¹⁰e^(ax)` make the intended correction unambiguous.

The shortcut is valid on the eventually positive domain: for `x>0`, `(e^(ax)/x¹⁰)^(1/10)=e^(ax/10)/x`. Put `b=a/10>0`; Example 7 gives the latter ratio tending to `+∞`, and its tenth power also tends to `+∞`. The equality would have `|x|` in the denominator for arbitrary nonzero real `x`; `x→+∞` makes the source’s `x` version appropriate. The notation `∞¹⁰=∞` is a shorthand for this unboundedness argument.

Independent bound: `e^(ax)≥(ax)¹¹/11!` for `x>0`, so `e^(ax)/x¹⁰≥a¹¹x/11!→+∞`. For `a≤0`, the ratio tends to `0`; the positivity condition must be retained.

### Example 9 — PDF page 5

Problem: `lim(x→+∞) ln x / x^(1/3)`, on the real domain `x>0`.

The form is `+∞/+∞`. Differentiate to obtain `(1/x)/[(1/3)x^(−2/3)]=3x^(−1/3)→0`; the denominator derivative is positive on `x>0`. Thus the answer is `0`.

Independent check: set `t=ln x`, so `t→+∞` and the ratio becomes `t/e^(t/3)`. From the positive exponential series, `e^(t/3)≥t²/18` for `t>0`, so `0≤t/e^(t/3)≤18/t→0`. The displayed derivative and simplification are correct.

### Example 10 — PDF page 5

Problem: `lim(x→0) x^x for x>0`; the real-domain approach is `x→0+`.

For every `x>0`, `x^x=e^(x ln x)`. Near zero the exponent has signed product form `0·(−∞)`. Rewrite it as `ln x/(1/x)`, whose numerator tends to `−∞` and denominator to `+∞`. The derivatives are `1/x` and `−1/x²`, and the derivative quotient is `−x→0` with denominator derivative nonzero. Thus `x ln x→0` (from below), and continuity of the exponential gives `x^x→e^0=1` (from below for sufficiently small positive `x`). All steps are within the positive real domain; no value of `0^0` is being assigned.

Independent check: let `t=1/x→+∞`. Then `x ln x=−ln t/t`. The earlier verified growth comparisons, or the same exponential-series bound after setting `u=ln t`, show `ln t/t→0`; therefore the exponent tends to zero and the answer is `1`.

The source also tries `x/(1/ln x)`. This identity is valid near zero with `x>0` (excluding `x=1`, which is irrelevant to this limit), and it really has form `0/0`, because `1/ln x→0−`. The claimed obstacle that this reciprocal-log limit is unknown is not a mathematical obstruction: `ln x→−∞` immediately gives it, and that logarithmic behaviour is also used by the source’s preferred rewrite. Differentiating this alternative quotient gives `1/[−1/(x(ln x)²)]=−x(ln x)²`, which is less convenient but tends to zero. A verification using Example 9: with `t=1/x`, `(ln t)²/t=[ln t/t^(1/3)]² t^(−1/3)→0`. The alternative route works, although the chosen `ln x/(1/x)` route is shorter.

## Remaining claims checked

**Indeterminate-form notation.** `0/0`, `∞/∞`, `1^∞`, `0^0`, and `0·∞` describe limiting patterns, not numbers or a guarantee of a unique answer. The two quotient types require the theorem’s other hypotheses. Product/power patterns require an algebraic reformulation before a quotient rule applies. For real variable powers, the base must be positive on the relevant approach before taking a logarithm. The sign in the particular product `x ln x` is negative. The source lists but does not set a separate exercise for `1^∞`.

Independent checks of indeterminacy, not additional source tasks: as `t→0+`, `t·(1/t)→1`, `t·(1/t²)→+∞` and `t·(1/√t)→0`; all have the magnitude pattern `0·∞`. The `0^0` pattern can give `1` via `t^t`, or `e^(−1)` via `(e^(−1/t))^t`. The `1^∞` pattern can give `e` via `(e^t)^(1/t)` and `1` via `(e^(t²))^(1/t)`. The quotient `0/0` can give different constants using `ct/t` with fixed nonzero `c`; analogous `∞/∞` examples are `ct/t` as `t→+∞` with `c>0`. These verify the need for more information.

**Derivative remark.** At a point where an ordinary finite derivative exists, continuity makes `Δy=f(a+Δx)−f(a)→0` as `Δx→0`, so the difference quotient is indeed a `0/0` form. This is not an assertion that any ratio of increments has a derivative or that every such limit exists. If continuity/differentiability is not available, the numerator need not tend to zero. L’Hôpital is not a necessary step for evaluating a difference quotient.

**Growth chain.** Interpret the source’s `≪` here as “ratio of the left function to the right function tends to zero,” for `x→+∞` and fixed `a>0`. Each adjacent comparison is independently verified:

| Adjacent pair | Left/right ratio | Limit |
|---|---|---|
| `ln x`, `x^(1/3)` | `ln x/x^(1/3)` | `0`, Example 9 |
| `x^(1/3)`, `x` | `x^(−2/3)` | `0` |
| `x`, `x¹⁰` | `x^(−9)` | `0` |
| `x¹⁰`, `e^(ax)` | reciprocal of positive `e^(ax)/x¹⁰` | `0`, Example 8 |

Thus the displayed order is correct in this ratio sense. It is stronger than eventual pointwise inequality and does not by itself mean a comparison valid for every finite input. The notation’s meaning needs to be supplied rather than silently importing a different asymptotic convention.

**Endpoint extensions.** The rule can be formulated for `x→±∞` and finite one-sided approaches, subject to the same applicable hypotheses. Merely changing the endpoint to infinity does not make a determinate ratio eligible. The source has worked `+∞` examples but no separate `−∞` exercise. No worked proof of the full general theorem occurs in this packet; the elementary derivative proof only establishes its easy finite-endpoint special case.

**Visual/identity content.** The cover and headers identify MIT OpenCourseWare, 18.01, Fall 2006 and Lecture 34. There are no visual diagrams whose geometry needs validation. Whole-page inspection confirms the three literal mathematical typos noted above and the absence of hidden tasks. The spelling aside presents “L’Hôpital” and “L’Hospital”; it supplies no mathematical premise. No separate external historical or attribution verification was performed in this original-only stage.

## Source findings to preserve for later comparison

| ID | Location | Finding | Mathematical consequence / precise correction |
|---|---|---|---|
| D030-S01 | PDF p2, example 0 definition | `f(x)=x³=1` is a visible typo. | Use `f(x)=x³−1`; the stated limit remains `3/2`. |
| D030-S02 | PDF pp2–4, rule exposition | The easy proof needs differentiability at the endpoint; the full general rule’s sufficient hypotheses are never fully stated. | State the applicable one-sided/tail differentiability, nonzero denominator derivative, form and derivative-ratio-limit conditions. Do not apply the easy `g′(a)≠0` condition as a universal endpoint requirement. |
| D030-S03 | PDF p3, example 4 | Differentiated denominator is printed as `x`; `lim(−sin x/x)` is falsely labelled `0`. | The proper denominator derivative is `1`; that gives the correct original answer `0`. The printed intermediate limit would be `−1`. |
| D030-S04 | PDF p4, example 6 | A two-sided problem is left without its full sign-sensitive conclusion; the first displayed two-sided L’Hôpital equality lacks a two-sided derivative-ratio limit. | Right limit `+∞`, left limit `−∞`, two-sided limit nonexistent. First application can be used separately on each side; second application is invalid because the current form is `1/0`. |
| D030-S05 | PDF p4, example 8 | Second derivative numerator contains undefined `c²`. | Replace it by `a²`; keep fixed `a>0`. |
| D030-S06 | PDF p5, example 10 alternative | The asserted difficulty evaluating `1/ln x` is misplaced. | Its right-hand limit is `0−`; the proposed `0/0` rewrite is valid but less convenient. Its derivative quotient also tends to zero. |
| D030-S07 | PDF p5, domain/notation | The positive domain and eventual positive tenth-root calculation are essential qualifiers, not additional source errors. | Use `x→0+` for `x^x`; keep `x>0` in the root shortcut, radians in trigonometry, and interpret indeterminate symbols as forms rather than numerical equalities. |

Status: every source example and mathematical claim in the admitted five-page packet has an independent calculation or explicit scope check above. This status does not certify any current or future teaching, assessment, learner answer, PROF compliance, or source-to-teaching coverage. Those inputs were not admitted and were not read.
