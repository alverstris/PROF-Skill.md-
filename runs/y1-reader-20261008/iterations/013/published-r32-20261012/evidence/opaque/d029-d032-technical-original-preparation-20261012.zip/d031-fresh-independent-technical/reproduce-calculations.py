"""Reproduce numerical arithmetic in the D031 original-only technical dossier.

Only Python's standard library is used. Constants are explicitly supplied by
the authorized original or the complete authorized baseline. This script does
not retrieve data and does not independently establish empirical parameters.
"""
from pathlib import Path
import json
import math


def calculate():
    # Lecture PDF page 3: 138 days, approximate N_A = 6e23, 210 g/mol,
    # and stated emitted energy 5.3 MeV/decay. Baseline Physics: SI conversion.
    half_life_seconds = 138 * 24 * 60**2
    atoms_per_gram = 6e23 / 210
    decay_constant = math.log(2) / half_life_seconds
    activity = atoms_per_gram * decay_constant
    joules_per_decay = 5.3e6 * 1.60e-19
    return {
        "scope": "Arithmetic from admitted premises; no external empirical validation",
        "half_life_seconds": half_life_seconds,
        "atoms_per_gram_using_lecture_NA": atoms_per_gram,
        "decay_constant_per_second": decay_constant,
        "initial_activity_Bq_per_gram": activity,
        "joules_per_decay_using_baseline_eV_conversion": joules_per_decay,
        "stated_emission_power_W_per_gram": activity * joules_per_decay,
        "curie_equivalence": {
            "lecture_approximate_curies_per_gram": 4500,
            "factor_implied_by_lecture_values_Bq_per_curie": activity / 4500,
            "independently_verified_unit_definition": False,
            "reason": "A curie definition is not supplied in the admitted inputs.",
        },
        "gaussian_integral_sqrt_pi_over_2": math.sqrt(math.pi) / 2,
        "example7_derived_lower_bound": 3 / math.sqrt(2),
        "example7_derived_upper_bound": 3,
        "example8_correct_comparator_integral_from_1": math.exp(-1),
        "example8_comparator_integral_from_0": 1,
        "example8_full_target_derived_upper_bound": 1 + math.exp(-1),
        "example10_comparator_integral_exp_minus_x_over_2_from_0": 2,
        "example10_integer_values_from_proved_recurrence": {
            str(n): math.factorial(n) for n in range(7)
        },
        "endpoint_sqrt_integral": 2,
        "checks": {
            "source_activity_rounds_to_1_66e14": round(activity / 1e14, 2) == 1.66,
            "source_power_140_appropriate_to_two_significant_figures": round(activity * joules_per_decay, -1) == 140,
            "example8_printed_equality_1_is_false": math.exp(-1) != 1,
        },
    }


if __name__ == "__main__":
    data = calculate()
    assert all(data["checks"].values())
    destination = Path(__file__).with_name("calculation-results.json")
    destination.write_text(json.dumps(data, indent=2) + "\n")
    print("Independent arithmetic checks complete.")
