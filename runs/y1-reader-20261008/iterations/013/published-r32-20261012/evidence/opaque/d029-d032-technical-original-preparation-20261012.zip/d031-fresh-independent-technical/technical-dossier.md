# D031 — independent original-only technical dossier

Status: source-only work frozen before admission of PROF, final assessment prompts, or any new teaching document. This is an independent analysis of the authorized original and full four-subject baseline. It is not an assessment of a future teaching document and is not a teaching-acceptance claim. Findings are to remain withheld from the future author until the whole new teaching document has been frozen.

## 1. Identity, scope, and evidence limits

The original is MIT 18.01, Fall 2006, Lecture 35, **Improper Integrals**, stable ID `mit-18-01-fall-2006-L35`, material D031. The authorized PDF has 7 physical pages: a cover followed by printed lecture pages 1–6. Its 863826 bytes have SHA256 `526d15e1609795621993060e3981ba7ad7625a6188087d40b2ec9bd09827a2bc`. All seven page texts and all seven whole-page PNGs were read. The PDF itself was byte-hashed and its seven-page count was independently obtained with `pdfinfo`. All supplied derivative hashes match the identity file. That file's provenance URLs and cache paths were not followed.

The entire authorized four-subject baseline was read, not merely searched for relevant topics. Its 247840 bytes have SHA256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. The exact bounded reading intervals, normalization convention, seam rereads, and hashes are in `read-access-record.json`. The model saw all 2561 normalized read units, including the full Chemistry reference footer. All source and baseline input hashes are in `input-manifest.json`.

No PROF, teaching document, final prompt, current or previous review, external source audit, other agent's output, queue, external original, ancestral cache, browser, network source, or GitHub write was used. There are no separately supplied exercises in this original beyond the ten numbered examples and the final unnumbered endpoint-power calculation. “From PS8” identifies a provenance reference, not admission of PS8 itself. No unseen PS8 question is claimed to have been solved.

The technical record distinguishes an algebraic verification from an empirical fact supplied by the lecture. The original's isotope parameters can be used as given inputs to check its arithmetic; this does not independently verify their empirical measurement. No external research was authorized at this stage.

## 2. Baseline premises actually available

The combined baseline already supplies finite-bound antiderivatives, the fundamental theorem under suitable continuity, substitution, integration by parts, powers, logarithms, exponentials, and principal inverse trigonometric functions. Further Mathematics FM28 explicitly supplies replacing an infinite endpoint by a finite cutoff, taking the limit, the tail power test for p > 1, and splitting at an interior singularity with separate one-sided limits. FM29 supplies the derivative and primitive of arctangent. Improper integration must therefore not be misclassified wholesale as absent prior knowledge.

FM27 supplies the real exponential Maclaurin series. This permits an explicit polynomial-versus-exponential proof without importing L'Hôpital's rule; no L'Hôpital theorem is supplied anywhere in the full baseline. FM42 supplies density normalization and FM44 the normal density, which together yield an independent baseline-supported evaluation of the Gaussian integral. FM30 supplies disk/washer volumes, but does not supply a general cylindrical-shell method. The source's reference to a previously completed volume calculation is not a visible derivation in this packet.

Physics supplies expected radioactive activity A = λN, exponential survival/activity, half-life ln(2)/λ, Bq, the eV-to-joule conversion, day-to-second conversion, power as energy per time, and conditional explanations of alpha penetration and internal exposure. Chemistry supplies N = nN_A and n = m/M, as well as the first-order half-life relation with explicit rate conventions. The baseline provides N_A ≈ 6.02 × 10^23 mol^-1; the lecture deliberately uses the coarser 6 × 10^23. A curie definition, quantitative radiation weighting, an isotope-specific toxicity model, and thermal conditions sufficient to infer incandescence are not supplied.

The baseline's Statistics, Mechanics, remaining Physics, and complete Chemistry sections were also read. They do not add an unmentioned L'Hôpital rule, special-function theory, Gaussian non-elementarity theorem, or the missing physical conversions/model assumptions above. Their formulas are not silently replaced by an external memory corpus.

## 3. Definitions and comparison principles

For a function integrable on each finite interval [a,M], the right-tail integral is

\[
\int_a^\infty f(x)\,dx=\lim_{M\to\infty}\int_a^M f(x)\,dx.
\]

“Converges” requires a **finite real limit**. The source's opening “limit exists” is to be read in this finite sense: later it explicitly calls a limit of +∞ divergent. A lower endpoint singularity is a separate improper endpoint and cannot be hidden inside the finite-bound integral. Infinity is a limiting direction, not a real number to substitute into an antiderivative. The source labels its `e^{-k∞}` calculation informal; it is valid shorthand only after the preceding limit has been justified.

For locally integrable functions satisfying 0 ≤ f(x) ≤ g(x) on [a,∞), finite-cutoff order gives F(M) ≤ G(M), where each accumulated area is nondecreasing. If G has a finite limiting area, F is nondecreasing and bounded by that finite area, so F has a finite limit. If F grows without bound, G does also. The monotone bounded accumulation step is the content that makes the area intuition a convergence argument; a fully formal treatment would explain the real-number completeness step. Neither a divergent upper bound nor a convergent lower bound decides the target's behavior. Nonnegativity is substantive: f = -1 ≤ g = 0 would invalidate the convergence implication if signs were omitted. The correct area relation is non-strict ≤; equality is possible.

It is sufficient for a comparison to hold beyond a finite A, provided the omitted part of the target integral is finite. Finite interval length by itself is insufficient: the integrand must have the required finite integral there. In the lecture's Examples 7 and 8 this follows from continuity and boundedness on [0,1].

The printed “limit comparison” statement needs an eventually positive denominator g, local integrability, and an existing finite ratio limit. As literally printed, f = 1 and g = -1 satisfy f ≥ 0 and lim(f/g) = -1 ≤ 1 but do not satisfy f ≤ 2g. With g > 0 eventually and 0 ≤ L = lim(f/g) ≤ 1, choose a sufficiently late A so f/g < 2, giving f ≤ 2g. This is an upper comparison. It does not prove divergence of f from divergence of g when L = 0.

For the two-way test, require 0 < L < ∞. Beyond some A,

\[
\frac L2 g(x)\le f(x)\le\frac{3L}{2}g(x),
\]

so both positive tails have the same convergence classification. Example 9 has L = 1 and needs the lower comparison (or a direct lower bound); the preceding printed upper-bound-only statement does not by itself justify that example. Example 10 legitimately uses an upper comparison with ratio tending to zero.

## 4. Independent solutions and checks

### Example 1 — exponential tail and finite-cutoff approximation (PDF 2)

For k > 0 and M ≥ 0,

\[
\int_0^M e^{-kx}\,dx=\left[-\frac1k e^{-kx}\right]_0^M
=\frac{1-e^{-kM}}k \longrightarrow \frac1k.
\]

The formula and convergence are correct. The excluded cases matter: k = 0 gives integral M → +∞; k < 0 gives an exponentially growing positive integrand and divergence. The infinite value overestimates the finite integral by exactly e^{-kM}/k. Its error relative to 1/k is e^{-kM}; relative to the finite integral it is e^{-kM}/(1-e^{-kM}). “Large M” means kM is sufficiently large. For error at most ε relative to 1/k, with 0 < ε < 1, M ≥ ln(1/ε)/k suffices. There is no k-independent justification for dropping the exponential simply because M looks numerically large.

### Radioactive-decay application (PDF 2–3)

Let R be the **initial expected parent-nucleus activity**, and assume one fixed positive decay constant k, a closed initial population, and no replenishment. Then R(t) = R e^{-kt}, and the total expected number of original parent decays over all time is

\[
N=\int_0^\infty R e^{-kt}\,dt=R/k.
\]

The half-life relation e^{-kH} = 1/2 gives k = ln(2)/H and R = Nk = N ln(2)/H. Units are k in s^-1, H in s, R in decays/s (Bq), and N an atom count. The population tends to zero as t → ∞; the smooth exponential population model does not reach zero at a finite time. A daughter-decay chain is not included merely by integrating the parent activity.

Using the lecture's stated inputs, independently computed:

\[
H=138(24)(60)^2=11\,923\,200\ {\rm s},\qquad
N=\frac{6\times10^{23}}{210}=2.857142857\times10^{21}\ {\rm atoms/g},
\]

\[
k=5.813432472\times10^{-8}\ {\rm s^{-1}},\qquad
R=1.660980706\times10^{14}\ {\rm Bq/g}.
\]

This confirms the intended activity magnitude. The extracted text collapses the scientific notation; the numerical result must be written clearly as approximately 1.66 × 10^14 decays/s for one gram, not read as the decimal `1.661014`.

Using the baseline's 1 eV = 1.60 × 10^-19 J, a stated 5.3 MeV per decay is 8.48 × 10^-13 J per decay. Multiplying by the activity gives **140.851 W/g**, consistent with the source's approximately 140 W/g at its precision. This is the stated emitted energy rate; the amount actually deposited in a chosen body depends on absorption and geometry.

The source's approximately 4500-curie equivalence cannot be independently checked as a unit conversion from admitted premises: the curie definition is absent. Its own numbers imply approximately 3.6911 × 10^10 decays/s per curie, but inferring this ratio from the claimed equivalence does not independently establish the conversion. The phrase “white hot” does not follow from power alone; surface area, heat loss, material and thermal conditions are missing. Alpha particles' relatively low penetration and high ionisation/internal exposure relevance are supported qualitatively by the Physics baseline, subject to energy and material. The universal-sounding “20 times more dangerous” and the stated ingested lethal-mass estimate lack a defined dose/outcome model and supporting data in this packet. They remain source-supplied, externally unverified empirical assertions, not consequences of the integral or approved quantitative teaching premises.

### Example 2 — arctangent (PDF 3; Figure 2 continues on PDF 4)

For M ≥ 0,

\[
\int_0^M\frac{dx}{1+x^2}=\arctan M-\arctan0=\arctan M\to\pi/2.
\]

The integrand is continuous on the whole real line; only the upper endpoint is improper. The principal arctangent has range (-π/2,π/2), and the limit approaches π/2 from below. This is correct; arctangent is not the reciprocal of tangent.

### Example 3 — Gaussian (PDF 4)

A tail convergence proof from the lecture's comparisons is immediate: on x ≥ 1, x² ≥ x, so 0 < e^{-x²} ≤ e^{-x}; the [0,1] integral is finite. To evaluate it independently using the actual baseline, choose the supplied normal density with μ = 0 and σ² = 1/2. That density is e^{-x²}/√π, integrates to 1 by FM42, and is even. Therefore

\[
1=\frac2{\sqrt\pi}\int_0^\infty e^{-x^2}\,dx,
\qquad \int_0^\infty e^{-x^2}\,dx=\frac{\sqrt\pi}{2}\approx0.8862269255.
\]

This explicitly uses normal-density normalization as a baseline premise; it is not claimed to reconstruct the lecture's unprovided earlier shell/slice proof. No earlier lecture was accessed.

The assertion that there is no elementary formula for the general finite-cutoff antiderivative is not proved in the original or baseline, and a proof of non-elementarity has not been manufactured here. The phrase “can only [be] evaluated numerically” is too absolute if taken beyond elementary closed forms. A precise exact alternative can be derived from FM27. For finite M ≥ 0,

\[
\int_0^M e^{-x^2}\,dx
=\sum_{j=0}^\infty\frac{(-1)^jM^{2j+1}}{(2j+1)j!}.
\]

The passage to the limit can be justified explicitly rather than assuming a general termwise-integration theorem: the absolute pointwise series remainder on [0,M] is at most \(\sum_{j>N} M^{2j}/j!\), which tends to zero by the supplied convergent exponential series at M². The difference of the integrals is then at most M times that bound. Thus finite-cutoff values admit an exact convergent series, though ordinary numerical evaluation generally truncates it. M = 0 is a trivial finite exception to any blanket claim about finite values being “harder.” The finite/infinite comparison is an illustrative observation, not a universal theorem of relative difficulty.

### Examples 4–6 — the tail power test (PDF 4–5)

For p = 1,

\[
\int_1^M\frac{dx}{x}=\ln M\to+\infty.
\]

For p ≠ 1,

\[
\int_1^M x^{-p}\,dx=\frac{M^{1-p}-1}{1-p}.
\]

If p > 1, M^{1-p} → 0 and the value is 1/(p-1). If 0 < p < 1, the power grows without bound and the integral diverges to +∞. All printed formulas are correct. The same calculation extends the divergent range to **all real p ≤ 1**, including p = 0 and negative p; the source's summary only addresses its explicitly considered p > 0 range and is not a contradiction. The p = 1 boundary needs the logarithm and cannot be inserted into the p ≠ 1 formula.

### Example 7 — bounded origin, integrable tail (PDF 6)

Let f(x) = 1/√(x³+1) on x ≥ 0. It is positive, continuous, and at most 1 on [0,1], so that part is finite. On x ≥ 1,

\[
0<f(x)\le x^{-3/2},\qquad
\int_1^\infty x^{-3/2}\,dx=2.
\]

Therefore the target converges and is at most 3. A useful independent two-sided check is 1/√2 ≤ f ≤ 1 on [0,1] and x^{-3/2}/√2 ≤ f ≤ x^{-3/2} on [1,∞), giving

\[
3/\sqrt2\le\int_0^\infty\frac{dx}{\sqrt{x^3+1}}\le3.
\]

The attempted comparator over (0,∞) does diverge at zero:

\[
\int_a^1 x^{-3/2}\,dx=2(a^{-1/2}-1)\to+\infty.
\]

Its divergence supplies no conclusion about the smaller target. The source correctly repairs the argument by splitting the domain. Merely observing an integrand tends to infinity at zero does not prove divergence; the final 1/√x example itself is a counterexample to that shortcut.

### Example 8 — cubic exponential (PDF 6)

On [0,1], 0 < e^{-x³} ≤ 1, so the finite piece is bounded by 1. For x ≥ 1, x³ ≥ x implies e^{-x³} ≤ e^{-x}. Consequently

\[
\int_1^\infty e^{-x^3}\,dx\le\int_1^\infty e^{-x}\,dx
=e^{-1},
\]

and the full target converges, with upper bound 1+e^-1. **The original prints the last comparator integral as 1; its correct value is e^-1.** The value 1 belongs to the interval [0,∞). Replacing the incorrect equality by either `= e^-1 < ∞` or `≤ 1 < ∞` preserves the intended convergence proof. Both the whole-page image and text contain the incorrect lower-limit/equality combination; this is not an OCR-only error.

### Example 9 — divergent rational tail (PDF 6)

For f(x) = (x+10)/(x²+1), continuity on [0,1] is clear. On x ≥ 1,

\[
f(x)-\frac1x=\frac{10x-1}{x(x^2+1)}\ge0.
\]

The harmonic tail is therefore a divergent lower comparator, proving divergence. The stated limiting behavior can be made exact:

\[
\frac{f(x)}{1/x}=\frac{x^2+10x}{x^2+1}
=\frac{1+10/x}{1+1/x^2}\to1.
\]

A second independent check evaluates the finite cutoff:

\[
\int_0^M f(x)\,dx=\tfrac12\ln(1+M^2)+10\arctan M\to+\infty.
\]

The source's differential `dx` on only the left side of its asymptotic line is imprecise notation: compare the functions f(x) and 1/x, or consistently compare integrands. Its conclusion is correct once the required lower comparison is supplied.

### Example 10 — polynomial times exponential (PDF 7)

The original does not state the domain of n. For a fixed **nonnegative integer** n, the entire integral converges. On [0,1], x^n e^-x is bounded. For x > 0, FM27 gives

\[
e^{x/2}\ge\frac{(x/2)^{n+1}}{(n+1)!},\qquad
0\le\frac{x^n}{e^{x/2}}\le\frac{2^{n+1}(n+1)!}{x}\to0.
\]

Thus beyond some finite A, x^n e^-x ≤ e^{-x/2}. The latter has tail 2e^{-A/2}, hence the former is integrable. This supplies the missing growth-rate reasoning without L'Hôpital's rule. The source's notation `<<` can be explained here as a ratio tending to zero; it is not an unqualified inequality at every x.

The weaker direct observation x^n/e^x → 0 only says the integrand tends to zero and does not by itself prove its integral converges: 1/x tends to zero but has a divergent tail. Saving half the exponential produces an integrable bound.

For completeness, the integral can be fully evaluated for nonnegative integers using the available integration-by-parts rule. Let I_n(M) = ∫_0^M x^n e^-x dx. Then I_0(M) = 1-e^-M, and for n ≥ 1,

\[
I_n(M)=-M^n e^{-M}+n I_{n-1}(M).
\]

The boundary term tends to zero by the already proved exponential comparison. Therefore I_0 = 1 and I_n = n I_{n-1}, giving **I_n = n!**. No unseen problem-set requirements are inferred from this additional solution.

If n is instead any fixed real number, the tail still converges: choose a positive integer m > n in the same exponential-series bound. But on (0,1], e^-1 x^n ≤ x^n e^-x ≤ x^n. The full integral converges **if and only if n > -1**. It diverges at zero for n ≤ -1. An unrestricted assertion for all real n would therefore be false. The factorial answer is asserted only for nonnegative integers; no Gamma function is imported.

### Unnumbered second-type example and full endpoint power test (PDF 7)

For a > 0,

\[
\int_a^1 x^{-1/2}\,dx=2-2\sqrt a\to2\quad(a\to0^+).
\]

The positive-side limit is essential for this real square root. More generally, for real p ≠ 1,

\[
\int_a^1 x^{-p}\,dx=\frac{1-a^{1-p}}{1-p}.
\]

If p < 1, this tends to 1/(1-p); for p > 1 it tends to +∞. If p = 1, the separate logarithmic expression -ln a tends to +∞. The source's values, conditions, and p = 1/2 substitution are correct. For p ≤ 0 the integrand can be given a continuous finite endpoint value, so this formula includes proper or removable-endpoint cases as well as genuinely singular integrands. On x > 0 all real powers in the calculation are defined.

Combining the two independently checked tests: a pure power x^-p is integrable at infinity exactly when p > 1, and at zero exactly when p < 1. Thus no real p makes ∫_0^∞ x^-p dx converge. This consequence explains why domain splitting, rather than a single global power comparator, was necessary in Example 7.

## 5. Whole-page visual and figure checks

**PDF 1:** MIT OpenCourseWare cover, course 18.01, Fall 2006, citation/terms notice. It contains no assessment mathematics or hidden exercise. Read in full.

**Figure 1, PDF 3:** the tangent principal branch is drawn between vertical guides x = -π/2 and x = π/2. The curve increases through the origin. The marked point has coordinates (θ,M), horizontal dotted guide at M and vertical dotted guide at θ. Hence M = tan θ, with 0 < θ < π/2 for the displayed positive M; increasing M sends θ toward π/2 from the left. Axis orientation, guides, signs, asymptote labels and caption are consistent. The drawing is qualitative, not a scale from which numerical values should be read.

**Figure 2, PDF 4:** the inverse curve increases through the origin with horizontal asymptotes y = ±π/2. The marked point is (M,θ), with θ = arctan M and θ below the positive horizontal asymptote. The vertical label y = arctan(x) and horizontal label x = tan(y) describe the mutually inverse relationship. Interchanging the coordinates from Figure 1 is correct. The curve does not attain ±π/2 at finite x.

**Figure 3, PDF 5:** the vertical x = a guide identifies the start of the tail. The red g arrow points to the upper positive curve and the green f arrow to the lower positive curve. Their order agrees with 0 ≤ f ≤ g on the illustrated tail. No shaded numerical area or convergence rate is specified. The sketch alone does not establish that either area is finite; it illustrates order, and the convergence/divergence premise must come from elsewhere. Caption “less than” should be understood as “no greater than” in the general non-strict theorem.

**PDF 2, 6, 7:** all equations, bounds, signs, roots, exponents, example numbering and page footers were read visually. In particular, the Example 8 `1` at the end of a comparator whose lower bound is visibly `1` is confirmed in the page image; the Example 10 exponent is n and its n-domain is not displayed; the final cutoff is a → 0^+. These are physical-page observations, not assumptions from reordered extraction text.

## 6. Sealed source-only findings

1. The main integral answers and classifications are correct under their stated or explicitly repaired hypotheses.
2. A concrete arithmetic error appears in Example 8: ∫_1^∞ e^-x dx = e^-1, not 1. Its convergence conclusion survives.
3. The printed limit-comparison statement omits eventual positivity of g and local integrability, and supplies only an upper direction. Example 9 additionally needs a positive-limit lower bound or the direct inequality proved above.
4. Example 10 needs n declared. Nonnegative integer n gives convergence and value n!; arbitrary real n requires n > -1 for convergence of the complete interval. The tail alone converges for every fixed real n.
5. L'Hôpital is invoked without being supplied in either admitted source or full baseline. The exponential-series inequality above is a fully explicit baseline-supported replacement.
6. “Convergent” requires a finite limit; an omitted finite interval must itself be integrable; an integrand tending to infinity at an endpoint does not alone determine divergence; a vanishing tail integrand does not alone prove convergence.
7. The Gaussian value is independently recoverable from supplied normal-density premises. The earlier volume calculation is absent, non-elementarity is not proved by these inputs, and the absolute numerical-only wording needs qualification.
8. The isotope activity and stated-energy-rate arithmetic are internally consistent. Curie conversion and strong empirical thermal/biological claims are not independently established by authorized inputs. Mathematical checking must not silently promote them into verified empirical conclusions.

These are source-only findings. They have not been compared with final prompts or any whole frozen new teaching. Subsequent admission must happen in the ordered stages specified by the parent: current published full PROF first, then final-prompt-only independent solving and sealing, then the complete frozen new teaching. This dossier must not be treated as evidence that any of those later stages occurred.
