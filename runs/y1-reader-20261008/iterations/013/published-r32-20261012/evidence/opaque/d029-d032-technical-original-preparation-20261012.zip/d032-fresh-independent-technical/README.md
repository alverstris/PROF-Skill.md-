# D032 technical examination — sealed Phase A

Original-only examination of MIT 18.01 Lecture 36, “Infinite Series and Convergence Tests.”

The full four-subject baseline and all eight original page texts and whole-page PNGs, including the cover, were read. Source calculations, hypotheses, domains and figures were independently examined. Unsupported historical/theorem or empirical remarks are explicitly classified rather than certified.

Contents:

- `technical-dossier.md`: complete source-only findings, derivations and baseline boundaries.
- `coverage.json`: 28 source items, all seven figures and all eight pages.
- `input-manifest.json`: authorized-input byte counts, hashes and integrity comparisons.
- `access-ledger.json`: actual bounded baseline reads, repaired truncation, original text/image access and exclusions.
- `arithmetic-check.py` and `arithmetic-results.json`: reproducible finite calculations and integral-bound certificate.
- `phase-a-seal.json`: phase boundary, file hashes and freeze record.

No current teaching acceptance claim is made. No PROF, final prompt, teaching, review, source audit, other agent's findings or outside subject input was admitted. Keep these findings withheld from the future author until the entire new teaching freezes. Root must separately authorize the current full PROF and then a final-prompt-only solve-and-seal phase before frozen teaching is examined. Preserve Phase A unchanged in later work.
