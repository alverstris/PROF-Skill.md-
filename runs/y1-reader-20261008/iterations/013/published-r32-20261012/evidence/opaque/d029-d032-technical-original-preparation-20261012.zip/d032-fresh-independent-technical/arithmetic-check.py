"""Reproduce D032 source-only arithmetic. No file or network reference inputs.

All mathematical bounds are derived in technical-dossier.md. The only
computations here are finite sums, fractions, decimal arithmetic, logs, and
exponentials. This is an auditor calculation, not an additional learner premise.
"""
from decimal import Decimal, localcontext
from fractions import Fraction
import json


def run(precision=70):
    with localcontext() as ctx:
        ctx.prec = precision
        d = Decimal
        m = 1_000_000
        h_m = sum((d(1) / d(k) for k in range(1, m + 1)), d(0))

        def bounds(n):
            dn, dm = d(n), d(m)
            lower = h_m + (dn / dm).ln() - d(1)/(2*dm) + d(1)/(2*dn)
            upper = h_m + ((dn+d('0.5'))/(dm+d('0.5'))).ln()
            return lower, upper

        n0, n1 = 14_872_568_830, 14_872_568_831
        b0, b1 = bounds(n0), bounds(n1)
        allowance = d('1e-55')
        assert b0[1] + allowance < 24
        assert b1[0] - allowance > 24
        assert n1 == n0 + 1
        assert Fraction(25, 12) > 2 > Fraction(11, 6)
        assert Fraction(137, 60) > 2
        return {
            'precision_decimal_digits': precision,
            'external_reference_inputs': [],
            'harmonic_small_cases': {
                str(n): str(sum((Fraction(1, k) for k in range(1, n+1)), Fraction()))
                for n in range(1, 8)
            },
            'rough_logarithmic_counts_and_heights': {
                str(a): {
                    'exp_a': str(d(a).exp()),
                    'height_0_03_exp_a_metres': str(d('.03')*d(a).exp())
                } for a in (23, 24)
            },
            'finite_harmonic_anchor_index': m,
            'finite_harmonic_anchor_sum': str(h_m),
            'consecutive_candidate_bounds': {
                str(n0): {'lower': str(b0[0]), 'upper': str(b0[1])},
                str(n1): {'lower': str(b1[0]), 'upper': str(b1[1])},
            },
            'conservative_decimal_allowance': str(allowance),
            'minimum_index_with_harmonic_sum_at_least_24': n1,
            'physical_blocks_for_full_span_26_units': n1 + 1,
            'height_for_full_span_26_units_metres': str(d('.03')*(n1+1)),
            'conditional_metric_room_calculations': [
                {
                    'assumed_span_metres': str(length),
                    'target_half_block_units': str(length/d('.15')-2),
                    'source_style_log_height_metres': str(d('.03')*(length/d('.15')-2).exp()),
                }
                for length in (d('9'), d('9.144'), d('10'))
            ],
            'metric_length_implied_by_exact_1e26_log_height': str(
                d('.15')*((d('1e26')/d('.03')).ln()+2)
            ),
            'foot_conversion_factor_algebraically_implied_if_exactly_30_feet': str(
                ((d('1e26')/d('.03')).ln()+2)/200
            ),
            'foot_factor_status': 'Algebraic implication only; no actual foot conversion admitted.',
            'numerical_assertions_passed': True,
        }


if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
