# D032 — independent original-only technical dossier

Phase A: original-source mathematical examination. Prepared 12 October 2026.

This dossier examines MIT 18.01, Fall 2006, Lecture 36, “Infinite Series and Convergence Tests,” from the authorized eight-page `lec36.pdf`, its eight whole-page PNGs and eight texts, its supplied identity, and the entire authorized four-subject baseline. PDF page numbers below include the cover; printed lecture page numbers are one smaller. No teaching draft, final prompt, PROF, prior review, prior source audit, queue, ancestor directory, other agent's findings, browser, or network source was admitted. This is not a teaching acceptance decision. The sealed findings must remain unavailable to a future author until the full new teaching has frozen.

The original PDF is 1,421,492 bytes, SHA-256 `7d5e99897f7c24f895c46916b68e3e153699603e6db05f952bee999d95dcae5a`. The baseline is 247,840 bytes, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. Every supplied page derivative matches its identity hash. Full per-file metadata and actual reading records accompany this dossier.

## 1. Scope and disposition of every original mathematical item

| ID | Original location | Item | Independent disposition |
|---|---|---|---|
| C00 | PDF 1, cover | MIT OCW; course; Fall 2006; citation/terms notice | Whole page read; identity consistent with supplied packet. URLs recorded as provenance only, not followed. |
| C01 | PDF 2 | Geometric series and formal subtraction | Formula correct for real `abs(a)<1`; finite partial-sum proof supplied below. Subtracting unestablished infinite sums is not a proof of convergence. |
| C02 | PDF 2–3 | `a=1`, `a=-1`; invalid infinity subtraction | Correct divergence warnings; `a=-1` has partial sums 1,0,1,0, and has no ordinary sum 1/2. All other real parameter cases checked below. |
| C03 | PDF 2–3 | Infinite series, partial sum, finite-limit definition | Correct. The source's `S_n=sum_(k=0)^n a_k` has `n+1` terms. The later harmonic sum starts at 1 and has `N` terms. These are separate conventions. |
| C04 | PDF 3, 5 | Replacing a p-series by an improper integral | Correct convergence equivalence after stating positivity, monotonicity and local integrability, and applying inequalities to finite quantities. Not an equality of values. |
| C05 | PDF 3 | `sum 1/n^2=pi^2/6` | Independently derivable; a finite trigonometric-product proof and limit justification are given in §4. Integral comparison alone does not give this value. |
| C06 | PDF 3 | `sum 1/n^3` is irrational; “only recently” | Convergence independently verified (`p=3`). Irrationality and the historical recency assertion are unproved source remarks: no allowed-input proof or dating evidence is supplied, and none was imported. They are not established by the convergence tests. |
| C07 | PDF 3–4, Figure 1 | Harmonic upper rectangles | Correct intervals, heights and inequality; produces a lower bound on the harmonic sum from an upper bound on the integral. |
| C08 | PDF 4, Figure 2 | Harmonic lower rectangles | Correct; bounds `H_N-1` above by `ln N`. |
| C09 | PDF 4, 8 | `ln N < H_N < 1+ln N` | Correct for integer `N>=2`. At `N=1`, the upper inequality is equality. Use `H_N<=1+ln N` for all `N>=1`. |
| C10 | PDF 5 | Absolute difference of infinite sum and integral is less than `f(1)` | As printed, undefined when both diverge. Must be formulated with finite sums/integrals before taking limits. Non-strict versus strict monotonicity also affects the displayed strict bound. |
| C11 | PDF 5 | p-series criterion for all p | Correct for real p, with a separate argument for `p<=0`, because `x^(-p)` is not decreasing then. The integral criterion applies directly for `p>0`. |
| C12 | PDF 5 | Limit-comparison theorem | Valid for eventually positive terms with a ratio tending to a finite positive constant. This positivity condition must remain explicit. A signed-series counterexample is given below. |
| C13 | PDF 3, 5 | Meaning of `~` | Source-specific notation: a ratio tending to *any* `c` with `0<c<infinity`, and informal convergence correspondence between a sum and an integral. These uses must not be confused with equality or an approximation giving a sum. |
| C14 | PDF 5 | `sum 1/sqrt(n^2+10)` | Diverges; all real terms defined and positive for integer `n>=1`; ratio tends to 1. Direct comparison also supplied. |
| C15 | PDF 5 | `sum_(n=1)^infinity n/sqrt(n^5-10)` | Not a defined real series as printed: at `n=1` the denominator is `sqrt(-9)`. The explicitly corrected tail starting at `n=2` converges. Ignoring an undefined term is not the finite-prefix principle. |
| C16 | PDF 6, Figure 3 | Can such a stack be built? | Yes under an ideal uniform-block model and correct offsets. Figure 3 is schematic and cannot be taken as a scale-valid equilibrium diagram; literal equal-mass geometry is checked in §6. |
| C17 | PDF 6 | Top-down placement; support beneath aggregate centre of mass | Correct for the stated one-block-per-level staircase model, with a limiting placement at an edge. Uniform mass, horizontal rigid blocks, vertical uniform gravity and contact equilibrium are needed. Edge placement is marginal, not robust. |
| C18 | PDF 7–8, Figures 4–6 | COM recurrence | Correct: `C_(n+1)=[n C_n+(C_n+1)]/(n+1)=C_n+1/(n+1)` in half-block-length units. The old aggregate has mass n, the new block mass 1. |
| C19 | PDF 7 | `C_0,...,C_5` | `0,1,3/2,11/6,25/12,137/60`; source expressions correct. Already `C_4>2`; the printed `C_5>2` is true but does not identify a first crossing. |
| C20 | PDF 7 | Points in Figures 4 and 5 | `C_2` and `C_3` are aggregate COM coordinates, not the geometric centres of blocks 2 and 3. The drawn segment ratios agree approximately with `1,1/2,1/3`. |
| C21 | PDF 8 | Arbitrarily large horizontal extent | Correct in the ideal model because the harmonic sums diverge. Distinguish aggregate COM `C_N`, bottom left end `C_(N-1)`, total span `2+C_(N-1)`, and support-edge overhang. |
| C22 | PDF 8, Figure 7 | 30 cm × 3 cm; 6.5 blocks/table; 13 units/table | Correct: length 2 units makes 1 unit 15 cm. A table is 195 cm; two are 390 cm or 26 units. Figure 7 labels length and thickness consistently. |
| C23 | PDF 8 | `26-2=24` units of overhang | Arithmetic correct. For *total end-to-end span*, `N` physical blocks require `H_(N-1)>=24`; if `H_M` counts increments, there are `M+1` blocks. The source suppresses this one-block distinction. Table/support geometry otherwise is not drawn. |
| C24 | PDF 8 | `ln N=24`; height about `8×10^8 m` | Arithmetic correct as a sufficient logarithmic estimate: `0.03 e^24=7.946736638953...×10^8 m`. It is not the minimum required height or the equation `H_N=24`. Rigorous bounds and an independent minimum-count certificate are in §7. |
| C25 | PDF 8 | About twice the Moon distance | No Moon distance is supplied in the authorized baseline or source. The comparison is a source assertion, not independently certified here. The physical height calculation itself is certified. |
| C26 | PDF 8 | Room about 30 ft; height `10^26 m` | No exact foot-to-metre conversion or precise room span is supplied. The exponential sensitivity makes this unsuitable as a precise required height. Conditional metric-span calculations are given; none silently admits an external conversion. |
| C27 | PDF 8 | About the observable-universe diameter | No diameter data or cosmological derivation is supplied by the allowed inputs. Classified as an unverified source scale analogy, not a result of the series calculation. |

There is no separate numbered exercise sheet in this packet. The convergence question on PDF 5, all geometric/harmonic/p-series calculations, the stacking feasibility questions, the recurrence and displayed small cases, and the two scale calculations are all covered. Historical or astronomical assertions are explicitly distinguished from solved mathematics; their status is not concealed by the term “checked.”

## 2. Geometric series and the definition of an infinite sum

For a real parameter a, use the finite polynomial

`S_N=1+a+...+a^N`, with integer `N>=0`.

Multiplication and finite subtraction give

`(1-a)S_N=1-a^(N+1)`.

For `a!=1`, `S_N=(1-a^(N+1))/(1-a)`. For `a=1`, `S_N=N+1`. The limit is therefore `1/(1-a)` when `|a|<1`. The exact omitted tail is `a^(N+1)/(1-a)` once convergence has been established. This proves existence as well as finding the putative value; the source's infinite subtraction only identifies a possible value if the operations are already legitimate.

All real cases:

| Parameter | Partial-sum behaviour | Ordinary infinite series |
|---|---|---|
| `-1<a<1` | `a^(N+1)->0`; finite limit `1/(1-a)` | Convergent |
| `a=1` | `S_N=N+1->+infinity` | Divergent |
| `a=-1` | `S_(2m)=1`, `S_(2m+1)=0` | Divergent by distinct subsequences |
| `a>1` | Positive terms grow; partial sums unbounded | Divergent |
| `a<-1` | Terms do not tend to zero; partial sums alternate with unbounded magnitude | Divergent |

At `a=0`, the polynomial convention has the constant term 1 and all later terms zero, so the sum is 1. No undefined `0^0` need be introduced: the constant polynomial term is specified as 1.

For a general series, convergence is precisely convergence of its finite partial sums to a finite number. If `S_N->s`, then `a_N=S_N-S_(N-1)->0`. Thus a term failing to approach zero disproves convergence; terms approaching zero do not establish convergence (the harmonic series below is a counterexample). Writing a divergent positive series as `infinity` records unbounded partial sums and does not make infinity an ordinary real number that can be subtracted.

The baseline supplies finite/infinite geometric sums, real limit language and elementary algebra (lines 128–174), so this argument does not require a newly assumed general convergence test. The source's new central organization is the explicit definition by partial sums.

## 3. Integral comparison, harmonic bounds and all p-values

### 3.1 Finite inequalities first

Let f be positive and nonincreasing on `[1,infinity)`, finite at 1, and integrable on every finite subinterval. Continuity is a familiar sufficient hypothesis; monotone finite functions also suffice. For integer `n>=1` and `x` in `[n,n+1]`,

`f(n+1)<=f(x)<=f(n)`.

Integrate over that unit interval and add. With `A_N=sum_(n=1)^N f(n)`,

`integral_1^(N+1) f(x) dx <= A_N <= f(1)+integral_1^N f(x) dx`.

An equivalent finite-difference bound for `N>=1` is

`f(N) <= A_N-integral_1^N f(x) dx <= f(1)`.

These inequalities remain meaningful even when the limiting sum and integral diverge. The source's literal subtraction of two infinite divergent quantities does not. If f is strictly decreasing, the displayed finite inequalities sharpen where a nonempty interval is involved; at `N=1`, the difference is exactly `f(1)`. A constant positive function is a simple counterexample to a universally strict finite bound under a merely nonincreasing interpretation.

Because all terms and integrands are nonnegative, `A_N` and the accumulated integrals are nondecreasing. If the integral has a finite limit, the upper inequality bounds `A_N`; the monotone-bounded convergence property yields a finite limit. If the sum has a finite limit, the lower inequality bounds the increasing integrals and yields their finite limit. Conversely, if either is unbounded the inequalities force the other to be unbounded. Thus convergence is equivalent, but values need not be equal.

The monotone-bounded convergence property is an actual analytical bridge in this proof. It is not explicitly a named operational theorem in the supplied baseline; if a later document relies on it, it must supply it or otherwise justify the passage from a bounded positive sum to convergence. The baseline does provide finite endpoint rectangle bounds (line 434), integrals as limits and the fundamental theorem (line 336), and improper-integral definitions (FM28, line 733).

Finite changes to *defined, finite* starting terms cannot change convergence: after the finite prefix, two partial sums differ by a fixed finite constant. Likewise, an eventual version of the hypotheses works by starting at an integer M and treating the prefix separately. This principle does not turn an undefined original term into a legitimate real number.

### 3.2 Harmonic series and the two figures

Write `H_N=sum_(n=1)^N 1/n`.

Figure 1 draws width-1 left-endpoint rectangles over `[1,2]`, `[2,3]`, `[3,4]`, of heights `1,1/2,1/3`. The curve `1/x` decreases and lies below each rectangle. Consequently, for `N>=2`,

`ln N=integral_1^N dx/x < H_(N-1) < H_N`.

Figure 2 draws the corresponding right-endpoint rectangles of heights `1/2,1/3,1/4`, lying below the curve. Thus

`H_N-1 < integral_1^N dx/x = ln N` for `N>=2`.

Combine to obtain `ln N < H_N < 1+ln N` for `N>=2`. At `N=1`, `ln 1=0<H_1=1=1+ln 1`. The weaker upper inequality is valid for all positive integer N. Because `ln N` grows without bound, so does `H_N`. Because the additive discrepancy lies between 0 and 1, `H_N/ln N ->1` as `N->infinity` (take `N>1`). This establishes slow logarithmic growth; it does not require a memorised Euler constant.

These are comparisons of area with a width-1 sum. They are not a computation of an improper integral by shrinking-mesh Riemann sums. The integral is evaluated by its logarithmic antiderivative, and fixed-width rectangles transfer the divergence to a series.

### 3.3 Complete p-series decision

For real p and `R>1`,

`integral_1^R x^(-p) dx = (R^(1-p)-1)/(1-p)` if `p!=1`,

and it is `ln R` if `p=1`.

For `p>1`, `R^(1-p)->0`, giving the finite integral `1/(p-1)`. Since `x^(-p)>0` and decreases on `[1,infinity)`, the p-series converges. For `0<p<1`, the primitive tends to positive infinity, so the series diverges. At `p=1` the harmonic proof applies. For `p<=0`, each term `n^(-p)>=1`, hence the partial sum is at least N and diverges without applying a decreasing-function test incorrectly. Therefore `sum_(n=1)^infinity n^(-p)` converges exactly when `p>1`.

In particular, the positive `p=2` and `p=3` series converge. Their integral values are respectively 1 and 1/2; those are not their series sums. Integral comparison gives, for p>1, `1/(p-1) <= sum n^(-p) <= 1+1/(p-1)`; with strictly decreasing positive functions the inequalities can be sharpened, but no exact value follows from them alone.

## 4. Independent verification of the Basel value; limit of the irrationality remark

The exact `p=2` value on PDF 3 can be obtained without importing a Fourier theorem or an external answer. The following is a self-contained finite-algebra route using baseline trigonometry, complex roots of unity (FM08), real differentiation and sine's real Maclaurin expansion (FM27), plus the already proved convergence of the p=2 series.

For integer `m>=2`, factor `z^m-1` over its m roots of unity and substitute `z=exp(2ix)`. Writing each sine in exponential form gives the finite identity

`sin(mx)=2^(m-1) product_(k=0)^(m-1) sin(x+k*pi/m)`.

The constant and sign follow directly from the leading coefficient: `product_(k=0)^(m-1)(z exp(2*pi*i*k/m)-1)=(-1)^(m-1)(z^m-1)`. Thus this is finite complex-number algebra, not a use of complex analysis or an infinite product. For real x avoiding the zeros, take a logarithmic derivative (of absolute values if needed), then differentiate once more:

`sum_(k=0)^(m-1) cot(x+k*pi/m)=m cot(mx)`,

`sum_(k=0)^(m-1) csc^2(x+k*pi/m)=m^2 csc^2(mx)`.

Sine's supplied expansion gives `csc^2(x)=1/x^2+1/3+O(x^2)` near 0: square `sin x=x-x^3/6+O(x^5)` and invert. Subtract the `k=0` singular term and let x tend to zero. This produces the finite identity

`sum_(k=1)^(m-1) csc^2(k*pi/m)=(m^2-1)/3`.

Take odd `m=2q+1`, pair the terms k and m-k, and divide by m squared:

`2 sum_(k=1)^q [1/(m^2 sin^2(k*pi/m))]=(1-1/m^2)/3`.

For each fixed positive k, the bracket tends to `1/(pi^2 k^2)` by the small-angle limit. To justify passage from finite sums to the convergent series, note that sine is concave on `[0,pi/2]` and lies above its endpoint chord, so `sin t>=2t/pi`. Hence, for `k<=q`,

`0<1/(m^2 sin^2(k*pi/m))<=1/(4 k^2)`.

For a fixed K, the first K terms have the stated termwise limit. The remaining doubled tail is bounded above by `(1/2) sum_(k>K) 1/k^2 <=1/(2K)`, by the integral bound. This tends to zero uniformly in m as K grows. Thus the left side tends to `(2/pi^2) sum_(k=1)^infinity 1/k^2`, whereas the right side tends to 1/3. It follows that

`sum_(k=1)^infinity 1/k^2=pi^2/6`.

This proof verifies the displayed exact value but is much more substantial than the source's integral test, consistent with the source's warning. It is a technical verification, not a recommendation that this additional proof be required of a baseline learner.

For `sum 1/n^3`, convergence follows independently from §3. No irrationality proof is present in the supplied source or baseline, and the statement does not follow from that convergence result. This dossier does not import a remembered named theorem as an authorized premise or manufacture a verification of “recently.” The original remark is preserved with its unproved status. Resolving that distinct historical/theorem assertion would require an independently authorized proof or source; it is not necessary for any of the lecture's convergence-test exercises.

## 5. Limit comparison and the two source examples

### 5.1 Exact hypotheses and finite proof

Let `a_n,b_n` be positive for all sufficiently large integer n. Suppose `a_n/b_n -> c` where `0<c<infinity`. Eventually `c/2 < a_n/b_n < 3c/2`, so

`(c/2)b_n < a_n < (3c/2)b_n`.

Sum these inequalities over a finite tail. An upper convergent positive comparison bounds the increasing partial sums; a lower divergent positive comparison forces unboundedness. The two series therefore converge together or diverge together, with finite defined prefixes immaterial. No decreasing hypothesis is required for limit comparison; positivity replaces the sign difficulties. A limit 0 or infinity does not give this two-sided conclusion, though one-sided comparison can sometimes be used separately.

If a statement is made about functions f(x),g(x) and the real limit as `x->infinity`, eventually positive samples at integer n and the same ratio limit give the sequence result. Differentiability is not required by the test itself.

The positive-term requirement cannot be dropped. For `k>=1`, define

`a_(2k-1)=1/sqrt(k)`, `a_(2k)=-1/sqrt(k)`;

`b_(2k-1)=1/sqrt(k)+1/k`, `b_(2k)=-1/sqrt(k)`.

The a-series converges to 0: its even partial sums are 0 and its odd partial sums tend to 0. The b-series diverges to positive infinity because its even partial sums are `H_k` and its odd ones are larger. Nevertheless `b_n/a_n` tends to 1: it equals `1+1/sqrt(k)` on odd indices and 1 on even indices. This uses only the already proved harmonic divergence and elementary limits. It demonstrates why a bare ratio statement is insufficient for signed series.

The source defines `f~g` by a finite nonzero positive ratio, not necessarily ratio 1. A later use must explain that convention. The symbol between an infinite sum and an integral on PDF 3/5 is even looser: it denotes corresponding convergence behaviour, not an arithmetic quotient of two divergent quantities.

### 5.2 First source series

`a_n=1/sqrt(n^2+10)`, with integer `n>=1`, is real, finite and positive. Against `b_n=1/n`,

`a_n/b_n=n/sqrt(n^2+10)=1/sqrt(1+10/n^2)->1`.

The harmonic series diverges, so the source series diverges. A completely direct check is also available: for `n>=1`, `n^2+10<=11 n^2`, hence `a_n>=1/(sqrt(11)n)`. This lower bound has divergent partial sums. If monotonicity is desired for an integral method, `d/dx (x^2+10)^(-1/2)=-x/(x^2+10)^(3/2)<0` for `x>0`. There is no early-index exception here.

### 5.3 Second source series: original real-domain defect and solved tail

The original lower index is visibly `n=1` in both the full-page PNG and the page text. At that index, `n^5-10=-9`, so `n/sqrt(n^5-10)` is undefined as a real term. The original question has no real-series convergence classification until its definition is repaired. A finite-prefix invariance rule applies only after finite values have actually been specified.

The explicit real-tail repair is to start at `n=2`. For all such n, `n^5-10>0`. Compare with `b_n=n^(-3/2)`:

`[n/sqrt(n^5-10)] / n^(-3/2) = 1/sqrt(1-10/n^5)->1`.

The positive p=3/2 comparison converges, so the repaired tail converges. Independently, for `n>=2`, `10/n^5<=5/16`, giving

`n^(-3/2) <= n/sqrt(n^5-10) <= (4/sqrt(11)) n^(-3/2)`.

This gives a direct convergent majorant. The continuous real function is defined for `x>10^(1/5)` and decreases there, since

`d/dx [x/sqrt(x^5-10)] = [-(3/2)x^5-10]/(x^5-10)^(3/2) <0`.

A chosen complex square-root convention could assign a finite imaginary first term, but no such convention is supplied by this real-calculus question. It must not be silently inserted as if it were the printed real problem. No exact tail sum is requested or furnished by the convergence test.

## 6. Blocks: equilibrium, recurrence, coordinates and figures

### 6.1 Model and centre-of-mass derivation

Take identical uniform horizontal rigid blocks with length 2 in normalized units and equal mass 1. Gravity is vertical and uniform, and contacts can supply the required upward resultants within the overlap. The figure describes a single staircase with one block at each level. Set the left end of the top block to `C_0=0`; its centre is `C_1=1`. Place block 2 with left end `C_1`. Its own centre is 2, and the centre of mass of the top two blocks is `(1+2)/2=3/2=C_2`.

In general let `C_n` be the horizontal COM of the first n blocks. Add block `n+1` with its left end at `C_n`, so its own centre is `C_n+1`. The combined mass-weighted mean gives

`C_(n+1) = [n C_n + 1(C_n+1)]/(n+1) = C_n+1/(n+1)`.

The denominator counts all n+1 blocks. The term `C_n+1` in the numerator is an ordinary coordinate plus 1, not the subscripted aggregate `C_(n+1)`. Starting at `C_0=0`, induction yields `C_n=H_n` for `n>=1`. The zero-block “COM” is not physically defined: `C_0` was separately defined as the top left end, and serves as an initial coordinate, not the centre of mass of an empty system.

Exact values are `C_1=1`, `C_2=3/2`, `C_3=11/6`, `C_4=25/12`, `C_5=137/60`, `C_6=49/20`. The source's displayed expressions through `C_5` are correct. Since `C_3<2` and `C_4>2`, the first aggregate COM beyond the right end of the original top block is `C_4`. Five physical blocks are the first whose *bottom left end* lies strictly right of the top block's right end, because that endpoint is `C_4`.

The baseline supplies weighted centres of mass (FM63, line 807), the midpoint of a uniform rod (FM64, line 809), zero-resultant-force and zero-resultant-moment equilibrium and support-edge reasoning (FM65, line 811), and induction (FM01, line 679). The lecture adds the particular construction and the harmonic recurrence, not a wholly new general mechanics formalism.

The “as far right as possible” claim can also be checked within this staircase family. If `l_k` is block k's left end and `l_1=0`, support requires `l_(n+1)<=1+(l_1+...+l_n)/n`. The right-hand side increases in every earlier `l_k`. Inductively each `l_k` is at most its greedy value `H_(k-1)`, so `l_(n+1)<=H_n`; the displayed construction attains that bound. This proves the claimed extremal placement in this model. It makes no claim about configurations with multiple blocks per level or counterweights.

### 6.2 Support and stability

At each stage, the top n blocks' aggregate weight line is exactly at the left edge of the supporting block `n+1`. This is the limiting no-toppling placement under the model. It is marginal: an arbitrarily small outward shift or perturbation may cause tipping. The source's real demonstration can use slightly smaller offsets; ideal equality is not a practical tolerance guarantee.

Unbounded extent does not rely on choosing marginal equality. For any fixed `0<alpha<1`, put the left end of block k at `alpha H_(k-1)`. Its own centre is `1+alpha H_(k-1)`. The average of the top n centres is `1+alpha(H_n-1)` because `sum_(k=1)^n H_(k-1)=n(H_n-1)`, obtained by reversing a finite double count. The left end of block `n+1` is `alpha H_n`, so the COM lies `1-alpha>0` inside that edge. It also lies within the overlap's right boundary. Yet the bottom's displacement `alpha H_(N-1)` remains unbounded. Thus arbitrarily large ideal overhang can be demonstrated with a strict inward margin at every support, although finite strength, imperfect contacts and astronomical material counts are outside this rigid ideal model.

### 6.3 What the different distances actually mean

For N physical blocks, with top left end at 0:

| Quantity | Coordinate or distance, in half-block units |
|---|---|
| Top right end | 2 |
| Left end of block k | `H_(k-1)` (`H_0=0`) |
| Own centre of block k | `H_(k-1)+1` |
| COM of the top k blocks | `H_k` |
| Bottom left end | `H_(N-1)` |
| Bottom right end / full end-to-end horizontal span | `H_(N-1)+2` |
| Most extreme table edge able to support the entire ideal N-block stack | `H_N` |
| Top overhang beyond that table edge | `H_N` |
| Bottom block's own left overhang beyond that table edge | `H_N-H_(N-1)=1/N` |

The source's `S_N` can describe the aggregate COM or maximal table-edge overhang. It is one index ahead of the bottom-left displacement of N physical blocks. A complete interpretation must choose which distance is meant before counting blocks or converting to height.

### 6.4 All seven original figures

| Figure | PDF page | Whole-page visual inspection and mathematical check |
|---|---|---|
| 1 | 4 | `y=1/x`, width-1 intervals starting at x=1; heights 1, 1/2, 1/3 are left-endpoint heights; curve lies under tops. Correct upper-area comparison. |
| 2 | 4 | Width-1 intervals `[1,2]`, `[2,3]`, `[3,4]`; heights 1/2, 1/3, 1/4 are right-endpoint heights and lie below the decreasing curve. Correct lower-area comparison. |
| 3 | 6 | Seven equal-width blocks shift right downward; dashed lines compare the top right end with the bottom left end. This conveys the intended large displacement, but the almost uniform drawn shifts are not the harmonic equilibrium offsets. Literal geometry cannot verify its caption's universal COM claim. Approximate displayed x-coordinates give widths about 268 pixels and left ends 330,378,434,483,531,579,625. The first five centres average about 565, left of the sixth block's left edge about 579; the first six average about 590, left of the bottom edge about 625. Thus it would tip if interpreted as a to-scale equal-mass stack. Treat it explicitly as a schematic of the goal, or use an equilibrium-consistent drawing. |
| 4 | 7 | Block length labelled 2. `C_0->C_1=1`, `C_1->C_2=1/2`; lower left at C1. C2 marks the combined COM within the second block, not that block's own midpoint. Geometry approximately consistent with the recurrence. |
| 5 | 7 | Three blocks numbered top-down; third left end at C2; successive labels 1,1/2,1/3; C3 is the aggregate COM. Approximately consistent normalized construction. |
| 6 | 8 | Bracket labels the upper n blocks; lower gray block labelled `(n+1)st`; dashed line at the new block's left edge represents the COM of the upper group. Conceptually correct schematic of the recurrence; it does not supply a precise general scale layout. |
| 7 | 8 | Side view of a block, 30 cm horizontal and 3 cm vertical. The 10:1 dimensions and axes of the requested height conversion are unambiguous. |

No figure was inspected only through its caption or OCR. All were seen as part of their complete original pages, including surrounding mathematics and text.

## 7. Table span, block count and height calculations

### 7.1 Units, indexing and the source's estimate

The 30 cm block has normalized length 2, so one unit is 15 cm = 0.15 m; thickness is 3 cm = 0.03 m. One table is `6.5*30 cm=195 cm=13` units, and two tables are 390 cm = 3.9 m = 26 units. Subtracting a full block gives the source's 24 units = 3.6 m.

If “span” means the stack's entire leftmost-to-rightmost extent, then `N` physical blocks have span `H_(N-1)+2`. Reaching 26 units requires `H_(N-1)>=24`. Put `M=N-1`; then solve `H_M>=24`, with physical height `0.03(M+1)` m. If instead the target specifies table-edge overhang, the relevant quantity is `H_N` and the geometry should say so. The source does not include a table diagram settling every possible reading, so its count is best regarded as asymptotic.

Using `ln M < H_M < 1+ln M`, any M meeting `H_M>=24` must have `M>e^23`. Taking `M=ceil(e^24)` certainly suffices. Thus the least possible M lies between these two explicit scales; equating `ln M` to 24 is a sufficient logarithmic construction, not an equation for the exact harmonic threshold.

Numerical arithmetic:

`e^23=9,744,803,446.248902600...`

`e^24=26,489,122,129.843472294...`

`0.03 e^23=292,344,103.387467078... m`

`0.03 e^24=794,673,663.895304169... m`.

The source's `8*10^8 m` is therefore correct to one significant figure for its explicit `e^24` estimate. Integer rounding and the one-block indexing distinction change this approximate height by at most a few centimetres, negligible at this scale. In contrast, replacing the harmonic sum by its logarithm changes the minimum count by a substantial factor, so the source's “would be” height should not be read as a proved minimum.

### 7.2 Independent minimum-count certificate without a memorised harmonic constant

A sharper original calculation is possible using only finite arithmetic and convex integral bounds. This is supplementary technical verification, not a hidden premise required to understand the source's rough estimate.

Choose `m=1,000,000` and compute the finite sum H_m. For integer `N>m`, the trapezium overestimate for the convex function `1/x` on `[m,N]` yields

`L_N=H_m+ln(N/m)-1/(2m)+1/(2N) <= H_N`.

For the upper bound, integrate over `[k-1/2,k+1/2]`. Pairing the integrand at k-t and k+t shows

`1/(k-t)+1/(k+t)=2k/(k^2-t^2)>=2/k`.

Consequently `1/k <= integral_(k-1/2)^(k+1/2) dx/x`. Summing from `k=m+1` through N gives

`H_N <= U_N=H_m+ln((N+1/2)/(m+1/2))`.

No unprovided Euler constant, asymptotic expansion or special-function value is used. At 70-decimal-digit working precision,

`H_1000000=14.39272672286572363138112749318858767664480001374431165341843304581283`.

The certificate evaluates consecutive candidates:

| N | Lower bound `L_N` | Upper bound `U_N` |
|---:|---:|---:|
| 14,872,568,830 | 23.99999999995540079790295250... | 23.99999999995552579786072073... |
| 14,872,568,831 | 24.00000000002263867801386015... | 24.00000000002276367797162838... |

The first upper bound is below 24; the next lower bound is above 24. Since the harmonic sums strictly increase, the least integer M with `H_M>=24` is **14,872,568,831**. The positive margins exceed `2*10^(-11)`, vastly larger than a conservative `10^(-55)` arithmetic allowance at the working precision. Under the full-span interpretation there are **14,872,568,832 physical blocks**, giving **446,177,064.96 m** height. Under a target of exactly 24 units of *table-edge overhang*, one uses the former count as the physical block count, changing height by 0.03 m. The source's logarithmic construction remains sufficient but exceeds the minimum height by about a factor 1.78.

The accompanying arithmetic script reproduces both the rough source estimate and these independently derived bounds. It does not retrieve reference values.

### 7.3 Moon and room/universe comparisons

The authorized baseline has some astronomical reference data (year, light-year, parsec, AU), but gives no Earth–Moon distance or observable-universe diameter. No outside value has been admitted. Therefore the two named comparisons are preserved as source rhetoric and classified as unverified in this phase; they cannot be silently converted into measured facts supplied by the baseline.

For a metric total span L metres in the same one-block-per-level geometry, the target harmonic displacement is `A=L/0.15-2`, and a sufficient logarithmic height is approximately `0.03 exp(A)` metres, with integer and support-block corrections as above. Every extra 0.15 m in L multiplies this estimate by e. Thus an approximate room length has a large effect on its exponent.

The original says approximately 30 feet, but neither allowed input supplies the foot-to-metre factor. The following computations are therefore *explicitly conditional on specified metric spans*, not a covert conversion of the source's feet:

| Assumed metric total span L | Target A | Source-style sufficient logarithmic height |
|---:|---:|---:|
| 9.000 m | 58 | `4.636616806770...*10^23 m` |
| 9.144 m | 58.96 | `1.210943576286...*10^24 m` |
| 10.000 m | 64.666666... | `3.643323634724...*10^26 m` |

The values illustrate that a rounded “room-sized” estimate can span multiple orders of magnitude. They do not establish which metric length the lecturer intended. Treating `10^26 m` as exact in this approximation would require `L=0.15[ln(10^26/0.03)+2]=9.806065547274... m`, equivalent to an *implied* factor about 0.32686885 m/ft if the room were exactly 30 ft; this is an algebraic implication, not an admitted conversion constant. No precise physical necessity claim can be certified from the source's approximate phrase alone.

## 8. Full-baseline consequences and boundaries for a later independent audit

The entire 2,561-line four-subject baseline, including cover and all Physics/Chemistry content, was actually read. It was not reduced to a mathematics-only lookup. Relevant positive grants include:

| Premise available from the combined baseline | Exact location |
|---|---|
| Domains, implication versus converse, legal equation operations, counterexamples | Mathematics lines 40–64 |
| Power algebra, functions, graph transformations, partial fractions | Mathematics lines 72–124 |
| Sequence versus series, finite-limit language, sigma notation, geometric sums | Mathematics lines 128–174 |
| Trig identities, derivatives, elementary integration, logs/exponentials | Mathematics lines 178–398 |
| Convex trapezium overestimate and endpoint-rectangle bounds | Mathematics lines 426–434 |
| Induction; finite root-of-unity algebra; telescoping with a limit | FM01 line 679; FM08 line 693; FM23 line 723 |
| Real Maclaurin series, including the logarithmic series at x=1 | FM27 line 731 |
| Improper integrals as limits, p-integral criterion and singular-point caution | FM28 line 733 |
| Weighted COM, standard uniform-body centres, support and moment balance | FM63–65 lines 807–811 |
| Units, dimensional and graphical checks, equilibrium and gravity interpretation | Physics lines 879–903, 1009–1029, 1201–1209 |

Reading Physics and Chemistry did not supply a missing general series theorem, a proof of irrationality of the cube-reciprocal sum, a foot conversion, a Moon distance, or an observable-universe diameter. No merely familiar topic name was treated as an unstated grant. The baseline's curriculum-completion assumption is not a measured learner performance claim.

Later teaching must make the actual new or clarified connections visible: partial-sum convergence as the definition of an infinite series; finite positive inequalities controlling the limit; the complete p-series result; eventual positivity and a finite positive ratio in limit comparison; real-domain checks before applying tests; and the precise mapping from block count to COM, endpoints and overhang. No conclusion about whether any current or future teaching document does these things has been reached here.

## 9. Seal and next-stage admission boundary

This dossier, its coverage table, arithmetic script/output, input manifest and access ledger are frozen as Phase A. Their digests are listed in `phase-a-seal.json`. Findings are source-only and must be withheld from a future author until the full new teaching freeze. The original-only phase admitted neither current published full PROF nor final assessment prompts. Root must separately admit the current full PROF, and then the final-prompt-only packet for independent solving/sealing before any whole frozen new teaching is examined. A later phase must preserve this Phase A record and identify its own newly authorized inputs; it must not retroactively attribute later knowledge to this reading.
