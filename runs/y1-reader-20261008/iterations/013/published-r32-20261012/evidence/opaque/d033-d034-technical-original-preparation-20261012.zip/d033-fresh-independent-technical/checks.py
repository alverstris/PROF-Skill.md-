"""Finite exact checks for D033. General proofs are in technical-dossier.txt.

Only arithmetic and explicit equations from the assigned source/baseline are
used. No network, external subject source, or sibling work product is read.
"""
from fractions import Fraction as F
from math import factorial, comb
from pathlib import Path
import json


results = []


def record(check_id, pages, description, test_count, details):
    results.append({
        "id": check_id,
        "physical_pages": pages,
        "description": description,
        "status": "passed",
        "exact_assertions": test_count,
        "details": details,
        "scope": "Finite exact corroboration; unrestricted claims use dossier arguments.",
    })


def polynomial_value(coefficients, x):
    return sum((a*x**n for n, a in enumerate(coefficients)), F(0))


def derivative(coefficients):
    return [n*a for n, a in enumerate(coefficients) if n]


def binomial_coefficients(a, n):
    coefficients = [F(1)]
    for k in range(n):
        coefficients.append(coefficients[-1]*(a-k)/(k+1))
    return coefficients


xs = [F(-3, 2), F(-1), F(-3, 4), F(0), F(1, 2), F(1), F(3, 2)]
count = 0
for a in xs:
    for n in range(21):
        partial = sum((a**k for k in range(n+1)), F(0))
        assert (1-a)*partial == 1-a**(n+1)
        if a == -1:
            assert partial == (1 if n % 2 == 0 else 0)
            count += 1
        count += 1
record("C01", [2], "Finite geometric identity and alternating partial sums", count,
       "Includes endpoints and exterior inputs; identity is finite and not a convergence claim.")

count = 0
for n in range(31):
    convolution = sum(F(1) for j in range(n+1))
    derivative_coefficient = F(n+1)
    assert convolution == n+1 == derivative_coefficient
    count += 1
record("C02", [3], "Geometric product and derivative coefficient agreement", count,
       "Coefficient x^n is n+1 through n=30; combinatorial proof covers all n.")

sample = [F(7), F(-3, 2), F(5), F(-9, 4), F(11, 7)]
primitive = [F(13)] + [a/F(n+1) for n, a in enumerate(sample)]
assert derivative(primitive) == sample
printed_primitive = [F(13)+sample[0], F(0)] + [sample[n]/F(n+1) for n in range(1,len(sample))]
assert derivative(printed_primitive) != sample
assert derivative(printed_primitive)[0] == 0
record("C03", [3], "General integration correction and missing-x defect", 3,
       "The printed general primitive has zero constant derivative coefficient; corrected primitive recovers a_0=7.")

count = 0
for x in [F(-3,4), F(-1,2), F(0), F(1,2), F(1), F(3,2)]:
    for n in range(1,21):
        t_prime = sum(((-1)**k*x**k for k in range(n)), F(0))
        assert F(1)/(1+x)-t_prime == (-1)**n*x**n/(1+x)
        count += 1
printed_log = [F(0), F(1), F(-1,2), F(1,3), F(1,4)]
printed_log_derivative = polynomial_value(derivative(printed_log), F(1,2))
true_derivative = F(1)/(1+F(1,2))
assert printed_log_derivative == F(7,8)
assert true_derivative == F(2,3)
assert printed_log_derivative-true_derivative == F(5,24)
record("C04", [3], "Logarithm finite residual identity and printed-sign witness", count+3,
       {"printed_derivative_at_half": str(printed_log_derivative),
        "correct_derivative_at_half": str(true_derivative),
        "difference": "5/24",
        "interpretation": "A nonzero derivative discrepancy disproves the printed identity on an interval."})

count = 0
for x in xs:
    for n in range(21):
        a_prime = sum(((-1)**k*x**(2*k) for k in range(n+1)), F(0))
        assert F(1)/(1+x*x)-a_prime == (-1)**(n+1)*x**(2*n+2)/(1+x*x)
        count += 1
record("C05", [3], "Arctangent finite geometric remainder derivative identity", count,
       "All tested real denominators positive; integrated remainder argument in dossier supplies convergence at both endpoints.")

coefficients = [F((-1)**n*(n+2),n+1) for n in range(21)]
count = 0
for n in range(21):
    d = coefficients[:]
    for k in range(n):
        d = derivative(d)
    assert d[0] == factorial(n)*coefficients[n]
    count += 1
record("C06", [4], "Taylor coefficient extraction by repeated finite differentiation", count,
       "Checks n=0 through 20, including 0!=1; power-series passage is conditional on source termwise rule.")

count = 0
for n in range(41):
    assert F(n+1, factorial(n+1)) == F(1, factorial(n))
    count += 1
e_bounds = []
for n in [0,1,5,10,20]:
    s = sum((F(1,factorial(k)) for k in range(n+1)),F(0))
    bound = F(n+2,(n+1)*factorial(n+1))
    e_bounds.append({"N":n,"partial_sum":str(s),"strict_remainder_upper_bound":str(bound)})
record("C07", [4], "Exponential derivative coefficients and certified bound formula values", count,
       {"bounds":e_bounds,"warning":"No rounded-decimal certification is inferred from bound width alone."})

count = 0
for k in range(1,21):
    assert F((-1)**k*2*k, factorial(2*k)) == F((-1)**k,factorial(2*k-1))
    assert F((-1)**(k-1)*(2*k-1),factorial(2*k-1)) == F((-1)**(k-1),factorial(2*k-2))
    count += 2
assert F((-1)**2, factorial(2)) != F((-1)**1, factorial(2))
record("C08", [4,5], "Cosine/sine derivative coefficients and cosine sign-exponent defect", count+1,
       {"printed_cosine_x2_coefficient":"1/2","correct_cosine_x2_coefficient":"-1/2"})

count = 0
for a in [F(-3),F(-1),F(-1,2),F(0),F(1,2),F(1),F(2),F(5,2),F(6)]:
    cs = binomial_coefficients(a,21)
    for n in range(21):
        assert (n+1)*cs[n+1] == (a-n)*cs[n]
        count += 1
    for x in [F(-3,4),F(0),F(2,3)]:
        # Finite residual of (1+x)B_N'-aB_N is confined to degree N.
        n = 20
        bn = cs[:n+1]
        residual = (1+x)*polynomial_value(derivative(bn),x)-a*polynomial_value(bn,x)
        assert residual == (n-a)*cs[n]*x**n
        count += 1
    if a.denominator == 1 and a >= 0:
        m = int(a)
        assert all(c == 0 for c in cs[m+1:])
        count += 1
        for x in xs:
            assert polynomial_value(cs,x) == (1+x)**m
            count += 1
record("C09", [5], "Binomial recurrence, finite ODE residual, and polynomial termination", count,
       "Real-a endpoint classification is intentionally not claimed by this finite check.")

sqrt_cs = binomial_coefficients(F(1,2),50)
assert sqrt_cs[:5] == [F(1),F(1,2),F(-1,8),F(1,16),F(-5,128)]
count = 1
for n in range(1,51):
    q_prev = F(comb(2*n-2,n-1),4**(n-1))
    q = F(comb(2*n,n),4**n)
    assert abs(sqrt_cs[n]) == q_prev-q
    assert sum(map(abs,sqrt_cs[1:n+1]),F(0)) == 1-q
    count += 2
record("C10", [6], "Square-root coefficients and absolute-tail telescoping identity", count,
       "General endpoint conclusion also needs q_N -> 0, established in the dossier.")

output = {
    "material_id":"D033",
    "method":"Python standard-library exact Fraction arithmetic; no outside reference function evaluations",
    "overall_status":"passed",
    "test_groups":len(results),
    "reported_exact_assertions":sum(r["exact_assertions"] for r in results),
    "results":results,
    "general_proof_location":"technical-dossier.txt",
    "teaching_or_trial_status":"No teaching admission, student trial, SASIS, or acceptance performed.",
}
destination = Path(__file__).with_name("checks-results.json")
destination.write_text(json.dumps(output,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"status":"passed","groups":len(results),"output":str(destination)}))
