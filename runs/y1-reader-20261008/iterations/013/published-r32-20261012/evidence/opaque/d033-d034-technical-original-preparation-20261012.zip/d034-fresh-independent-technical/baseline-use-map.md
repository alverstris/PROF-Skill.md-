# Complete baseline reading and technical dependencies

The entire 247,840-byte baseline, decoded as 246,945 Unicode characters and displayed as 245,568 characters after universal-newline normalization, was read. The following map identifies usable premises relevant to D034 after that complete read. It does not replace the access record and does not claim measured student mastery.

| Baseline part | Operational premises actually present | Relevance and limit for D034 |
|---|---|---|
| Mathematics: arithmetic, algebra and proof | Unit conversions, factorials, powers, logarithms, inequalities, finite sums, deduction and counterexamples | Coefficients, half-life conversion and scope counterexamples; familiar notation alone cannot grant a new theorem |
| Mathematics: functions and trigonometry | Unit-circle values, radians, principal arcsin domain/range and inverse-versus-reciprocal distinction | sin(pi/2)=1 and the branch of arcsin are already available |
| Mathematics: sequences and binomial expansion | Geometric finite/infinite sums with |r|<1; rational binomial expansion for |u|<1 | The negative-half binomial expansion is available; its boundary is not automatically included |
| Mathematics: calculus and numerical methods | Scalar product, quotient, chain and implicit differentiation; FTC; substitution; integration by parts; monotone rectangle bounds | Exponential moments and an explicit convergence comparison can be reconstructed; the scalar differentiation rules are not new to this student |
| Mathematics: statistics | Frequency-weighted means, probability rules, independence, normal standardization | An initial weighted-mean analogy and two-life independent-event calculation are available; the further density/moment definitions come from Further Mathematics |
| Further Mathematics FM01 | Mathematical induction, including inequalities and factorials | Establishes the coefficient bounds used in the endpoint proof |
| Further Mathematics FM09–FM16 | Finite matrices and operations, order of multiplication, identities and inverses | Matrix notation exists; a Jacobian, multivariable derivative or derivative-composition theorem is not thereby pre-taught |
| Further Mathematics FM23 | Finite sums and telescoping, with explicit limit checks | Reinforces that finite algebra does not itself justify an infinite sum |
| Further Mathematics FM27 | Real exponential, sine, cosine, logarithmic and binomial expansions; substitution changes validity | Gaussian expansion and sine substitution are available; general convergence proofs and a remainder theorem are explicitly not automatically granted |
| Further Mathematics FM28 | Improper integrals as limits; x^(-p) improper-integral convergence for p>1 | Handles the endpoint arcsin integral and positive-rate exponential moments; supplies the integral used in the reconstructed series comparison |
| Further Mathematics FM29 | Principal inverse-trigonometric derivatives and primitives with real domains | Arcsin derivative/primitive is present for |x|<1; reaching x=1 still requires a limit |
| Further Mathematics FM30 | Ordinary integral average on a finite interval | Distinguishes unweighted average from a probability-weighted one |
| Further Mathematics FM38–FM45 | Normalization, CDF/density relation, continuous moments, exponential and normal densities, expectation of functions and linearity | Establishes the event-time density, verifies the exponential payoff and normal-kernel qualification, and permits the two-life counterexample |
| Further Mathematics FM69–FM71 | Explicit boundary on partial differentiation, multiple integrals and other university formalisms; cross-subject reasoning must expose premises | D034's closing multivariable preview does not become fully operational prior knowledge simply because scalar calculus and matrices are known |
| Physics: quantities and exponential processes | Time units, exponential laws, interpretation of rate constants, dimensionless exponents | Seconds versus years must be reconciled; payment units require a rate converting time to money |
| Physics: nuclear decay | S(t)=e^(-lambda t), positive conditional decay rate, half-life ln(2)/lambda, random individual decay | Supports the lifetime model and distinguishes survival probability from a density or finite-interval rate |
| Chemistry CH-01.02 | Isotope relative mass as an abundance-weighted mean | Supplies a second actual prior weighted-mean example, not a new probability law |
| Chemistry CH-04.02 | First-order loss and k=ln(2)/half-life with careful rate convention and units | Supports the symbolic half-life relation; no polonium isotope/half-life data are supplied |
| All four sections | Topic names and provenance URLs do not grant omitted rules or extra retrieval access | No linked document or previous lecture/problem-set premise was imported |

No part of the operational baseline states L'Hôpital's rule. D034's optional hint names the rule without its statement or hypotheses. The endpoint proof in the dossier uses permitted induction, algebra and integral bounds instead. General termwise power-series calculus is asserted in D034; the dossier makes its interior convergence requirement and an independent local justification explicit. A general elementary-antiderivative nonexistence theorem is absent. The chemistry section was fully read even though most of its content is not needed by this particular lecture.

This is a dependency record for technical preparation, not an assessment of whether a future explanation or student response meets any teaching acceptance standard.
