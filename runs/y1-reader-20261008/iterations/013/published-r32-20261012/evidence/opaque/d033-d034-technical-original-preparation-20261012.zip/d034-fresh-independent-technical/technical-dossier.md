# D034 independent technical preparation

Prepared 12 October 2026. Recipient: root only. Source: MIT 18.01, Fall 2006, Lecture 38, Final Review. This is an original-only technical dossier. It is not PROF admission, teaching acceptance, a student trial, a SASIS result, an author prompt, or a teaching draft. No conclusion has been sent to a future author.

The permitted subject inputs were the original D034 packet and the complete four-subject baseline. The original PDF has four physical pages: a cover and three lecture pages numbered 1–3. All four supplied full-page images and all four full-page text files were read. The original PDF was subsequently opened and its four page texts read directly. Each text derivative exactly matches that PDF extraction, and each PNG's decoded RGB pixels exactly match a fresh 2× rendering of its corresponding PDF page. There are no mathematical figures, plots, axes, tables, or diagrams in this source; the mathematical visual content is typeset equations. The cover, page headers, footer numbers and final verse were included in visual coverage.

The baseline was actually read in thirteen contiguous bounded character slices, including the entire Mathematics, Further Mathematics, Physics and Chemistry sections and the final references. No slice was truncated. Counts, intervals and actual tool-result identifiers are in input-access.json. Hashes identify bytes, not pedagogical validity.

## 1. Power-series calculus, physical page 2 / printed page 1

The source writes f(x) = sum from n=0 to infinity of a_n x^n, followed by

\[
f'(x)=\sum_{n=1}^{\infty}n a_n x^{n-1},\qquad
\int f(x)\,dx=C+\sum_{n=0}^{\infty}\frac{a_n x^{n+1}}{n+1}.
\]

Both formulae are valid inside an interval of convergence with positive radius R, meaning |x|<R. The differentiated sum begins at n=1 because the n=0 term has derivative zero. The integrated constant C is free; for the integral from 0 to x it is zero. These statements do not license termwise differentiation at an endpoint, nor do they supply an endpoint convergence test. A power series of radius zero provides no interval on which the displayed calculus assertion operates. Infinite radius covers every finite real x.

An independent local justification is available without treating arbitrary sums like finite polynomials. Fix 0<r<s<R. Convergence at s makes the terms a_n s^n bounded in absolute value by some M. On |x|≤r, set q=r/s<1. The original terms are bounded by M q^n and the differentiated terms by (M/s)n q^(n-1). The corresponding positive geometric sums and their finite-sum derivatives have finite limits. Thus the tails of both the original and derivative partial sums are bounded uniformly on that interval. Integrating a uniformly bounded tail over a finite interval gives a bound equal to interval length times that tail bound. Applying this fact to derivative partial sums, and then the fundamental theorem of calculus, identifies the derivative of their limiting primitive. Integrating the original partial sums gives the second formula in the same way. This supplies the missing condition and a reason for the interchange; the source itself does not state this justification.

The finite geometric derivative limit uses n q^n→0 for 0<q<1. Writing q=e^(-c), c>0, this follows from e^(cn)≥(cn)^2/2, a consequence of the baseline's exponential expansion, so n e^(-cn)≤2/(c^2 n). No use of an unstated L'Hôpital rule is required.

## 2. Gaussian example, physical page 2 / printed page 1

The source's integrand expands as

\[
e^{-t^2}=\sum_{n=0}^{\infty}\frac{(-1)^n t^{2n}}{n!}
=1-t^2+\frac{t^4}{2!}-\frac{t^6}{3!}+\frac{t^8}{4!}-\cdots.
\]

The baseline explicitly supplies the real exponential series for every real argument. Substitution is legitimate for every real t. On any bounded t interval its absolute terms are bounded by the summable series for e^(M^2), so integration over any finite real interval is justified. The independent result is

\[
G(x):=\int_0^x e^{-t^2}\,dt
=\sum_{n=0}^{\infty}\frac{(-1)^n x^{2n+1}}{n!(2n+1)}
=x-\frac{x^3}{3}+\frac{x^5}{10}-\frac{x^7}{42}+\frac{x^9}{216}-\cdots.
\]

Every displayed source coefficient is correct. Differentiating the resulting series recovers e^(-x^2); G(0)=0 fixes the constant. This works for every finite real x, including negative x with the oriented integral convention. All these variables are pure mathematical variables; the exponent requires a dimensionless t. A physical Gaussian variable would require a scale in its exponent.

The heading “Normal (or Gaussian) Distribution” is broader than the displayed expression: e^(-t^2) is a Gaussian kernel, not a probability density with unit total mass as written, and G(x) is not a cumulative distribution function. The baseline's normal density at mean 0 and variance 1/2 is p(t)=e^(-t^2)/sqrt(pi). Therefore its CDF is 1/2+G(x)/sqrt(pi), by symmetry. This distinction follows from FM44 rather than from an unprovided evaluation of a Gaussian integral.

There is also a direct computational control if the phrase “we can still compute it” is read as a numerical claim. For |x|≤M and a truncation through n=N with N+2>M^2, put q=M^2/(N+2)<1. Successive absolute omitted terms have ratio at most q. Consequently the absolute truncation error is at most

\[
\frac{M^{2N+3}}{(N+1)!(2N+3)}\frac{1}{1-q}.
\]

This is a conservative geometric tail bound derived from the coefficients, not an imported general Taylor remainder theorem. No particular x or required accuracy is specified in the source.

The source asserts that G is not elementary. Its series and derivative do not prove that nonexistence statement. Neither the baseline nor D034 supplies a characterization of elementary antiderivatives or a non-elementarity proof. This assertion remains source-asserted and independently unproved in this constrained dossier. No computer algebra failure is being used as proof, and no outside differential-algebra theorem was imported. The accompanying preference for elementary functions and statement that some series are unintuitive are qualitative commentary.

## 3. Sine, inverse sine and the improper integral, physical page 2 / printed page 1

The sine expansion and its substitution x=pi/2 are correct for real x:

\[
\sin x=\sum_{n=0}^{\infty}\frac{(-1)^n x^{2n+1}}{(2n+1)!},\qquad
1=\sum_{n=0}^{\infty}\frac{(-1)^n(\pi/2)^{2n+1}}{(2n+1)!}.
\]

Radian measure is required. The unit-circle baseline gives sin(pi/2)=1 exactly. Saying numerical evaluation would be a waste of time is commentary about that particular known value, not a theorem excluding numerical uses of sine series. The series alone is not offered as a definition of an angle in the source.

The notation sin^(-1) means the principal inverse sine, not 1/sin. Its domain is [-1,1], its range is [-pi/2,pi/2], and its derivative is 1/sqrt(1-x^2) only for |x|<1. The displayed integral to 1 must therefore be interpreted as

\[
\int_0^1\frac{dx}{\sqrt{1-x^2}}
=\lim_{b\uparrow1}\bigl(\arcsin b-\arcsin0\bigr)
=\frac{\pi}{2}.
\]

This independently verifies the value and convergence using the baseline inverse derivative and improper-integral definition. The source's endpoint evaluation is correct in this limiting sense; it is not an application of a bounded-integrand formula at x=1. Merely knowing sin(pi/2)=1 would not distinguish inverse branches without the principal-range convention.

## 4. Binomial expansion and integrated endpoint, physical pages 2–3 / printed pages 1–2

Define a_0=1 and, for n≥1,

\[
a_n=\frac{1\cdot3\cdots(2n-1)}{2\cdot4\cdots(2n)}
=\frac{(2n)!}{4^n(n!)^2},\qquad
\frac{a_{n+1}}{a_n}=\frac{2n+1}{2n+2}.
\]

Here a_n denotes these specific coefficients; it is not a new restriction on the arbitrary coefficients in section 1. The source's two versions of the binomial expansion agree:

\[
(1+u)^{-1/2}=\sum_{n=0}^{\infty}(-1)^n a_n u^n
=1-\frac12u+\frac{1\cdot3}{2\cdot4}u^2
-\frac{1\cdot3\cdot5}{2\cdot4\cdot6}u^3+\cdots.
\]

The general-binomial baseline supplies this identity for |u|<1. Its negative-half exponent produces n negative factors in the coefficient, hence the alternating signs; odd numerators and even denominators are correct. The real function is defined for u>-1, but its domain is not itself the convergence interval of this series. No unsupported boundary inclusion follows from the binomial rule.

Putting u=-x^2 makes every coefficient positive and requires |x|<1:

\[
(1-x^2)^{-1/2}=\sum_{n=0}^{\infty}a_nx^{2n}
=1+\frac{x^2}{2}+\frac{3x^4}{8}+\frac{5x^6}{16}+\cdots.
\]

Integration within that open interval gives

\[
\arcsin x=\sum_{n=0}^{\infty}\frac{a_nx^{2n+1}}{2n+1}
=x+\frac{x^3}{6}+\frac{3x^5}{40}+\frac{5x^7}{112}+\cdots,
\]

and the indefinite primitive is this expression plus C. The constant is zero for arcsin because arcsin(0)=0. All source factors of 3, 5 and 7 in the integrated denominators are correct. Differentiation verifies the primitive on |x|<1.

The source then substitutes x=1 into the integrated series. This is true, but it is a separate endpoint step, not granted by the source's open-interval binomial expansion:

\[
\frac{\pi}{2}=\sum_{n=0}^{\infty}\frac{a_n}{2n+1}
=1+\frac16+\frac{3}{40}+\frac{5}{112}+\cdots.
\]

## 5. Full independent solution of the optional convergence problem

For n≥0, induction gives a_n≤1/sqrt(n+1). The base value is a_0=1. The induction step is exactly

\[
\left(\frac{2n+1}{2n+2}\right)^2\frac{n+2}{n+1}\le1,
\]

because 4(n+1)^3-(2n+1)^2(n+2)=3n+2≥0. Thus, for n≥1,

\[
0<\frac{a_n}{2n+1}\le\frac{1}{2n^{3/2}}.
\]

The convergence comparison itself can be derived from rectangles: t^(-3/2) decreases, so, for M>N≥1,

\[
\sum_{n=N+1}^{M}\frac{a_n}{2n+1}
\le\frac12\sum_{n=N+1}^{M}n^{-3/2}
\le\frac12\int_N^M t^{-3/2}\,dt
\le\frac{1}{\sqrt N}.
\]

The partial sums are increasing and have arbitrarily small tails, so the series converges; the same tail estimate is valid for the integrated series uniformly for |x|≤1. This argument uses baseline induction, inequalities, finite sums, rectangles and improper integrals; it does not assume a memorized p-series test or a general uniform-convergence theorem.

To establish the value at the endpoint, fix N, let 0≤r<1, and write P_N(r)=sum from n=0 through N of a_n r^(2n+1)/(2n+1). The established interior identity gives 0≤arcsin(r)-P_N(r)≤1/sqrt(N). Let r increase to 1. The finite polynomial is continuous and arcsin(r) tends to pi/2, yielding

\[
0\le\frac{\pi}{2}-P_N(1)\le\frac1{\sqrt N}.
\]

Taking N to infinity proves both the source's equality and a certified, though loose, error bound. At x=-1 the integrated series converges absolutely to -pi/2 by oddness. The original, unintegrated binomial series diverges at x=±1 and its real function is singular there; integration has improved the endpoint behavior.

The rate of decay can also be bounded from below. For n≥1, induction gives a_n≥1/(2sqrt(n)), because a_1=1/2 and (2n+1)^2≥4n(n+1). Therefore

\[
\frac1{6n^{3/2}}\le\frac{a_n}{2n+1}\le\frac1{2n^{3/2}}\quad(n\ge1).
\]

The terms decrease on the scale n^(-3/2), in the precise sense of these constant-multiple bounds. In particular, this is stronger than merely showing terms tend to zero. The latter would not prove series convergence. The exact successive-term ratio is (2n+1)^2/[(2n+2)(2n+3)], which tends to 1, so a simple ratio limit would be inconclusive.

The source labels this problem optional and hard, and hints at L'Hôpital's rule. The baseline does not state that rule, and D034 names it without supplying its hypotheses or a function to which it applies. A factorial/product sequence cannot simply be differentiated with respect to its index. The proof above resolves the problem from permitted premises without presenting that hint as a supplied method. No Stirling formula, gamma function, Wallis formula or remembered exact coefficient asymptotic was used.

## 6. Weighted average and radioactive payoff, physical pages 3–4 / printed pages 2–3

For an ordinary positive weighted average on an interval, the displayed ratio is valid under the following conditions: w≥0, 0<W=integral w<infinity, and integral |f|w<infinity. Then p=w/W is a normalized density and the average is integral fp. The same formula can define a signed weighted ratio if weights have both signs, but it need not lie between the values of f or represent a probability expectation. A zero or infinite denominator does not define the ordinary finite weighted mean. The denominator has the units of total weight, and the ratio retains the units of f. With w=1 on a finite interval this is the already supplied ordinary integral mean. For other positive weights, “total” means the total of the particular weight, not an automatically dimensionless total probability.

In the decay example the source states that the likelihood of not yet decaying is e^(-kt). This is the survival probability S(t)=P(T>t), for t≥0 and k>0. It is not itself the probability density. The source writes w(x)=e^(-kt), switching variable names; w(t) is the consistent reading. The distinction is consequential but the particular source calculation has the correct answer, since

\[
F_T(t)=1-e^{-kt},\qquad p_T(t)=k e^{-kt},\qquad
W=\int_0^\infty S(t)\,dt=\frac1k,
\]

so its normalized survival weight S/W happens to equal the decay-time density. The CDF/density relation is explicitly available in FM42 and the exponential model in FM44; Physics supplies the decay survival law. For t<0, this lifetime distribution has F=0; the expression 1-e^(-kt) is not its CDF there. If k=0, survival is constant and the finite-normalization integral diverges; if k<0, survival exceeds one for positive times and is not a valid decay model.

The denominator and numerator can be independently evaluated at a finite upper bound B and then limited:

\[
\int_0^B e^{-kt}\,dt=\frac{1-e^{-kB}}k,
\]
\[
\int_0^B t e^{-kt}\,dt
=\frac1{k^2}-e^{-kB}\left(\frac Bk+\frac1{k^2}\right).
\]

Both exponential boundary terms vanish for k>0. For example u e^(-u)≤2/u for u>0, using the exponential series. Consequently the denominator is 1/k, the numerator is 1/k^2, and their ratio is 1/k. With u=kt, du=k dt, the same computation is

\[
k\int_0^\infty t e^{-kt}\,dt
=\frac1k\int_0^\infty u e^{-u}\,du=\frac1k,
\]

because integration by parts gives integral from 0 to B of u e^(-u) du = 1-(B+1)e^(-B)→1. All displayed source equalities, limits, the factor k, and the substitution factor du/k are consistent.

The identity between normalized survival weighting and event-density weighting must not be generalized without a check. A counterexample available entirely from the baseline is a lifetime uniform on [0,1]: its density is 1, mean 1/2, survival is 1-t on that interval, but the survival-weighted ratio is (integral t(1-t)dt)/(integral (1-t)dt)=(1/6)/(1/2)=1/3. The source's correct exponential calculation does not establish a general rule for obtaining an event-time density by dividing a survival curve by its area.

Time and money need separate units. If t measures seconds, k has units s^(-1). The shorthand “$t” means a payment c t with c=1 dollar/second. Then E[T]=1/k seconds and E[cT]=c/k dollars. Treating the numerical value in seconds as the dollar amount explains the source's f(t)=t notation. Its answer is an undiscounted expected payout, and corresponds to a break-even price only under an expectation-based, no-cost model. It does not determine every person's willingness to pay from probability alone.

## 7. Half-life statement, physical page 4 / printed page 3

The image literally prints “Polonium” with a superscript 120, and H=(131)(24)(60)^2 seconds. The superscript is part of the source, not an OCR inference. No isotope data in the permitted material verifies this isotope label or its asserted empirical half-life. These are unresolved source data; they have not been silently changed to a different isotope or a different number of days.

Conditional on the specified H, all subsequent algebra and unit conversion are correct:

\[
e^{-kH}=\frac12\ \Longrightarrow\ k=\frac{\ln2}{H}>0,
\qquad E[T]=\frac1k=\frac{H}{\ln2}.
\]

H=131 days gives H=11,318,400 seconds, k approximately 6.1240739023×10^(-8) s^(-1), and E[T] approximately 16,328,999.5508 seconds or 188.99305036 days. These numerical evaluations are independent arithmetic checks, not independent nuclear-data verification. The payoff in dollars has the same numerical value as E[T] in seconds only under the source's one-dollar-per-second convention. The baseline's half-life physics and Chemistry first-order rate relation both support the symbolic relation, but neither supplies this polonium datum.

## 8. Annuity analogy and two lives, physical page 4 / printed page 3

The source's statement that no one bets on particle decay is a rhetorical empirical universal, not a proved fact, and remains unverified. The annuity description is a simplified lifetime-contingent payment model. The packet supplies neither actual product terms nor evidence that real human mortality follows an exponential survival law. Therefore the mathematical comparison is conditional on the stated model.

In that model, if T is remaining life in years and S(t)=e^(-kt), then k must be in years^(-1). A constant continuous payment rate c in dollars/year produces total payment cT and mean c/k. The shorthand f(t)=t assumes c=1 in these chosen units. The earlier k in seconds^(-1) cannot be reused numerically with years without conversion.

The prose says payments are monthly, whereas the expression f(t)=t treats the total as a continuous linear payment. For literal payments A each month in arrears at times m/12, m≥1, and no other benefits or discounting, the independent expectation is

\[
A\sum_{m=1}^{\infty}P(T\ge m/12)
=A\sum_{m=1}^{\infty}e^{-km/12}
=\frac{A}{e^{k/12}-1}.
\]

The event probability at an exact payment boundary is unchanged by > versus ≥ for the continuous exponential model. The expression follows from the expectation of each payment indicator, finite linearity and a convergent nonnegative geometric tail. It is not exactly 12A/k. Thus cT is a continuous-payment idealization, or an explicitly chosen continuously prorated convention, rather than the exact consequence of monthly payments alone. Payment amount, timing, guarantees and any discount convention are unspecified in the source.

The claim that a two-life annuity needs multiple integrals is too strong as a statement of mathematical necessity. “Two-life” does not specify whether payments stop at the first or second death, nor a joint dependence model. Multiple integrals are one possible general method, but a one-dimensional calculation suffices in accessible examples. For independent exponential remaining lives T_1,T_2 with rates k_1,k_2>0, independence gives

\[
P(\min(T_1,T_2)>t)=e^{-(k_1+k_2)t}.
\]

The first-death time is therefore exponential with mean 1/(k_1+k_2). An annuity paid continuously at rate c while both live has expected undiscounted payment c/(k_1+k_2). This uses only the baseline's independence and exponential results. For payments until the last death, max(T_1,T_2)+min(T_1,T_2)=T_1+T_2 gives mean duration 1/k_1+1/k_2-1/(k_1+k_2) by linearity of expectation. These counterexamples qualify the source's necessity claim without importing multivariable integration. They are conditional mathematical checks, not a reconstruction of unspecified real annuity terms.

## 9. Closing chain-rule preview, physical page 4 / printed page 3

“Differentiate anything” describes an instructional aspiration, not a literal theorem: a derivative requires differentiability, which fails even for the baseline function |x| at 0. The source's claim that a multivariable chain rule can unify the ordinary chain, product, quotient and implicit differentiation rules is mathematically coherent with the appropriate hypotheses.

Precisely, if g is differentiable and F is differentiable at g(x), the matrix derivative rule has form D(F composed with g)(x)=DF(g(x))Dg(x). Merely possessing partial derivatives is not in general a substitute for differentiability. Its local algebra is consistent: if g(x+h)=g(x)+B h+r(h) with |r(h)|/|h|→0, and F(g(x)+v)=F(g(x))+A v+s(v) with |s(v)|/|v|→0, then the composite increment is A B h+A r(h)+s(B h+r(h)); the last two terms divided by |h| tend to zero. Thus its derivative is the matrix product A B. This paragraph states the differentiability premise explicitly; the source itself supplies no such definition or proof, and the baseline does not grant the multivariable formalism.

Under that rule, the advertised special cases are verified as follows. A scalar outer function and scalar inner function give the ordinary chain rule. For F(u,v)=uv the row derivative is (v,u), yielding v u'+u v'. For F(u,v)=u/v with v≠0 it is (1/v,-u/v^2), yielding (v u'-u v')/v^2. For an already differentiable graph y(x) satisfying F(x,y(x))=0, the rule gives F_x+F_y y'=0; when F_y≠0 it gives y'=-F_x/F_y. A claim that an implicit equation actually has such a local graph requires additional existence hypotheses; it is not proved merely by writing this quotient. The baseline already supplies ordinary product, quotient, chain and implicit differentiation, so the unification is a preview of new organization and formalism, not four newly introduced scalar techniques.

The final four-line verse and its attribution are literary commentary. Its matrix phrase agrees with the conditional derivative-product formulation just checked; it supplies no mathematical rule by itself. No literary provenance research was performed. The “Final Exam” heading likewise does not add an exam paper or hidden questions to this four-page source. References to previous problem sets establish that the lecturer is recalling prior material; those absent problem sets were not read or treated as additional inputs.

## 10. Technical status and unresolved truth

All displayed source equations and the optional convergence question have been checked. The equations have consistent results once their stated or necessary domains, endpoint limits, positive rate, normalizations and unit conventions are made explicit. The endpoint series identity has an independent proof, not just numerical agreement. The generalized necessity claim for multiple integrals has a baseline-supported counterexample. The probability interpretation of the source's exponential weighted mean is correct because normalized exponential survival equals its density; the same procedure is not generally valid for arbitrary lifetimes.

The non-elementarity assertion, the polonium isotope/half-life datum, the universal statement about betting, real-world scope of the annuity description, and real mortality-model fidelity have not been independently established from the permitted inputs. They are separately recorded rather than promoted to verified facts. Some source sentences are preferences, aspirations or rhetoric rather than truth-bearing mathematical claims. Every such source portion remains covered in source-coverage.json.

No overall teaching-sufficiency verdict follows from these checks. No admission, author transfer, teaching acceptance, student-performance claim or SASIS result was undertaken.
