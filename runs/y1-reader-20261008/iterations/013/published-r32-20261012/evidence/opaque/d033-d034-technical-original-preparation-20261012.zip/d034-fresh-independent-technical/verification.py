from pathlib import Path
from fractions import Fraction
import hashlib
import json
import math
import fitz
from PIL import Image

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
SOURCE = ROOT / 'original-inputs/D034'
BASELINE = ROOT / 'd013-clean-r32-20261012/inputs/student-baseline.txt'
OUT = ROOT / 'd034-fresh-independent-technical'

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

expected_pdf = 'cf22137b1ae1237d5a4d020b13b9c91a857b393c21e5ec9a4d7ba2f3bb497eac'
expected_baseline = '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
assert (SOURCE / 'lec38.pdf').stat().st_size == 192085
assert sha256(SOURCE / 'lec38.pdf') == expected_pdf
assert BASELINE.stat().st_size == 247840
assert sha256(BASELINE) == expected_baseline

identity = json.loads((SOURCE / 'source-identity.json').read_text())
asset = identity['assets'][0]
assert asset['local_pdf'] == 'lec38.pdf'
assert asset['sha256'] == expected_pdf
doc = fitz.open(SOURCE / 'lec38.pdf')
assert len(doc) == 4
pages = []
for i, page in enumerate(doc, 1):
    text_path = SOURCE / f'lec38-p{i:02}.txt'
    image_path = SOURCE / f'lec38-p{i:02}.png'
    reference = asset['page_derivatives'][i-1]
    assert sha256(text_path) == reference['text_sha256']
    assert sha256(image_path) == reference['image_sha256']
    supplied_text = text_path.read_text()
    extracted_text = page.get_text()
    assert extracted_text == supplied_text
    img = Image.open(image_path).convert('RGB')
    pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
    assert img.size == (pix.width, pix.height) == (1224, 1584)
    assert img.tobytes() == pix.samples
    pages.append({
        'physical_page': i,
        'printed_page': None if i == 1 else i-1,
        'text_characters': len(supplied_text),
        'pdf_text_exact_match': True,
        'render_pixel_exact_match': True,
        'image_dimensions': list(img.size),
        'embedded_raster_images': len(page.get_images()),
        'visual_math_figure_count': 0,
        'visual_count_basis': 'All four full-page original-size PNGs were inspected by the agent; image-object count alone was not used to infer absence of figures.'
    })

# Exact two-variable Laurent polynomials. This deliberately uses only the
# standard library for algebra: keys are exponent pairs, values are Fractions.
def clean(p):
    return {key: Fraction(value) for key, value in p.items() if value}

def add(*polys):
    out = {}
    for p in polys:
        for key, value in p.items():
            out[key] = out.get(key, Fraction(0)) + value
    return clean(out)

def scale(p, q):
    return clean({key: value*q for key, value in p.items()})

def mul(a, b):
    out = {}
    for (i,j), x in a.items():
        for (k,l), y in b.items():
            key = (i+k,j+l)
            out[key] = out.get(key,Fraction(0)) + x*y
    return clean(out)

def power(p, n):
    out = {(0,0): Fraction(1)}
    for _ in range(n):
        out = mul(out,p)
    return out

def deriv(p, index=0):
    out = {}
    for key,value in p.items():
        exponents = list(key)
        factor = exponents[index]
        if factor:
            exponents[index] -= 1
            out[tuple(exponents)] = value*factor
    return clean(out)

def integral_0_1(p):
    assert all(j==0 and i>=0 for i,j in p)
    return sum((value/Fraction(i+1) for (i,j),value in p.items()),Fraction(0))

one = {(0,0): Fraction(1)}
z = {(1,0): Fraction(1)}
rate = {(0,1): Fraction(1)}
checks = {}
upper_difference = add(scale(power(add(z,one),3),4),scale(mul(power(add(scale(z,2),one),2),add(z,scale(one,2))),-1))
assert upper_difference == {(1,0): Fraction(3),(0,0): Fraction(2)}
checks['upper_coefficient_induction_difference'] = '3*n+2'
lower_difference = add(power(add(scale(z,2),one),2),scale(mul(z,add(z,one)),-4))
assert lower_difference == one
checks['lower_coefficient_induction_difference'] = '1'
# The derivative of exp(-k*t)*P(t,k) is exp(-k*t)*(P_t-k*P).
primitive_survival_prefactor = {(0,-1): Fraction(-1)}
primitive_first_prefactor = {(1,-1): Fraction(-1),(0,-2): Fraction(-1)}
primitive_unit_prefactor = {(1,0): Fraction(-1),(0,0): Fraction(-1)}
assert add(deriv(primitive_survival_prefactor),scale(mul(rate,primitive_survival_prefactor),-1)) == one
assert add(deriv(primitive_first_prefactor),scale(mul(rate,primitive_first_prefactor),-1)) == z
assert add(deriv(primitive_unit_prefactor),scale(primitive_unit_prefactor,-1)) == z
checks['exponential_primitives_differentiate_correctly'] = True
checks['improper_moments'] = {'integral_survival': '1/k', 'integral_t_survival': '1/k^2', 'integral_u_exp_minus_u': '1', 'condition': 'k>0; boundary limits proved in dossier'}
checks['arcsine_derivative'] = {'basis': 'FM29 baseline and independent domain/improper-limit reasoning in dossier; not a computational identity check', 'real_condition': '|x|<1'}
variance = Fraction(1,2)
assert 2*variance == 1
checks['normal_kernel_normalization_from_baseline_density'] = {'density': 'exp(-t^2)/sqrt(pi)', 'mean': '0', 'variance': '1/2'}
uniform_mean = integral_0_1(z)
uniform_survival = add(one,scale(z,-1))
survival_ratio = integral_0_1(mul(z,uniform_survival))/integral_0_1(uniform_survival)
assert uniform_mean == Fraction(1,2)
assert survival_ratio == Fraction(1,3)
checks['uniform_lifetime_counterexample'] = {'event_mean': str(uniform_mean), 'normalized_survival_mean': str(survival_ratio)}
assert deriv({(1,1):Fraction(1)},0) == {(0,1):Fraction(1)}
assert deriv({(1,1):Fraction(1)},1) == {(1,0):Fraction(1)}
assert deriv({(1,-1):Fraction(1)},0) == {(0,-1):Fraction(1)}
assert deriv({(1,-1):Fraction(1)},1) == {(1,-2):Fraction(-1)}
checks['product_quotient_outer_derivatives'] = {'product_row': ['v','u'], 'quotient_row': ['1/v','-u/v^2'], 'quotient_condition': 'v!=0', 'general_chain_rule_status': 'conditional on differentiability; local argument in dossier'}

a = Fraction(1)
coefficients = []
gaussian_poly = {}
integrand_poly = {}
falling = Fraction(1)
for j in range(8):
    g = Fraction((-1)**j, math.factorial(j)*(2*j+1))
    assert a == Fraction(math.factorial(2*j), 4**j * math.factorial(j)**2)
    if j:
        falling *= Fraction(-1,2)-(j-1)
    assert falling/Fraction(math.factorial(j)) == ((-1)**j)*a
    coefficients.append({'n': j, 'a_n': str(a), 'integrated_arcsine': str(a/Fraction(2*j+1)), 'integrated_gaussian': str(g)})
    gaussian_poly[(2*j+1,0)] = g
    integrand_poly[(2*j,0)] = Fraction((-1)**j,math.factorial(j))
    a *= Fraction(2*j+1,2*j+2)
assert deriv(gaussian_poly) == integrand_poly
checks['finite_gaussian_coefficients_differentiate_correctly'] = True

sanity = []
for N in (10,100,1000):
    a = 1.0
    total = 0.0
    for j in range(N+1):
        total += a/(2*j+1)
        a *= (2*j+1)/(2*j+2)
    remainder = math.pi/2-total
    assert 0 < remainder < 1/math.sqrt(N)
    sanity.append({'N_inclusive': N, 'partial_sum': total, 'numerical_pi_over_2_difference': remainder, 'proved_tail_bound': 1/math.sqrt(N)})

H = 131*24*60**2
assert H == 11318400
result = {
    'scope': 'Independent local computational checks only; not a teaching acceptance or empirical-data verification.',
    'source_pdf_sha256': expected_pdf,
    'baseline_sha256': expected_baseline,
    'pages': pages,
    'exact_algebra_checks': checks,
    'exact_coefficients': coefficients,
    'pi_series_numerical_sanity': sanity,
    'half_life_conditional_arithmetic': {
        'literal_source_isotope_label': 'Polonium with superscript 120',
        'empirical_label_and_half_life_verified': False,
        'H_days_as_given': 131,
        'H_seconds': H,
        'k_per_second': math.log(2)/H,
        'mean_seconds': H/math.log(2),
        'mean_days': 131/math.log(2),
        'monetary_convention': 'one dollar per second; otherwise multiply duration by the specified payment rate'
    },
    'not_proved_by_computation': [
        'Non-elementarity of the Gaussian primitive',
        'Polonium isotope identity or empirical half-life',
        'Universal statement that nobody bets on particle decay',
        'Accuracy of exponential human survival or actual annuity product terms'
    ],
    'originals_unchanged_at_check_completion': sha256(SOURCE/'lec38.pdf') == expected_pdf and sha256(BASELINE) == expected_baseline
}
(OUT/'check-results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'all_assertions_passed': True, 'pages_checked': len(pages), 'output': str(OUT/'check-results.json')},indent=2))
