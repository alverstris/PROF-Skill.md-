D013 final prompts: sealed independent calculations

Status: every prompt P1–P6 and its subdemands solved before any supplied answer, hint or newly generated teaching was admitted. Input: prompts-only.txt, 2598 bytes, SHA-256 ad1c3da78e32b9f13939a31f773983d000ae2cc5a27eb55d40b34c7a2758aec8. Identity was checked before text decoding/display. This is an independent technical solution record, not a student-performance or delayed-retention observation.

Scope and premises

All variables and functions here are real-valued. Numerical decimals in P3 are treated as the exact stated numbers; no rounding uncertainty was supplied. No physical units are assigned in the packet. A slope has function-output units per input unit if units are later attached; these exercises use numerical real variables. The derivative of the exponential and its positivity, polynomial differentiation, elementary algebra and the stated baseline are available. MVT is also in the previously admitted original source. The theorem's proof is not requested in this packet. No new source was fetched and no supplied solution was used.

P1 — polynomial on [1,4]

The function f(x)=x² is a polynomial, hence continuous on the entire closed interval [1,4] and differentiable on the open interval (1,4). These are the two MVT hypotheses. The ordered distinct endpoints also satisfy 1<4. The derivative is f′(x)=2x.

The secant slope is (f(4)−f(1))/(4−1)=(16−1)/3=5. The equality f′(c)=5 is 2c=5, so c=5/2=2.5. This is strictly between 1 and 4. The linear equation has only this solution, so this is every eligible c; uniqueness follows from this particular derivative, not from MVT in general.

The secant through (1,1) and (4,16) has equation y=5x−4. The tangent at (5/2,25/4) has equation y−25/4=5(x−5/2), or y=5x−25/4. Their slopes are equal, so the lines are parallel. They are not asserted to be the same line. Equivalently, the instantaneous rate at c equals the average rate over [1,4].

P2 — hypotheses versus actual conclusions

P2(a). The function f(x)=|x| is continuous on [-1,2], including at zero and both endpoints. Away from zero, its derivative is −1 on (-1,0) and +1 on (0,2). At zero the left derivative is −1 and the right derivative is +1, so the derivative does not exist. The differentiability hypothesis on the whole open interval (-1,2) fails; the continuity hypothesis does not fail.

The endpoint values are f(-1)=1 and f(2)=2, giving secant slope (2−1)/(2−(-1))=1/3. Every existing interior derivative equals −1 or +1, neither of which is 1/3; at zero no derivative can supply the missing value. Thus MVT is inapplicable, and its conclusion independently fails for this function and this interval.

P2(b). The function is g(x)=x for 0≤x<1, with g(1)=2. It is differentiable on (0,1), with g′(x)=1 everywhere there. The limit of g(x) as x approaches 1 from the left is 1, whereas g(1)=2. Therefore g is not continuous at the right endpoint relative to [0,1], and the closed-interval continuity hypothesis fails. Endpoint differentiability is not required by MVT, so that is not the failed hypothesis.

The secant slope is (g(1)−g(0))/(1−0)=(2−0)/1=2. The only possible interior derivative value is 1. Hence no interior c has g′(c)=2: MVT is inapplicable, and its conclusion independently fails here too.

These two examples establish failure of the conclusion in these two cases. Failure of a sufficient hypothesis by itself establishes only that the theorem supplies no guarantee; it does not establish that the conclusion must fail for every function lacking that hypothesis.

Two optional explicit checks of that logical distinction, supplied here as reviewer reasoning rather than additional learner tasks: (i) h(x)=x² for 0≤x<1 and h(1)=1/2 is discontinuous at 1, but its secant slope on [0,1] is 1/2 and h′(1/4)=1/2. (ii) k(x)=|x|−x² on [-1,1] is not differentiable at zero, but its secant slope is zero and k′(-1/2)=k′(1/2)=0. Thus either kind of failed hypothesis can coexist with the MVT slope conclusion in other examples.

P3 — tangent estimate versus exact MVT identity

Take a=2 and x=2.2=11/5. The polynomial is continuous on [2,11/5] and differentiable on its interior. Its tangent-line expression at a is L(x)=f(2)+f′(2)(x−2)=4+4(x−2).

The four requested numerical results are:

1. Tangent-line estimate: L(11/5)=4+4(1/5)=24/5=4.8.
2. Exact value: f(11/5)=(11/5)²=121/25=4.84.
3. Signed error, exact minus estimate: 121/25−24/5=1/25=+0.04. The estimate is below the exact value.
4. MVT point: the secant slope is (121/25−4)/(1/5)=21/5=4.2. Since f′(c)=2c, c=21/10=2.1, strictly between 2 and 2.2. This is the only solution of the slope equation here.

The exact identity is f(2.2)=f(2)+f′(2.1)(0.2)=4+4.2(0.2)=4.84. The tangent estimate instead uses f′(2)=4, giving 4+4(0.2)=4.8. Replacing the slope at the interior MVT point by the endpoint slope changes the increment from 0.84 to 0.8; their difference is (4.2−4)(0.2)=0.04. The two slopes are unequal, so this replacement does not preserve the identity for this nonzero increment. Direct expansion gives the exact remainder h² in f(2+h)=4+4h+h²; for h=0.2 it is 0.04 and it tends to zero with h. No universal equality or error guarantee is inferred merely from writing a tangent estimate.

P4 — derivative signs and a false strict converse

Since p is differentiable everywhere on the real line, it is continuous on [2,5] and differentiable on (2,5). MVT gives p(5)−p(2)=3p′(c) for some c∈(2,5). This is strictly negative because p′(c)<0. Therefore p(5)<7.

On [-1,2], the same hypotheses hold, so p(2)−p(-1)=3p′(d) for some d∈(-1,2). This is strictly negative, giving p(-1)>7. Together, p(5)<7<p(-1). No exact values, uniform derivative bound or sign of p(5) is determined by the given information. More generally this reasoning on any a<b proves strict decrease on the real line.

The proposed converse, that every differentiable strictly increasing function has derivative strictly positive everywhere, is false. For q(x)=x³, q′(x)=3x² exists for every real x, but q′(0)=0.

To establish strict increase without a sketch or an invalid inference from nonnegative derivative alone, take any real u<v. Then q(v)−q(u)=(v−u)(v²+vu+u²). The first factor is positive. The second factor equals (v+u/2)²+3u²/4, a sum of nonnegative quantities that can vanish only if u=v=0. This is impossible when u<v, so the second factor is strictly positive. Consequently q(v)>q(u) for every u<v. Thus a differentiable strictly increasing function may have a zero derivative at a point. This example suffices to disprove the claimed strict positivity everywhere.

P5 — next exponential lower bound and the missing limit

Define H(t)=e^t−(1+t+t²/2+t³/6) for real t. Its value at zero is H(0)=1−1=0. Differentiating gives H′(t)=e^t−(1+t+t²/2). The stated preceding inequality makes H′(t)>0 whenever t>0.

For an arbitrary fixed x>0, H is continuous on [0,x] and differentiable on (0,x), being a difference of the differentiable exponential and a polynomial. MVT applied to H gives H(x)−H(0)=xH′(ξ) for some ξ∈(0,x). Here x>0 and ξ>0, hence H′(ξ)>0. Therefore H(x)>0, or e^x>1+x+x²/2+x³/6. At x=0 the two sides equal 1, so the strict inequality is replaced by equality. The proof just given is scoped to x>0; it makes no conclusion about negative x without a further argument.

For a fixed x>0 let S_N(x)=Σ from n=0 to N of x^n/n!. Arbitrarily many strict finite bounds S_N(x)<e^x do not by themselves prove lim as N→∞ of S_N(x)=e^x. Even if convergence of the partial sums is established, their limit might be strictly less than the common upper bound. For example, a_N=M−1−1/(N+1) is strictly below M for every integer N≥0, increases, and converges to M−1 rather than M.

The missing claim for the exponential series is that the remainder R_N(x)=e^x−S_N(x) tends to zero for the x in question; equivalently, one needs an upper control that squeezes the difference to zero, or another argument establishing convergence to e^x specifically. Strict positivity at every finite N does not supply that limit and does not contradict a zero limiting remainder. The frozen baseline already states the exponential series identity in FM27; that prior fact is separate from what this finite-lower-bound argument proves. No new derivation of the identity from these bounds alone is claimed here.

P6 — theorem retrieval and existence versus uniqueness

MVT statement: let a<b be real and let f:[a,b]→R be continuous on the whole closed interval [a,b] and differentiable at every point of the open interval (a,b). Then there is at least one c∈(a,b) such that f′(c)=(f(b)−f(a))/(b−a), equivalently f(b)−f(a)=f′(c)(b−a). The conclusion says that an instantaneous rate at some interior point equals the average rate over the interval, or that a tangent there is parallel to the endpoint secant. It does not require a unique c, continuity of f′, or differentiability at the endpoints.

For the equation define F(t)=e^t+t−2. The exponential and the linear function are differentiable on R, so F is continuous on [0,1] and differentiable on (0,1). F(0)=1+0−2=−1.

To justify the other endpoint's sign without assuming a numerical value of e, apply MVT to E(t)=e^t on [0,1]. It is continuous on the closed interval and differentiable on the open interval; E′(t)=e^t>0. Thus e^1−e^0=e^η for some η∈(0,1), which is positive. Since e^0=1, e^1>1 and F(1)=e^1−1>0. The allowed continuous-sign-change fact now gives at least one r strictly between 0 and 1 with F(r)=0. This is the existence argument.

For uniqueness, F′(t)=e^t+1>0 for every real t. If two distinct roots r<s lay in (0,1), F would be continuous on [r,s] and differentiable on (r,s). MVT would give 0=F(s)−F(r)=(s−r)F′(c)>0 for some c∈(r,s), a contradiction. Hence there is at most one root in (0,1). Combined with existence, there is exactly one. No root estimate is used or required.

The prompt's later/no-looking-back instruction is a study direction. This independent AI review states the theorem without opening teaching or supplied answers, but it does not demonstrate a human delayed retrieval trial, measured retention or erased prior knowledge.

Independent verification and remaining scope

Exact rational arithmetic independently checked P1's secant and c, both P2 secants, all four P3 results, and the error identity (f′(c)−f′(a))(x−a), with all assertions passing. Remaining checks are the explicit analytic derivations above: one-sided derivatives and endpoint limit in P2, positive factorisation in P4, derivative/MVT implication in P5, and two separate interval arguments in P6. No symbolic-software result is used as an unexplained proof.

No prompt is unresolved or lacks enough information for its requested conclusion. Ambiguity about physical units does not obstruct these dimensionless real-variable tasks. This seal establishes independent answer completion only. It does not assess the still-unadmitted teaching's explanations, hints, answers, source coverage, actual rendering or navigation, and it is not SASIS acceptance.
