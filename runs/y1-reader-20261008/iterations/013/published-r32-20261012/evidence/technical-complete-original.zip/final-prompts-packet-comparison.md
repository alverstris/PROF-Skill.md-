D013 final prompt packets: identity, comparison and completion

Both exact prompt-only inputs were validated by byte count and SHA-256 before their respective full text reads. Neither contains supplied hints or solutions. Their source paths are limited to the two expressly admitted files below; no other author file was opened.

| Input | Bytes | SHA-256 |
| --- | ---: | --- |
| /workspace/scratch/f9c0b7fc7e76/d013-clean-r32-20261012/author/prompts-only.txt | 2598 | ad1c3da78e32b9f13939a31f773983d000ae2cc5a27eb55d40b34c7a2758aec8 |
| /workspace/scratch/f9c0b7fc7e76/d013-clean-r32-20261012/author/prompts-only.md | 2761 | c5e8d386c2ea6698f02d0b1b4b5974a911ab84cc479ca1d63a02f4e01146f3c2 |

Preserved byte-identical copies are admitted-final-prompts-only.txt and admitted-final-prompts-only.md in this reviewer directory.

The Markdown file contains 35 inline mathematical payloads. Removing only the dollar/backtick opening and closing delimiters, translating the single backslash-le command with its terminating space to <=, the two backslash-lt commands with their terminating spaces to <, and the five backslash-gt commands with their terminating spaces to > produces exactly the entire original text file. The normalized SHA-256 is ad1c3da78e32b9f13939a31f773983d000ae2cc5a27eb55d40b34c7a2758aec8. Every prose word, mathematical datum, interval, condition, prompt ID and demanded response is preserved. This verifies the claimed markup-only change at source level; it does not claim live destination rendering preservation.

The complete independent solution file was written after the TXT read and before the Markdown packet's admission. It has been retained unchanged. The final Markdown introduces no mathematical or response demand requiring a new calculation. The 42-item demand map covers all six prompts and every requested subpart, including domains, hypothesis checks, exact numerical results, sign and limit reasoning, and the separate existence/uniqueness arguments. All are solved; no missing information blocks a requested conclusion.

The complete solution SHA-256 is c2dd799e6d824631e1c988871eebd76284b97736bb102d7a13d7acfa26dab07c. Exact rational arithmetic verified the numerical results and signed-error identity; explicit analytic proofs and counterexamples are preserved in the solution record. No supplied answer, new teaching, author reasoning or other review was consulted. No result was communicated to an author. Root's separate calculations were not accessed.

This package seals independent answer completion before teaching access. It does not certify explanatory adequacy, source coverage, rendered output, navigation or SASIS acceptance of the unadmitted new document. The P6 later/no-looking-back study instruction is not treated as measured human retention. Access restrictions are procedural; no technical isolation or memory-erasure claim is made.

Next: await root's admission of the entire frozen new teaching, then read and review every constituent against the already sealed independent work and operative r32 requirements.
