D013 technical reviewer: operative PROF r32 admission

Status: complete package admission on 2026-10-12; independent final-prompt solutions and frozen-teaching review remain pending because neither has been admitted. This is preparation for technical review, not SASIS, teaching acceptance, or evidence of student learning.

Published identity

The operative version is 2026-10-12-r32 from alverstris/PROF-Skill.md-, release pin 02627f9dc0055946f0883d6a9c243375f6fe70a2. Root explicitly confirmed that all 36 published files at this pin matched the local package by bytes, SHA-256 and Git blob identity, and that all 34 operative internal hash references matched. I did not perform remote verification. Publication identity is root-confirmed, not independently fetched by this reviewer. The local folder and external manifest retain their historical candidate labels; those labels do not negate the attributed published identity.

Admitted package: /workspace/scratch/f9c0b7fc7e76/d008-clean-r31-20261011/candidate-prof

Admitted manifest: /workspace/scratch/f9c0b7fc7e76/d008-clean-r31-20261011/publication/candidate-package-manifest.json

Manifest SHA-256: f4f12aeb49c55a581a1b0f1820f06d66448ee0b3fa7345838865f977e1402dfe

Own local verification and access

I personally verified all 36 manifest-listed files, totaling 901678 bytes, against their byte counts, SHA-256 digests and Git blob SHA-1 identities. I also checked the 34 bundled operative internal hash references: four profile subject entries, 19 profile file hashes, three profile control hashes, four release subject entries, the release combined-baseline hash, and three bundled chemistry freeze entries. All matched. Historical chemistry Markdown entries absent from the admitted package and outside source/archive hashes were not followed or relabelled as operative files.

All 30 non-reused files were fully read as text, including the complete SKILL, execution/recovery protocol, domain and production guidance, SASIS operating and rewrite instructions, state-helper documentation and full Python source, provenance/research records, release metadata, course registry, full lecture-selection CSV through EOF, YAML, SVG source, and LaTeX assets. The full reading includes support material regardless of whether it directly applies to D013. The SVG was read as source, not visually rendered; the LaTeX sample was read, not compiled; the state helper was read, not run to validate any unreceived teaching. Historical research records were read as attributed package evidence, without opening their external sources or claiming new verification of literature, specifications, downloads or current website contents.

Six files reuse the already completed full baseline reading: the aggregate baseline, its cover and four subject payloads. The exact aggregate remains 247840 bytes with SHA-256 3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5, byte-identical to the baseline previously read contiguously through EOF. The cover is an exact byte prefix. The four subject files have newline differences from their aggregate occurrences; I confirmed complete matching substrings after changing only CRCRLF, CRLF and CR to LF. This is full content reuse after verified equivalence, not a claim that these individual raw-byte files were freshly read or were previously identical raw substrings. Exact positions and normalized hashes are recorded in the access JSON. Baseline package support records do not add learner prerequisites beyond the actual frozen baseline.

The original source and baseline preparation reports and their access records retain their prior sealed hashes. The current package admission does not alter them. The original source preparation covers all five pages and images of lec14.pdf; its findings remain separately sealed. No source findings were sent to an author.

Reading evidence and recovery

prof-r32-admission-access.json provides a file-by-file inventory with exact byte ranges, hashes, read/reuse dispositions and available tool-output identifiers. The initially truncated SKILL output was not counted as full reading: two bounded rereads recovered all bytes. A failed transport on a script read was retried successfully without missing coverage. After context compaction, I reread the entire SKILL and execution protocol in bounded contiguous ranges before finishing admission. The lecture index was read in five contiguous ranges, including the final bytes [69150,72388). The original reading and recovery records are retained in prof-r32-read-progress.json, now complete. Hashes establish identity, not semantic adequacy.

Restrictions and current limits

Only the admitted package, its manifest, the previously admitted full baseline and my own original preparation were accessed for this stage. No other D008 workspace content, teaching, reviewer report, root receipt, queue/history, old draft or author reasoning was opened. Package-internal research/provenance and original selection registry are admitted support material; reading them is not reading the current run queue or prior teaching. No browser, network or GitHub action was performed. These are instruction-based access restrictions, not technical isolation or erased memory/pretraining.

No new D013 final prompt packet or teaching has been received, solved, read or approved. The next permitted step is admission of the exact final-prompt-only packet, complete independent solutions and a solution seal before access to any newly generated teaching. After that seal and explicit full freeze, review every frozen constituent, including complete main text, figures, prompts, hints, solutions and ending. Report technical, prerequisite-route and source-coverage findings separately from destination rendering/navigation and SASIS evidence. Full rendering/navigation acceptance cannot be claimed from this package admission or from source-only checks.
