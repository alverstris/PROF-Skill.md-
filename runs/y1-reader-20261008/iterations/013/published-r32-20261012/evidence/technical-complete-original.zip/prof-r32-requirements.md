D013 operative r32 requirements for staged technical review

Scope and role

Use the complete published r32 package identity admitted in prof-r32-admission.md. This file is a recovery index of requirements actually read; it does not replace the operative package. I am the independent technical reviewer, not SASIS. Original source coverage includes all five pages, their figures, examples and consequential qualifications. An author-selected route cannot silently narrow assigned source coverage. Review conclusions must identify the exact frozen artifact and evidence inspected.

Stage gates

1. Await an exact final-prompt-only packet. Check its identity and complete scope. Independently solve every final response task, including optional or later tasks, before seeing teaching, hints or proposed solutions. Preserve full workings, assumptions, qualifications and unresolved information. Seal the complete prompt solutions before teaching access. This ordering is a parent-imposed access condition for this reviewer, consistent with PROF's independent-answer audit.
2. Admit the complete newly frozen teaching only after the solution seal. Read all constituents in their actual route, including figures, help, full answers and ending. Keep original frozen bytes unchanged. Compare proposed answers to the independent solutions and independently check every consequential claim, not only the exercises.
3. Reconstruct consequential learner-facing moves from the exact full baseline and earlier teaching. Name the available premise and connection. Reviewer expertise, source knowledge or a correct independent answer cannot fill a missing teaching bridge. Later text cannot retroactively license an earlier required use; valid independent later passages remain reviewable when a dependency is blocked.
4. Return precise findings with location, obligation, technical/prerequisite/source evidence, consequence, scope and necessary repair. Separate established failures, disproved concerns and unverified checks. Preserve a clean cycle if no material failure is verified; do not invent one.
5. During explicit self-iteration, never patch the teaching, including mathematical, local, representation or navigation defects. Root diagnoses supported issues and repairs the reusable PROF trigger, action and observable check, publishes and verifies the full revised package, then regenerates with a fresh author and reader. Publication alone is not teaching acceptance. Do not send source findings to the author before full teaching freeze.

Teaching acceptance duties

T1: At first consequential use, establish purpose, meaning, relevant conditions and a usable instance. A new technical hypothesis needs its constrained object and a usable recognition/check, rather than only familiar words or a technical synonym.

T2: Teach unfamiliar representations by meaningful parts, roles/types, grouping and composition, both reading and construction. Preserve the original form and demonstrate the mapping. Include applicable domain, units, indices, ordering and evaluation context.

T3: Identify the warrant for consequential transitions: definition, assumption, law, deduction, approximation, convention, contract or author choice. Check implication direction and governing conditions. Defined inputs alone do not guarantee that a licensed operation or result exists. A finite approximation and its limit need distinct claims; tending to zero is not equality to zero at every finite stage.

T4: A newly taught procedure or reasoning capability needs connected representative worked reasoning, including consequential choices and interpretation. Split at genuine prerequisite boundaries and reconnect the whole operation.

T5: Study notes normally require an early supported attempt and a meaningful changed application. A controlling condition, representation, method or inference must change; changed numbers alone show only numerical practice. Supply incidental prerequisites. No fixed exercise quota follows.

T6: Every retained response prompt, including optional prompts, requires a target capability and response criterion. Distinguish a right answer with a wrong reason through justification or a discriminating variation. Avoid hidden prerequisites, decorative prompts and method-revealing labels in method-selection tasks.

T7: Every retained response prompt requires a matched useful hint and complete reasoned solution unless the user expressly withholds them. A hint should advance the stuck decision. Open tasks require criteria and a reasoned example with acceptable variation. Separate hints from full answers; do not invent observed learner mistakes.

T8: Durable study normally needs a later retrieval/application opportunity and a distinction between retained recall and new-task transfer. Spacing advice is adjustable, not a universal optimum. No unrequested reminders or study systems.

T9: Compress steps supported by evidenced baseline familiarity and bridge local novelty. Use visual/representational relationships for an actual inference, with nearby mapping and stated analogy limits. Avoid redundant demands and unjustified expansion.

T10: Independently verify significant claims, all full answers and source correspondence. Choose discriminating algebraic, sign, dimensional, numerical, limiting and boundary checks. Test the scope of qualitative summaries themselves; correct examples cannot establish an unconditional claim. Track actual source identity and read scope.

T11: Verify the requested real output and route. Teaching prose has no bold or italic styling, including headings, captions and table headers; Markdown uses plain paragraph labels. Inspect all final figure canvases at usable size. Attempts, hints and solutions must match and be reachable with usable separation. For markup math, inventory every source expression, then compare every intended operand, operator and grouping with its actual rendered result, counting absent/raw expressions and renderer errors. GitHub uses dollar/backtick inline delimiters, math fences outside disclosures, strict comparison commands with terminating spaces, supported command forms and document-specific sibling anchors. Actual settled forward/return clicks must reach visible intended targets, including later targets from already fragmented URLs. Source parsing, href presence or a substitute renderer is insufficient. If LaTeX/PDF applies, compile, inspect every page/help destination and freshly extracted bundle. No such destination check has occurred in this admission.

T12: Review every required portion, the full integrated route and help, and all applicable duties. Distinguish teaching adequacy, technical correctness, rendered quality and portability. Do not claim human understanding, learning improvements or platform tests that were not observed.

Baseline and source handling

Reuse the exact previously fully read baseline identity and sealed preparation; do not infer its coverage from titles. Its four subjects include useful algebra, calculus, proof and mechanics premises, with specific limits recorded separately. A package research record or expert recollection does not silently extend the learner's baseline. Preserve course conventions where clear; a technical source error needs independent checking, not a request that the learner decide scientific truth. Reopen necessary original passages if details have fallen out of working context. Own source findings remain in the separate source preparation and are not transferred to authors before freeze.

Evidence, recovery and limits

Record each requirement's trigger, status, exact witness, revision and check method. Allowed states are pending, pass, fail, unverified, not_applicable and waived_by_user; unknown is not false. A heading, fresh digest or another agent's assurance cannot establish a semantic pass. The state-helper check only detects recorded presence/freshness, not undeclared scope or explanatory sufficiency. This admission reads the helper but does not manufacture a teaching project or execute a fictitious acceptance gate.

On recovery reread the full SKILL and execution protocol and reload exact constraints, current records and needed original definitions. Preserve failed evidence and unresolved limitations. Do not speculate about memory erasure or technical isolation. Root-confirmed publication remains attributed; local integrity checks are my own. Live browsing is not authorized for this reviewer, so live destination evidence must remain unverified here unless a later authorized stage supplies or permits the appropriate check. This limit does not waive T11 or permit global acceptance.

SASIS remains a separate fresh reader with only complete baseline and complete frozen teaching as subject inputs, launched without inherited conversation. It reads every substantive step in order rather than grading a task battery. The technical reviewer may use original sources and PROF; that broader scope must not be misrepresented as SASIS's two-input restriction. Baseline/source/package reading is preparation, not the still-pending new D013 cycle result.
