from pathlib import Path
import json,hashlib,collections
p=Path('/workspace/scratch/f9c0b7fc7e76/d013-clean-r33-20261012');r=json.loads((p/'reader-inputs/reader-route.json').read_text());log=[json.loads(x) for x in (p/'sasis/access-log.jsonl').read_text().splitlines()]
success=[x for x in log if x['event'] in ['text_read','figure_read_for_immediate_view']]
checks=[];expected=[]
for i,(a,b) in enumerate(r['baseline']['ordered_ranges'],1):expected.append({'label':f'B{i}','path':r['baseline']['path'],'range':[a,b]})
for i,s in enumerate(r['ordered_document_route'],1):expected.append({'label':f'D{i:02}','path':s['path'],'range':[s.get('start_byte',0),s.get('end_byte',Path(s['path']).stat().st_size)]})
assert len(expected)==len(success)==41
for x,y in zip(expected,success):
 assert x['path']==y['path'] and x['range']==y['range'],(x,y)
 b=Path(y['path']).read_bytes()[y['range'][0]:y['range'][1]];assert hashlib.sha256(b).hexdigest()==y['sha256']
 checks.append({'step':x['label'],'range':y['range'],'hash_pass':True})
figures=[x for x in log if x['event']=='figure_view_completed'];assert len(figures)==3
out={'all_successful_routed_reads_exact_and_ordered':True,'route_checks':checks,'actual_event_counts':dict(collections.Counter(x['event'] for x in log)),'figure_view_receipts':figures,'preserved_failure':[x for x in log if x['event']=='failed_retrieval_command'],'strict_clean_admission':False,'material_execution_failure':True,'recovered_coverage_is_not_first_exposure_repair':True,'content_verdict':'Original reader reports no established substantive teaching defect, but this cannot constitute an admitted clean SASIS pass.','limits':'Failed Python compiler byte extent unknown; diagnostic showed only already-read text. Shared tools were instruction-confined, not technically restricted.'}
(p/'review/sasis-lead-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['route_checks','figure_view_receipts']},indent=2))
