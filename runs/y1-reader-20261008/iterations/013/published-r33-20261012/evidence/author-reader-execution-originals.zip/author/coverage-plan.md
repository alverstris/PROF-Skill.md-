D013 r33 coverage and prerequisite plan

Product: standalone repo-native GitHub Markdown, no heading emphasis, separate hints and solutions; all source pages required, no PDF deliverable.
Capability: read/apply/justify MVT, distinguish exact existence from tangent approximation, prove monotonicity/constancy and derivative-based inequalities.
Baseline read fully in nine byte-contiguous bounded chunks (read-log.json), CRCRLF preserved in raw source. Relevant established premises: Mathematics differentiation definition/tangent line/product-sum rules/exponential positivity, log derivative/intervals/strict comparison; FM01 induction; FM27 real exponential series identity, but no convergence proof/remainder theorem. Continuity meaning and recognition, MVT and geometric proof warrant need local teaching.

C1 Original p2 MVT and Fig1 -> main sections continuity, theorem, x² example, P1, geometric proof; introduce EVT as explicit established foundation and show stationary extrema derivative warrant.
C2 p2–3 absolute-value failure and Fig2 -> main hypothesis check with slopes, P2; strict derivative and domain interval distinction.
C3 p3 trip -> main 1000-mile/3-hour differentiable distance model; exact speed and conditions.
C4 p3–4 identities and Fig3 -> main exact MVT vs tangent approximation, exact squared example and signed error, P3 radical derivative bounds.
C5 p4 sign consequences -> main all-three proofs and source correction, interval hypothesis, P2.
C6 p5 inequalities -> main f1,f2,f3 and cubic chain, zero values, x>0 restriction, finite sums/series preview with FM27 distinction, P4 changed comparison, P5 retrieval/induction.

T5–T8 applicable: notes teach use and durable study, all five tasks require matched distinct hints and reasoned solutions. P1 early supported attempt; P2 hypothesis/method discrimination; P3 switches curvature and uses derivative bounds; P4 reverses input order; P5 delayed retrieval and proof/convergence distinction. All tasks generated.
No unresolved course convention; decreasing typo is technical source error, independently verifiable by definition and f=-x. No exam provenance claimed.
