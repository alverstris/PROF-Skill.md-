from pathlib import Path
import hashlib,json,re,datetime
w=Path('.').resolve(); teach=w/'teaching'; out=w/'reader-inputs';out.mkdir(exist_ok=True);(w/'sasis').mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
files=[]
for p in sorted(teach.rglob('*')):
 if p.is_file():
  b=p.read_bytes();files.append({'path':str(p),'relative':str(p.relative_to(teach)),'bytes':len(b),'sha256':h(b),'git_blob':hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()})
manifest={'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'immutable':True,'operative_prof_commit':'5f353a3a6b47629effdc2e13772f9de357c9c06d','files':files,'prompt_only':{'path':str(w/'review/prompts-only.txt'),'bytes':2571,'sha256':'094b882c08e16c8bb0bf4425e4b98c3283b40a573ef92c73b806b92d2c198147'}}
(w/'whole-freeze-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,src in [('student-baseline.txt',w/'inputs/student-baseline.txt'),('student-role.txt',w/'verified-prof/references/sasis/student-role.txt')]: (out/name).write_bytes(src.read_bytes())
route=[]
def add_text(p,s,e):
 b=p.read_bytes()
 # split oversized text only at paragraph boundaries, maintaining exact bytes
 while e-s>7000:
  c=b.rfind(b'\n\n',s+2500,s+7000)+2
  assert c>s
  route.append({'kind':'text','path':str(p),'start_byte':s,'end_byte':c,'sha256_of_slice':h(b[s:c])});s=c
 if e>s:route.append({'kind':'text','path':str(p),'start_byte':s,'end_byte':e,'sha256_of_slice':h(b[s:e])})
p=teach/'main.md';b=p.read_bytes();events=[]
for m in re.finditer(rb'<img src="([^"]+)"[^>]+>\n',b):events.append((m.start(),m.end(),'figure',m.group(1).decode()))
for m in re.finditer(rb'<a id="d013-main-p[1-5]"></a>',b):
 end=b.find(b'\n\n',b.find(b'[Hint P',m.end()))+2
 events.append((m.start(),end,'task',None))
s=0
for a,z,k,arg in sorted(events):
 add_text(p,s,a);add_text(p,a,z)
 if k=='figure':route.append({'kind':'figure','path':str(teach/arg),'sha256':h((teach/arg).read_bytes())})
 s=z
add_text(p,s,len(b))
for n in ['hints.md','solutions.md']:
 p=teach/n;b=p.read_bytes();starts=[m.start() for m in re.finditer(rb'<a id="d013-(?:hint|solution)-p[1-5]"></a>',b)];cuts=[0]+starts+[len(b)]
 for s,e in zip(cuts,cuts[1:]):add_text(p,s,e)
for i,r in enumerate(route,1):r['step']=i
baseline=(out/'student-baseline.txt').read_bytes();ranges=json.loads((w/'author/read-log.json').read_text())['baseline']['ranges']
metadata={'range_convention':'0-based half-open UTF-8 raw byte offsets; text reads print every byte decoded. Baseline has CRCRLF and CRLF; use bytes, not splitlines to slice.','baseline':{'path':str(out/'student-baseline.txt'),'bytes':len(baseline),'sha256':h(baseline),'ordered_ranges':ranges},'document_files':files,'ordered_document_route':route,'role':{'path':str(out/'student-role.txt'),'bytes':len((out/'student-role.txt').read_bytes()),'sha256':h((out/'student-role.txt').read_bytes())},'output_directory':str(w/'sasis'),'isolation':'Instruction-confined only; broad tools remain available; no technical pretraining erasure.'}
(out/'reader-route.json').write_text(json.dumps(metadata,indent=2)+'\n')
# Exact source-byte inventory and navigation listing for destination owner.
expressions=[];links=[]
for name in ['main.md','hints.md','solutions.md']:
 p=teach/name;b=p.read_text(); matches=list(re.finditer(r'\$`(.*?)`\$|```math\n(.*?)\n```',b,re.S))
 for i,m in enumerate(matches,1): expressions.append({'file':name,'item':i,'line':b[:m.start()].count('\n')+1,'kind':'inline' if m.group(1)!=None else 'display','payload':m.group(1) if m.group(1)!=None else m.group(2)})
 for m in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)',b):links.append({'file':name,'label':m.group(1),'href':m.group(2)})
(w/'review/source-expression-inventory.json').write_text(json.dumps(expressions,indent=2)+'\n');(w/'review/navigation-inventory.json').write_text(json.dumps(links,indent=2)+'\n')
print('FROZEN',len(files),'files',sum(x['bytes'] for x in files),'bytes; route',len(route),'steps; math',len(expressions));print('manifest sha256',h((w/'whole-freeze-manifest.json').read_bytes()));print('route sha256',h((out/'reader-route.json').read_bytes()))
