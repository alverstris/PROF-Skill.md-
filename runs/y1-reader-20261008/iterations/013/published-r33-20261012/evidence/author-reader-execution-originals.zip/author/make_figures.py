import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path
out=Path('teaching/figures');out.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.size':12,'font.weight':'normal','axes.labelweight':'normal','axes.titleweight':'normal','figure.facecolor':'white'})
def finish(fig,ax,name):
 ax.spines[['top','right']].set_visible(False); ax.set_xlabel('input');ax.set_ylabel('output');ax.grid(alpha=.16);fig.subplots_adjust(left=.12,right=.96,bottom=.15,top=.9);fig.savefig(out/name,dpi=140);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.8));t=np.linspace(0,2,300)
ax.plot(t,t*t,color='#172a3a',lw=2.5,label='curve: y = t²');ax.plot(t,2*t,color='#2869b1',lw=2,label='secant: y = 2t');ax.plot(t,2*t-1,color='#b04035',lw=2,label='parallel tangent: y = 2t − 1');ax.plot(t,2*t-1.7,ls=':',color='#777777',lw=1.5,label='line shifted below contact')
ax.scatter([0,1,2],[0,1,4],color='#172a3a',zorder=5);ax.axvline(1,ymin=0,ymax=.46,color='#888',lw=.8,ls='--');ax.set_xticks([0,1,2],['a = 0','c = 1','b = 2']);ax.set_ylim(-1.9,4.4);ax.legend(loc='upper left',fontsize=10,frameon=False);finish(fig,ax,'mvt-geometry.png')
fig,ax=plt.subplots(figsize=(8,4.8));t=np.linspace(-1,2,300)
ax.plot(t,np.abs(t),color='#172a3a',lw=2.5,label='curve: y = |t|');ax.plot(t,t/3+4/3,color='#2869b1',lw=2,label='secant slope: 1/3');ax.plot(t,t/3,color='#b04035',lw=2,label='parallel line touching the corner');ax.plot(t,t/3-.45,ls=':',color='#777',lw=1.5)
ax.scatter([-1,0,2],[1,0,2],color='#172a3a',zorder=5);ax.text(-.93,.35,'slope −1',color='#172a3a');ax.text(1.2,1.0,'slope +1',color='#172a3a');ax.set_xticks([-1,0,2]);ax.set_ylim(-.85,2.5);ax.legend(loc='upper left',fontsize=10,frameon=False);finish(fig,ax,'corner.png')
fig,ax=plt.subplots(figsize=(8,4.8));t=np.linspace(.75,1.65,300)
ax.plot(t,t*t,color='#172a3a',lw=2.5,label='curve: y = t²');ax.plot(t,2*t-1,color='#2869b1',lw=2,label='tangent at a = 1: y = 2t − 1');ax.scatter([1,1.5,1.5],[1,2.25,2],color=['#172a3a','#172a3a','#2869b1'],zorder=5)
ax.annotate('',xy=(1.5,2.25),xytext=(1.5,2),arrowprops={'arrowstyle':'<->','color':'#b04035'});ax.text(1.53,2.10,'error = 0.25',color='#b04035',fontsize=11);ax.set_xticks([1,1.5],['a = 1','x = 1.5']);ax.set_yticks([1,2,2.25]);ax.set_ylim(.4,2.95);ax.legend(loc='upper left',fontsize=10,frameon=False);finish(fig,ax,'approximation.png')
