from pathlib import Path
import json,hashlib,zipfile,shutil
p=Path('/workspace/scratch/f9c0b7fc7e76/d013-clean-r33-20261012');prefix='runs/y1-reader-20261008/iterations/013/published-r33-20261012/'
shutil.copyfile('/workspace/scratch/f9c0b7fc7e76/root-review-d013-r34-publication/candidate-review.json',p/'evidence/root-candidate-review.json')
# Preserve complete author/reader/probe/dependency records without altering originals.
files=[]
for directory in ['author','review','.prof-state','reader-inputs','sasis','repair-probe']:
 for f in sorted((p/directory).rglob('*')):
  if f.is_file() and f.name!='student-baseline.txt':files.append(f)
for f in ['package-admission.json','internal-hash-verification.json','input-identities.json','publication-initial.json','publication-initial-readback.json','whole-freeze-manifest.json']:
 if (p/f).exists():files.append(p/f)
for f in sorted((p/'evidence').iterdir()):
 if f.is_file() and f.suffix=='.json':files.append(f)
archive=p/'evidence/author-reader-execution-originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.writestr(str(f.relative_to(p)),f.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for f in files:assert z.read(str(f.relative_to(p)))==f.read_bytes()
entries=[]
def add(local,path):
 b=local.read_bytes();entries.append({'path':path,'local':str(local),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'sha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
for x in json.loads((p/'review/candidate-package-manifest.json').read_text())['files']:add(p/'candidate-prof'/x['path'],x['path'])
for f in sorted((p/'teaching').rglob('*')):
 if f.is_file():add(f,prefix+str(f.relative_to(p)))
for rel in ['whole-freeze-manifest.json','package-admission.json','internal-hash-verification.json','publication-initial.json','publication-initial-readback.json','review/whole-disposition.md','review/issues.json','review/sasis-lead-audit.json','review/sasis-original-preservation.json','review/full-check.json','review/topic-check.json','review/candidate-package-manifest.json','review/candidate-internal-hashes.json','review/candidate-repair.diff','review/lead-recovery-read-record.json','review/earlier-reader-dependencies/report.md','review/earlier-reader-dependencies/findings.json','review/earlier-reader-dependencies/readback.json','repair-probe/PROBE_REPORT.txt','repair-probe/test_results.json','repair-probe/live_verification.json','repair-probe/sealed_inventory.json','evidence/root-content-and-disposition.md','evidence/root-final-disposition.json','evidence/root-candidate-review.json','evidence/root-probe-final-review.json','evidence/author-reader-execution-originals.zip','evidence/d008-d016-d106-d107-prepared-20261012.zip']:
 add(p/rel,prefix+rel)
for f in sorted((p/'sasis').iterdir()):
 if f.is_file():add(f,prefix+str(f.relative_to(p)))
for f in sorted((p/'evidence/root-complete-review').iterdir()):
 if f.is_file():add(f,prefix+str(f.relative_to(p)))
assert len({x['path'] for x in entries})==len(entries)
(p/'release-plan.json').write_text(json.dumps({'parent':'2c7c04d1af657f409cf416868e792c67b261084c','base_tree':'5d7411615c58776b49ee2246b7db2cb65fd33808','entries':entries},indent=2)+'\n')
print(json.dumps({'entries':len(entries),'bytes':sum(x['bytes'] for x in entries),'archive_bytes':archive.stat().st_size,'original_archive_members':len(files),'package_files':36,'queue_unchanged':True}))
