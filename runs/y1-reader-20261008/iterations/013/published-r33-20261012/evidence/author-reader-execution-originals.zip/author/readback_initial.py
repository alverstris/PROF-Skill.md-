from pathlib import Path
import subprocess,json,hashlib,datetime
w=Path('.').resolve();clone=Path('/workspace/scratch/f9c0b7fc7e76/prof-iteration');p=json.loads((w/'publication-initial.json').read_text());shas=[x['sha'] for x in p['entries']];fetch=subprocess.run(['git','fetch','origin','--stdin'],cwd=clone,input=('\n'.join(shas)+'\n').encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
subprocess.run(['git','fetch','origin',p['commit']],cwd=clone,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
requests=''.join(f"{p['commit']}:{x['path']}\n" for x in p['entries']).encode();data=subprocess.run(['git','cat-file','--batch'],cwd=clone,input=requests,stdout=subprocess.PIPE,check=True).stdout;i=0;rows=[]
prefix='runs/y1-reader-20261008/iterations/013/published-r33-20261012/'
for x in p['entries']:
 e=data.index(b'\n',i);hdr=data[i:e].decode().split();i=e+1;assert len(hdr)==3,hdr;sha,kind,n=hdr;assert kind=='blob';n=int(n);b=data[i:i+n];i+=n;assert data[i:i+1]==b'\n';i+=1
 local=w/x['path'].removeprefix(prefix);expected=local.read_bytes();assert b==expected;assert sha==x['sha'];rows.append({'path':x['path'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':sha,'actual_published_byte_match':True})
assert i==len(data)
r={'commit':p['commit'],'tree':p['tree'],'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_pass':True,'file_count':len(rows),'files':rows,'method':'Exact intended blobs prefetched read-only with git fetch origin --stdin; pinned commit fetched; git cat-file --batch explicit commit:path binary full-byte comparisons.'}
(w/'publication-initial-readback.json').write_text(json.dumps(r,indent=2)+'\n');print('PASS',p['commit'],len(rows),'files',sum(x['bytes'] for x in rows),'actual published bytes')
