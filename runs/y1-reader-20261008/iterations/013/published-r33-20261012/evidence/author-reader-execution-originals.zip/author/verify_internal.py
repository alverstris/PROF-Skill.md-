from pathlib import Path
import json,hashlib,sys
package=Path(sys.argv[1]);r=package/'references/sasis';checks=[]
def ck(decl,p,h):
 b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==h,p
 checks.append({'declaration':decl,'target':str(p.relative_to(package)),'bytes':len(b),'sha256':h})
p=json.loads((r/'profile-manifest.json').read_text())
for x in p['subject_files']:ck('profile subject_files',r/x['path'],x['sha256'])
for x,h in p['file_hashes'].items():ck('profile file_hashes',r/p['file_hashes_base_directory']/x,h)
for x,h in p['control_file_hashes'].items():ck('profile control_file_hashes',r/x,h)
r2=r/'ocr-baseline-20261007';d=json.loads((r2/'release-manifest.json').read_text())
for x in d['subjects']:ck('release subjects',r2/x['path'],x['sha256'])
ck('release combined',r2/'student-baseline.txt',d['combined_baseline_sha256'])
r3=r2/'chemistry';d=json.loads((r3/'freeze-manifest.json').read_text())
for x in d['files']:
 if (r3/x['path']).exists():ck('chemistry bundled freeze',r3/x['path'],x['sha256'])
assert len(checks)==34
print(json.dumps({'package':str(package),'all_pass':True,'declarations':len(checks),'checks':checks},indent=2))
