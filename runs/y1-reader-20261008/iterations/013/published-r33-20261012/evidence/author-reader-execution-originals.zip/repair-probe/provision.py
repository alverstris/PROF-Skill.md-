#!/usr/bin/python3
"""Provision immutable-by-procedure synthetic routes; no subject input accepted."""
import base64
import hashlib
import json
from pathlib import Path
import struct
import uuid
import zlib

ROOT = Path(__file__).resolve().parent
FIRST = b"SYNTHETIC FIXTURE ONLY.\nFirst bounded slice: cobalt square, amber circle.\n"
SECOND = b"Second bounded slice: fixture route is complete. No teaching content.\n"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def png_bytes():
    width, height = 160, 100
    scanlines = bytearray()
    for y in range(height):
        scanlines.append(0)
        for x in range(width):
            if x < 4 or y < 4 or x >= width - 4 or y >= height - 4:
                rgb = (20, 24, 35)
            elif x < 20 and y < 20:
                rgb = (190, 40, 150)
            elif x < 80:
                rgb = (42, 99, 196)
            else:
                rgb = (238, 177, 48)
            scanlines.extend(rgb)
    def chunk(tag, payload):
        return struct.pack(">I", len(payload)) + tag + payload + struct.pack(">I", zlib.crc32(tag + payload) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(bytes(scanlines), 9)) + chunk(b"IEND", b"")


def base_route():
    full_text = FIRST + SECOND
    figure = png_bytes()
    return {"version": 1, "steps": [
        {"id": "text-01", "type": "text", "stage": "baseline", "file": "synthetic_text.txt", "source_bytes": len(full_text),
         "start": 0, "end": len(FIRST), "sha256": sha(FIRST)},
        {"id": "figure-01", "type": "figure", "stage": "baseline", "file": "synthetic_figure.png", "bytes": len(figure), "sha256": sha(figure)},
        {"id": "inspect-01", "type": "inspection_receipt", "stage": "baseline", "figure_step": "figure-01"},
        {"id": "text-02", "type": "text", "stage": "teaching", "file": "synthetic_text.txt", "source_bytes": len(full_text),
         "start": len(FIRST), "end": len(full_text), "sha256": sha(SECOND)},
    ], "revisits": [{"id": "revisit-text-01", "target": "text-01"}]}


def provision(destination, route=None, bad_route_pin=False):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=False)
    for child in ["fixtures", "delivered", "receipts"]:
        (destination / child).mkdir()
    (destination / "fixtures" / "synthetic_text.txt").write_bytes(FIRST + SECOND)
    (destination / "fixtures" / "synthetic_figure.png").write_bytes(png_bytes())
    route = route if route is not None else base_route()
    canonical = json.dumps(route, sort_keys=True, separators=(",", ":")).encode()
    pin = sha(canonical)
    executable = (ROOT / "launcher_template.py").read_text()
    executable = executable.replace("__ROOT_LITERAL__", repr(str(destination)))
    executable = executable.replace("__ROUTE_BASE64_LITERAL__", repr(base64.b64encode(canonical).decode()))
    executable = executable.replace("__ROUTE_HASH_LITERAL__", repr("0" * 64 if bad_route_pin else pin))
    (destination / "retrieve-next").write_text(executable)
    (destination / "route.json").write_text(json.dumps(route, indent=2, sort_keys=True) + "\n")
    state = {"run_id": uuid.uuid4().hex, "route_sha256": pin, "next_index": 0, "awaiting": None}
    (destination / "state.json").write_text(json.dumps(state, sort_keys=True) + "\n")
    manifest = {"route_sha256": pin, "launcher_sha256": sha(executable.encode()),
                "synthetic_text_sha256": sha(FIRST + SECOND), "synthetic_figure_sha256": sha(png_bytes())}
    (destination / "provision_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    (destination / "retrieve-next").chmod(0o555)
    (destination / "route.json").chmod(0o444)
    (destination / "provision_manifest.json").chmod(0o444)
    return destination


if __name__ == "__main__":
    print(provision(ROOT / "verified-live"))
