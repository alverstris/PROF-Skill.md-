#!/usr/bin/python3
"""Verify retained synthetic live evidence and write an integrity inventory."""
import base64
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LIVE = ROOT / "verified-live"
checks = []


def check(name, passed, **evidence):
    checks.append({"check": name, "passed": bool(passed), **evidence})


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    route = json.loads((LIVE / "route.json").read_text())
    manifest = json.loads((LIVE / "provision_manifest.json").read_text())
    state = json.loads((LIVE / "state.json").read_text())
    audit = [json.loads(x) for x in (LIVE / "audit.jsonl").read_text().splitlines()]
    view = json.loads((LIVE / "actual_view_tool_record.json").read_text())
    receipt = json.loads((LIVE / "receipts" / "figure-01.json").read_text())
    tests = json.loads((ROOT / "test_results.json").read_text())
    check("synthetic_tests", tests["all_passed"] and tests["checks_count"] == 138)
    canonical = json.dumps(route, sort_keys=True, separators=(",", ":")).encode()
    check("pinned_route", digest(canonical) == manifest["route_sha256"] == state["route_sha256"])
    check("unchanged_configured_executable", digest((LIVE / "retrieve-next").read_bytes()) == manifest["launcher_sha256"])
    check("complete_route_cursor", state["next_index"] == 4 and state["awaiting"] is None)
    figure = (LIVE / "delivered" / "synthetic_figure.png").read_bytes()
    fixture = (LIVE / "fixtures" / "synthetic_figure.png").read_bytes()
    returned = base64.b64decode(view["raw_result"]["image_url"].split(",", 1)[1], validate=True)
    check("complete_exact_image_delivered", figure == fixture)
    check("actual_view_return_is_exact_image", returned == figure,
          image_bytes=len(figure), returned_bytes=len(returned), image_sha256=digest(figure), returned_sha256=digest(returned))
    check("actual_view_receipt_record", receipt["tool_result"]["record_kind"] == "actual_tool_result" and receipt["tool_invocation"] == view["arguments"] and receipt["tool_result"] == view["observed_result"])
    check("view_receipt_run_image_binding", receipt["run_id"] == state["run_id"] and receipt["image_sha256"] == digest(figure) and receipt["image_bytes"] == len(figure))
    # Exec invocations use separate PID namespaces and may all report PID 2.
    # Each process starts its monotonic local sequence at 1; the fixed lock
    # serializes accepted reads, and these recorded live calls are sequential.
    invocations = []
    for event in audit:
        if event["process_sequence"] == 1:
            invocations.append([])
        invocations[-1].append(event)
    for invocation_number, events in enumerate(invocations, 1):
        rejected = [e for e in events if e["event"] == "rejected"]
        if rejected:
            check("live_rejection_no_fixture_open_" + str(invocation_number), not any(e["event"] == "subject_open_attempt" for e in events), codes=[e["code"] for e in rejected])
        for index, event in enumerate(events):
            if event["event"] in ["emission_authorized", "complete_image_delivered"]:
                earlier = events[:index]
                check("same_invocation_actual_hash_before_release_" + str(invocation_number),
                      any(e["event"] == "content_read" and e["actual_sha256"] == event["actual_sha256"] and e["actual_bytes"] == event["actual_bytes"] for e in earlier)
                      and any(e["event"] == "content_verified" and e["actual_sha256"] == event["actual_sha256"] and e["actual_bytes"] == event["actual_bytes"] for e in earlier))
    revisits = [e for e in audit if e["event"] == "baseline_revisit_completed"]
    check("live_revisit_cursor_unchanged", len(revisits) == 1 and revisits[0]["cursor_before"] == revisits[0]["cursor_after"] == 1)
    delivered_index = next(i for i, e in enumerate(audit) if e["event"] == "complete_image_delivered")
    receipt_index = next(i for i, e in enumerate(audit) if e["event"] == "inspection_receipt_accepted")
    final_read_index = next(i for i, e in enumerate(audit) if e["event"] == "content_read" and e["step"] == "text-02")
    check("image_then_receipt_then_next_read", delivered_index < receipt_index < final_read_index)
    result = {"all_passed": all(c["passed"] for c in checks), "checks_count": len(checks), "checks": checks,
              "run_id": state["run_id"], "route_sha256": manifest["route_sha256"], "launcher_sha256": manifest["launcher_sha256"]}
    (ROOT / "live_verification.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    inventory = []
    for path in sorted(ROOT.rglob("*")):
        if path.is_file() and path.name != "sealed_inventory.json":
            raw = path.read_bytes()
            inventory.append({"path": str(path.relative_to(ROOT)), "bytes": len(raw), "sha256": digest(raw)})
    (ROOT / "sealed_inventory.json").write_text(json.dumps({"files": inventory, "file_count": len(inventory)}, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"all_passed": result["all_passed"], "live_checks_count": len(checks), "sealed_files": len(inventory),
                      "run_id": state["run_id"], "route_sha256": manifest["route_sha256"], "launcher_sha256": manifest["launcher_sha256"]}, sort_keys=True))
    raise SystemExit(0 if result["all_passed"] else 1)


if __name__ == "__main__":
    main()
