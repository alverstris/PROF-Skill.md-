#!/usr/bin/python3
"""Synthetic tests; retain each configured launcher, fixture, stdout, stderr, and audit."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
from provision import ROOT, FIRST, SECOND, base_route, png_bytes, provision

TESTS = ROOT / "tests-v2"
CHECKS = []


def check(label, condition, **evidence):
    CHECKS.append({"check": label, "passed": bool(condition), **evidence})
    if not condition:
        raise AssertionError(label)


def events(case):
    path = case / "audit.jsonl"
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []


def invoke(case, args, expected_code, expected_rejection=None, expected_opens=None, expected_stdout=None):
    before = len(events(case))
    call_number = len(list(case.glob("call-*.json"))) + 1
    argv = [str(case / "retrieve-next"), *args]
    result = subprocess.run(argv, capture_output=True, cwd="/", timeout=10)
    after = events(case)[before:]
    stem = case / ("call-%02d" % call_number)
    stem.with_suffix(".stdout").write_bytes(result.stdout)
    stem.with_suffix(".stderr").write_bytes(result.stderr)
    report = {"argv": argv, "returncode": result.returncode, "audit_event_start": before,
              "audit_event_end": before + len(after), "stdout_bytes": len(result.stdout),
              "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
              "subject_open_attempts": sum(e["event"] == "subject_open_attempt" for e in after),
              "events": after}
    stem.with_suffix(".json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    prefix = case.name + "/call-%02d" % call_number
    check(prefix + ":exit", result.returncode == expected_code, actual=result.returncode)
    if expected_rejection:
        check(prefix + ":rejection", any(e["event"] == "rejected" and e["code"] == expected_rejection for e in after))
        check(prefix + ":no_stdout", result.stdout == b"")
    if expected_opens is not None:
        check(prefix + ":subject_opens", report["subject_open_attempts"] == expected_opens,
              actual=report["subject_open_attempts"], expected=expected_opens)
    if expected_stdout is not None:
        check(prefix + ":exact_stdout", result.stdout == expected_stdout)
    return result, after


def new_case(name, route=None, bad_route_pin=False):
    return provision(TESTS / name, route=route, bad_route_pin=bad_route_pin)


def write_test_receipt(case, wrong_run=False):
    state = json.loads((case / "state.json").read_text())
    receipt = {"run_id": "0" * 32 if wrong_run else state["run_id"], "figure_step": "figure-01",
               "image_sha256": hashlib.sha256(png_bytes()).hexdigest(), "image_bytes": len(png_bytes()),
               "tool": "view_image", "acknowledgement": "image_returned",
               "tool_call_reference": "SYNTHETIC TEST ONLY: no actual view tool invoked in this case",
               "tool_invocation": {"path": str(case / "delivered" / "synthetic_figure.png"), "detail": "original"},
               "tool_result": {"image_returned": True, "returned_detail": "original", "returned_mime": "image/png",
                               "record_kind": "synthetic_test_acknowledgement"},
               "recorded_by": "external_orchestrator"}
    (case / "receipts" / "figure-01.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")


def main():
    TESTS.mkdir(exist_ok=False)
    requests = [
        ("unknown", ["unknown-01"], "unknown_step"),
        ("skipped", ["text-02"], "not_next_step"),
        ("extra_argument", ["text-01", "synthetic_text.txt"], "exactly_one_step_argument"),
        ("missing_argument", [], "exactly_one_step_argument"),
        ("path_argument", ["../text-01"], "request_id_syntax"),
        ("unread_baseline_revisit", ["revisit-text-01"], "baseline_revisit_not_yet_read"),
    ]
    for name, args, rejection in requests:
        invoke(new_case(name), args, 2, rejection, 0)
    case = new_case("ordinary_repeated")
    invoke(case, ["text-01"], 0, expected_opens=1, expected_stdout=FIRST)
    invoke(case, ["text-01"], 2, "not_next_step", 0)
    mutations = [
        ("range_type", lambda r: r["steps"][0].update(start=True), "range_syntax"),
        ("range_negative", lambda r: r["steps"][0].update(start=-1), "range_bounds"),
        ("range_past_pin", lambda r: r["steps"][0].update(end=99999), "range_bounds"),
        ("range_over_cap", lambda r: r["steps"][0].update(source_bytes=10000, end=5000), "range_limit"),
        ("hash_syntax", lambda r: r["steps"][0].update(sha256="bad"), "content_hash_syntax"),
        ("unknown_type", lambda r: r["steps"][0].update(type="command"), "step_type"),
        ("filename_traversal", lambda r: r["steps"][0].update(file="../synthetic_text.txt"), "file_schema"),
        ("future_teaching_revisit", lambda r: r["revisits"][0].update(target="text-02"), "revisit_target"),
        ("baseline_after_teaching", lambda r: r["steps"][0].update(stage="teaching"), "baseline_after_teaching"),
        ("later_bad_hash", lambda r: r["steps"][3].update(sha256="bad"), "content_hash_syntax"),
    ]
    for name, mutate, rejection in mutations:
        route = copy.deepcopy(base_route())
        mutate(route)
        invoke(new_case(name, route), ["text-01"], 2, rejection, 0)
    invoke(new_case("route_pin_mismatch", bad_route_pin=True), ["text-01"], 2, "route_pin_mismatch", 0)
    case = new_case("actual_bounds_mismatch")
    (case / "fixtures" / "synthetic_text.txt").write_bytes(FIRST[:20])
    _, audit = invoke(case, ["text-01"], 2, "actual_bounds_mismatch", 1)
    read = next(e for e in audit if e["event"] == "content_read")
    check("truncated_read_has_actual_range_hash", read["actual_bytes"] == 20 and read["actual_end_exclusive"] == 20 and read["actual_sha256"] == hashlib.sha256(FIRST[:20]).hexdigest())
    case = new_case("actual_hash_mismatch")
    source = case / "fixtures" / "synthetic_text.txt"
    source.write_bytes(b"X" + (FIRST + SECOND)[1:])
    _, audit = invoke(case, ["text-01"], 2, "actual_hash_mismatch", 1)
    check("hash_mismatch_records_actual_hash", any(e["event"] == "content_read" and e["actual_sha256"] == hashlib.sha256(b"X" + FIRST[1:]).hexdigest() for e in audit))
    case = new_case("oversized_figure")
    invoke(case, ["text-01"], 0, expected_opens=1, expected_stdout=FIRST)
    (case / "fixtures" / "synthetic_figure.png").write_bytes(png_bytes() + b"X")
    invoke(case, ["figure-01"], 2, "actual_bounds_mismatch", 1)
    check("bad_figure_not_delivered", not (case / "delivered" / "synthetic_figure.png").exists())
    case = new_case("complete_route")
    invoke(case, ["text-01"], 0, expected_opens=1, expected_stdout=FIRST)
    before = (case / "state.json").read_bytes()
    invoke(case, ["revisit-text-01"], 0, expected_opens=1, expected_stdout=FIRST)
    check("baseline_revisit_cursor_unchanged", before == (case / "state.json").read_bytes())
    invoke(case, ["figure-01"], 0, expected_opens=1)
    check("complete_exact_image", (case / "delivered" / "synthetic_figure.png").read_bytes() == png_bytes())
    invoke(case, ["text-02"], 2, "not_next_step", 0)
    invoke(case, ["inspect-01"], 2, "inspection_receipt_missing", 0)
    invoke(case, ["revisit-text-01"], 2, "inspection_receipt_required", 0)
    write_test_receipt(case, wrong_run=True)
    invoke(case, ["inspect-01"], 2, "inspection_receipt_binding", 0)
    write_test_receipt(case)
    invoke(case, ["inspect-01"], 0, expected_opens=0)
    invoke(case, ["text-02"], 0, expected_opens=1, expected_stdout=SECOND)
    invoke(case, ["text-02"], 2, "route_complete", 0)
    before = (case / "state.json").read_bytes()
    invoke(case, ["revisit-text-01"], 0, expected_opens=1, expected_stdout=FIRST)
    check("post_route_revisit_cursor_unchanged", before == (case / "state.json").read_bytes())
    audit = events(case)
    main_reads = [e["step"] for e in audit if e["event"] == "content_verified"]
    check("complete_route_read_order", main_reads == ["text-01", "text-01", "figure-01", "text-02", "text-01"], actual=main_reads)
    for position, event in enumerate(audit):
        if event["event"] == "emission_authorized":
            previous = audit[:position]
            check("durable_hash_before_emission_" + str(position), any(e["event"] == "content_verified" and e["actual_sha256"] == event["actual_sha256"] for e in previous))
    check("complete_cursor", json.loads((case / "state.json").read_text())["next_index"] == 4)


if __name__ == "__main__":
    error = None
    try:
        main()
    except Exception as caught:
        error = {"type": type(caught).__name__, "message": str(caught)}
    summary = {"all_passed": error is None and all(c["passed"] for c in CHECKS),
               "checks_count": len(CHECKS), "error": error, "checks": CHECKS,
               "test_receipts": "Synthetic acknowledgements test only parsing/order; live/ records a real view tool call separately."}
    (ROOT / "test_results.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "checks"}, sort_keys=True))
    raise SystemExit(0 if summary["all_passed"] else 1)
