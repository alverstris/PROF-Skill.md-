#!/usr/bin/python3 -I
"""Synthetic-only guard template. Provision once; invoke generated launcher + ID."""
import base64
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT = Path(__ROOT_LITERAL__)
ROUTE_BYTES = base64.b64decode(__ROUTE_BASE64_LITERAL__)
ROUTE_SHA256 = __ROUTE_HASH_LITERAL__
FIXTURES = ROOT / "fixtures"
AUDIT = ROOT / "audit.jsonl"
STATE = ROOT / "state.json"
SHA_RE = re.compile(r"[0-9a-f]{64}\Z")
ID_RE = re.compile(r"[a-z][a-z0-9-]{0,47}\Z")
FILE_RE = re.compile(r"synthetic_[a-z]+\.(?:txt|png)\Z")
EVENT_SEQUENCE = 0


def log(event, **fields):
    global EVENT_SEQUENCE
    EVENT_SEQUENCE += 1
    record = {"time_ns": time.time_ns(), "pid": os.getpid(),
              "process_sequence": EVENT_SEQUENCE, "event": event, **fields}
    with open(AUDIT, "ab") as handle:
        handle.write((json.dumps(record, sort_keys=True) + "\n").encode())
        handle.flush()
        os.fsync(handle.fileno())


def audit_open(event, args):
    if event != "open":
        return
    path = args[0]
    if isinstance(path, (str, bytes, os.PathLike)):
        lexical = os.fsdecode(path)
        if lexical == str(FIXTURES) or lexical.startswith(str(FIXTURES) + "/"):
            log("subject_open_attempt", path=lexical,
                mode=str(args[1]), flags=args[2])


sys.addaudithook(audit_open)


def reject(code, **details):
    log("rejected", code=code, **details)
    print("REJECTED: " + code, file=sys.stderr)
    raise SystemExit(2)


def exact_keys(value, keys):
    return isinstance(value, dict) and set(value) == set(keys)


def integer(value):
    return type(value) is int


def preflight():
    if not SHA_RE.fullmatch(ROUTE_SHA256):
        reject("route_hash_syntax")
    actual = hashlib.sha256(ROUTE_BYTES).hexdigest()
    if actual != ROUTE_SHA256:
        reject("route_pin_mismatch")
    try:
        route = json.loads(ROUTE_BYTES)
    except (ValueError, UnicodeError):
        reject("route_json")
    if not exact_keys(route, ["version", "steps", "revisits"]) or route["version"] != 1:
        reject("route_schema")
    steps = route["steps"]
    if not isinstance(steps, list) or not steps or len(steps) > 20:
        reject("route_steps")
    ids = set()
    teaching_started = False
    for index, step in enumerate(steps):
        if not isinstance(step, dict):
            reject("step_schema")
        step_id = step.get("id")
        if not isinstance(step_id, str) or not ID_RE.fullmatch(step_id) or step_id in ids:
            reject("step_id_schema")
        ids.add(step_id)
        if step.get("stage") not in ["baseline", "teaching"]:
            reject("step_stage")
        if step["stage"] == "teaching":
            teaching_started = True
        elif teaching_started:
            reject("baseline_after_teaching")
        kind = step.get("type")
        if kind == "text":
            if not exact_keys(step, ["id", "type", "stage", "file", "source_bytes", "start", "end", "sha256"]):
                reject("text_schema")
            values = [step["source_bytes"], step["start"], step["end"]]
            if not all(integer(v) for v in values):
                reject("range_syntax")
            if not 0 <= step["start"] < step["end"] <= step["source_bytes"] <= 1048576:
                reject("range_bounds")
            if step["end"] - step["start"] > 4096:
                reject("range_limit")
        elif kind == "figure":
            if not exact_keys(step, ["id", "type", "stage", "file", "bytes", "sha256"]):
                reject("figure_schema")
            if not integer(step["bytes"]) or not 0 < step["bytes"] <= 1048576:
                reject("figure_bounds")
            if index + 1 >= len(steps) or not isinstance(steps[index + 1], dict):
                reject("figure_receipt_route")
            if steps[index + 1].get("type") != "inspection_receipt" or steps[index + 1].get("figure_step") != step_id:
                reject("figure_receipt_route")
        elif kind == "inspection_receipt":
            if not exact_keys(step, ["id", "type", "stage", "figure_step"]):
                reject("receipt_schema")
            if index == 0 or steps[index - 1].get("type") != "figure" or step["figure_step"] != steps[index - 1]["id"]:
                reject("receipt_route")
            if step["stage"] != steps[index - 1]["stage"]:
                reject("receipt_stage")
            continue
        else:
            reject("step_type")
        if not isinstance(step["file"], str) or not FILE_RE.fullmatch(step["file"]):
            reject("file_schema")
        extension = ".txt" if kind == "text" else ".png"
        if not step["file"].endswith(extension):
            reject("file_type")
        if not isinstance(step["sha256"], str) or not SHA_RE.fullmatch(step["sha256"]):
            reject("content_hash_syntax")
    if not isinstance(route["revisits"], list) or len(route["revisits"]) > 20:
        reject("revisits_schema")
    for revisit in route["revisits"]:
        if not exact_keys(revisit, ["id", "target"]):
            reject("revisit_schema")
        if (not isinstance(revisit["id"], str) or not ID_RE.fullmatch(revisit["id"]) or
            revisit["id"] in ids):
            reject("revisit_id_schema")
        ids.add(revisit["id"])
        target = next((s for s in steps if s["id"] == revisit["target"]), None)
        if target is None or target["type"] != "text" or target["stage"] != "baseline":
            reject("revisit_target")
    return route


def save_state(state):
    temporary = ROOT / "state.json.tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(state, handle, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, STATE)


def read_content(step):
    path = FIXTURES / step["file"]
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError as error:
        reject("subject_open_failed", error_type=type(error).__name__)
    with os.fdopen(fd, "rb") as handle:
        size = os.fstat(handle.fileno()).st_size
        log("subject_open_success", step=step["id"], actual_file_bytes=size)
        if step["type"] == "text":
            start = step["start"]
            requested_bytes = step["end"] - start
            handle.seek(start, os.SEEK_SET)
            data = handle.read(requested_bytes)
        else:
            start = 0
            requested_bytes = step["bytes"]
            # Read at most the full pinned image plus one sentinel byte.
            data = handle.read(requested_bytes + 1)
    digest = hashlib.sha256(data).hexdigest()
    # This durable record always precedes content release, even on mismatch.
    log("content_read", step=step["id"], type=step["type"],
        requested_start=start, requested_end_exclusive=start + requested_bytes,
        actual_start=start, actual_end_exclusive=start + len(data),
        actual_bytes=len(data), actual_sha256=digest, actual_file_bytes=size)
    expected_size = step.get("source_bytes", step.get("bytes"))
    if size != expected_size or len(data) != requested_bytes:
        reject("actual_bounds_mismatch", step=step["id"])
    if digest != step["sha256"]:
        reject("actual_hash_mismatch", step=step["id"])
    log("content_verified", step=step["id"], actual_bytes=len(data), actual_sha256=digest)
    return data, digest


def accept_receipt(step, state):
    awaiting = state["awaiting"]
    if not isinstance(awaiting, dict) or awaiting.get("figure_step") != step["figure_step"]:
        reject("receipt_state")
    path = ROOT / "receipts" / (step["figure_step"] + ".json")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            raw = handle.read(8193)
        if len(raw) > 8192:
            reject("receipt_too_large")
        receipt = json.loads(raw)
    except FileNotFoundError:
        reject("inspection_receipt_missing", step=step["id"])
    except (ValueError, UnicodeError):
        reject("inspection_receipt_invalid")
    keys = ["run_id", "figure_step", "image_sha256", "image_bytes", "tool",
            "acknowledgement", "tool_call_reference", "tool_invocation", "tool_result", "recorded_by"]
    if not exact_keys(receipt, keys):
        reject("inspection_receipt_schema")
    if (receipt["run_id"] != state["run_id"] or
        receipt["figure_step"] != awaiting["figure_step"] or
        receipt["image_sha256"] != awaiting["image_sha256"] or
        type(receipt["image_bytes"]) is not int or receipt["image_bytes"] != awaiting["image_bytes"]):
        reject("inspection_receipt_binding")
    if (receipt["tool"] != "view_image" or receipt["acknowledgement"] != "image_returned" or
        receipt["recorded_by"] != "external_orchestrator" or
        not isinstance(receipt["tool_call_reference"], str) or
        not 1 <= len(receipt["tool_call_reference"]) <= 200):
        reject("inspection_receipt_acknowledgement")
    invocation = receipt["tool_invocation"]
    result = receipt["tool_result"]
    expected_path = str(ROOT / "delivered" / "synthetic_figure.png")
    if (not exact_keys(invocation, ["path", "detail"]) or
        invocation["path"] != expected_path or invocation["detail"] != "original" or
        not exact_keys(result, ["image_returned", "returned_detail", "returned_mime", "record_kind"]) or
        result["image_returned"] is not True or result["returned_detail"] != "original" or
        result["returned_mime"] != "image/png" or
        result["record_kind"] not in ["actual_tool_result", "synthetic_test_acknowledgement"]):
        reject("inspection_receipt_tool_record")
    log("inspection_receipt_accepted", step=step["id"], receipt=receipt,
        evidence_scope="externally_recorded_tool_return; not_authenticated; not_semantic_inspection")
    state["awaiting"] = None
    state["next_index"] += 1
    save_state(state)
    print(json.dumps({"step": step["id"], "status": "external_view_receipt_recorded"}, sort_keys=True))


def main():
    # The caller supplies no source, offset, hash, interpreter, or other option.
    if len(sys.argv) != 2:
        reject("exactly_one_step_argument", actual_argument_count=len(sys.argv) - 1)
    requested = sys.argv[1]
    if not ID_RE.fullmatch(requested):
        reject("request_id_syntax")
    route = preflight()
    ids = [step["id"] for step in route["steps"]]
    revisit_ids = {item["id"]: item["target"] for item in route["revisits"]}
    if requested not in ids and requested not in revisit_ids:
        reject("unknown_step", requested=requested)
    with open(ROOT / "run.lock", "a+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            with open(STATE, "r", encoding="utf-8") as handle:
                state = json.load(handle)
        except (OSError, ValueError, UnicodeError):
            reject("state_unreadable")
        if (not exact_keys(state, ["run_id", "route_sha256", "next_index", "awaiting"]) or
            not isinstance(state["run_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", state["run_id"]) or
            state["route_sha256"] != ROUTE_SHA256 or not integer(state["next_index"]) or
            not 0 <= state["next_index"] <= len(ids)):
            reject("state_schema")
        index = state["next_index"]
        revisiting = requested in revisit_ids
        if revisiting:
            target_index = ids.index(revisit_ids[requested])
            if target_index >= index:
                reject("baseline_revisit_not_yet_read", requested=requested)
            if state["awaiting"] is not None:
                reject("inspection_receipt_required")
            expected = requested
            step = route["steps"][target_index]
        elif index == len(ids):
            reject("route_complete", requested=requested)
        else:
            expected = ids[index]
            if requested != expected:
                reject("not_next_step", requested=requested, expected=expected)
            step = route["steps"][index]
        if step["type"] != "inspection_receipt" and state["awaiting"] is not None:
            reject("inspection_receipt_required")
        log("request_validated", requested=requested, expected=expected,
            type=step["type"], route_sha256=ROUTE_SHA256, run_id=state["run_id"],
            revisiting=revisiting, source_step=step["id"], cursor=index)
        if step["type"] == "inspection_receipt":
            accept_receipt(step, state)
            return
        data, digest = read_content(step)
        if step["type"] == "text":
            try:
                data.decode("utf-8", errors="strict")
            except UnicodeError:
                reject("text_encoding", step=requested)
            if not revisiting:
                state["next_index"] += 1
            log("emission_authorized", step=requested, actual_bytes=len(data), actual_sha256=digest)
            save_state(state)
            sys.stdout.buffer.write(data)
            sys.stdout.buffer.flush()
            log("stdout_write_completed", step=requested, actual_bytes=len(data), actual_sha256=digest)
            if revisiting:
                log("baseline_revisit_completed", step=requested, source_step=step["id"],
                    cursor_before=index, cursor_after=state["next_index"])
        else:
            delivery = ROOT / "delivered" / step["file"]
            with open(delivery, "wb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            state["awaiting"] = {"figure_step": requested, "image_sha256": digest, "image_bytes": len(data)}
            state["next_index"] += 1
            log("complete_image_delivered", step=requested, image_path=str(delivery),
                actual_bytes=len(data), actual_sha256=digest, awaiting_receipt=ids[index + 1])
            save_state(state)
            print(json.dumps({"step": requested, "image_path": str(delivery), "image_bytes": len(data),
                              "image_sha256": digest, "run_id": state["run_id"],
                              "required_receipt_step": ids[index + 1]}, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as error:
        reject("internal_error", error_type=type(error).__name__)
