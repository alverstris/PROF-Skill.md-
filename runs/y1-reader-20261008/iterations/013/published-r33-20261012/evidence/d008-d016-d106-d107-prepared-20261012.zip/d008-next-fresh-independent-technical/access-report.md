# Independent access record

Only the permitted original D008 directory and the exact permitted baseline were used as subject-content inputs. This workspace contains new derived preparation records. No browsing, network, GitHub, delegation, PROF package, author prompt, current/prior generated teaching, historical reports or other agents' findings was accessed. The parent supplied the task and isolation boundary only. No link in the source or baseline was opened.

Original inputs were left intact. File hashes were calculated over all bytes. `source-identity.json` was parsed for original identity fields only; its ancestry/workflow/preparation/contents/scope/path fields were neither surfaced as findings nor followed. The selected identity fields are preserved in `original-identity.json`.

All seven original PNGs were displayed with `view_image(detail="original")`, as complete 1224×1584 pages. PDF pages 1–3 were displayed in the first batch; pages 4–7 in the second. All seven text files were displayed completely in a single output, totalling 7623 bytes, below the 7000-token budget. The image readings recovered layout, subscripts, fractions, source typos, figure content and continuations that raw text alone does not reliably convey. No crop replaced a whole-page reading.

The PDF itself was hashed and inspected with `pdfinfo` (result chunk `ab53a7`), confirming seven pages, 880629 bytes, letter page size and no encryption. The provided PDF-page text and images supplied the complete semantic content; PDF metadata was not treated as subject findings.

Baseline content was printed in the sixteen contiguous intervals below. Each of the first fifteen calls requested at most 16000 bytes and an 8000-token output budget; the final 7840-byte call had a 5000-token budget. UTF-8 boundary protection was enabled; each chosen boundary already ended at an admissible byte boundary. Every output was received completely, with no tool truncation marker. No clipping occurred, so no recovery interval was necessary. Truncation recovery count is zero, not an assertion that an unseen clipped section was read.

| Byte interval [start,end) | Tool result chunk |
|---|---|
| [0,16000) | 2ffc94 |
| [16000,32000) | 80fc76 |
| [32000,48000) | a34529 |
| [48000,64000) | e2ad9a |
| [64000,80000) | 5b241c |
| [80000,96000) | f99b92 |
| [96000,112000) | 9450b9 |
| [112000,128000) | bc9464 |
| [128000,144000) | ae1afe |
| [144000,160000) | 01210e |
| [160000,176000) | a15f23 |
| [176000,192000) | 602a94 |
| [192000,208000) | 130d48 |
| [208000,224000) | 8d3151 |
| [224000,240000) | 58f822 |
| [240000,247840) | 7466c6 |

Other substantive access results: complete source/text display `27d03f`, image-read logging `e667cf`, baseline-anchor indexing `7c57d5` followed by precise passage anchors `7e9f43`, arithmetic-check execution `85db51`, and coverage generation `d7e4e6`. The JSON ledger is the primary path/range/hash record. Tool result identifiers identify actual session output and are not source content.

Whole-file reads for hashing, metadata projection or anchor extraction are distinguished from semantic full-content reads. The latter are the seven explicit text displays, seven original-resolution page displays and the sixteen baseline displays. Merely hashing a file was not counted as reading its subject matter.
