# D008 complete-baseline bridge map

This map uses the entire four-subject baseline, not an H240-only proxy. Every byte in `[0,247840)` was read in sixteen consecutive bounded outputs. Its SHA256 is `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. Byte ranges below are zero-based half-open ranges in the original unmodified bytes, including the original CR/LF sequences. Full selected premise passages and their exact ranges are in `baseline-evidence-anchors.json`. Each of the 53 original-source coverage rows explicitly maps to the pertinent anchor IDs; the administrative cover is the only item needing no subject premise.

## The combined starting position

| Subject | Title byte offset | Applicable positive knowledge | Limits consequential for D008 |
|---|---:|---|---|
| Mathematics A H240 | 2093 | Algebra, domain/equality/units, line equation, derivatives as limits and tangent gradients, product/chain rules, second derivatives, binomial truncations, radians/small angles, basic integration | H240 alone does not supply unrestricted Taylor/Maclaurin theory or a general remainder theorem; the separate FM27 grant must be included |
| Further Mathematics A H245, Pure Core plus selected Statistics and Mechanics | 50677 | FM27 explicitly supplies derivative-based Maclaurin expansions and all five functions used by D008; FM57 dimensions; FM56 distinguishes least-squares fitting | Maclaurin convergence proofs and a general remainder theorem are not automatically granted; algebraic series knowledge supplies no special-relativistic model |
| Physics A H556 | 90025 | Light speed, SI/unit conversions, dimensionless ratios, graphical rates, exponential models, accuracy/precision/resolution and uncertainty | Explicitly no relativistic-spacetime course; E=mc² is not a premise for time dilation; no current atomic-clock performance bound or complete GPS model |
| Chemistry A H432 | 150631 | Conditional approximation is explicit in weak-acid chemistry; units and quantitative measurement reasoning distinguish an approximation from a justified empirical precision claim | No extra premise changes the D008 time-dilation law or instrument capability; chemistry does not silently supply a Taylor remainder theorem |

The complete readings of the remaining topics produced no further necessary premise for the assigned source. Their presence was considered, rather than excluded by a keyword search. In particular, probability distributions, confidence intervals and regression do not make an unspecified deterministic truncation error into a random uncertainty; nuclear mass–energy equivalence does not derive time dilation; chemistry's known logarithms and exponential rates do not by themselves establish a clock model.

## Consequential bridges

| Bridge | Source coverage | Existing premise anchors | What must be made explicit or derived if assessed |
|---|---|---|---|
| Tangent as a computational approximation | S03–S05 | B02 [11555,11972); B06 [20290,23787) | Name the polynomial separately; set h=x−x0; derive error/h→0 from the derivative limit; explain locality without promising monotonic global error |
| Nonzero base point and shifted input | S06–S07 | B05 [18931,20248); B06; B08 [63872,64638) | x near 1 becomes u=x−1 near zero; preserve the logarithm's domain |
| Five linear and five quadratic entries | S08–S18, S40–S46 | B03 [14437,15243); B04 [15823,16654); B06; B08 | These are already available through FM27. Connect the displayed derivative values to each coefficient, use radians, and allow degree below the truncation order |
| Fixed exponent and finite truncation conditions | S12–S15, S21–S22, S45 | B01 [3315,5200); B03; B08 | r is fixed; real input has a suitable domain; infinite-series convergence is distinct from a required finite-approximation tolerance |
| Algebra with approximate factors | S19–S25, S51–S53 | B01; B03; B06; B08 | Track small inner arguments and denominator nonzero conditions; keep only coefficients justified by both factor expansions; show which factor and cross terms contribute |
| Reading derivatives from an approximation | S24 | B06; B08 | It is the established first-order expansion, not arbitrary visual/numerical closeness, that determines the derivative |
| Limit from a truncated numerator | S26–S27 | B03; B06; B08 | Explain why the omitted error divided by x tends to zero; derivative definition or exact finite binomial calculation supplies a complete argument |
| Supplied clock law and conventions | S28–S31 | B10 [80355,80772); B11 [91523,92831); B13 [149570,150255); B16 [89411,90025) | Supply/retain the physical equation and T/T' definitions. Do not infer it from the baseline. Identify the local idealised frame interpretation and fixed quantity needed by the calculation |
| Dimensionless perturbation and corrected source line | S30–S33 | B01; B03; B08; B10; B11 | Let epsilon=v²/c², set u=−epsilon, expand T'/T, or retain T as a factor. Correct source exponent 4 to r and missing T explicitly |
| Physical accuracy and empirical claims | S34, S48–S50 | B11; B12 [93403,99717); B14 [188700,193637); B15 [233294,237680) | Distinguish fractional ratio correction from elapsed-time error. A tolerance, duration and adequate physical model are needed. GPS and atomic-clock statements remain historical source claims unless evidence is supplied |
| Quadratic construction and one-half | S35–S39 | B06; B08; B09 [79841,80337) | Match value, slope and second derivative, derive the coefficient 1/2, and distinguish osculation from least squares. Handle zero quadratic coefficient |
| Approximation validity/error bound | S04, S23, S35, S50, S53 | B06; B07 [23842,25671); B08 | A general remainder theorem is not baseline recall. For a rigorous demand, state sufficient regularity and derive the needed integral/error relation, or provide a justified bound; the dossier gives one permissible derivation |
| Quirk's order variable | S47–S50 | B03; B08; B10 | A quadratic expression in epsilon is fourth order in v; a linear epsilon approximation already contains v². Compare terms in one declared variable |
| Source printing versus mathematical identity | S14–S15, S31–S32 | B01; B06; B10 | Correct actual visible source faults. Do not repeat f=its truncation as an identity or drop physical units |

## Assumption of competence and evidence limits

The baseline is an explicit competence assumption across completed courses. It is not a measured mastery result. This preparation establishes source coverage, permitted starting premises and independent technical calculations. It does not establish that an authored explanation is teachable, that a student trial has run, or that any teaching passed a later evaluator. No generated teaching was available or read in this phase.
