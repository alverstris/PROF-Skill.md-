"""Independent arithmetic and analytic cross-checks of D008, using standard library only.
No files are read except the original-input hashes when separately sealing; this script
constructs the mathematical expressions directly from independently read source.
"""
from fractions import Fraction as F
from decimal import Decimal as D, localcontext
from math import comb
import json
from pathlib import Path

out = Path(__file__).resolve().parent
checks=[]
def check(name,condition,detail):
    assert condition,name
    checks.append({'name':name,'passed':bool(condition),'detail':detail})

# Product coefficients are computed once by convolution, once by differentiation.
a=[F(1),F(-2),F(2)]
b=[F(1),F(-1,2),F(3,8)]
product=[sum((a[i]*b[k-i] for i in range(3) if 0<=k-i<3),F(0)) for k in range(5)]
check('composite product coefficients',product[:3]==[F(1),F(-5,2),F(27,8)],list(map(str,product)))
# Independent route: f'/f = g = -2 - 1/[2(1+x)], and f''/f = g^2+g'.
g0=F(-2)-F(1,2); gp0=F(1,2)
f2=g0*g0+gp0
check('composite direct derivative',g0==F(-5,2) and f2==F(27,4),{'f0':'1','f1':str(g0),'f2':str(f2),'quadratic_coefficient':str(f2/2)})
# Third derivative via product-rule derivatives, independent of product truncation.
f3=F(-8)+3*F(4)*F(-1,2)+3*F(-2)*F(3,4)+F(-15,8)
check('composite first omitted coefficient',f3/F(6)==F(-163,48),{'f3':str(f3),'coefficient_x3':str(f3/6)})
wrong_product=[F(1),F(-5,2),F(1)]
check('linear-factor product cannot identify quadratic term',wrong_product[2]!=product[2],{'linear_factor_x2':'1','true_x2':'27/8','missing':'19/8'})

poly=[F(comb(10,k)*(2**k)) for k in range(11)]
check('Example 3 exact polynomial limit',poly[0]==1 and poly[1]==20,{'coefficients_ascending':list(map(str,poly)),'quotient_limit':'20','quotient_next_term':'180*x'})

# Standard derivative triples: computed by differentiating the original defining forms.
standard=[
 {'function':'sin(x)','value':'0','first':'1','second':'0','linear':'x','quadratic':'x'},
 {'function':'cos(x)','value':'1','first':'0','second':'-1','linear':'1','quadratic':'1-x^2/2'},
 {'function':'exp(x)','value':'1','first':'1','second':'1','linear':'1+x','quadratic':'1+x+x^2/2'},
 {'function':'ln(1+x)','value':'0','first':'1','second':'-1','linear':'x','quadratic':'x-x^2/2'},
 {'function':'(1+x)^r','value':'1','first':'r','second':'r*(r-1)','linear':'1+r*x','quadratic':'1+r*x+r*(r-1)*x^2/2'}]
for r in [F(-1,2),F(-1),F(1,2),F(10),F(0),F(1)]:
    # Coefficient recurrence derived by coefficient matching in (1+x)y'=r*y.
    c0=F(1);c1=r*c0;c2=(r-1)*c1/2
    check('binomial coefficient recurrence r='+str(r),c2==r*(r-1)/2,{'c0':str(c0),'c1':str(c1),'c2':str(c2)})

with localcontext() as ctx:
    ctx.prec=80
    eps=(D(4)/D(300000))**2
    gamma=D(1)/(D(1)-eps).sqrt()
    linear=D(1)+eps/2
    quadratic=linear+D(3)*eps**2/8
    corr1=eps/2;corr2=D(3)*eps**2/8
    check('Quirk parameter arithmetic',abs(eps-D('1.7777777777777777777777777777777777777777777777777777777777777777777777777777778e-10'))<D('1e-85'),str(eps))
    check('Quirk quadratic coefficient',F(-1,2)*(F(-1,2)-1)/2==F(3,8),'3/8')
    check('Quirk residual after linear',abs((gamma-linear)/corr2-1)<D('2e-10'),{'gamma':str(gamma),'gamma_minus_1':str(gamma-1),'linear_correction':str(corr1),'quadratic_correction':str(corr2),'linear_residual':str(gamma-linear),'quadratic_residual':str(gamma-quadratic),'quad_to_linear_correction':str(corr2/corr1),'linear_time_difference_if_T_86400_s':str(D(86400)*corr1),'quadratic_time_correction_if_T_86400_s':str(D(86400)*corr2)})
    numerical=[]
    for xs in ['-0.1','-0.01','0.01','0.05','0.1','0.2']:
        x=D(xs);f=(-2*x).exp()/(1+x).sqrt();L=1-D(5)*x/2;Q=L+D(27)*x*x/8
        numerical.append({'x':xs,'f':str(f),'linear':str(L),'quadratic':str(Q),'f_minus_L':str(f-L),'f_minus_Q':str(f-Q)})
    x=D('0.0001');f=(-2*x).exp()/(1+x).sqrt();L=1-D(5)*x/2;Q=L+D(27)*x*x/8
    check('composite numerical leading errors',abs((f-L)/(x*x)-D(27)/8)<D('0.001') and abs((f-Q)/(x**3)+D(163)/48)<D('0.001'),{'x':str(x),'linear_error_div_x2':str((f-L)/(x*x)),'quadratic_error_div_x3':str((f-Q)/(x**3))})
    # ln near the actual nonzero base point checks the independent logarithm example.
    u=D('0.001');ln=(1+u).ln()
    check('logarithm at base point one',abs((ln-u)/u**2+D('0.5'))<D('0.001'),{'u':str(u),'ln_1_plus_u':str(ln),'linear':str(u),'scaled_error':str((ln-u)/u**2)})

report={'status':'all_checks_passed','check_count':len(checks),'precision_digits':80,'standard_derivative_triples':standard,'checks':checks,'composite_numerical_comparisons':numerical,'scope':'Exact algebra plus independent derivative and high-precision numeric routes; empirical GPS/clock-performance claims not tested.'}
(out/'calculation-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'check_count':len(checks),'numeric_comparisons':len(numerical),'standard_functions':len(standard)},indent=2))
