from pathlib import Path
import hashlib,json,datetime
out=Path(__file__).resolve().parent
source=Path('/workspace/scratch/f9c0b7fc7e76/original-inputs/D008')
baseline=Path('/workspace/scratch/f9c0b7fc7e76/d013-clean-r33-20261012/inputs/student-baseline.txt')
sha=lambda b:hashlib.sha256(b).hexdigest()
log_path=out/'access-log.jsonl'
entries=[json.loads(x) for x in log_path.read_text().splitlines()]
initial={x['path']:x for x in entries if x['kind']=='identity_hash'}
inputs=[]
for p in [*sorted(source.iterdir()),baseline]:
 b=p.read_bytes();rec={'path':str(p),'bytes':len(b),'sha256':sha(b)};before=initial[str(p)]
 assert rec['sha256']==before['sha256'],str(p)+' changed'
 assert len(b)==before['byte_range'][1],str(p)+' length changed'
 rec['unchanged_from_initial_identity']=True;inputs.append(rec)
assert inputs[-1]['bytes']==247840
assert inputs[-1]['sha256']=='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
indexed=[]
for line in (source/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1);actual=sha((source/name).read_bytes());assert expected==actual,name;indexed.append(name)
assert len(indexed)==16
ranges=[x['byte_range'] for x in entries if x['kind']=='baseline_content_read']
assert ranges==[[a,min(a+16000,247840)] for a in range(0,247840,16000)]
assert sum(z-a for a,z in ranges)==247840
text_reads=[x for x in entries if x['kind']=='full_source_text_read']
image_reads=[x for x in entries if x['kind']=='source_image_visual_read']
assert len(text_reads)==7 and sum(x['byte_range'][1] for x in text_reads)==7623
assert len(image_reads)==7 and all(x['detail']=='original' and x['whole_page'] and x['dimensions']==[1224,1584] for x in image_reads)
assert all(not x.get('output_clipped',False) for x in text_reads+image_reads+[x for x in entries if x['kind']=='baseline_content_read'])
coverage=json.loads((out/'source-coverage.json').read_text());anchors=json.loads((out/'baseline-evidence-anchors.json').read_text());checks=json.loads((out/'calculation-checks.json').read_text())
assert len(coverage['items'])==53 and {x['pdf_page'] for x in coverage['items']}==set(range(1,8))
assert len(anchors)==16
anchorids={x['id'] for x in anchors}
assert all(set(x['baseline_anchor_ids'])<=anchorids for x in coverage['items'])
assert all(x['baseline_anchor_ids'] or x['pdf_page']==1 for x in coverage['items'])
assert checks['check_count']==16 and all(x['passed'] for x in checks['checks'])
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
integrity={'verified_utc':now,'all_inputs_unchanged':True,'source_checksum_index_entries_verified':len(indexed),'inputs':inputs}
(out/'input-integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
audit={'status':'complete_no_clipping_outstanding','original_pages':7,'source_text_files':7,'source_text_bytes':7623,'original_resolution_images':7,'image_dimensions':[1224,1584],'baseline_total_bytes':247840,'baseline_content_read_ranges':ranges,'baseline_chunk_count':len(ranges),'baseline_unique_bytes_read':247840,'baseline_gaps':[],'baseline_overlaps':[],'subject_sections':['Mathematics A H240','Further Mathematics A H245 Pure Core Y540/Y541 plus Statistics Y542 and Mechanics Y543','Physics A H556','Chemistry A H432'],'clipping_observed':False,'clipping_recovery_intervals':[],'source_coverage_entries':53,'baseline_premise_anchors':16,'calculation_checks_passed':16,'independence_attestation':{'prior_teaching_read':False,'current_generated_teaching_read':False,'author_packet_read':False,'prof_package_read':False,'other_agent_findings_read':False,'historical_paths_followed':False,'browser_or_network_used':False,'delegation_used':False,'only_allowed_original_and_baseline_inputs':True},'semantic_read_and_hash_distinguished':True,'all_inputs_unchanged':True,'stage':'technical_preparation_only_not_teaching_or_acceptance'}
(out/'access-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
with log_path.open('a') as f:
 f.write(json.dumps({'kind':'directory_inventory','path':str(source),'tool':'exec_command rg --files','timing':'initial inventory; retrospectively recorded','contents_read':False})+'\n')
 f.write(json.dumps({'kind':'independent_calculation_check','script':str(out/'calculation_checks.py'),'tool':'exec_command python','tool_result_chunk':'85db51','checks_passed':16,'external_input_reads':False})+'\n')
 f.write(json.dumps({'kind':'final_integrity_and_access_validation','verified_utc':now,'tool':'exec_command python seal_preparation.py','original_files_hashed':17,'baseline_bytes_hashed':247840,'all_inputs_unchanged':True,'baseline_complete':True,'source_complete':True,'output':'input-integrity.json;access-audit.json','subject_input_paths':[str(source),str(baseline)]})+'\n')
artifacts=[]
for p in sorted(out.iterdir()):
 if p.is_file() and p.name not in {'manifest.json','SHA256SUMS'}:
  b=p.read_bytes();artifacts.append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
manifest={'schema':'independent-technical-preparation-manifest-v1','material_id':'D008','sealed_utc':now,'stage':'source_only_technical_preparation','status':'READY_FOR_LATER_FROZEN_TEACHING_REVIEW','not_claimed':['authored teaching','SASIS attempt','student trial','teaching acceptance','empirical verification of GPS or clock performance'],'source':{'stable_id':'mit-18-01-fall-2006-L09','pdf':'lec9.pdf','bytes':880629,'sha256':'d1b383663f7792bbdaa4d6108e17b11679d4688e413e197486941af337892320','pages':7},'baseline':{'path':str(baseline),'bytes':247840,'sha256':inputs[-1]['sha256'],'full_content_read':True,'read_chunks':16,'subjects':4},'counts':{'source_text_files':7,'source_images':7,'source_coverage_entries':53,'baseline_premise_anchors':16,'numbered_source_examples':5,'numbered_source_figures':4,'source_figure_panels':5,'basic_formula_entries':10,'calculation_checks':16,'numeric_comparison_points':6},'isolation':'Only allowed original D008 content and complete specified baseline were used. Findings not provided to the future author; retain until entire teaching freeze. Exact then-current PROF package and fresh prompt-only packet have not yet been supplied.','artifacts':artifacts,'checksum_convention':'SHA256SUMS covers every listed artifact and manifest.json; excludes SHA256SUMS itself to avoid self-reference.'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
sums=[]
for p in sorted(out.iterdir()):
 if p.is_file() and p.name!='SHA256SUMS':sums.append(sha(p.read_bytes())+'  '+p.name)
(out/'SHA256SUMS').write_text('\n'.join(sums)+'\n')
print(json.dumps({'sealed':True,'artifact_payload_count':len(artifacts),'checksummed_file_count':len(sums),'manifest_sha256':sha((out/'manifest.json').read_bytes()),'sha256sums_sha256':sha((out/'SHA256SUMS').read_bytes()),'source_coverage_entries':53,'baseline_bytes_read':247840,'baseline_chunks':16,'math_checks_passed':16},indent=2))
