# D008 independent technical preparation dossier

Status: sealed source-only preparation, not teaching, not a student attempt, not SASIS, and not teaching acceptance. Prepared independently from the seven original D008 page images and text pairs and the complete specified four-subject baseline. No PROF package, fresh author packet, existing teaching, prior reports, other agents' findings, browser, network, or historical ancestry was consulted. Findings must remain unavailable to the future author until the whole teaching is frozen.

## Identity and page convention

D008 is MIT 18.01 Single Variable Calculus, Fall 2006, Lecture 9, *Linear and Quadratic Approximations*. Stable source ID: `mit-18-01-fall-2006-L09`. Original PDF: 880629 bytes, SHA256 `d1b383663f7792bbdaa4d6108e17b11679d4688e413e197486941af337892320`. There are seven PDF pages: the cover is PDF page 1; printed lecture pages 1–6 are PDF pages 2–7. All seven pages and every figure were included. Metadata was used only for original identity and the all-pages boundary; historical paths and preparation/workflow metadata were not followed or used.

The baseline is 247840 bytes, SHA256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. All four subject sections were read in contiguous bounded chunks, not just mathematics excerpts. The baseline already grants substantial calculus, the five Maclaurin expansions, dimensional analysis and scientific measurement reasoning. It does not grant a special-relativistic clock model or a general Taylor remainder theorem.

## 1. Local linear approximation

Write the base point as `a` and the signed displacement as `h=x-a`. A line through `(a,f(a))` with gradient `f'(a)` is

`L_a(x)=f(a)+f'(a)(x-a)`.

This follows from the baseline point-gradient equation. The derivative definition also explains what makes this line an approximation: if `f` is differentiable at `a`, define

`eta(h)=[f(a+h)-f(a)]/h-f'(a)` for nonzero h.

Then `eta(h)->0` and the exact relation is

`f(a+h)=f(a)+f'(a)h+h eta(h)`.

Thus the error, divided by the input displacement, tends to zero. This explicit relation is sufficient to justify local first-order calculations without importing an unstated general remainder theorem. It also separates three objects: the actual function `f`, its line `L_a`, and the approximation statement `f(x)≈L_a(x)`.

Source Figure 1 (PDF 2) depicts a concave-down increasing curve with its tangent drawn above the curve locally. Its labels identify `b=f(x0)` and `a=f'(x0)` in `y=b+a(x-x0)`. Here the source uses `a` for slope, whereas this dossier uses `a` for base point; these conventions must not be mixed. The figure's intended fact is local contact and shared slope. Concavity determines the depicted local overestimate. It does not establish a global theorem that error increases monotonically with distance from the base point. A function can be exactly linear or meet its tangent again.

The source's claim that approximation becomes less accurate farther away is a useful local expectation for its illustrated examples, not an unconditional result for arbitrary differentiable functions. A requested numerical accuracy requires a scale, a region and error information. Small displacement alone gives no universal decimal accuracy across arbitrary functions or arbitrary coefficients.

## 2. Example 1: logarithm and a changed variable

For `f(x)=ln x`, real domain `x>0`, at base point `a=1`,

`f(1)=0`, `f'(x)=1/x`, `f'(1)=1`, hence `L_1(x)=x-1`.

Set `u=x-1`, equivalently `x=1+u`. As `x` approaches 1, `u` approaches 0. The same approximation becomes `ln(1+u)≈u`, with `u>-1` and `|u|` small. This is a change of input coordinate, not the statement that the original function's base point somehow changed while its argument stayed unchanged. The new function `g(u)=ln(1+u)` has base point zero.

The quadratic correction derived below is `-u²/2`; the omitted first-order error therefore begins at negative order `u²`. Numerically, the supplied independent check uses `u=0.001` and verifies `(ln(1+u)-u)/u²` is near `-1/2`.

## 3. All five basic linear and quadratic formulae

At zero, let `L(x)=f(0)+f'(0)x` and `Q(x)=f(0)+f'(0)x+f''(0)x²/2`. Direct differentiation gives every entry, including the proofs the source leaves to the reader:

| f(x) | f'(x) | f''(x) | Values f(0), f'(0), f''(0) | L(x) | Q(x) |
|---|---|---|---|---|---|
| sin x | cos x | −sin x | 0, 1, 0 | x | x |
| cos x | −sin x | −cos x | 1, 0, −1 | 1 | 1−x²/2 |
| e^x | e^x | e^x | 1, 1, 1 | 1+x | 1+x+x²/2 |
| ln(1+x) | 1/(1+x) | −1/(1+x)² | 0, 1, −1 | x | x−x²/2 |
| (1+x)^r | r(1+x)^(r−1) | r(r−1)(1+x)^(r−2) | 1, r, r(r−1) | 1+rx | 1+rx+r(r−1)x²/2 |

Trigonometric arguments must be in radians. For logarithms, require `x>-1`. For arbitrary fixed real `r`, taking `1+x>0` is a sufficient real-valued domain around zero. A negative integer exponent also excludes its pole; nonnegative integer powers are polynomials. The local formula for any fixed real exponent follows from its derivatives. If an infinite binomial expansion is invoked, the baseline grants `|x|<1` unless an endpoint has separately been justified. This convergence condition is distinct from a tolerance-dependent condition for accurate finite truncation. A large fixed exponent can produce substantial higher coefficients, and a variable exponent depending on `x` cannot be treated as fixed without separate analysis.

A linear approximation means degree at most one, so cosine's `1` qualifies. A quadratic approximation means retaining through order two, so sine's `x` qualifies even though its degree is one. For sine, the coefficient of x² is zero, not omitted by accident. These cases are especially important because the source's informal descriptions as a line and parabola can otherwise imply that every approximation has the maximal degree.

Figure 2a (PDF 3) shows `sin x` and `y=x` crossing with equal slope at zero; Figure 2b shows `cos x` and the horizontal tangent `y=1`. They illustrate local agreement, not equality away from zero. The source writes `f(x)=x` in the sine proof and `f(x)=f(0)+f'(0)x` in the power proof. Those displayed equalities must be interpreted as formulae for `L`, or replaced by approximation signs; the actual sine and generic power functions are not equal to their truncations.

The baseline FM27 independently supplies the Maclaurin expansions. Hence the learner already has all ten source table entries as truncations. The new instructional burden, if assessed, lies in making the source's local interpretation, substitutions, bookkeeping, exceptions and error logic explicit; it is not legitimate to claim this baseline knows no series.

## 4. Example 2: linear approximation of the composite function

The function is `f(x)=e^(−2x)/sqrt(1+x)=e^(−2x)(1+x)^(−1/2)`, on `x>-1`, near zero. Substituting `u=−2x` in the exponential approximation gives `e^(−2x)≈1−2x`. The small-input condition concerns `|u|=2|x|`, which tends to zero with x.

The source first approximates `sqrt(1+x)≈1+x/2`, then inverts:

`1/(1+x/2)≈1−x/2`, using `(1+u)^(-1)≈1−u` with `u=x/2`.

The footnote gives the shorter direct route `(1+x)^(-1/2)≈1−x/2`. Both give

`(1−2x)(1−x/2)=1−(5/2)x+x²`.

Only the constant and linear terms are justified by first-order inputs. Thus `L(x)=1−5x/2`. Keeping the `x²` from this multiplication does not produce the correct quadratic approximation: each factor had other quadratic terms removed. The true quadratic coefficient, checked independently below, is `27/8`, not `1`. The missing coefficient is `19/8`.

A precise algebraic justification can use the differentiability relation: write `A(x)=1−2x+x eta_A(x)` and `B(x)=1−x/2+x eta_B(x)`, with both eta terms tending to zero. Their product is `1−5x/2+x eta(x)` where `eta(x)->0`. For reciprocal manipulation, denominators must stay away from zero locally. Since `sqrt(1+x)->1`, this condition holds sufficiently close to zero within the real domain.

The source reads off `f(0)=1` and `f'(0)=−5/2`. That inference is valid because the polynomial has been established as the actual first-order expansion, whose error divided by x tends to zero. A vague numerical approximation `f≈L` with no local error meaning is not by itself enough to identify a derivative exactly.

An independent derivative route gives

`f'(x)=e^(−2x)[−2(1+x)^(−1/2)−(1/2)(1+x)^(−3/2)]`,

so `f(0)=1`, `f'(0)=−5/2`. It agrees with the factor method without relying on its truncation arithmetic.

## 5. Example 3: the limit

For `f(x)=(1+2x)^10`, `f(0)=1`. Its derivative is `20(1+2x)^9`, so the derivative definition yields

`lim_(x->0) [(1+2x)^10−1]/x=20`.

The approximation route must retain error control when dividing by x. Because

`(1+2x)^10=1+20x+x eta(x)`, `eta(x)->0`,

the quotient equals `20+eta(x)` for x nonzero and therefore tends to 20. The limit is not proved merely by replacing an expression with something numerically close when both the numerator and denominator approach zero.

There is a wholly independent finite-polynomial check: the exact binomial expansion starts

`(1+2x)^10=1+20x+180x²+960x³+...+1024x^10`.

After subtracting 1 and dividing by x, every term except 20 tends to zero. The check script generates all eleven exact integer coefficients. This example already fits the baseline's derivative definition, chain rule and finite binomial theorem; the needed bridge is why an approximation is strong enough to survive division by the small variable.

## 6. Example 4: Planet Quirk, linear order

The source supplies the borrowed model

`T'=T/sqrt(1−v²/c²)`.

In its convention, T is the interval measured on the satellite's clock and T' the ground observer's corresponding interval. Treat this clock relationship as a supplied physical model, not as a consequence of the baseline's elementary mechanics or `E=mc²`. A careful use of special-relativistic time dilation requires that T describe the proper interval along the satellite clock, with T' the corresponding coordinate interval in the observer's inertial-frame description. The illustrated ground wristwatch is an informal description; its adequacy for comparing distant events, satellite acceleration and gravitational effects is not established by the diagram. For the calculus application it suffices to state the supplied relation and which quantity is held fixed.

Require `c>0`, `|v|<c` and positive time intervals when discussing clocks. Let `epsilon=v²/c²`, so epsilon is nonnegative and dimensionless. The required smallness is `epsilon<<1`; set `u=−epsilon`, `r=−1/2` in the binomial approximation. Then

`T'/T=(1−epsilon)^(-1/2)≈1+epsilon/2`,

or, equivalently,

`T'≈T[1+v²/(2c²)]`, `T'−T≈T v²/(2c²)`.

The source line on PDF 5 omits the factor T on the right after the approximation sign. That is a source printing error confirmed visually, not an OCR-only fault: its left side has time units, while its shown right side is dimensionless. It can be repaired either by keeping T multiplying the bracket or by explicitly approximating the ratio T'/T. In the same line, the bracket reads `(1+u)^4≈1+ru`; the exponent should be r. Both corrections preserve the intended argument.

With `v=4 km/s` and `c=3×10^5 km/s`,

`v/c=1/75000`, `epsilon=1/5625000000≈1.7777777777777778×10^(-10)`.

Thus the first fractional correction is `epsilon/2≈8.888888888888889×10^(-11)`. The source's `≈10^(-10)` is an order-of-magnitude statement, not a one-significant-figure rounding of epsilon. A time difference in seconds additionally requires an interval T. For the explicit diagnostic choice `T=86400 s`, the linear difference is `7.68×10^(-6) s`. This day calculation is an added independent diagnostic, not a number supplied by the lecture.

Figure 3 (PDF 5) shows the satellite's leftward velocity arrow relative to an observer. The sign/direction is immaterial to the displayed scalar factor because it uses v². No orbit radius, gravitational potential or acceleration appears in the supplied equation. The source says GPS engineers use such approximations, alongside others, and offset satellite transmitter frequencies. This is a historical source claim retained as context; this source-only preparation does not independently verify a complete GPS correction model, quantitative net correction or present engineering practice. The lecture itself warns by saying several other approximations are involved.

## 7. Quadratic approximation and the factor one-half

For a general base point a, choose a polynomial in displacement h:

`Q(a+h)=A+B h+C h²`.

Matching value, first derivative and second derivative at a gives

`A=f(a)`, `B=f'(a)`, `2C=f''(a)`.

Therefore `Q_a(x)=f(a)+f'(a)(x−a)+f''(a)(x−a)²/2`. This independently explains the half. For `f(x)=a0+b0 x+c0 x²` at zero, the derivatives are `b0+2c0 x` and `2c0`, and the formula reproduces all three coefficients exactly. At any base point, an actual polynomial of degree at most two is reproduced exactly after expanding the translated expression. Constants and lines are included.

Matching derivatives identifies the polynomial; explaining why it is accurate needs regularity. A sufficient assumption for the source's smooth examples is that f has a continuous second derivative in a neighbourhood of a. From the fundamental theorem and integration by parts, rather than an ungranted named remainder theorem,

`f(a+h)−f(a)−f'(a)h = integral_0^h (h−t) f''(a+t) dt`.

Subtracting `f''(a)h²/2` yields

`R(h)=integral_0^h (h−t)[f''(a+t)−f''(a)]dt`.

For positive or negative h, its absolute value is bounded by `h²/2` times the maximum oscillation of f'' between a and a+h. Continuity makes that oscillation tend to zero, so `R(h)/h²->0`. If a finite quantitative bound `|f'''|≤M` is additionally available throughout that segment, `|f''(a+t)−f''(a)|≤M|t|` and the displayed integral gives `|R(h)|≤M|h|³/6`. The derivative-bound step can itself be justified by the baseline fundamental theorem when f''' is continuous. These are explicitly derived sufficiency conditions, not claimed baseline recall or claims that the lecture provided a remainder bound.

The source's phrase 'best-fit parabola' should mean the unique local polynomial matching these derivatives. It is not a least-squares curve fit over measured data or a claim of least error over an unspecified interval. In this baseline the latter notion has a precise regression meaning, so the distinction matters. The source's claim that quadratic approximations are used only when higher accuracy is needed is motivational shorthand, not a universal characterisation of their applications. The approximation is local; adding a term need not improve error at every distant point or in every degenerate example.

For cosine at zero, the matching values are 1, 0, −1, giving `Q(x)=1−x²/2`. Figure 4 (PDF 6) shows this downward parabola and cosine tangent at the top. Near zero, the next cosine term is `x^4/24`, so cosine lies above Q for sufficiently small nonzero x. Its error begins at fourth order rather than at the generic third order because the cubic coefficient vanishes.

## 8. Planet Quirk at quadratic order

For `g(u)=(1+u)^(-1/2)`, the quadratic coefficient is

`r(r−1)/2 = (−1/2)(−3/2)/2 = 3/8`.

Putting `u=−epsilon` gives

`T'/T≈1+epsilon/2+3epsilon²/8`.

The square removes the sign of u; the second correction is positive. In terms of v, this is `1+v²/(2c²)+3v^4/(8c^4)`. 'Linear' and 'quadratic' here refer to u or epsilon, not to v: they correspond respectively to second and fourth powers of v.

For the specified speeds,

`epsilon²≈3.1604938271604938×10^(-20)`,

`3epsilon²/8≈1.1851851851851852×10^(-20)`.

The second correction is smaller than the first by `(3/4)epsilon≈1.3333333333333333×10^(-10)`. It is a fractional correction to the clock ratio. A duration error in seconds is T times this quantity; for the stated diagnostic day, it is `1.024×10^(-15) s`. The high-precision check directly evaluates `1/sqrt(1−epsilon)` and verifies the linear residual against the independently derived quadratic term.

On PDF 7 the source asserts that even the best atomic clocks cannot measure time to this precision. This is a dated empirical claim, not a mathematical consequence, and it lacks a stated measurement duration, type of fractional precision and apparatus model. Without new external evidence it must not become a present-day universal claim. The defensible mathematical conclusion is conditional: if the required fractional tolerance is larger than the omitted correction, and the rest of the physical model is adequate, the linear truncation suffices. A numerical small term is not by itself proof about a particular instrument. The mathematical size comparison in the source is correct to order of magnitude.

## 9. Example 5: full quadratic composite calculation

Use both factors through degree two:

`e^(−2x)≈1−2x+2x²`,

`(1+x)^(-1/2)≈1−x/2+3x²/8`.

The quadratic coefficient in the product has three contributions: `2` from the first factor's quadratic term, `(-2)(-1/2)=1` from multiplying the linear terms, and `3/8` from the second factor's quadratic term. Their sum is `27/8`. Thus

`Q(x)=1−5x/2+27x²/8`.

The product of the two displayed quadratics also contains `−7x³/4+3x^4/4`. These higher coefficients are not reliable coefficients of the original function, because cubic and higher terms were already omitted in the factors. They are dropped for a consistent quadratic approximation. This is the same bookkeeping issue as in Example 2, at one order higher.

Independent differentiation gives

`f''(x)=e^(−2x)[4(1+x)^(-1/2)+2(1+x)^(-3/2)+(3/4)(1+x)^(-5/2)]`,

so `f''(0)=27/4` and its Taylor coefficient is `27/8`. Equivalently, if `g=f'/f=−2−1/[2(1+x)]`, then `f''/f=g²+g'`; at zero this gives `25/4+1/2=27/4`. This route is separate from the multiplication route.

A further product-rule calculation gives `f'''(0)=−163/8`, hence a first omitted coefficient `−163/48` for x³. The check script evaluates the original exponential/root formula to 80 decimal digits at six positive/negative x values and checks the scaled first neglected terms at x=0.0001. Those numerical checks support, but do not replace, the exact derivations. For x near −1 the function's denominator tends to zero; a zero-base low-degree polynomial should not be represented as a globally reliable substitute.

## 10. Error vocabulary, assumptions and assessment boundary

There are three distinct activities: computing the unique derivative-matching polynomial, using it to estimate a value, and proving the estimate meets a numerical tolerance. The source does the first two informally and compares term sizes; it does not provide a general rigorous error theorem or universal radius of accuracy. The baseline supplies series but expressly withholds a general remainder theorem. Any assessment asking for a guaranteed error therefore needs to supply or derive the necessary bound.

When using order notation in this dossier, `O(h^k)` means bounded in magnitude by a constant times `|h|^k` near zero, while `o(h^k)` means its ratio to `h^k` tends to zero. Such notation is not asserted as student baseline recall. The explicit eta and integral relations above supply the meaning without relying on notation. Fixed coefficients, admissible domains and local nonzero denominators must be checked before algebra on approximations. Errors cannot be dropped merely because their powers are high if the retained lower coefficients vanish or the chosen x is not small enough.

Coverage includes the source's administrative cover, title/unit framing, all five numbered examples, both approximation lists, proofs, four numbered figures including both Figure 2 panels, footnote shortcut, motivating/empirical claims, continuation across page breaks and visible typographic faults. `source-coverage.json` supplies the item ledger, and `baseline-map.md` separates existing knowledge from actual bridges. All 16 computational checks pass. Physical source claims about GPS practice and atomic-clock capability remain source-attributed and unverified by design.
