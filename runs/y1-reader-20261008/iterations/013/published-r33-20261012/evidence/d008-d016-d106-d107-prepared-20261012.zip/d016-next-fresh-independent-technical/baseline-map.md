# Complete four-subject baseline map

Input: `/workspace/scratch/f9c0b7fc7e76/d013-clean-r33-20261012/inputs/student-baseline.txt`.
Identity: 247,840 bytes; SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`.
All byte ranges are zero-based, start inclusive and end exclusive, measured on the original unnormalised bytes. CRLF/CRCRLF line endings were not rewritten in the source. Sixteen line-bounded chunks provide full semantic coverage [0,247840); their actual ranges are in `baseline-chunks.json` and `access-log.jsonl`.

## Full inspection map

| Subject/input section | Original byte range | Inspected extent and relationship to D016 |
|---|---:|---|
| Cover and joint-use rules | [0,2093) | Complete. Defines combined four-subject grant, no outside premises, competence assumption rather than measured mastery. |
| Mathematics A H240 | [2093,50677) | Complete: arithmetic/mensuration; proof; algebra/functions/coordinate geometry; sequences and binomial expansion; trigonometry; exponentials/logs; differentiation; integration/ODEs; numerical methods; vectors; statistics/probability/testing; mechanics; scope limits. Direct calculus, sum, area, and unit premises are below. |
| Further Mathematics A H245 | [50677,90025) | Complete Pure Core FM01-FM36, Statistics Y542 FM37-FM56, Mechanics Y543 FM57-FM68, and scope/resource/combination FM69-FM71. Direct premises include induction, exact square sums, average values, and dimensional checks. All other topics read; no complex, matrix, distribution, or advanced mechanics premise required. |
| Physics A H556 | [90025,150631) | Complete reference constants; quantities/measurement/practice; mechanics/materials; electricity/waves/quantum phenomena; thermal/circular/SHM/gravity; stars/cosmology; capacitors/fields; nuclear/imaging; entry-scope limits. Rate/area units and current provide optional bridges; no other physical content is needed. |
| Chemistry A H432 | [150631,247840) | Complete CH-META, CH-00 through CH-12, all subsections and CH-REF. Units, reaction rates and chromatographic area supply optional analogies; all bonding, equilibrium, acids, thermochemistry, redox, organic, spectroscopy, practical and scope content was read. No further chemical premise is needed. |

The baseline contains provenance URLs and a terminal reference to a separate research file. Neither those URLs nor any separate file was followed. The source permitted exactly this complete baseline, not its provenance corpus.

## Consequential premise map

| ID | Actual premise | Exact byte range | Use/bridge | Boundary |
|---|---|---:|---|---|
| B01 | Arithmetic, percentages, units | [3315,4093) | Rate conversion, principal times interest fraction, dimensional consistency. | Already granted; do not confuse repeated percentage growth with the supplied simple-interest model. |
| B02 | Explicit mensuration | [5200,5809) | Rectangle and triangle areas, prism-volume contrast. | General square-pyramid formula is supplied by the original; it is not separately displayed in this paragraph. |
| B03 | Variables, constants, intervals | [4099,4751) | Fix b as n changes; vary b for derivatives; interpret closed intervals. | Function/domain restrictions remain required. |
| B04 | Inequality signs | [8375,9044) | Divide by n^3>0 and multiply by b^3 for b>0. | Negative b would require separate sign and geometric interpretation. |
| B05 | Sequence convergence | [12994,13655) | Finite sums form a sequence; approaching a limit is not substituting infinity. | A fixed-point condition alone is not a convergence proof. |
| B06 | Sigma notation and arithmetic progressions | [13661,13908) | Sum of integers for linear-area and monthly-loan calculations. | Formula and index limits are explicit, not a topic-name inference. |
| B07 | Derivative from difference quotient | [20290,20881) | Interpret accumulation derivative locally. | No general derivative exists merely because an integral exists. |
| B08 | Power rule and elementary derivative rules | [20881,21533) | Differentiate b^3/3 and b^2/2. | These are prior competence. |
| B09 | Antiderivatives, fundamental theorem, rectangle sums | [23842,24288) | Independent area checks and the concept of limiting rectangle sums. | The baseline expressly qualifies the theorem with suitably continuous/well-behaved cases. |
| B10 | Signed definite integral | [25671,26176) | Qualify source area prose; distinguish orientation and geometric area. | A negative integrand is not an ordinary positive rectangle height. |
| B11 | Numerical integration and monotone rectangle bounds | [28101,28834) | Left/right brackets and convergence of endpoint approximations. | Section includes the displayed trapezium rule and following sign/bounds prose. |
| B12 | FM01 induction | [51644,52117) | Independent proof of sum-of-squares identity. | Finite checks alone are not a universal proof. |
| B13 | FM23 integer, square, cube sums and telescoping | [62401,62825) | Direct source finite-sum checks and alternative derivation. | These formulas are explicitly granted prior knowledge. |
| B14 | FM30 volumes and means | [65894,66359) | Average-value claim context; independent volume/area checks. | Do not make an integral-based pyramid calculation the foundation of the original x^2-area proof. |
| B15 | FM57 dimensions | [80355,80768) | Add matching quantities; interest factor dimensionless. | Dimension agreement alone cannot prove a model. |
| B16 | FM58 variable-force work | [80772,81332) | Optional analogy for accumulating a varying quantity. | Not necessary for original derivations; no line integral imported. |
| B17 | FM61 impulse | [82297,82753) | Optional rate/increment-to-total analogy. | Not a new loan or finance premise. |
| B18 | Physics graph gradients and areas | [95624,96172) | Graph-area units are products of axis units; strip approximation. | Supports correction of source dollar/year total error. |
| B19 | Physics current and transferred charge | [111670,112340) | Rate times duration gives amount, constant Q=It. | Optional cross-subject bridge; formal calculus supplied separately. |
| B20 | Chemistry rate conventions | [180581,181179) | Rates have per-time units and sign conventions. | Analogy only; no kinetic model needed. |
| B21 | Chemistry chromatography | [226523,227233) | Integrated peak area versus peak height. | Optional familiar accumulation context; no calibration numbers used. |
| B22 | FM71 combined-subject scope | [89411,89943) | Use actual combined premises and show consequential deductions. | No university formalism or financial distribution inferred from a topic label. |
| B23 | Power antiderivatives and linearity | [24294,24931) | Independent x, x^2, and polynomial borrowing integral checks. | Verification method already taught in baseline; preserve source geometric method as its own argument. |

## Needed bridges still owed by an explanation

1. Index a sample point to its own subinterval and multiply its height/rate by that interval width.
2. Derive the b^3/n^3 factor and identify right-endpoint overestimation for x^2 on [0,b], b>0.
3. Explain unit layer heights and which bounding solids have the source-supplied one-third volume factor.
4. Explain the vanishing upper/lower gap; separate the n-limit from later differentiation in b.
5. Preserve the common-limit/regularity conditions in the definition and signed-area qualification.
6. Refine the 12-month sum to n periods at fixed horizon rather than shrinking twelve periods to zero duration.
7. Use the remaining duration T−t for each loan and name the source model as simple interest.
8. Distinguish borrowing rate, amount borrowed, total borrowed, and final debt, with compatible units.
9. Separate exact finite monthly payment timing from the continuous flow limit.

These bridges can be built from the actual granted premises plus the original source; they do not require a new external subject source. The map makes no finding about any teaching artifact, assessment response, or student acceptance.
