from pathlib import Path
import json,hashlib
out=Path(__file__).resolve().parent
base=Path('/workspace/scratch/f9c0b7fc7e76/d013-clean-r33-20261012/inputs/student-baseline.txt')
src=Path('/workspace/scratch/f9c0b7fc7e76/original-inputs/D016')
b=base.read_bytes()
refs=[r for r in json.loads((out/'baseline-premise-spans.json').read_text()) if r['id']!='B23']
ends={'B06':'A geometric progression with first term','B07':'Core derivatives,','B08':'For differentiable','B11':'Vectors\r'}
for rec in refs:
    if rec['id'] in ends:
        z=b.find(ends[rec['id']].encode(),rec['byte_start']+1);assert z>=0
        rec['byte_end_exclusive']=z;rec['bytes']=z-rec['byte_start']
s='Standard antiderivatives include';start=b.find(s.encode());end=b.find(b'With substitution',start)
refs.append(dict(id='B23',start_phrase=s,byte_start=start,byte_end_exclusive=end,bytes=end-start))
(out/'baseline-premise-spans.json').write_text(json.dumps(refs,indent=2)+'\n')

items=[
(1,'Cover','MIT OpenCourseWare provenance, course 18.01 Single Variable Calculus, Fall 2006, citation/terms URL.','Identity; administrative','Not a mathematical premise. URLs not followed.'),
(2,'Title','Lecture 18: Definite Integrals.','Identity','Physical p2 is printed lecture p1.'),
(2,'Opening use claim','Integrals calculate cumulative totals, averages, and areas.','T1','Average value is mentioned but not developed.'),
(2,'Three-step procedure','Divide into rectangles, sum areas, take limit as rectangles become thin.','T1','Fixed finite interval; increasing subdivision count.'),
(2,'Figure 1(i)','Positive region between curve, a, b, and horizontal axis.','T1','No numerical data.'),
(2,'Figure 1(ii)','Rectangles approximate the same curved region.','T1','Finite approximations differ from area.'),
(2,'Example 1 declaration','f(x)=x^2, a=0, b arbitrary.','T2','A01: positive-width picture needs b>0.'),
(2,'Example 1 partition','n intervals; base b/n.','T2','n positive integer; b held fixed during n limit.'),
(2,'Example 1 heights','First point b/n and height (b/n)^2; second point 2b/n and height (2b/n)^2.','T2','Right endpoints.'),
(2,'Example 1 expanded sum','Sum (b/n)(ib/n)^2 = (b^3/n^3)(1^2+...+n^2).','T2','All n contributions; width is a separate factor.'),
(3,'Figure 2','Parabola above [0,b], three illustrative right rectangles.','T2','Overestimation; labels a=0,b.'),
(3,'Geometric method','Estimate square sum with three-dimensional staircase pyramid.','T3','Independent source method retained.'),
(3,'Figure 3','n=4 nested square top view and stepped side view, inner green and outer red bounding outlines.','T3','Square-pyramid comparators, not prisms.'),
(3,'Layer volumes','Bottom n by n gives n^2; next (n-1) by (n-1) gives (n-1)^2, etc.','T3','A02: thickness 1 implicit.'),
(3,'Staircase total','n^2+(n-1)^2+...+1.','T3','Equals sum of squares.'),
(3,'Lower volume bound','1^2+...+n^2 > (1/3)(base)(height)=(1/3)n^2*n=n^3/3.','T3','A03: source calls the comparator inner prism.'),
(3,'Upper volume bound','1^2+...+n^2 < (1/3)(n+1)^2(n+1)=(n+1)^3/3.','T3','A03: source calls comparator outer prism.'),
(4,'Normalised bounds','1/3=(n^3/3)/n^3 < (1^2+...+n^2)/n^3 < (1/3)(n+1)^3/n^3.','T3','A04: vanishing bound gap explains limit.'),
(4,'Example 1 conclusion','Limit (b^3/n^3)(1^2+...+n^2)=b^3/3; area under x^2 from 0 to b.','T2,T3','Correct on pictured b>=0 domain.'),
(4,'Example 2','f(x)=x; area above [0,b]; (b^2/n^2)(1+...+n) tends to b^2/2.','T4','Finite arithmetic-sum bridge supplied by baseline.'),
(4,'Figure 4','Triangle under y=x with base and height both b.','T4','Area b^2/2 independently checks limit.'),
(4,'Derivative identities','d/db(b^3/3)=b^2 and d/db(b^2/2)=b.','T4','Now vary b, not n.'),
(4,'Accumulation pattern','Area A(b) under f should satisfy A prime(b)=f(b).','T4','A05: continuity and fixed lower endpoint; source motivation not full proof.'),
(5,'Figure 5','One tagged rectangle; c_i interior sample, curve y=f(x), interval a to b.','T5','Rectangle crosses curve; not necessarily inscribed.'),
(5,'General partition','n equal pieces of length Delta x=(b-a)/n.','T5','Finite a<b, n positive integer.'),
(5,'General tag','Pick any c_i in the interval; height f(c_i).','T5','A06: interpret as its own ith subinterval.'),
(5,'Riemann sum','f(c1)Delta x+...+f(cn)Delta x = sum_i=1^n f(c_i)Delta x.','T5','Summation notation explicitly named.'),
(5,'Definite integral definition','lim_n->infinity sum_i=1^n f(c_i)Delta x = integral_a^b f(x)dx.','T5','A07: existence/common limit/regularity implicit.'),
(5,'Area interpretation','Integral represents area under y=f(x) above [a,b].','T1,T5','A08: ordinary area requires f>=0.'),
(5,'Example 3 quantities','Student borrows from parents; P dollars, t years, r interest rate, 6 percent is 0.06/year.','T6','Interest-model input, not external financial advice.'),
(5,'Single loan formula','After time t owe P(1+rt)=P+Prt.','T6','A09: constant simple interest.'),
(5,'Borrowing function','f(t) in dollars/year, allowed to vary with time.','T6','Rate distinguished from principal or balance.'),
(5,'Constant-rate illustration','$1000/month corresponds to f(t)=12000/year.','T6,T9','Amounts and units preserved.'),
(5,'Monthly grid','Delta t=1/12 year=1 month; t_i=i/12, i=1,...,12.','T6,T7','Right-end monthly sampling.'),
(6,'Monthly amount','f(t_i) is rate during ith month, amount f(t_i)Delta t.','T7','A10: exact only for relevant constant/average rate; otherwise sampled approximation.'),
(6,'Borrowed finite total','Sum_i=1^12 f(t_i)Delta t.','T7','Principal only.'),
(6,'Borrowed continuous total','As Delta t->0, integral_0^1 f(t)dt.','T7','A11: implicit n->infinity at fixed horizon.'),
(6,'Units sentence','Total borrowed in one year is described as dollars per year.','T7','A12: visible source error; integral has dollar units.'),
(6,'Owed-total interpretation','Amount owed depends on interest rate.','T8','Distinguish from total borrowed.'),
(6,'One contribution with interest','f(t_i)(1+r(1-t_i))Delta t owed for amount borrowed at time t_i.','T8','A13: remaining duration 1 year minus borrowing time.'),
(6,'Final owed-total integral','Integral_0^1 f(t)(1+r(1-t))dt.','T8,T9','A14: common horizon; simple interest; finite and continuous timing distinct.'),
(2,'Running administration','Lecture 18 / 18.01 Fall 2006 headers and printed page numbers 1-5 on physical pages 2-6.','Identity','Repeated metadata checked on all five lecture pages.')]
coverage=[]
for i,(p,kind,content,section,qualification) in enumerate(items,1):
    coverage.append(dict(id=f'C{i:02d}',physical_pdf_page=p,printed_lecture_page=None if p==1 else p-1,
                         type=kind,source_content=content,dossier_sections=section,qualification=qualification,
                         inspected_text=f'lec18-p{p:02d}.txt',inspected_original_image=f'lec18-p{p:02d}.png',status='covered'))
coverage[-1]['physical_pdf_pages']=[2,3,4,5,6]
(out/'source-coverage.json').write_text(json.dumps(dict(material_id='D016',coverage_count=len(coverage),original_examples=3,original_figures=5,physical_pages=6,items=coverage),indent=2)+'\n')

meaning={
'B01':('Arithmetic, percentages, units','Rate conversion, principal times interest fraction, dimensional consistency.','Already granted; do not confuse repeated percentage growth with the supplied simple-interest model.'),
'B02':('Explicit mensuration','Rectangle and triangle areas, prism-volume contrast.','General square-pyramid formula is supplied by the original; it is not separately displayed in this paragraph.'),
'B03':('Variables, constants, intervals','Fix b as n changes; vary b for derivatives; interpret closed intervals.','Function/domain restrictions remain required.'),
'B04':('Inequality signs','Divide by n^3>0 and multiply by b^3 for b>0.','Negative b would require separate sign and geometric interpretation.'),
'B05':('Sequence convergence','Finite sums form a sequence; approaching a limit is not substituting infinity.','A fixed-point condition alone is not a convergence proof.'),
'B06':('Sigma notation and arithmetic progressions','Sum of integers for linear-area and monthly-loan calculations.','Formula and index limits are explicit, not a topic-name inference.'),
'B07':('Derivative from difference quotient','Interpret accumulation derivative locally.','No general derivative exists merely because an integral exists.'),
'B08':('Power rule and elementary derivative rules','Differentiate b^3/3 and b^2/2.','These are prior competence.'),
'B09':('Antiderivatives, fundamental theorem, rectangle sums','Independent area checks and the concept of limiting rectangle sums.','The baseline expressly qualifies the theorem with suitably continuous/well-behaved cases.'),
'B10':('Signed definite integral','Qualify source area prose; distinguish orientation and geometric area.','A negative integrand is not an ordinary positive rectangle height.'),
'B11':('Numerical integration and monotone rectangle bounds','Left/right brackets and convergence of endpoint approximations.','Section includes the displayed trapezium rule and following sign/bounds prose.'),
'B12':('FM01 induction','Independent proof of sum-of-squares identity.','Finite checks alone are not a universal proof.'),
'B13':('FM23 integer, square, cube sums and telescoping','Direct source finite-sum checks and alternative derivation.','These formulas are explicitly granted prior knowledge.'),
'B14':('FM30 volumes and means','Average-value claim context; independent volume/area checks.','Do not make an integral-based pyramid calculation the foundation of the original x^2-area proof.'),
'B15':('FM57 dimensions','Add matching quantities; interest factor dimensionless.','Dimension agreement alone cannot prove a model.'),
'B16':('FM58 variable-force work','Optional analogy for accumulating a varying quantity.','Not necessary for original derivations; no line integral imported.'),
'B17':('FM61 impulse','Optional rate/increment-to-total analogy.','Not a new loan or finance premise.'),
'B18':('Physics graph gradients and areas','Graph-area units are products of axis units; strip approximation.','Supports correction of source dollar/year total error.'),
'B19':('Physics current and transferred charge','Rate times duration gives amount, constant Q=It.','Optional cross-subject bridge; formal calculus supplied separately.'),
'B20':('Chemistry rate conventions','Rates have per-time units and sign conventions.','Analogy only; no kinetic model needed.'),
'B21':('Chemistry chromatography','Integrated peak area versus peak height.','Optional familiar accumulation context; no calibration numbers used.'),
'B22':('FM71 combined-subject scope','Use actual combined premises and show consequential deductions.','No university formalism or financial distribution inferred from a topic label.'),
'B23':('Power antiderivatives and linearity','Independent x, x^2, and polynomial borrowing integral checks.','Verification method already taught in baseline; preserve source geometric method as its own argument.')}
lines=['# Complete four-subject baseline map','',
'Input: `/workspace/scratch/f9c0b7fc7e76/d013-clean-r33-20261012/inputs/student-baseline.txt`.',
'Identity: 247,840 bytes; SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`.',
'All byte ranges are zero-based, start inclusive and end exclusive, measured on the original unnormalised bytes. CRLF/CRCRLF line endings were not rewritten in the source. Sixteen line-bounded chunks provide full semantic coverage [0,247840); their actual ranges are in `baseline-chunks.json` and `access-log.jsonl`.','',
'## Full inspection map','',
'| Subject/input section | Original byte range | Inspected extent and relationship to D016 |',
'|---|---:|---|',
'| Cover and joint-use rules | [0,2093) | Complete. Defines combined four-subject grant, no outside premises, competence assumption rather than measured mastery. |',
'| Mathematics A H240 | [2093,50677) | Complete: arithmetic/mensuration; proof; algebra/functions/coordinate geometry; sequences and binomial expansion; trigonometry; exponentials/logs; differentiation; integration/ODEs; numerical methods; vectors; statistics/probability/testing; mechanics; scope limits. Direct calculus, sum, area, and unit premises are below. |',
'| Further Mathematics A H245 | [50677,90025) | Complete Pure Core FM01-FM36, Statistics Y542 FM37-FM56, Mechanics Y543 FM57-FM68, and scope/resource/combination FM69-FM71. Direct premises include induction, exact square sums, average values, and dimensional checks. All other topics read; no complex, matrix, distribution, or advanced mechanics premise required. |',
'| Physics A H556 | [90025,150631) | Complete reference constants; quantities/measurement/practice; mechanics/materials; electricity/waves/quantum phenomena; thermal/circular/SHM/gravity; stars/cosmology; capacitors/fields; nuclear/imaging; entry-scope limits. Rate/area units and current provide optional bridges; no other physical content is needed. |',
'| Chemistry A H432 | [150631,247840) | Complete CH-META, CH-00 through CH-12, all subsections and CH-REF. Units, reaction rates and chromatographic area supply optional analogies; all bonding, equilibrium, acids, thermochemistry, redox, organic, spectroscopy, practical and scope content was read. No further chemical premise is needed. |','',
'The baseline contains provenance URLs and a terminal reference to a separate research file. Neither those URLs nor any separate file was followed. The source permitted exactly this complete baseline, not its provenance corpus.','',
'## Consequential premise map','',
'| ID | Actual premise | Exact byte range | Use/bridge | Boundary |','|---|---|---:|---|---|']
for rec in refs:
    title,use,bound=meaning[rec['id']]
    lines.append(f"| {rec['id']} | {title} | [{rec['byte_start']},{rec['byte_end_exclusive']}) | {use} | {bound} |")
lines += ['','## Needed bridges still owed by an explanation','',
'1. Index a sample point to its own subinterval and multiply its height/rate by that interval width.',
'2. Derive the b^3/n^3 factor and identify right-endpoint overestimation for x^2 on [0,b], b>0.',
'3. Explain unit layer heights and which bounding solids have the source-supplied one-third volume factor.',
'4. Explain the vanishing upper/lower gap; separate the n-limit from later differentiation in b.',
'5. Preserve the common-limit/regularity conditions in the definition and signed-area qualification.',
'6. Refine the 12-month sum to n periods at fixed horizon rather than shrinking twelve periods to zero duration.',
'7. Use the remaining duration T−t for each loan and name the source model as simple interest.',
'8. Distinguish borrowing rate, amount borrowed, total borrowed, and final debt, with compatible units.',
'9. Separate exact finite monthly payment timing from the continuous flow limit.',
'',
'These bridges can be built from the actual granted premises plus the original source; they do not require a new external subject source. The map makes no finding about any teaching artifact, assessment response, or student acceptance.']
(out/'baseline-map.md').write_text('\n'.join(lines)+'\n')

recovery=[]
for p in range(1,7):
    q=src/f'lec18-p{p:02d}.txt';raw=q.read_bytes();txt=raw.decode()
    offsets=[];i=0
    for ch in txt:
        if ch=='\ufffd':offsets.append(i)
        i+=len(ch.encode())
    recovery.append(dict(physical_pdf_page=p,text_bytes=len(raw),full_text_read_range=[0,len(raw)],replacement_glyph_count=len(offsets),replacement_glyph_byte_offsets=offsets,image=f'lec18-p{p:02d}.png',resolution=[1190,1540],image_read_detail='original'))
(out/'source-text-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
(out/'source-recovery.md').write_text('''# Original-source extraction and clipping recovery

All six text files were read completely, and all six images were inspected at the tool's `original` detail level, 1190 × 1540 pixels. No supplied image edge clipped a mathematical line or figure required by the lecture. The body/formulas and printed page numbers were visible. The full-text calls and all sixteen bounded baseline outputs were returned without a truncation notice or missing tail. Therefore there is no unrecovered tool-output clipping gap.

Text extraction alone does lose mathematical glyphs and all figure geometry. `source-text-recovery.json` records the actual replacement-character byte offsets, not character indices. Image-grounded recoveries are:

- Physical p1: course/term and provenance cover; no mathematical body.
- Physical p2: superscript squares, parentheses enclosing b/n and 2b/n, the expanded n-term right-rectangle sum and the b³/n³ factor. Figure 1 has an area panel and a rectangle panel, both with a and b. All reconstructed formulas are in T1–T2.
- Physical p3: Figure 2's increasing parabola and three right rectangles. Figure 3 has n=4 nested square tiers and a side staircase bounded by green inner/red outer pyramid outlines. The strict lower and upper bounds, their one-third factors, and exponents are visible. The word “prism” is present in the image and is a source wording defect, not an extraction accident.
- Physical p4: normalized strict bounds; the b³-scaled limit and b³/3 area; the linear sum tending to b²/2; both derivative identities; and A′(b)=f(b), whose prime is corrupted in extraction. Figure 4 labels both triangle dimensions b. These are reconstructed in T2–T4.
- Physical p5: Figure 5's internal tag c_i and red rectangle. Both sigma summations have lower i=1 and upper n. The definite-integral symbol has lower a and upper b, and its integrand is f(x)dx. The first source simple-interest formula and the month-end time list are completely visible. Reconstructed in T5–T6.
- Physical p6: finite borrowing sum has i=1,…,12. Both integrals have bounds 0 and 1. The weight is 1+r(1−t), with outer and inner parentheses; the discrete weight uses t_i. The source's dollar/year wording for the integrated total is visible and is a genuine units error. Reconstructed in T7–T9.

Red boxes around figure-reference numbers are PDF hyperlink annotations, not mathematical boxes or red emphasis intended for an exercise. Running headers and page numbers have no further mathematical content. The source includes three worked examples and five numbered figures; it includes no separate assessment-question set.

This record preserves rather than overwrites the original text extractions. Corrected mathematical readings live only in the preparation dossier and coverage map.
''')

exec_history=[
 {'attempt':1,'interpreter':'system python','status':'infrastructure failure before any check','error':'ModuleNotFoundError: No module named sympy'},
 {'attempt':2,'interpreter':'CODEX_PRIMARY_RUNTIME_PYTHON','status':'infrastructure failure before any check','error':'ModuleNotFoundError: No module named sympy'},
 {'attempt':3,'interpreter':'system python','status':'pass','change':'Removed optional external algebra dependency; used exact standard-library rational and polynomial arithmetic.','check_groups':14,'assertions':1737}
]
(out/'check-execution-history.json').write_text(json.dumps(exec_history,indent=2)+'\n')

with (out/'access-log.jsonl').open('a') as f:
    f.write(json.dumps({'step':16,'tool':'apply_patch','operation':'write independently derived technical-dossier.md','inputs':'previously inspected allowed source and complete baseline only'})+'\n')
    f.write(json.dumps({'step':17,'tool':'apply_patch and exec_command','operation':'write and execute independent calculation checks','file':str(out/'calculation-checks.py'),'execution_history':'check-execution-history.json','content_inputs':'none; independent mathematical constants/expressions','network_used':False})+'\n')
    f.write(json.dumps({'step':18,'tool':'exec_command/python','operation':'read two runtime environment variable values after dependency import failure','names':['CODEX_PRIMARY_RUNTIME_PYTHON','CODEX_PRIMARY_RUNTIME_ROOT'],'subject_content_read':False})+'\n')
    f.write(json.dumps({'step':19,'tool':'exec_command/python','operation':'build baseline-map, source-coverage and source-recovery records','source_paths':[str(base)]+[str(src/f'lec18-p{p:02d}.txt') for p in range(1,7)],'physical_read_ranges':'full [0,length) of each listed file; content already completely read in steps 2 and 5-12','own_records_read':['baseline-premise-spans.json'],'no_new_external_content':True})+'\n')
print(json.dumps({'coverage_atoms':len(coverage),'baseline_premise_spans':len(refs),'recovery_pages':len(recovery),'checks_passed':14,'assertions':1737}))
