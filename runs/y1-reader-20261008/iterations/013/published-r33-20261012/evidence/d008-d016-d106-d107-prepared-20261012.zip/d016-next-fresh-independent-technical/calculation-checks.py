#!/usr/bin/env python3
"""Independent D016 preparation checks; Python standard library only.
Reads no source, baseline, or teaching. Exact finite sums are compared against
independently expressed closed forms. A small Laurent-polynomial calculator
checks identities coefficientwise and evaluates polynomial integrals exactly.
"""
from fractions import Fraction as F
from pathlib import Path
import json

OUT=Path(__file__).resolve().parent

class Poly:
    """Exact univariate Laurent polynomial: exponent -> rational coefficient."""
    def __init__(self, value=0):
        d=value.d if isinstance(value,Poly) else value if isinstance(value,dict) else {0:F(value)}
        self.d={int(k):F(v) for k,v in d.items() if v}
    def __add__(self,other):
        other=Poly(other);keys=set(self.d)|set(other.d)
        return Poly({k:self.d.get(k,F(0))+other.d.get(k,F(0)) for k in keys})
    __radd__=__add__
    def __neg__(self):return Poly({k:-v for k,v in self.d.items()})
    def __sub__(self,other):return self+-Poly(other)
    def __rsub__(self,other):return Poly(other)+-self
    def __mul__(self,other):
        other=Poly(other);d={}
        for k,v in self.d.items():
            for l,w in other.d.items():d[k+l]=d.get(k+l,F(0))+v*w
        return Poly(d)
    __rmul__=__mul__
    def __truediv__(self,other):
        other=Poly(other)
        if len(other.d)!=1:raise ValueError('Only nonzero monomial divisors are supported')
        (k,v),=other.d.items()
        return Poly({l-k:w/v for l,w in self.d.items()})
    def __pow__(self,power):
        if not isinstance(power,int) or power<0:raise ValueError('Nonnegative integer powers only')
        ans=Poly(1)
        for _ in range(power):ans=ans*self
        return ans
    def __eq__(self,other):return self.d==Poly(other).d
    def __repr__(self):return repr({k:str(v) for k,v in sorted(self.d.items())})
    def at(self,x):return sum((v*F(x)**k for k,v in self.d.items()),F(0))
    def diff(self):return Poly({k-1:k*v for k,v in self.d.items() if k})
    def definite_integral(self,a,b):
        if any(k<0 for k in self.d):raise ValueError('This checker integrates ordinary polynomials only')
        return sum((v*(F(b)**(k+1)-F(a)**(k+1))/F(k+1) for k,v in self.d.items()),F(0))
    def limit_inf(self):
        if any(k>0 for k in self.d):raise ValueError('Nonconstant positive powers do not have finite limits here')
        return self.d.get(0,F(0))
    def compose(self,inner):
        if any(k<0 for k in self.d):raise ValueError('Polynomial composition only')
        return sum((v*Poly(inner)**k for k,v in self.d.items()),Poly())

records=[];assertions=0;previous=0

def eq(a,b):
    global assertions
    assert a==b,(a,b)
    assertions+=1

def truth(value):
    global assertions
    assert value
    assertions+=1

def emit(cid,title,method,details):
    global previous
    records.append(dict(id=cid,title=title,method=method,assertions=assertions-previous,status='pass',details=details))
    previous=assertions

for n in range(1,501):
    eq(sum(range(1,n+1)),n*(n+1)//2)
    eq(sum(i*i for i in range(1,n+1)),n*(n+1)*(2*n+1)//6)
emit('K01','Direct integer sums','Exact enumeration against separately expressed closed forms',
     {'n_range':[1,500],'sum_i':'n(n+1)/2','sum_i_squared':'n(n+1)(2n+1)/6'})

n=Poly({1:1});S=n*(n+1)*(2*n+1)/6
# Coefficientwise identities hold as polynomials, not merely at sampled n.
eq(S.at(1),F(1));eq(S.compose(n+1)-S,(n+1)**2)
eq((n+1)**3-1,3*S+3*n*(n+1)/2+n)
emit('K02','Finite-square-sum universal identity','Exact polynomial coefficient comparisons for induction and telescoping',
     {'base':'F(1)=1','induction':'F(n+1)-F(n)=(n+1)^2','telescoping':'(n+1)^3-1=3S+3n(n+1)/2+n'})

low_gap=n*(3*n+1)/6;high_gap=(n+1)*(3*n+2)/6
eq(S-n**3/3,low_gap);eq((n+1)**3/3-S,high_gap)
truth(all(v>0 for v in low_gap.d.values()));truth(all(v>0 for v in high_gap.d.values()))
for k in range(1,501):
    sm=sum(i*i for i in range(1,k+1));truth(F(k**3,3)<sm<F((k+1)**3,3))
eq(sum(i*i for i in range(1,5)),30)
emit('K03','Staircase pyramid bounds','Positive polynomial gaps and direct exact volume samples',
     {'lower_gap':repr(low_gap),'upper_gap':repr(high_gap),'n4':{'lower':'64/3','stairs':'30','upper':'125/3'},
      'universal_reason':'Both factored gaps are positive for every n>=1.'})

normalized_R=S/n**3
eq(normalized_R,Poly(F(1,3))+Poly(1)/(2*n)+Poly(1)/(6*n*n))
eq(normalized_R.limit_inf(),F(1,3));eq(((n+1)**3/(3*n**3)).limit_inf(),F(1,3))
samples=[]
for k in [1,2,4,10,100,1000]:
    actual=F(sum(i*i for i in range(1,k+1)),k**3);error=actual-F(1,3)
    eq(error,F(1,2*k)+F(1,6*k*k));samples.append({'n':k,'R_for_b1':str(actual),'error':str(error)})
emit('K04','Square-curve Riemann limit','Laurent coefficient limit checked against independent exact direct summation',
     {'limit':'b^3/3','samples':samples})

for nn in [1,2,3,4,7,12,25,100]:
    for bb in [F(1,2),F(1),F(2),F(5)]:
        dx=bb/nn
        rr=sum(dx*(i*dx)**2 for i in range(1,nn+1))
        ll=sum(dx*((i-1)*dx)**2 for i in range(1,nn+1))
        mm=sum(dx*(F(2*i-1,2)*dx)**2 for i in range(1,nn+1))
        eq(rr,bb**3*(F(1,3)+F(1,2*nn)+F(1,6*nn*nn)))
        eq(ll,bb**3*(F(1,3)-F(1,2*nn)+F(1,6*nn*nn)))
        eq(mm,bb**3*(F(1,3)-F(1,12*nn*nn)))
        eq(rr-ll,bb**3/nn)
        qq=sum(dx*((F(i-1)+F((i%7)+1,9))*dx)**2 for i in range(1,nn+1))
        truth(ll<=qq<=rr)
emit('K05','Endpoint and interior-tag sensitivity','Widths/heights recomputed directly in 32 n/b cases',
     {'left':'b^3(1/3-1/(2n)+1/(6n^2))','right':'b^3(1/3+1/(2n)+1/(6n^2))',
      'midpoint':'b^3(1/3-1/(12n^2))','bracket_width':'b^3/n','tag_offsets':'((i mod 7)+1)/9, inside each subinterval'})

x=Poly({1:1})
eq((n*(n+1)/2)/(n*n),(n+1)/(2*n));eq(((n+1)/(2*n)).limit_inf(),F(1,2))
for bb in [F(1,2),F(1),F(2),F(5)]:
    eq(x.definite_integral(0,bb),bb*bb/2)
    eq((x*x).definite_integral(0,bb),bb**3/3)
eq((x**3/3).diff(),x*x);eq((x*x/2).diff(),x)
emit('K06','Triangle, antiderivatives, and derivative pattern','Independent polynomial integration/differentiation plus triangle formula',
     {'triangle_area':'b^2/2','square_curve_area':'b^3/3','derivatives':['b^2','b']})

h=Poly({1:1})
eq((F(1,2)+2*h-F(1,2))/h,2);eq((F(1,2)-h-F(1,2))/(-h),1);truth(1!=2)
emit('K07',"Continuity qualification for A'=f",'Exact one-sided increments for a height-1/height-2 step',
     {'jump_location':'1/2','left_slope':1,'right_slope':2,'conclusion':'An integral exists while the accumulation derivative fails at the jump.'})

rate=(1,-1);dt=(0,1);interest_rate=(0,-1);elapsed=(0,1)
add=lambda u,v:tuple(a+b for a,b in zip(u,v))
eq(add(rate,dt),(1,0));eq(add(interest_rate,elapsed),(0,0));eq(F(12000)*F(1,12),F(1000));eq(F(6,100),F(3,50))
emit('K08','Dimensions and rate conversion','Independent unit-exponent arithmetic and month/year conversion',
     {'basis':['dollar','time'],'integrated_rate_units':'dollars','interest_multiplier_units':'dimensionless','one_month_principal':'1000 dollars','annual_r':'3/50 per year'})

t=Poly({1:1});K=F(12000);r=F(3,50);w=1+r*(1-t)
principal=sum(K/F(12) for _ in range(12))
monthly_end=sum((K/12)*(1+r*(1-F(i,12))) for i in range(1,13))
monthly_start=sum((K/12)*(1+r*(1-F(i-1,12))) for i in range(1,13))
monthly_middle=sum((K/12)*(1+r*(1-F(2*i-1,24))) for i in range(1,13))
continuous=(12000*w).definite_integral(0,1)
eq(principal,F(12000));eq(monthly_end,F(12330));eq(monthly_start,F(12390));eq(monthly_middle,F(12360));eq(continuous,F(12360))
emit('K09','Original constant borrowing example evaluated','Exact 12-loan sums versus independent polynomial integration',
     {'principal':str(principal),'month_end_debt':str(monthly_end),'continuous_debt':str(continuous),
      'month_start_debt':str(monthly_start),'midmonth_debt':str(monthly_middle),'currency':'dollars'})

samples=[]
for nn in [1,2,4,12,120,1200]:
    debt=sum((K/nn)*(1+r*(1-F(i,nn))) for i in range(1,nn+1))
    eq(debt,K*(1+r*F(nn-1,2*nn)));eq(debt-F(12360),-K*r/F(2*nn))
    samples.append({'n':nn,'debt':str(debt),'error':str(debt-F(12360))})
eq((K*(1+r*(n-1)/(2*n))).limit_inf(),F(12360))
emit('K10','Continuous borrowing limit from discrete timing','Direct cash-flow sums at six resolutions and coefficient limit',
     {'formula':'D_n=K[1+r(n-1)/(2n)]','limiting_error':'-Kr/(2n)','samples':samples})

late=24000*t;early=24000*(1-t)
eq(late.definite_integral(0,1),F(12000));eq(early.definite_integral(0,1),F(12000))
eq((late*w).definite_integral(0,1),F(12240));eq((early*w).definite_integral(0,1),F(12480))
emit('K11','Variable borrowing with fixed total principal','Independent polynomial integrals for early and late flows',
     {'late_rate':'24000t','early_rate':'24000(1-t)','principal_each':'12000','late_debt':'12240','early_debt':'12480'})

eq(w.at(1),F(1));eq(w.at(0),1+r)
eq(late.definite_integral(0,1),(late*(1+0*(1-t))).definite_integral(0,1));eq((0*w).definite_integral(0,1),F(0))
for pp,dd in [(12000,12240),(12000,12330),(12000,12360),(12000,12390),(12000,12480)]:truth(pp<=dd<=pp*(1+r))
emit('K12','Boundary and debt-bound checks','Endpoint weights, zero cases, and nonnegative-flow bounds',
     {'end_weight':'1','start_weight':'1+r','zero_r':'D=B','zero_flow':'D=B=0','bound':'B<=D<=(1+rT)B for f,r>=0'})

m=Poly({1:1});month_integrand=1000*(1+F(1,200)*(12-m))
eq(month_integrand.definite_integral(0,12),continuous);eq((12000*w).compose(m/12)/12,month_integrand)
emit('K13','Time-unit invariance','Year-to-month substitution and separate exact polynomial integration',
     {'monthly_flow':'1000 dollars/month','monthly_r':'0.005/month','horizon_months':12,'debt':'12360 dollars'})

wrong_tag_samples=[]
for nn in [1,2,10,100]:
    wrong=sum(F(1,nn)*1 for _ in range(nn));eq(wrong,F(1));truth(wrong!=F(1,2));wrong_tag_samples.append({'n':nn,'all_tags_at_1':str(wrong)})
emit('K14','Necessary per-subinterval restriction','Countercheck of a possible misreading of any sample point',
     {'function':'f(x)=x on [0,1]','true_area':'1/2','invalid_tag_sums':wrong_tag_samples,
      'interpretation':'For n>1 most tags at 1 violate their own subinterval; allowing any point in the full interval is wrong.'})

report=dict(status='pass',scope='independent technical preparation only',check_groups=len(records),assertions=assertions,checks=records,
            limitations=['Finite enumerations validate cases but are not universal proofs.',
                         'Universal identities, signs, and limit conditions are separately derived in technical-dossier.md.',
                         'The standard-library polynomial checker compares rational coefficients; no external computer-algebra service was used.',
                         'No generated teaching or proposed assessment was read or tested.'])
(OUT/'calculation-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','check_groups','assertions']}))
