from pathlib import Path
import hashlib,json,datetime,os
out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ids=json.loads((out/'input-identities.json').read_text())
for r in ids:
    p=Path(r['path']);assert p.stat().st_size==r['bytes'];assert sha(p)==r['sha256']
chunks=json.loads((out/'baseline-chunks.json').read_text())
assert len(chunks)==16 and chunks[0]['byte_start']==0 and chunks[-1]['byte_end_exclusive']==247840
assert all(a['byte_end_exclusive']==b['byte_start'] for a,b in zip(chunks,chunks[1:]))
assert sum(c['bytes'] for c in chunks)==247840
log=[json.loads(l) for l in (out/'access-log.jsonl').read_text().splitlines()]
semantic=[r for r in log if r.get('operation')=='semantic baseline read']
assert len(semantic)==16
assert {(r['byte_start'],r['byte_end_exclusive']) for r in semantic}=={(r['byte_start'],r['byte_end_exclusive']) for r in chunks}
images=[r for r in log if r.get('operation')=='visual semantic read at original resolution']
assert len(images)==6 and all(r['pixels']==[1190,1540] and r['detail']=='original' for r in images)
coverage=json.loads((out/'source-coverage.json').read_text());assert coverage['coverage_count']==42 and len(coverage['items'])==42
assert {r['physical_pdf_page'] for r in coverage['items']}==set(range(1,7))
assert all(r['status']=='covered' for r in coverage['items'])
checks=json.loads((out/'calculation-results.json').read_text())
assert checks['status']=='pass' and checks['check_groups']==14 and checks['assertions']==1737
assert all(r['status']=='pass' for r in checks['checks'])
refs=json.loads((out/'baseline-premise-spans.json').read_text());assert len(refs)==23
base=Path(ids[-1]['path']).read_bytes()
for r in refs:
    assert base[r['byte_start']:].startswith(r['start_phrase'].encode())
    assert 0<=r['byte_start']<r['byte_end_exclusive']<=len(base)
recovery=json.loads((out/'source-text-recovery.json').read_text());assert len(recovery)==6
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
readiness=dict(material_id='D016',status='ready_and_sealed',stage='independent_source_only_preparation',prepared_at_utc=now,
               original_pdf_sha256=ids[12]['sha256'],baseline_sha256=ids[-1]['sha256'],baseline_bytes=247840,
               original_input_files=14,original_pdf_pages=6,source_images_read_original_resolution=6,source_texts_fully_read=6,
               source_text_bytes=sum(r['text_bytes'] for r in recovery),baseline_subjects_fully_read=4,baseline_chunks_fully_read=16,
               coverage_atoms=42,original_examples=3,original_figures=5,baseline_premise_spans=23,
               calculation_check_groups=14,calculation_assertions=1737,unrecovered_clipping_gaps=0,
               no_generated_teaching_read=True,no_prof_package_read=True,no_network_browser_github=True,no_delegation=True,
               author_findings_release_gate='after whole teaching artifact freeze',
               next_inputs='Await root-supplied exact then-current complete PROF package and fresh prompt-only packet.',
               nonclaims=['No teaching authored.','No student trial or SASIS performed.','No teaching or assessment acceptance determined.'])
assert readiness['original_pdf_sha256']=='3469042c0ca6aa75aa7e420b2bbf726228c31093aea11ddb2fc0044a4404fec0'
assert readiness['baseline_sha256']=='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
(out/'readiness.json').write_text(json.dumps(readiness,indent=2)+'\n')
with (out/'access-log.jsonl').open('a') as f:
    f.write(json.dumps({'step':20,'tool':'exec_command/pdfinfo','operation':'verify original PDF identity metadata','path':'/workspace/scratch/f9c0b7fc7e76/original-inputs/D016/lec18.pdf','file_bytes':985183,'pages':6,'page_size_points':[612,792],'semantic_pdf_content':'not extracted by this command','metadata_only':True})+'\n')
    f.write(json.dumps({'step':21,'tool':'apply_patch','operation':'refine own independent derivations and record isolation audit; make own record-builder premise extraction idempotent','paths':['technical-dossier.md','access-audit.md','build-records.py'],'external_subject_inputs':False})+'\n')
    f.write(json.dumps({'step':22,'tool':'exec_command/python','operation':'seal preparation; verify all original identities unchanged, semantic-read coverage, pixel dimensions, source coverage, premise ranges, and complete passed check report','permitted_original_read_ranges':'full [0,length) for each of the 15 entries in input-identities.json','own_payloads_read':'all local preparation payloads for validation and hashing','source_semantic_reread':'baseline anchor prefixes only; complete baseline had already been read','new_external_content':False})+'\n')
    f.write(json.dumps({'step':23,'tool':'exec_command/python','operation':'verify newly written SHA256SUMS against complete preparation payloads and manifest; set sealed files read-only','scope':'this preparation workspace only','completion_enforced':'script asserts every checksum before reporting readiness'})+'\n')
payloads=[p for p in sorted(out.iterdir()) if p.is_file() and p.name not in ['MANIFEST.json','SHA256SUMS']]
manifest=dict(schema='independent-technical-preparation-seal-v1',material_id='D016',sealed_at_utc=now,
              status='sealed_preparation_only',workspace=str(out),isolation='Source-only; findings withheld from future author until whole teaching freeze.',
              source_identity=readiness['original_pdf_sha256'],baseline_identity=readiness['baseline_sha256'],
              input_count=len(ids),inputs_preserved_unchanged=True,inputs=ids,
              inspection_counts={k:readiness[k] for k in ['original_pdf_pages','source_images_read_original_resolution','source_texts_fully_read','source_text_bytes','baseline_subjects_fully_read','baseline_chunks_fully_read','coverage_atoms','baseline_premise_spans','calculation_check_groups','calculation_assertions','unrecovered_clipping_gaps']},
              payload_count=len(payloads),payloads=[dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in payloads],
              checksum_scope='SHA256SUMS covers all payloads and MANIFEST.json; excludes itself to avoid recursion.',
              future_prof_input='Not read; exact then-current complete package to be supplied by root.',
              limitations=readiness['nonclaims'])
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
sealed=payloads+[out/'MANIFEST.json']
(out/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(sealed)))
for row in (out/'SHA256SUMS').read_text().splitlines():
    expected,name=row.split('  ',1);assert sha(out/name)==expected
for p in sealed+[out/'SHA256SUMS']:p.chmod(0o444)
print(json.dumps(dict(status='sealed_ready',payload_files=len(payloads),sealed_files_including_manifest_and_checksums=len(payloads)+2,
                     coverage_atoms=42,check_groups=14,assertions=1737,baseline_chunks=16,
                     manifest_sha256=sha(out/'MANIFEST.json'),sha256sums_sha256=sha(out/'SHA256SUMS'))))
