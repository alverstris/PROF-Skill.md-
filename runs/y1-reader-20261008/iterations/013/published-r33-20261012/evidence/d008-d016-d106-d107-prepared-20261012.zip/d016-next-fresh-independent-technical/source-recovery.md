# Original-source extraction and clipping recovery

All six text files were read completely, and all six images were inspected at the tool's `original` detail level, 1190 × 1540 pixels. No supplied image edge clipped a mathematical line or figure required by the lecture. The body/formulas and printed page numbers were visible. The full-text calls and all sixteen bounded baseline outputs were returned without a truncation notice or missing tail. Therefore there is no unrecovered tool-output clipping gap.

Text extraction alone does lose mathematical glyphs and all figure geometry. `source-text-recovery.json` records the actual replacement-character byte offsets, not character indices. Image-grounded recoveries are:

- Physical p1: course/term and provenance cover; no mathematical body.
- Physical p2: superscript squares, parentheses enclosing b/n and 2b/n, the expanded n-term right-rectangle sum and the b³/n³ factor. Figure 1 has an area panel and a rectangle panel, both with a and b. All reconstructed formulas are in T1–T2.
- Physical p3: Figure 2's increasing parabola and three right rectangles. Figure 3 has n=4 nested square tiers and a side staircase bounded by green inner/red outer pyramid outlines. The strict lower and upper bounds, their one-third factors, and exponents are visible. The word “prism” is present in the image and is a source wording defect, not an extraction accident.
- Physical p4: normalized strict bounds; the b³-scaled limit and b³/3 area; the linear sum tending to b²/2; both derivative identities; and A′(b)=f(b), whose prime is corrupted in extraction. Figure 4 labels both triangle dimensions b. These are reconstructed in T2–T4.
- Physical p5: Figure 5's internal tag c_i and red rectangle. Both sigma summations have lower i=1 and upper n. The definite-integral symbol has lower a and upper b, and its integrand is f(x)dx. The first source simple-interest formula and the month-end time list are completely visible. Reconstructed in T5–T6.
- Physical p6: finite borrowing sum has i=1,…,12. Both integrals have bounds 0 and 1. The weight is 1+r(1−t), with outer and inner parentheses; the discrete weight uses t_i. The source's dollar/year wording for the integrated total is visible and is a genuine units error. Reconstructed in T7–T9.

Red boxes around figure-reference numbers are PDF hyperlink annotations, not mathematical boxes or red emphasis intended for an exercise. Running headers and page numbers have no further mathematical content. The source includes three worked examples and five numbered figures; it includes no separate assessment-question set.

This record preserves rather than overwrites the original text extractions. Corrected mathematical readings live only in the preparation dossier and coverage map.
