# D016 independent source-only technical dossier

Preparation only. This document is not teaching, an author prompt, a student response, a SASIS result, or a teaching-acceptance decision. Its findings must remain unavailable to the future author until the whole teaching artifact is frozen. No current or historical teaching artifact, prompt, review, audit, or PROF package was consulted. No network, browser, GitHub, or other agent's findings were used. No delegation occurred.

## Identity and complete inspection

The original is MIT 18.01 Single Variable Calculus, Fall 2006, Lecture 18, **Definite Integrals**: `lec18.pdf`, 985,183 bytes, SHA-256 `3469042c0ca6aa75aa7e420b2bbf726228c31093aea11ddb2fc0044a4404fec0`. It has six physical PDF pages: the OpenCourseWare cover and five lecture pages. Every supplied PNG was read at its original 1190 × 1540 resolution, and every byte of every supplied text extract was printed and read. Figures and mathematical glyphs were checked against the images, not inferred from broken extraction characters. The PDF was hashed; the semantic inspection used its supplied six image/text pairs. Metadata was used only to establish this original's identity. No URLs in it were followed.

The sole other content input is the complete four-subject baseline, 247,840 bytes, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. Its full contents were read in sixteen contiguous, line-bounded byte chunks, including all Mathematics, Further Mathematics, Physics, and Chemistry sections. `baseline-chunks.json`, `baseline-map.md`, `baseline-anchor-index.json`, and `baseline-premise-spans.json` identify coverage and consequential premises. No subject was reduced to a topic-name assumption. All original files are preserved unchanged.

Page references below use physical PDF pages, followed where useful by the printed lecture page. Coverage IDs refer to the exhaustive 42-item matrix in `source-coverage.json`.

## T1. Purposes, rectangles, and what counts as area

Source p2 (printed 1), C03–C06, says integrals calculate cumulative totals, averages, and areas. It then proposes three operations: divide the region into rectangles; add their areas; take a limit as widths become small. Figure 1(i) shows a positive curve and a shaded region between vertical boundaries a and b and the horizontal axis. Figure 1(ii) shows rectangles approximating that same region. No numerical curve values or numerical rectangle count is specified there, so no numerical example can be extracted from it. The example's rectangles for an increasing curve have right-endpoint heights, but the general definition later allows any in-subinterval sample.

For a finite interval a < b and a positive integer n, set Δx = (b−a)/n and x_i = a+iΔx for i = 0,…,n. For c_i in [x_(i−1),x_i], a rectangle has width Δx and height f(c_i). If f is nonnegative, its area is f(c_i)Δx, and the sum is an ordinary positive area approximation. If f can be negative, this product is a signed contribution; the definite integral is signed, while geometric area is obtained using |f| or splitting at sign changes. This distinction is already supplied by Mathematics, B10, and is needed to qualify the source's unrestricted prose about “area under” the curve.

The opening reference to averages is a use claim, not a worked topic in this lecture. No later original paragraph defines or calculates an average. The complete baseline independently supplies the average-value formula in FM30 (B14): for a < b, average f = (1/(b−a)) ∫_a^b f(x) dx. It also follows from the equal-sample arithmetic mean: (1/n)∑f(c_i) = (1/(b−a))∑f(c_i)Δx; take the common tagged-sum limit. It is therefore available as prior knowledge and an explicit deduction, but must not be falsely attributed to the original lecture's worked development.

## T2. Example 1: x², its finite sums, and its limit

Source p2–p4, C07–C11 and C18–C19. The original writes f(x)=x², a=0, and b arbitrary. Its rectangle-area geometry requires b>0; b=0 is the degenerate zero-area limit. For negative b, b/n is not a rectangle's positive base length, so an oriented-integral interpretation must be stated separately. The picture shows b to the right of zero.

With n positive integer subdivisions, x_i=ib/n and Δx=b/n. The first rectangle height is (b/n)² and the second (2b/n)². In general height is (ib/n)². Multiplying each height by its width gives

R_n = (b/n)(b/n)² + (b/n)(2b/n)² + … + (b/n)(nb/n)²
    = (b³/n³) ∑_(i=1)^n i².

The factor b³/n³ is obtained from one b/n for the width and two for the squared height. There are n terms, not n+1, and zero is excluded from this right-endpoint list. Figure 2 on p3 shows three illustrative right rectangles under the increasing parabola, with their top right corners on it. Those rectangles overestimate the curved area; the picture does not claim exact equality for finite n.

An independent finite-sum derivation, permitted by B06 and B13, pairs the integers to give ∑i=n(n+1)/2. Summing (i+1)³−i³=3i²+3i+1 over i=1,…,n gives

(n+1)³−1 = 3∑i² + 3n(n+1)/2 + n,

so ∑i² = n(n+1)(2n+1)/6. The induction alternative in B12 verifies the same formula: it holds at n=1, and F(n+1)−F(n)=(n+1)². These are checks and alternative permissible deductions; they do not replace the lecture's original geometric argument in the coverage record.

Substitution yields the exact finite expression

R_n = b³(1/3 + 1/(2n) + 1/(6n²)).

Therefore R_n → b³/3, with excess R_n−b³/3 = b³(1/(2n)+1/(6n²)) for b>0. The independent antiderivative check, using baseline B09, is [x³/3]_0^b = b³/3. Its agreement is a verification, not a justification that the lecture's geometric proof may silently assume its own result.

For completeness, left- and midpoint-sampled sums derived from the same algebra are

L_n = b³(1/3−1/(2n)+1/(6n²)),
M_n = b³(1/3−1/(12n²)).

Because x² increases on [0,b], any correctly tagged sum Q_n satisfies L_n ≤ Q_n ≤ R_n. The gap R_n−L_n=b³/n tends to zero, giving tag independence for this particular function without invoking a general integration theorem. This is also a useful check that endpoint choice affects finite approximations but not their limiting area. For b<0, ∫_0^b x² dx=b³/3 is negative, whereas the geometric area between b and 0 is |b|³/3; the original picture does not cover that case.

## T3. The staircase pyramid, its bounds, and the source's terminology

Source p3–p4, C12–C18. The staircase solid has square horizontal layers of unit thickness. Reading upward from the bottom, the side lengths are n,n−1,…,1, so layer volumes are n²,(n−1)²,…,1. Their total is S_n=∑_(i=1)^n i². Figure 3's left view is labelled n=4 and has four nested square levels, while its right view has four steps enclosed between a lower green triangular outline and an upper red triangular outline. The outlines are side views of smooth square pyramids, not three-dimensional prisms.

The implicit unit layer thickness is necessary: side area alone becomes layer volume only after multiplication by thickness 1. Centred, nested square layers make the visual containment clear. One precise reconstruction sets vertical coordinate z=0 at the bottom. For k=1,…,n, at heights k−1<z<k the stair's cross-section has side s=n−k+1. An inner square pyramid has side n−z and height n; an outer has side n+1−z and height n+1. At the same height the centred inner square is inside the stair square, and that square is inside the outer square. The outer also continues for n<z<n+1. Boundary slices do not affect volumes.

The source uses the volume formula V=(1/3)(base area)(perpendicular height), giving

n³/3 < S_n < (n+1)³/3,

strictly for every n≥1. This pyramid-volume rule is displayed in the original itself. The explicit mensuration inventory B02 lists prism and cone volumes but does not separately display a general square-pyramid formula; one should identify the source-supplied formula rather than claim a memorised named pyramid theorem was independently granted by the baseline. The finite-sum derivation in T2 gives a second route requiring no additional geometric theorem.

The prose in the original calls the comparators an “inner prism” and an “outer prism.” That terminology is inconsistent with both the diagram and the 1/3 volume factors. A prism of base n² and height n has volume n³, not n³/3. The intended smooth comparators are square pyramids. This is a source wording defect, not an OCR substitution; it is visible in the original image. The source also writes “volumne” and an extra close parenthesis in the second-layer description; those are nonmathematical typographical defects.

Independent algebra confirms the strict volume gaps:

S_n − n³/3 = n(3n+1)/6 > 0,
(n+1)³/3 − S_n = (n+1)(3n+2)/6 > 0.

For the pictured n=4, the staircase volume is 16+9+4+1=30, between 64/3 and 125/3. A graph-area integral of a pyramid's cross-sectional area can also check its volume using the baseline's integration, but that would be circular if used as the foundational geometric proof of the very x²-area formula being established. It is not used here as that proof.

Dividing the geometric bounds by n³>0 produces

1/3 < S_n/n³ < (1/3)(1+1/n)³.

The upper bound minus the lower bound is 1/n+1/n²+1/(3n³), tending to zero. Thus S_n/n³ is trapped within a vanishing interval above 1/3 and tends to 1/3. For b>0, multiplication by b³ preserves the inequalities; R_n→b³/3 follows. This explains the squeeze reasoning explicitly rather than assuming the name of a squeeze theorem was separately taught. It is a limit as integer n increases without bound, never substitution of an actual infinite integer into the finite formula.

## T4. Example 2 and the derivative pattern

Source p4, C20–C23. For f(x)=x on [0,b], b>0, right heights are ib/n and widths b/n, hence

R_n^(linear) = (b²/n²)∑_(i=1)^n i
             = (b²/2)(1+1/n) → b²/2.

Figure 4 is a right triangle with horizontal base b and vertical height b, so its geometric area bh/2 is b²/2, independently confirming the limit. A finite right sum exceeds that area by b²/(2n). The source's “similar but easier” reasoning does not spell out the integer-sum formula; that bridge is explicitly available from the arithmetic-progression rule B06 and FM23/B13.

The two derivatives shown in the original are

d/db (b³/3)=b², and d/db (b²/2)=b.

Both follow from the baseline power rule B08. In those statements b becomes the varying input of an accumulation function even though b was held fixed while n varied in the preceding limits. Distinguishing these two roles avoids conflating a variable upper endpoint with an increasing rectangle count.

The source then says the area A(b) under f should satisfy A′(b)=f(b). This is a motivated pattern, not an unrestricted theorem proved there. A correct local statement is: for fixed lower endpoint a, if f is integrable on the required interval and continuous at b, then A(b)=∫_a^b f(x)dx has A′(b)=f(b) (with appropriate one-sided interpretation at a domain endpoint). The full baseline already supplies the standard suitably continuous fundamental theorem for evaluating definite integrals, B09, and in FM42 the density/CDF derivative relation at differentiable points. Reintroducing this pattern is not necessarily new university content for this student.

An elementary local explanation uses A(b+h)−A(b)=∫_b^(b+h) f(x)dx. If |f(x)−f(b)| is bounded by ε throughout that short interval, the difference between the increment and f(b)h has absolute value at most ε|h|. Continuity at b supplies such a bound for every ε>0 when |h| is small enough, so the difference quotient tends to f(b). This requires the stated continuity condition; it must not be asserted for every arbitrary function. For example, a step from height 1 to height 2 at b=1/2 yields an accumulation function with left slope 1 and right slope 2 at that point. A Riemann integral exists, but A′(1/2) does not. This is a derived limitation check, not an example in the original.

## T5. The general Riemann sum and its definition

Source p5, C24–C29. Figure 5 shows a positive curve y=f(x), a finite interval from a to b, and one red rectangle with a dashed vertical sample line c_i inside its base interval. The rectangle top is f(c_i); it crosses rather than uniformly lies below the curve. Thus the word “any” in the source is not restricted to an endpoint or to an inscribed rectangle.

The three bullets and definition reconstruct as

Δx=(b−a)/n,
c_i∈[a+(i−1)Δx,a+iΔx], i=1,…,n,
Q_n=∑_(i=1)^n f(c_i)Δx,
lim_(n→∞) Q_n = ∫_a^b f(x)dx.

The printed “Pick any c_i in the interval” must mean the i-th subinterval. Selecting every c_i arbitrarily anywhere in the whole [a,b] is not the definition. A concrete failure of that mistaken reading is f(x)=x on [0,1]: taking all c_i=1 makes every such sum equal 1, whereas the area is 1/2. The tag's permitted subinterval matters mathematically, not only typographically.

For rigorous meaning, there must be one common finite limit for all valid selections of tags as the equal widths tend to zero. Tags really depend on both i and n, even though the source suppresses n in c_i. A sufficient case is continuous f on the finite closed interval; ordinary bounded piecewise-continuous functions with finitely many jumps are also Riemann integrable. One chosen tag sequence converging is not by itself a complete definition of Riemann integrability. The source states no regularity or common-limit condition; its positive smooth drawings suggest well-behaved functions. The baseline says rectangle sums in the “usual well-behaved cases,” so it does not justify extending this unconditionally to every function.

The integral's symbols have distinct roles: a and b are the fixed bounds; x is a dummy integration variable; f specifies the height/rate; dx accompanies integration in x and is not a finite rectangle width. At finite n use Δx; dx belongs to the limiting notation. Changing the dummy variable to u changes no value. Integrand-times-increment units become the units of the accumulated result. The original introduces equal widths only; it neither develops arbitrary nonuniform partitions nor requires a general mesh theorem. Those should not be silently attributed to it.

## T6. Example 3: one principal and simple interest

Source p5, C30–C34. The declared quantities are P (principal, dollars), t (elapsed time, years), and r (constant interest rate, inverse years), with 6% annually represented as r=0.06/year. The source postulates

amount owed after elapsed time t = P(1+rt)=P+Prt.

Here rt is dimensionless. The formula is a **simple-interest** model: interest accumulates on the original principal, without interest on interest. The constant interest flow is rP dollars/year; multiplying by elapsed time t gives rPt dollars and adding back the principal gives P+rPt=P(1+rt). It is not the repeated-growth formula P(1+r)^n from baseline arithmetic or a continuous-compounding exponential. It assumes the principal remains outstanding for the stated period and excludes repayments, extra fees, changing interest rates, or another interest convention unless a new model is supplied.

The borrowed-flow example then replaces a single principal by many contributions. A function f(t) is a borrowing **rate** in dollars/year, not an outstanding balance and not the dollars borrowed in an entire year. If the rate is constant at $1000/month, it is $12,000/year. A duration of 1/12 year at that rate contributes ($12,000/year)(1/12 year)=$1000. Rate and increment units must match before multiplication.

The source takes Δt=1/12 year and t_i=i/12 year, i=1,…,12, the right endpoints of monthly intervals. The symbol t in the preceding P(1+rt) formula is an elapsed duration for a given principal. In the borrowing function f(t) and the later interest factor, t is the loan's calendar time measured from the start of the year. The remaining interest-bearing duration is therefore T−t, not t, where T=1 year is the common repayment horizon.

## T7. Borrowed amounts, the continuous limit, and dimensions

Source p6, C35–C38. The monthly amount associated with sample i is f(t_i)Δt. It is exact if f(t_i) is defined as that month's constant or average rate; for a general instantaneous rate varying within the month it is an approximation. The source's phrase “borrowing rate during the ith month” does not distinguish these possibilities. Its right-endpoint formula identifies the intended sampled-rate model.

The finite total borrowed is B_12=∑_(i=1)^12 f(t_i)Δt. To take a limit at fixed one-year horizon, the number of periods must increase: use n periods, Δt=T/n, and t_i=iT/n, then let n→∞. Keeping twelve terms while sending Δt→0 would shrink the total covered time to zero and would not produce the source's integral. This implicit refinement is a consequential omitted step in its compact presentation.

For a Riemann-integrable borrowing rate, the limit is

B=∫_0^T f(t)dt, T=1 year.

The original writes limits 0 and 1 because time is numerically measured in years. f has units dollars/year and dt has units years, so B has units **dollars**. The original sentence describes this as total borrowed in one year “in dollars per year.” That is a visible source unit error, not a special convention or extraction artefact. A total and a rate must remain distinct. The average borrowing rate over a horizon T is B/T, which would have dollars/year units; that is not what the displayed integral alone computes.

For a physical borrowing-only model, take f(t)≥0. The mathematical integral also permits signed f, but then it would represent a signed cash-flow total; repayments need their own debt/interest treatment rather than silently reinterpreting every negative amount as an independent reversed loan.

## T8. The end-of-year debt formula

Source p6, C39–C41. The amount borrowed at time t_i is q_i=f(t_i)Δt. Applying the simple-interest rule to this principal for the remaining duration T−t_i gives

debt contribution at T = q_i[1+r(T−t_i)]
                       = f(t_i)[1+r(T−t_i)]Δt.

Add the contributions and refine the partition:

D(T)=∫_0^T f(t)[1+r(T−t)]dt.

The source's displayed end-of-year version is D(1)=∫_0^1 f(t)[1+r(1−t)]dt. The numeral 1 means the end time 1 year when units are restored. Each multiplier is dimensionless; the result is dollars. This formula is a weighted accumulation: borrowing earlier receives a larger remaining-time multiplier. It assumes one fixed repayment horizon, constant simple-interest rate, independent addition of debts, no initial debt before t=0, no intervening payments, and no compounding. A different loan convention requires a different weight, not a change to the same formula justified solely by familiarity with exponentials.

Expanding the supplied weight with ordinary integral linearity gives

D(T)=B+r∫_0^T (T−t)f(t)dt.

The first term is total principal; the second is total interest. For f≥0 and r≥0,

B ≤ D(T) ≤ (1+rT)B,

because the time weights lie between 1 and 1+rT. For positive B define the amount-weighted mean borrowing time t_bar=(∫tf(t)dt)/B; then D=B[1+r(T−t_bar)]. This consequence is an independent interpretation/check, not a formula stated by the original. It is analogous to the weighted means supplied in the baseline, but no probabilistic or financial theorem is needed.

Boundary checks: a contribution made at t=T bears zero elapsed-time interest; a contribution at t=0 bears a full year's interest; r=0 gives D=B; f=0 gives B=D=0. Point contributions are illustrated as finite loans for these checks, not represented by an ordinary rate function concentrated at one point. No delta-function formalism is assumed.

## T9. Independent borrowing calculations and timing sensitivity

For the original constant-rate illustration f=$12,000/year and the original rate example r=0.06/year over T=1 year:

B=$12,000,
D=$12,000 ∫_0^1 [1+0.06(1−t)]dt = $12,360.

This evaluated total is independently derived here; the original does not evaluate a numerical debt.

If instead exactly $1000 is borrowed at each month end t_i=i/12, its finite simple-interest total is

D_12 = 1000∑_(i=1)^12[1+0.06(1−i/12)]
     = 12000 + 60(12−78/12)
     = $12,330.

The $30 difference is real model timing: twelve month-end loans differ from continuously borrowing at the same annual rate. Month-start loans yield $12,390. Midmonth loans yield $12,360 because the weight is linear in t. They must not all be labelled the same finite process merely because their total principal agrees.

For n equal end-of-period loans from a constant annual flow K, direct arithmetic gives

D_n = K[1+r(n−1)/(2n)] → K(1+r/2),
D_n−D = −Kr/(2n),

when time is expressed numerically in years with horizon 1. At K=12000, r=0.06, the error is −360/n dollars. This independently checks both the continuous limit and the direction of the finite timing error.

Two other permitted polynomial rates isolate timing while holding principal fixed. With t numerical in years, f_late(t)=24000t and f_early(t)=24000(1−t), both integrate to $12,000. The respective total interest values are $240 and $480, giving debts $12,240 and $12,480. The earlier flow costs more under the stated simple-interest rule. These are check cases, not new original examples.

An independent unit-change check sets m=12t months. The rate becomes $1000/month, the monthly simple-interest rate 0.005/month, and horizon 12 months. Then ∫_0^12 1000[1+0.005(12−m)]dm=$12,360, unchanged. Using 0.06/month or mixing dollars/month with year increments would change the model and fail dimensional consistency.

## T10. Baseline bridges, novelty, and limits

The complete baseline already supplies rectangle-limit integration, standard power antiderivatives, signed-area rules, the fundamental theorem in suitably continuous cases, power differentiation, finite summation notation, arithmetic progressions, exact sums of squares, induction, average values, and graphical/physical rate-area interpretation. Those are usable premises rather than novel concepts that can be withheld merely because the source is a university lecture. The source adds this particular geometric arrangement, its pyramid bounds, its compact tagged-sum presentation, and its simple-interest borrowing model and weighted debt integral.

Consequential bridges must still be made explicit: how i selects a particular subinterval; why Δx times height is one contribution; why the factor in Example 1 is b³/n³; how unit-thickness layers produce square volumes; why the geometric bounds trap a limit; how b changes from fixed endpoint to differentiation variable; how the twelve-period borrowing model becomes n periods at fixed horizon; why a loan at time t accrues for 1−t; and why an integral of dollars/year with respect to years is dollars. Familiar topic names do not fill these steps automatically.

Relevant Physics and Chemistry premises reinforce the same logic: graph-area units multiply axis units (B18); current is charge per time and constant current gives Q=It (B19); chemical species rates are concentration changes per time with explicit signs (B20); chromatographic integrated peak area differs from peak height (B21). No electrical, chemical, quantum, statistical, or other advanced premise is needed to derive the lecture's mathematics. The remaining baseline content was read and mapped, not silently used as a source of extra finance or integration theory.

No general theorem for non-Riemann-integrable functions, measure theory, stochastic borrowing, general variable interest, discrete-compounding finance, improper integrals, or multivariable integration is required by this original. The baseline may contain some additional methods, but their availability does not mean the original taught them. Any future assessment or teaching scope extending into them needs a separately declared purpose and its actual premises.

## Source defects and unresolved assumptions registry

| ID | Location | Finding | Required mathematical treatment |
|---|---|---|---|
| A01 | p2 Example 1 | b called arbitrary while positive-width area picture is used | State b>0 for the pictured construction; handle zero/negative bounds separately. |
| A02 | p3 layers | Unit layer height implicit | State thickness 1 when converting square areas to volumes. |
| A03 | p3 comparison prose | “Inner/outer prism” conflicts with factor 1/3 and image | Identify the bounding solids as square pyramids; do not alter source evidence. |
| A04 | p4 limit | Squeeze reasoning compressed | Give vanishing bound gap or an equivalent valid deduction. |
| A05 | p4 derivative pattern | “Should satisfy” is not a general theorem proof | State fixed lower bound and continuity at the upper evaluation point for the derivative claim. |
| A06 | p5 sample choice | “The interval” does not explicitly index each subinterval | Restrict c_i to the i-th base interval. |
| A07 | p5 definition | Existence and tag independence unspoken | Require a common finite limit for the chosen integrable class; continuity is a sufficient case. |
| A08 | p5 area prose | No nonnegativity condition stated | Distinguish signed integral from geometric area. |
| A09 | p5 interest rule | Interest convention not named | Recognise simple interest, constant r, and no interest on interest. |
| A10 | p5–p6 sampled rate | Exact interval-average/constant rate versus instantaneous sample unclear | Distinguish exact finite amounts from numerical approximation. |
| A11 | p6 Δt→0 | Fixed twelve-term example becomes a continuum without showing n | Use n→∞ with nΔt=T fixed. |
| A12 | p6 units sentence | Total borrowed labelled dollars/year | Correct result units to dollars; dollars/year is the borrowing rate or horizon average. |
| A13 | p6 remaining duration | Numerical 1 carries the implicit year horizon | Use T−t with compatible time units and T=1 year. |
| A14 | p6 loan timing | End-month finite sampling can be mistaken for continuous borrowing | Preserve the timing distinction and associated finite error. |
| A15 | whole lecture | Averages are mentioned but not developed | Record the claim; attribute any average-value formula to the actual baseline or a new deduction. |

## Verification status

`calculation-checks.py` and `calculation-results.json` contain exact-rational, symbolic, dimensional, and model-sensitivity checks. They are independent of any generated teaching or prospective assessment. Analytic identities and conditions are explained above; finite computational samples are not represented as proofs of universal statements. The source coverage matrix includes all original mathematical examples, every figure, substantive statements, definition, and administrative cover/header content. No reading output was clipped; all sixteen baseline chunk boundaries are contiguous and cover [0,247840). Broken extraction glyphs and lost figure information were recovered by original-resolution image inspection, as recorded separately.

The dossier is sealed as preparation. It makes no claim that teaching, a student attempt, assessment validation, or acceptance has occurred. Any later role uses the exact then-current complete PROF package and a fresh prompt-only packet supplied by the root; neither is part of this preparation input set.
