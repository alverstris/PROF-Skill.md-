from pathlib import Path
import json,hashlib
R=Path('/workspace/scratch/f9c0b7fc7e76');O=R/'d106-fresh-independent-technical';S=R/'original-inputs/D106'
notes={
'reading-chapter1fields': {14:'Boundary: only heading 1.6 downward. Definition E=lim F/q and Coulomb source-field equation. Earlier gravitational discussion/figure excluded.',15:'Only continuation of 1.6, Figure 1.6.1/caption: outward positive and inward negative radial arrows. Stop before heading 1.7; magnetic material excluded.'},
'reading-chap2coulomb_law': dict(enumerate([
'Contents: sections 2.1–2.13.6; required full chapter, not only slide overlap.',
'Contents: conceptual questions and all eight additional problems.',
'Charge sign, quantization, conservation; Coulomb vector direction. Figure 2.2.1 shows repulsion ++ and attraction +−, rhat source1 to target2.',
'Coulomb constant, permittivity, third law, hydrogen force comparison. Figure 2.2.2 same/opposite sign field textures and fixed generator; static frames only.',
'Animation artificial bounce and field-stress qualitative account; superposition; Example 2.1 numerical givens.',
'Example 2.1 diagram: q1 at origin, q2 at (0,a), q3 at (a,a); component construction and displacement unit vectors.',
'Example 2.1 printed 3.0 N is arithmetically inconsistent (correct approximately 3.0e2 N). Quadrant II direction; exclude self-term; test-charge limiting definition.',
'Figure 2.4.1 rhat is opposite inward field for negative source; point-field and vector superposition. Figure 2.4.2 slow-motion/static animation frames.',
'Positive outward/negative inward/dipole field lines; symmetry, near/far and null-point heuristics. Far-field outward wording needs negative-total-charge qualification.',
'Field-line tangent/density/endpoint/nonintersection rules; Figure 2.6.1 positive test charge falls from positive upper plate in downward E; exclude self-field.',
'Constant acceleration/speed/kinetic-energy result; dipole ±q at y=±a, θ measured from +y to observation ray, θ± from horizontal; neutral-system dipole sum.',
'Exact finite dipole components and far-field/3D vector formula; dipole moment from − to +; polar-molecule examples.',
'Finite-versus-point dipole field-line figures and static interactive frame; uniform external field setup with θ now measured from +x.',
'Uniform dipole figure and torque derivation: both endpoint moments into page, τ=p×E; work sign for increasing θ.',
'Dipole work and U=−p·E with reference at π/2; stable parallel/unstable antiparallel; aligned nonuniform-field figure and first-order expansion.',
'One-dimensional small-dipole force p dE/dx; polarized paper and comb; charge-element source-to-observer geometry and volume density.',
'Volume/surface/line density definitions, units and integrals; continuum coarse-grained interpretation and signed densities.',
'Vector-integral setup; Example 2.2 rod lies x′ from x0 to x0+ell, P at origin, positive-charge field left.',
'Example 2.2 result/point limit; Example 2.3 centered rod and P above origin, θ from downward perpendicular.',
'Example 2.3 paired cancellation, component integral/trig substitution. Printed first intermediate denominator sec²+1 is wrong; use tan²+1.',
'Finite rod limits and odd signed plot with divergence at ideal line; Example 2.4 ring xy plane, P on z axis.',
'Ring opposing elements cancel transverse components; axial formula and odd plot with zero center and peaks near ±0.707R.',
'Ring center zero; Example 2.5 disk as rings, annular area 2πr′dr′, signed z/|z| from square root.',
'Disk two-sided field and odd discontinuous plot; far point and near-plane limits; caption says plane while curve is finite disk.',
'Infinite-plane step graph and normal jump σ/eps0; Coulomb/field summary.',
'Summary of point charges, acceleration, dipole torque/energy and continuum field; qualify finite-net-neutral far-field summary.',
'Integration strategy and coordinate differential-element table; table gives coordinate-edge lengths/surface patches, not arbitrary path formula; new coordinate meanings needed.',
'Comparative rod/ring/disk table. Intro says infinite line but table integrates finite rod; primes inconsistent in rod integral. Symmetry cancels summed components, not each element.',
'Solved 2.13.1 hydrogen parts a–d: field numeric uses 0.50e−10 instead of stated 0.53e−10; compute consistent result.',
'Hydrogen ratio/planet neutrality explanation; solved 2.13.2 oil-drop givens, downward E and mass from sphere.',
'Oil drop negative charge and five excess electrons; source loses signed q/e and overstates static condition. Electron deflection diagram: y2 denotes additional drift displacement.',
'Solved 2.13.3 seven subquestions, electron upward electric force and acceleration in downward field.',
'Electron exit time/velocity/displacement/angle and screen displacement; solved 2.13.4 dipole task begins.',
'Dipole far-field Cartesian/polar task, exact components and expansion premise; angular convention from +y.',
'Binomial −3/2 expansion and Cartesian result. Keep radial scaling distinct from explicit r−5 denominators with xy numerators.',
'Polar unit vectors/field/magnitude; solved 2.13.5 arc with uniform λ and signed angle from +x.',
'Arc figure right-side sector ±θ0, field left and ring/small-arc checks; solved 2.13.6 finite rod x1..x2 to right of P foot.',
'Off-axis rod figure, source element, negative Ex and endpoint cosine difference; no assumed symmetric cancellation.',
'Off-axis Ey and infinite-line limit; conceptual Q1 gravitation/Coulomb, Q2 lines, Q3 −q left/+3q right, Q4 begins.',
'Conceptual Q4 rod/test charge and Q5 pivoted dipole; additional 2.15.1 equilateral triangle .600 m (3,−6,9 µC), additional 2.15.2 begins.',
'Additional 2.15.2 isosceles geometry (2q origin,+q y-axis,−q x-axis), P hypotenuse midpoint; 2.15.3 square (4q bottom-left,2q bottom-right,3q top-left,q top-right); 2.15.4 upper semicircle θ from +y.',
'Semicircle λ0 cosθ parts; dipole small-oscillation task; cylindrical side shell figure bottom z′=0, top h, P above top at z.',
'Solid cylinder continuation; conducting balls common suspension point and separation r, but numerical task suddenly calls it x (ambiguous); dipole +2e above −2e, separation d.',
'External field (3i+3j) N/C; dipole moment, torque and internal-force questions.'
],1)),
'presentation-presentati_w01d2':dict(enumerate([
'Full outline: field review/charge/dipoles and continuous distributions.',
'Review title.',
'Gravity/electric field force analogies; distinguish source and test charge despite reused q.',
'Field-line PRS transition.',
'Field-line definition and equal/opposite-sign patterns; direction is tangent, not trajectory.',
'In-class unlike-charge pair: −q left,+q right,separation d,P above midpoint at s; solve horizontal negative field.',
'Two point-charge PRS transition.',
'Creating charge title.',
'Friction/contact/induction drawings; induction image demonstrates charge separation, not net charging alone.',
'Charging demonstration title; no dynamic experiment is supplied.',
'Dipole title.',
'±q separated by 2a; p points from − to +.',
'Static molecular/dipole animation frame.',
'Dipoles make fields title.',
'Exact finite dipole geometry with p along +y, observer (x,y), θ measured from +y.',
'Dipole falloff PRS transition.',
'Far-field components and finite/point-dipole field lines; r much greater than a.',
'Static 3D dipole field animation frame.',
'Dipoles feel fields title.',
'Dipole demonstration title; no unseen motion claimed.',
'Uniform horizontal field/tilted dipole: zero net electric force and clockwise torque p×E.',
'Field-stress picture for uniform-field torque, qualitative only.',
'Nonuniform-field dipole PRS transition.',
'Continuous charge distribution title.',
'Discrete sum to differential charge/vector integral.',
'Uniform volume/surface/line density examples and dq elements.',
'Continuous line discretization/static field depiction.',
'Line-field static depiction continuation.',
'Ring discretization/static field depiction.',
'Ring static field depiction continuation.',
'Ring-axis question; ring radius a and observation x.',
'Ring transverse cancellation by opposing elements.',
'Project element field onto axis before integration.',
'Ring angular integral; axis distance independent of source angle.',
'Ring result/point limit at fixed Q; source uses positive x.',
'Finite line question centered on x axis, observation above at s.',
'Finite line primed source coordinate and displacement diagram.',
'Finite line result and far point/near infinite-line limits.',
'Uniform disk axis setup.',
'Disk result and large-distance/small-distance limits at fixed charge or fixed density as appropriate.',
'Falloff comparison dipole/point/line/plane, with geometry/domain qualifications.'
],1)),
'prs-prs_w01d2':dict(enumerate([
'Q field lines option4: direction of electric force on positive test charge static or moving, not generic velocity.',
'Answer4 and field-line explanation; blanket particles do not move along field lines is too absolute.',
'Q field texture with like-sign sources/sinks and null region: interaction repulsive.',
'Answer2 repulsive, qualitative tension picture; sign cannot be selected without arrows.',
'Q equal +q pair separation d, P(0,s), vertical symmetry.',
'Answer1: E=2kqs/(s²+d²/4)^(3/2) j.',
'Q regular hexagon side R, remove bottom +q, ask center field.',
'Answer4: downward magnitude kq/R²; faint removed bottom charge must be excluded.',
'Q dipole large-distance falloff relative to 1/r².',
'Answer2: faster, leading 1/r³ for a nonzero dipole moment.',
'Q pivoted horizontal dipole in northeast field weakening rightward: labels left q1/right−q1 control sign, not colors.',
'Answer3: nonzero net electric force and torque for drawn configuration; pivot reaction can prevent translation.'
],1))}
identity=json.loads((S/'source-identity.json').read_text());acc=[json.loads(x) for x in (O/'access.jsonl').read_text().splitlines()];coverage=[];inputs=[]
for a in identity['assets']:
 folder=str(Path(a['local_pdf']).parent)
 req=a.get('required_pdf_pages') or list(range(1,a['page_count']+1))
 for page in req:
  p=next(v for v in a['page_derivatives'] if v['page']==page)
  row={'asset':folder,'pdf_page':page,'assigned_scope':a.get('assigned_portion','full asset'),'observed':notes[folder][page]}
  for kind in ['text','image']:
   rel='original-inputs/D106/'+p[kind+'_file'];b=(R/rel).read_bytes();h=hashlib.sha256(b).hexdigest();assert h==p[kind+'_sha256'];ids=[x['sequence'] for x in acc if x.get('path')==rel and ('read' in x.get('operation','') if kind=='text' else 'view_image' in x.get('operation',''))]
   row[kind]={'path':rel,'bytes':len(b),'sha256':h,'actual_access_records':ids,'inspection_complete':True}
  row['image']['dimensions']=p['image_dimensions'];row['image']['detail']='original';coverage.append(row)
 # PDF fingerprint, not substitute for actual derivative reading
 b=(S/a['local_pdf']).read_bytes();assert hashlib.sha256(b).hexdigest()==a['sha256'];assert len(b)==a['bytes']
assert len(coverage)==99
(O/'coverage.json').write_text(json.dumps({'scope':'Source-only independent technical preparation; no current teaching or acceptance inspected.','required_pages':99,'full_page_text_inspected':99,'full_page_png_original_resolution_inspected':99,'boundary_pages':[{'asset':'chapter1fields','pages':[14,15],'start':'Heading 1.6, lower p14','end':'Before heading 1.7 p15; Figure 1.6.1 and caption included'}],'context_recovery':'Access records 135–150 were not delivered visibly because of context clipping; later repeated access records recover every affected page. They are not counted twice.','pages':coverage},indent=2)+'\n')
for p in sorted(S.rglob('*')):
 if p.is_file():
  b=p.read_bytes();inputs.append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'use':'identity/assigned source content' if str(p.relative_to(R))=='original-inputs/D106/source-identity.json' or any(str(p.relative_to(R)) in [x['text']['path'],x['image']['path']] for x in coverage) else 'fingerprint only; unassigned chapter1 content not used' if p.suffix in ['.txt','.png'] else 'original PDF identity fingerprint; supplied derivatives inspected'})
bp=R/'d013-clean-r32-20261012/inputs/student-baseline.txt';b=bp.read_bytes();assert len(b)==247840 and hashlib.sha256(b).hexdigest()=='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5';inputs.append({'path':str(bp.relative_to(R)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'use':'whole four-subject prerequisite baseline;13 consecutive bounded byte chunks'})
(O/'input-manifest.json').write_text(json.dumps({'packet':'D106','original_files_unchanged':True,'inputs':inputs},indent=2)+'\n')
# Supplemental tool accesses after full baseline reading. Record exact source access purpose and bounds.
new=[{'operation':'identity metadata and required derivative verification','path':'original-inputs/D106/source-identity.json','note':'Read metadata to resolve required pages/hash records; did not follow cache_source or identity_basis.'},{'operation':'baseline supplemental byte-heading searches','path':str(bp.relative_to(R)),'note':'Three Python scans returned short heading or term anchors only, after complete original baseline read.'}]
for lo,hi in [(59400,60800),(133700,138500),(164500,167750),(104600,108300),(12900,15300),(88200,90025)]:new.append({'operation':'baseline supplemental bounded byte read','path':str(bp.relative_to(R)),'byte_start':lo,'byte_end_exclusive':hi,'slice_sha256':hashlib.sha256(b[lo:hi]).hexdigest(),'output_clipped':False})
new.append({'operation':'source fingerprint audit','paths':'input-manifest.json entries','note':'Hashed original packet bytes only. No unassigned derivative semantic reading. All four original PDF hashes and all 198 required derivative hashes match identity.'})
with (O/'access.jsonl').open('a') as f:
 for x in new:x['sequence']=len(acc)+1;acc.append(x);f.write(json.dumps(x)+'\n')
print(json.dumps({'coverage_pages':len(coverage),'input_fingerprints':len(inputs),'access_records':len(acc)}))
