"""Independent local numerical checks of source-derived formulas; no network or hidden solutions."""
import math,json
from pathlib import Path
O=Path(__file__).resolve().parent
k=9.0e9;eps=1/(4*math.pi*k);checks=[]
def report(name,data,ok=True):
 assert ok,name
 checks.append({'id':name,'pass':bool(ok),'results':data})
def near(a,b,tol=1e-9):return abs(a-b)<=tol*max(1,abs(a),abs(b))
def vecnear(a,b,tol=1e-9):return all(near(x,y,tol) for x,y in zip(a,b))
def norm(v):return math.sqrt(sum(x*x for x in v))
def add(*vs):return [sum(x) for x in zip(*vs)]
def scale(c,v):return [c*x for x in v]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def field(P,charges,K=1):
 out=[0.0]*len(P)
 for q,s in charges:
  d=[x-y for x,y in zip(P,s)];out=add(out,scale(K*q/norm(d)**3,d))
 return out
# Composite Simpson, numerically independent of endpoint antiderivative formulas.
def quad(f,a,b,n=4000):
 h=(b-a)/n;return h/3*(f(a)+f(b)+sum((4 if j%2 else 2)*f(a+j*h) for j in range(1,n)))
def quadvec(f,a,b,n=4000):return [quad(lambda t,j=j:f(t)[j],a,b,n) for j in range(len(f((a+b)/2)))]
# Example 2.1
q1,q2,q3,a=6e-6,-6e-6,3e-6,.02
F=scale(q3,field([a,a],[(q1,[0,0]),(q2,[0,a])],k));expected=scale(k*q1*q3/a**2,[math.sqrt(2)/4-1,math.sqrt(2)/4]);mag=norm(F);angle=math.degrees(math.atan2(F[1],F[0]))
report('CH2-example-2.1',{'force_N':F,'magnitude_N':mag,'angle_deg':angle,'source_printed_N':3.0,'printed_value_is_inconsistent':abs(mag-3)>290},vecnear(F,expected) and 298<mag<300 and 151<angle<152)
# Hydrogen and oil drop
r=5.3e-11;e=1.6e-19;G=6.67e-11;me=9.1e-31;mp=1.7e-27
Fe=k*e*e/r**2;E=k*e/r**2;Fg=G*me*mp/r**2;ratio=Fe/Fg
report('CH2-2.13.1',{'electric_force_N':Fe,'field_N_per_C':E,'gravitational_force_N':Fg,'ratio':ratio,'source_field_5_76e11_uses_other_radius':k*e/(5e-11)**2},abs(Fe/(e*E)-1)<1e-12 and near(ratio,k*e*e/(G*me*mp)))
m=851*4*math.pi*(1.64e-6)**3/3;g=9.8;charge=-m*g/1.92e5
report('CH2-2.13.2',{'mass_kg':m,'charge_C':charge,'signed_charge_in_e':charge/e,'excess_electron_count_rounded':round(-charge/e)},abs(charge/e+5)<.02 and abs((-m*g-charge*1.92e5)/(m*g))<1e-12)
# Pair and hexagon problems normalized k,q
s,d=1.7,.8;den=(s*s+d*d/4)**1.5
unlike=field([0,s],[(-1,[-d/2,0]),(1,[d/2,0])]);like=field([0,s],[(1,[-d/2,0]),(1,[d/2,0])])
report('presentation-6-unlike-pair',{'field_normalized':unlike},vecnear(unlike,[-d/den,0]))
report('PRS-p5-p6-like-pair',{'field_normalized':like},vecnear(like,[0,2*s/den]))
vertices=[[math.cos(-math.pi/2+j*math.pi/3),math.sin(-math.pi/2+j*math.pi/3)] for j in range(6)]
Ehex=field([0,0],[(1,v) for v in vertices[1:]])
report('PRS-p7-p8-hexagon',{'field_in_kq_per_R2':Ehex},vecnear(Ehex,[0,-1]))
# Uniform dipole endpoint torque independent of net torque formula.
theta=.63;a=.4;q=.7;Eext=[2.1,0,0];rp=[a*math.cos(theta),a*math.sin(theta),0];rm=scale(-1,rp);Fp=scale(q,Eext);Fm=scale(-1,Fp);p=scale(2*q,rp)
tau=add(cross(rp,Fp),cross(rm,Fm));tau2=cross(p,Eext)
report('dipole-uniform-torque-energy',{'force':add(Fp,Fm),'endpoint_torque':tau,'cross_product_torque':tau2,'potential_energy':-sum(x*y for x,y in zip(p,Eext))},vecnear(tau,tau2) and vecnear(add(Fp,Fm),[0,0,0]) and tau[2]<0)
x=.3;a=.01;q=.9
Ef=lambda x:2+3*x+4*x*x
finite=q*(Ef(x+a)-Ef(x-a));gradient=2*q*a*(3+8*x)
report('dipole-one-dimensional-gradient',{'finite_pair_force':finite,'p_times_derivative':gradient},near(finite,gradient))
# All finite rod formulas from quadrature.
lambda_=1.3;x0=.7;ell=2.6
axial=quad(lambda xp:-lambda_/xp**2,x0,x0+ell);closed=-lambda_*ell/(x0*(x0+ell))
report('CH2-example-2.2-axis-rod',{'quadrature':axial,'formula':closed},near(axial,closed))
y=.83
rod=quadvec(lambda xp:[-lambda_*xp/(xp*xp+y*y)**1.5,lambda_*y/(xp*xp+y*y)**1.5],-ell/2,ell/2)
report('CH2-example-2.3-bisector',{'quadrature':rod,'formula':[0,lambda_*ell/(y*math.sqrt(y*y+ell*ell/4))]},vecnear(rod,[0,lambda_*ell/(y*math.sqrt(y*y+ell*ell/4))]))
x1,x2=.27,2.13;r1=math.hypot(x1,y);r2=math.hypot(x2,y)
off=quadvec(lambda xp:[-lambda_*xp/(xp*xp+y*y)**1.5,lambda_*y/(xp*xp+y*y)**1.5],x1,x2)
offformula=[lambda_*(1/r2-1/r1),lambda_/y*(x2/r2-x1/r1)]
report('CH2-2.13.6-off-axis-rod',{'quadrature':off,'formula':offformula},vecnear(off,offformula))
# Ring and disk
R=1.2;z=.81;lam=.9;Q=2*math.pi*R*lam
ring=quadvec(lambda phi:scale(lam*R/(R*R+z*z)**1.5,[-R*math.cos(phi),-R*math.sin(phi),z]),0,2*math.pi)
ringformula=[0,0,Q*z/(R*R+z*z)**1.5]
report('CH2-example-2.4-ring',{'quadrature':ring,'formula':ringformula,'peak_z_over_R':1/math.sqrt(2),'normalized_peak':2/(3*math.sqrt(3))},vecnear(ring,ringformula))
sigma=.7
for z in [.81,-.81]:
 disk=quad(lambda u:2*math.pi*sigma*u*z/(u*u+z*z)**1.5,0,R)
 closed=2*math.pi*sigma*(math.copysign(1,z)-z/math.sqrt(z*z+R*R))
 report('CH2-example-2.5-disk-'+str(z),{'quadrature':disk,'formula':closed},near(disk,closed))
# Dipole expansion: next finite-size correction is relative O((a/r)^2).
P=[.6,.8,0];pvec=[0,1,0];r=norm(P);far=add(scale(-1/r**3,pvec),scale(3*sum(x*y for x,y in zip(pvec,P))/r**5,P));errors=[]
for a in [.1,.05,.025]:
 exact=field(P,[(1/(2*a),[0,a,0]),(-1/(2*a),[0,-a,0])]);err=norm(add(exact,scale(-1,far)))/norm(far);errors.append(err)
report('CH2-2.13.4-dipole-asymptotics',{'relative_errors_for_a_over_r_0_1_0_05_0_025':errors,'successive_error_ratios':[errors[0]/errors[1],errors[1]/errors[2]]},all(3.8<errors[i]/errors[i+1]<4.2 for i in [0,1]))
th=math.atan2(P[0],P[1]);rhat=[math.sin(th),math.cos(th),0];that=[math.cos(th),-math.sin(th),0];polar=add(scale(2*math.cos(th),rhat),scale(math.sin(th),that))
report('dipole-polar-convention',{'cartesian':far,'polar_converted':polar,'norm':norm(far)},vecnear(far,polar) and near(norm(far),math.sqrt(1+3*math.cos(th)**2)))
# Electron trajectory: independent integration of acceleration weighted by remaining flight time.
acc=2.3;L1=.6;L2=1.1;v0=1.7;t1=L1/v0;T=(L1+L2)/v0
Y=quad(lambda t:acc*(T-t),0,t1);formula=acc*L1/v0**2*(L1/2+L2)
report('CH2-2.13.3-piecewise-motion',{'total_time':T,'exit_velocity':[v0,acc*t1],'exit_y':acc*t1*t1/2,'screen_y_integral':Y,'screen_y_formula':formula},near(Y,formula))
# Arc
th0=1.17;lam=.8;R=1.6
arc=quadvec(lambda t:[-lam/R*math.cos(t),-lam/R*math.sin(t)],-th0,th0);closed=[-2*lam*math.sin(th0)/R,0]
report('CH2-2.13.5-uniform-arc',{'quadrature':arc,'formula':closed},vecnear(arc,closed))
# Conceptual null point
D=2.1;u=D/(math.sqrt(3)-1);Enull=field([-u,0],[(-1,[0,0]),(3,[D,0])])
report('CH2-conceptual-3-null',{'distance_left_of_negative_charge':u,'field':Enull},vecnear(Enull,[0,0]))
# Additional 1,2,3
side=.6;A=[0,0];B=[side,0];C=[side/2,math.sqrt(3)*side/2];charges=[(3e-6,A),(-6e-6,B),(9e-6,C)];forces=[]
for idx,(q,P) in enumerate(charges):forces.append(scale(q,field(P,[v for j,v in enumerate(charges) if j!=idx],k)))
report('CH2-2.15.1-equilateral',{'force_on_9uC_N':forces[2],'force_on_minus6uC_N':forces[1],'magnitudes_N':[norm(forces[2]),norm(forces[1])],'angles_deg':[math.degrees(math.atan2(v[1],v[0])) for v in [forces[2],forces[1]]],'all_forces_sum_N':add(*forces)},vecnear(add(*forces),[0,0]) and vecnear(forces[2],[1.0125,-.3375*math.sqrt(3)]))
Et=field([.5,.5],[(1,[0,1]),(-1,[1,0]),(2,[0,0])]);report('CH2-2.15.2-triangle',{'field_in_kq_per_a2':Et},vecnear(Et,[4*math.sqrt(2),0]))
Esq=field([1,1],[(3,[0,1]),(4,[0,0]),(2,[1,0])]);Fsq=scale(2,field([1,0],[(1,[1,1]),(3,[0,1]),(4,[0,0])]))
report('CH2-2.15.3-square',{'external_field_at_q_in_kq_per_a2':Esq,'force_on_2q_in_kq2_per_a2':Fsq},vecnear(Esq,[3+math.sqrt(2),2+math.sqrt(2)]) and vecnear(Fsq,[8+3/math.sqrt(2),-2-3/math.sqrt(2)]))
# Nonuniform upper semicircle, angle from +y.
lam0=.9;R=1.3
Q=quad(lambda t:lam0*math.cos(t)*R,-math.pi/2,math.pi/2)
Esemi=quadvec(lambda t:[-lam0/R*math.cos(t)*math.sin(t),-lam0/R*math.cos(t)**2],-math.pi/2,math.pi/2)
report('CH2-2.15.4-nonuniform-semicircle',{'Q':Q,'Q_formula':2*lam0*R,'E':Esemi,'E_formula':[0,-math.pi*Q/(4*R*R)]},near(Q,2*lam0*R) and vecnear(Esemi,[0,-math.pi*Q/(4*R*R)]))
pE=2.6;I=1.7;omega=math.sqrt(pE/I);theta=.02
report('CH2-2.15.5-small-oscillations',{'omega_rad_s':omega,'frequency_Hz':omega/(2*math.pi),'linearization_ratio_sin_theta_over_theta':math.sin(theta)/theta},near(I*omega*omega,pE) and abs(math.sin(theta)/theta-1)<1e-4)
# Cylinder shell and solid; z above top as source figure, plus interior symmetry.
R=.8;h=1.4;Q=2.1;rho=Q/(math.pi*R*R*h)
for z in [2.7,h/2,-.6]:
 shell=quad(lambda zp:Q/h*(z-zp)/(R*R+(z-zp)**2)**1.5,0,h);shformula=Q/h*(1/math.hypot(R,z-h)-1/math.hypot(R,z))
 # Integral split at potential absolute-value kink, where relevant.
 fn=lambda zp:2*math.pi*rho*((1 if z>zp else -1 if z<zp else 0)-(z-zp)/math.hypot(R,z-zp))
 solid=quad(fn,0,h) if not (0<z<h) else quad(lambda t:2*math.pi*rho*(1-(z-t)/math.hypot(R,z-t)),0,z)+quad(lambda t:2*math.pi*rho*(-1-(z-t)/math.hypot(R,z-t)),z,h)
 soformula=2*math.pi*rho*(abs(z)-abs(z-h)+math.hypot(R,z-h)-math.hypot(R,z))
 report('CH2-2.15.6-cylinder-z-'+str(z),{'shell_quad':shell,'shell_formula':shformula,'solid_quad':solid,'solid_formula':soformula},near(shell,shformula) and near(solid,soformula))
# Balls: both interpretations of undefined x, retained explicitly.
l=1.2;m=.01;g=9.8;vals=[]
for r in [.05,.1]:
 theta=math.asin(r/(2*l));qapprox=math.sqrt(m*g*r**3/(2*k*l));qexact=math.sqrt(m*g*math.tan(theta)*r*r/k)
 vals.append({'separation_m':r,'angle_deg':math.degrees(theta),'q_approx_C':qapprox,'q_exact_C':qexact,'relative_error':abs(qapprox/qexact-1)})
report('CH2-2.15.7-balls-ambiguous-x',vals,all(v['relative_error']<.0005 for v in vals))
p=[0,2*e*1e-9,0];tau=cross(p,[3,3,0]);report('CH2-2.15.8-dipole',{'dipole_C_m':p,'torque_N_m':tau,'torque_magnitude_N_m':norm(tau)},abs(tau[2]/(-9.6e-28)-1)<1e-12 and tau[:2]==[0,0])
# Meaningful regime checks, normalized k=1.
R=1;Q=1;z=100
ring=Q*z/(R*R+z*z)**1.5;disk=2*Q/R**2*(1-z/math.hypot(z,R))
report('finite-object-far-field',{'ring_over_point':ring/(Q/z**2),'disk_over_point':disk/(Q/z**2)},abs(ring/(Q/z**2)-1)<.0002 and abs(disk/(Q/z**2)-1)<.0002)
report('all_checks_passed',{'individual_checks_before_summary':len(checks)})
(O/'calculation-results.json').write_text(json.dumps({'method':'Independent direct vector sums, composite Simpson quadrature, component cross-products, limit/error checks and dimensional derivations in dossier; k=9e9 where numerical textbook rounding is compared.','checks':checks,'passed':len(checks),'failed':0},indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'failed':0}))
