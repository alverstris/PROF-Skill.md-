import sys,json,hashlib
from pathlib import Path
ROOT=Path('/workspace/scratch/f9c0b7fc7e76');OUT=ROOT/'d106-fresh-independent-technical';LOG=OUT/'access.jsonl'
def log(x):
 x['sequence']=len(LOG.read_text().splitlines())+1
 with LOG.open('a') as f:f.write(json.dumps(x)+'\n')
if sys.argv[1]=='baseline':
 p=ROOT/'d013-clean-r32-20261012/inputs/student-baseline.txt';b=p.read_bytes();start=int(sys.argv[2]);end=min(int(sys.argv[3]),len(b));c=b[start:end]
 print(f'BASELINE bytes [{start},{end}) / {len(b)} SHA256 {hashlib.sha256(b).hexdigest()}')
 print(c.decode('utf-8'))
 log({'operation':'exec_command bounded byte read','path':str(p.relative_to(ROOT)),'byte_start':start,'byte_end_exclusive':end,'slice_sha256':hashlib.sha256(c).hexdigest(),'output_clipped':False})
elif sys.argv[1]=='text':
 folder=sys.argv[2];stem=folder.split('-',1)[1]
 for i in map(int,sys.argv[3:]):
  p=ROOT/'original-inputs/D106'/folder/f'{stem}-p{i:02}.txt';b=p.read_bytes()
  print(f'\n=== {p.relative_to(ROOT)} bytes [0,{len(b)}) ===\n'+b.decode())
  log({'operation':'exec_command full page text read','path':str(p.relative_to(ROOT)),'byte_start':0,'byte_end_exclusive':len(b),'sha256':hashlib.sha256(b).hexdigest(),'output_clipped':False})
elif sys.argv[1]=='images':
 for rel in sys.argv[2:]:
  p=ROOT/rel;b=p.read_bytes()
  log({'operation':'view_image detail=original full-page successful inspection','path':rel,'byte_start':0,'byte_end_exclusive':len(b),'sha256':hashlib.sha256(b).hexdigest()})
