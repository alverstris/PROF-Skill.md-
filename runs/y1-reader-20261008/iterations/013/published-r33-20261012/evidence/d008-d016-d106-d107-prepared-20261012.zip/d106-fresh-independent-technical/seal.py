from pathlib import Path
import json,hashlib,datetime
R=Path('/workspace/scratch/f9c0b7fc7e76');O=R/'d106-fresh-independent-technical'
sha=lambda b:hashlib.sha256(b).hexdigest()
# Verify original fingerprints after all analysis; no source mutation is permitted.
inp=json.loads((O/'input-manifest.json').read_text())
for x in inp['inputs']:
 b=(R/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],x['path']
A=[json.loads(s) for s in (O/'access.jsonl').read_text().splitlines()]
A.append({'sequence':len(A)+1,'operation':'final source preservation fingerprint verification','paths':'all252 input-manifest.json entries','note':'All original packet and baseline byte counts/hashes unchanged since fingerprinting. Fingerprint access only, not additional semantic reading.'})
(O/'access.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in A))
# Preserve raw records; normalize retrospectively appended supplemental items to their actual tool order.
order=list(range(1,230))+[231,232,233,234,235,236,237,230,238,239,240]+list(range(241,len(A)+1))
retro=[x['sequence'] for x in A if x.get('operation')=='retrospective page-text access record recovered from actual tool result']
order=[n for n in order if n not in retro]
pos=order.index(184)
order[pos:pos]=retro
assert sorted(order)==list(range(1,len(A)+1))
ledger=[]
for n,r in enumerate(order,1):
 x=dict(A[r-1]);x['actual_event_order']=n;x['raw_record_id']=x.pop('sequence')
 if 135<=r<=150:
  x['model_visible_inspection']=False;x['delivery_note']='Combined result was context-clipped; later repeated reads recover all pages.'
 elif x.get('operation','').startswith('retrospective page-text') or x.get('operation','').startswith('view_image') or x.get('operation') in ['exec_command full page text read','exec_command bounded byte read']:
  x['model_visible_inspection']=True
 ledger.append(x)
(O/'access-ledger.json').write_text(json.dumps({'scope':'Actual reading/access evidence; metadata and hash-only reads separately identified.','raw_append_log':'access.jsonl','supplemental_log_order_note':'Some supplemental metadata/search events and four visibly delivered page-text outputs were recorded retrospectively. actual_event_order restores their observed tool order. The four text outputs were also repeated with fresh logged reads before sealing.','source_identity_first_content_read':True,'baseline_complete_bounded_read_records':list(range(4,17)),'clipped_unseen_records':list(range(135,151)),'clipped_identity_record':2,'clipped_redundant_baseline_search_record':229,'events':ledger},indent=2)+'\n')
c=json.loads((O/'coverage.json').read_text())
for row in c['pages']:
 for kind in ['text','image']:
  p=row[kind]['path'];ids=[x['sequence'] for x in A if x.get('path')==p and (x.get('operation')=='exec_command full page text read' if kind=='text' else x.get('operation','').startswith('view_image'))]
  row[kind]['actual_access_records']=ids;row[kind]['model_visible_access_records']=[n for n in ids if not 135<=n<=150]
  assert row[kind]['model_visible_access_records'],p
c['inspection_count_basis']='99 unique required page texts plus99 unique original-resolution full-page PNGs; clipped attempts excluded and repeats not double-counted.'
(O/'coverage.json').write_text(json.dumps(c,indent=2)+'\n')
s=(O/'technical-dossier.md').read_text().replace('field-line direction represents electric force on a positive test charge, whether initially stationary or moving, within this electrostatic model.','field-line direction represents acceleration due to the electric force on a positive test charge, whether initially stationary or moving, within this electrostatic model.')
(O/'technical-dossier.md').write_text(s)
results=json.loads((O/'calculation-results.json').read_text());assert results['passed']==31 and results['failed']==0
baseline=json.loads((O/'baseline-use-map.json').read_text());assert len(baseline['actual_full_read_chunks'])==13
ass=json.loads((O/'assessment-coverage.json').read_text());assert ass['assessment_sets']==32
manifest={'material_id':'D106','phase':'sealed independent source-only technical preparation','author_or_acceptance_work':False,'current_teaching_or_PROF_or_fresh_prompt_read':False,'allowed_subject_inputs':['original-inputs/D106/**','d013-clean-r32-20261012/inputs/student-baseline.txt'],'forbidden_inputs_accessed':[],'network_or_browser_or_GitHub_used':False,'other_agent_findings_used':False,'delegated':False,'source_identity_sha256':sha((R/'original-inputs/D106/source-identity.json').read_bytes()),'baseline_sha256':baseline['sha256'],'baseline_bytes':247840,'baseline_complete_chunks':13,'required_page_texts':99,'required_original_resolution_page_PNGs':99,'required_derivative_hashes_verified':198,'original_PDF_hashes_verified':4,'input_fingerprints':252,'assessment_sets_independently_solved':32,'substantive_calculation_checks_passed':30,'calculation_summary_records':1,'calculation_checks_failed':0,'baseline_map_rows':15,'actual_access_ledger_events':len(ledger),'originals_preserved':True,'release_restriction':'Do not release semantic dossier to future author before whole-teaching freeze. Root receives readiness/counts/hashes only. Await later exact published PROF and fresh prompt-only packet.','files':[]}
for p in sorted(O.iterdir()):
 if p.is_file() and p.name not in ['manifest.json','SHA256SUMS']:
  b=p.read_bytes();manifest['files'].append({'name':p.name,'bytes':len(b),'sha256':sha(b)})
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files=[p for p in sorted(O.iterdir()) if p.is_file() and p.name!='SHA256SUMS']
(O/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in files))
for p in files:assert sha(p.read_bytes()) in (O/'SHA256SUMS').read_text()
print(json.dumps({'ready':True,'files_including_SHA256SUMS':len(files)+1,'manifest_sha256':sha((O/'manifest.json').read_bytes()),'SHA256SUMS_sha256':sha((O/'SHA256SUMS').read_bytes()),'dossier_sha256':sha((O/'technical-dossier.md').read_bytes()),'page_texts':99,'page_images':99,'baseline_bytes':247840,'baseline_chunks':13,'assessment_sets':32,'substantive_calculation_checks':30,'failed_checks':0,'ledger_events':len(ledger)},indent=2))
