# D106 independent technical source dossier — sealed preparation

This is an independent source-only technical analysis, not university teaching, an author revision, or an acceptance decision. No current teaching, PROF, prompt packet, previous review, source map, agent finding, network source, browser, or GitHub material was consulted. The only subject inputs were the original D106 packet and the specified complete four-subject baseline. Original files were not edited. A future author must not receive this dossier before the whole-teaching freeze.

## Scope and evidence

The source identity was consulted first after a filenames-only inventory. It assigns Chapter 1 section 1.6: the heading on the lower portion of PDF p14 through Figure 1.6.1/caption on p15, stopping before 1.7. All 44 PDF pages of Chapter 2, all 41 presentation pages, and all 12 PRS pages are assigned. This gives 99 required pages. Their complete text derivatives and full-page original-resolution PNGs were actually inspected. Chapter 1 boundary-page surroundings were inspected to establish boundaries, not promoted into assigned content. Page numbers in this dossier are PDF page numbers, not printed folios (Chapter 2 folios are one less).

The four-subject baseline is 247840 bytes, SHA256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`, read in 13 adjacent bounded chunks, covering bytes 0 through 247839. Supplemental exact byte reads and short searches located prerequisites after that complete reading. Curriculum completion is an explicit competence assumption, not evidence of individual mastery.

`coverage.json` contains a row for every required page, figure/notation observations, original dimensions, fingerprints and actual access-record references. `access.jsonl` records actual accesses. One original identity `cat` was clipped and assignment structure was recovered. A later combined Chapter 2 image/text call was not delivered because of context clipping; every affected page was re-read in smaller batches. Its initial records do not count as visible inspection. Seal validation also found absent append-log rows for four earlier visibly delivered page texts (Chapter 2 pp21–24); those accesses were recorded transparently from tool history and all four texts were repeated with fresh logged reads. The normalized ledger preserves actual access order rather than pretending every append occurred immediately. Historical claims in source metadata are not this reader's claims. Metadata cache paths and identity-basis paths were not followed. Animation references were read as supplied static frames and captions; no linked motion or demonstration was observed.

## Conventions and physical model

Use k=1/(4πɛ₀), approximately 8.99×10⁹ N m² C⁻² (9.0×10⁹ for the source's rounded numerical examples). Charge q is signed; the elementary-charge magnitude e is positive. A source at r′ and an observation point r give R=r−r′, R=|R|, R-hat=R/R. Then E(r)=k q R/R³ and the force on a distinct test charge q₀ is q₀E. R-hat never silently becomes the direction of force on a negative test charge. E excludes the test charge's self-field. Superposition sums Cartesian vectors, not scalar magnitudes. For force on charge j, omit i=j. The static Coulomb model assumes prescribed sources and vacuum (or approximately air); source motion/polarization caused by a finite probe changes the problem. The limiting probe definition prevents that disturbance.

Units: q,Q,dq in C; λ in C/m, σ in C/m², ρ in C/m³; E in N/C; force in N; dipole moment p in C m; torque in N m; energy in J. The point formula is singular at a source. Ideal line and sheet limits require attention to their supports and one-sided fields. A charge sign may be factored into a signed density; a quantity called a magnitude must then use absolute values. Coordinate symbols are reused across the sources and must be reset for each geometry.

Both Coulomb and Newtonian gravity are central inverse-square pair laws with superposition; gravity between positive masses is attractive, while electric forces can attract or repel. Comparable geometry does not mean comparable source properties. The field definition is force per positive probe charge, not force per electron. The baseline already supplies elementary field, force, charge, vector and Newtonian mechanics facts; the dossier's extensions below remain consequential new connections.

## Independently derived fields and geometric readings

### Fields, lines, charging and the Chapter 1 boundary

Chapter 1 pp14–15 supplies E=lim(q₀→0)F/q₀ and the point field. Figure 1.6.1 shows positive-source arrows outward and negative-source arrows inward. The gravitational material above 1.6 and magnetic material beginning 1.7 are outside the assignment.

Chapter 2 pp9–10 and presentation p5 use field lines as curves tangent to the local field, with direction of force on a positive test charge. Line density is a chosen graphical encoding proportional to field strength per perpendicular area, not a literal count of physical threads. Lines originate at positive charge or infinity and terminate at negative charge or infinity. They do not cross at regular nonzero-field points; the field has one direction there. At a zero the direction is undefined, so the usual noncrossing explanation requires that qualification. Field curves are not generally trajectories: acceleration follows qE/m, while velocity also depends on initial conditions. A suitably initialized particle can follow a straight field line. Near an isolated point charge its radial field dominates; far from a localized distribution with nonzero net charge the monopole dominates, inward if total charge is negative. A neutral dipole instead has leading 1/r³ field. Diagram symmetries refer to the charge configuration and observation region, not to every arbitrary charge distribution.

Presentation p9 depicts friction, contact and induction. Transferring electrons changes net charge while preserving total charge in the closed system. The induction picture itself shows negative charge near an external positive source and positive charge farther away in an otherwise neutral object. Charge separation alone is polarization; net charging by induction additionally needs a grounding/separation process whose actual sequence is not supplied on that slide. The demonstration title pages provide no additional apparatus or results. The field-stress images convey qualitative force direction; they do not independently establish a quantitative stress-tensor law.

### Two-charge comparisons and finite dipole

Presentation p6: sources −q at (−d/2,0), +q at (+d/2,0), observation (0,s), q>0. Each displacement has length b=√(s²+d²/4). Direct signed vector addition gives

E=−k q d/b³ i.

The vertical components cancel and the horizontal components reinforce toward the negative charge. The separation is d, so inserting an additional factor two is wrong.

PRS pp5–6 instead has two +q sources at the same positions. The horizontal components cancel and

E=2k q s/(s²+d²/4)^(3/2) j.

For s>0 it points up, and d→0 at fixed q gives the field of charge 2q. These are different problems despite nearly identical geometry.

For Chapter 2 pp11–13 and presentation pp12,15–18, the dipole is −q at (0,−a), +q at (0,a), with q>0 and p=2qa j. At P=(x,y,0), define b₊²=x²+(y−a)² and b₋²=x²+(y+a)². Exact components are

Ex=kq x(b₊⁻³−b₋⁻³),
Ey=kq[(y−a)b₊⁻³−(y+a)b₋⁻³].

Here θ is measured from +y toward +x: x=r sinθ, y=r cosθ. The smaller θ₊ and θ₋ in the source drawing are measured relative to horizontal directions; they are not the same θ. In the far region r≫a, factor b±⁻³=r⁻³[1+(a²∓2ay)/r²]⁻³/² and use (1+u)⁻³/²=1−3u/2+15u²/8−…. Retaining the first nonzero pair difference yields

Ex=3kp sinθ cosθ/r³,
Ey=kp(3cos²θ−1)/r³,
E=k[3(p·r)r/r⁵−p/r³].

Although a Cartesian term contains xy/r⁵ or y²/r⁵, x and y scale with r, so it contributes at order 1/r³. For the centered symmetric finite pair the next field term is O(kqa³/r⁵); the relative finite-size error is O(a²/r²). The exact finite source and an ideal point dipole are distinguished: an ideal limiting dipole keeps p fixed while a→0 and q grows, whereas a far-field approximation keeps the actual finite source fixed and increases r.

For solved 2.13.4, r-hat=sinθ i+cosθ j and θ-hat=cosθ i−sinθ j. Dotting the Cartesian result into these orthonormal vectors gives Er=2kp cosθ/r³ and Eθ=kp sinθ/r³. Hence |E|=kp√(1+3cos²θ)/r³. On the equatorial axis E opposes p; on either axial side the vector points along p (the signed radial component differs on the two sides). The neutral-system definition p=Σqᵢrᵢ is independent of origin because a common origin shift contributes a multiple of Σqᵢ=0.

### Dipole forces, torque and energy

In Chapter 2 pp13–16 and presentation p21, E=E i and the dipole angle is now from +x. With endpoint positions ±a(cosθ i+sinθ j), the electric forces ±qE i sum to zero. Each endpoint contributes −aqE sinθ k to torque about the midpoint. Thus τ=p×E=−pE sinθ k. A magnitude-angle cross-product rule is not presumed from the baseline; it follows here by the supplied component cross product or the baseline moment arm. The torque tends to reduce a positive θ. Without dissipation, the body need not settle at alignment.

Taking signed rotation about +k, dW_field=τz dθ=−pE sinθ dθ. Integrating from θ₀ to θ gives W_field=pE(cosθ−cosθ₀). Therefore ΔU=−W_field. With U(π/2)=0, U=−pE cosθ=−p·E. The parallel configuration has minimum energy −pE and is stable; antiparallel has maximum +pE and is unstable. Both have zero instantaneous torque. Moment work in angular displacement is a bridge from baseline force-work/arc length, not an automatically supplied university principle.

The aligned one-dimensional nonuniform example has sources at x±a and external E(x)i. F=q[E(x+a)−E(x−a)]i≈2qa E′(x)i=p E′(x)i if a is small compared with the field-variation scale. This is a one-dimensional formula, not permission to replace an arbitrary vector-field gradient by a scalar derivative. For any finite rigid pair, F=q[E(r₊)−E(r₋)] and τ about its center equals r₊×qE(r₊)+r₋×[−qE(r₋)], with positions relative to that center. Nonuniformity can produce net force; it does not logically guarantee both force and torque for every orientation and field. A center pivot can supply a reaction balancing translation while still allowing rotation. The comb/paper figure illustrates induced polarization, not a quantitative susceptibility law.

### Continuous distributions and coordinate elements

A small charge element contributes dE=k dq R/R³. Add vector components before integrating. Density definitions are signed local ratios dq/dℓ, dq/dA, dq/dV; Q/L,Q/A,Q/V are constants only for uniform distributions. A continuum approximation describes charge averaged over many particles at scales small compared with variation/observation scales. It does not invalidate charge quantization. Distinguish fixed observation coordinates from integration coordinates and from source-to-observer displacement. A symmetry argument pairs equal charge elements: one component cancels after summation, not within each element.

Chapter 2 p27's coordinate table is complete but is not all prior knowledge. Cartesian coordinate-edge lengths are dx,dy,dz, face areas dxdy,dydz,dzdx, and volume dxdydz. Cylindrical (s,φ,z) has edge scales ds,s dφ,dz, face areas ds dz,s dφ dz,s ds dφ, volume s ds dφ dz. Spherical (r,θ,φ), θ from the polar axis, has dr,r dθ,r sinθ dφ, areas r dr dθ,r sinθ dr dφ,r²sinθ dθdφ, and volume r²sinθ dr dθdφ. They follow from radial lengths and circumference/arc-length scale factors. The comma-separated entries are alternatives along coordinate directions/surfaces, not a general path-length identity; do not use the density symbol ρ ambiguously for cylindrical radius. An annulus has dA=2πu du because the full azimuth has already been summed. Componentwise one-variable integrations suffice for all assigned worked geometries; unintroduced abstract surface/volume integration must be explained when the compact general notation is used.

### Rod, ring and disk: examples 2.2–2.5 and slide calculations

Example 2.2, Chapter 2 pp18–19: place P at origin and the rod on x′∈[x₀,x₀+ℓ], x₀>0, uniform λ=Q/ℓ. All displacement directions are −i. Integrating −kλ dx′/x′² gives

E=−kλ[1/x₀−1/(x₀+ℓ)]i=−kQ/[x₀(x₀+ℓ)]i.

For x₀≫ℓ this tends to −kQ/x₀² i. x₀ is the near-end distance, not the center distance. A vanishing-length point limit holds Q fixed.

Example 2.3, Chapter 2 pp19–21; presentation pp36–38: rod x′∈[−ℓ/2,ℓ/2], P=(0,y), y>0. The source displacement is (−x′,y). Odd Ex cancels; Ey=kλy∫dx′/(x′²+y²)³/². The antiderivative is x′/[y²√(x′²+y²)], giving

E=kQ/[y√(y²+ℓ²/4)] j.

This expression also gives the correct signed direction for y<0, away from a positive rod. The ideal rod-support point y=0 is singular. y≫ℓ gives kQ/y² for the positive-side magnitude; ℓ≫|y| gives 2kλ/|y|. A genuinely infinite-line limit holds λ fixed, so Q increases with length. Holding Q fixed instead yields zero as ℓ→∞ at fixed y. The normalized source plot is odd with a vertical singularity, consistent with the formula. In the chapter substitution x′=y tanθ′, the correct denominator is y³(tan²θ′+1)³/² for y>0; one printed intermediate line instead has sec²θ′+1 and must not be copied.

Example 2.4, Chapter 2 pp21–23; presentation pp31–35: a ring radius R in the xy plane, P=(0,0,z), λ=Q/(2πR). dq=λR dφ. Opposite elements have equal distances b=√(R²+z²) and cancel transverse contributions. Thus

E=kQz/(R²+z²)³/² k-hat.

The chapter axis is z; the slide uses x and ring radius a. The formula is odd in the signed axis coordinate and is zero at the center. At fixed Q, |z|≫R gives kQz/|z|³. Differentiation yields maxima/minima at z=±R/√2, with normalized magnitude 2/(3√3), matching the plotted peak below 0.4. A positive charge's dE magnitude times a cosine is only a convenience for the shown positive-axis case; the signed vector formula generalizes safely.

Example 2.5, Chapter 2 pp23–25; presentation pp39–40: disk radius R, constant σ=Q/(πR²), annuli radius u with dq=2πσu du. Integrating ring fields gives, for z≠0,

Ez=2πkσ[sgn(z)−z/√(z²+R²)] = σ/(2ɛ₀)[sgn(z)−z/√(z²+R²)].

The |z| enters from √(z²), and cannot be dropped on the negative side. For z>0 and z≫R, expand (1+R²/z²)⁻¹/² to obtain kQ/z². For |z|≪R, Ez≈σ sgn(z)/(2ɛ₀). An infinite-plane limit fixes σ, not finite Q. The ideal sheet has distinct one-sided fields, not a unique value obtained by setting z=0 in this expression. Their jump is σ/ɛ₀. The chapter's finite-disk graph is odd with a jump; the next infinite-plane graph is a step. A literal line drawn between the one-sided levels is not a continuum of physical values on the sheet. The general normal-field boundary jump is stated in the chapter as a later result, not proved for arbitrary surfaces here.

Slide p41's powers have regimes: finite dipole far-field 1/r³; point monopole 1/r²; infinite line or near the middle of a sufficiently long line 1/r; infinite sheet or close to a broad sheet constant. Finite charged rods/disks with nonzero total charge eventually have monopole far-fields.

## Independent solutions to every assigned assessment set

### Chapter worked Example 2.1

On pp5–7, q₁=+6.0 µC at (0,0), q₂=−6.0 µC at (0,a), q₃=+3.0 µC at (a,a), a=.020 m. F₁₃ has unit direction (i+j)/√2 and separation √2a; F₂₃ points left with separation a. Therefore

F₃=(kq₁q₃/a²)[(√2/4−1)i+(√2/4)j]
≈(−261.81 i+143.19 j) N,
|F₃|≈298.41 N, angle ≈151.32° from +x.

The PNG clearly prints 3.0 N after substituting these givens. That is a factor-100 arithmetic error, not an OCR ambiguity. The algebra and second-quadrant angle are consistent; the magnitude should round to 3.0×10² N. A principal arctangent alone returns the wrong quadrant.

### Unnumbered release between plates, Chapter 2 pp10–11

For +q released from rest over downward distance d in E=−E₀j, E₀>0, a=−qE₀j/m. The final velocity is −√(2qE₀d/m)j; speed is positive √(2qE₀d/m); KE=qE₀d. The printed v_y is used as a speed despite an upward-positive coordinate; preserve signed velocity separately. This assumes only the electric force, an effectively uniform field, classical speed and no collision before the stated endpoint.

### Solved 2.13.1 hydrogen, pp29–30

(a) With r=0.53×10⁻¹⁰ m and e=1.6×10⁻¹⁹ C, Fe=ke²/r²=8.2022×10⁻⁸ N, attractive.
(b) E=ke/r²=5.12638×10¹¹ N/C, outward from the proton. The source prints 5.76×10¹¹ after substituting 0.50×10⁻¹⁰ m instead of the stated radius. Use the consistent radius; also check Fe=eE.
(c) Fe/Fg=ke²/(Gmₚmₑ), independent of r. Using the source's rounded masses 1.7×10⁻²⁷ and 9.1×10⁻³¹ kg gives 2.23288×10³⁹, with Fg≈3.6734×10⁻⁴⁷ N. The introductory p4's more rounded 3.6×10⁻⁴⁷ is compatible.
(d) Macroscopic bodies are approximately charge-neutral; electric contributions cancel extensively, while positive masses accumulate gravitational attraction. This explains gravitational dominance of planetary bulk motion, not a theorem that electrical interactions never influence matter or that gravity is negligible in every electrostatic apparatus. The historical numerical charge-equality claim on p30 is not established independently by this source-only calculation and need not be promoted as a fresh measured fact. The orbit model is explicitly classical; no stable classical-atom claim is inferred.

### Solved 2.13.2 oil drop, pp30–31

(a) M=ρ(4πr³/3)=851×4π(1.64×10⁻⁶)³/3≈1.57235×10⁻¹⁴ kg.
(b) Upward-positive, weight is −Mg j and E=−1.92×10⁵ j N/C. Force balance requires q=−Mg/E₀≈−8.0255×10⁻¹⁹ C (g=9.80). Thus q/e≈−5.016, consistent with five **excess** electrons at the stated precision. The number of excess electrons is −q/e, not the printed signed q/e=+5. An electron has charge −e. The drop has many electrons overall. Buoyancy/drag are neglected in the given two-force model. Zero resultant alone means zero acceleration and does not stop an already falling drop; true static equilibrium additionally requires zero velocity.

### Solved 2.13.3 electron deflection, pp31–33

Assume E=−E₀j inside plates, zero outside (ignore fringing), q=−e, initial velocity v₀i, plate length L₁, drift distance L₂. Classical speeds and sufficient plate clearance are required.
(a) F=+eE₀j.
(b) a=(eE₀/m)j.
(c) Exit time t₁=L₁/v₀; the acceleration is transverse.
(d) v(t₁)=v₀i+[eE₀L₁/(mv₀)]j.
(e) y₁=eE₀L₁²/(2mv₀²).
(f) θ₁=arctan[eE₀L₁/(mv₀²)] above +x.
(g) Total time t₂=(L₁+L₂)/v₀. Additional drift deflection is y_drift=eE₀L₁L₂/(mv₀²). The total screen displacement is y_screen=eE₀L₁(L₁/2+L₂)/(mv₀²). In the figure, y₂ is the additional displacement, not the total from the initial axis. This is a parabola followed by a tangent straight segment and directly disproves identifying field curves with generic particle paths.

### Solved 2.13.4–2.13.6

2.13.4(a,b), pp33–36, is derived fully in the finite/far dipole and polar sections above, including the required components and magnitude.

2.13.5, pp36–37: an arc radius R centered at origin extends θ∈[−θ₀,+θ₀] about +x with uniform λ. dq=λR dθ and the displacement to origin is −R(cosθ i+sinθ j). Hence

E=−(kλ/R)∫[cosθ i+sinθ j]dθ=−2kλ sinθ₀/R i.

The y integral is odd. θ₀=π is a complete ring with zero center field; small θ₀ gives −kQ/R²i with Q=2λRθ₀. If taking a nonzero point-source limit, hold Q fixed; at fixed λ the shrinking arc charge also vanishes.

2.13.6, pp37–39: rod x′∈[x₁,x₂], P=(0,y), y>0, λ constant. Let bᵢ=√(xᵢ²+y²), tanθᵢ=xᵢ/y, θᵢ∈(−π/2,π/2). Direct components give

Ex=kλ(1/b₂−1/b₁)=(kλ/y)(cosθ₂−cosθ₁),
Ey=(kλ/y)(x₂/b₂−x₁/b₁)=(kλ/y)(sinθ₂−sinθ₁).

For the drawn rod to the right, Ex<0 and Ey>0. Sending x₁→−∞,x₂→+∞ at fixed λ gives Ex=0,Ey=2kλ/y. A rod symmetric about the observation foot gives the earlier bisector formula. This endpoint form supports negative x₁ without erasing its signed sine.

### Conceptual questions 2.14, pp39–40

1. Both laws have the central inverse-square/superposition properties described above, but charge has either sign, electric force can repel, and gravity of positive masses attracts. Magnitude formulas use |q₁q₂|; a signed product belongs in a vector law with a stated displacement direction. Their constants have different units.
2. Regular electric field lines cannot cross because the field is single-valued; null points need a separate undefined-direction qualification.
3. With −q at x=0,+3q at x=D>0, fields between them reinforce leftward. Outside the larger charge the weaker source is farther away and cannot cancel it. To the left, put x=−u: q/u²=3q/(D+u)², so u=D/(√3−1). Thus the unique finite zero is x=−D(√3+1)/2. Non-collinear points cannot give opposite collinear displacement vectors, so there is no off-axis zero.
4. The rod's field at P remains unchanged when the nonperturbing probe magnitude/sign changes. Probe force decreases in magnitude proportionally and reverses direction; its own field is excluded.
5. The general finite-pair formulas above determine electric force and center torque. A nonuniform field can give either or both; the wording lacks the field/orientation needed to guarantee both. For example an aligned dipole in a varying collinear field has net force but zero torque. A pivot adds constraint force. This conceptual task is less specified than the particular PRS diagram and should not inherit its guaranteed answer without its picture.

### Additional 2.15.1–2.15.8, pp40–44

1. Equilateral triangle side .600 m: +3 µC at (0,0), −6 µC at (.600,0), +9 µC at (.300,.300√3). Using k=9×10⁹,
(a) F₉=(1.0125 i−0.584567 j) N, magnitude 1.16913 N, 30° below +x.
(b) F₋₆=(−1.125 i+1.169134 j) N, magnitude 1.62250 N, approximately 133.90° from +x. Each pair contribution is attractive or repulsive according to signs, and all three resultant forces sum to zero.

2. The right isosceles triangle has +2q at origin,+q at (0,a),−q at (a,0), and P=(a/2,a/2). Every source distance is a/√2. The ±q pair contributes (2√2 kq/a²)(i−j); +2q contributes (2√2 kq/a²)(i+j). Thus E=(4√2 kq/a²)i. For the shown positive q, magnitude is 4√2 kq/a² directed +x.

3. Choose square origin at lower-left: 4q at (0,0),2q at (a,0),3q at (0,a),q at (a,a).
(a) External field at the q location, excluding its self-field, is (kq/a²)[(3+√2)i+(2+√2)j].
(b) Force on 2q is (kq²/a²)[(8+3/√2)i−(2+3/√2)j]. The diagonal separation is √2a; using a or omitting its unit-vector factor changes the result.

4. The upper semicircle's θ is from +y, with θ∈[−π/2,π/2], source position R(sinθ,cosθ) and λ=λ₀cosθ≥0.
(a) Q=λ₀R∫cosθdθ=2λ₀R, so λ₀=Q/(2R).
(b) Ex=0 by odd symmetry; Ey=−(kλ₀/R)∫cos²θdθ=−kπλ₀/(2R)=−kπQ/(4R²). A test charge q at origin feels F=−kπqQ/(4R²)j. A negative q reverses force. Measuring θ from +x without transforming the density incorrectly gives a sign-changing distribution and zero total charge.

5. Torque about center is τz=−pE sinθ with p=2qa. Rotational equation Iθ̈=τz gives θ̈+(pE/I)sinθ=0. For |θ|≪1 rad around stable parallel equilibrium, θ̈+ω²θ=0, ω=√(pE/I)=√(2qaE/I), f=ω/(2π). Released from θ₀ with zero angular velocity: θ=θ₀cosωt. The baseline does not state I or Iθ̈=τ; that governing bridge must be provided or derived from tangential F=ma and I=Σmᵢrᵢ². SHM mathematics itself is supplied. No damping is assumed.

6. The figure places the cylinder axis along z, bottom at z′=0, top at h, P above it at z>h. The shell is its lateral cylindrical surface, with no charged end caps; otherwise the specification/hint would describe a different source.
(a) Uniform side-shell Q: dq=(Q/h)dz′. Integrating ring fields yields
Ez=(kQ/h)[1/√(R²+(z−h)²)−1/√(R²+z²)].
It is positive above a positive shell. This expression also gives the axial interior/below values, and vanishes at z=h/2.
(b) Uniform solid density ρ: a thickness dz′ disk has σ_eff=ρdz′. For z>h,
Ez=ρ/(2ɛ₀)[h+√(R²+(z−h)²)−√(R²+z²)].
If the same total Q is intended, ρ=Q/(πR²h); if density rather than Q is supplied, retain ρ. A general axial extension is ρ/(2ɛ₀)[|z|−|z−h|+√(R²+(z−h)²)−√(R²+z²)]. Both constructions reduce to the point-charge far field and have zero at the midplane by symmetry. The source caption calls the shell a cylinder; the side-shell wording and ring hint fix the interpretation. Uniform charge is prescribed, not a conducting-equilibrium density inferred from shape.

7. Each tiny ball has weight mg, string tension T, and horizontal electric repulsion kq²/r². Balance gives Tcosθ=mg and Tsinθ=kq²/r². Geometry gives r=2ℓsinθ. With tanθ≈sinθ,
r³=2kq²ℓ/(mg)=q²ℓ/(2πɛ₀mg), matching (a).
(b) ℓ=120 cm=1.2 m and m=10 g=.010 kg. The numerical task gives x=5.0 cm but the diagram/preceding equation define r, not x. It is therefore ambiguous. If x means separation r=.050 m, |q|≈2.38145×10⁻⁸ C (24 nC). If x is each ball's horizontal offset, r=.100 m and |q|≈6.73575×10⁻⁸ C (67 nC). The implied angles are 1.19° and 2.39°, so the small-angle approximation is good in either interpretation; exact-force values differ by about 0.011% and 0.043%. Geometry alone gives magnitude, while the diagram shows positive balls. Treating tiny conducting balls as point charges neglects finite-size redistribution and requires ball radius small compared with separation. Do not silently resolve undefined x in a unique answer key.

8. +2e is above −2e, separation d=10⁻⁹ m. (a) p=2ed j=3.2×10⁻²⁸ j C m, directed +y. (b) E_ext=(3i+3j) N/C gives τ=p×E=−9.6×10⁻²⁸ k N m, into the page/clockwise, magnitude 9.6×10⁻²⁸ N m. Only the x component contributes. (c) The mutual Coulomb forces lie along the dipole axis and give zero torque about the center; their total internal torque about any origin is zero because the pair is central and equal/opposite. Individual self-fields are not included.

### Full PRS independent answers

The six question/answer pairs have choices 4,2,1,4,2,3 in order.

1. pp1–2: field-line direction represents acceleration due to the electric force on a positive test charge, whether initially stationary or moving, within this electrostatic model. Negative charge and additional forces require qualification. Motion direction is not generally encoded.
2. pp3–4: the texture shows two like-sign sources/sinks with field bowing away and a null region between; the interaction is repulsive. Without arrowheads one cannot distinguish two positive from two negative sources. Force direction can be inferred; their exact values cannot.
3. pp5–6: equal-positive-charge pair field is the expression above, upward at the marked P.
4. pp7–8: the regular hexagon has circumradius equal to its side R. All six equal positive vertex fields would cancel at center. Removing the bottom charge removes an upward kq/R² field, so the remaining five give −kq/R²j. The faint lower vertex denotes the removed charge and is not included.
5. pp9–10: a finite dipole's far field falls faster than 1/r², with leading 1/r³ for nonzero p. Net zero charge cancels the monopole; this is a far-field result, not a statement about distances close to either charge.
6. pp11–12: the displayed left endpoint is labeled q₁ and right is −q₁. Field arrows point northeast and become shorter to the right. For q₁>0 the left northeast force is stronger than the right southwest force, producing net northeast electric force; both endpoint moments are clockwise. If q₁ is negative both reverse, but nonzero force and torque still apply. Colors alone are misleading; read labels. The pivot can balance translational force. The source's general phrasing about alignment and nonuniformity needs the exceptions already noted.

## Source discrepancies and minimum prerequisite bridges

Material discrepancies that can change a learner's result: Example 2.1's factor-100 numerical error; hydrogen field's changed radius; oil-drop electron sign/excess-count wording; rod substitution's sec²+1 intermediate typo; undefined x in the two-ball numerical task. Figure-dependent hazards: opposite versus like pair tasks; hexagon removed vertex; nonstandard dipole/semicircle angle conventions; square vertex labels; cylinder's bottom-origin axial distance; PRS endpoint labels versus colors; electron y₂ as additional rather than total displacement.

Qualifications with conceptual consequences: field line versus trajectory; negative-total-charge far-field inward direction; monopole far-field requires nonzero net charge; “gravity negligible” is conditional; zero force versus rest; torque tendency versus damped settling; nonuniformity alone does not guarantee nonzero torque or translation; external versus self/internal fields; point/support singularities; fixed Q versus fixed density in limits. The table's finite-rod content is mislabeled as an infinite-line illustration in introductory prose, and disk graphs are captioned as a plane. These can be handled by identifying the actual formulas and domains rather than treating captions as a new model.

Baseline-supported operations are mapped exactly in `baseline-use-map.json`. Consequential bridges not already granted include: interpreting r−r′ geometrically in Coulomb integration; signed local charge densities and continuous vector superposition; choosing and deriving ring/annulus/coordinate elements; physics dipole-moment direction and origin independence; translating a scalar moment into vector torque with the supplied cross-product components; angular work and dipole energy reference; first-order field variation applied to a finite dipole; signed polar unit vectors for the source convention; I and the rotational equation for the oscillation exercise. The general coordinate table and compact volume/surface notation need definitions, not silent reliance on prior university vector calculus. Gauss's law and a stress tensor are not prerequisites supplied by these assigned pages.

## Calculation checks and seal boundary

`calculation_checks.py` reproduces independent direct source-vector sums, component torques, Simpson quadrature of rod/ring/disk/arc/cylinder elements, finite-dipole error scaling, polar transformation, electron time integration, null-point location, numerical examples and both interpretations of the ball data. `calculation-results.json` holds 30 substantive checks plus a pass-count summary. Dimension checks are explicit in this dossier: k dq/R² is N/C; kλ/L, kσ and kρL are N/C; pE is N m/J; pE/I is s⁻²; the ball expression r³ has m³. These checks corroborate the independently derived solutions; they do not amount to acceptance of any future authored teaching.

No semantic findings from this dossier have been sent to the root or another agent before the freeze. Only readiness, access counts and file hashes may be reported at this preparation stage.
