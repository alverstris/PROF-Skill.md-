from pathlib import Path
import sys,json,hashlib,datetime
out=Path('d107-fresh-independent-technical'); log=out/'access.jsonl'
p=Path(sys.argv[1]); b=p.read_bytes(); start=int(sys.argv[2]) if len(sys.argv)>2 else 0; end=int(sys.argv[3]) if len(sys.argv)>3 else len(b)
part=b[start:end]
entry={'operation':'bounded_text_read','path':str(p),'bytes_total':len(b),'start_inclusive':start,'end_exclusive':min(end,len(b)),'sha256':hashlib.sha256(b).hexdigest(),'chunk_sha256':hashlib.sha256(part).hexdigest(),'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with log.open('a') as f:f.write(json.dumps(entry)+'\n')
print('ACCESS',json.dumps(entry));print(part.decode('utf-8',errors='replace'))
