# Complete-baseline use map for source-only D107 preparation

This records prerequisite analysis, not a lesson, authoring plan, learner trial, or acceptance verdict. The declared student baseline was read in full before the technical dossier was written. Its four subjects must be combined: an exclusion from Mathematics A alone does not remove an operation supplied explicitly in Further Mathematics or Physics. Course completion is an assumption of usable competence, not evidence of a particular learner's retained mastery. All byte offsets below are zero-based, half-open ranges in the original 247,840-byte UTF-8 file, preserving its original line endings.

The baseline SHA-256 is `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. The actual initial semantic-read chunks were [0,14000), [14000,34000), [34000,54000), [54000,74000), [74000,94000), [94000,114000), [114000,134000), [134000,154000), [154000,174000), [174000,194000), [194000,214000), [214000,234000), [234000,247840). Each was individually returned without clipping; their contiguous union is the entire file. Strict UTF-8 decoding of each chunk succeeds. Later small reinspections and heading searches are separately recorded as such; they do not substitute for this complete read. Links and references inside the baseline were not followed.

## Mathematics A, H240

The subject begins with the MATHEMATICS heading at byte 2093. Operational headings include arithmetic/geometry at 3257, algebra/functions/coordinates at 7179, sequences/binomial expansion at 12948, trigonometry at 15243, exponentials/logarithms at 18931, differentiation at 20248, integration at 23787, numerical methods at 26731, vectors at 28834, statistics at 30353 and hypothesis tests at 37610. The declared further-teaching limits begin at 48420; Further Mathematics follows around 50.7 kB. The entire subject, including statistics and all stated exclusions, was read.

| Supplied operation | D107 use | Boundary respected |
|---|---|---|
| Signed arithmetic, units, ratios, scientific notation, rearrangement | q versus Q sign, volts versus joules, density units, dimensions of A and B | Do not infer a sign from a charge magnitude notation without reading the diagram. |
| Coordinates, Pythagoras, distances and symmetry | P36 distances a and sqrt(2)a; rod/ring/disk source-to-point distances | Drawn source and field coordinates must be assigned separately. |
| Scalar/vector components, basic vector addition, trigonometric projections | Field direction and radial/axial component cancellation | The general dot-product formula is supplied by Further Mathematics FM18, not silently attributed to H240. |
| Powers, logarithms and algebraic transformations | Point potential, rod logarithmic ratio, dimensionless log argument | Potential reference cannot be established by logarithm algebra alone. |
| Derivative as local gradient, limit, chain/product rules | Read the P32 line slopes; differentiate single-variable axial potentials | A spatial gradient and partial derivatives are new formal definitions, even though their computations can use known ordinary derivatives. |
| Definite integrals, signed areas, antiderivatives, substitution and integration by parts | Radial inverse-square work, one-variable density integrals, disk ring integration | General field line integrals are not granted merely by ordinary integration. |
| Binomial expansion and leading-order approximations | Near-Earth mgh; far ring/disk/rod limits; long rod denominator | Cancellation can remove the leading term; retain the first nonzero surviving term and specify small parameter. |
| Indexed sums | Point-charge superposition and counting distinct pairs | Physical linear superposition is supplied by the physics/source content, not by sum notation alone. |
| Mechanics and signed work relations | Newton-law release-from-rest qualification, equal endpoint kinetic energy | General conservative-field machinery requires the supplied source definition/derivation. |

Statistics, probability, hypothesis testing, numerical root-finding, and the other fully read mathematical techniques are not needed as substantive laws for these D107 examples. Their presence does not justify importing statistical or other physical theories. Numerical quadrature in the checker is an independent computational verification; it is not a required unprovided student technique.

## Further Mathematics A, H245; Pure Y540/Y541, Statistics Y542, Mechanics Y543

The qualification heading occurs at byte 50832. Every numbered item FM1–FM71 was read, including the selected Statistics and Mechanics options and their limits. Exact useful anchors are FM18 at 59636, FM24 at 62829, FM28 at 64638, FM57 at 80355, FM58 at 80772, FM69 at 88305, FM71 at 89411. These anchors identify original text, not external specifications.

| Supplied operation | D107 use | Boundary respected |
|---|---|---|
| FM18 real Cartesian dot product, magnitude-angle form and perpendicularity | F·ds work projection, E·ds potential change, gradient tangent perpendicularity | This is an available prerequisite. A variable-field path integral still needs its definition. |
| Hyperbolic/inverse-hyperbolic identities and calculus, FM24–26 | Rod integral via x′=y sinh u; asinh/log equivalence | The alternative asinh result is a transparent deduction, not a new physics assumption. |
| Maclaurin/binomial reasoning | Consistent small/large-distance asymptotes | State the domain and terms retained. |
| FM28 improper integrals and endpoint limits | V(infinity)=0 for finite localized sources; divergence for an infinite line/sheet reference | Convergence must be checked; infinity is not a finite physical point. |
| FM29 substitutions, including inverse-square-root primitives | Reproducible rod primitive | Do not introduce a table lookup absent from the allowed packet. |
| FM57 dimensions; FM58 constant-force dot work and one-dimensional variable work, kinetic/potential energy | Units and signs, external work versus kinetic and potential changes | General vector-field line integrals are expressly outside prior formalism. |
| Density and mechanics reasoning, including FM63 strip/section ideas | Understand dq=lambda dl or dq=sigma dA as limiting source totals | These examples can be reduced to one-dimensional integrals; arbitrary multiple-integral technique is not presumed. |

FM69 explicitly withholds prior partial differentiation, gradient/divergence/curl calculus and general multiple/line/surface integrals of fields. FM71 requires evaluating bridges against all four supplied subjects. The available algebra, ordinary calculus and dot products suffice to introduce the limited new operations used in this source: take a directional one-variable slice, define a partial with other coordinates fixed, sum field-work over small displacement segments, and pass to a limit. Nothing in the source-only solution imports Gauss's law, Poisson's equation, divergence, curl, differential forms, tensor calculus or general PDE methods.

Complex numbers, matrices, selected statistics and the rest of the mechanics material were fully read; they are not prerequisites for these assigned calculations. Availability of a mathematical operation does not grant an unstated physical theory.

## Physics A, H556

Physics begins around byte 90.2 kB, with operational section anchors: quantities/measurement at 93345, forces/motion/energy at 104616, charge/circuits/waves/quantum at 111579, thermal/circular/oscillations/gravitation at 121386, stars/cosmology at 129620, capacitors/electric/magnetic fields at 133738, nuclear/particle/medical at 139314, and scope at 148883. All sections were read, including practical and scope qualifications, not just the electric-field section.

| Supplied knowledge | D107 use | Consequence for prerequisite judgment |
|---|---|---|
| Scalars/vectors, SI quantities and derived units | E=N/C=V/m, V=J/C, U in J, gravitational Vg in J/kg | Dimensional meaning is available; notation differences must still be defined. |
| F=ma, acceleration versus velocity, kinetic energy and conservation/work relations | PRS sign analysis and counterexample to universal downhill motion | Release from rest is a consequential physical premise; force does not dictate an arbitrary existing velocity. |
| Constant-force work F s cos(theta), gravitational energy and potential | Gravity/electric analogy, local mgh versus global -GMm/r | Familiar physical content can support a new integral derivation. |
| Signed charge, Coulomb force/field, E=F/q, field-line interpretation, superposition | Fixed point sources, midpoint cancellation of potential but addition of field | Vector addition of E and scalar addition of V must be kept distinct. |
| Point-charge electric potential, work/energy per charge and U=qV | Point potential and PRS questions | Point potential is not wholly absent prior knowledge. What is new here includes formal line-integral/gradient methods and distribution integrals. |
| Uniform fields and parallel-plate potential gradient | Ex=-dV/dx in one dimension, field direction and graph slopes | General three-variable gradient still requires a definition. |
| Electronvolt and supplied constants | Interpret eV positively as an energy unit; optional sheet-density estimate | e=1.60e-19 C, epsilon0=8.85e-12 F/m, G=6.67e-11 SI and g=9.81 m/s² are available approximate baseline constants. Source g~9.8 is compatible rounding. |

The entire circuit, capacitor, wave, thermal, quantum, astronomy, nuclear and practical content was read. No field-energy-density theorem, advanced electrodynamics or quantum model is imported from their topic labels. Baseline capacitor energy does not by itself establish a general continuum electric-field-energy formula. The supplied core point-charge/field knowledge is retained, rather than needlessly treating every university heading as an unknown.

## Chemistry A, H432

Chemistry metadata begins at byte 150718; CH-00 at 151198 states the baseline's operational and reference limits. The full CH-01–CH-12 and CH-REF content was read. Main anchors: CH-01 153588, CH-02 160599, CH-03 168069, CH-04 179139, CH-05 188700, CH-06 193637, CH-07 203129, CH-08 207264, CH-09 215858, CH-10 223920, CH-11 233241, CH-12 243883, CH-REF 246616.

CH-01 supports units, sign conventions and elementary charge representations. CH-02 supplies qualitative ionic attraction, covalent polarity and dipole reasoning; those can reinforce interpretation but do not replace the Coulomb model actually given in D107. CH-06 supplies state-function/pathway reasoning through enthalpy/Hess cycles, offering a limited analogy to endpoint-only energy changes. CH-07 electrode potentials reinforce that quoted potentials use a reference; the electrochemical sign and reference conventions are not interchangeable with an isolated electrostatic scalar field without explanation.

Acid/base calculations, kinetics, equilibria, organic transformations, analytical/spectroscopic interpretation, practical planning and all other chemistry were fully read but are not necessary for the assigned rod, ring, disk, assembly or gradient solutions. CH-12 explicitly prevents topic labels from silently supplying chemical potentials, activities, Nernst equations, statistical thermodynamics or quantum orbital derivations. No such extension is used. CH-REF links remain provenance text only; none were visited, and no absent reference tables were assumed available.

## Consequential new bridges and admissible deductions

| D107 demand | Existing support | Source-specific addition that cannot be assumed already known |
|---|---|---|
| Work along a curved path through a variable field | Ordinary integration; real dot products; constant-force and one-dimensional work | Define small vector displacement and sum F(r)·Delta r, then the path-integral limit; show radial projection or constant-field endpoint reduction. |
| Electrostatic potential difference and reference | Prior potential/work per charge; point potential | General line-integral relation, conservative/path-independent interpretation and conditions for V(infinity)=0. |
| E from a general V(x,y,z) | Ordinary differentiation and component vectors | Partial derivatives with other coordinates fixed; Cartesian gradient and the essential minus sign. |
| Equipotential perpendicularity and steepest descent | Dot-product geometry and ordinary local rate | First-order multivariable increment and directional rate; nonzero-gradient qualification. |
| Continuous charge distribution potential | Scalar superposition, density, sums, single integrals and distances | Replace charge sum by source-element integral while fixing the observation point; determine dq and source domain from the actual geometry. |
| Multiple-charge configuration energy | U=qV and signed pair potential | Assembly counts each pair once, excludes self-interaction, and explains when one-half is required. |
| Positive-sheet interpretation of a one-axis graph | P32 slopes and assigned disk sheet limit | A stated plane-symmetry model plus background field; one trace alone does not establish a unique source distribution. |

These are explicit technical prerequisite distinctions. They are not permission to introduce unrelated formalism, prescribe a future teaching sequence, or infer a learner's observed success. No PROF, future prompt packet, historical source review or other agent findings informed this map.
