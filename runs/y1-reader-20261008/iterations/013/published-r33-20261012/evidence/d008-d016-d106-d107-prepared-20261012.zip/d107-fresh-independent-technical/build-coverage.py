from pathlib import Path
import json
p=Path(__file__).parent
# Each record is authored from complete text and original-resolution visual inspection.
# P=whole presentation; R=whole PRS; C=assigned chapter PDF pages, not printed page.
P={
1:('Studio agenda','Hour 1 groups and experiment 1 visualizations; hour 2 electric potential. Group assignment reminder.','Text-only agenda; not an additional physics exercise.','context'),
2:('Groups title','Section divider; retained as full presentation coverage.','No substantive diagram.','context'),
3:('Group benefits','Ask questions, explain ideas, work together, ensure teammates keep up.','Text-only prompts; no uniquely calculable answer.','context'),
4:('Group participation','Contribution, shared credit and signed work responsibilities.','Text-only; no physics data.','context'),
5:('Group difficulties','Discuss first, seek graduate TA then teamwork consultant; act early.','Named procedural sequence belongs to the historical course context.','context'),
6:('Introductions and expectations','Discuss E&M experience, group working expectations, nonparticipation and absence.','Open-ended discussion; requires participants, no fixed source answer.','context'),
7:('Experiment 1 visualizations','Calls for a course-packet write-up and group tear sheet with all signatures.','Those experiment materials are absent from the three supplied source assets; do not invent instructions or data.','missing-associated-material'),
8:('Gravity and electric fields','Last-time recap divider.','No new calculation.','D01,D02'),
9:('Fields and forces','g=-GM rhat/r², E=kq rhat/r²; F=m g or q E.','Side-by-side gravitational/electrical notation uses q in two roles; distinguish source Q and test q.','D01,D02'),
10:('Gravitational energy and potential','Starts gravitational analogy.','Title page.','D01'),
11:('Gravity and work','Gravitational force and Wg=integral Fg dot ds.','Vector path increment and radial field; path integral requires bridge from known constant-force dot product.','D01'),
12:('Radial gravitational work','Radial projection yields GMm(1/rB-1/rA).','Earth figure has rB>rA; work is negative. Local angle between rhat and ds is distinct from polar angle in r dtheta thetahat.','D01'),
13:('Near-Earth gravitational work','Constant downward g; Wg=-mg(yB-yA), endpoint only.','A lower than B; upward y; curved path does not change endpoint result.','D01'),
14:('Gravitational potential energy','DeltaUg=-Wg, Ug=-GMm/r+U0 or mgy+U0.','Equality to external work requires deltaK=0; constants set reference.','D01'),
15:('Gravitational potential','Potential difference per unit mass equals minus integral g dot ds.','Units J/kg; field source property distinct from m-dependent energy.','D01'),
16:('PRS masses reminder','Directs to the gravitational potential PRS.','Corresponds to PRS1–2; no additional numerical data.','D03'),
17:('Electrostatic analogy title','Transitions gravity to electrostatics.','Divider only.','D02'),
18:('Comparison of gravity and electrostatics','Parallel formulas for force, field, potential energy and potential.','Conservative path relations; separate source/test charges.','D01,D02'),
19:('Electric potential and work','DeltaV=-integral E dot ds; deltaU=q deltaV; volts J/C.','Wexternal=deltaU assumes equal endpoint kinetic energy.','D02'),
20:('Creating potential','V(r)=V0 minus field integral from reference.','Reference label 0 need not be spatial origin; endpoint reference must be defined.','D02'),
21:('Potential landscape','Height encodes scalar potential.','Positive charge peak at left, negative charge well at right; not an added spatial dimension.','D08'),
22:('Creating and feeling potential','Sources create V; placed charge has U=qV.','Same V gives different signed U for positive/negative test charges.','D04,D05'),
23:('Potential landscape reprise','Repeat scalar landscape used to discuss energy.','Same positive peak and negative well; preserve sign interpretation.','D08'),
24:('Three potential-energy PRS','Question navigation for positive, negative and statement questions.','Corresponds to PRS3–8.','D04,D05,D06'),
25:('Creating potentials title','Introduces example calculations.','Divider; no extra example beyond subsequent content.','D02'),
26:('Point charge potential','Radial integral gives kQ(1/rB-1/rA), V(infinity)=0 gives kQ/r.','Q at origin, A/B radii, arbitrary path ds and projection dr; local-angle/polar-angle distinction.','D02'),
27:('Two potential PRS','Navigation to point-charge and landscape questions.','Corresponds to PRS9–12; potential scalar addition and gradient direction.','D07,D08'),
28:('Potential landscape reprise','Repeated scalar landscape before derivatives.','Peak positive, well negative; local slope determines field.','D08'),
29:('Obtaining electric field','Title transition from V to E.','No new diagram or exercise.','D15'),
30:('One component from potential','Ex=-partial V/partial x, with y,z fixed.','A(x,y,z), B(x+dx,y,z); formula correct, prose omits word negative. Difference quotient becomes derivative.','D15'),
31:('Gradient','E=-grad V; Cartesian gradient components.','Operator defined by three fixed-other-coordinate derivatives; no assumed prior vector calculus.','D15'),
32:('In-class potential graph','Draw Ex; bonus whether/where charge exists.','Graph points (-2,-10),(-1,0),(0,10),(2,5) in m,V. Slopes +10,-2.5 V/m; Ex=-10,+2.5, undefined ideal corner. Positive sheet plus background is conditional on planar symmetry.','D09'),
33:('Configuration energy title','Introduces charge assembly.','Divider.','D10'),
34:('Two charges','First charge free of pair energy; bringing second costs kq1q2/r12.','Two charge locations separated r12; self-energy excluded.','D10'),
35:('Three charges','Third adds q3(V1+V2); sum of three distinct pair terms.','Triangle labels r12,r13,r23; each pair counted once.','D10'),
36:('In-class three-charge exercise','Find V(P), initial energy, and work to add +3Q at P.','q1=-Q at(-a,0), q2=-Q at(0,0), q3=+Q at(a,0), P(0,a). Outer distances sqrt2 a; initial pair distances a,a,2a. V=-kQ/a, U=-kQ²/(2a), added W=-3kQ²/a.','D11')}
R={
1:('Masses in potentials question','Equal masses at zero, constant nonzero, and linearly varying gravitational potentials; only linear case has acceleration.','At the linear case marked V=0, value alone does not imply zero field. Answer option3 under free-motion/full-space interpretation.','D03'),
2:('Masses answer','Printed option3; compares to heights.','Constant height along a surface cannot imply all gravity absent; distinguish scalar value from gradient.','D03'),
3:('Positive charge question','Intended lower V and lower U, option2.','Read direction choices explicitly; release-from-rest/electric-force-only qualification.','D04'),
4:('Positive charge answer','Printed option2.','Printed always-move-down-energy wording is too broad for nonzero initial velocity.','D04'),
5:('Negative charge question','Intended higher V and lower U, option4.','Negative signed q reverses energy change relative to potential.','D05'),
6:('Negative charge answer','Printed option4.','Same always-move qualification as positive charge.','D05'),
7:('Three statements question','I external positive work bringing like charges closer true; II field lines decreasing V true; III negative charge along E decreasing U false.','Option4 I and II. I requires external/equal-endpoint-K work meaning.','D06'),
8:('Three statements answer','Printed option4 with explanation.','Check each claim by signed energy and field relation, not option matching alone.','D06'),
9:('Two point charges question','Work from infinity to midpoint of +q and -q.','+q left, -q right, midpoint P; curved approach. Equal distances cancel V, fields add rightward. Intended option3 zero.','D07'),
10:('Two point charges answer','Printed zero potential-work result.','Does not imply zero field or zero local force at P.','D07'),
11:('Potential landscape question','Which direction does electric field point on scalar potential surface?','Option2 steepest descent; landscape peak/well and direction choices visually read.','D08'),
12:('Potential landscape answer','Printed option2 fastest downhill.','Local field direction from gradient; stationary points have no unique first-order direction.','D08')}
C={
2:('3.1 Gravitational potential','Exterior spherical/point gravity, work path integral and radial reduction.','Fig3.1.1 shows rB>rA outward path; g inward, ds tangent. G=6.67e-11 SI. Assignment starts at section3.1 below chapter title.','D01'),
3:('Gravity work and energy','External/field work relation; near-Earth g~9.8; conservative closed loop; Ug=-GMm/r+U0.','Fig3.1.2 upward y, A lower than B. External work equality needs unchanged endpoint K.','D01'),
4:('Reference and electric potential','Ug reference/mgh approximation; gravitational potential per mass; electric deltaV=-integral E dot ds and deltaU=q0deltaV.','Explicit unchanged-kinetic-energy condition; units J/C=V; electronvolt begins.','D01,D02'),
5:('3.2 Uniform field','1eV=1.6e-19 J; downward E gives deltaV=-E0d; oblique path.','Fig3.2.1 upward j with A above B; Fig3.2.2 A above C, B right of C, diagonal s makes theta with downward field, y defined downward.','D02'),
6:('Uniform broken path; 3.3 point charge','Direct versus AC+CB yields same -E0y; perpendicular segment no change. Point-source rhat dot ds=dr.','B,C equipotential; Fig3.3.1 source Q, two radial endpoints, local path ds.','D02'),
7:('Point charge and superposition','Finite-source V(infinity)=0 gives kQ/r; scalar potentials sum; gravity/electric comparison table.','Table writes V for A-to-B differences and |deltaU|=qEd with implicit magnitude/parallel restriction.','D01,D02,D10'),
8:('3.3.1 Pair assembly','Two then three charge assembly; interaction energy sign.','Fig3.3.2/3.3.3 source locations and r12,r13,r23. At-rest-at-end alone not identical to no acceleration; equal endpoint K suffices for work relation.','D10'),
9:('N-charge assembly; 3.4 continuum','Pair sum i<j and half ordered sum; continuum source elements.','Fig3.4.1 source cloud deltaq, rhat from source element to P, deltaE outward for positive element. No self pair.','D10,D12,D13,D14'),
10:('Continuum potential; 3.5 differentiating','dV=k dq/r, integral potential; dV=-E dot ds, Ex=-partialx V, vector gradient.','Eq3.5.2 printed component expansion lacks minus sign, while neighboring equations correctly retain it. Inspected original PNG, not extraction artifact.','D12,D13,D14,D15'),
11:('Radial derivative and 3.5.1 equipotentials','Point kQ/r differentiated; level curves/surfaces.','Fig3.5.1 nested C1,C2,C3 contours without justified numerical ordering; radial formula only under spherical symmetry.','D02,D08'),
12:('Equipotential tangent and field','First-order potential increment, gradient directional rate, field perpendicular to level surface.','Fig3.5.2 tangent ds and perpendicular gradient; Fig3.5.3 uniform rightward field/vertical dashed levels, radial positive point, +left/-right dipole.','D08'),
13:('Topographic analogy; Example3.1 rod','Level-height analogy z=f(x,y), Vg=gz; rod geometry begins.','Fig3.5.4 perspective hill and contour map. Fig3.5.5 rod from -ell/2 to ell/2, P(0,y), source xprime, diagonal r and angle theta-prime.','D08,D12'),
14:('Rod integration and graph','dq=lambda dxprime; integrate inverse sqrt to logarithmic ratio; begin long-rod limit.','Fig3.5.6 normalized V/V0 vs y/ell, V0=klambda, even diverging center and vanishing tails. Keep nonzero denominator term in long-rod limit.','D12'),
15:('Rod field; Example3.2 ring','Long-rod logarithmic V and exact Ey; ring potential setup.','Differentiate exact rod V for exact Ey. Ring is in xy plane, point on z axis, source azimuth phi-prime. Wording from central axis conflicts with actual axial geometry.','D12,D13'),
16:('Ring result; Example3.3 disk','Ring V=kQ/sqrt(R²+z²), axial E; disk decomposed into source rings.','Ring center E0 despite V nonzero. Disk figure labeled3.4.3; rprime source radius, drprime width, z axis observation, R outerradius.','D13,D14'),
17:('Disk result and comparison graph','V=sigma/(2eps)(sqrt(R²+z²)-|z|); Q=piR²sigma; far limit, finite center, signed field.','Fig3.4.4 V/V0 disk peaks2 at0, below point1/|z/R|, both even and converge far away. V0=kQ/R. Cusp demands one-sided fields.','D14'),
18:('Disk sheet limit; Example3.4 polynomial','Positive-side sheet limit; V=Ax²y²+Bxyz differentiated into three field components.','R>>|z| needs sign(z). Prose C unused. Exact assignment ends before3.6 Summary; first two summary bullets visible incidentally on whole page excluded.','D14,D15')}
rows=json.loads((p/'required-pages.json').read_text())
visual=json.loads((p/'visual-access.json').read_text())
access=[json.loads(line) for line in (p/'access.jsonl').read_text().splitlines()]
for row in rows:
    mapping={'presentation':P,'prs':R,'reading':C}[row['role']]
    title,claims,figure,derivations=mapping[row['page']]
    row.update(title=title,source_claims=claims,full_resolution_figure_and_notation_reading=figure,
               dossier_derivations=derivations.split(','),text_status='complete individually read, no output clipping',
               image_status='complete full page displayed and read at original resolution')
    row['actual_text_access_record_1based']=next(i+1 for i,r in enumerate(access) if r.get('path')=='original-inputs/D107/'+row['text_file'] and r['operation']=='bounded_text_read')
    row['actual_visual_ordinal']=next(r['ordinal'] for r in visual if r['role']==row['role'] and r['page']==row['page'])
    if row['role']=='reading':row['printed_chapter_page']=row['page']-1
    row['assignment_boundary']='whole page' if not(row['role']=='reading' and row['page'] in [2,18]) else ('start at 3.1 heading below chapter title' if row['page']==2 else 'end immediately before 3.6 Summary')
assert len(rows)==65 and len(P)==36 and len(R)==12 and len(C)==17
(p/'coverage.json').write_text(json.dumps({'counts':{'presentation':36,'prs':12,'reading':17,'total':65},'pages':rows},indent=2)+'\n')
print('Wrote 65-page coverage map.')
