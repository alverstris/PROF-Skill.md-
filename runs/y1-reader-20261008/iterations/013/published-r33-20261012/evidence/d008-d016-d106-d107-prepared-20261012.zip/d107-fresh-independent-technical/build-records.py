from pathlib import Path
import hashlib,json
p=Path(__file__).parent
root=p.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
identity_path=root/'original-inputs/D107/source-identity.json'
s=json.loads(identity_path.read_text())
records=[json.loads(line) for line in (p/'access.jsonl').read_text().splitlines()]
# Post-access annotations: these only document actual metadata searches already performed.
extra=[
 {'operation':'metadata_search','path':'d013-clean-r32-20261012/inputs/student-baseline.txt','byte_range_loaded':[0,247840],'display':'occurrence offsets of subject and FM labels only','tool_chunk':'8f60f0','semantic_reading_claim':False},
 {'operation':'metadata_search','path':'d013-clean-r32-20261012/inputs/student-baseline.txt','byte_range_loaded':[0,247840],'display':'subject and chemistry heading lines with byte offsets','tool_chunk':'04dad3','semantic_reading_claim':False},
 {'operation':'metadata_search','path':'d013-clean-r32-20261012/inputs/student-baseline.txt','byte_range_loaded':[0,247840],'display_byte_region_scanned':[0,50000],'display':'short Mathematics lines and heading offsets','tool_chunk':'f493c2','semantic_reading_claim':False},
 {'operation':'metadata_search','path':'original-inputs/D107/source-identity.json','byte_range_loaded':[0,50156],'display':'top-level and asset key names only','tool_chunk':'db8ec6','semantic_reading_claim':False},
]
# Keep access.jsonl immutable ordering from the actual reader; annotate later searches separately.
(p/'supplementary-access.json').write_text(json.dumps(extra,indent=2)+'\n')
visual=json.loads((p/'visual-access.json').read_text())
seq=[]
def event(kind,**kw):seq.append(dict(sequence=len(seq)+1,kind=kind,**kw))
event('directory_inventory',tool='tools.exec_command',operation='rg file paths only',semantic_content=False)
event('identity_initial_read',tool='tools.exec_command',path='original-inputs/D107/source-identity.json',attempted_bytes=[0,50156],output_clipped=True,tool_chunk='fc2b2f',complete_read_claim=False)
event('identity_boundary_recovery',tool='tools.exec_command',path='original-inputs/D107/source-identity.json',tool_chunk='7d5c89',display='Complete exact asset assignment scopes, required pages and PDF hash/size metadata',historical_reading_claims_not_adopted=True)
base=[(i+1,r) for i,r in enumerate(records) if r['operation']=='bounded_text_read' and r['path'].endswith('student-baseline.txt')]
for i,r in base:
 event('baseline_chunk',tool='tools.exec_command via access_reader.py',access_record_1based=i,path=r['path'],byte_range=[r['start_inclusive'],r['end_exclusive']],sha256=r['chunk_sha256'],output_clipped=False)
event('hash_and_dimension_validation',tool='tools.exec_command',scope='Three PDFs and all 130 required page text/image derivatives versus source identity',semantic_reading_claim=False)
def textbatch(role,a,b,chunk):
 entries=[]
 for i,r in enumerate(records):
  if r['operation']=='bounded_text_read' and f'original-inputs/D107/{role}-' in r['path']:
   page=int(Path(r['path']).stem.rsplit('-p',1)[1])
   if a<=page<=b and not any(e['page']==page for e in entries):
    entries.append(dict(page=page,access_record_1based=i+1,path=r['path'],byte_range=[r['start_inclusive'],r['end_exclusive']],sha256=r['sha256']))
 event('source_text_batch',tool='tools.exec_command via access_reader.py',tool_chunk=chunk,role=role,pages=list(range(a,b+1)),individual_reads=entries,output_clipped=False)
def imagebatch(role,a,b):
 event('source_full_page_images',tool='tools.view_image',role=role,pages=list(range(a,b+1)),detail='original',individual_reads=[v for v in visual if v['role']==role and a<=v['page']<=b],thumbnails_used=False)
textbatch('presentation',1,12,'fd5b75');imagebatch('presentation',1,6);imagebatch('presentation',7,12)
textbatch('presentation',13,24,'250c54');imagebatch('presentation',13,18);imagebatch('presentation',19,24)
textbatch('presentation',25,36,'44cb55');imagebatch('presentation',25,30);imagebatch('presentation',31,36)
textbatch('prs',1,12,'b77e21');imagebatch('prs',1,4);imagebatch('prs',5,8);imagebatch('prs',9,12)
textbatch('reading',2,7,'dae8aa');imagebatch('reading',2,4);imagebatch('reading',5,7)
textbatch('reading',8,13,'017c35');imagebatch('reading',8,10);imagebatch('reading',11,13)
textbatch('reading',14,18,'1d1cbd');imagebatch('reading',14,16);imagebatch('reading',17,18)
ids=[(i+1,r) for i,r in enumerate(records) if r['operation']=='bounded_text_read' and r['path'].endswith('source-identity.json')]
for (i,r),chunk in zip(ids,['dd8c31','c3e537','b33040','c45169']):
 event('identity_full_clipping_recovery_chunk',tool='tools.exec_command via access_reader.py',access_record_1based=i,path=r['path'],byte_range=[r['start_inclusive'],r['end_exclusive']],sha256=r['chunk_sha256'],tool_chunk=chunk,output_clipped=False)
event('visual_access_recording_and_utf8_check',tool='tools.exec_command',tool_chunk='6f5c26',meaning='Post-access recording of actual 65 full displays and strict UTF8 validation of baseline chunks',semantic_reading_claim=False)
event('baseline_anchor_lookup',**{k:v for k,v in extra[0].items() if k!='operation'})
event('baseline_bounded_reinspection',tool='tools.exec_command',tool_chunk='8af771',ranges=[[0,320],[49600,51200],[88000,91300],[150500,153500],[243800,247840]],output_clipped=False,note='Already-read paragraphs revisited for exact scope wording')
for e in extra[1:3]:event('baseline_heading_lookup',**{k:v for k,v in e.items() if k!='operation'})
r=records[-1]
assert r['path'].endswith('ch3electri_poten-p08.txt')
event('source_text_reinspection',tool='tools.exec_command via access_reader.py',tool_chunk='2d1663',access_record_1based=len(records),path=r['path'],byte_range=[r['start_inclusive'],r['end_exclusive']],output_clipped=False,note='Verify exact figure numbers after dossier drafting')
event('metadata_key_lookup',**{k:v for k,v in extra[3].items() if k!='operation'})
event('seal_input_inventory',tool='tools.exec_command via build-records.py',semantic_reading_claim=False,note='Hash all allowed packet files; verify original PDFs/required derivative/baseline hashes. Unassigned pages are not semantically read.')
(p/'reading-sequence.json').write_text(json.dumps({'description':'Actual tool/content order, reconstructed from this agent own invocations and actual per-file access logs; no historical metadata reading claim adopted.','sequence':seq},indent=2)+'\n')

files=[]
for f in sorted((root/'original-inputs/D107').rglob('*')):
 if f.is_file():
  b=f.read_bytes();files.append(dict(path=str(f.relative_to(root)),bytes=len(b),sha256=sha(b),operation='hash_only_inventory',semantic_reading_claim=False))
bp=root/'d013-clean-r32-20261012/inputs/student-baseline.txt';bb=bp.read_bytes()
assert len(bb)==247840 and sha(bb)=='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
assets=[]
for a in s['assets']:
 f=root/'original-inputs/D107'/a['local_pdf'];b=f.read_bytes()
 assert sha(b)==a['sha256'] and len(b)==a['bytes']
 assets.append(dict(role=a['role'],path=str(f.relative_to(root)),bytes=len(b),sha256=sha(b),pdf_pages=a['page_count'],required_pdf_pages=a['required_pdf_pages'],original_hash_match=True))
required=json.loads((p/'required-pages.json').read_text())
for row in required:
 for k in ['text','image']:
  b=(root/'original-inputs/D107'/row[k+'_file']).read_bytes()
  assert sha(b)==row[k+'_sha256']
expected=0
for _,r in base:
 assert r['start_inclusive']==expected
 assert sha(bb[r['start_inclusive']:r['end_exclusive']])==r['chunk_sha256']
 bb[r['start_inclusive']:r['end_exclusive']].decode('utf-8')
 expected=r['end_exclusive']
assert expected==247840
(p/'input-manifest.json').write_text(json.dumps(dict(
 allowed_original_roots=['original-inputs/D107','d013-clean-r32-20261012/inputs/student-baseline.txt'],
 source_identity=dict(path='original-inputs/D107/source-identity.json',bytes=identity_path.stat().st_size,sha256=sha(identity_path.read_bytes())),
 baseline=dict(path=str(bp.relative_to(root)),bytes=len(bb),sha256=sha(bb),initial_bounded_read_chunks=len(base),whole_file_covered=True),
 source_assets=assets,original_packet_file_count=len(files),original_packet_inventory=files,
 required_derivatives_verified=130,originals_preserved=True,
 preservation_basis='No source mutations were performed. All three PDF and all required derivative hashes still match original source identity; baseline matches assigned hash. Other allowed files inventoried by hash only, not claimed as semantic reads.'),indent=2)+'\n')
print(json.dumps(dict(sequence_events=len(seq),original_packet_files=len(files),required_source_pages=len(required),baseline_chunks=len(base),original_hash_checks_passed=True)))
