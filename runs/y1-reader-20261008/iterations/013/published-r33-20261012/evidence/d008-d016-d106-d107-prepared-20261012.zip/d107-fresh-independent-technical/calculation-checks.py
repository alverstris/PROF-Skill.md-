"""Independent D107 checks; Python 3 standard library only, no network.
Numerical fixtures are normalized k=1 or GMm=1 unless stated. None are source data.
Adaptive quadrature integrates Coulomb kernels independently of closed forms.
Finite differences and path integration supplement the exact derivations in dossier.md.
"""
from pathlib import Path
from itertools import permutations, combinations
from fractions import Fraction as F
import json, math

results=[]
def check(name,actual,expected,tol=2e-10,method='',scope=''):
    error=abs(actual-expected)
    results.append(dict(name=name,actual=float(actual),expected=float(expected),
                        absolute_error=float(error),relative_scale_tolerance=tol,
                        passed=error<=tol*max(1,abs(expected)),method=method,scope=scope))

def quad(fn,a,b,eps=2e-12):
    if a==b:return 0.
    if a>b:return -quad(fn,b,a,eps)
    fa,fb=fn(a),fn(b);c=(a+b)/2;fc=fn(c);whole=(b-a)*(fa+4*fc+fb)/6
    def rec(a,b,fa,fb,fc,whole,eps,depth):
        c=(a+b)/2;d=(a+c)/2;e=(c+b)/2;fd,fe=fn(d),fn(e)
        left=(c-a)*(fa+4*fd+fc)/6;right=(b-c)*(fc+4*fe+fb)/6
        delta=left+right-whole
        if depth<=0 or abs(delta)<=15*eps:return left+right+delta/15
        return rec(a,c,fa,fc,fd,left,eps/2,depth-1)+rec(c,b,fc,fb,fe,right,eps/2,depth-1)
    return rec(a,b,fa,fb,fc,whole,eps,25)

def diff(fn,x):
    h=2e-4*max(1,abs(x))
    return (fn(x-2*h)-8*fn(x-h)+8*fn(x+h)-fn(x+2*h))/(12*h)

# A curved path checks the radial projection in Cartesian components.
def gravitational_work_density(t):
    r=2+t;theta=.7*t
    px,py=r*math.cos(theta),r*math.sin(theta)
    dx,dy=math.cos(theta)-.7*r*math.sin(theta),math.sin(theta)+.7*r*math.cos(theta)
    return (-px*dx-py*dy)/r**3
wg=quad(gravitational_work_density,0,1)
check('gravity_curved_path_work',wg,1/3-1/2,method='Cartesian F dot dr integrated along curved spiral',scope='D01')
check('gravity_deltaU_minus_work',(-1/3+1/2)+wg,0,method='Endpoint energy plus field work',scope='D01')
check('uniform_curved_path_potential',-quad(lambda t:-5*(4-2*t),0,1),15,
      method='Cartesian path x=2t, y=3t+t(1-t) versus endpoint displacement',scope='D02')
for Q in [2,-3]:
    check('point_potential_radial_integral_Q'+str(Q),-quad(lambda u:Q/u**2,2,5),Q*(1/5-1/2),
          method='Independent minus E dr quadrature with both source signs',scope='D02')
    check('point_potential_derivative_Q'+str(Q),-diff(lambda r:Q/r,1.7),Q/1.7**2,
          method='Five-point potential derivative against Coulomb field',scope='D02')
for label,v,expected in [('zero',lambda x:0,0),('constant_nonzero',lambda x:7,0),('zero_value_nonzero_gradient',lambda x:3*x,-3)]:
    check('prs_gravity_'+label,-diff(v,0),expected,method='Numerical slope at the mass location',scope='D03')
for q in [-1,1]:
    dt=F(1,10);dx=F(q,2)*dt**2
    check('prs_release_deltaU_q'+str(q),q*(-dx),F(-1,200),tol=0,
          method='Exact rational Newton motion from rest; E=m=1, V=-x',scope='D04–D05')
    dx=-q*dt+F(q,2)*dt**2
    check('prs_initial_velocity_counterexample_q'+str(q),q*(-dx),F(19,200),tol=0,
          method='Exact rational motion with initial v=-q; deltaU positive',scope='D04–D05 qualification')
check('prs_like_charge_external_work',F(1)-F(1,2),F(1,2),tol=0,method='Unit like charges, separation 2 to 1',scope='D06')
check('prs_negative_charge_along_field_deltaU',(-1)*(-2),2,tol=0,method='E=1, displacement +2, q=-1',scope='D06')
check('prs_dipole_midpoint_potential',F(1,2)-F(1,2),0,tol=0,method='Signed scalar sum, equal midpoint distances',scope='D07')
check('prs_dipole_midpoint_field',F(1,4)+F(1,4),F(1,2),tol=0,method='Both vectors point from +q toward -q',scope='D07')
check('prs_steepest_descent_directional_change',3*(-F(3,5))+4*(-F(4,5)),-5,tol=0,
      method='Gradient (3,4), unit descent (-3/5,-4/5)',scope='D08')

# Figure-derived slopes, not output formulas recycled as test inputs.
left=(F(10)-0)/(0-(-1));right=(F(5)-10)/(2-0)
check('graph_left_field',-left,-10,tol=0,method='Points (-1,0),(0,10)',scope='D09')
check('graph_right_field',-right,F(5,2),tol=0,method='Points (0,10),(2,5)',scope='D09')
check('graph_cross_corner_deltaV',-((-10)*1+F(5,2)*2),5,tol=0,
      method='Piecewise field integrated from x=-1 to 2 versus endpoint graph values',scope='D09')
B=(F(-10)+F(5,2))/2;S=(F(5,2)-F(-10))/2
check('graph_sheet_background',B,F(-15,4),tol=0,method='Solve B-S=-10, B+S=2.5',scope='D09 bonus')
check('graph_sheet_sigma_over_epsilon',2*S,F(25,2),tol=0,
      method='Assigned disk infinite-radius limit S=sigma/(2 epsilon)',scope='D09 bonus')

# All assembly permutations independently compared with unordered pair sum.
charges=[-1,-1,1,3];points=[(-1,0),(0,0),(1,0),(0,1)]
def distance(i,j):return math.hypot(points[i][0]-points[j][0],points[i][1]-points[j][1])
def pairs(indices):return math.fsum(charges[i]*charges[j]/distance(i,j) for i,j in combinations(indices,2))
def assembly(order):
    old=[];terms=[]
    for i in order:
        terms.append(charges[i]*math.fsum(charges[j]/distance(i,j) for j in old));old.append(i)
    return math.fsum(terms)
check('configuration_V_at_P',math.fsum(charges[j]/distance(3,j) for j in range(3)),-1,
      method='Signed source sum at original coordinates, k=Q=a=1',scope='D11')
check('configuration_three_pair_sum',pairs(range(3)),-.5,method='All three unordered pairs',scope='D10–D11')
check('configuration_fourth_marginal',pairs(range(4))-pairs(range(3)),-3,
      method='Four-body pair sum minus three-body pair sum',scope='D11')
check('configuration_four_total',pairs(range(4)),-3.5,method='All six unordered pairs',scope='D11')
for n in [3,4]:
    errors=[abs(assembly(order)-pairs(range(n))) for order in permutations(range(n))]
    check('configuration_all_'+str(n)+'_charge_assembly_orders',max(errors),0,1e-13,
          'All '+str(len(errors))+' assembly permutations versus order-free pair enumeration','D10–D11')

# Coulomb kernels independently verify both potential and field.
L=2.4;lam=.7;R=1.3;Q=-1.2;sigma=.4
rod_v=lambda y:2*lam*math.asinh(L/(2*abs(y)))
rod_e=lambda y:lam*L/(y*math.sqrt((L/2)**2+y*y))
for y in [.31,2.7,-.8]:
    qv=quad(lambda u:lam/math.sqrt(u*u+y*y),-L/2,L/2)
    qe=quad(lambda u:lam*y/(u*u+y*y)**1.5,-L/2,L/2)
    check('rod_potential_kernel_y'+str(y),qv,rod_v(y),method='Direct source-element Coulomb potential quadrature',scope='D12')
    check('rod_field_kernel_y'+str(y),qe,rod_e(y),method='Direct source-element axial field projection quadrature',scope='D12')
    check('rod_potential_derivative_y'+str(y),-diff(rod_v,y),qe,2e-9,
          'Five-point derivative against independent field integral','D12')
check('rod_near_axis_limit',rod_v(1e-6)/(2*lam*math.log(L/1e-6)),1,1e-10,
      'Finite rod logarithmic asymptote, retaining finite L','D12')
check('rod_far_field_limit',rod_v(1e5)/(lam*L/1e5),1,1e-10,
      'Total-charge point limit','D12')

ring_v=lambda z:Q/math.sqrt(R*R+z*z)
ring_e=lambda z:Q*z/(R*R+z*z)**1.5
for z in [0,.4,-2.1]:
    qv=quad(lambda phi:Q/(2*math.pi)/math.sqrt(R*R+z*z),0,2*math.pi)
    qe=quad(lambda phi:Q/(2*math.pi)*z/(R*R+z*z)**1.5,0,2*math.pi)
    ex=quad(lambda phi:Q/(2*math.pi)*(-R*math.cos(phi))/(R*R+z*z)**1.5,0,2*math.pi)
    check('ring_potential_kernel_z'+str(z),qv,ring_v(z),method='Angular source integral',scope='D13')
    check('ring_field_kernel_z'+str(z),qe,ring_e(z),method='Axial field projection integral',scope='D13')
    check('ring_transverse_cancellation_z'+str(z),ex,0,method='Signed transverse angular field integral',scope='D13')
    check('ring_potential_derivative_z'+str(z),-diff(ring_v,z),qe,2e-9,
          'Five-point derivative versus independent field integral','D13')
check('ring_far_field_negative_axis',ring_v(-1e5)/(Q/1e5),1,1e-10,
      'Far limit using absolute distance on negative axis','D13')

# k=1 gives 1/(2 epsilon)=2 pi. Rationalized V avoids far-axis cancellation.
disk_v=lambda z:2*math.pi*sigma*R*R/(math.sqrt(R*R+z*z)+abs(z))
disk_e=lambda z:2*math.pi*sigma*(math.copysign(1,z)-z/math.sqrt(R*R+z*z))
for z in [.2,3.7,-.8]:
    qv=quad(lambda u:2*math.pi*sigma*u/math.sqrt(u*u+z*z),0,R)
    qe=quad(lambda u:2*math.pi*sigma*u*z/(u*u+z*z)**1.5,0,R)
    check('disk_potential_kernel_z'+str(z),qv,disk_v(z),method='Ring-element potential quadrature',scope='D14')
    check('disk_field_kernel_z'+str(z),qe,disk_e(z),method='Ring-element axial field quadrature',scope='D14')
    check('disk_potential_derivative_z'+str(z),-diff(disk_v,z),qe,2e-9,
          'Five-point derivative versus independent field integral off the plane','D14')
check('disk_center_normalized_potential',disk_v(0)/(math.pi*R*sigma),2,
      method='V0=kQ/R, Q=pi R² sigma',scope='D14 figure')
check('disk_far_field_limit',disk_v(1e5)/(math.pi*R*R*sigma/1e5),1,1e-10,
      'Finite disk versus point total charge, stable rationalized expression','D14')
for sign in [-1,1]:
    check('disk_sheet_side_limit_'+str(sign),disk_e(sign*1e-10)/(2*math.pi*sigma),sign,1e-9,
          'One-sided fields, excluding the ideal charged plane','D14')

# Multivariable numerical differentiation, then independent line integration.
A=1.7;B=-.9
V=lambda x,y,z:A*x*x*y*y+B*x*y*z
def E(x,y,z):return (-2*A*x*y*y-B*y*z,-2*A*x*x*y-B*x*z,-B*x*y)
for p in [(1.2,-.7,2.3),(-2,1.4,-.2),(0,2,3)]:
    for j,axis in enumerate('xyz'):
        def along(u):
            arg=list(p);arg[j]=u;return V(*arg)
        check('polynomial_gradient_'+axis+'_'+str(p),-diff(along,p[j]),E(*p)[j],2e-9,
              'Five-point partial holding other coordinates fixed','D15')
def poly_work_density(t):
    ex,ey,ez=E(1+t,2-t,-1+3*t)
    return ex-ey+3*ez
check('polynomial_line_integral_reconstruction',quad(poly_work_density,0,1),-(V(2,1,2)-V(1,2,-1)),
      method='Oblique 3D path integration compared with independent endpoint potential',scope='D15')
for t in [.17,.91,2.1]:
    x,y=2*math.cos(t),2*math.sin(t);dx,dy=-2*math.sin(t),2*math.cos(t)
    check('equipotential_tangent_orthogonality_'+str(t),2*x*dx+2*y*dy,0,
          method='V=x²+y², radius-2 level curve, gradient dot tangent',scope='C11–C12')
summary=dict(description=__doc__.strip(),numeric_arithmetic='IEEE-754 binary64; exact rational checks where marked',
             checks=len(results),passed=sum(r['passed'] for r in results),failed=sum(not r['passed'] for r in results),
             all_passed=all(r['passed'] for r in results),results=results)
Path(__file__).with_name('calculation-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2))
if not summary['all_passed']:
    print(json.dumps([r for r in results if not r['passed']],indent=2));raise SystemExit(1)
