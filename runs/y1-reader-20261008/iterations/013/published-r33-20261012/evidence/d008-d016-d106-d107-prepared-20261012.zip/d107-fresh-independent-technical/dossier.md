# D107 independent technical dossier — sealed source preparation

This is an independent, source-only technical record for MIT 8.02T Spring 2005 studio 4. It is not a teaching document, a current authoring review, an acceptance decision, or evidence of a student trial. It may be released to a future evaluator only under the parent task's freeze protocol. No current PROF or prompt-only packet was available or read during preparation.

## Inputs and boundaries

The only subject inputs accessed were `original-inputs/D107` and the complete 247,840-byte four-subject student baseline at `d013-clean-r32-20261012/inputs/student-baseline.txt`, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. Source identity was the first content read. Its historical inspection language was treated as metadata, never as this agent's actual reading. Its `cache_source` and `identity_basis` targets were not followed. No network, browser, GitHub, other dossier, prior teaching, audit, PROF, or other agent findings supplied content.

Required coverage is all 36 presentation pages, all 12 associated PRS pages, and chapter 3 sections 3.1–3.5 on PDF pages 2–18. Chapter PDF p2 starts at the 3.1 heading, below the chapter title. Chapter PDF p18 includes the disk continuation and all Example 3.4, ending before `3.6 Summary`. Full-page text and PNG inspection necessarily displayed the first two summary bullets below that boundary; these were excluded from assigned claims and exercises. PDF p1 and p19–30 were not read as subject content. Printed chapter page numbers are one less than PDF page numbers. All 65 required pages were read as complete individual text files and complete original-resolution PNGs; no thumbnail or contact sheet substituted for a figure. Source wording and provided solutions were visible during that reading; independent verification therefore means rederivation and alternative checks, not a claim to have been blinded to printed source answers.

The original packet supplies only the three named source PDFs and their derivatives. Slide 7 refers to an experiment write-up and tear sheet that are not part of those assets. No experiment instructions, measurements, or answers have been fabricated. Group-introduction prompts are contextual discussions, not problems with unique physics solutions.

## Convention and claim ledger

Use stationary sources, electrostatics, an inertial laboratory frame, vacuum permittivity, and a test charge whose presence does not rearrange the prescribed sources. Source locations and source charges remain fixed unless the task is explicitly assembly. Write k = 1/(4π ε₀), q for a signed moved charge, Q for a signed source charge unless the figure explicitly makes Q a positive magnitude, and r > 0 for source-to-field-point distance. Point-charge self-potential and self-energy are excluded.

1. **Forces and fields** [P9, P11–15, P18; C2–4, C7]. For an exterior point/spherically symmetric gravitational source, g = −GM r̂/r² and Fg = m g. For a point electric source, E = kQ r̂/r² and Fe = qE. The source-to-field r̂ points outward regardless of charge sign. The exterior gravitational formula is not an inside-uniform-sphere formula. Field and potential are properties of the prescribed sources and observation point; force and test-charge interaction energy also depend on the test particle.
2. **Work and conservative fields** [P11–19, P26; C2–7]. Wfield = ∫A^B F·ds and ΔU = U(B)−U(A) = −Wfield. A conservative force has zero work around every permitted closed path, yielding endpoint-only work. At a singular source, the integrals and endpoints must remain well defined. Wext = ΔU holds when the net kinetic-energy change is zero and no additional dissipative transfer is omitted; generally Wext = ΔK + ΔU for this mechanical system. The supplied chapter explicitly qualifies unchanged kinetic energy on C4. Near Earth's surface, take y upward and g nearly constant: Wg = −mg(yB−yA), ΔUg = mg(yB−yA). At larger radii, Wg = GMm(1/rB−1/rA) and Ug = −GMm/r + constant.
3. **Potential and reference** [P15, P18–23, P26; C4–7]. ΔV = −∫A^B E·ds, ΔU = qΔV. Units: E in N/C = V/m, V in J/C, U and work in J, gravitational potential in J/kg. A constant shift in V leaves E and all ΔV invariant; the matching energy reference shifts by q times that constant. For localized finite sources V(∞)=0 is available and V = kQ/r. This reference is not generally available for an infinite uniform field, infinite line, or infinite sheet. An eV is the positive energy unit 1.6×10⁻¹⁹ J, not a voltage or a signed electron charge.
4. **Uniform field and path geometry** [C5–6]. Constant E gives ΔV = −E·(rB−rA). With downward field magnitude E₀ and downward separation d, ΔV = −E₀d. For a slanted displacement of length s making angle θ to E, ΔV = −E₀s cos θ. C5 first uses upward j and E = −E₀j; its later figure explicitly defines downward y. Those coordinates must not be silently merged. Segment AC is parallel to the field, CB perpendicular: ΔVCA = −E₀y and ΔVBC = 0, giving the same result as the direct slant. A negative q reverses the sign of ΔU for the same prescribed motion.
5. **Superposition and assembly** [P34–36; C7–9]. V(r) = k Σi qi/|r−ri|. Quasistatic assembly from separated charges at infinity has U = k Σi<j qi qj/rij = (1/2) Σi qi Vothers(ri). Each distinct pair is counted once. Adding one charge qnew to fixed existing sources costs ΔU = qnew Vold(rnew), without a factor one-half. The first charge costs zero interaction energy in empty space. Opposite-sign assembly can require negative external work, meaning energy removal, not an impossible negative energy expenditure.
6. **Continuous distributions** [C9–10, C13–18]. V(P)=k∫dq/r with r the distance from each source element to P. For a thin line dq=λ dl, λ in C/m; for a thin surface dq=σ dA, σ in C/m². Integrate source coordinates while holding the observation point fixed. The continuum limit follows scalar summation and a single-variable integral for the symmetric examples. Finite-source V(∞)=0 and ideal prescribed nonconducting uniform densities are essential. Surface/line density is not a claim that a free conductor has that distribution.
7. **Potential to field** [P29–32; C10–12, C18]. At fixed y,z, Ex = −∂V/∂x; similarly Ey and Ez. The partial derivative is an ordinary derivative of the one-variable slice with the other coordinates treated as constants. E = −∇V with ∇V = (∂xV, ∂yV, ∂zV). In spherical symmetry E = −(dV/dr)r̂. Differentiation of kQ/r returns kQ/r² outward times the signed Q. The scalar V can vanish while E is nonzero; E can vanish at nonzero V.
8. **Equipotentials and directional change** [C11–13; PRS11–12; P21, P23, P28]. Along a level curve/surface, dV = 0 = −E·ds, so the nonzero field is perpendicular to its tangent space. Along unit direction u, the local rate of V change is ∇V·u = |∇V|cos θ. Its maximum is |∇V| toward ∇V and minimum is −|∇V| along E. Field lines point down the potential surface, but a particle's trajectory need not follow field lines. On an equipotential electrostatic work is zero; a constraint can still exert a force, and an external agent can do other work if speed or dissipative energy changes. At E=0 there is no unique field direction. Concentric spheres represent a point-charge potential, planes a uniform-field potential. The drawn landscape height is V, not a physical extra spatial coordinate or automatically U for a negative charge.

## Independent derivations and all calculable source prompts

### D01 — radial gravity, the sign question, and the uniform-gravity derivation

For any smooth permitted path let dr = r̂·ds. Then ∫(−GMm/r²)r̂·ds = −GMm∫rA^rB r⁻² dr = GMm(1/rB−1/rA). P12 depicts B farther from Earth's centre than A, so this is negative. Reversing endpoints makes it positive; a closed return gives zero. For constant downward gravity, ds = dx i + dy j gives Fg·ds = −mg dy; hence horizontal wandering changes no gravitational work and an upward endpoint change increases Ug. Dividing by m gives ΔVg. Expanding −GMm/(RE+h) to first order in h/RE gives a constant plus (GMm/RE²)h, independently reconciling the two formulas.

### D02 — constant electric field and point-source potential

The direct diagonal and broken AC/CB paths both give −E₀y. For point Q, −∫kQ r⁻² dr = kQ(1/rB−1/rA). Letting rA→∞ gives kQ/rB. A circular segment at fixed r contributes zero because r̂·ds=0. For positive Q, increasing radius decreases V; for negative Q it increases V toward zero. The force on a positive/negative test charge must then be assessed with qE, not with the source sign alone.

### D03 — PRS question 1, Masses in Potentials [PRS1–2; P16]

Independent result: option **3**, only C, assuming free masses and a nonzero linear slope. For Vg=A, g=−dA/dx=0 whether A is zero or nonzero. For Vg=sx, g=−s is nonzero even at x=0 where Vg=0. The three equal masses have F=mg and acceleration g; equal masses are unnecessary to the conclusion. A potential constant only along one horizontal path does not imply gravity vanishes in other directions: the prompt must mean constant in the accessible configuration space. The height analogy in the solution should be read with this distinction.

### D04 — PRS question 2, Positive Charge [PRS3–4; P24]

Independent intended result: option **2**, lower V and lower U, for release from rest under electric force alone near a nonzero field. Set small dt>0. The initial displacement is ds ≈ (qE/2m)dt², so ΔV ≈ −q|E|²dt²/(2m)<0 for q>0, and ΔU ≈ −q²|E|²dt²/(2m)<0. This establishes the initial tendency from the permitted Newton law, rather than treating lower energy as a universal velocity rule.

### D05 — PRS question 3, Negative Charge [PRS5–6; P24]

Independent intended result: option **4**. The same small-time formula gives ΔV>0 for q<0 but ΔU<0. A freely moving charge with pre-existing velocity can temporarily climb U; an external agent can move it either way. The printed blanket statement that objects always move to reduce potential energy is therefore overbroad, even though the intended release-from-rest choices are correct.

### D06 — PRS question 4, Potential and Energy [PRS7–8; P24]

Independent result: option **4**, I and II, under the source's electrostatic/quasistatic work convention. I: q1q2>0 and rf<ri imply ΔU=kq1q2(1/rf−1/ri)>0, so positive Wext is required at equal initial/final K. Field work is negative. II: along a nonzero field-line tangent ds, dV=−|E|ds<0. III: with q<0 and dV<0, dU=q dV>0, so it is false. Neither sign of charge nor direction of initial velocity was erased in making these statements.

### D07 — PRS question 5, Two Point Charges [PRS9–10; P27]

Independent result: option **3**, zero. In the figure +q is left, −q right, and P their midpoint. Equal distances d give V(P)=kq/d−kq/d=0=V(∞), so ΔU=qtestΔV=0 and quasi-static Wext=0. The curved approach path need not lie on an equipotential. The field at P is not zero: each charge contributes toward the negative source, giving E(P)=2kq/d² to the right. If "work" were intended to include a nonzero change of K, additional mechanical information would be needed; the printed solution makes the potential-work convention clear.

### D08 — PRS question 6, Potential Landscape [PRS11–12; P27]

Independent result: option **2**, steepest local descent. For unit u, dV/ds=∇V·u; the smallest possible value is −|∇V| at u=−∇V/|∇V|. At a stationary point there is no unique descent direction supplied by first derivatives. The analogy concerns the direction of E, not every moving charge's trajectory.

### D09 — presentation graph problem [P32]

Full-resolution figure reading: the left straight segment passes through (−2 m,−10 V), (−1 m,0 V), and (0 m,10 V). The right straight segment passes through (0 m,10 V) and (2 m,5 V). Thus on the displayed open intervals:

Vleft=10 V+(10 V/m)x; Vright=10 V−(2.5 V/m)x.

The plotted field component is **Ex=−10 V/m for x<0**, **Ex=+2.5 V/m for x>0**. At x=0 the ideal V has a corner, so the ordinary derivative is not defined. The field plot has two horizontal branches and a jump; no justified point value is supplied at the corner. The visible cropped extent does not justify extending either branch indefinitely.

Bonus: under a genuinely one-dimensional, plane-symmetric idealization a positive charged sheet at x=0 plus a uniform background field is consistent. This can be deduced using the assigned disk's infinite-sheet limit, without importing Gauss's law: let sheet magnitude S act away from x=0 and let background B point along x. Then B−S=−10, B+S=2.5 V/m, so S=6.25 V/m and B=−3.75 V/m. Since S=σ/(2ε₀), σ=12.5ε₀ V/m>0 (about 1.11×10⁻¹⁰ C/m² using the baseline ε₀). The source only asks whether/where charge is present and gives no plane-symmetry or transverse-potential information. A one-dimensional trace alone does not specify a unique three-dimensional source distribution, nor total vector E, so the sheet is a qualified model, not an unqualified reconstruction. No unassigned Gauss/Poisson formalism is assumed.

### D10 — two- and three-charge assembly [P34–35; C8–9]

Start with no pair interactions. Place q1, then q2: W2=q2(kq1/r12). Place q3 in the potential of the first two: W3=kq3(q1/r13+q2/r23). Adding gives U=k(q1q2/r12+q1q3/r13+q2q3/r23). Any placement order lists the same three pairs, establishing order independence. For N charges, the ordered double sum lists each physical pair twice and excludes i=j, so the factor one-half is necessary only for that counting convention. No divergent self term is used.

### D11 — presentation three-charge problem [P36]

Image transcription: q1=−Q at (−a,0), q2=−Q at (0,0), q3=+Q at (a,0), P=(0,a), with a>0 and Q>0. The two outer-to-P distances are √2 a; the middle-to-P distance is a. Therefore

V(P)=k[−Q/(√2a)−Q/a+Q/(√2a)] = **−kQ/a volts** when Q and a are in SI.

The three pair distances are a, a, 2a, so U123=k[Q²/a−Q²/a−Q²/(2a)] = **−kQ²/(2a) joules**. Bringing q4=+3Q from infinity to P with all existing charges held fixed gives Wext,4=3Q V(P)=**−3kQ²/a joules**. The final four-charge energy is −7kQ²/(2a). Negative external work means the agent extracts energy while the electric field does positive work; no numeric Q or a is supplied. The printed word "change" in the fourth-charge prompt is a typo for charge. None of these results uses the potential of the newly placed charge at its own position.

### D12 — Example 3.1, uniformly charged finite rod [C13–15]

The figure has a thin nonconducting rod on x from −ℓ/2 to +ℓ/2, total Q=λℓ, field point P=(0,y) above its midpoint, and source coordinate x′. Take y>0 initially and V(∞)=0. Distance r=√(x′²+y²) and dq=λ dx′ give

V(y)=kλ∫−ℓ/2^ℓ/2 dx′/√(x′²+y²)
=kλ ln[(√((ℓ/2)²+y²)+ℓ/2)/(√((ℓ/2)²+y²)−ℓ/2)]
=2kλ asinh(ℓ/(2y)).

The log argument is dimensionless. The indefinite log primitive can be checked by differentiation or derived with x′=y sinh u using the explicitly supplied Further Mathematics rules. Symmetry makes Ex=0 on the midpoint axis. Differentiating the exact expression gives Ey=kλℓ/[y√(y²+(ℓ/2)²)]. For y<0 use V=2kλ asinh(ℓ/(2|y|)); Ey retains the displayed signed-y expression and points away for λ>0. At y=0 the thin-line model is singular.

For 0<|y|≪ℓ, V≈2kλ ln(ℓ/|y|); keeping the leading nonzero denominator term in √(1+(2y/ℓ)²) is essential to obtain the logarithm. The approximate field is 2kλ/y. The source's displayed exact Ey immediately following the approximate V is obtained from the exact V, not by differentiating the approximation. For |y|≫ℓ, V≈kλℓ/|y|=kQ/|y|, Ey≈kQ sign(y)/y². Taking ℓ→∞ with λ fixed sends V relative to infinity to infinity, while potential differences and local field can remain finite. The graph is even in y/ℓ, diverges as y→0 and decays toward zero; its normalization is V₀=kλ, not the disk's V₀.

### D13 — Example 3.2, uniformly charged ring [C15–16]

The full figure puts a thin ring of radius R in the xy plane, P=(0,0,z) on its axis, and azimuth φ′ at a source element. The wording "distance z from the central axis" must mean along that axis from the centre/plane; it is not an off-axis radial displacement. dq=λR dφ′, 0≤φ′<2π; all source distances are √(R²+z²). Thus Q=2πRλ and V=kQ/√(R²+z²). Opposite elements cancel transverse field components, and Ez=−dV/dz=kQz/(R²+z²)^(3/2). It is zero at z=0 while V=kQ/R is nonzero. V is even, Ez odd, and for |z|≫R, V≈kQ/|z| and Ez≈kQ sign(z)/z². The source's kQ/z limit is for z>0 as drawn.

### D14 — Example 3.3, uniformly charged disk [C16–18]

The prescribed thin nonconducting disk has radius R in the xy plane, uniform σ, and P=(0,0,z). Divide the disk into source rings of radius r′ and width dr′: dq=σ(2πr′dr′). Holding z fixed,

V(z)=2πkσ∫0^R r′dr′/√(r′²+z²)
=σ/(2ε₀)[√(R²+z²)−|z|].

The |z| at the lower limit cannot be replaced by z below the plane. Total Q=πR²σ. Expanding for |z|≫R leaves V≈kQ/|z|; cancellation of the leading |z| terms makes the next expansion term essential. At z=0, Vc=σR/(2ε₀)=2kQ/R=2V₀, finite. Off the charged plane,

Ez=σ/(2ε₀)[sign(z)−z/√(R²+z²)].

Transverse components vanish by symmetry on the axis. For R≫|z| with z≠0, Ez≈σ sign(z)/(2ε₀), the infinite-sheet result on the correct side. At z=0 the ideal field is discontinuous and V has a cusp; the displayed derivative formula has no ordinary value there. In the R→∞ limit V(∞)=0 cannot remain a finite absolute reference. The normalized disk graph V/V₀=2[√(1+(z/R)²)−|z/R|] has peak 2 and stays below the positive point-charge comparison 1/|z/R| for nonzero z, approaching it at large |z|. Its evenness and finite centre match the rendered figure.

### D15 — Example 3.4, Cartesian polynomial potential [C18]

The actual displayed potential is V=Ax²y²+Bxyz. Holding the other variables fixed in each derivative yields Ex=−2Axy²−Byz, Ey=−2Ax²y−Bxz, Ez=−Bxy. Thus E=(−2Axy²−Byz)i+(−2Ax²y−Bxz)j−Bxy k. If x,y,z are metres, A has units V/m⁴ and B V/m³, ensuring all components are V/m. The prose also names C, although no C appears in the formula: it is unused. Adding a constant C would change none of these derivatives, but must not be silently inserted as original content. A reverse integral along a general straight segment reconstructs −ΔV, independently checking all three signs.

## Source ambiguities and corrections to preserve

These are source qualifications established from both full-page images and independent reasoning, not differences invented from text extraction.

| Location | Observed issue | Technical treatment |
|---|---|---|
| C10 Eq. 3.5.2 | Both the expanded dot product and component sum are printed without the minus sign in dV. | Correct to dV=−(Ex dx+Ey dy+Ez dz), consistent with preceding Eq. 3.5.1 and following Eq. 3.5.3. |
| P30 prose | Calls Ex the rate of change of V, omitting "negative"; boxed formula has the correct minus sign. | Ex is the negative rate with y,z fixed. |
| C3; P14, P19 | External work equals ΔU stated compactly. | Require equal endpoint K (or quasistatic motion) and appropriate transfer accounting; C4 supplies this condition. |
| PRS4, PRS6 | "Always move" toward reduced U. | Correct as initial acceleration tendency under conservative force; pre-existing velocity or external forcing can increase U. |
| PRS2 | Constant-height analogy can imply absence of all gravity. | Constant V throughout accessible coordinates gives zero field; constant V only along a level curve gives no tangential component. |
| C7 comparison table | A-to-B integrals labelled V rather than ΔV; magnitude line uses qEd. | Use potential difference unless a reference is specified. For an arbitrary signed q and displacement use |q E·Δr|; qEd assumes a charge magnitude and field-parallel displacement. |
| P9, P18 | Same q is used for source charge and test charge in separate schematic roles. | Distinguish Qsource from qtest in any derivation. |
| P12, P26 | θ appears as local path/radial angle in the drawing and as polar coordinate in r dθ θ̂. | Use a separate local angle ψ for r̂·ds=ds cos ψ=dr; do not identify it with the global polar angle. |
| C15 after Eq. 3.5.11 | Exact rod field follows approximate long-rod potential. | Differentiate exact Eq. 3.5.10 for exact Ey; differentiate approximation for its leading limit. |
| C15–16 ring/disk statements | "Distance from central axis" wording conflicts with axial P in figures and solutions. | Interpret as distance along z axis from plane/centre. No off-axis solution is supplied. |
| C18 sheet limit | Positive-side Ez printed without side qualification. | General result carries sign(z), z≠0. |
| C18 Example 3.4 | Prose lists A,B,C but expression uses only A,B. | C unused; optional additive constant would have no field effect. |
| P32 bonus | Source geometry is not specified from the one-dimensional plot. | Give Ex and a qualified positive-sheet/background construction; avoid a unique 3D reconstruction. |
| C16–17 figure numbers | Disk figures are labelled 3.4.3 and 3.4.4 despite placement in section 3.5. | Preserve exact source labels in references and use PDF page to disambiguate. |
| C8 | "Without acceleration" is equated to "at rest at the end." | The latter alone only supports equal endpoint K if initially at rest; quasistatic placement is a stronger, sufficient idealization. |

## Calculation verification

`calculation-checks.py` is a reproducible local check using exact rational comparisons, Coulomb-kernel quadrature independent of the closed-form potential derivatives, explicit endpoint path integrals, pair enumeration over all assembly orders, and five-point finite differences. It uses the Python standard library only. Test numbers are declared check fixtures, not new source data or replacement exercises. `calculation-results.json` records 80 individual passing comparisons, methods, and tolerances. This supplements, rather than replaces, the complete exact derivations above and original figure reading. An initial symbolic-check implementation could not run because the local environments lack SymPy and mpmath; it was replaced by the independent standard-library checks without network access. No unavailable symbolic run is claimed.

## Completeness limit

All six PRS questions (and their six answer pages), both presentation in-class problems including the graph bonus and all three charge-configuration subquestions, all four numbered chapter examples with stated field/limit continuations, and the unnumbered gravitational/uniform/point-potential derivations have been independently resolved. Group discussion and missing experiment-write-up references are explicitly identified. No claims are made about exercises in unassigned sections 3.6 onward. The whole baseline is accounted for separately in `baseline-use-map.md`; `coverage.json` preserves every required page's content/figure reading and calculation links. This dossier remains isolated from any future author until whole-freeze authorization.
