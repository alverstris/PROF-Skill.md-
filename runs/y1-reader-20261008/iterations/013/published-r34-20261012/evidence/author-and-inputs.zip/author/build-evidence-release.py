from pathlib import Path
import json,hashlib,zipfile,io,shutil
W=Path(__file__).resolve().parents[1]; shared=W.parent; out=W/'release'; out.mkdir(exist_ok=True)
PREFIX='runs/y1-reader-20261008/iterations/013/published-r34-20261012/'
h=lambda b:hashlib.sha256(b).hexdigest(); blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
entries=[];archives=[]
def register(p,remote):
 b=p.read_bytes();entries.append({'local':str(p.resolve()),'path':remote,'bytes':len(b),'sha256':h(b),'git_blob':blob(b)})
def archive(name,groups):
 target=out/(name+'.zip'); members=[]
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  seen=set()
  for local,remote in groups:
   fs=sorted(local.rglob('*')) if local.is_dir() else [local]
   for f in fs:
    if not f.is_file():continue
    assert not f.is_symlink()
    dest=(Path(remote)/f.relative_to(local)).as_posix() if local.is_dir() else remote
    assert dest not in seen;seen.add(dest);b=f.read_bytes();z.writestr(dest,b);members.append({'path':dest,'bytes':len(b),'sha256':h(b)})
 b=target.read_bytes()
 with zipfile.ZipFile(io.BytesIO(b)) as z:
  assert z.testzip() is None
  for r in members:
   data=z.read(r['path']);assert len(data)==r['bytes'] and h(data)==r['sha256']
 manifest={'archive':target.name,'archive_bytes':len(b),'archive_sha256':h(b),'member_count':len(members),'members':members}
 mp=out/(name+'-members.json');mp.write_text(json.dumps(manifest,indent=2)+'\n');register(mp,PREFIX+'evidence/'+mp.name)
 if len(b)>7000000:
  parts=[]
  for i,off in enumerate(range(0,len(b),7000000),1):
   p=out/(name+f'.part-{i:03d}.bin');p.write_bytes(b[off:off+7000000]);register(p,PREFIX+'evidence/'+p.name);parts.append({'ordinal':i,'filename':p.name,'offset':off,'bytes':p.stat().st_size,'sha256':h(p.read_bytes())})
  rp=out/(name+'-reassembly.json');rp.write_text(json.dumps({'archive_filename':target.name,'archive_bytes':len(b),'archive_sha256':h(b),'reassembly':'Concatenate raw part files in ascending ordinal; verify original byte length and SHA256 before opening ZIP.','parts':parts},indent=2)+'\n');register(rp,PREFIX+'evidence/'+rp.name)
 else:register(target,PREFIX+'evidence/'+target.name)
 archives.append({'name':name,'archive_bytes':len(b),'archive_sha256':h(b),'member_count':len(members)})
# State and read records are snapshotted only after all final audit gates.
base_files=['request.txt','input-identities.json','package-admission.json','internal-profile-hashes.json','internal-hash-verification.json','author-baseline-route.json','author-read-log.jsonl','freeze-manifest.json','teaching-publication.json','teaching-readback.json','teaching-tree-metadata-correction.json','reader-admission-before-report-seal.json','reader-admission.json','reader-original-view-results-verification.json','metadata-only-verification.json','release-package-manifest.json']
author_groups=[(W/p,p) for p in base_files]+[(W/'author','author'),(W/'review','review'),(W/'.prof-state','prof-state'),(W/'inputs/source','original-source'),(W/'inputs/student-baseline.txt','student-baseline.txt'),(W/'teaching','frozen-teaching'),(W/'checkpoint','checkpoint')]
archive('author-and-inputs',author_groups)
archive('reader-complete',[(W/'reader-r34','reader'),(W/'reader-runner','launcher-preflight')])
archive('technical-complete',[(shared/'d013-r34-fresh-independent-technical','independent-technical')])
config=json.loads((W/'root-evidence-locations.json').read_bytes());archive('root-complete',[(shared/r['local'],r['archive']) for r in config])
package=json.loads((W/'release-package-manifest.json').read_bytes())
for r in package['files']:register(W/'release-prof'/r['path'],r['path'])
for p in sorted((W/'review').iterdir()):
 if p.is_file():register(p,PREFIX+'closure-review/'+p.name)
for p in ['reader-admission.json','reader-original-view-results-verification.json','metadata-only-verification.json','release-package-manifest.json']:
 register(W/p,PREFIX+'closure-review/'+p)
entries.extend(json.loads((W/'opaque-future-publication-inputs.json').read_bytes()))
assert len({e['path'] for e in entries})==len(entries)
(out/'publication-inputs.json').write_text(json.dumps(entries,indent=2)+'\n');(out/'archive-summary.json').write_text(json.dumps(archives,indent=2)+'\n')
print(json.dumps({'paths':len(entries),'bytes':sum(e['bytes'] for e in entries),'archives':archives},indent=2))
