from pathlib import Path
import hashlib,json,shutil,re
w=Path(__file__).parent.parent;d=w/'reader-r34';d.mkdir(exist_ok=True);(d/'view-results').mkdir(exist_ok=True);shutil.copy2(w/'reader-runner/read-step',d/'read-step');(d/'read-step').chmod(0o755);shutil.copy2(w/'verified-prof/references/sasis/student-role.txt',d/'student-role.txt')
h=lambda b:hashlib.sha256(b).hexdigest();files=[];steps=[];rev=[]
def addfile(fid,p,kind,art):
 b=p.read_bytes();files.append({'id':fid,'artifact':art,'kind':kind,'path':str(p),'size':len(b),'sha256':h(b)});return b
b=addfile('baseline',w/'inputs/student-baseline.txt','text','baseline')
for i,r in enumerate(json.loads((w/'author-baseline-route.json').read_text()),1):
 sid=f'B{i:03}';steps.append({'id':sid,'kind':'text','file_id':'baseline','start':r['start'],'end':r['end'],'sha256':r['sha256']});rev.append({'id':'R'+sid,'initial_step_id':sid})
figs={'mvt-square.png':'F001','cusp.png':'F002','linear-approximation.png':'F003'}
for name,fid in figs.items():addfile(fid,w/'teaching/figures'/name,'image','teaching')
idx=0;route_notes=[]
for name in ['main.md','hints.md','solutions.md']:
 fid=name[:-3];b=addfile(fid,w/'teaching'/name,'text','teaching');bound={0,len(b)};fig_after={}
 for m in re.finditer(rb'<img src="figures/([^"]+)"[^\n]*\n',b):bound.add(m.end());fig_after[m.end()]=m.group(1).decode()
 for m in re.finditer(rb'<a id="[^\n]+\n',b):bound.add(m.start())
 for m in re.finditer(rb'\[(?:Hint|Return to) Q\d\][^\n]+\n(?:\n)?',b):bound.add(m.end())
 # Add bounded paragraph boundaries, never splitting a mathematical block.
 positions=sorted(bound);expanded=[0]
 for end in positions[1:]:
  start=expanded[-1]
  while end-start>6000:
   cut=b.rfind(b'\n\n',start+1000,min(start+5800,end))+2
   assert cut>start and b[start:cut].count(b'```')%2==0
   expanded.append(cut);start=cut
  expanded.append(end)
 for start,end in zip(expanded,expanded[1:]):
  if end==start:continue
  idx+=1;sid=f'T{idx:03}';bb=b[start:end];bb.decode('utf-8');steps.append({'id':sid,'kind':'text','file_id':fid,'start':start,'end':end,'sha256':h(bb)})
  route_notes.append({'step':sid,'file':name,'start':start,'end':end,'begins':bb.decode().splitlines()[0][:100],'ends':bb.decode().splitlines()[-1][:100]})
  if end in fig_after:
   fname=fig_after[end];ffid=figs[fname];im=next(x for x in files if x['id']==ffid)
   steps.append({'id':ffid,'kind':'figure','file_id':ffid,'sha256':im['sha256'],'receipt_step_id':'V'+ffid[1:],'receipt_file':str(d/'view-results'/f'{ffid}.json'),'first_use':{'text_step_id':sid,'position':'after'}})
route={'schema':'sasis-fixed-route-v1','route_id':'D013-r34-reader-01','artifacts':{'baseline':{'id':'OCR-A-4-subjects-r1','revision':'3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'},'teaching':{'id':'D013-r34','revision':'ce407f3f2a5276700e61f43d7d1c371b9f452121'}},'files':files,'steps':steps,'revisits':rev}
(d/'route.json').write_text(json.dumps(route,indent=2)+'\n');seal={'schema':'sasis-route-seal-v1','route_id':route['route_id'],'route_sha256':h((d/'route.json').read_bytes()),'launcher_sha256':h((d/'read-step').read_bytes())};(d/'route-seal.json').write_text(json.dumps(seal,indent=2)+'\n');(w/'author/reader-route-boundaries.json').write_text(json.dumps(route_notes,indent=2)+'\n')
print(json.dumps(seal));print('Steps:',','.join(x['id']+('/'+x['receipt_step_id'] if x['kind']=='figure' else '') for x in steps));print(json.dumps(route_notes,indent=2))
