from pathlib import Path
import json,hashlib,base64,collections
W=Path(__file__).resolve().parents[1]; R=W/'reader-r34'
h=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda o:json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
route=json.loads((R/'route.json').read_bytes()); seal=json.loads((R/'route-seal.json').read_bytes())
assert h((R/'route.json').read_bytes())==seal['route_sha256']
assert h((R/'read-step').read_bytes())==seal['launcher_sha256']
files={f['id']:f for f in route['files']}; steps={s['id']:s for s in route['steps']}; expected=[]
for s in route['steps']:
 expected.append(s['id'])
 if s['kind']=='figure':expected.append(s['receipt_step_id'])
for f in files.values():
 b=Path(f['path']).read_bytes(); assert len(b)==f['size'] and h(b)==f['sha256']
for fid,f in files.items():
 subset=[s for s in route['steps'] if s['file_id']==fid]; cursor=0; joined=b''
 for s in subset:
  a,z=(s['start'],s['end']) if s['kind']=='text' else (0,f['size'])
  assert a==cursor; b=Path(f['path']).read_bytes()[a:z]; assert h(b)==s['sha256']; joined+=b;cursor=z
 assert cursor==f['size'] and h(joined)==f['sha256']
events=[json.loads(x) for x in (R/'runtime/ledger.jsonl').read_bytes().splitlines()]; prev='0'*64;calls=collections.OrderedDict()
for i,e in enumerate(events):
 saved=e['sha256']; cp={k:v for k,v in e.items() if k!='sha256'}
 assert e['index']==i and e['previous']==prev and h(canon(cp))==saved
 prev=saved; calls.setdefault(e['call_id'],[]).append(e)
commits=[]; rejected=[]; actual=[]; images=[]
for cid,ev in calls.items():
 assert ev[0]['event']=='call_attempt' and ev[-1]['event']=='call_finished'
 sid=ev[0]['data']['argv'][0]; assert len(ev[0]['data']['argv'])==1
 c=[e for e in ev if e['event']=='state_commit']; accesses=[e for e in ev if e['event']=='actual_access']; outs=[e for e in ev if e['event']=='stdout_complete']
 if ev[-1]['data']['outcome']=='rejected':
  assert not c and not accesses and not outs and not any(e['event'] in ('subject_open_attempt','subject_read','stdout_begin','figure_receipt_accepted') for e in ev)
  rejected.append({'call_id':cid,'step_id':sid,'reason':ev[-1]['data']['reason'],'subject_open_or_read':False,'subject_output':False});continue
 assert len(c)==1 and c[0]['data']['step_id']==sid and len(outs)==1
 op=c[0]['data']['operation']; assert c[0]['data']['route_sha256']==seal['route_sha256']
 assert op!='revisit', 'Handle actual revisit explicitly if it occurred'
 commits.append(sid)
 if op=='figure_received':
  assert not accesses
  ac=[e for e in ev if e['event']=='figure_receipt_accepted'];assert len(ac)==1
  receipt=ac[0]['data']['receipt']; ss=steps[receipt['figure_step_id']]; f=files[ss['file_id']]; b=Path(f['path']).read_bytes()
  assert sid==ss['receipt_step_id'] and receipt['image_path']==f['path'] and receipt['image_sha256']==f['sha256']
  assert receipt['invocation']=={'path':f['path'],'detail':'original'}
  m=receipt['result_metadata']; url='data:'+m['mime_type']+';base64,'+base64.b64encode(b).decode()
  assert m['success'] is True and m['detail']=='original' and m['kind']=='image'
  assert len(url)==m['image_url_chars'] and h(url.encode())==m['image_url_sha256']
  assert h(Path(ss['receipt_file']).read_bytes())==ac[0]['data']['receipt_sha256']
  images.append({'figure_step_id':ss['id'],'receipt_step_id':sid,'receipt_sha256':ac[0]['data']['receipt_sha256'],'tool_call_label':receipt['tool_call_id'],'tool_result_full_image_identity_matches':True})
 else:
  s=steps[sid];f=files[s['file_id']]; assert len(accesses)==1; a=accesses[0];d=a['data'];start,end=(s['start'],s['end']) if s['kind']=='text' else (0,f['size'])
  assert d['file_id']==f['id'] and d['path']==f['path'] and d['start']==start and d['end']==end and d['bytes']==end-start and d['verified'] is True and d['sha256']==s['sha256']
  assert a['index']<next(e for e in ev if e['event']=='stdout_begin')['index']<outs[0]['index']<c[0]['index']
  if s['kind']=='text': assert outs[0]['data']['bytes']==end-start and outs[0]['data']['sha256']==s['sha256']
  actual.append({'step_id':sid,'file_id':f['id'],'start':start,'end':end,'sha256':s['sha256'],'access_before_output':True})
assert commits==expected,(commits,expected)
assert len(images)==3
assert len(rejected)==1 and rejected[0]['step_id']=='V001' and rejected[0]['reason']=='view receipt: incorrect object fields'
original=json.loads((R/'reports/F001-original-rejected-receipt.json').read_bytes()); corrected=json.loads((R/'view-results/F001.json').read_bytes());extra=set(original)-set(corrected)
assert extra=={'tool_call_id_kind'}
assert {k:v for k,v in original.items() if k in corrected}==corrected
out={'schema':'d013-r34-reader-ledger-admission-v1','route_sha256':seal['route_sha256'],'launcher_sha256':seal['launcher_sha256'],'ledger_sha256':h((R/'runtime/ledger.jsonl').read_bytes()),'event_count':len(events),'call_count':len(calls),'ordered_successful_steps':commits,'exact_route_complete':True,'baseline_bytes':247840,'teaching_text_bytes':29582,'figure_count':3,'actual_accesses':actual,'figure_receipts':images,'safe_rejections':rejected,'recovery_scope':'Removed one extra operational receipt field only; preserved original; no later or unauthorized subject access before retry.','limits':'Independent ledger/full-byte comparison validates instrumented access and the preserved tool-result identities. Actual displays and semantic inspection additionally require original reader tool/witness records. Shared tools were instruction-whitelisted, not technically confined; no erased pretraining or human learning claim.'}
(W/'reader-admission.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('actual_accesses','ordered_successful_steps')},indent=2))
