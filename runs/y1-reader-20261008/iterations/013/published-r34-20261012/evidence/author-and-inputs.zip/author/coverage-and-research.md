D013 scope, prerequisites and conventions

Product: standalone GitHub-native Markdown main/hints/solutions and exact local PNG figures. User no bold/italic prose and no PDF overrides default PDF. No exclusions from original five-page PDF. All practice/help is authored here, not assigned exam provenance.

Coverage IDs:
C01 source physicalp2 theorem: connect finite secant and interior derivative; prerequisites baseline derivative/line/interval notation, new recognisable continuity and differentiability conditions; main opening, worked square, Q1.
C02 sourcep2 figure1 and sliding parallel-line proof: explicitly supplied EVT plus derivative-limit sign deduction, subtract chord h; own fig1 maps same geometry.
C03 sourcep2–3 nondifferentiable cusp/figure2: |t| on[-1,2], derivative ±1 vs chord1/3, support line slope within(-1,1); ownfig2. Endpoint continuity tested Q2.
C04 sourcep3 travel: specified1000mile/3hour idealised differentiable forward route coordinate, derivative speed, actualhypotheses.
C05 sourcep3–4 alternate forms/figure3: endpoint renamedx, c depends on f,a,x, exact versus tangent approximation; ownfig3, signed error, Q3.
C06 sourcep4 monotonicity/constants: arbitrary endpoints in one interval; source decreasing typo corrected; positive/zero proofs, decreasing workedcase and Q4 proof/changed disconnected condition.
C07 sourcep5 inequalities: positivity premise, anchored differences r1,r2,r3,r4, allstrictx>0 and equality0; Q5fourth term; distinguish finite bounds from infinite-series convergence.
C08 sourcep5 Taylor preview: series notation/factorials baselineFM27, note equality is separate fact not justified by finite lowerbounds; no new generalremainderclaim.
C09 new transfer: Q6 two-sided logarithm bounds and negative-input upperbound, integrates methodchoice/sign/domain/anchor, separately grouped hints/solutions.

Read full source and baseline evidence in input-reading.md and accessjson. No source convention uncertainty: real functions, differentiable onopeninterval and continuous onclosedinterval; course strict increasing/decreasing, not nondecreasing terminology. Corrections are mathematical, not a request for learner to decide truth.

Research read2026-10-12:
Official MIT18.100A Fall2020 Lecture19 PDF https://ocw.mit.edu/courses/18-100a-real-analysis-fall-2020/mit18_100af20_lec192.pdf actual extracted lines126–205, theorems4,5,7,9; derivative-at-interior-extremum via signs, continuous closedinterval extrema/Rolle, subtract-linear MVT. Supplemental corroboration, not another assigned lecture. Apparent typesetting errors in unrelated chain-rule portion are not imported. Mathematical deductions rechecked locally.
MIT18.01 chapter10.1 https://math.mit.edu/~djk/18_01/chapter10/section01.html lines5–32: theorem conditions/geometricmeaning and consequences.
OpenStax CalculusVolume1 §2.4 https://openstax.org/books/calculus-volume-1/pages/2-4-continuity lines49–65,120–128,189–199: three-condition pointdefinition, polynomial/rational continuity, endpoint one-sided conditions. Supplies new condition's meaning; no need for formal epsilon-delta theory.
OpenStax CalculusVolume1 §4.3 https://openstax.org/books/calculus-volume-1/pages/4-3-maxima-and-minima lines42–53: EVT continuous closed bounded interval attains extrema, no proofofEVT in scope. Introduce as explicit theorem not derive from mere definedness.
Search engine2 first located foundations; engine1 verified officialcontinuity source. No claims about current editions or humanlearning. Externaltheorem proof not copied; lesson gives its own checked reasoning.

Requirements applicability: T1–T12 all apply to this lesson. T5/8 study aim needs early supportedQ1, changed conditionQ2/Q4, approximationQ3 and changedfunction methodselectionQ6 plus optional later revisit of those existing questions. T6/7 everyQ1–Q6 has criterion, useful separatehint and complete solution. Actualdestination/browser verification pending until immutable publication. Helper checks presence/freshness only.
