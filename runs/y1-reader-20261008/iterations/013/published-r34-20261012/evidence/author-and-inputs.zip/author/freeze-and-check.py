from pathlib import Path
import json,re,hashlib,datetime
from PIL import Image
w=Path(__file__).parent.parent;t=w/'teaching';hashf=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[];expr=[];links=[];anchors=set()
for p in sorted(t.rglob('*')):
 if p.is_file():
  b=p.read_bytes();files.append({'path':str(p.relative_to(w)),'bytes':len(b),'sha256':hashf(p),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
for name in ['main.md','hints.md','solutions.md']:
 p=t/name;s=p.read_text();assert not re.search(r'^\s*#{1,6}\s',s,re.M);assert not re.search(r'\*\*|__|(?<!\*)\*[^*]+\*',s)
 for a in re.findall(r'<a id="([^"]+)"',s):assert a not in anchors;anchors.add(a)
 for m in re.finditer(r'\$`(.*?)`\$|```math\n(.*?)\n```',s,re.S):
  payload=m.group(1) if m.group(1) is not None else m.group(2);assert '<' not in payload and '>' not in payload;assert not re.search(r'\\(?:lt|gt)(?! )',payload)
  expr.append({'id':f'{name}:{len(expr)+1:03}','file':name,'line':s[:m.start()].count('\n')+1,'kind':'inline' if m.group(1) is not None else 'display','tex':payload})
 prose=re.sub(r'\$`.*?`\$|```math\n.*?\n```','',s,flags=re.S)
 for label,dest in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',prose):
  if not dest.startswith('https:'):
   fn,sep,an=dest.partition('#');target=t/fn;assert target.is_file(),dest
   if sep:assert f'id="{an}"' in target.read_text(),dest
   links.append({'source':name,'label':label,'target':dest})
for p in (t/'figures').glob('*.png'):
 im=Image.open(p);assert im.size==(960,564)
manifest={'material':'D013','revision':'r34-20261012','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'byte_total':sum(x['bytes'] for x in files),'baseline':{'path':'inputs/student-baseline.txt','bytes':247840,'sha256':hashf(w/'inputs/student-baseline.txt')},'prompt_only':{'path':'author/prompts-only.md','sha256':hashf(w/'author/prompts-only.md')},'immutable_after_freeze':True,'constituents':'All learner-facing main/hints/solutions, three completePNGfigures, no other teaching constituent'}
(w/'freeze-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(w/'author/expression-inventory.json').write_text(json.dumps(expr,indent=2)+'\n');(w/'author/navigation-inventory.json').write_text(json.dumps(links,indent=2)+'\n')
print(json.dumps({'manifest_sha256':hashf(w/'freeze-manifest.json'),'files':files,'expressions':len(expr),'links':len(links),'anchors':len(anchors)},indent=2))
