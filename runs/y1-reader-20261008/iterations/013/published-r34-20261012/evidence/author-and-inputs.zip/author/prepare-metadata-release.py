from pathlib import Path
import json,hashlib
W=Path(__file__).resolve().parents[1]; src=W/'verified-prof'; dst=W/'release-prof';dst.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
manifest=json.loads((W/'inputs/prof-package-manifest.json').read_bytes())
for r in manifest['files']:
 b=(src/r['path']).read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256'] and blob(b)==r['git_blob'];p=dst/r['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
changes={
'SKILL.md':[(b'version: "2026-10-12-r34"',b'version: "2026-10-12-r35"')],
'references/sasis.md':[(b'Protocol revision: 2026-10-12-r34.',b'Protocol revision: 2026-10-12-r35.')],
'references/sasis/student-testing-contract.txt':[(b'SASIS reader contract \xe2\x80\x94 revision 2026-10-12-r34',b'SASIS reader contract \xe2\x80\x94 revision 2026-10-12-r35')]
}
for name,reps in changes.items():
 b=(dst/name).read_bytes()
 for a,z in reps: assert b.count(a)==1;b=b.replace(a,z)
 (dst/name).write_bytes(b)
name='references/sasis/profile-manifest.json';old=(src/name).read_bytes();p=json.loads(old);oldhash=p['control_file_hashes']['student-testing-contract.txt'];newhash=h((dst/'references/sasis/student-testing-contract.txt').read_bytes()); reps=[(b'"protocol_revision": "2026-10-12-r34"',b'"protocol_revision": "2026-10-12-r35"'),(oldhash.encode(),newhash.encode())];changes[name]=reps
b=old
for a,z in reps:assert b.count(a)==1;b=b.replace(a,z)
(dst/name).write_bytes(b)
rows=[];diffs=[]
for r in manifest['files']:
 name=r['path'];a=(src/name).read_bytes();b=(dst/name).read_bytes();back=b
 for old,new in reversed(changes.get(name,[])): assert back.count(new)>=1;back=back.replace(new,old,1)
 assert back==a,(name,'non-metadata change')
 rows.append({'path':name,'bytes':len(b),'sha256':h(b),'git_blob':blob(b)})
 if a!=b:diffs.append({'path':name,'old_sha256':h(a),'new_sha256':h(b),'changes':[{'from':a.decode(),'to':z.decode()} for a,z in changes[name]],'inverse_metadata_replacement_restores_exact_original':True})
assert len(diffs)==4 and len(rows)==36
checks=[]
for d in json.loads((W/'internal-hash-verification.json').read_bytes())['verified_declarations']:
 new=dict(d);new['sha256']=h((dst/d['path']).read_bytes());checks.append(new)
prof=json.loads((dst/'references/sasis/profile-manifest.json').read_bytes())
for s in prof['subject_files']:assert s['sha256']==h((dst/'references/sasis'/s['path']).read_bytes())
for name,sha in prof['file_hashes'].items():assert sha==h((dst/'references/sasis'/prof['file_hashes_base_directory']/name).read_bytes())
for name,sha in prof['control_file_hashes'].items():assert sha==h((dst/'references/sasis'/name).read_bytes())
# Non-profile declarations are unchanged in both declaring and declared files.
for d in checks:
 if d['declaration']!='references/sasis/profile-manifest.json':
  assert (src/d['declaration']).read_bytes()==(dst/d['declaration']).read_bytes()
  assert (src/d['path']).read_bytes()==(dst/d['path']).read_bytes()
assert len(checks)==34
out={'status':'candidate_only_pending_whole_audit_disposition','incoming_version':'2026-10-12-r34','version':'2026-10-12-r35','count':36,'bytes':sum(x['bytes'] for x in rows),'files':rows}
(W/'release-package-manifest.json').write_text(json.dumps(out,indent=2)+'\n')
(W/'metadata-only-verification.json').write_text(json.dumps({'instruction_bodies_unchanged':True,'changed_files':diffs,'unchanged_files':32,'all34_internal_hash_declarations_verified':True,'internal_declarations':checks,'limits':'Rolling candidate metadata only; no behavioural repair and no acceptance or publication inferred.'},indent=2)+'\n')
print(json.dumps({'candidate_files':36,'bytes':out['bytes'],'metadata_files':list(changes),'internal_declarations':len(checks)},indent=2))
