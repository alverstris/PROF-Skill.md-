# Fixed SASIS retrieval launcher

`read-step` is the production executable. It uses only the Python standard library
and a Unix `fcntl` lock. Invoke it directly with exactly one route ID:

```text
/absolute/frozen/deployment/read-step B001
```

No interpreter, filename, offset, end position, environment override, or second
argument is accepted. `preflight.py` is an orchestrator-only test harness, not a
reader command. There is deliberately no production subject route in this
directory yet. All supplied subjects and routes under `synthetic-preflight*` are
synthetic non-subject fixtures.

## Freeze and adapt

1. Put an unchanged executable copy of `read-step` in a fresh deployment directory.
   Do not reuse a prior reader's deployment or ledger. Record its SHA-256 outside
   the deployment as well. The executable should have mode 0755.
2. Freeze the complete baseline and teaching constituents at exact absolute paths.
   Compute each constituent's full byte length and SHA-256. Do not use symlinks.
   Text is a binary byte stream: ranges are zero-based, half-open `[start,end)`.
3. Prepare `route.json` beside the executable, using the exact schema below.
   Every file must be completely covered exactly once by initial steps. Per-file
   text ranges must be contiguous, nonoverlapping and in file order. All baseline
   steps must precede every teaching step. The orchestrator must additionally
   verify the intended order across files, coherent text boundaries, UTF-8
   boundaries where relevant, prompts/help/endings, and the actual first use of
   every visual. Structure checks cannot infer these semantic boundaries.
4. Divide each text file into bounded coherent slices (maximum 1,048,576 bytes;
   choose substantially smaller slices to fit actual tool output limits). Compute
   the SHA-256 of exactly each range. The launcher reads only that range; it does
   not read unseen portions to recompute the full-file text hash. The orchestrator
   must verify full-file and per-range hashes when freezing.
5. End a text slice at each figure's first-use position, then schedule the whole
   figure immediately after that slice. Multiple figures may follow the same
   slice consecutively. A later text step may not intervene. An image is one whole
   immutable raster file, maximum 134,217,728 bytes. Never replace it with a crop,
   checksum, caption, or extracted text. `first_use.position` is exactly `after`:
   the preceding bounded text slice is the first-use locator.
6. Each figure declares a unique receipt ID and fixed absolute receipt pathname
   in `<deployment>/view-results/NAME.json`. That directory is outside both subject
   inputs. Precreate it. It must not contain subject material, other than the
   operational image identity and actual view-result metadata permitted below.
7. Predeclare any baseline revisit IDs. Each refers to one initial baseline text
   step; revisits cannot widen or join ranges. A revisit succeeds only after that
   initial chunk succeeded and never changes the route cursor, including while a
   figure is pending and after the document is complete.
8. Write `route-seal.json` using the exact raw-byte digest of the completed
   `route.json` and executable. Record both hashes, route identity, paths, fresh
   reader identity, permitted tools, and instruction-confined condition externally.
   Freeze these files for this reader. The seal is a local integrity assertion,
   not a cryptographic signature or technical access-control boundary.
9. Inspect the successful synthetic preflight evidence before reader dispatch.
   This version has passed 38 cases including an actual `tools.view_image` call.
   Changing launcher bytes requires a new synthetic preflight. Binding unchanged
   launcher bytes to a new frozen route requires full orchestrator route review.
10. Give the fresh reader the subject-free route metadata and exact direct command.
    Do not give it this development directory, test harness, previous outputs, raw
    sources, skill material, or other authors' evidence. A reader receipt save is
    an explicit operational-file exception to the read-only subject whitelist.

## Exact route schema

All objects reject unknown or missing keys and duplicate JSON keys. JSON booleans
are rejected where integers are required. IDs match
`[A-Za-z][A-Za-z0-9_.-]{0,79}`. SHA-256 values are 64 lowercase hex characters.
Absolute paths must be normalized and not contain NUL, `..`, or symlinks. All IDs
across initial steps, figure receipt stages and revisits must be distinct. File
IDs and file paths must be unique. The executable validates the entire route,
including all future metadata, before opening any subject file.

```json
{
  "schema": "sasis-fixed-route-v1",
  "route_id": "reader-condition-revision",
  "artifacts": {
    "baseline": {"id": "frozen-baseline-id", "revision": "frozen-revision"},
    "teaching": {"id": "frozen-teaching-id", "revision": "frozen-revision"}
  },
  "files": [
    {
      "id": "baseline",
      "artifact": "baseline",
      "kind": "text",
      "path": "/absolute/baseline.txt",
      "size": 100,
      "sha256": "FULL_FILE_SHA256"
    },
    {
      "id": "teaching",
      "artifact": "teaching",
      "kind": "text",
      "path": "/absolute/teaching.txt",
      "size": 200,
      "sha256": "FULL_FILE_SHA256"
    },
    {
      "id": "figure1",
      "artifact": "teaching",
      "kind": "image",
      "path": "/absolute/figure1.png",
      "size": 300,
      "sha256": "FULL_IMAGE_SHA256"
    }
  ],
  "steps": [
    {"id": "B001", "kind": "text", "file_id": "baseline", "start": 0, "end": 100, "sha256": "EXACT_RANGE_SHA256"},
    {"id": "T001", "kind": "text", "file_id": "teaching", "start": 0, "end": 80, "sha256": "EXACT_RANGE_SHA256"},
    {
      "id": "F001", "kind": "figure", "file_id": "figure1", "sha256": "FULL_IMAGE_SHA256",
      "receipt_step_id": "V001",
      "receipt_file": "/absolute/frozen/deployment/view-results/F001.json",
      "first_use": {"text_step_id": "T001", "position": "after"}
    },
    {"id": "T002", "kind": "text", "file_id": "teaching", "start": 80, "end": 200, "sha256": "EXACT_RANGE_SHA256"}
  ],
  "revisits": [{"id": "RB001", "initial_step_id": "B001"}]
}
```

The illustrative uppercase hash placeholders above are deliberately invalid.
`synthetic-preflight-v2/primary/route.json` is a complete, valid concrete example.
`files` can contain any number of text/image constituents. Baseline constituents
must be text. Nonempty baseline and teaching text constituents are required.

The exact seal schema is:

```json
{
  "schema": "sasis-route-seal-v1",
  "route_id": "reader-condition-revision",
  "route_sha256": "EXACT_RAW_ROUTE_JSON_SHA256",
  "launcher_sha256": "EXACT_EXECUTABLE_SHA256"
}
```

## Figure view and fixed receipt stage

`read-step F001` internally reads and verifies the whole image, persists its access
receipt, and returns JSON identifying the image's exact path/hash/length, the view
tool, and fixed receipt pathname and ID. That stdout JSON is only a path, not image
display. The document cursor remains at F001.

The reader must now invoke `tools.view_image` on that exact path with
`detail: "original"`, inspect the returned image, and preserve the actual tool call
and result evidence. The permitted operational save creates the fixed JSON receipt
below. It may omit the potentially large data URL, but its digest, character count,
returned detail and MIME must be computed from the actual returned result. The
tool result must exist before this file is created. Never synthesize a success
receipt from the input file or from a checksum alone.

```json
{
  "schema": "sasis-view-result-v1",
  "route_id": "reader-condition-revision",
  "figure_step_id": "F001",
  "receipt_step_id": "V001",
  "image_path": "/absolute/figure1.png",
  "image_sha256": "FULL_IMAGE_SHA256",
  "tool_name": "tools.view_image",
  "tool_call_id": "actual-visible-call-id-or-unique-correlated-invocation-label",
  "completed_at": "2026-10-12T12:00:00+00:00",
  "invocation": {"path": "/absolute/figure1.png", "detail": "original"},
  "result_metadata": {
    "success": true,
    "kind": "image",
    "detail": "original",
    "image_url_sha256": "SHA256_OF_UTF8_DATA_URL_STRING",
    "image_url_chars": 12345,
    "mime_type": "application/octet-stream"
  }
}
```

`tool_call_id` must map unambiguously to the preserved actual tool call/result in
the tool transcript. If the API does not expose its platform ID, use a unique
explicit correlation label and record that this is a wrapper label, not a platform
issued ID. The preflight uses this latter method and also preserves the complete
small raw result as `actual-view-tool-result.json`.

MIME is read from the actual data URL. The tool can return an image in an
`application/octet-stream` wrapper; this is supported alongside PNG/JPEG/WebP/GIF.
The launcher validates receipt identity, shape, successful image-result metadata,
unique invocation identity, and a timezone-aware completion time after dispatch
and no later than the current clock. Receipt JSON is limited to 65,536 bytes. It
does not independently authenticate a tool transcript or prove semantic inspection.

The next reader command is exactly:

```text
/absolute/frozen/deployment/read-step V001
```

It reads only the predetermined operational receipt, records its exact bytes'
SHA-256 and structured contents, and advances the figure gate. A bare path,
checksum, `viewed: true`, missing file, mismatched identity or failed result cannot
advance. The reader may save receipt evidence with a separately authorized
operational-file tool; this is not a per-step interpreter retrieval command.

## Actual access, stdout and chronology

The fixed `<deployment>/runtime/ledger.jsonl` is an fsynced JSONL hash chain under
an exclusive process lock. Each normal invocation records its arguments, outcome,
route and launcher identity, validated operation, and cursor. The launcher
instruments `subject_open_attempt`, `subject_opened`, each bounded `subject_read`,
`subject_closed`, and `actual_access` separately. Actual-access receipts contain
path, file identity, exact range, actual length/hash and verification outcome.

Text uses binary `os.lseek`/bounded `os.read`; stdout is exactly the verified range
bytes, without a prefix or suffix. No subject file is executed, imported,
evaluated or compiled. Image dispatch internally reads the complete image but
emits only operational path metadata. Subject access receipts are persisted before
`stdout_begin`. `stdout_complete` records bytes actually written to the transport,
not a claim that the downstream tool/UI displayed every byte. The caller must
preserve actual retrieval tool results and their visible truncation indicators.

Route state is reconstructed from successful ordered commits, verified access
receipts and completed stdout events. Initial text advances once. A revisit never
advances. Figure dispatch holds the cursor; only its matched receipt commits its
advance. Partial/unfinished calls, read/hash failure after byte access or output
failure block continuation and require preserved evidence plus a fresh reader.
Ordinary rejected calls without content access (wrong ID, order, type, range or
missing/malformed receipt) remain logged and do not change the cursor.

If the operational ledger cannot itself be opened or verified, the launcher fails
closed on stderr before subject access; preserve that external tool result. No
program can promise a persisted receipt when the receipt store itself is
unwritable or corrupted. Do not remove/rewrite ledger events to resume a reader.

## Admission audit

Before admitting the reader report, the orchestrator must compare the entire
frozen route with the ordered ledger, not merely a count or a checksum. For each
initial text step verify exact path/range/hash and successful actual output; check
that the full baseline precedes teaching, all file coverage is complete, and
revisits refer only to initially read baseline chunks. For every figure, verify
the internal full-image access, the actual view call/result in the tool transcript
at that first-use stage, the saved receipt digest and metadata, and its accepted
receipt stage before the next teaching slice. Compare transport evidence with the
actual output shown to the reader for truncation. Preserve every rejected or
interrupted call and any accidental early access. Metadata and a complete route
ledger alone do not prove complete reader-visible delivery or understanding.

This is an instruction whitelist, not technical confinement. Other tools remain
available unless the runtime independently restricts them. Local seals and ledger
hash chains do not prevent an agent or external process from rewriting files or
fabricating a receipt. The immutable-input requirement and transcript comparison
are essential, including the interval between verified image dispatch and actual
view. No memory erasure or exclusion of pretraining is claimed.
