# Synthetic launcher preflight — 2026-10-12

**Result: all 38 checks passed on the final executable. No baseline, teaching,
source, or other subject material was accessed.** Only the two authorized pinned
operational instruction files were read outside this assigned directory.

Final launcher SHA-256:
`d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd`

The production executable and successful primary synthetic deployment executable
have identical bytes. Every test used the direct invocation shape
`/absolute/deployment/read-step STEP_ID`, except intentional wrong-argument tests.
No per-call subject paths, byte ranges or interpreter retrieval commands were used.

| Evidence | Result |
|---|---|
| Valid first and subsequent text slices | Exact expected bytes only, exact lengths and SHA-256 values |
| Missing/extra argument, unknown/skipped ID | Rejected before any instrumented subject open/read |
| Unread baseline revisit | Rejected before subject open/read |
| Already-read baseline revisit | Exact original bounded bytes; following initial step still required |
| Initial baseline before teaching | Early teaching rejected; all initial baseline chunks precede teaching |
| Boolean type, negative/oversized range | Rejected before subject open/read |
| Missing coverage, delayed baseline/figure | Entire invalid route rejected before subject open/read |
| Wrong file kind, revisit target, receipt location | Rejected before subject open/read |
| Route identity and executable identity mismatch | Rejected before subject open/read |
| Duplicate JSON keys | Rejected before subject open/read |
| Changed slice bytes | Internal bytes logged, hash mismatch, zero subject stdout; further reading blocked |
| Whole figure dispatch | Full synthetic PNG internally read/verified; exact identified path returned; cursor held |
| Figure bypass, missing receipt, bare viewed assertion | Rejected without next subject open/read |
| Baseline revisit while figure pending | Allowed, with gate still held afterward |
| Wrong image identity or failed view result receipt | Rejected without subject open/read |
| Actual view invocation/result | `tools.view_image(..., detail="original")` returned and displayed the synthetic image |
| Fixed receipt stage | Accepted actual result metadata; then and only then allowed next text slice |
| Complete-route teaching repeat | Rejected; authorized baseline revisit still allowed |
| Access versus stdout | Verified actual-access event persisted before stdout begins; separate stdout transport outcome |
| Evidence integrity | All synthetic ledger hash chains valid; primary route commits match full route order |

The complete primary initial route committed as
`B001 → B002 → T001 → F001 (held) → V001 (receipt) → T002`.
Three baseline revisit commits occurred without changing this route sequence.
The actual image-view result is preserved in full for this small synthetic fixture;
the receipt's data-URL digest/length and invocation label match that raw result.
The invocation label is an explicit wrapper correlation ID, not an exposed
platform tool-call ID.

Evidence paths relative to this directory:

- `synthetic-preflight-v2/results.json`: all 38 commands, outcomes, stdout hashes and
  synthetic stdout bytes, stderr, instrumented-open/read counts, ledger index
  spans, and assertions.
- `synthetic-preflight-v2/primary/route.json` and `route-seal.json`: successful exact
  frozen synthetic route and binding.
- `synthetic-preflight-v2/primary/runtime/ledger.jsonl`: ordered actual-access,
  output, unsuccessful-call and cursor/figure receipt evidence.
- `synthetic-preflight-v2/primary/actual-view-tool-result.json`: actual returned
  synthetic `tools.view_image` result and invocation correlation metadata.
- `synthetic-preflight-v2/primary/view-results/F001.json`: prerequisite fixed view
  receipt accepted by `read-step V001`.
- Other v2 case directories: separate malformed-route/identity/hash-failure
  fixtures and their ledgers.
- `artifact-hashes.json`: concrete SHA-256 inventory of this complete deliverable.

An earlier development preflight is preserved in `synthetic-preflight/`. Its first
32 cases passed; its actual view receipt was rejected because the real tool
returned a valid displayed PNG wrapped as `application/octet-stream`, absent from
the initial MIME allowlist. The failure held the figure gate and returned no later
text. The final launcher accepts this actual wrapper; the full fresh v2 preflight
then passed 38/38. The earlier executable, fixtures, tool result, ledger and
`development-failure.json` remain available; they are not the accepted version.

This establishes the launcher's checked synthetic behavior, not production route
correctness or complete reader-visible delivery. The orchestrator still must
freeze/validate the actual two artifacts and their route, select slice sizes that
fit real output limits, preserve actual tool results, and compare the complete
ordered ledger and figure tool evidence before admitting a reader report. An
instruction whitelist is not technical confinement; local hashes and structured
view receipts do not prove semantic inspection or authenticate an external tool
transcript. See `README.md` for the exact schema and adaptation instructions.
