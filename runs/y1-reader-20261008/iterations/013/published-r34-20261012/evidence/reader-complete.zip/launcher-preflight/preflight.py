#!/usr/bin/env python3
"""Orchestrator-only synthetic preflight; never a reader command."""
import base64
import copy
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import zlib

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "synthetic-preflight-v2"
BASE = b"SYNTHETIC BASELINE CHUNK A.\nSYNTHETIC BASELINE CHUNK B.\n"
TEXT = b"SYNTHETIC TEACHING BEFORE FIGURE.\nSYNTHETIC TEACHING AFTER FIGURE.\n"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def png():
    def chunk(kind, data):
        return struct.pack("!I", len(data)) + kind + data + struct.pack("!I", zlib.crc32(kind + data) & 0xffffffff)
    rows = b"".join(b"\0" + b"".join(bytes((20, 80, 200) if x < 48 else (230, 160, 30))
                                    for x in range(96)) for _ in range(64))
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack("!2I5B", 96, 64, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b"")


def fixture(name):
    deployment = OUT / name
    if deployment.exists():
        raise RuntimeError("preserve previous evidence; fixture already exists: " + str(deployment))
    (deployment / "fixtures").mkdir(parents=True)
    (deployment / "view-results").mkdir()
    shutil.copy2(ROOT / "read-step", deployment / "read-step")
    blobs = {"baseline": BASE, "teaching": TEXT, "figure": png()}
    paths = {}
    for key, blob in blobs.items():
        paths[key] = deployment / "fixtures" / (key + (".png" if key == "figure" else ".bin"))
        paths[key].write_bytes(blob)
    bmid, tmid = BASE.index(b"\n") + 1, TEXT.index(b"\n") + 1
    route = {
        "schema": "sasis-fixed-route-v1", "route_id": "synthetic-" + name,
        "artifacts": {"baseline": {"id": "synthetic-baseline", "revision": "fixture-v1"},
                      "teaching": {"id": "synthetic-teaching", "revision": "fixture-v1"}},
        "files": [{"id": key, "artifact": "baseline" if key == "baseline" else "teaching",
                   "kind": "image" if key == "figure" else "text", "path": str(paths[key]),
                   "size": len(blob), "sha256": sha(blob)} for key, blob in blobs.items()],
        "steps": [
            {"id": "B001", "kind": "text", "file_id": "baseline", "start": 0, "end": bmid, "sha256": sha(BASE[:bmid])},
            {"id": "B002", "kind": "text", "file_id": "baseline", "start": bmid, "end": len(BASE), "sha256": sha(BASE[bmid:])},
            {"id": "T001", "kind": "text", "file_id": "teaching", "start": 0, "end": tmid, "sha256": sha(TEXT[:tmid])},
            {"id": "F001", "kind": "figure", "file_id": "figure", "sha256": sha(blobs["figure"]),
             "receipt_step_id": "V001", "receipt_file": str(deployment / "view-results" / "F001.json"),
             "first_use": {"text_step_id": "T001", "position": "after"}},
            {"id": "T002", "kind": "text", "file_id": "teaching", "start": tmid, "end": len(TEXT), "sha256": sha(TEXT[tmid:])}],
        "revisits": [{"id": "RB001", "initial_step_id": "B001"}, {"id": "RB002", "initial_step_id": "B002"}]
    }
    seal(deployment, route)
    return deployment, route


def seal(deployment, route):
    write_json(deployment / "route.json", route)
    write_json(deployment / "route-seal.json", {"schema": "sasis-route-seal-v1", "route_id": route["route_id"],
               "route_sha256": sha((deployment / "route.json").read_bytes()),
               "launcher_sha256": sha((deployment / "read-step").read_bytes())})


def events(deployment):
    path = deployment / "runtime" / "ledger.jsonl"
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []


RESULTS = []


def invoke(deployment, args, label, expect, expected_bytes=None, no_subject_open=False):
    before = len(events(deployment))
    result = subprocess.run([str(deployment / "read-step"), *args], capture_output=True)
    delta = events(deployment)[before:]
    opened = [e for e in delta if e["event"] == "subject_open_attempt"]
    reads = [e for e in delta if e["event"] == "subject_read"]
    assertions = {"exit_code": result.returncode == expect,
                  "attempt_recorded": any(e["event"] == "call_attempt" for e in delta),
                  "call_finished": bool(delta) and delta[-1]["event"] == "call_finished"}
    if expected_bytes is not None:
        assertions["exact_stdout_bytes"] = result.stdout == expected_bytes
    if expect:
        assertions["no_subject_stdout"] = result.stdout == b""
    if no_subject_open:
        assertions["zero_subject_opens_and_reads"] = not opened and not reads
    if opened and expect == 0:
        access = next(e for e in delta if e["event"] == "actual_access")
        begin = next(e for e in delta if e["event"] == "stdout_begin")
        assertions["access_receipt_before_output"] = access["index"] < begin["index"] and access["data"]["verified"] is True
    record = {"label": label, "command_argv": [str(deployment / "read-step"), *args],
              "exit_code": result.returncode, "stdout_sha256": sha(result.stdout), "stdout_bytes": len(result.stdout),
              "stdout_base64": base64.b64encode(result.stdout).decode(), "stderr": result.stderr.decode(),
              "subject_open_attempts": len(opened), "internal_read_bytes": sum(e["data"]["returned"] for e in reads),
              "event_indices": [before, before + len(delta)], "assertions": assertions,
              "pass": all(assertions.values())}
    RESULTS.append(record)
    assert record["pass"], record
    return result, delta


def save_results():
    old = json.loads((OUT / "results.json").read_text()) if (OUT / "results.json").exists() else []
    write_json(OUT / "results.json", old + RESULTS)


def phase_one():
    OUT.mkdir(exist_ok=True)
    primary, route = fixture("primary")
    invoke(primary, [], "no_argument", 2, no_subject_open=True)
    invoke(primary, ["B001", "extra"], "extra_argument", 2, no_subject_open=True)
    invoke(primary, ["UNKNOWN"], "unknown_step", 2, no_subject_open=True)
    invoke(primary, ["B002"], "skipped_step", 2, no_subject_open=True)
    invoke(primary, ["RB001"], "unread_baseline_revisit", 2, no_subject_open=True)
    invoke(primary, ["V001"], "premature_receipt", 2, no_subject_open=True)
    bmid, tmid = BASE.index(b"\n") + 1, TEXT.index(b"\n") + 1
    invoke(primary, ["B001"], "valid_first_slice", 0, BASE[:bmid])
    invoke(primary, ["RB001"], "known_baseline_revisit", 0, BASE[:bmid])
    invoke(primary, ["RB002"], "still_unread_baseline_revisit", 2, no_subject_open=True)
    invoke(primary, ["T001"], "teaching_before_baseline_complete", 2, no_subject_open=True)
    invoke(primary, ["B002"], "revisit_did_not_advance_cursor", 0, BASE[bmid:])
    invoke(primary, ["T001"], "teaching_first_slice", 0, TEXT[:tmid])
    result, _ = invoke(primary, ["F001"], "whole_figure_dispatch", 0)
    returned = json.loads(result.stdout)
    assert returned["image_path"] == route["files"][2]["path"] and returned["cursor_held"] is True
    invoke(primary, ["T002"], "figure_bypass_without_receipt", 2, no_subject_open=True)
    invoke(primary, ["V001"], "missing_tool_receipt", 2, no_subject_open=True)
    write_json(Path(route["steps"][3]["receipt_file"]), {"viewed": True})
    invoke(primary, ["V001"], "bare_viewed_assertion_rejected", 2, no_subject_open=True)
    Path(route["steps"][3]["receipt_file"]).unlink()
    invoke(primary, ["RB001"], "known_revisit_while_figure_pending", 0, BASE[:bmid])
    invoke(primary, ["T002"], "revisit_does_not_release_figure_gate", 2, no_subject_open=True)
    mutations = {
        "bad-type": lambda r: r["steps"][0].update(start=True),
        "negative-range": lambda r: r["steps"][0].update(start=-1),
        "oversized-range": lambda r: r["steps"][0].update(end=9999999),
        "gap-coverage": lambda r: r["steps"][1].update(start=r["steps"][1]["start"] + 1),
        "late-baseline": lambda r: r["steps"].insert(3, r["steps"].pop(1)),
        "late-figure": lambda r: r["steps"].append(r["steps"].pop(3)),
        "wrong-revisit-target": lambda r: r["revisits"][0].update(initial_step_id="T001"),
        "receipt-in-subject": lambda r: r["steps"][3].update(receipt_file=r["files"][0]["path"]),
        "wrong-file-kind": lambda r: r["steps"][0].update(file_id="figure"),
    }
    for name, mutate in mutations.items():
        deployment, r = fixture(name)
        mutate(r)
        seal(deployment, r)
        invoke(deployment, ["B001"], name, 2, no_subject_open=True)
    deployment, r = fixture("route-mismatch")
    (deployment / "route.json").write_bytes((deployment / "route.json").read_bytes() + b" ")
    invoke(deployment, ["B001"], "route_identity_mismatch", 2, no_subject_open=True)
    deployment, r = fixture("launcher-mismatch")
    (deployment / "read-step").write_bytes((deployment / "read-step").read_bytes() + b"\n")
    invoke(deployment, ["B001"], "launcher_identity_mismatch", 2, no_subject_open=True)
    deployment, r = fixture("slice-hash-mismatch")
    path = Path(r["files"][0]["path"])
    data = path.read_bytes()
    path.write_bytes(b"X" + data[1:])
    invoke(deployment, ["B001"], "slice_hash_mismatch_withheld", 2)
    invoke(deployment, ["B001"], "read_failure_requires_fresh_reader", 2, no_subject_open=True)
    deployment, r = fixture("duplicate-json-key")
    raw = (deployment / "route.json").read_bytes().replace(b'"route_id":', b'"schema":"sasis-fixed-route-v1", "route_id":', 1)
    (deployment / "route.json").write_bytes(raw)
    s = json.loads((deployment / "route-seal.json").read_text())
    s["route_sha256"] = sha(raw)
    write_json(deployment / "route-seal.json", s)
    invoke(deployment, ["B001"], "duplicate_json_key_rejected", 2, no_subject_open=True)
    save_results()
    print(json.dumps({"phase": "awaiting_actual_view_image", "tests_passed": len(RESULTS),
                      "synthetic_image_path": route["files"][2]["path"],
                      "receipt_path": route["steps"][3]["receipt_file"]}, indent=2))


def phase_two():
    primary = OUT / "primary"
    route = json.loads((primary / "route.json").read_text())
    receipt_path = Path(route["steps"][3]["receipt_file"])
    actual = json.loads(receipt_path.read_text())
    altered = copy.deepcopy(actual)
    altered["image_path"] = "/wrong/image.png"
    write_json(receipt_path, altered)
    invoke(primary, ["V001"], "wrong_image_receipt_rejected", 2, no_subject_open=True)
    altered = copy.deepcopy(actual)
    altered["result_metadata"]["success"] = False
    write_json(receipt_path, altered)
    invoke(primary, ["V001"], "failed_view_result_rejected", 2, no_subject_open=True)
    write_json(receipt_path, actual)
    invoke(primary, ["V001"], "actual_view_result_receipt_advances", 0, no_subject_open=True)
    tmid = TEXT.index(b"\n") + 1
    invoke(primary, ["T002"], "post_figure_text_after_receipt", 0, TEXT[tmid:])
    invoke(primary, ["T002"], "completed_teaching_cannot_reopen", 2, no_subject_open=True)
    invoke(primary, ["RB002"], "baseline_revisit_after_route_complete", 0, BASE[BASE.index(b"\n") + 1:])
    save_results()
    all_results = json.loads((OUT / "results.json").read_text())
    print(json.dumps({"tests_passed": len(all_results), "all_pass": all(r["pass"] for r in all_results)}, indent=2))


if __name__ == "__main__":
    if sys.argv[1:] == ["phase-one"]:
        phase_one()
    elif sys.argv[1:] == ["phase-two"]:
        phase_two()
    else:
        raise SystemExit("orchestrator preflight.py phase-one|phase-two")
