# Actual figure tool receipts and limitations

All three fixed dispatches were followed by an actual tools.view_image invocation on the exact dispatched path with detail original, and image(result.image_url) returned the actual image for inspection. No figure was postponed beyond its first-use route position. Each report witness was saved before later teaching text.

| Step | Explicit correlation label | Completion UTC | Actual detail | Data URL chars | Actual MIME wrapper |
|---|---|---|---|---:|---|
| F001 | D013-r34-reader-01-F001-view-call-01 | 2026-10-12T02:32:53.722Z | original | 79193 | application/octet-stream |
| F002 | D013-r34-reader-01-F002-view-call-01 | 2026-10-12T02:35:24.909Z | original | 80213 | application/octet-stream |
| F003 | D013-r34-reader-01-F003-view-call-01 | 2026-10-12T02:36:39.716Z | original | 76869 | application/octet-stream |

The SHA256 stored in each fixed receipt was computed from UTF-8 bytes of that actual returned data URL, not from an invented URL or the PNG contents. The separate image_sha256 field is the fixed dispatch's PNG digest. Full data URLs were retained in tool-session state during receipt generation but intentionally omitted from receipt files after digest/length calculation. Correlation labels are not platform call IDs; that limitation is stated here rather than as an unrequested schema field.

F001's initial receipt included an extra tool_call_id_kind field and V001 rejected its object fields. The exact rejected object has been regenerated in reports/F001-original-rejected-receipt.json from the unchanged retained actual result and original serialization; the original fixed receipt location had already been rewritten, so this was not a filesystem copy of its old bytes. The corrected fixed receipt removes that extra field only. Same-step V001 retry was explicitly authorized operationally and accepted before T002. V002/V003 were accepted without rejection.

The launcher receipt responses all state semantic_inspection_proven:false. This accurately limits what a metadata receipt establishes; semantic reading is documented in the chronological figure witnesses. The image tool's application/octet-stream wrapper did not prevent actual image display. F003's bottom-axis-label appearance is a provisional presentation concern as recorded in the report, with no blocked inference.
