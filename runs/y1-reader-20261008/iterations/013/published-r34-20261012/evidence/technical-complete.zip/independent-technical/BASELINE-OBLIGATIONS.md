# Full-baseline obligations for D013

The complete four-subject baseline was read, not inferred from its cover or a mathematics-only extract. `baseline-read-receipts.json` records the 16 contiguous byte ranges, their SHA256 hashes, actual commands and complete-output receipts. The combined baseline is one declared knowledge input; course completion is assumed competence, not observed mastery. Outside links in it are provenance only and were not accessed.

## Positive prior premises that D013 can use

| Baseline location | Explicit available premise | Consequence for D013 |
|---|---|---|
| Cover and Mathematics: language/proof | Domains, interval brackets, implication versus converse, universal counterexamples, deduction, limits in the derivative definition | Track a<b, all/some quantifiers, strict endpoints, admissible counterexamples and the difference between a theorem and its converse. |
| Mathematics: algebra/functions/geometry | Modulus as a piecewise function, function/domain/range, graph reading, line slopes and parallelism | Read the absolute-value graph and compute secant slopes without new algebraic machinery. |
| Mathematics: exponentials | Positive a^x, e^x positive, e^0=1, exponential derivative, exponential/log inverses | Positivity and differentiation of e^x are prior premises. They need not be derived from first principles in this lecture. |
| Mathematics: differentiation | Difference-quotient definition, local versus chord rate, constants/sums/powers/exponentials, tangent equation, stationary points, derivative-sign methods | The calculations of auxiliary-function derivatives and tangent lines are available; MVT provides a new theoretical justification of familiar sign methods. |
| Mathematics: sequences and series | Finite versus infinite sums, convergence as approaching a finite value, factorial/binomial algebra, geometric convergence | Finite positive lower bounds do not constitute an infinite equality; any convergence argument must actually establish the limiting remainder. |
| Further Mathematics FM01 | Mathematical induction including base and successor implication | A fully specified finite truncation induction can be expected without treating induction itself as untaught. |
| Further Mathematics FM27 | Maclaurin construction and e^x=Σx^n/n! for all real x; general remainder theorem and convergence proofs expressly not granted | The exponential series identity is already supplied, but its proof and a general Taylor error theorem cannot be silently assumed. Do not incorrectly classify all Taylor/Maclaurin content as absent from this four-subject baseline. |
| Mathematics integration; FM23/FM28 | Fundamental theorem for suitable continuous integrands, substitution, integration by parts, explicit limit requirements | A new exponential remainder proof could be derived if the question calls for it and the consequential steps are shown; its result is not an independently memorised grant. |
| Mathematics mechanics; FM57 and Physics motion | Signed velocity is derivative of position, speed is magnitude, distance differs from displacement, average rate and instantaneous rate, units | The trip example must not collapse a radial-distance derivative or arbitrary signed coordinate derivative into speed without stating the model. |
| Physics graphs/rates and Chemistry CH-01.01/CH-04.02 | Secant as average rate; tangent as instantaneous rate; rate sign depends on the measured quantity | Both scientific subjects reinforce the rate distinction. They do not supply MVT or a global existence theorem. |
| Physics/Chemistry scientific and practical reasoning | State model assumptions, units, limits, evidence and what a diagram supports | Graphs are interpretations/illustrations; a drawn shape is not a universal proof of error sign or a license to ignore theorem hypotheses. |

## New statements or bridges requiring the notes

B01. MVT itself is not an explicit baseline theorem. Its full assumptions, interval, existential conclusion and usable forms must be supplied before being required.

B02. The bridge from local derivatives to arbitrary finite changes is the lecture's substance, even though sign-based graph analysis is already available. A task requiring that proof needs the MVT identity and quantifier reasoning to be accessible, not just a restatement of familiar operational rules.

B03. Continuity has operational appearances in the baseline (root bracketing, fundamental theorem and domain warnings), but a formal general extreme-value theorem and Rolle's theorem are not granted. If assessed, a proof using them needs them supplied or derived. A geometric illustration can be labelled as such without pretending all analytic existence steps have been taught.

B04. Endpoint versus interior assumptions, c's dependence, nonuniqueness, reversed endpoint order and the distinction between a sufficient condition and a necessary one follow from careful theorem use; no unseen stronger theorem should be introduced as prior knowledge.

B05. Comparing exact MVT with tangent approximation needs an explicit distinction between f'(c) and f'(a). If a numerical error bound is assessed, provide the derivative control or sufficient remainder statement required to obtain it. FM27 does not provide a general error theorem.

B06. Each inequality by differentiation requires four connected pieces: a named difference function, its derivative, the interval on which the derivative has the required sign, and a comparison value (here zero at x=0). “Derivative positive, therefore function positive” omits an essential bridge.

B07. The source's positive-x proof chain should not silently become a strict all-real chain. Zero gives equality; a negative-x extension needs its own signs/interval argument. A prompt may ask for transfer, but the necessary premises and derivation path must be within the admitted notes plus this baseline.

B08. Full four-subject competence permits multi-step algebra and reasonable transfer; it does not permit external memory, unseen source solutions, historical trial answers or new university facts. Honest partial reasoning and focused questions remain valid student behaviour when material is genuinely missing.

## All-subject scope review

The Mathematics section was read through elementary proof, algebra, coordinate geometry, sequences, trigonometry, exponentials, differentiation, integration, numerical methods, vectors, statistics, probability tests and mechanics, including its explicit exclusions. Its differentiation and exponential rules are directly relevant. Its H240-only exclusion of Taylor theory is superseded, for the combined learner, by the positive FM27 grant; exclusions are not blanket prohibitions on deductions.

The Further Mathematics section was read through FM01–FM71, including the full Pure Core, selected Statistics Y542 and Mechanics Y543. Induction, Maclaurin e^x, integration and motion supply the concrete D013 links. Complex arithmetic/matrices, vector geometry, statistical tests and advanced mechanics do not silently add real-analysis existence theorems. Additional Pure and Discrete are not assumed.

The Physics section was read through reference data, quantities and measurement, practical skills, motion/forces/energy/materials, electricity/waves/quantum examples, thermal physics, circular motion/oscillations/gravity, astrophysics, fields/capacitors, nuclear/imaging and the stated first-year boundary. Its average/instantaneous rate, speed/velocity, dimensions and explicit model qualifications are relevant. It does not independently supply MVT, formal calculus or general Taylor theory.

The Chemistry section was read through CH-00 to CH-12 and CH-REF: quantities, atoms/bonds, acid/redox/inorganic material, reaction rates/equilibria, acid-base quantitative models, enthalpy/entropy/Gibbs, electrochemistry, organic mechanisms/synthesis, spectroscopy, practical methods and transfer limits. It explicitly supports secant/tangent rate interpretation and distinguishes species-rate signs. It supplies neither MVT nor general convergence/remainder theory. Its university-topic exclusions are restrictions on assumed memory, not on a shown deduction from all four permitted subjects.

No physical constants, spectra tables, statistical lookup values, outside calculator facility or chemical data are needed for the original D013 claims. Introducing a new cross-subject question could create such a requirement; all required data would then have to be present in its admitted content.

## Future review separation

These obligations identify available premises and potential gaps. They do not score or predict a student attempt, do not approve any future prompt, and do not claim the current teaching satisfies them. That judgment waits for the whole teaching freeze, exact complete published then-current PROF admission, fresh prompt-only packet and only then the teaching inputs authorised by the parent.
