# Independent D013 mathematics and source audit

Prepared from the admitted original source and full four-subject baseline only. Page references below are PDF pages; the lecture's printed numbering is one lower after the cover. These are technical findings and later checking obligations, not authored teaching or a judgment of any teaching artifact.

## A. Source identity and complete semantic reading

PDF page 1 is the MIT OpenCourseWare cover: 18.01 Single Variable Calculus, Fall 2006, source attribution and terms link. It adds no mathematical claim, but remains part of the assigned complete source.

PDF page 2 introduces Lecture 14, the mean value theorem, its differentiability/continuity hypotheses, the secant/tangent slope equality, Figure 1, the translated-parallel-line geometric argument, and the differentiability failure illustrated by absolute value.

PDF page 3 completes that failure with Figure 2, gives the 1,000-mile/3-hour travel interpretation, rewrites the theorem as a change and then a value identity, renames the right endpoint as x, stresses the unknown dependence of c, and compares with local linear approximation.

PDF page 4 continues the exact-versus-approximate comparison and Figure 3, states positive/negative/zero derivative conclusions, defines increasing/decreasing, proves the positive and zero cases, explicitly omits the negative case as similar, and explains why connecting a local derivative to finite changes matters.

PDF page 5 uses positive exponentials and successive auxiliary functions to prove positive-x lower bounds, extends through quadratic and cubic truncations, and previews the infinite exponential series for later Taylor-series study.

## B. Mean value theorem: exact content and independent derivation

M01. Fix a real interval `[a,b]` with `a<b`. If f is continuous on that entire closed interval and differentiable at every point of `(a,b)`, some `c∈(a,b)` satisfies

`m = (f(b)-f(a))/(b-a) = f'(c)`.

The statement is existential. It does not assert the same c for different intervals, c=(a+b)/2, uniqueness, a recipe to find c, or that every intermediate point works. It needs no continuity of f' and no endpoint differentiability. Ordinary differentiability at all interior points does imply continuity there, but the endpoint continuity still matters. An interval of positive length is essential to the displayed quotient and interior-point claim.

M02. Both lines have equal gradients, hence are parallel. They need not coincide: the secant goes through both endpoints, while the tangent touches at the intermediate point. Figure 1 shows the labelled endpoint a on the descending section, b on the rising section, and c between them on a rising section where the tangent is parallel to the secant. The dotted parallel line is shifted upward toward contact. There is no numerical assertion about the plotted coordinates.

M03. To make the geometric argument exact, set `h(t)=f(t)-m(t-a)`. Then `h(a)=h(b)=f(a)`. Continuity gives attained extrema on the closed interval. If h is constant, h'=0 at every interior point. Otherwise one of its extrema differs from the common endpoint value and is attained at an interior point c. At an interior extremum of a differentiable function h'(c)=0, so f'(c)=m.

This argument identifies the additional proof premises: attainment of extrema for a continuous function on a closed bounded interval, and the interior-extremum derivative rule. The former is not established in this original lecture, nor explicitly granted as a general theorem in the supplied baseline. The geometric account must either be recognised as an explanatory sketch or have that existence fact supplied if a rigorous proof is required. The derivative rule itself is readily derived from the baseline difference quotient: at a local minimum, nonnegative numerator gives a nonnegative quotient for h>0 and nonpositive quotient for h<0; a common two-sided limit must be zero. The signs reverse at a maximum. Do not claim that a supporting-line picture by itself proves the existence and interior location of contact.

M04. Two mathematically independent hypothesis checks, derived here rather than taken from external examples:

- On `[-1,1]`, f(t)=|t| is continuous and has average slope 0; its derivative is -1 for negative t and +1 for positive t, while f'(0) does not exist. No eligible c has derivative 0.
- On `[0,1]`, define f(0)=1 and f(t)=t for 0<t≤1. All interior derivatives are 1, but the endpoint quotient is 0. Failure of continuity at the left endpoint prevents use of the theorem.

Failure of a hypothesis removes the guarantee; it does not imply that the conclusion fails for every such function.

M05. The absolute-value explanation on PDF page 2 says first contact is at zero “no matter what its slope is.” That unrestricted statement is false. For a secant with endpoints `a=-u<0<b=v`, u,v>0, its slope is `(v-u)/(v+u)`, strictly between -1 and +1. It is within this range that translating a line from below first contacts the V at the vertex. For slope ±1 a branch can share the supporting line; for slopes outside [-1,1] no translated line is a global lower support to the full V, and on a compact restricted graph an endpoint can be the first contact. Figure 2 is consistent with the relevant secant straddling the corner. The correction preserves the example without licensing an arbitrary-slope assertion.

## C. Motion, equivalent forms and approximation

M06. With a differentiable scalar progress coordinate s(t), continuous on `[0,3]`, `s(0)=0` and `s(3)=1000` miles, MVT yields `s'(c)=1000/3` miles/hour at some c∈(0,3). The units come from miles divided by hours. The baseline distinguishes position/displacement, distance, signed velocity and speed. Calling s' “speed” throughout is justified for a one-dimensional increasing route coordinate or accumulated distance with the required differentiability. Even with reversals along a one-dimensional route, the guaranteed positive signed velocity equals speed at that particular c; monotonicity of the entire trip is not necessary. If s instead means radial distance from Boston for an arbitrary spatial trajectory, its derivative need not equal physical speed. The lecture is an idealised scalar travel illustration; a later account should state its interpretation and smoothness rather than silently generalising it.

M07. Multiplication and rearrangement give

`f(b)-f(a)=f'(c)(b-a)` and `f(b)=f(a)+f'(c)(b-a)`.

For x>a, the same theorem on `[a,x]` gives `f(x)=f(a)+f'(c)(x-a)`, a<c<x. For x<a, apply the theorem on `[x,a]`; the value identity still holds, but x<c<a. At x=a the value identity is trivial and does not supply a point strictly between equal endpoints. The source's displayed a<c<x is thus a right-side statement, not a universal ordering for arbitrary x.

M08. The exact identity uses an unspecified f'(c); tangent linearisation `L_a(x)=f(a)+f'(a)(x-a)` uses the known slope at a and is normally approximate near a. It is not legitimate to replace c by a in an exact MVT identity. Figure 3 shows the curve above its tangent at the chosen x, with a vertical error arrow; that drawing does not establish the sign of error for all differentiable functions.

M09. When the derivative at a and MVT hypotheses are available, exact subtraction gives

`E(x)=f(x)-L_a(x)=[f'(c)-f'(a)](x-a)`.

If `|f'(t)-f'(a)|≤δ` at every possible intermediate t, then `|E(x)|≤δ|x-a|`. Mere invocation of MVT supplies no numerical δ. More basically, differentiability at a itself says `(f(x)-f(a))/(x-a)→f'(a)`, so `E(x)/(x-a)→0`. This derives first-order approximation without assuming that f' is continuous near a. A general Taylor/Lagrange remainder theorem is not a baseline grant, even though specific Maclaurin expansions are.

## D. Derivative signs and finite changes

M10. The source's strict convention is: f increasing means for every a<b in the interval, f(a)<f(b); decreasing means f(a)>f(b). PDF page 4 actually prints f(a)<f(b) for decreasing too. Visual inspection confirms it is an original sign error, not a text-extraction accident. The decreasing inequality must be reversed.

M11. On an interval where the corresponding MVT hypotheses hold for each pair a<b, `b-a>0` and

`f(b)-f(a)=f'(c)(b-a)`.

Therefore f'>0 gives f(b)>f(a), f'<0 gives f(b)<f(a), and f'=0 everywhere gives f(b)=f(a). The negative case follows by multiplying the negative derivative by the positive interval length; the source's omitted proof has no new mathematical ingredient. The zero case requires zero derivative throughout the connected interval, not just at one stationary point.

M12. Domain and quantifiers are consequential. A derivative sign on a disconnected domain cannot compare values across a missing interval. For example, f(t)=1/t has f'(t)=-1/t²<0 on each side of zero, but f(-1)=-1<f(1)=1, so it is not globally strictly decreasing on its disconnected domain. Likewise constants chosen separately on two disjoint intervals have zero derivative everywhere on that domain without sharing a global value.

M13. Positive/negative derivative everywhere is sufficient, not necessary, for strict monotonicity. For instance x³ is strictly increasing although its derivative vanishes at zero: if a<b, `b³-a³=(b-a)(a²+ab+b²)>0`, since the second factor can vanish only when both a and b are zero, impossible for a<b. Nonnegative derivative gives nondecreasing values but alone does not force strict increase; the constant function supplies a counterexample. These are qualifications against overclaiming, not requirements to expand the assigned lecture into a general monotonicity theory.

M14. The local-to-finite bridge is the point of the proof. Baseline learners already know derivative-sign methods operationally, but the source now supplies their theorem-based justification. A derivative defined by a limit at a point and an ordered pair of function values over a finite interval are distinct statements connected by MVT.

## E. Exponential inequalities and infinite-series boundary

M15. The permitted starting facts are `(e^x)'=e^x`, e^x>0 for real x, and e^0=1. They appear explicitly in the baseline and are taken for granted by the lecture. Let `g1(x)=e^x-1`; then g1(0)=0 and g1'(x)=e^x>0. Hence g1(x)>0 for x>0, equals 0 at zero, and is negative for x<0. This proves e^x>1 for x>0. The source occasionally changes f1 to f in its explanatory line; that is a minor inconsistent label, with no change to the intended auxiliary function.

M16. Let `g2(x)=e^x-(1+x)`; then g2(0)=0 and g2'=g1. On `(0,x)` for x>0 the derivative is positive, so g2(x)>g2(0)=0. The missing written reference value g2(0)=0 is a necessary step, supplied by direct evaluation. A function having positive derivative does not by itself mean that function is positive.

M17. PDF page 5 lists e^x>1+x without an x restriction and repeats it as a displayed result. At x=0 this strict inequality is false. The proof provided establishes x>0. Independently, the stronger true statement is e^x≥1+x for all real x, equality only at x=0: for x<0, g2'<0 on `(x,0)`, so g2(x)>g2(0)=0. A later account can either state the proved positive-x scope or explicitly justify the stronger scope; it cannot retain the strict all-real formulation.

M18. For `g3(x)=e^x-(1+x+x²/2)`, g3(0)=0 and g3'=g2. Positive-x positivity of g2 implies g3(x)>0 for x>0. This derivative is why the coefficient 1/2 is chosen. The strict quadratic bound is false at zero and, unlike the linear one, false at every negative x: g2 is positive on `(x,0)`, so g3(0)-g3(x)>0 and g3(x)<0. A concrete independent check is x=-1: the quadratic polynomial is 1/2, whereas e^-1<1/2 follows from e>2, itself the already-proved linear bound at x=1.

M19. For `g4(x)=e^x-(1+x+x²/2+x³/3!)`, g4(0)=0 and g4'=g3. Thus the cubic lower bound holds for x>0. This makes the source's “one can keep on going” a genuine derivative chain, not a visual guess from polynomial coefficients.

M20. Define `P_n(x)=Σ[k=0..n] x^k/k!` and `R_n(x)=e^x-P_n(x)` for integer n≥0. Then R_n(0)=0 and, for n≥1, R_n'=R_(n-1). Base R_0=e^x-1 is positive for x>0. If R_(n-1)>0 on the positive half-line, MVT between 0 and any x>0 gives R_n(x)=x R_(n-1)(c)>0. Induction proves every finite positive-x truncation is a strict lower bound. The induction principle and factorial algebra are explicitly available in Further Mathematics FM01/FM37.

M21. Optional scope check for negative x: the same recursion and the negative factor x show `sign R_n(x)=(-1)^(n+1)` when x<0. Odd-degree truncations are lower bounds there and even-degree truncations upper bounds. This is an independent qualification; it must not be mistaken for an additional topic that every rendition of this lecture must teach.

M22. A lower bound for every finite n does not, by itself, prove the partial sums converge to e^x. The source explicitly defers the infinite identity to later Taylor-series study. The combined baseline already supplies the exponential Maclaurin identity for every real x in FM27, so a student may use that given identity when relevant. Neither source nor baseline grants a general remainder theorem or a general proof that every smooth function equals its Taylor series.

M23. Independent verification of the preview, if an actual proof were later required, can be built from permitted calculus plus explicitly justified bounds. Integration by parts gives the finite exact identity

`R_n(x)=(1/n!) ∫[0..x] e^t (x-t)^n dt`.

For n=0 it is the integral of e^t; integration by parts gives `I_n=I_(n-1)-x^n/n!`, matching the next partial-sum subtraction. For either sign of x,

`|R_n(x)|≤e^(max(0,x)) |x|^(n+1)/(n+1)!`.

For fixed x, consecutive positive bounding terms have ratio `|x|/(n+2)`, eventually at most 1/2, and hence tend to zero by comparison to a geometric sequence. This proves the exponential preview but exceeds the source's chosen proof scope. It is recorded for mathematical verification, not imposed as additional teaching.

## F. Later technical acceptance boundaries

An eventual teaching review must cover the actual five-page source, preserve the three figures' conceptual functions, state theorem hypotheses and quantifiers accurately, repair the definite decreasing-sign error, control the absolute-value slope claim, preserve the motion interpretation's assumptions, distinguish exact MVT from tangent approximation, supply the auxiliary functions' anchor values, keep strict exponential inequalities off x=0 and the quadratic lower bound off x<0, and separate finite inequalities from the infinite-series preview.

No optional enrichment in this audit is automatically an assessment requirement. In particular the disconnected-domain examples, negative-x parity and integral remainder proof are audit probes and mathematically derived qualifications. Their existence does not authorise testing them without sufficient explicit preparation in the later admitted notes and prompt.
