# Retrospectively preserved Python body of receipt 5c9390.
# It followed mkdir -p of this new output directory and ran as a heredoc.
# These three header comments were not part of the executed body.
from pathlib import Path
import hashlib,json,datetime
root=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical')
src=Path('/workspace/scratch/f9c0b7fc7e76/d013-clean-r33-20261012/inputs/student-baseline.txt')
b=src.read_bytes(); ranges=[]; pos=0
while pos<len(b):
 end=min(pos+16000,len(b))
 if end<len(b): end=b.rfind(b'\n',pos,end)+1
 chunk=b[pos:end]; chunk.decode('utf-8')
 ranges.append({'index':len(ranges)+1,'start_inclusive':pos,'end_exclusive':end,'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()});pos=end
(root/'baseline-read-plan.json').write_text(json.dumps({'path':str(src),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'range_convention':'zero-based byte offsets, half-open','chunks':ranges},indent=2)+'\n')
(root/'read_baseline_chunk.py').write_text('''from pathlib import Path
import hashlib,json,sys,datetime
root=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical')
plan=json.loads((root/'baseline-read-plan.json').read_text())
r=plan['chunks'][int(sys.argv[1])-1]
with open(plan['path'],'rb') as f:
 f.seek(r['start_inclusive']);b=f.read(r['bytes'])
assert hashlib.sha256(b).hexdigest()==r['sha256']
print('BEGIN_BASELINE_CHUNK '+json.dumps(r,sort_keys=True))
print(b.decode('utf-8'),end='')
print('END_BASELINE_CHUNK '+str(r['index']))
with (root/'baseline-read-events.jsonl').open('a') as f:f.write(json.dumps(dict(r,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command='python '+str(root/'read_baseline_chunk.py')+' '+str(r['index']),output='full decoded text printed between BEGIN/END markers; inspect tool response for clipping'))+'\\n')
''')
print(json.dumps(ranges,indent=2))
