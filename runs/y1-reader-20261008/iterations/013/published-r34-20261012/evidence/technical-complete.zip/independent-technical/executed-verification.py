# Retrospectively preserved exact Python body of the already-executed heredoc
# associated with exec_command receipt 2f419e. These two comments were not in
# that heredoc; every line below is its original command body.
from pathlib import Path
import hashlib,json,fitz,datetime
from PIL import Image
out=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical')
src=Path('/workspace/scratch/f9c0b7fc7e76/original-inputs/D013')
baseline=Path('/workspace/scratch/f9c0b7fc7e76/d013-clean-r33-20261012/inputs/student-baseline.txt')
ident=json.loads((src/'source-identity.json').read_text())
files=[]
for p in sorted(src.iterdir()):
 b=p.read_bytes();files.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
sums=[]
for line in (src/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);actual=hashlib.sha256((src/name).read_bytes()).hexdigest();assert h==actual;sums.append({'name':name,'listed_sha256':h,'actual_sha256':actual,'match':True})
pages=[]
doc=fitz.open(src/'lec14.pdf')
for i,p in enumerate(doc,1):
 t=(src/f'lec14-p{i:02}.txt').read_bytes();im=Image.open(src/f'lec14-p{i:02}.png').convert('RGB'); pix=p.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
 assert p.get_text('text').encode()==t
 assert im.size==(pix.width,pix.height) and im.tobytes()==pix.samples
 pages.append({'pdf_page':i,'literal_text_bytes':len(t),'fresh_extraction_byte_identical':True,'png_dimensions':list(im.size),'fresh_render_pixels_identical':True,'semantic_full_text_read':True,'original_resolution_image_inspected':True})
b=baseline.read_bytes();assert len(b)==247840 and hashlib.sha256(b).hexdigest()=='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
plan=json.loads((out/'baseline-read-plan.json').read_text()); ev=[json.loads(x) for x in (out/'baseline-read-events.jsonl').read_text().splitlines()]
assert [x['index'] for x in ev]==list(range(1,17));assert plan['chunks'][0]['start_inclusive']==0 and plan['chunks'][-1]['end_exclusive']==len(b)
assert all(a['end_exclusive']==z['start_inclusive'] for a,z in zip(plan['chunks'],plan['chunks'][1:]))
for c in plan['chunks']: assert hashlib.sha256(b[c['start_inclusive']:c['end_exclusive']]).hexdigest()==c['sha256']
receipts=[('1d0ca2',4005),('aced4b',4017),('7b2eaa',4027),('61bc37',4011),('50f130',4007),('c05c9a',3982),('089895',4009),('754966',4013),('9f7bfc',3959),('7f32d8',4045),('75064b',4030),('e716c2',4044),('31ab61',3884),('c28e85',3944),('c64783',3886),('ae1e1b',2906)]
for c,(rid,tokens) in zip(ev,receipts):c.update({'exec_command_chunk_id':rid,'tool_original_token_count':tokens,'max_output_tokens':10000,'exit_code':0,'begin_and_end_markers_observed':True,'tool_truncation_reported':False,'unrecovered_clipping':False,'semantic_read_complete':True})
(out/'baseline-read-receipts.json').write_text(json.dumps({'input':{'path':str(baseline),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'range_convention':'zero-based raw byte offsets, half-open','ordered_complete_cover':True,'chunks':ev},indent=2)+'\n')
(out/'identity-verification.json').write_text(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Original D013 directory and exact permitted baseline only; paths mentioned inside source identity are provenance strings, never followed.','original_directory_files':files,'source_SUMS_check':sums,'pdf_page_count':len(doc),'pdf_identity_record_match':ident['sha256']==hashlib.sha256((src/'lec14.pdf').read_bytes()).hexdigest(),'pages':pages,'baseline':{'path':str(baseline),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'expected_identity_matches':True}},indent=2)+'\n')
# Locate subject headings within the already-read byte sequence, without searching any additional input.
heads=[b'MATHEMATICS\r\n',b'FURTHER MATHEMATICS\r\n',b'PHYSICS\r\n',b'CHEMISTRY\r\n']
starts=[b.index(h) for h in heads]
(out/'baseline-subject-ranges.json').write_text(json.dumps({'input_sha256':hashlib.sha256(b).hexdigest(),'range_convention':'zero-based raw byte offsets, half-open','cover':{'start_inclusive':0,'end_exclusive':starts[0]},'sections':[{'subject':h.decode().strip(),'start_inclusive':s,'end_exclusive':starts[i+1] if i+1<len(starts) else len(b)} for i,(h,s) in enumerate(zip(heads,starts))]},indent=2)+'\n')
print(json.dumps({'source_files':len(files),'source_SUMS_entries':len(sums),'pdf_pages':len(doc),'page_text_bytes':sum(p['literal_text_bytes'] for p in pages),'image_views':5,'baseline_bytes':len(b),'baseline_chunks':len(ev),'subjects':len(heads),'verification':'all identity, extraction, pixel, chunk-contiguity and hash assertions passed'}))
