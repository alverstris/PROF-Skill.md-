from pathlib import Path
import json,hashlib,datetime
ad=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical/independent-prompt-solutions')
prep=ad.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
expected={'held-prep-manifest.json':'cf632a5c215b313df78869564b70740d89ef93beccb1c0cd1460a260b4e704a7','SHA256SUMS':'4b15a0ec30c2662bac8e7cfc27d7e7b0b973b848031a026be04b1af1546a4c91','seal.json':'32a6ca3ce57cb3fcfe79887e28a4fef303fb6324d03917cf8118b99e6ba7632d','package-admission/admission-manifest.json':'4e3d7e37a8e42072c04e7c2fc3ff821e3aabe39578b7bd2b6a457ec9a01ee35b','package-admission/SHA256SUMS':'dd3df277a729ba952296df1f1318b03c4ef61e89a44e736735a3edf719fa5be2','package-admission/seal.json':'4d0f2814e3da880b51ec64049a50ddc8f65630eb71bc79beef15ad0cc32be72f'}
for p,h in expected.items():assert sha((prep/p).read_bytes())==h
for directory in [prep,prep/'package-admission']:
    for line in (directory/'SHA256SUMS').read_text().splitlines():
        h,p=line.split('  ',1);assert sha((directory/p).read_bytes())==h
inp=json.loads((ad/'prompt-input-receipt.json').read_bytes())
b=Path(inp['path']).read_bytes();assert len(b)==inp['bytes']==2264 and sha(b)==inp['sha256']
results=json.loads((ad/'calculation-results.json').read_bytes());assert results['count']==31 and all(r['passed'] for r in results['checks'])
assert not (ad/'solutions-manifest.json').exists()
files=[]
for p in sorted(ad.iterdir()):
    if p.is_file():
        b=p.read_bytes();files.append(dict(path=p.name,bytes=len(b),sha256=sha(b)))
m=dict(state='INDEPENDENT_SOLUTIONS_SEALED_HELD_BEFORE_TEACHING_ACCESS',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),agent='/root/technical_d013_r34_prepared',prompt_input=inp,prompt_count=6,all_prompt_demands_addressed=True,independent_calculation_checks=31,package_admitted_before_prompt_read=True,prior_seals_unchanged=expected,authored_teaching_access=False,authored_hints_access=False,authored_solutions_access=False,source_findings_released=False,answers_released=False,whole_freeze_received=False,artifact_files=files)
(ad/'solutions-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
files.append(dict(path='solutions-manifest.json',bytes=(ad/'solutions-manifest.json').stat().st_size,sha256=sha((ad/'solutions-manifest.json').read_bytes())))
(ad/'SHA256SUMS').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in sorted(files,key=lambda r:r['path'])))
s=dict(state='HELD',manifest=dict(path='solutions-manifest.json',bytes=(ad/'solutions-manifest.json').stat().st_size,sha256=sha((ad/'solutions-manifest.json').read_bytes())),SUMS=dict(path='SHA256SUMS',bytes=(ad/'SHA256SUMS').stat().st_size,sha256=sha((ad/'SHA256SUMS').read_bytes())),SUMS_entries=len(files),no_self_hash_claim=True)
(ad/'seal.json').write_text(json.dumps(s,indent=2)+'\n')
for line in (ad/'SHA256SUMS').read_text().splitlines():
    h,p=line.split('  ',1);assert sha((ad/p).read_bytes())==h
for p in ad.iterdir():
    if p.is_file():p.chmod(0o444)
print(json.dumps(dict(manifest=s['manifest'],SUMS=s['SUMS'],seal=dict(path='seal.json',bytes=(ad/'seal.json').stat().st_size,sha256=sha((ad/'seal.json').read_bytes())),SUMS_entries=len(files),prompts=6,checks=31,prior_seals_unchanged=True)))
