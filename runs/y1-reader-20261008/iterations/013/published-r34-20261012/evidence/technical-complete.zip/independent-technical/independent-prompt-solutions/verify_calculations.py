import math,json
from fractions import Fraction as F
rows=[]
def record(name,condition,data):
    assert condition,name
    rows.append(dict(check=name,passed=True,data=data))
record('Q1 secant',F(1-(-1),1-(-1))==1,{'slope':'1','root_squares':['1/3','1/3']})
for c in [-1/math.sqrt(3),1/math.sqrt(3)]:
    record('Q1 interior root',-1<c<1 and math.isclose(3*c*c,1),{'c':c})
record('Q2 secant versus derivatives',F(2-0,1-0)==2 and F(1)!=F(2),{'secant':'2','interior_derivative':'1'})
estimate=F(1)+F(3)*(2-1);exact=F(2)**3;mid=F(3,2)
record('Q3 exact arithmetic',estimate==4 and exact==8 and exact-estimate==4 and 3*mid**2==F(27,4),{'estimate':str(estimate),'actual':str(exact),'signed_error':str(exact-estimate),'midpoint_derivative':str(3*mid**2)})
c=math.sqrt(7/3);record('Q3 interior point',1<c<2 and math.isclose(3*c*c,7),{'c':c})
for n in range(1,5):
    for k in range(1,n+1):
        record('Q5 finite polynomial derivative coefficient',F(k,math.factorial(k))==F(1,math.factorial(k-1)),{'n':n,'k':k})
for x in [0.25,1.0,2.0]:
    poly=sum(x**k/math.factorial(k) for k in range(5))
    record('Q5 positive-x numerical corroboration',math.exp(x)>poly,{'x':x,'remainder':math.exp(x)-poly})
for x in [F(1,4),F(1),F(2)]:
    record('Q6 lower-gap derivative identity',1/(1+x)-1/(1+x)**2==x/(1+x)**2 and x/(1+x)**2>0,{'x':str(x)})
    record('Q6 upper-gap derivative identity',1-1/(1+x)==x/(1+x) and x/(1+x)>0,{'x':str(x)})
    z=float(x);record('Q6 positive bounds numerical corroboration',z/(1+z)<math.log1p(z)<z,{'x':z})
for x in [-0.9,-0.5,-0.1]:record('Q6 negative upper bound numerical corroboration',math.log1p(x)<x and x/(1+x)<0,{'x':x,'gap':x-math.log1p(x)})
print(json.dumps(dict(checks=rows,count=len(rows),limits='Exact coefficient/arithmetic and numerical corroboration; the written general proofs establish domains, existence, uniqueness and universal inequalities. No finite sample is claimed as proof.'),indent=2))
