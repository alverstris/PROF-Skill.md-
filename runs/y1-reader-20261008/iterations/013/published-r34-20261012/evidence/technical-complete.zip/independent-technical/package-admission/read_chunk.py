from pathlib import Path
import json,hashlib,sys,datetime
ad=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical/package-admission')
plan=json.loads((ad/'read-plan.json').read_text());r=plan['chunks'][int(sys.argv[1])-1]
with (Path(plan['package_root'])/r['path']).open('rb') as f:
 f.seek(r['start_inclusive']);b=f.read(r['bytes'])
assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
print('BEGIN_PACKAGE_CHUNK '+json.dumps(r,sort_keys=True))
print(b.decode('utf8'),end='')
print('\nEND_PACKAGE_CHUNK '+str(r['index']))
with (ad/'read-events.jsonl').open('a') as f:f.write(json.dumps(dict(r,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command='python '+str(ad/'read_chunk.py')+' '+str(r['index'])))+'\n')
