from pathlib import Path
import hashlib,json,datetime
ad=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical/package-admission')
sha=lambda b:hashlib.sha256(b).hexdigest()
excluded={'admission-manifest.json','SHA256SUMS','seal.json'}
assert not any((ad/p).exists() for p in excluded)
files=[]
for p in sorted(ad.iterdir()):
    if p.is_file():
        b=p.read_bytes();files.append(dict(path=p.name,bytes=len(b),sha256=sha(b)))
m=dict(state='COMPLETE_PACKAGE_ADMISSION_SEALED_AWAIT_PROMPT_ONLY',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),agent='/root/technical_d013_r34_prepared',verified_package_commit='a36a6f0a9f452460a3e0a9c0fdc10d7c4a2a46e0',later_checkpoint_root_attestation='75d41178bb87e473d907e852f85f7047e0530a86',files_verified=36,package_bytes=907146,internal_hash_declarations_verified=34,full_new_content_bytes=415494,new_content_files=31,unique_bounded_chunks=49,reused_files=5,reused_package_bytes=491652,unrecovered_clipping=0,held_prep_manifest_sha256='cf632a5c215b313df78869564b70740d89ef93beccb1c0cd1460a260b4e704a7',prior_seal_unchanged=True,fresh_prompt_read=False,current_or_old_authored_teaching_read=False,held_source_findings_released=False,artifact_files=files)
(ad/'admission-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
files.append(dict(path='admission-manifest.json',bytes=(ad/'admission-manifest.json').stat().st_size,sha256=sha((ad/'admission-manifest.json').read_bytes())))
(ad/'SHA256SUMS').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in sorted(files,key=lambda r:r['path'])))
s=dict(state='SEALED',manifest=dict(path='admission-manifest.json',bytes=(ad/'admission-manifest.json').stat().st_size,sha256=sha((ad/'admission-manifest.json').read_bytes())),SUMS=dict(path='SHA256SUMS',bytes=(ad/'SHA256SUMS').stat().st_size,sha256=sha((ad/'SHA256SUMS').read_bytes())),SUMS_entries=len(files),no_self_hash_claim=True)
(ad/'seal.json').write_text(json.dumps(s,indent=2)+'\n')
for line in (ad/'SHA256SUMS').read_text().splitlines():
    h,p=line.split('  ',1);assert sha((ad/p).read_bytes())==h
for p in ad.iterdir():
    if p.is_file():p.chmod(0o444)
print(json.dumps(dict(manifest=s['manifest'],SUMS=s['SUMS'],seal=dict(path='seal.json',bytes=(ad/'seal.json').stat().st_size,sha256=sha((ad/'seal.json').read_bytes())),SUMS_entries=len(files))))
