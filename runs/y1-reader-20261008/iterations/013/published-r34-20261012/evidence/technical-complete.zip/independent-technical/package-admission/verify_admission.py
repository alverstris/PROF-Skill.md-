from pathlib import Path
import json, hashlib, collections, datetime

ad = Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical/package-admission')
prep = ad.parent
manifest_path = Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-package-admission-manifest.json')
manifest_raw = manifest_path.read_bytes()
m = json.loads(manifest_raw)
root = Path(m['package_root'])
sha = lambda b: hashlib.sha256(b).hexdigest()
write = lambda n,d: (ad/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
assert sha(manifest_raw)=='9945ae309943b03e02e7c2fa791c2eaffda8c8254c4858acaac57c1ce4e54d75'
assert m['commit']=='a36a6f0a9f452460a3e0a9c0fdc10d7c4a2a46e0'
paths = {r['path'] for r in m['files']}
assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} == paths
actual = {}
for r in m['files']:
    b = (root/r['path']).read_bytes()
    assert len(b)==r['bytes'] and sha(b)==r['sha256']
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_blob']
    actual[r['path']]={'bytes':len(b),'sha256':sha(b),'git_blob':r['git_blob']}
assert len(actual)==36 and sum(r['bytes'] for r in actual.values())==907146

# Declarations are kept distinct even when two declarations identify the same bytes.
checks=[]
def check(origin,field,path,expected,expected_bytes=None):
    assert path in actual, path
    a=actual[path]
    assert a['sha256']==expected
    if expected_bytes is not None: assert a['bytes']==expected_bytes
    checks.append(dict(origin=origin,field=field,path=path,expected_sha256=expected,actual_sha256=a['sha256'],actual_bytes=a['bytes'],match=True))
sasis='references/sasis/'
base=sasis+'ocr-baseline-20261007/'
profile=sasis+'profile-manifest.json'
d=json.loads((root/profile).read_bytes())
for i,r in enumerate(d['subject_files']):check(profile,f'subject_files[{i}].sha256',sasis+r['path'],r['sha256'])
for p,h in d['file_hashes'].items():check(profile,'file_hashes.'+p,base+p,h)
for p,h in d['control_file_hashes'].items():check(profile,'control_file_hashes.'+p,sasis+p,h)
release=base+'release-manifest.json'
d=json.loads((root/release).read_bytes())
for i,r in enumerate(d['subjects']):check(release,f'subjects[{i}].sha256',base+r['path'],r['sha256'],r['bytes'])
check(release,'combined_baseline_sha256',base+'student-baseline.txt',d['combined_baseline_sha256'])
historical=[dict(origin=release,field='archive_sha256',sha256=d['archive_sha256'],bytes=d['archive_bytes'],status='unbundled historical identity preserved; no target opened')]
freeze=base+'chemistry/freeze-manifest.json'
d=json.loads((root/freeze).read_bytes())
for i,r in enumerate(d['files']):
    p=base+'chemistry/'+r['path']
    if p in paths:check(freeze,f'files[{i}].sha256',p,r['sha256'],r['bytes'])
    else:historical.append(dict(origin=freeze,field=f'files[{i}].sha256',**r,status='unbundled historical identity preserved; no target opened'))
assert len(checks)==34
write('internal-hash-checks.json',dict(checks=checks,count=len(checks),all_match=True,historical_unbundled_declarations=historical,other_historical_source_hashes='The fully read download/source manifests retain original hashes; no unbundled target was opened or reverified.'))

reuse=json.loads((ad/'baseline-reuse-proof.json').read_bytes())
old=Path(reuse['prior_input_path']).read_bytes()
assert len(old)==247840 and sha(old)==reuse['prior_input_sha256']
for r in reuse['reused_files']:
    b=(root/r['path']).read_bytes();lo,hi=r['baseline_range'];oldpart=old[lo:hi]
    assert r['package_range']==[0,len(b)]
    assert sha(b)==r['package_sha256'] and sha(oldpart)==r['baseline_slice_sha256']
    if r['method'].startswith('exact'):assert b==oldpart
    else:
        norm=b.replace(b'\r',b'');other=oldpart.replace(b'\r',b'')
        assert norm==other and sha(norm)==r['normalized_sha256'] and len(norm)==r['normalized_bytes']
        assert b.count(b'\r')==r['package_CR_count'] and oldpart.count(b'\r')==r['baseline_slice_CR_count']

plan=json.loads((ad/'read-plan.json').read_bytes())
receipts=json.loads((ad/'tool-receipts-final.json').read_bytes())
events=[json.loads(s) for s in (ad/'read-events.jsonl').read_text().splitlines()]
assert len(receipts)==58 and len(events)==57
# Initial chunk 24 has a successful tool receipt but no durable read-event row.
# Preserve that gap; its new fully displayed revisit has both kinds of evidence.
assert [r['index'] for j,r in enumerate(receipts) if j!=23]==[r['index'] for r in events]
perfile=collections.defaultdict(list)
for r in plan['chunks']:
    b=(root/r['path']).read_bytes()[r['start_inclusive']:r['end_exclusive']]
    assert len(b)==r['bytes'] and sha(b)==r['sha256']
    good=[x for x in receipts if x['index']==r['index'] and x.get('model_delivery')!='clipped_at_context_boundary_not_counted_until_recovered']
    assert good and all(x['exit_code']==0 and x['end_marker'] for x in good)
    perfile[r['path']].append(r)
for p,rows in perfile.items():
    pos=0
    for r in rows:assert r['start_inclusive']==pos;pos=r['end_exclusive']
    assert pos==actual[p]['bytes']
reused_paths={r['path'] for r in reuse['reused_files']}
assert not(set(perfile)&reused_paths) and set(perfile)|reused_paths==paths
assert sum(r['bytes'] for r in plan['chunks'])==415494
assert sum(actual[p]['bytes'] for p in reused_paths)==491652

expected_prior={'held-prep-manifest.json':'cf632a5c215b313df78869564b70740d89ef93beccb1c0cd1460a260b4e704a7','SHA256SUMS':'4b15a0ec30c2662bac8e7cfc27d7e7b0b973b848031a026be04b1af1546a4c91','seal.json':'32a6ca3ce57cb3fcfe79887e28a4fef303fb6324d03917cf8118b99e6ba7632d'}
for p,h in expected_prior.items():assert sha((prep/p).read_bytes())==h
lines=(prep/'SHA256SUMS').read_text().splitlines()
for line in lines:
    h,p=line.split('  ',1);assert sha((prep/p).read_bytes())==h
assert len(lines)==16
write('final-verification.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command='python '+str(ad/'verify_admission.py'),package_files=len(actual),package_bytes=907146,sha256_and_git_blob_checks=36,internal_declarations_checked=len(checks),new_fulltext_files=len(perfile),new_fulltext_chunks=49,new_fulltext_bytes=415494,reused_files=5,reused_package_bytes=491652,semantic_reuse_not_second_read=True,execution_events=57,initial_clipped_deliveries=1,complete_recoveries=1,instruction_revisits=7,unrecovered_clipping=0,scope_gap_bytes=0,prior_seal_unchanged=expected_prior,prior_sums_entries_verified=len(lines),network_browser_git_installed_skill_access=False,current_teaching_access=False,fresh_prompt_packet_access=False))
print(json.dumps(dict(result='verified',package_files=36,package_bytes=907146,internal_hash_checks=34,new_fulltext_bytes=415494,reused_package_bytes=491652,scope_gap_bytes=0,unrecovered_clipping=0,prior_seal_unchanged=True)))
