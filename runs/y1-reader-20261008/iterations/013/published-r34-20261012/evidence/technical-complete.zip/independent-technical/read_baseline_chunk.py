from pathlib import Path
import hashlib,json,sys,datetime
root=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical')
plan=json.loads((root/'baseline-read-plan.json').read_text())
r=plan['chunks'][int(sys.argv[1])-1]
with open(plan['path'],'rb') as f:
 f.seek(r['start_inclusive']);b=f.read(r['bytes'])
assert hashlib.sha256(b).hexdigest()==r['sha256']
print('BEGIN_BASELINE_CHUNK '+json.dumps(r,sort_keys=True))
print(b.decode('utf-8'),end='')
print('END_BASELINE_CHUNK '+str(r['index']))
with (root/'baseline-read-events.jsonl').open('a') as f:f.write(json.dumps(dict(r,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command='python '+str(root/'read_baseline_chunk.py')+' '+str(r['index']),output='full decoded text printed between BEGIN/END markers; inspect tool response for clipping'))+'\n')
