from pathlib import Path
import json,hashlib,sys,datetime
root=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical/whole-technical-review')
r=json.loads((root/'teaching-read-plan.json').read_bytes())[int(sys.argv[1])-1]
lo,hi=r['raw_range']
with Path(r['path']).open('rb') as f:f.seek(lo);b=f.read(hi-lo)
assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
print('BEGIN_TEACHING_CHUNK '+json.dumps(r))
for i,s in enumerate(b.decode('utf8').splitlines(),r['start_line']):print(str(i)+': '+s)
print('END_TEACHING_CHUNK '+str(r['index']))
with (root/'read-events.jsonl').open('a') as f:f.write(json.dumps(dict(r,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command='python '+str(root/'read_teaching.py')+' '+str(r['index'])))+'\n')
