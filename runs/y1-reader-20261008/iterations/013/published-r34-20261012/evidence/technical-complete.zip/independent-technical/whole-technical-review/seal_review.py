from pathlib import Path
import json,hashlib,datetime
review=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical/whole-technical-review')
prep=review.parent
root=Path('/workspace/scratch/f9c0b7fc7e76/d013-clean-r34-20261012')
sha=lambda b:hashlib.sha256(b).hexdigest()
freeze=(root/'freeze-manifest.json').read_bytes()
assert sha(freeze)=='2d3abafb01909b498bd74709f4c279499215ed4c1f8668520aca65c8bfdc97fb'
m=json.loads(freeze)
for r in m['files']:
    b=(root/r['path']).read_bytes()
    assert len(b)==r['bytes'] and sha(b)==r['sha256']
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_blob']
assert len(m['files'])==6 and sum(r['bytes'] for r in m['files'])==206702
old_expected={'held-prep-manifest.json':'cf632a5c215b313df78869564b70740d89ef93beccb1c0cd1460a260b4e704a7','SHA256SUMS':'4b15a0ec30c2662bac8e7cfc27d7e7b0b973b848031a026be04b1af1546a4c91','seal.json':'32a6ca3ce57cb3fcfe79887e28a4fef303fb6324d03917cf8118b99e6ba7632d','package-admission/admission-manifest.json':'4e3d7e37a8e42072c04e7c2fc3ff821e3aabe39578b7bd2b6a457ec9a01ee35b','package-admission/SHA256SUMS':'dd3df277a729ba952296df1f1318b03c4ef61e89a44e736735a3edf719fa5be2','package-admission/seal.json':'4d0f2814e3da880b51ec64049a50ddc8f65630eb71bc79beef15ad0cc32be72f','independent-prompt-solutions/solutions-manifest.json':'32e1350285b258d77d1c0e7cab3ae0a03d3ff11b12ce8140d782776b74ab78ad','independent-prompt-solutions/SHA256SUMS':'19cf2c80a5f4d4540f8c27821bf1fdb827d99937bf66cc36f3592a4b3dc88709','independent-prompt-solutions/seal.json':'cf6316a04704b62b81f09f6f4426adbf26a177422124f1a6b6cb66a26fa8a09d'}
for p,h in old_expected.items():assert sha((prep/p).read_bytes())==h
old_sums_count=0
for d in [prep,prep/'package-admission',prep/'independent-prompt-solutions']:
    for line in (d/'SHA256SUMS').read_text().splitlines():
        h,p=line.split('  ',1);assert sha((d/p).read_bytes())==h;old_sums_count+=1
assert old_sums_count==40
plan=json.loads((review/'teaching-read-plan.json').read_bytes())
events=[json.loads(s) for s in (review/'read-events.jsonl').read_text().splitlines()]
receipts=json.loads((review/'read-tool-receipts.json').read_bytes())
assert len(plan)==len(events)==len(receipts)==5
assert [r['index'] for r in events]==[r['index'] for r in receipts]==[2,3,4,1,5]
assert all(r['exit_code']==0 and r['end_marker'] for r in receipts)
assert sum(r['bytes'] for r in plan)==29582
for name in ['main.md','hints.md','solutions.md']:
    path=str(root/'teaching'/name);rows=[r for r in plan if r['path']==path];pos=0;b=Path(path).read_bytes()
    for r in rows:
        lo,hi=r['raw_range'];assert lo==pos and sha(b[lo:hi])==r['sha256'];pos=hi
    assert pos==len(b)
images=json.loads((review/'image-view-receipts.json').read_bytes());assert len(images['images'])==3 and images['all_entire_canvases_visually_inspected']
coverage=json.loads((review/'source-coverage.json').read_bytes());assert len(coverage['units'])==30 and coverage['uncovered_assigned_units']==0
static=json.loads((review/'static-checks.json').read_bytes());assert len(static['prompt_checks'])==6 and all(r['normalized_text_equal'] for r in static['prompt_checks'])
v=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command='python '+str(review/'seal_review.py'),freeze_unchanged=True,all_six_file_identities_verified=True,teaching_total_bytes=206702,whole_text_bytes_read=29582,whole_text_chunks=5,full_original_resolution_images_viewed=3,coverage_units_reconciled=30,prompts_independently_solved_then_compared=6,prior_sums_entries_verified_unchanged=40,prior_seals=old_expected,unrecovered_clipping=0)
(review/'final-verification.json').write_text(json.dumps(v,indent=2)+'\n')
assert not (review/'review-manifest.json').exists()
files=[]
for p in sorted(review.iterdir()):
    if p.is_file():
        b=p.read_bytes();files.append(dict(path=p.name,bytes=len(b),sha256=sha(b)))
manifest=dict(state='COMPLETE_WHOLE_TECHNICAL_REVIEW_NO_SUPPORTED_MATERIAL_ISSUES',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),agent='/root/technical_d013_r34_prepared',whole_freeze_received_before_teaching_access=True,freeze_sha256=sha(freeze),teaching_files=6,teaching_bytes=206702,text_bytes_semantically_read=29582,figures_original_resolution_viewed=3,original_coverage_units=30,independent_prompt_solutions_compared=6,supported_material_issues=[],unverified_by_this_reviewer=['Actual GitHub render preservation, styling, image loading geometry and click routes','Target identity/content/theorem numbering for new external support citations at main lines 11,48,67'],not_a_SASIS_report=True,no_observed_human_mastery_claim=True,frozen_teaching_edited=False,earlier_seals_unchanged=True,artifact_files=files)
(review/'review-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files.append(dict(path='review-manifest.json',bytes=(review/'review-manifest.json').stat().st_size,sha256=sha((review/'review-manifest.json').read_bytes())))
(review/'SHA256SUMS').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in sorted(files,key=lambda r:r['path'])))
s=dict(state='SEALED',manifest=dict(path='review-manifest.json',bytes=(review/'review-manifest.json').stat().st_size,sha256=sha((review/'review-manifest.json').read_bytes())),SUMS=dict(path='SHA256SUMS',bytes=(review/'SHA256SUMS').stat().st_size,sha256=sha((review/'SHA256SUMS').read_bytes())),SUMS_entries=len(files),no_self_hash_claim=True)
(review/'seal.json').write_text(json.dumps(s,indent=2)+'\n')
for line in (review/'SHA256SUMS').read_text().splitlines():
    h,p=line.split('  ',1);assert sha((review/p).read_bytes())==h
for p in review.iterdir():
    if p.is_file():p.chmod(0o444)
print(json.dumps(dict(result=manifest['state'],report=dict(path='TECHNICAL-REVIEW.md',bytes=(review/'TECHNICAL-REVIEW.md').stat().st_size,sha256=sha((review/'TECHNICAL-REVIEW.md').read_bytes())),manifest=s['manifest'],SUMS=s['SUMS'],seal=dict(path='seal.json',bytes=(review/'seal.json').stat().st_size,sha256=sha((review/'seal.json').read_bytes())),SUMS_entries=len(files))))
