from pathlib import Path
import re,json
base=Path('/workspace/scratch/f9c0b7fc7e76/d013-clean-r34-20261012')
out=Path('/workspace/scratch/f9c0b7fc7e76/d013-r34-fresh-independent-technical/whole-technical-review')
texts={n:(base/'teaching'/n).read_text() for n in ['main.md','hints.md','solutions.md']}
original=(base/'author/prompts-only.md').read_text()
normalize=lambda s:re.sub(r'\s+','',s.replace('$`','').replace('`$','').replace('\\lt ','<').replace('\\gt ','>').replace('\\le ','≤').replace('\\ln','ln'))
ps={int(m.group(1)):m.group(0) for m in re.finditer(r'^Q([1-6])\..*$',original,re.M)}
ms={int(m.group(1)):m.group(0) for m in re.finditer(r'^Q([1-6])\..*$',texts['main.md'],re.M)}
checks=[{'prompt':i,'normalized_text_equal':normalize(ps[i])==normalize(ms[i])} for i in range(1,7)]
assert all(r['normalized_text_equal'] for r in checks)
anchors={n:re.findall(r'<a id="([^"]+)"',s) for n,s in texts.items()}
flat=[a for v in anchors.values() for a in v];assert len(flat)==len(set(flat))==18
links=[]
for n,s in texts.items():
    prose=re.sub(r'```math\n.*?```','',s,flags=re.S)
    prose=re.sub(r'\$`.*?`\$','',prose,flags=re.S)
    for target in re.findall(r'\]\(([^)]+)\)',prose):
        if target.startswith('http'):continue
        fname,_,anchor=target.partition('#');assert fname in texts
        assert not anchor or anchor in anchors[fname]
        links.append({'from':n,'target':target,'static_target_exists':True})
result={'prompt_normalization':'Remove math delimiters and whitespace; translate only \\lt / \\gt / \\le and \\ln to exact packet plain counterparts. No semantic or phrase rewrite.','prompt_checks':checks,'unique_document_specific_anchors':18,'static_internal_links':links,'static_internal_link_count':len(links),'actual_destination_click_check_performed':False,'external_reference_targets_opened':False,'initial_checker_error':'An initial inline regex incorrectly treated mathematical products ](x-a) and ](2-1) as links. Restricting link scans to prose corrected this reviewer-check error; no teaching defect is inferred.'}
(out/'static-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'prompts_equal':6,'anchors_unique':18,'static_links':len(links),'actual_clicks':'root scope'}))
