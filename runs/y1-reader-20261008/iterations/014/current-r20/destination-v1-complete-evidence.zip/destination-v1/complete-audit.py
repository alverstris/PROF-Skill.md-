from pathlib import Path
import json,re,hashlib,collections,fitz
from html.parser import HTMLParser
p=Path(__file__).parent;source=p.parent/'author/teaching-v1.md';s=source.read_text();article=(p/'github-article.html').read_text();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def read(f):return json.loads((p/f).read_text())
def save(f,obj):
 with (p/f).open('x') as o:json.dump(obj,o,ensure_ascii=False,indent=2);o.write('\n')
a=read('source-math.json');b=read('destination-math.json');rawnodes=re.findall(r'<math-renderer\b[^>]*>.*?</math-renderer>',article,re.S);diff=[];characters=[]
for i,(x,y) in enumerate(zip(a,b),1):
 if x['payload']!=y['payload']:
  lost=[]
  assert s[x['span'][0]:].startswith('$$')
  for m in re.finditer(r'\\,',x['payload']):
   at=x['span'][0]+2+m.start();assert s[at:at+2]=='\\,';before=s[:at];item=dict(math_ordinal=i,label=x['label_section'],character_offset_zero_based=at,UTF8_byte_offset_zero_based=len(before.encode()),line_one_based=before.count('\n')+1,column_one_based=at-before.rfind('\n'),source_two_characters='\\,',destination_character=',');lost.append(item);characters.append(item)
  diff.append(dict(ordinal=i,label=x['label_section'],source_block_line=x['source_line'],source_span=x['span'],source=x['payload'],actual=y['payload'],destination_element=y['element'],raw_HTML=rawnodes[i-1],lost_backslashes=lost,only_thinspace_command_backslash_loss=x['payload'].replace('\\,',',')==y['payload'],effect='A TeX thin-space command becomes a literal mathematical comma. This inserts punctuation before dx/du and in L1 separates the coefficient from dx; operands/grouping remain, but spacing/product notation is not preserved. Client-rendered pixels are not observed.'))
save('complete-math-failure-map.json',diff);save('all13-lost-character-positions.json',characters)
norm=lambda x:re.sub(r'\s+',' ',x).strip()
def masked(text,tokens):
 out='';pos=0
 for i,x in enumerate(tokens):
  d='$$' if x['type']=='js-display-math' else '$';needle=norm(d+x['payload']+d);at=text.find(needle,pos);assert at>=0,(i,needle);out+=text[pos:at]+f'MATHNODE{i:03d}';pos=at+len(needle)
 return out+text[pos:]
expected=(p/'expected-prose-math-stream.txt').read_text().strip();actual=(p/'actual-prose-math-stream.txt').read_text().strip();em=masked(expected,a);am=masked(actual,b)
(p/'source-prose-with-math-placeholders.txt').write_text(em+'\n');(p/'destination-prose-with-math-placeholders.txt').write_text(am+'\n')
class Paragraphs(HTMLParser):
 def __init__(self):super().__init__();self.active=False;self.parts=[];self.paragraphs=[]
 def handle_starttag(self,t,attrs):
  if t=='p':self.active=True;self.parts=[]
 def handle_endtag(self,t):
  if t=='p':self.paragraphs.append(norm(''.join(self.parts)));self.active=False
 def handle_data(self,d):
  if self.active:self.parts.append(d)
pars=Paragraphs();pars.feed(article);source_labels=re.findall(r'^([LPHS][1-8])\.',s,re.M);actual_labels=[m[1] for x in pars.paragraphs if (m:=re.match(r'^([LPHS][1-8])\.',x))];save('paragraph-label-check.json',dict(source=source_labels,actual=actual_labels,exact=source_labels==actual_labels,count=len(source_labels),scope='Paragraph-start labels L1–L8,P1–P7,H1–H7,S1–S7. In-paragraph cross-references not counted. Generic inherited Pnnn extraction is not used as acceptance.'))
nav=read('navigation.json');internal=[x for x in nav['links'] if x['href'].startswith('#')];positives=[]
for i in range(1,8):
 row=dict(task='P'+str(i),hint='H'+str(i),solution='S'+str(i),source_labels_present=all(source_labels.count(t+str(i))==1 for t in 'PHS'),actual_labels_present=all(actual_labels.count(t+str(i))==1 for t in 'PHS'),task_label_source_line=next(j for j,line in enumerate(s.splitlines(),1) if line.startswith(f'P{i}.')),hint_label_source_line=next(j for j,line in enumerate(s.splitlines(),1) if line.startswith(f'H{i}.')),solution_label_source_line=next(j for j,line in enumerate(s.splitlines(),1) if line.startswith(f'S{i}.')),native_task_target_present=False,native_hint_target_present=False,native_solution_target_present=False,task_to_hint=False,task_to_solution=False,hint_to_task=False,solution_to_task=False,positive_navigation_requirement_pass=False)
 assert not nav['targets'] and not internal
 positives.append(row)
navproof=dict(id='NAV-1',obligation='T11',status='FAIL',expected_task_help_triples=7,actual_label_triples=7,actual_native_targets=len(nav['targets']),actual_internal_links=len(internal),required_minimum_targets=21,required_minimum_directed_help_return_links=28,rows=positives,hints_group_separate_from_solutions=actual_labels.index('H7')<actual_labels.index('S1'),labels_are_not_native_targets=True,repair='Provide stable native targets and task-to-hint/task-to-solution/hint-to-task/solution-to-task links for each of seven tasks. Add usable reading-route/group links as appropriate. Verify actual targets and positive required relationships, not merely validity of an empty link list.')
save('positive-navigation-audit.json',navproof)
styles=read('element-style-evidence.json');assets=read('asset-fetch.json');css=[]
for f in (p/'css').glob('*.css'):
 for m in re.finditer(r'([^{}]+)\{([^{}]*)\}',f.read_text()):
  sel,body=m.groups()
  if ('markdown-body'in sel or sel.strip() in ['body','p','a','article']) and any(x in body for x in ['font-style','font-weight']):css.append(dict(file=f.name,selector=sel,declarations=body))
save('css-font-rules.json',css)
sourcehref='https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/c07ab6e13cf8684dd98b2650b64672fb_lec15.pdf';local=p.parent/'source/lec15.pdf';frozen=p/'frozen-source-lec15.pdf';official=p/'official-source-lec15.pdf';supp=p/'official-supplement-MVT.pdf';supdoc=fitz.open(supp);suptext=supdoc[0].get_text();(p/'supplement-page1-extracted.txt').write_text(suptext)
sourceproof=dict(main_href=sourcehref,actual_links=nav['links'],all2_external_hrefs_preserved=[x['href'] for x in nav['links']]==re.findall(r'\[[^\]]*\]\((https:[^)]+)\)',s),main_official_immutable_local_bytes_equal=local.read_bytes()==frozen.read_bytes()==official.read_bytes(),main_sha256=sha(frozen),main_bytes=frozen.stat().st_size,main_page_count=len(fitz.open(frozen)),supplement_sha256=sha(supp),supplement_bytes=supp.stat().st_size,supplement_page_count=len(supdoc),supplement_page1_text_record='supplement-page1-extracted.txt',scope='Official PDFs fetched successfully; main lecture provenance verified against immutable/local copy. Supplemental page1 extracted to verify target identity. No full source-PDF visual or substantive content audit claimed here.')
save('source-PDF-link-check.json',sourceproof)
checks=dict(observed_scope_result='FAIL — MATH-1 display-parser command loss and NAV-1 absent native task-help navigation',immutable_commit='c222a4fbf9c51cb72141e352dfe909278febb37a',source_sha256=sha(source),source_bytes=source.stat().st_size,actual_raw_exact=(p/'actual-raw-teaching.md').read_bytes()==source.read_bytes(),identity=read('destination-identity.json'),source_math_count=len(a),actual_math_count=len(b),inline_count=sum(x['type']=='js-inline-math' for x in a),display_count=sum(x['type']=='js-display-math' for x in a),all310_inline_payloads_exact=all(x['payload']==y['payload'] for x,y in zip(a,b) if x['type']=='js-inline-math'),exact_payload_count=sum(x['payload']==y['payload'] for x,y in zip(a,b)),display_payload_mismatches=len(diff),lost_thinspace_command_backslashes=len(characters),all_differences_fully_classified=all(x['only_thinspace_command_backslash_loss'] for x in diff),ordered_types_equal=[x['type'] for x in a]==[x['type'] for x in b],all_wrappers_valid=all(x['wrapper_valid'] for x in b),missing_math_spans=[],all_nonmath_prose_exact_after_whitespace_folding=em==am,whole_prose_math_stream_exact=read('prose-comparison.json')['exact_after_whitespace_folding'],all29_paragraph_start_labels_exact=source_labels==actual_labels and len(actual_labels)==29,all21_P_H_S_labels_present=all(actual_labels.count(t+str(i))==1 for t in 'PHS' for i in range(1,8)),positive_required_navigation_pass=False,positive_navigation_evidence='positive-navigation-audit.json',hints_group_separate_from_solutions=navproof['hints_group_separate_from_solutions'],no_figures_in_single_constituent=len(read('image-markup.json'))==0 and not re.search(r'!\[',s),figure_visual_review='not_applicable — no figure files or image markup in this single-constituent packet',all_CSS_fetched=all(x['exit']==0 for x in assets),CSS_count=sum(x['kind']=='css' for x in assets),no_forced_emphasis_prose_elements=not any(styles['tags'].get(t,0) for t in ['strong','b','em','i','h1','h2','h3','h4','h5','h6','th','dt','table']),actual_tags=styles['tags'],inline_style_summary=dict(collections.Counter(x['tag']+': '+x['style'] for x in styles['inline_styles'])),style_scope='Actual fetched body default weight400; no applicable heading/table/emphasis/definition-term prose nodes or inline font-emphasis declarations. Live computed styles/pixels unobserved.',source_PDFs=sourceproof,internal_preview='NOT PERFORMED — root held full preview for known-failing v1; no PDF/AST/native-PDF-navigation/page inspection claimed. A preview could not repair actual destination failures.',material_findings=['MATH-1','NAV-1'],limits=['Live GitHub pixels, computed styles, client MathJax, responsive layout and browser clicks unobserved.','Actual server parser payloads, CSS and href/target data checked; no claims of native visual rendering.','No source-PDF full visual audit or learner technical/semantic acceptance claim; those are separate review roles.'])
save('final-audit.json',checks)
rows='\n'.join('| '+str(x['ordinal'])+' | '+x['label']+' | '+','.join(str(c['line_one_based'])+':'+str(c['column_one_based']) for c in x['lost_backslashes'])+' | `'+x['source'].replace('\n','\\n')+'` | `'+x['actual'].replace('\n','\\n')+'` |' for x in diff)
report='''# D014 v1 actual destination audit

FAIL. Two material findings are established in the actual immutable GitHub output: MATH-1,12 display expressions lose13 TeX command backslashes; and NAV-1,all seven task/help triples lack native targets and links. The full audit continued through core, all hints and all solutions.

MATH-1 (T11/destination preservation): all346 expressions are recognized in order (310inline,36display). Every310 inline payload and24 display payloads match exactly. The remaining12 displays turn each affected `\\,` thin-space command into a literal comma. This is not ordinary whitespace normalization: mathematical punctuation is inserted before dx/du, including between the coefficient and dx in the defining L1 equality. Operand strings and grouping survive, but the intended notation is altered. No missing math nodes or other payload mismatches were found.

| Ordinal | Label | Source line:column of lost backslash | Source payload | Actual parsed payload |
|---|---|---|---|---|
'''+rows+'''

`complete-math-failure-map.json` retains full raw HTML, source spans, source/actual payloads and per-character positions. `all13-lost-character-positions.json` gives zero-based Unicode-character and UTF8-byte offsets, plus one-based line/column locations. Raw source bytes are exact; loss occurs in actual server-parser output. No additional entity decoding or reconstructed math was used as acceptance. Repair must preserve the intended expression in destination-supported syntax; replacing the affected thin-space command with ordinary TeX whitespace would avoid this particular Markdown escape collision, but the complete new revision must be rechecked.

NAV-1 (T11): there are21 unique P/H/S labels but zero actual native targets and zero internal links. All seven positive required task-to-hint, task-to-solution, hint-to-task and solution-to-task checks fail. The only two actual links are external source citations. The reading route tells readers to match numbers and each task says “Help: Hn; full solution: Sn,” but neither text is a link; hint and solution paragraphs also lack return links. All hints are correctly grouped before solutions, and the label/content correspondence is retained; those successes do not satisfy native navigation on a supporting destination. `positive-navigation-audit.json` explicitly tests required nonempty relationships, with every task/hint/solution source line, rather than passing an empty set of links. Repair requires at least21 stable task/help targets and28 directed help/return links for seven tasks, plus an appropriate route/group navigation.

All nonmath prose matches after ordinary whitespace folding when the ordered math nodes are masked. Whole prose-plus-math equality correctly fails only on the13 lost backslashes. All29 paragraph-start L/P/H/S labels match in order, including every21 task/help label. In-paragraph references are excluded from this label count.

Frozen identity: `c222a4fbf9c51cb72141e352dfe909278febb37a`; teaching23136bytes, SHA256 `60f908bb588e6dea64725b321f6eb753a33f8293bd452105f9fd48cefe68adbb`. Fresh immutable raw bytes equal local frozen bytes. Embedded commit/path/untruncated source identity pass; its rawLines representation omits only the terminal newline. This packet has one constituent and no figure markup/files requiring visual asset inspection.

All21 referenced stylesheet assets were fetched. Actual body default is weight400; article has no bold/italic/heading/table-header/definition-term prose nodes and inline styles only specify mathematical display mode. Applicable fetched rules do not establish unintended prose emphasis. Live computed styles/pixels were not inspected, so no live-style pass is claimed.

Both external source hrefs are exact and successfully fetched. Official/immutable/local Lecture15 PDF bytes agree,130496bytes,five pages,SHA256 `10c3dc97fa877d3ed97c5561b5082dca3006c632d85e58e01d059484ae455323`. The official supplemental MVT PDF is472962bytes,SHA256 `9428a339cbc094840fdd85c58f4116d71fedbe29107d3d346d6a35fc7c1bba6f`; page1 text is retained as target-identity evidence. This destination review does not claim a complete source-PDF visual/technical audit.

Root explicitly held the full internal preview for the known-failing v1. No PDF build, faithful AST conversion, native-PDF-navigation or final-page pass is claimed. A separately rendered preview would not remove the actual parser/navigation failures. No learner/source/skill files were edited and nothing was published.

Primary evidence: `final-audit.json`, `complete-math-failure-map.json`, `all13-lost-character-positions.json`, `positive-navigation-audit.json`, `paragraph-label-check.json`, original GitHub page/article/raw source, complete math/prose/navigation/CSS records and source-PDF identity records. Live GitHub pixels, client MathJax, computed styles, responsive behavior and browser clicks remain unobserved. Originals remain unchanged for consolidated repair.
'''
with (p/'review.md').open('x') as f:f.write(report)
print(json.dumps({k:v for k,v in checks.items() if k not in ['identity','source_PDFs']},indent=2))
