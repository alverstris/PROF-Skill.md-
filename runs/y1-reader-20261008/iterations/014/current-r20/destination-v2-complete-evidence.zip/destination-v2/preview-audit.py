from pathlib import Path
import json,re,hashlib,fitz,itertools
from PIL import Image
p=Path(__file__).parent;o=p/'preview-final2';s=(p.parent/'author/teaching-v2.md').read_text()
def read(n):return json.loads((p/n).read_text())
def save(n,v):
 with (p/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2,default=str);f.write('\n')
def nodes(x,t):
 if isinstance(x,dict):
  if x.get('t')==t:yield x
  for v in x.values():yield from nodes(v,t)
 elif isinstance(x,list):
  for v in x:yield from nodes(v,t)
def stream(x):
 if isinstance(x,list):return ''.join(stream(v) for v in x)
 if not isinstance(x,dict):return ''
 t=x.get('t');c=x.get('c')
 if t=='Str':return c
 if t in ['Space','SoftBreak','LineBreak']:return ' '
 if t=='Math':
  d='$$' if c[0]['t']=='DisplayMath' else '$';return d+c[1]+d
 if t in ['Link','Span']:return stream(c[1])
 if t in ['RawInline','RawBlock','Image']:return ''
 if t in ['Para','Plain']:return stream(c)+'\n'
 return stream(c)
norm=lambda s:re.sub(r'\s+',' ',s).strip();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();ast=read('preview-final2/preview-ast.json');math=read('source-math.json');nav=read('navigation.json');ids=re.findall(r'<a (?:name|id)="([^"]+)"></a>',s);internals=[x['href'] for x in nav['links'] if x['href'].startswith('#')];external=[x['href'] for x in nav['links'] if x['href'].startswith('https:')];aststream=stream(ast['blocks']);(o/'AST-prose-math-stream.txt').write_text(aststream)
astproof=dict(complete_prose_math_exact_after_whitespace_folding=norm(aststream)==norm((p/'expected-prose-math-stream.txt').read_text()),all346_math_payloads_exact=[x['c'][1] for x in nodes(ast,'Math')]==[x['payload'] for x in math],all346_math_types_exact=[x['c'][0]['t'] for x in nodes(ast,'Math')]==['DisplayMath' if x['type']=='js-display-math' else 'InlineMath' for x in math],all25_source_anchors_exact=[x['c'][0][0] for x in nodes(ast,'Span') if x['c'][0][0]]==ids,all43_links_exact=[x['c'][2][0] for x in nodes(ast,'Link')]==[x['href'] for x in nav['links']],no_images=list(nodes(ast,'Image'))==[],no_emphasis_nodes=not any(list(nodes(ast,t)) for t in ['Strong','Emph']),prof_style_exact=(o/'prof.sty').read_bytes()==(p.parents[5]/'assets/latex/prof.sty').read_bytes(),source_content_unchanged_from_attempt1=norm(stream(read('preview-final/preview-ast.json')['blocks']))==norm(aststream),adaptations=['Protected inline math delimiters converted for Pandoc; exact source math payloads restored and verified in final AST.','Source named anchors mapped to native Pandoc Span destinations.','PDF-only clearpage before hints and complete solutions.','PDF-only Needspace before L1–L8 labels keeps headings with explanatory text.','Current prof.sty, A4/11pt; explicit Unicode glyph declarations in preamble do not change source/AST.','No image files or reconstructed figures.'])
save('preview-final2/AST-content-check.json',astproof)
f=o/'verified-build.pdf';b=f.read_bytes();assert b'%%EOF' in b[-1024:];d=fitz.open(stream=b,filetype='pdf');digest=hashlib.sha256(b).hexdigest();names=d.resolve_names();links=[dict(from_page=i+1,**x) for i,page in enumerate(d) for x in page.get_links()];named=[x for x in links if 'nameddest' in x];fonts=sorted({sp['font'] for page in d for block in page.get_text('dict')['blocks'] if 'lines' in block for line in block['lines'] for sp in line['spans']});hintpages={f'h{i}':names[f'd014-h{i}']['page']+1 for i in range(1,8)};solpages={f's{i}':names[f'd014-s{i}']['page']+1 for i in range(1,8)}
proof=dict(canonical_file='preview-final2/verified-build.pdf',sha256=digest,bytes=len(b),page_count=len(d),digest_matches_successful_build=digest==read('preview-final2/preview-check.json')['pdf_sha256'],all25_named_targets_exist=len(ids)==25 and all(x in names for x in ids),all41_logical_internal_links_exact=[k for k,g in itertools.groupby(x['nameddest'] for x in named)]==[x[1:] for x in internals],all_native_link_targets_valid=all(x['nameddest'] in names and x.get('page')==names[x['nameddest']]['page'] and 0<=x['page']<len(d) for x in named),all2_external_hrefs_preserved=set(x.get('uri') for x in links if x.get('uri'))==set(external),hint_pages=hintpages,solution_pages=solpages,hint_solution_page_sets_disjoint=set(hintpages.values()).isdisjoint(solpages.values()),all_solutions_later_than_hints=min(solpages.values())>max(hintpages.values()),font_inventory=fonts,no_bold_or_italic_prose_fonts=all(not any(t in x for t in ['Bold','Oblique','Slant']) and ('Italic' not in x or 'Math' in x) for x in fonts),destinations=names,links=links,scope='Native PDF destinations/annotations inspected; no PDF-viewer click claim. This separate PDF does not prove GitHub client fragment navigation.')
save('preview-final2/navigation-fonts.json',proof)
rasters=[]
for i,page in enumerate(d,1):
 pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5));saved=Image.open(o/f'page-{i:02}.png').convert('RGB');rasters.append(dict(page=i,dimensions_equal=saved.size==(pix.width,pix.height),all_RGB_pixels_exact=saved.tobytes()==pix.samples,sha256=sha(o/f'page-{i:02}.png')))
save('preview-final2/exact-PDF-raster-correspondence.json',dict(canonical_pdf_sha256=digest,rasters=rasters,canonical_bytes_stable_after_check=f.read_bytes()==b,main_pdf_still_identical=(o/'main.pdf').read_bytes()==b))
print(json.dumps(dict(AST=astproof,PDF={k:v for k,v in proof.items() if k not in ['destinations','links']},all_rasters_exact=all(x['all_RGB_pixels_exact'] for x in rasters),stable=f.read_bytes()==b),indent=2))
