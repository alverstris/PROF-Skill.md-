from pathlib import Path
import json,re,hashlib,importlib.util,collections,fitz
from html.parser import HTMLParser
p=Path(__file__).parent;r=p.parents[5];s=(p.parent/'author/teaching-v2.md').read_text();article=(p/'github-article.html').read_text()
def read(n):return json.loads((p/n).read_text())
def save(n,v):
 with (p/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
norm=lambda s:re.sub(r'\s+',' ',s).strip()
spec=importlib.util.spec_from_file_location('h',r/'runs/y1-reader-20261008/iterations/008/render-evidence/r15-v2/dependency-review_helpers.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);a=h.DestinationArticle();a.feed(article)
map=[dict(label=f'P{i}',task=f'd014-p{i}',hint=f'd014-h{i}',solution=f'd014-s{i}') for i in range(1,8)];relations=h.check_task_relationships(a,map)
ids=re.findall(r'<a (?:id|name)="([^"]+)"></a>',s);internals=[x for x in a.links if x['href'].startswith('#')];sourcehrefs=re.findall(r'\[[^\]]*\]\(([^)]+)\)',s);counts=collections.Counter(t['value'] for t in a.targets)
for row in relations:
 row['hint_to_solution']=any(x['href']=='#'+row['mapping']['solution'] for x in row['section_links']['hint'])
nav=dict(source_ids=ids,actual_targets=a.targets,all25_unique_source_targets_exact=[t['value'] for t in a.targets]==['user-content-'+x for x in ids] and len(ids)==len(set(ids))==25,all41_internal_refs_resolve_uniquely=len(internals)==41 and all(counts['user-content-'+x['href'][1:]]==1 for x in internals),all43_source_links_exact_in_order=[x['href'] for x in a.links]==sourcehrefs,all7_positive_relationships_pass=all(all(row[k] for k in ['task_to_hint','task_to_solution','hint_to_task','solution_to_task','hint_to_solution']) and all(c==1 for c in row['target_element_counts'].values()) for row in relations),relationships=relations,initial_helper_record='navigation.json initial relationship rows used inherited pN/hN/sN config values; actual v2 uses d014-* names. Initial incorrect adapter rows preserved, not interpreted as learner failure. This corrected positive check uses current source IDs.',browser_clicks='unobserved')
save('positive-navigation-audit.json',nav)
class Pars(HTMLParser):
 def __init__(self):super().__init__();self.on=False;self.text=[];self.pars=[]
 def handle_starttag(self,t,a):
  if t=='p':self.on=True;self.text=[]
 def handle_data(self,d):
  if self.on:self.text.append(d)
 def handle_endtag(self,t):
  if t=='p':self.pars.append(norm(''.join(self.text)));self.on=False
pars=Pars();pars.feed(article);labels=re.findall(r'^([LPHS][1-8])\.',s,re.M);actual=[m[1] for x in pars.pars if (m:=re.match(r'^([LPHS][1-8])\.',x))];save('paragraph-label-check.json',dict(source=labels,actual=actual,all29_exact=labels==actual and len(labels)==29,scope='Paragraph starts only; no in-paragraph cross-reference overcount.'))
css=[]
for f in (p/'css').glob('*.css'):
 for m in re.finditer(r'([^{}]+)\{([^{}]*)\}',f.read_text()):
  sel,body=m.groups()
  if ('markdown-body' in sel or sel.strip() in ['body','p','a','article']) and any(x in body for x in ['font-style','font-weight']):css.append(dict(file=f.name,selector=sel,declarations=body))
save('css-font-rules.json',css)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();local=p.parent/'source/lec15.pdf';frozen=p/'frozen-source-lec15.pdf';official=p/'official-source-lec15.pdf';supp=p/'official-supplement-MVT.pdf';supdoc=fitz.open(supp);(p/'supplement-page1-extracted.txt').write_text(supdoc[0].get_text())
sourceproof=dict(external_hrefs=[x['href'] for x in a.links if x['href'].startswith('https:')],all2_external_hrefs_exact=[x['href'] for x in a.links if x['href'].startswith('https:')]==[x for x in sourcehrefs if x.startswith('https:')],main_official_immutable_local_bytes_equal=local.read_bytes()==frozen.read_bytes()==official.read_bytes(),main_sha256=sha(frozen),main_bytes=frozen.stat().st_size,main_pages=len(fitz.open(frozen)),supplement_sha256=sha(supp),supplement_bytes=supp.stat().st_size,supplement_pages=len(supdoc),fresh_fetch_success=all(x['exit']==0 for x in read('raw-source-fetch.json')),scope='Target identity/provenance only, not full source-PDF visual or mathematical review.')
save('source-PDF-link-check.json',sourceproof)
styles=read('element-style-evidence.json');assets=read('asset-fetch.json');checks=dict(immutable_commit=read('frozen-config.json')['commit'],source_sha256=sha(p.parent/'author/teaching-v2.md'),source_bytes=len(s.encode()),actual_raw_exact=(p/'actual-raw-teaching.md').read_bytes()==s.encode(),identity=read('destination-identity.json'),all346_math_payloads_exact=read('math-comparison.json')['exact_all'],inline_count=310,display_count=36,all_prose_math_exact=read('prose-comparison.json')['exact_after_whitespace_folding'],all29_paragraph_start_labels_exact=labels==actual and len(labels)==29,navigation={k:v for k,v in nav.items() if k.startswith('all')},all21_CSS_fetched=len(assets)==21 and all(x['exit']==0 for x in assets),no_emphasis_prose_elements=not any(styles['tags'].get(t,0) for t in ['b','strong','em','i','h1','h2','h3','h4','h5','h6','th','dt']),inline_styles=styles['inline_styles'],source_PDFs=sourceproof,no_figures=len(read('image-markup.json'))==0,scope_limits=['Actual server parser, raw bytes, link/target markup and fetched CSS inspected.','Live GitHub pixels, client MathJax, computed styles, responsive layout and browser clicks unobserved.','No image inspection applicable: single Markdown constituent, no figures or companions.'])
save('server-audit.json',checks);print(json.dumps({k:v for k,v in checks.items() if k not in ['identity','inline_styles','source_PDFs']},indent=2))
