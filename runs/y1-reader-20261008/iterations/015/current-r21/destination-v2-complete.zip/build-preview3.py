from pathlib import Path
import re,json,subprocess,shutil,hashlib,fitz,copy
p=Path(__file__).parent;r=p.parents[5];o=p/'preview-attempt3';o.mkdir();shutil.copy(r/'assets/latex/prof.sty',o/'prof.sty');shutil.copy(r/'assets/latex/main.tex',o/'template-original.tex');shutil.copytree(p/'remote/assets',o/'assets');names=['teaching','hints','solutions']
def run(cmd,name):
 q=subprocess.run(cmd,cwd=o,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(o/name).write_text(q.stdout);assert q.returncode==0,(cmd,q.stdout[-3000:]);return q.stdout
def nodes(x,t):
 if isinstance(x,dict):
  if x.get('t')==t:yield x
  for v in x.values():yield from nodes(v,t)
 elif isinstance(x,list):
  for v in x:yield from nodes(v,t)
combined=None;linkmap=[];imagemap=[];anchor_map=[];expected=[]
for name in names:
 s=(p/'remote'/f'{name}.md').read_text();tokens=json.loads((p/name/'source-math.json').read_text());expected+=tokens;md=re.sub(r'\$`(.*?)`\$',lambda m:'$'+m[1]+'$',s,flags=re.S);md=re.sub(r'^```math\n(.*?)\n```',lambda m:'$$\n'+m[1]+'\n$$',md,flags=re.M|re.S);(o/(name+'.md')).write_text(md)
 ast=json.loads(run(['pandoc',name+'.md','-f','markdown-smart-fancy_lists-implicit_figures','-t','json'],name+'-initial-ast.json'));ms=list(nodes(ast,'Math'));assert len(ms)==len(tokens)
 for node,token in zip(ms,tokens):assert node['c'][1].strip()==token['payload'].strip();node['c'][1]=token['payload']
 (o/(name+'-source-ast.json')).write_text(json.dumps(ast))
 for node in list(nodes(ast,'RawInline')):
  assert node['c'][0]=='html'
  if node['c'][1]=='</a>':node.update(t='Str',c='');continue
  m=re.fullmatch(r'<a (?:name|id)="([^"]+)">',node['c'][1]);assert m
  dest=name+'--'+m[1];anchor_map.append(dict(source_file=name+'.md',source=m[1],PDF=dest));node.update(t='Span',c=[[dest,[],[]],[]])
 for node in nodes(ast,'Link'):
  href=node['c'][2][0]
  if href.startswith('https:'):continue
  file,_,frag=href.partition('#');file=file.removesuffix('.md') or name;assert file in names;dest=file+'--'+frag if frag else file+'--entry';node['c'][2][0]='#'+dest;linkmap.append(dict(source_file=name+'.md',source_href=href,PDF_href='#'+dest))
 for node in nodes(ast,'Image'):
  src=node['c'][2][0];assert src.endswith('.svg');dest=src[:-4]+'.pdf';node['c'][2][0]=dest;imagemap.append(dict(source=src,PDF=dest));run(['inkscape',src,'--export-type=pdf','--export-filename='+dest],Path(src).stem+'-PDF-export.log')
 # Preserve every original paragraph; only add native entry target and PDF page breaks.
 ast['blocks'].insert(0,{'t':'Para','c':[{'t':'Span','c':[[name+'--entry',[],[]],[]]}]})
 # Attach empty named anchors to the following content paragraph so pagination cannot separate them.
 for i in range(len(ast['blocks'])-1,-1,-1):
  block=ast['blocks'][i]
  if block.get('t')=='Para' and block['c'] and all((x.get('t')=='Span' and not x['c'][1]) or (x.get('t')=='Str' and not x['c']) for x in block['c']):
   anchors=[x for x in block['c'] if x.get('t')=='Span'];j=next(j for j in range(i+1,len(ast['blocks'])) if ast['blocks'][j].get('t')=='Para');ast['blocks'][j]['c']=anchors+ast['blocks'][j]['c'];ast['blocks'].pop(i)
 for i in range(len(ast['blocks'])-1,-1,-1):
  block=ast['blocks'][i]
  if block.get('t')=='Para' and block['c'] and next((x['c'] for x in block['c'] if x.get('t')=='Str' and x['c']),None) in ['Section','Hint','Solution']:
   ast['blocks'].insert(i,{'t':'RawBlock','c':['latex',r'\Needspace{6\baselineskip}']})
 if combined is None:combined=ast
 else:combined['blocks'] += [{'t':'RawBlock','c':['latex',r'\clearpage']}]+ast['blocks']
(o/'preview-ast.json').write_text(json.dumps(combined));(o/'conversion-map.json').write_text(json.dumps(dict(anchors=anchor_map,links=linkmap,images=imagemap,file_entries=[x+'--entry' for x in names]),indent=2));tex=run(['pandoc','preview-ast.json','-f','json','-t','latex'],'body.tex');tex=tex.replace('\\includegraphics{','\\includegraphics[width=0.85\\linewidth]{')
# Start horizontal mode before an empty hypertarget; keeps its PDF destination on the paragraph's actual page.
tex=tex.replace(r'\protect\hypertarget',r'\leavevmode\protect\hypertarget')
head=r'''\documentclass[11pt,a4paper]{article}
\usepackage{prof}
\ProfHeader{Differential equations and separation}
\providecommand{\gt}{>}
\providecommand{\lt}{<}
\providecommand{\tightlist}{}
\DeclareUnicodeCharacter{2212}{\ensuremath{-}}
\DeclareUnicodeCharacter{2264}{\ensuremath{\leq}}
\DeclareUnicodeCharacter{2265}{\ensuremath{\geq}}
\DeclareUnicodeCharacter{2032}{\textsuperscript{\ensuremath{\prime}}}
\DeclareUnicodeCharacter{221E}{\ensuremath{\infty}}
\DeclareUnicodeCharacter{02E3}{\textsuperscript{x}}
\DeclareUnicodeCharacter{2081}{\textsubscript{1}}
\DeclareUnicodeCharacter{2082}{\textsubscript{2}}
\begin{document}
'''
(o/'main.tex').write_text(head+tex+'\n\\end{document}\n')
for i in [1,2]:run(['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],f'pass-{i}.txt');shutil.copy(o/'main.log',o/f'pass-{i}.log')
b=(o/'main.pdf').read_bytes();assert b'%%EOF' in b[-1024:];doc=fitz.open(stream=b,filetype='pdf');assert len(doc)>0;(o/'verified-build.pdf').write_bytes(b);pages=[]
for i,page in enumerate(doc,1):
 name=f'page-{i:02}.png';page.get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(o/name);pages.append(dict(page=i,image=name,text=page.get_text(),links=page.get_links(),visual_review='PENDING'))
(o/'pages.json').write_text(json.dumps(pages,indent=2,default=str));record=dict(page_count=len(doc),pdf_sha256=hashlib.sha256(b).hexdigest(),pdf_bytes=len(b),all_math_payloads_exact=[x['c'][1] for x in nodes(combined,'Math')]==[x['payload'] for x in expected],diagnostics=re.findall(r'^.*(?:Overfull|Underfull|Warning|undefined|Missing).*$',(o/'main.log').read_text(),re.M),canonical_stable=(o/'verified-build.pdf').read_bytes()==b,role='Internal source-faithful combined PDF derivative, not actual GitHub pixels/user deliverable. Exact transformations preserved in conversion-map.json.')
(o/'preview-check.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
