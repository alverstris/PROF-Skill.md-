from pathlib import Path
import json,re,hashlib,collections,shutil,fitz,xml.etree.ElementTree as ET
from html.parser import HTMLParser
from PIL import Image
p=Path(__file__).parent;commit='f531ccd1a3ec4b4918b96fbab30a7f6d8c03aafa';prefix='/alverstris/PROF-Skill.md-/blob/'+commit+'/runs/y1-reader-20261008/iterations/015/current-r21/author/v2/';names=['teaching','hints','solutions'];norm=lambda s:re.sub(r'\s+',' ',s).strip();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def read(n):return json.loads((p/n).read_text())
def save(n,v):
 with (p/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
class Pars(HTMLParser):
 def __init__(self):super().__init__();self.on=None;self.text=[];self.rows=[];self.ols=[]
 def handle_starttag(self,t,a):
  if t in ['p','li']:self.on=t;self.text=[]
  if t=='ol':self.ols.append(dict(a))
 def handle_data(self,s):
  if self.on:self.text.append(s)
 def handle_endtag(self,t):
  if t==self.on:self.rows.append(dict(tag=t,text=norm(''.join(self.text))));self.on=None
labels=[];prose=[];navs={n:read(n+'/navigation.json') for n in names};navchecks=[];alllinks=[];cssurls=[];stylesummary=[]
def mask(text,tokens):
 out='';pos=0
 for i,x in enumerate(tokens):
  delim='$$' if x['type']=='js-display-math' else '$';needle=norm(delim+x['payload']+delim);at=text.find(needle,pos);assert at>=0,(i,needle);out+=text[pos:at]+f'MATHNODE{i:03d}';pos=at+len(needle)
 return out+text[pos:]
labelregex=r'^(Section [1-7]|Q[1-5]\.|Hint Q[1-5]|Solution Q[1-5]|Figure [1-3]\.)'
for n in names:
 s=(p/'remote'/f'{n}.md').read_text();article=(p/n/'github-article.html').read_text();pars=Pars();pars.feed(article);sl=re.findall(labelregex,s,re.M);dl=[m[1] for row in pars.rows if (m:=re.match(labelregex,row['text']))];labels.append(dict(file=n+'.md',source_labels=sl,actual_paragraph_start_labels=dl,exact=sl==dl));a=read(n+'/source-math.json');b=read(n+'/destination-math.json');sp=mask((p/n/'expected-prose-math-stream.txt').read_text().strip(),a);dp=mask((p/n/'actual-prose-math-stream.txt').read_text().strip(),b);(p/n/'source-prose-with-math-placeholders.txt').write_text(sp+'\n');(p/n/'destination-prose-with-math-placeholders.txt').write_text(dp+'\n');prose.append(dict(file=n+'.md',all_nonmath_prose_exact=sp==dp,whole_prose_math_exact=read(n+'/prose-comparison.json')['exact_after_whitespace_folding']))
 ids=re.findall(r'<a name="([^"]+)"></a>',s);hrefs=re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',s);expected=[x if x.startswith('https:') else prefix+x for x in hrefs];nonimage=[x for x in navs[n]['links'] if '/assets/' not in x['href']];navchecks.append(dict(file=n+'.md',source_ids=ids,all_named_targets_exact=[x['value'] for x in navs[n]['targets']]==['user-content-'+i for i in ids],all_unique_targets=len(ids)==len(set(ids)),source_hrefs=hrefs,actual_nonimage_links=nonimage,all_source_hrefs_exact=[x['href'] for x in nonimage]==expected));alllinks += [dict(source_file=n+'.md',**x) for x in nonimage];style=read(n+'/element-style-evidence.json');cssurls+=style['css_urls'];stylesummary.append(dict(file=n+'.md',tags=style['tags'],inline_styles=style['inline_styles'],no_emphasis_prose_nodes=not any(style['tags'].get(t,0) for t in ['b','strong','i','em','h1','h2','h3','h4','h5','h6','th','dt'])))
 if n=='teaching':
  sourceitems=re.findall(r'^([1-6])\. (.*)$',s,re.M);actualitems=[x['text'] for x in pars.rows if x['tag']=='li'];expecteditems=[text.replace('$`','$').replace('`$','$') for _,text in sourceitems];save('exam-list-check.json',dict(source_items=sourceitems,actual_items=actualitems,all6_items_exact=expecteditems==actualitems and len(actualitems)==6,ordered_list_attributes=pars.ols,ordered_list_start_one=len(pars.ols)==1 and pars.ols[0].get('start','1')=='1'))
save('paragraph-label-check.json',labels);save('full-prose-check.json',prose)
def sectionlinks(file,target):
 nav=navs[file];starts=[x['element'] for x in nav['targets'] if x['value']=='user-content-'+target];assert len(starts)==1;start=starts[0];end=min([x['element'] for x in nav['targets'] if x['element']>start]+[10**9]);return [x['href'] for x in nav['links'] if start<=x['element']<end]
relationships=[]
for i in range(1,6):
 q=sectionlinks('teaching',f'q{i}');h=sectionlinks('hints',f'h{i}');a=sectionlinks('solutions',f'a{i}');relationships.append(dict(task=f'Q{i}',task_to_hint=prefix+f'hints.md#h{i}' in q,task_to_answer=prefix+f'solutions.md#a{i}' in q,hint_to_task=prefix+f'teaching.md#q{i}' in h,answer_to_task=prefix+f'teaching.md#q{i}' in a,answer_to_hint=prefix+f'hints.md#h{i}' in a,hint_file_to_solutions=any(x['href']==prefix+'solutions.md' for x in navs['hints']['links']),section_links=dict(task=q,hint=h,answer=a)))
resolved=[]
for link in alllinks:
 if not link['href'].startswith(prefix):continue
 ref=link['href'][len(prefix):];file,_,frag=ref.partition('#');targetdoc=file.removesuffix('.md');assert targetdoc in names;count=sum(t['value']=='user-content-'+frag for t in navs[targetdoc]['targets']) if frag else None;resolved.append(dict(source=link['source_file'],href=link['href'],target_file=file,fragment=frag or None,target_count=count,exact_unique_target=count==1 if frag else (p/targetdoc/'github-article.html').exists()))
shutil.copy(p.parent/'root-navigation-contract.md',p/'root-navigation-contract-copy.md');navproof=dict(documents=navchecks,relationships=relationships,all5_positive_chains=all(all(row[k] for k in ['task_to_hint','task_to_answer','hint_to_task','answer_to_task','answer_to_hint','hint_file_to_solutions']) for row in relationships),crossfile_refs=resolved,all31_crossfile_refs_valid=len(resolved)==31 and all(x['exact_unique_target'] for x in resolved),total_named_targets=sum(len(navs[n]['targets']) for n in names),mapping_scope='Actual hrefs rewritten to the exact immutable blob path; actual names have user-content- prefix. Compare explicit prefix correspondence, not literal fragment/name equality. Root-provided official relative-link/custom-anchor contract preserved; client implementation/clicks/scroll not observed.',help_separation='Hints and complete solutions are distinct actual immutable files, each fetched and audited. Global hints-to-solutions link present; not an interactive reveal or PDF page-separation claim.')
save('positive-navigation-audit.json',navproof)
css=[]
for f in (p/'css').glob('*.css'):
 for m in re.finditer(r'([^{}]+)\{([^{}]*)\}',f.read_text()):
  sel,body=m.groups()
  if ('markdown-body' in sel or sel.strip() in ['body','p','a','article','li']) and any(x in body for x in ['font-style','font-weight']):css.append(dict(file=f.name,selector=sel,declarations=body))
save('css-font-rules.json',css);save('style-audit.json',dict(documents=stylesummary,unique_external_stylesheet_count=len(set(x for x in cssurls if x)),stylesheet_links_without_href=sum(x is None for x in cssurls),note='Outer GitHub page contains a stylesheet link without href on at least one page; no external URL exists to fetch for that entry. All referenced external CSS URLs fetched. Body default normal400; no applicable heading/table/emphasis/definition-term nodes. Live computed styles unobserved.'))
failures=read('complete-math-failure-map.json');positions=[]
for row in failures:
 s=(p/'remote'/row['file']).read_text();at=row['source_span'][0]+2;assert s[row['source_span'][0]:].startswith('$`');only=row['source'].replace('<','&lt;').replace('>','&gt;')==row['actual'];assert only
 for m in re.finditer('[<>]',row['source']):
  offset=at+m.start();before=s[:offset];positions.append(dict(file=row['file'],math_ordinal=row['ordinal'],line=before.count('\n')+1,column=offset-before.rfind('\n'),character_offset=offset,UTF8_byte_offset=len(before.encode()),source_character=m[0],actual_literal_entity='&lt;' if m[0]=='<' else '&gt;',source_payload=row['source'],actual_payload=row['actual']))
save('comparison-character-failures.json',positions)
assets=[]
for item in read('initial-fetch.json'):
 if not item['path'].startswith('remote/'):continue
 row=dict(item);f=p/item['path']
 if f.suffix in ['.png','.svg']:
  row['full_frame_visually_inspected']=True
  if f.suffix=='.png':row['size']=Image.open(f).size
  else:
   root=ET.parse(f).getroot();hrefs=[v for e in root.iter() for k,v in e.attrib.items() if k.endswith('href')];row.update(svg_root_attributes=root.attrib,all_external_dependencies_absent=all(v.startswith('#') for v in hrefs),local_glyph_references=len(hrefs),render_file='svg-renders/'+f.stem+'.png',render_sha256=sha(p/'svg-renders'/(f.stem+'.png')))
 assets.append(row)
save('asset-manifest.json',assets)
assetviews=[dict(figure=1,PNG='remote/assets/figure-1-gaussian.png',SVG='remote/assets/figure-1-gaussian.svg',finding='Both complete frames viewed: symmetric bell on [-6,6], peak(0,1), thin tails near zero. Labels upright/legible and caption derivative-sign/height interpretation agrees. Finite display resolution cannot prove asymptotic nonzero values, which prose establishes analytically.'),dict(figure=2,PNG='remote/assets/figure-2-slopes.png',SVG='remote/assets/figure-2-slopes.svg',finding='Both complete frames viewed: y=x² curve, dashed y=x ray and red y=2x−1 tangent meet at labelled(1,1). Slopes1 and2 distinguish ray/tangent; normal legend/axis typography. Geometry agrees with the worked caption.'),dict(figure=3,PNG='remote/assets/figure-3-orthogonal.png',SVG='remote/assets/figure-3-orthogonal.svg',finding='Both complete frames viewed: four up/down parabolas, two horizontal ellipses, same coordinate unit scale. Ellipse intercepts agree with c=.4 and1.2 (horizontal about1.265 and2.191; vertical .894 and1.549), ratio√2. Dark/teal legend and captions distinguish families; axis-exception prose agrees. No obscured crossing needed for inference; no forced emphasis.')]
save('asset-visual-inspection.json',dict(all3_fresh_PNGs_opened=True,all3_fresh_SVGs_independently_rendered_and_opened=True,views=assetviews,material_issues=[],SVG_render_warnings='All Inkscape exits0; original GtkRecentManager initialization warnings retained in SVG-render-log.json; full frames rendered successfully.',scope='Fresh immutable raw assets, local full-frame rendering. No claim of live GitHub embedded image pixels.'))
print(json.dumps(dict(labels=labels,prose=prose,positive_nav=navproof['all5_positive_chains'],crossfile_refs=len(resolved),all_crossfile_valid=navproof['all31_crossfile_refs_valid'],targets=navproof['total_named_targets'],characters=len(positions),external_CSS_count=len(set(x for x in cssurls if x))),indent=2))
