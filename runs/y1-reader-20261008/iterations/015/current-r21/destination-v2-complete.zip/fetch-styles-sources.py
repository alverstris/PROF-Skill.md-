from pathlib import Path
import json,subprocess,concurrent.futures,hashlib
p=Path(__file__).parent;css=sorted({u for name in ['teaching','hints','solutions'] for u in json.loads((p/name/'element-style-evidence.json').read_text())['css_urls'] if u});(p/'css').mkdir();items=[(u,p/'css'/Path(u).name,'css') for u in css];prefix='https://raw.githubusercontent.com/alverstris/PROF-Skill.md-/f531ccd1a3ec4b4918b96fbab30a7f6d8c03aafa/runs/y1-reader-20261008/iterations/015/current-r21/'
items += [('https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/991e10d17c527483d3d41d83a7313536_lec16.pdf',p/'official-source-lec16.pdf','source'),(prefix+'source/lec16.pdf',p/'frozen-source-lec16.pdf','source'),('https://ocw.mit.edu/courses/22-51-quantum-theory-of-radiation-interactions-fall-2012/7290342f83e64ea532f20aa0c8d9a63a_MIT22_51F12_Ch9.pdf',p/'official-supplement-ch9.pdf','supplement'),(prefix+'primary-qm/MIT22_51F12_Ch9.pdf',p/'frozen-supplement-ch9.pdf','supplement')]
def get(it):
 url,f,kind=it;q=subprocess.run(['curl','-L','--fail','--max-time','55','--silent','--show-error',url,'-o',str(f)],capture_output=True,text=True);v=dict(url=url,file=str(f.relative_to(p)),kind=kind,exit=q.returncode,stderr=q.stderr)
 if q.returncode==0:v.update(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 return v
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:out=list(pool.map(get,items))
(p/'CSS-source-fetch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(items=len(out),failures=[x for x in out if x['exit']!=0]),indent=2))
