from pathlib import Path
import json,re,hashlib,fitz,itertools,copy
from PIL import Image
p=Path(__file__).parent;o=p/'preview-attempt3';names=['teaching','hints','solutions']
def read(n):return json.loads((p/n).read_text())
def save(n,v):
 with (p/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2,default=str);f.write('\n')
def nodes(x,t):
 if isinstance(x,dict):
  if x.get('t')==t:yield x
  for v in x.values():yield from nodes(v,t)
 elif isinstance(x,list):
  for v in x:yield from nodes(v,t)
def stream(x):
 if isinstance(x,list):return ''.join(stream(v) for v in x)
 if not isinstance(x,dict):return ''
 t=x.get('t');c=x.get('c')
 if t=='Str':return c
 if t in ['Space','SoftBreak','LineBreak']:return ' '
 if t=='Math':
  delim='$$' if c[0]['t']=='DisplayMath' else '$';return delim+c[1]+delim
 if t in ['Link','Span']:return stream(c[1])
 if t in ['RawInline','RawBlock','Image']:return ''
 if t in ['Para','Plain']:return stream(c)+'\n'
 return stream(c)
norm=lambda s:re.sub(r'\s+',' ',s).strip();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();ast=read('preview-attempt3/preview-ast.json');maps=read('preview-attempt3/conversion-map.json');math=[x for name in names for x in read(name+'/source-math.json')];asts=[read('preview-attempt3/'+name+'-source-ast.json') for name in names];sourceblocks=[block for a in asts for block in a['blocks']];sourcehrefs=[x['c'][2][0] for a in asts for x in nodes(a,'Link')];expectedstream=' '.join((p/name/'expected-prose-math-stream.txt').read_text() for name in names);aststream=stream(ast['blocks']);(o/'AST-prose-math-stream.txt').write_text(aststream)
# Compare the full content AST after reversing only recorded presentation mappings.
reverse_links={x['PDF_href']:x['source_href'] for x in maps['links']};reverse_images={x['PDF']:x['source'] for x in maps['images']}
def canonical(x):
 if isinstance(x,list):return [y for v in x if (y:=canonical(v)) is not None]
 if not isinstance(x,dict):return x
 t=x.get('t');c=x.get('c')
 if t in ['RawInline','RawBlock']:return None
 if t=='Str' and c=='':return None
 if t=='Span' and not c[1]:return None
 obj={k:canonical(v) for k,v in x.items()}
 if t=='Link':obj['c'][2][0]=reverse_links.get(obj['c'][2][0],obj['c'][2][0])
 if t=='Image':obj['c'][2][0]=reverse_images.get(obj['c'][2][0],obj['c'][2][0])
 if t in ['Para','Plain'] and not obj['c']:return None
 return obj
sourcecanonical=canonical(sourceblocks);finalcanonical=canonical(ast['blocks']);(o/'source-content-canonical-AST.json').write_text(json.dumps(sourcecanonical));(o/'preview-content-canonical-AST.json').write_text(json.dumps(finalcanonical))
sourceids=[dict(file=name+'.md',id=i) for name in names for i in re.findall(r'<a name="([^"]+)"></a>',(p/'remote'/f'{name}.md').read_text())];expectedanchors=[name+'--entry' for name in names]+[x['PDF'] for x in maps['anchors']];mappedlinks=[x['PDF_href'] for x in maps['links']];previewlinks=[x['c'][2][0] for x in nodes(ast,'Link')];sourceimgs=[x for a in asts for x in nodes(a,'Image')];previewimgs=list(nodes(ast,'Image'))
proof=dict(complete_prose_math_stream_exact_after_whitespace_folding=norm(aststream)==norm(expectedstream),complete_content_AST_exact_after_recorded_mapping=sourcecanonical==finalcanonical,all398_math_payloads_exact=[x['c'][1] for x in nodes(ast,'Math')]==[x['payload'] for x in math],all398_math_types_exact=[x['c'][0]['t'] for x in nodes(ast,'Math')]==['DisplayMath' if x['type']=='js-display-math' else 'InlineMath' for x in math],all21_source_anchors_mapped=[dict(file=x['source_file'],id=x['source']) for x in maps['anchors']]==sourceids,all24_preview_anchor_names_unique=len(expectedanchors)==len(set(expectedanchors))==24 and sorted(x['c'][0][0] for x in nodes(ast,'Span') if x['c'][0][0])==sorted(expectedanchors),all31_crossfile_links_mapped_in_order=[x for x in previewlinks if x.startswith('#')]==mappedlinks,all33_links_recover_source_hrefs=[reverse_links.get(x,x) for x in previewlinks]==sourcehrefs,all3_image_paths_recover_source=[reverse_images[x['c'][2][0]] for x in previewimgs]==[x['c'][2][0] for x in sourceimgs],all3_image_alts_exact=[x['c'][1] for x in previewimgs]==[x['c'][1] for x in sourceimgs],all6_original_assets_copied_exact=all((o/'assets'/f.name).read_bytes()==f.read_bytes() for f in (p/'remote/assets').iterdir()),source_style_exact=(o/'prof.sty').read_bytes()==(p.parents[5]/'assets/latex/prof.sty').read_bytes(),no_forced_emphasis_nodes=not any(list(nodes(ast,t)) for t in ['Strong','Emph']),no_unexpected_raw_AST_blocks=all(x['c']==['latex',r'\clearpage'] or x['c']==['latex',r'\Needspace{6\baselineskip}'] for x in nodes(ast,'RawBlock')),adaptations=['Protected inline/fenced math converted to Pandoc delimiters, then exact original payloads restored.','All3 files combined in teaching→hints→solutions order with PDF-only clearpage at document seams.','21 named anchors prefixed by source document, plus3 file-entry targets for fragment-free file links.','31 crossfile links rewritten to exact mapped native targets; external2 URLs unchanged.','3 actual SVGs exported to local PDF with Inkscape and included at0.85linewidth; originals/companions unchanged.','Current prof.sty; Needspace before section/hint/solution labels; explicit preamble glyph declarations only.'])
save('preview-attempt3/AST-content-check.json',proof)
f=o/'verified-build.pdf';b=f.read_bytes();assert b'%%EOF' in b[-1024:];d=fitz.open(stream=b,filetype='pdf');digest=hashlib.sha256(b).hexdigest();dest=d.resolve_names();links=[dict(from_page=i+1,**x) for i,page in enumerate(d) for x in page.get_links()];named=[x for x in links if 'nameddest' in x];fonts=sorted({sp['font'] for page in d for block in page.get_text('dict')['blocks'] if 'lines' in block for line in block['lines'] for sp in line['spans']});hp={f'h{i}':dest[f'hints--h{i}']['page']+1 for i in range(1,6)};ap={f'a{i}':dest[f'solutions--a{i}']['page']+1 for i in range(1,6)}
pdfproof=dict(canonical_file='preview-attempt3/verified-build.pdf',sha256=digest,bytes=len(b),pages=len(d),digest_matches_successful_build=digest==read('preview-attempt3/preview-check.json')['pdf_sha256'],all24_targets_exist=all(x in dest for x in expectedanchors),all31_logical_links_in_order=['#'+k for k,g in itertools.groupby(x['nameddest'] for x in named)]==mappedlinks,all_native_links_resolve=all(x['nameddest'] in dest and x.get('page')==dest[x['nameddest']]['page'] and 0<=x['page']<len(d) for x in named),all2_external_URLs_preserved=set(x.get('uri') for x in links if x.get('uri'))==set(x for x in sourcehrefs if x.startswith('https:')),hint_pages=hp,solution_pages=ap,hint_solution_page_sets_disjoint=set(hp.values()).isdisjoint(ap.values()),all_solutions_after_hints=min(ap.values())>max(hp.values()),font_inventory=fonts,no_bold_or_italic_prose_font=all(not any(t in x for t in ['Bold','Oblique','Slant']) and ('Italic' not in x or 'Math' in x) for x in fonts),destinations=dest,links=links,scope='Native PDF annotation/destination data; no PDF-viewer clicks; no inference to GitHub client behavior.')
label_pages={}
for i,page in enumerate(d,1):
 text=page.get_text()
 for m in re.finditer(r'(?m)^(Q[1-5]\.|Hint Q[1-5]|Solution Q[1-5])(?:$| )',text):
  label=m[1]
  if label.startswith('Q') or re.search(r'(?m)^'+re.escape(label)+r'$',text):label_pages.setdefault(label,[]).append(i)
landing=[]
for i in range(1,6):
 for doc,prefix,label in [('teaching','q',f'Q{i}.'),('hints','h',f'Hint Q{i}'),('solutions','a',f'Solution Q{i}')]:
  key=doc+'--'+prefix+str(i);pages=sorted(set(label_pages.get(label,[])));landing.append(dict(target=key,label=label,target_page=dest[key]['page']+1,label_pages=pages,correct_target_page=dest[key]['page']+1 in pages))
pdfproof['all15_task_help_targets_land_on_label_pages']=all(x['correct_target_page'] for x in landing);pdfproof['target_label_correspondence']=landing
section_landing=[]
for ident,label in [(f'teaching--s{i}',f'Section {i} ') for i in range(1,6)]+[('teaching--exam','Section 6 ')]:
 pages=[i+1 for i,page in enumerate(d) if label in page.get_text()]
 section_landing.append(dict(target=ident,label=label,target_page=dest[ident]['page']+1,label_pages=pages,correct=dest[ident]['page']+1 in pages))
for file in ['teaching','hints','solutions']:
 title=(p/'remote'/(file+'.md')).read_text().splitlines()[0];pages=[i+1 for i,page in enumerate(d) if norm(title) in norm(page.get_text())];ident=file+'--entry';section_landing.append(dict(target=ident,label=title,target_page=dest[ident]['page']+1,label_pages=pages,correct=dest[ident]['page']+1 in pages))
pdfproof['all9_section_and_entry_targets_land_on_label_pages']=all(x['correct'] for x in section_landing);pdfproof['section_and_entry_correspondence']=section_landing
save('preview-attempt3/navigation-fonts.json',pdfproof)
rasters=[]
for i,page in enumerate(d,1):
 pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5));im=Image.open(o/f'page-{i:02}.png').convert('RGB');rasters.append(dict(page=i,dimensions_equal=im.size==(pix.width,pix.height),all_RGB_pixels_exact=im.tobytes()==pix.samples,sha256=sha(o/f'page-{i:02}.png')))
save('preview-attempt3/exact-PDF-raster-correspondence.json',dict(canonical_sha256=digest,rasters=rasters,canonical_bytes_stable=f.read_bytes()==b,main_pdf_identical=(o/'main.pdf').read_bytes()==b))
print(json.dumps(dict(AST=proof,PDF={k:v for k,v in pdfproof.items() if k not in ['destinations','links']},all_rasters_exact=all(x['all_RGB_pixels_exact'] for x in rasters)),indent=2))
