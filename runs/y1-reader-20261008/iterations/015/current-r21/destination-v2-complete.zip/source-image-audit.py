from pathlib import Path
import json,hashlib,re,fitz
p=Path(__file__).parent;sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def read(n):return json.loads((p/n).read_text())
def save(n,v):
 with (p/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
sourceproof=[]
for name,local,off,frozen in [('lecture16',p.parent/'source/lec16.pdf',p/'official-source-lec16.pdf',p/'frozen-source-lec16.pdf'),('chapter9',p.parent/'primary-qm/MIT22_51F12_Ch9.pdf',p/'official-supplement-ch9.pdf',p/'frozen-supplement-ch9.pdf')]:
 d=fitz.open(off);f=p/(name+'-first-page-text.txt');f.write_text(d[0].get_text());sourceproof.append(dict(name=name,official_file=off.name,immutable_file=frozen.name,local_file=str(local),all_three_bytes_exact=local.read_bytes()==off.read_bytes()==frozen.read_bytes(),bytes=off.stat().st_size,sha256=sha(off),pages=len(d),first_page_extracted=f.name,scope='Exact complete PDF byte identity and first-page target-title/provenance inspection. Full PDF technical/visual source audit belongs to author/root; not claimed here.'))
save('source-PDF-identity.json',sourceproof)
s=(p/'remote/teaching.md').read_text();images=read('teaching/image-markup.json');sourceimgs=re.findall(r'!\[([^\]]*)\]\(([^)]+)\)',s);rawprefix='/alverstris/PROF-Skill.md-/raw/f531ccd1a3ec4b4918b96fbab30a7f6d8c03aafa/runs/y1-reader-20261008/iterations/015/current-r21/author/v2/';imagecheck=dict(all3_exact_alt_text=[x['alt'] for x in images]==[x[0] for x in sourceimgs],all3_exact_immutable_image_paths=[x['src'] for x in images]==[rawprefix+x[1] for x in sourceimgs],actual_image_styles=[x.get('style') for x in images],referenced_format='SVG; all3 corresponding PNG companions also freshly fetched and inspected',actual_live_embedded_pixels='unobserved');save('image-reference-check.json',imagecheck)
print(json.dumps(dict(source_identity=sourceproof,image_reference_check=imagecheck),indent=2))
