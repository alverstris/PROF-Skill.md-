from pathlib import Path
import json,hashlib,base64,re,datetime
root=Path('.').resolve();reader=root/'reader'
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
route=json.loads((reader/'route.json').read_text());files={f['id']:f for f in route['files']}
raw=(reader/'runtime/ledger.jsonl').read_bytes();events=[json.loads(l) for l in raw.splitlines()];previous='0'*64
for i,e in enumerate(events):
 obj={k:v for k,v in e.items() if k!='sha256'}
 assert e['index']==i and e['previous']==previous and sha(canonical(obj))==e['sha256']
 previous=e['sha256']
expected=[];actual=[e['data']['step_id'] for e in events if e['event']=='state_commit']
for s in route['steps']:
 expected.append(s['id'])
 if s['kind']=='figure':expected.append(s['receipt_step_id'])
assert actual==expected,(actual,expected)
failures=[e for e in events if e['event'] in ['rejected','stdout_incomplete'] or (e['event']=='call_finished' and e['data']['outcome']!='success')]
assert not failures,failures
access=[e for e in events if e['event']=='actual_access'];assert len(access)==33
checks=[]
for step,ev in zip(route['steps'],access):
 f=files[step['file_id']];b=Path(f['path']).read_bytes()
 assert len(b)==f['size'] and sha(b)==f['sha256']
 if step['kind']=='text':b=b[step['start']:step['end']]
 d=ev['data'];assert d['verified'] and d['sha256']==sha(b) and d['bytes']==len(b)
 result=json.loads((reader/'raw-results'/(step['id']+'-exec.json')).read_text())
 assert result['exit_code']==0 and not result.get('session_id')
 if step['kind']=='text':assert result['output'].encode()==b,('actual tool output differs',step['id'])
 checks.append({'step':step['id'],'file_id':f['id'],'bytes':len(b),'sha256':sha(b),'saved_actual_output_verified':True})
figures=[]
for s in route['steps']:
 if s['kind']!='figure':continue
 fid=s['id'];r=json.loads((reader/'raw-results'/(fid+'-result.json')).read_text())
 cap=json.loads((reader/'raw-results'/(fid+'-capture.json')).read_text());receipt=json.loads(Path(s['receipt_file']).read_text())
 url=r['image_url'];m=re.fullmatch(r'data:([^;,]+);base64,(.*)',url,re.S);assert m
 imagebytes=base64.b64decode(m[2],validate=True)
 assert imagebytes==Path(files[s['file_id']]['path']).read_bytes()
 assert receipt['result_metadata']['image_url_sha256']==sha(url.encode())
 assert receipt['result_metadata']['image_url_chars']==len(url)
 assert receipt['tool_call_id']==cap['tool_call_id'] and receipt['completed_at']==cap['completed_at']
 assert receipt['invocation']==cap['invocation']=={'path':files[s['file_id']]['path'],'detail':'original'}
 accepted=next(e for e in events if e['event']=='figure_receipt_accepted' and e['data']['figure_step_id']==fid)
 assert accepted['data']['receipt']==receipt
 figures.append({'id':fid,'original_result_sha256':sha((reader/'raw-results'/(fid+'-result.json')).read_bytes()),'image_sha256':sha(imagebytes),'image_url_sha256':sha(url.encode()),'receipt_correlated':True,'local_identity_provenance':cap.get('identity_provenance')})
snapshots=sorted((reader/'checkpoints').glob('*-ledger.jsonl'));old=b''
assert len(snapshots)==37
for p in snapshots:
 b=p.read_bytes();assert b.startswith(old) and raw.startswith(b);old=b
assert old==raw
record={'schema':'d015-author-reader-access-admission-v1','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mechanical_admission':True,'events':len(events),'successful_stages':len(actual),'stages':actual,'text_output_count':30,'actual_access_count':33,'full_baseline_bytes':247840,'full_teaching_bytes':186982,'all_tool_text_outputs_exact':True,'all_checkpoint_prefixes_preserved':True,'checkpoints':len(snapshots),'unresolved_launcher_failure_calls':failures,'files':checks,'figures':figures,'post_reading_operational_edit_failure':'Reader reconstruction.md discloses one failed apply_patch reordering attempt after the original report was complete; no subject/ledger/report change. Not a launcher failure. Displayed error transcribed, not synthesized as a raw tool object.','limits':'Exact input/order/result integrity only; cannot prove semantic comprehension, absence of pretraining or technical isolation. Reader report and independent semantic/destination checks remain separately required.'}
Path('evidence/reader-access-admission.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['files','figures','stages']},indent=2))
