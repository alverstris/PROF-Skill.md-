from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
out=Path(__file__).resolve().parents[1]/'teaching/figures'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'font.weight':'normal','axes.labelweight':'normal','axes.titleweight':'normal','axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
blue='#176c9e'; red='#b84439'; gray='#4d5964'
fig,ax=plt.subplots(figsize=(9,5),dpi=100); fig.subplots_adjust(left=.10,right=.96,bottom=.15,top=.90)
x=np.linspace(-4.2,4.2,601); ax.plot(x,np.exp(-x*x/2),color=blue,lw=2.7,label=r'$y=e^{-x^2/2}$'); ax.set(xlim=(-4.2,4.2),ylim=(-.04,1.13),xlabel='x',ylabel='y'); ax.axhline(0,color=gray,lw=.8); ax.axvline(0,color=gray,lw=.8); ax.scatter([0],[1],color=blue,s=32); ax.annotate('(0, 1)',(0,1),xytext=(.45,1.035)); ax.grid(alpha=.18); ax.legend(loc='upper left',frameon=False); fig.savefig(out/'gaussian.png',dpi=100); plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5.6),dpi=100); fig.subplots_adjust(left=.13,right=.81,bottom=.14,top=.91)
x=np.linspace(0,1.65,401); ax.plot(x,x*x,color=blue,lw=2.5,label=r'Curve $y=x^2$'); t=np.linspace(-.15,1.8,200); ax.plot(t,t,ls='--',color=gray,lw=2,label='Line from origin: slope 1'); ax.plot(t,2*t-1,color=red,lw=2,label='Tangent at P: slope 2'); ax.scatter([1],[1],s=45,color='black',zorder=5); ax.annotate('P = (1, 1)',(1,1),xytext=(.12,1.58),arrowprops={'arrowstyle':'-','color':gray}); ax.axhline(0,color=gray,lw=.8); ax.axvline(0,color=gray,lw=.8); ax.set(xlim=(-.2,1.85),ylim=(-.25,2.8),xlabel='x',ylabel='y'); ax.set_aspect('equal',adjustable='box'); ax.grid(alpha=.16); ax.legend(loc='upper left',bbox_to_anchor=(1.01,1),frameon=False,fontsize=11); fig.savefig(out/'tangent-ray.png',dpi=100); plt.close(fig)
fig,ax=plt.subplots(figsize=(9,6),dpi=100); fig.subplots_adjust(left=.10,right=.78,bottom=.12,top=.94)
x=np.linspace(-3,3,1001)
for j,a in enumerate([-.5,-1,-2,.5,1,2]):
 ax.plot(x,a*x*x,color=gray,lw=1.25,label=r'Parabolas $y=ax^2$' if j==0 else None)
t=np.linspace(0,2*np.pi,1001)
for j,c in enumerate([.75,1.5]):
 ax.plot(2*np.sqrt(c)*np.cos(t),np.sqrt(2*c)*np.sin(t),color=blue,lw=2.4,ls='-' if j==0 else '--',label=f'Ellipse C = {c:g}')
ax.axhline(0,color=gray,lw=.8);ax.axvline(0,color=gray,lw=.8);ax.set(xlim=(-2.9,2.9),ylim=(-2.4,2.4),xlabel='x',ylabel='y');ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.13);ax.legend(loc='upper left',bbox_to_anchor=(1.01,1),frameon=False,fontsize=11);fig.savefig(out/'perpendicular-families.png',dpi=100);plt.close(fig)
