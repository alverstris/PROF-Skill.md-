from pathlib import Path
import sympy as s,json,re,hashlib,datetime
x=s.symbols('x',real=True); a,C=s.symbols('a C',real=True)
checks=[]
def ck(name,result):
 ok=bool(result); assert ok,name;checks.append({'check':name,'pass':ok})
for name,y,rhs,x0,y0 in [
('direct worked',x**3+x+2,3*x*x+1,0,2),
('Gaussian',a*s.exp(-x*x/2),-x*a*s.exp(-x*x/2),0,a),
('negative-root worked',-s.sqrt(x*x+4),-x/s.sqrt(x*x+4),0,-2),
('Q1 zero',s.Integer(0),0,0,0),
('Q1 negative',-2*s.exp(-x*x/2),2*x*s.exp(-x*x/2),0,-2),
('Q2 nonconstant',1+s.exp(-x*x/2),-x*s.exp(-x*x/2),0,2),
('Q2 constant',s.Integer(1),0,0,1),
('Q3',-2*x**3,-6*x*x,-1,2),
('Q4',-s.sqrt(3-x*x/2),x/(2*s.sqrt(3-x*x/2)),2,-1),
('Q5a',x*x+2,2*x,1,3),
('Q5b',s.sqrt(x*x+3),x/s.sqrt(x*x+3),1,2)]:
 ck(name+' derivative',s.simplify(s.diff(y,x)-rhs)==0);ck(name+' initial',s.simplify(y.subs(x,x0)-y0)==0)
ck('parabola family differential',s.simplify(s.diff(a*x*x,x)-2*(a*x*x)/x)==0)
ck('ellipse derivative of conserved expression',s.simplify(x/2+s.symbols('y')*(-x/(2*s.symbols('y'))))==0)
ck('Q4 slopes',s.Rational(-1)*1==-1)
ck('Q5b slopes',s.Rational(-2)*s.Rational(1,2)==-1)
ck('ellipse semiaxis ratio',s.simplify(s.sqrt(6)/s.sqrt(3))==s.sqrt(2))
ck('source f sign correction',s.diff(-x*x/2,x)==-x)
ck('source a=-2 correction',s.diff(-2*x*x,x)==-4*x)
Path('author/calculation-checks.json').write_text(json.dumps({'checks':checks,'count':len(checks),'scope':'Symbolic checks plus stated domains separately reconstructed in author-audit.md; not observed learning.'},indent=2)+'\n')
main=Path('teaching/main.md').read_text();prompts=Path('author/prompts-only.md').read_text()
for q in range(1,6):
 block=re.search('Q'+str(q)+r' —.*?\n\n(.*?)(?=\n\nQ[1-5] —|\Z)',prompts,re.S).group(1).strip()
 ck('exact frozen prompt Q'+str(q),block in main)
files=[Path('teaching/main.md'),Path('teaching/hints.md'),Path('teaching/solutions.md')]; inv=[];nav=[];anchorfiles={}
for p in files:
 st=p.read_text()
 for anchor in re.findall(r'<a id="([^"]+)"></a>',st):
  ck('unique anchor '+anchor,anchor not in anchorfiles);anchorfiles[anchor]=p.name
 ck('plain prose markup '+p.name,not re.search(r'(?m)^\s*(#{1,6}\s|[0-9]+\. )|\*\*|(?<!\*)\*(?!\*)|^---+$',st))
 ck('no controls '+p.name,not any(ord(c)<32 and c not in '\n\t' for c in st))
 for kind,pat in [('inline',r'\$'+chr(96)+r'(.*?)'+chr(96)+r'\$'),('display',chr(96)*3+r'math\n(.*?)\n'+chr(96)*3)]:
  for m in re.finditer(pat,st,re.S):
   expr=m.group(1);ck('no literal angle math '+p.name+str(m.start()),'<' not in expr and '>' not in expr);ck('strict command delimiter '+p.name+str(m.start()),not re.search(r'\\(?:lt|gt)(?! )',expr));inv.append({'file':'teaching/'+p.name,'line':st[:m.start()].count('\n')+1,'start':m.start(),'kind':kind,'expression':expr})
 for m in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)',st):
  label,url=m.groups()
  if '://' not in url:
   target,frag=url.split('#');target=target or p.name;nav.append({'from':'teaching/'+p.name,'line':st[:m.start()].count('\n')+1,'label':label,'href':url,'target':'teaching/'+target,'fragment':frag})
for n in nav:ck('navigation '+n['from']+':'+str(n['line'])+n['label'],anchorfiles[n['fragment']]==Path(n['target']).name)
inv=sorted(inv,key=lambda e:(files.index(Path(e['file'])),e['start']))
for i,e in enumerate(inv,1):e['id']='E'+str(i).zfill(3)
Path('author/math-inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
Path('author/navigation-inventory.json').write_text(json.dumps({'first_use_priority':{'source':'teaching/hints.md#d015-r36-hint-q5','click_label':'Return to Q5','target':'teaching/main.md#d015-r36-main-q5','condition':'Before visiting main or image URLs; no scroll/full-page capture before settled target observation.'},'routes':nav},indent=2)+'\n')
Path('author/mechanical-checks.json').write_text(json.dumps({'check_count':len(checks),'all_pass':True,'math_count':len(inv),'route_count':len(nav),'checks':checks},indent=2)+'\n')
print('symbolic and mechanical checks',len(checks),'expressions',len(inv),'routes',len(nav))
