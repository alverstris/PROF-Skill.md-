from pathlib import Path
import hashlib,json,shutil,zipfile,datetime
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE.parent
def digest(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 b=p.read_bytes();return {'path':str(p.relative_to(BASE)),'bytes':len(b),'sha256':digest(b)}
def write(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
ev=BASE/'evidence'
for rel in ['final-disposition.md','destination/destination-review.md']:
 src=ROOT/'root-review-d015-r36'/rel;dst=ev/'root-original'/Path(rel).name
 shutil.copyfile(src,dst);assert src.read_bytes()==dst.read_bytes()
for stem in ['d015-r36-root-review-20261012.zip','d015-r36-root-review-20261012.manifest.json']:
 shutil.copyfile(ROOT/'source-audit-archives'/stem,ev/stem)
archive=ev/'d015-r36-root-review-20261012.zip'
assert len(archive.read_bytes())==9602671 and digest(archive.read_bytes())=='dffff1f17534fc9d121e714fe783920d9162601c00319fe6f63427e70e337a77'
bindings=[]
manifest=json.loads((ev/'d015-r36-root-review-20261012.manifest.json').read_text())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==63
 for m in manifest['members']:
  b=z.read(m['path']);assert len(b)==m['bytes'] and digest(b)==m['sha256']
 bindings.append({**ident(archive),'actual_member_bindings_verified':63})
for version in ['v10','v11']:
 stem=version+'-d015-r36-20261012';src=ROOT/'root-destination-tools'/stem
 shutil.copyfile(src.with_suffix('.zip'),ev/(stem+'.zip'))
 shutil.copyfile(src/'MANIFEST.json',ev/(stem+'-manifest.json'))
 m=json.loads((src/'MANIFEST.json').read_text())
 with zipfile.ZipFile(ev/(stem+'.zip')) as z:
  assert z.read(stem+'/MANIFEST.json')==(src/'MANIFEST.json').read_bytes()
  assert len(z.namelist())==len(m['files'])+1
  for f in m['files']:
   b=z.read(stem+'/'+f['path']);assert len(b)==f['bytes'] and digest(b)==f['sha256']
 bindings.append({**ident(ev/(stem+'.zip')),'actual_member_bindings_verified':len(m['files'])+1})
write(ev/'released-root-archive-bindings.json',{'scope':'Necessary release identity and declared-member binding, not a repeated semantic or browser audit.','archives':bindings})
opaque=json.loads((ev/'preserved-archives.json').read_text())
opaque['files']=[]
for p in sorted((ev/'preserved-archives').glob('*')):
 assert p.read_bytes()==(ROOT/'source-audit-archives'/p.name).read_bytes()
 opaque['files'].append({**ident(p),'preserved_exact':True,'opaque_not_unpacked':True})
assert len(opaque['files'])==8
write(ev/'preserved-archives.json',opaque)
state=BASE/'work/.prof-state';topic=json.loads((state/'topics/differential-equations.json').read_text());project=json.loads((state/'manifest.json').read_text())
final=ev/'final-adjudication.md';witness={'path':str(final.relative_to(BASE)),'sha256':digest(final.read_bytes()),'locator':{'kind':'lines','start':3,'end':len(final.read_text().splitlines())}}
for k in ['T11','T12']:
 topic['requirements'][k].update(status='pass',reason='Complete whole-route independent, access, technical and exact destination reviews support this duty with the specific witnesses and limits in the final adjudication.',evidence=[witness],dependencies=json.loads((BASE/'work/topic-dependencies.json').read_text()))
for check in project['output_checks']:
 if check['status']=='pending':
  check.update(status='pass',reason='Completed '+check['id']+' review is recorded substantively in the final adjudication, with unchanged original independent reports and exact artifact identities.',evidence=[witness],dependencies=json.loads((BASE/'work/project-dependencies.json').read_text()))
write(state/'topics/differential-equations.json',topic);write(state/'manifest.json',project)
(state/'RUN.md').write_text('D015 final full-route disposition completed after all independent audits. Exact incoming r36 activation and six frozen outputs remain unchanged. Detailed verdict and limits: evidence/final-adjudication.md. Original request: inputs/operational-handover.json. Original reports preserved in evidence archives. No material failure; r37 is metadata-only and not yet operative until publication/readback. Next: publish complete package/evidence, verify actual bytes, then close only D015 and prepare fresh D016 minimal inputs. Never edit the frozen teaching.\n')
print(json.dumps({'root_archives':bindings,'opaque_files':len(opaque['files']),'final_adjudication':ident(final)},indent=2))
