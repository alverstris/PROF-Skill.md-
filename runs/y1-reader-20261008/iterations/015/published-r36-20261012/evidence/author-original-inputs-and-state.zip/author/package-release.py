from pathlib import Path
import json,hashlib,zipfile,shutil
B=Path(__file__).resolve().parents[1]; E=B/'evidence'
prefix='runs/y1-reader-20261008/iterations/015/published-r36-20261012/'
def h(b):return hashlib.sha256(b).hexdigest()
def info(p,remote=None):
 b=p.read_bytes();return {'local':str(p),'remote':remote or prefix+str(p.relative_to(B)),'bytes':len(b),'sha256':h(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def wr(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
for n in ['report.md','reconstruction.md']:shutil.copyfile(B/'reader'/n,E/('sasis-'+n))
shutil.copyfile(B.parent/'d015-current-r36-whole-technical/report.txt',E/'technical-report.txt')
shutil.copyfile(B.parent/'root-independent-reader-mechanics/d015-r36/final/report.md',E/'independent-mechanics-report.md')
for n in ['final-topic-readiness','final-project-readiness']:
 d=json.loads((E/(n+'.json')).read_text());assert not d['defects']
package=json.loads((E/'package-candidate.json').read_text())
package.update(status='All current audits complete; metadata-only r37 approved for publication. Becomes operative only after actual published-byte readback.',incoming_commit='cb5f12cb9762839fade6841c161cdc8c670894cf',teaching_commit='97e10125d66e612e3f0446ab1f8460c6fd4064a5',behavioral_changes=False)
wr(E/'package-release.json',package)
paths=[]
for sub in ['author','inputs','work/.prof-state']:
 paths.extend(p for p in (B/sub).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths.append(B/'input-identities.json')
for n in ['admission.json','internal-hashes.json','internal-hashes-profile.json','author-baseline-access.jsonl','baseline-route.json','verification-repeat.json','topic-dependencies.json','project-dependencies.json','package-git-modes.json','publication1-entries.json','publication1-readback.json','quick_validate.py']:
 paths.append(B/'work'/n)
archive=E/'author-original-inputs-and-state.zip';members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(paths)):
  rel=str(p.relative_to(B));b=p.read_bytes();z.writestr(rel,b);members.append({'path':rel,'bytes':len(b),'sha256':h(b)})
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(members)
 for m in members:
  b=z.read(m['path']);assert len(b)==m['bytes'] and h(b)==m['sha256']
wr(E/'author-original-inputs-and-state-manifest.json',{'archive':str(archive.relative_to(B)),'bytes':archive.stat().st_size,'sha256':h(archive.read_bytes()),'members':len(members),'files':members,'scope':'All admitted original inputs, exact incoming package, author records and final helper state. Original independent evidence remains in separate unchanged archives. Excludes raw historical queue/RUN copies and opaque future source semantic contents.'})
(E/'README.md').write_text('D015 complete evidence and metadata-only r37 release\n\nThe [final adjudication](final-adjudication.md) distinguishes technical, SASIS, access, rendered, and portability findings and limitations. Original [SASIS report](sasis-report.md), [chronological reconstruction](sasis-reconstruction.md), [technical report](technical-report.txt), [mechanics report](independent-mechanics-report.md), and [root final disposition](root-original/final-disposition.md) are preserved byte-for-byte. Their full sealed inputs, access records, raw outputs, reports, scripts, and unsuccessful attempts are retained in the adjacent archives with exact member manifests. The 9602671-byte root archive includes complete actual GitHub destination records, images and original adapter failures. The v10/v11 tool archives preserve the corresponding original parser provenance.\n\nThe [package release manifest](package-release.json) identifies all 36 files and the metadata-only scope. The earlier candidate record remains unchanged as an earlier conditional record. Frozen teaching and help are in [main](../teaching/main.md), [hints](../teaching/hints.md), and [solutions](../teaching/solutions.md). The final readiness records check declared consistency only. Their original locator-error outputs are retained with the precise correction. Future source-audit archives in preserved-archives are opaque exact copies; no claim of semantic reading is made. Canonical closure follows only after actual release-byte readback.\n')
files=[]
for f in package['files']:
 p=B/'release-prof'/f['path'];item=info(p,f['path']);assert item['bytes']==f['bytes'] and item['sha256']==f['sha256'] and item['git_blob']==f['git_blob'];item['upload']=f['changed'];files.append(item)
for p in sorted(E.rglob('*')):
 if p.is_file():
  item=info(p);item['upload']=True;files.append(item)
for item in json.loads((B/'work/publication1-entries.json').read_text()):
 f=info(B/item['path']);assert f['git_blob']==item['sha'];f['upload']=False;files.append(f)
assert len({x['remote'] for x in files})==len(files)
plan={'parent':'97e10125d66e612e3f0446ab1f8460c6fd4064a5','base_tree':'ba6828823270f5611674e4bc8b5443a5f2e44583','files':files}
wr(B/'work/release-plan.json',plan)
print(json.dumps({'files':len(files),'bytes':sum(f['bytes'] for f in files),'upload_files':sum(f['upload'] for f in files),'author_archive_bytes':archive.stat().st_size,'author_archive_members':len(members)},indent=2))
