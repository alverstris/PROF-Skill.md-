from pathlib import Path
import subprocess,json,hashlib,sys,datetime
planpath,pin,outpath=sys.argv[1:]
plan=json.loads(Path(planpath).read_text())
repo='/workspace/scratch/f9c0b7fc7e76/prof-iteration'
entries=plan['files']
head=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=repo).decode().split()[0]
assert head==pin,('main mismatch',head,pin)
subprocess.run(['git','fetch','--no-tags','origin',pin],cwd=repo,check=True,capture_output=True)
rawtree=subprocess.check_output(['git','ls-tree','-rz','--full-tree',pin,'--']+[e['remote'] for e in entries],cwd=repo)
tree={}
for item in rawtree.split(b'\0'):
 if item:
  meta,path=item.split(b'\t',1);mode,kind,blob=meta.decode().split();assert kind=='blob'
  assert mode=='100644',('unexpected mode',path,mode)
  tree[path.decode()]=blob
assert set(tree)=={e['remote'] for e in entries},('tree paths mismatch',len(tree),len(entries))
for e in entries:assert tree[e['remote']]==e['git_blob'],e['remote']
shas=list(dict.fromkeys(tree.values()))
subprocess.run(['git','fetch','--no-tags','origin','--stdin'],cwd=repo,input=''.join(s+'\n' for s in shas).encode(),check=True,capture_output=True)
raw=subprocess.run(['git','cat-file','--batch'],cwd=repo,input=''.join(s+'\n' for s in shas).encode(),check=True,capture_output=True).stdout
pos=0;blobs={}
for wanted in shas:
 lineend=raw.index(b'\n',pos);header=raw[pos:lineend].decode().split();got,kind,size=header;size=int(size)
 assert got==wanted and kind=='blob'
 pos=lineend+1;b=raw[pos:pos+size];pos+=size
 assert raw[pos:pos+1]==b'\n';pos+=1
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==wanted
 blobs[wanted]=b
assert pos==len(raw)
checked=[]
for e in entries:
 b=blobs[e['git_blob']];local=Path(e['local']).read_bytes()
 assert b==local and len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'],e['remote']
 checked.append({'path':e['remote'],'bytes':len(b),'sha256':e['sha256'],'git_blob':e['git_blob'],'actual_git_bytes_match':True})
record={'schema':'d015-complete-publication-readback-v1','checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pin':pin,'tree':subprocess.check_output(['git','rev-parse',pin+'^{tree}'],cwd=repo).decode().strip(),'actual_main':head,'count':len(checked),'bytes':sum(e['bytes'] for e in checked),'files':checked,'all_actual_bytes_match':True}
Path(outpath).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
