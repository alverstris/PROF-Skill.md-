from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);dest=Path(sys.argv[2]);checks=[]
def check(p,expected):
 b=p.read_bytes();got=hashlib.sha256(b).hexdigest();assert got==expected,(p,got,expected)
 checks.append({'path':str(p.relative_to(root)),'bytes':len(b),'sha256':got})
prof=root/'references/sasis'
p=json.loads((prof/'profile-manifest.json').read_text());base=prof/p['file_hashes_base_directory']
for n,h in p['file_hashes'].items():check(base/n,h)
for n,h in p['control_file_hashes'].items():check(prof/n,h)
for s in p['subject_files']:check(prof/s['path'],s['sha256'])
r=json.loads((base/'release-manifest.json').read_text())
for s in r['subjects']:check(base/s['path'],s['sha256'])
check(base/'student-baseline.txt',r['combined_baseline_sha256'])
c=json.loads((base/'chemistry/freeze-manifest.json').read_text())
for f in c['files']:
 path=base/'chemistry'/f['path']
 if path.exists():check(path,f['sha256'])
assert len(checks)==34,len(checks)
dest.write_text(json.dumps({'count':len(checks),'all_match':True,'checks':checks,'external_historical_references':'Not claimed package-local; unchanged historical source/archive identities preserved.'},indent=2)+'\n')
print('All',len(checks),'internal declarations match actual bytes.')
