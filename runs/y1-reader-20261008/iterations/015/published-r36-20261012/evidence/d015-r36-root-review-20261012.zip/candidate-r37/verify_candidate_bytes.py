#!/usr/bin/env python3
"""Audit actual candidate bytes without interpreting instructional bodies."""
import collections
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
BASE = ROOT / 'd015-clean-r36-20261012'
CANDIDATE = BASE / 'release-prof'
REPO = ROOT / 'prof-iteration'
OUT = ROOT / 'root-review-d015-r36/candidate-r37'
PUBLISHED_R36 = '97e10125d66e612e3f0446ab1f8460c6fd4064a5'
R36_PARENT = 'cb5f12cb9762839fade6841c161cdc8c670894cf'
EXPECTED_TREE = 'ba6828823270f5611674e4bc8b5443a5f2e44583'
EXPECTED_CHANGED = {'SKILL.md', 'references/sasis.md',
                    'references/sasis/student-testing-contract.txt',
                    'references/sasis/profile-manifest.json'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob_id(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def safe(path):
    p = PurePosixPath(path)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in path and p.as_posix() == path
    return path


class GitBytes:
    def __init__(self):
        self.p = subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'],
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.cache, self.trees, self.identities = {}, {}, []

    def read(self, oid, kind):
        assert len(oid) == 40 and all(c in '0123456789abcdef' for c in oid)
        if oid not in self.cache:
            self.p.stdin.write((oid + '\n').encode())
            self.p.stdin.flush()
            header = self.p.stdout.readline().decode().strip().split()
            assert len(header) == 3 and header[0] == oid
            size = int(header[2])
            data = self.p.stdout.read(size)
            assert len(data) == size and self.p.stdout.read(1) == b'\n'
            actual = hashlib.sha1(header[1].encode() + b' ' + str(size).encode() + b'\0' + data).hexdigest()
            assert actual == oid
            self.cache[oid] = (header[1], data)
            self.identities.append({'oid': oid, 'type': header[1], 'bytes': size, 'sha256': sha(data),
                                    'object_id_recomputed': actual})
        actual_kind, data = self.cache[oid]
        assert actual_kind == kind
        return data

    def commit(self, oid):
        headers = self.read(oid, 'commit').split(b'\n\n', 1)[0].splitlines()
        tree = [x[5:].decode() for x in headers if x.startswith(b'tree ')]
        parents = [x[7:].decode() for x in headers if x.startswith(b'parent ')]
        assert len(tree) == 1
        return tree[0], parents

    def tree(self, oid):
        if oid not in self.trees:
            data = self.read(oid, 'tree')
            i, entries = 0, {}
            while i < len(data):
                j, k = data.index(b' ', i), data.index(b'\0', i)
                mode, name, child = data[i:j].decode(), data[j + 1:k].decode(), data[k + 1:k + 21].hex()
                assert name not in entries
                entries[name] = {'mode': mode, 'oid': child}
                i = k + 21
            assert i == len(data)
            self.trees[oid] = entries
        return self.trees[oid]

    def blob(self, tree, path):
        parts = PurePosixPath(safe(path)).parts
        for i, part in enumerate(parts):
            entry = self.tree(tree)[part]
            if i != len(parts) - 1:
                assert entry['mode'] == '40000'
                tree = entry['oid']
        assert entry['mode'] in ('100644', '100755')
        return entry, self.read(entry['oid'], 'blob')

    def close(self):
        self.p.stdin.close()
        self.p.wait()
        assert self.p.returncode == 0


def main():
    description_paths = [BASE / 'inputs/prof-package-manifest.json',
                         BASE / 'evidence/package-candidate.json',
                         BASE / 'evidence/package-internal-hashes.json']
    descriptions = [p.read_bytes() for p in description_paths]
    r36_manifest, candidate_claim, hashes_claim = map(json.loads, descriptions)
    assert r36_manifest['commit'] == R36_PARENT
    assert r36_manifest['count'] == candidate_claim['count'] == 36
    assert r36_manifest['bytes'] == candidate_claim['bytes'] == 907146
    assert candidate_claim['version'] == '2026-10-12-r37'
    old_manifest = {safe(r['path']): r for r in r36_manifest['files']}
    claimed = {safe(r['path']): r for r in candidate_claim['files']}
    assert len(old_manifest) == len(claimed) == 36 and set(old_manifest) == set(claimed)
    all_nodes = list(CANDIDATE.rglob('*'))
    assert all(not p.is_symlink() for p in all_nodes)
    actual_paths = {str(p.relative_to(CANDIDATE)) for p in all_nodes if p.is_file()}
    assert actual_paths == set(old_manifest)

    g = GitBytes()
    tree, parents = g.commit(PUBLISHED_R36)
    assert tree == EXPECTED_TREE and parents == [R36_PARENT]
    parent_tree, _ = g.commit(R36_PARENT)
    assert parent_tree == r36_manifest['tree']
    old, new, identities = {}, {}, []
    for path in sorted(actual_paths):
        current_entry, current_data = g.blob(tree, path)
        parent_entry, parent_data = g.blob(parent_tree, path)
        assert current_entry == parent_entry and current_data == parent_data
        old[path], new[path] = current_data, (CANDIDATE / path).read_bytes()
        baseline = old_manifest[path]
        candidate = claimed[path]
        assert len(current_data) == baseline['bytes'] and sha(current_data) == baseline['sha256']
        assert current_entry['oid'] == baseline['git_blob']
        assert len(new[path]) == candidate['bytes'] and sha(new[path]) == candidate['sha256']
        assert blob_id(new[path]) == candidate['git_blob']
        identities.append({'path': path, 'r36_bytes': len(current_data), 'r36_sha256': sha(current_data),
                           'r36_actual_git_blob': current_entry['oid'], 'r36_git_mode': current_entry['mode'],
                           'candidate_bytes': len(new[path]), 'candidate_sha256': sha(new[path]),
                           'candidate_computed_git_blob': blob_id(new[path]),
                           'changed_by_actual_byte_comparison': current_data != new[path],
                           'candidate_descriptor_identities_match_actual_bytes': True,
                           'r36_manifest_identities_match_both_actual_git_snapshots': True})
    assert sum(map(len, old.values())) == sum(map(len, new.values())) == 907146
    changed = {path for path in actual_paths if old[path] != new[path]}
    assert changed == EXPECTED_CHANGED and len(actual_paths - changed) == 32
    # Narrow, exact metadata replacements. No broad text/version normalisation.
    replacements = {
        'SKILL.md': [(b'  version: "2026-10-12-r36"\r\n', b'  version: "2026-10-12-r37"\r\n')],
        'references/sasis.md': [(b'Protocol revision: 2026-10-12-r36.\n', b'Protocol revision: 2026-10-12-r37.\n')],
        'references/sasis/student-testing-contract.txt': [
            ('SASIS reader contract — revision 2026-10-12-r36\n'.encode(),
             'SASIS reader contract — revision 2026-10-12-r37\n'.encode())],
        'references/sasis/profile-manifest.json': [
            (b'  "protocol_revision": "2026-10-12-r36",\n', b'  "protocol_revision": "2026-10-12-r37",\n'),
            (b'    "student-testing-contract.txt": "' + sha(old['references/sasis/student-testing-contract.txt']).encode() + b'",\n',
             b'    "student-testing-contract.txt": "' + sha(new['references/sasis/student-testing-contract.txt']).encode() + b'",\n')]
    }
    difference_checks = []
    for path, edits in replacements.items():
        expected, masked_old, masked_new = old[path], old[path], new[path]
        deltas = []
        for i, (before, after) in enumerate(edits):
            assert expected.count(before) == old[path].count(before) == new[path].count(after) == 1
            assert before in old[path].splitlines(keepends=True) and after in new[path].splitlines(keepends=True)
            expected = expected.replace(before, after, 1)
            marker = ('<BYTE_AUDIT_METADATA_' + str(i) + '>\n').encode()
            masked_old, masked_new = masked_old.replace(before, marker, 1), masked_new.replace(after, marker, 1)
            deltas.append({'old_line': old[path][:old[path].index(before)].count(b'\n') + 1,
                           'new_line': new[path][:new[path].index(after)].count(b'\n') + 1,
                           'old_metadata': before.decode().rstrip('\r\n'),
                           'new_metadata': after.decode().rstrip('\r\n'),
                           'line_ending_preserved': 'CRLF' if before.endswith(b'\r\n') else 'LF'})
        assert expected == new[path] and masked_old == masked_new
        difference_checks.append({'path': path, 'permitted_exact_line_edits': deltas,
                                  'all_remaining_bytes_identical': True,
                                  'r36_metadata_masked_body_sha256': sha(masked_old),
                                  'candidate_metadata_masked_body_sha256': sha(masked_new)})
    old_profile, profile = json.loads(old['references/sasis/profile-manifest.json']), json.loads(new['references/sasis/profile-manifest.json'])
    expected_profile = json.loads(old['references/sasis/profile-manifest.json'])
    expected_profile['protocol_revision'] = '2026-10-12-r37'
    expected_profile['control_file_hashes']['student-testing-contract.txt'] = sha(new['references/sasis/student-testing-contract.txt'])
    assert expected_profile == profile
    assert len(difference_checks) == 4 and sum(len(r['permitted_exact_line_edits']) for r in difference_checks) == 5

    # Reconstruct actual package-local declarations from their manifest bytes.
    declarations, exclusions = [], []
    def check(decl_file, pointer, path, digest, declared_bytes=None):
        path = safe(path)
        assert path in new, path
        data = new[path]
        assert sha(data) == digest
        assert declared_bytes is None or len(data) == declared_bytes
        declarations.append({'declaration_file': decl_file, 'json_pointer': pointer,
                             'path': path, 'declared_sha256': digest, 'actual_sha256': sha(data),
                             'declared_bytes': declared_bytes, 'actual_bytes': len(data), 'match': True})
    ppath = 'references/sasis/profile-manifest.json'
    pbase = 'references/sasis/'
    base_dir = safe(profile['file_hashes_base_directory'])
    for path, digest in profile['file_hashes'].items():
        check(ppath, '/file_hashes/' + path, pbase + base_dir + '/' + path, digest)
    for path, digest in profile['control_file_hashes'].items():
        check(ppath, '/control_file_hashes/' + path, pbase + path, digest)
    for i, r in enumerate(profile['subject_files']):
        check(ppath, '/subject_files/' + str(i) + '/sha256', pbase + r['path'], r['sha256'])
    release_path = 'references/sasis/ocr-baseline-20261007/release-manifest.json'
    release = json.loads(new[release_path])
    release_base = 'references/sasis/ocr-baseline-20261007/'
    for i, r in enumerate(release['subjects']):
        check(release_path, '/subjects/' + str(i) + '/sha256', release_base + r['path'], r['sha256'], r['bytes'])
    check(release_path, '/combined_baseline_sha256', release_base + 'student-baseline.txt', release['combined_baseline_sha256'])
    exclusions.append({'declaration_file': release_path, 'field': '/archive_sha256',
                       'reason': 'Historical archive reference is outside this 36-file package; declaration file is byte-unchanged from r36.'})
    chemistry_path = release_base + 'chemistry/freeze-manifest.json'
    chemistry = json.loads(new[chemistry_path])
    for i, r in enumerate(chemistry['files']):
        path = release_base + 'chemistry/' + r['path']
        if path in new:
            check(chemistry_path, '/files/' + str(i) + '/sha256', path, r['sha256'], r['bytes'])
        else:
            exclusions.append({'declaration_file': chemistry_path, 'field': '/files/' + str(i),
                               'referenced_path': path, 'declared_sha256': r['sha256'],
                               'reason': 'Historical file reference not present in the admitted 36-file package; unchanged declaration retained, not certified as a current package-local file.'})
    assert len(declarations) == 34
    # Claimed check-list is independently matched as a multiset, never by all_match.
    actual_multiset = collections.Counter((r['path'], r['actual_bytes'], r['actual_sha256']) for r in declarations)
    claimed_multiset = collections.Counter((r['path'], r['bytes'], r['sha256']) for r in hashes_claim['checks'])
    assert actual_multiset == claimed_multiset and len(hashes_claim['checks']) == hashes_claim['count'] == 34
    g.close()
    for path, data in new.items():
        assert (CANDIDATE / path).read_bytes() == data
    assert {str(p.relative_to(CANDIDATE)) for p in CANDIDATE.rglob('*') if p.is_file()} == actual_paths
    for path, data in zip(description_paths, descriptions):
        assert path.read_bytes() == data

    input_ids = [{'path': str(p.relative_to(ROOT)), 'bytes': len(b), 'sha256': sha(b)}
                 for p, b in zip(description_paths, descriptions)]
    identity_document = {'actual_file_identities': identities,
                         'exact_metadata_only_differences': difference_checks,
                         'actual_internal_hash_declarations': declarations,
                         'external_historical_exclusions': exclusions,
                         'input_description_identities': input_ids,
                         'actual_git_object_identities': g.identities}
    identity_path = OUT / 'byte-identities.json'
    identity_path.write_text(json.dumps(identity_document, indent=2) + '\n')
    report = {'status': 'BYTE_GATE_PASS', 'scope': 'Independent actual-byte audit of candidate PROF r37 relative to pinned r36',
              'audited_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'candidate_directory': str(CANDIDATE), 'candidate_version': '2026-10-12-r37',
              'r36_commit': PUBLISHED_R36, 'r36_tree': tree, 'r36_parent': R36_PARENT,
              'r36_parent_tree': parent_tree,
              'counts': {'candidate_files': 36, 'candidate_bytes': 907146, 'baseline_files': 36,
                         'baseline_bytes': 907146, 'actual_changed_files': 4, 'actual_unchanged_files': 32,
                         'metadata_or_corresponding_hash_line_edits': 5,
                         'actual_package_local_internal_hash_declarations': 34,
                         'unique_package_local_internal_hash_targets': len({r['path'] for r in declarations})},
              'changed_paths': sorted(changed),
              'checks': {'candidate_roster_exactly_matches_admitted_package': True,
                         'all_actual_candidate_size_sha256_gitblob_ids_match_description': True,
                         'all_r36_manifest_identities_reverified_against_both_actual_git_snapshots': True,
                         'exactly_four_expected_metadata_hash_only_changed_files': True,
                         'all_other_32_files_byte_identical': True,
                         'all_bytes_except_five_exact_metadata_hash_lines_identical': True,
                         'profile_json_only_protocol_revision_and_contract_digest_change': True,
                         'all_34_actual_internal_declarations_match_actual_candidate_bytes': True,
                         'claimed_internal_checklist_matches_independently_derived_multiset': True,
                         'candidate_files_and_input_descriptions_unchanged_after_audit': True},
              'gate_meaning': 'Passes the requested byte and metadata-only release gate. This is not semantic acceptance, a publication command, or authority for this auditor to publish.',
              'publisher': '/root/cycle_d015_clean_r36',
              'audit_harness_correction': 'Initial exact-line matcher assumed LF in SKILL.md and stopped before emitting a report. Inspection showed preserved CRLF in both versions; the matcher now requires the original CRLF exactly. No candidate file was changed.',
              'limits': ['Claimed changed/all_match/instruction_bodies_unchanged booleans were not used as proof.',
                         'Instructional bodies were treated as opaque bytes. Only changed metadata/hash lines and manifest identity fields were interpreted.',
                         'Candidate Git blob IDs are independently computed from candidate bytes; this report does not claim that the candidate is published.',
                         'Historical external source/archive references are preserved; the 34 verified declarations are actual package-local declarations, including repeated declarations of the same target.',
                         'Only exact Git objects in the two admitted r36 snapshots were read through git cat-file --batch. No Git mutations, checkout, index operations, older-history inspection or remote access occurred in this audit.',
                         'No browser, author contact, publication, semantic teaching review or fixture additions occurred.',
                         'Candidate and prior package bytes were not modified. Earlier held source findings remain held.'],
              'artifacts': {'byte_identities': {'path': str(identity_path.relative_to(ROOT)), 'bytes': identity_path.stat().st_size, 'sha256': sha(identity_path.read_bytes())},
                            'verification_script': {'path': str(Path(__file__).relative_to(ROOT)), 'bytes': Path(__file__).stat().st_size, 'sha256': sha(Path(__file__).read_bytes())}}}
    report_path = OUT / 'report.json'
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    payloads = [Path(__file__), identity_path, report_path]
    checksum_path = OUT / 'CHECKSUMS.sha256'
    checksum_path.write_text(''.join(sha(p.read_bytes()) + '  ' + p.name + '\n' for p in payloads))
    seal = {'status': 'SEALED_BYTE_GATE_PASS', 'candidate_version': '2026-10-12-r37',
            'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'candidate_files': 36, 'candidate_bytes': 907146, 'actual_changed_files': 4,
            'actual_unchanged_files': 32, 'verified_internal_declarations': 34,
            'instructional_body_byte_identity': True, 'semantic_acceptance_claimed': False,
            'published_by_this_agent': False, 'publisher': '/root/cycle_d015_clean_r36',
            'payloads': [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in payloads],
            'checksum_file': checksum_path.name, 'checksum_sha256': sha(checksum_path.read_bytes())}
    seal_path = OUT / 'SEAL.json'
    seal_path.write_text(json.dumps(seal, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'counts': report['counts'], 'directory': str(OUT),
                      'report_sha256': sha(report_path.read_bytes()), 'identities_sha256': sha(identity_path.read_bytes()),
                      'script_sha256': sha(Path(__file__).read_bytes()), 'checksums_sha256': sha(checksum_path.read_bytes()),
                      'seal_sha256': sha(seal_path.read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
