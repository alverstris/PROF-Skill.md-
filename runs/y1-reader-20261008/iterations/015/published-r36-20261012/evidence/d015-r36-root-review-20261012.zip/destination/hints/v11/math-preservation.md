# D015 r36 hints destination preservation

PASS. All 13 expression structures and types match (12 inline, 1 display); complete normalized prose (2137 characters), all 17 text links and 6 explicit anchors match. No source images occur. No content differences or unsupported mathematical forms were found.

Source SHA256 213956c9eeea4cc7f9d8ce2a31239bb94c814eecc3e9bf0d7cdbcfa91563e204. Actual capture SHA256 8e0bf378934887838fcdabb5d07602254adf6fcbc149e25b62d5e405a6854838, immutable commit 97e10125d66e612e3f0446ab1f8460c6fd4064a5.

The preserved v10 attempt rejected captured inline/block labels. V11 validates those labels against actual MathML and actual renderer class/style before mapping their spelling; mathematical parsing is unchanged. Two targeted metadata-conflict tests reject as required.

Scope: destination preservation only. No navigation success, geometry, scientific correctness or SASIS acceptance is asserted. Frozen source and original capture remain unchanged.
