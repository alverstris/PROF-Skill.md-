# D015 r36 main destination preservation

PASS. All 138 source expressions match actual captured MathML structures and types: 118 inline, 20 display. All expression operands, operators, visible grouping, fraction/script attachments and bounds are represented in the per-expression records.

Complete normalized nonmath prose matches (15,900 characters). All 15 text link labels and resolved destinations, all 6 explicit id anchors and expected GitHub prefixes, and all 3 image alt texts, image/wrapper destinations, declared dimensions and exact responsive style attributes match. No explicit math-error or raw-math slot occurs in the captured article. No content differences were found.

This uses the root-provided actual immutable DOM at commit 97e10125d66e612e3f0446ab1f8460c6fd4064a5. Capture SHA256 cbdf2179c0fc72fdc10a372ad1633e13133f50c4b292aa6998a7a0cb31b5393d; source SHA256 cb1798c3320123993edb5bab5f1136037e4367272441576522f11f099de68054.

The preserved v9 attempt rejected missing display metadata. Separate v10 derives type exclusively from actual article wrapper class/style and checks it against source type and actual MathML display; it also admits only the three witnessed image pairs 900x500, 900x560 and 900x600. Mathematical parsing is unchanged. Four targeted negative checks pass.

Scope: destination preservation only. This does not assert navigation success, image-loading behavior, geometry, scientific correctness or SASIS acceptance. The capture and frozen source are unchanged.
