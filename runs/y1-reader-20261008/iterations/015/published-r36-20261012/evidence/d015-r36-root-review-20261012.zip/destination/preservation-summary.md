# D015 r36 complete destination preservation

PASS: all 213 expressions preserve their structures and types (177 inline, 36 display). Complete prose, all 49 text links, all 18 explicit anchors, and all 3 image records match the frozen source. No content differences found.

| Page | Expressions | Prose characters | Text links | Anchors | Images |
|---|---:|---:|---:|---:|---:|
| main | 138 | 15900 | 15 | 6 | 3 |
| hints | 13 | 2137 | 17 | 6 | 0 |
| solutions | 62 | 5297 | 17 | 6 | 0 |

All captures identify immutable commit 97e10125d66e612e3f0446ab1f8460c6fd4064a5. Each per-expression report contains source LaTeX, exact actual MathML, canonical source/actual structures and hashes, display-type checks and complete whole-prose/link/anchor/image records. The summary JSON binds all source/capture/report hashes.

Initial v9/main and v10/hints/solutions failures remain preserved. V10 supports the actual reduced main-capture schema and three witnessed image sizes. V11 supports the actual hints/solutions inline/block metadata only after agreement with MathML and renderer wrappers. The mathematical parser and comparison loop remain byte-identical to v9. Six targeted negative checks across both versions reject the tested metadata/dimension/style conflicts.

This is destination preservation only. It does not establish navigation behavior, visual geometry, image-loading behavior, scientific correctness or SASIS acceptance. The actual reader was not accessed; final mechanics audit awaits the original final seal.
