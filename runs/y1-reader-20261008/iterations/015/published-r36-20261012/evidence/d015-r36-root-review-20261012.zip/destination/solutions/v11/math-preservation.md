# D015 r36 solutions destination preservation

PASS. All 62 expression structures and types match (47 inline, 15 display); complete normalized prose (5297 characters), all 17 text links and 6 explicit anchors match. No source images occur. No content differences or unsupported mathematical forms were found.

Source SHA256 237080669179279d8b85fe3a7ea0c5ad3242f1654f859d99dd6318e393b0c386. Actual capture SHA256 cd0115ed5d9e35fee2a230f08daa539212a145bde5f6c793b649de9370290366, immutable commit 97e10125d66e612e3f0446ab1f8460c6fd4064a5.

The preserved v10 attempt rejected captured inline/block labels. V11 validates those labels against actual MathML and actual renderer class/style before mapping their spelling; mathematical parsing is unchanged. Two targeted metadata-conflict tests reject as required.

Scope: destination preservation only. No navigation success, geometry, scientific correctness or SASIS acceptance is asserted. Frozen source and original capture remain unchanged.
