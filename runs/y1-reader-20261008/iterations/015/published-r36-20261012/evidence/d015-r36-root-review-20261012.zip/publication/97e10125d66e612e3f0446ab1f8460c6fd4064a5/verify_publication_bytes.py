#!/usr/bin/env python3
"""Byte-only verifier of two exact Git snapshots. Does not display payload content."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
REPO = ROOT / 'prof-iteration'
OUT = ROOT / 'root-review-d015-r36/publication/97e10125d66e612e3f0446ab1f8460c6fd4064a5'
TARGET = '97e10125d66e612e3f0446ab1f8460c6fd4064a5'
EXPECTED_TREE = 'ba6828823270f5611674e4bc8b5443a5f2e44583'
PARENT = 'cb5f12cb9762839fade6841c161cdc8c670894cf'
PREFIX = 'runs/y1-reader-20261008/iterations/015/published-r36-20261012/'
LOCAL = ROOT / 'd015-clean-r36-20261012'
MAP_PATH = LOCAL / 'work/publication1-readback.json'
PACKAGE_PATH = LOCAL / 'inputs/prof-package-manifest.json'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def identity(path, data):
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': sha256(data)}


def safe_path(path):
    p = PurePosixPath(path)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in path
    assert p.as_posix() == path
    return p


class ExactGit:
    def __init__(self):
        self.process = subprocess.Popen(
            ['git', '-C', str(REPO), 'cat-file', '--batch'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.cache = {}
        self.objects = []
        self.trees = {}

    def get(self, oid, expected_type=None):
        assert len(oid) == 40 and all(c in '0123456789abcdef' for c in oid)
        if oid not in self.cache:
            self.process.stdin.write((oid + '\n').encode())
            self.process.stdin.flush()
            header = self.process.stdout.readline().decode().strip().split()
            assert len(header) == 3 and header[0] == oid, header
            object_type, size = header[1], int(header[2])
            data = self.process.stdout.read(size)
            assert len(data) == size and self.process.stdout.read(1) == b'\n'
            actual_oid = hashlib.sha1(object_type.encode() + b' ' + str(size).encode() + b'\0' + data).hexdigest()
            assert actual_oid == oid
            self.cache[oid] = (object_type, data)
            self.objects.append({'git_oid': oid, 'type': object_type, 'bytes': size,
                                 'sha256': sha256(data), 'git_object_id_recomputed': actual_oid})
        object_type, data = self.cache[oid]
        assert expected_type is None or expected_type == object_type
        return data

    def commit(self, oid):
        data = self.get(oid, 'commit')
        # Interpret only tree and parent header fields. Do not interpret the message.
        headers = data.split(b'\n\n', 1)[0].splitlines()
        trees = [line[5:].decode() for line in headers if line.startswith(b'tree ')]
        parents = [line[7:].decode() for line in headers if line.startswith(b'parent ')]
        assert len(trees) == 1
        return trees[0], parents

    def tree(self, oid):
        if oid not in self.trees:
            data = self.get(oid, 'tree')
            entries = {}
            i = 0
            while i < len(data):
                j = data.index(b' ', i)
                k = data.index(b'\0', j)
                mode, name = data[i:j].decode(), data[j + 1:k].decode('utf-8')
                assert name not in entries and '/' not in name
                entries[name] = {'mode': mode, 'oid': data[k + 1:k + 21].hex()}
                i = k + 21
            assert i == len(data)
            self.trees[oid] = entries
        return self.trees[oid]

    def resolve(self, tree_oid, path):
        parts = safe_path(path).parts
        for i, part in enumerate(parts):
            entry = self.tree(tree_oid)[part]
            if i < len(parts) - 1:
                assert entry['mode'] == '40000'
                tree_oid = entry['oid']
        return entry

    def blob(self, tree_oid, path):
        entry = self.resolve(tree_oid, path)
        assert entry['mode'] in ('100644', '100755'), (path, entry['mode'])
        return entry, self.get(entry['oid'], 'blob')

    def close(self):
        self.process.stdin.close()
        self.process.wait()
        assert self.process.returncode == 0


def leaves(git, tree_oid, prefix=''):
    result = {}
    for name, entry in git.tree(tree_oid).items():
        path = prefix + name
        if entry['mode'] == '40000':
            result.update(leaves(git, entry['oid'], path + '/'))
        else:
            result[path] = entry
    return result


def tree_differences(git, old_oid, new_oid, prefix=''):
    if old_oid == new_oid:
        return []
    old = git.tree(old_oid) if old_oid else {}
    new = git.tree(new_oid) if new_oid else {}
    changes = []
    for name in sorted(set(old) | set(new)):
        before, after = old.get(name), new.get(name)
        if before == after:
            continue
        path = prefix + name
        if before and after and before['mode'] == after['mode'] == '40000':
            changes.extend(tree_differences(git, before['oid'], after['oid'], path + '/'))
        elif before is None and after['mode'] == '40000':
            changes.extend({'path': p, 'change': 'added', 'parent': None, 'published': e}
                           for p, e in leaves(git, after['oid'], path + '/').items())
        elif after is None and before['mode'] == '40000':
            changes.extend({'path': p, 'change': 'removed', 'parent': e, 'published': None}
                           for p, e in leaves(git, before['oid'], path + '/').items())
        else:
            changes.append({'path': path, 'change': 'added' if before is None else
                            'removed' if after is None else 'changed',
                            'parent': before, 'published': after})
    return sorted(changes, key=lambda r: r['path'])


def object_arrays(node, pointer=''):
    """Structural search only, never return interpreted object fields."""
    found = []
    if isinstance(node, list):
        if len(node) == 147 and all(isinstance(v, dict) for v in node):
            found.append((pointer, node))
        for i, value in enumerate(node):
            if isinstance(value, (dict, list)):
                found.extend(object_arrays(value, pointer + '/' + str(i)))
    elif isinstance(node, dict):
        for key, value in node.items():
            if isinstance(value, (dict, list)):
                found.extend(object_arrays(value, pointer + '/' + key.replace('~', '~0').replace('/', '~1')))
    return found


def canonical_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def main():
    map_data, package_data = MAP_PATH.read_bytes(), PACKAGE_PATH.read_bytes()
    claimed_map, claimed_package = json.loads(map_data), json.loads(package_data)
    assert len(claimed_map['files']) == claimed_map['count'] == 17
    assert len(claimed_package['files']) == claimed_package['count'] == 36
    assert claimed_map['pin'] == TARGET and claimed_map['tree'] == EXPECTED_TREE
    assert claimed_package['commit'] == PARENT
    git = ExactGit()
    target_tree, parents = git.commit(TARGET)
    assert target_tree == EXPECTED_TREE and parents == [PARENT]
    parent_tree, _ = git.commit(PARENT)
    assert parent_tree == claimed_package['tree']
    publication = []
    local_snapshots = {}
    for rec in claimed_map['files']:
        path = rec['path']
        safe_path(path)
        assert path.startswith(PREFIX)
        local_path = LOCAL / path[len(PREFIX):]
        assert not local_path.is_symlink() and local_path.is_file()
        local_data = local_path.read_bytes()
        entry, blob_data = git.blob(target_tree, path)
        actual_hash = sha256(blob_data)
        assert blob_data == local_data
        assert len(blob_data) == rec['bytes'] and actual_hash == rec['sha256']
        assert entry['oid'] == rec['git_blob']
        local_snapshots[str(local_path)] = local_data
        publication.append({'published_path': path, 'local_path': str(local_path.relative_to(ROOT)),
                            'mode': entry['mode'], 'actual_git_blob': entry['oid'],
                            'actual_git_bytes': len(blob_data), 'actual_git_sha256': actual_hash,
                            'local_bytes': len(local_data), 'local_sha256': sha256(local_data),
                            'claimed_git_blob': rec['git_blob'], 'claimed_bytes': rec['bytes'],
                            'claimed_sha256': rec['sha256'], 'exact_local_git_bytes_match': True,
                            'all_claimed_identities_independently_match': True})
    assert len({r['published_path'] for r in publication}) == 17
    assert sum(r['actual_git_bytes'] for r in publication) == claimed_map['bytes']
    publication_tree = git.resolve(target_tree, PREFIX.rstrip('/'))
    assert publication_tree['mode'] == '40000'
    actual_publication_paths = set(leaves(git, publication_tree['oid'], PREFIX))
    assert actual_publication_paths == {r['published_path'] for r in publication}

    package = []
    for rec in claimed_package['files']:
        path = rec['path']
        old_entry, old_data = git.blob(parent_tree, path)
        new_entry, new_data = git.blob(target_tree, path)
        assert old_entry == new_entry and old_data == new_data
        assert len(new_data) == rec['bytes'] and sha256(new_data) == rec['sha256']
        assert new_entry['oid'] == rec['git_blob']
        package.append({'path': path, 'parent_mode': old_entry['mode'], 'published_mode': new_entry['mode'],
                        'parent_git_blob': old_entry['oid'], 'published_git_blob': new_entry['oid'],
                        'bytes': len(new_data), 'parent_sha256': sha256(old_data),
                        'published_sha256': sha256(new_data), 'declared_sha256': rec['sha256'],
                        'declared_bytes': rec['bytes'], 'declared_git_blob': rec['git_blob'],
                        'exact_bytes_unchanged': True, 'manifest_identities_match': True})
    assert len({r['path'] for r in package}) == 36
    assert sum(r['bytes'] for r in package) == claimed_package['bytes']

    unchanged = []
    queue = None
    for name in ['queue.json', 'RUN.md', 'CHANGELOG.md']:
        path = 'runs/y1-reader-20261008/' + name
        old_entry, old_data = git.blob(parent_tree, path)
        new_entry, new_data = git.blob(target_tree, path)
        assert old_entry == new_entry and old_data == new_data
        unchanged.append({'path': path, 'parent_git_blob': old_entry['oid'],
                          'published_git_blob': new_entry['oid'], 'mode': new_entry['mode'],
                          'bytes': len(new_data), 'parent_sha256': sha256(old_data),
                          'published_sha256': sha256(new_data), 'exact_bytes_unchanged': True})
        if name == 'queue.json':
            old_arrays = object_arrays(json.loads(old_data))
            new_arrays = object_arrays(json.loads(new_data))
            assert len(old_arrays) == len(new_arrays) == 1
            old_pointer, old_objects = old_arrays[0]
            new_pointer, new_objects = new_arrays[0]
            assert old_pointer == new_pointer
            objects = []
            for i, (old_object, new_object) in enumerate(zip(old_objects, new_objects)):
                old_canonical, new_canonical = canonical_bytes(old_object), canonical_bytes(new_object)
                assert old_object == new_object and old_canonical == new_canonical
                objects.append({'index': i, 'canonical_bytes': len(new_canonical),
                                'parent_whole_object_sha256': sha256(old_canonical),
                                'published_whole_object_sha256': sha256(new_canonical),
                                'whole_object_equal': True})
            queue = {'path': path, 'object_array_json_pointer': old_pointer,
                     'whole_object_count': len(objects), 'whole_objects_equal': len(objects),
                     'whole_blob_also_byte_identical': True,
                     'canonical_encoding': 'UTF-8 JSON; sorted keys; compact separators; ensure_ascii=False',
                     'objects': objects}
    changes = tree_differences(git, parent_tree, target_tree)
    assert len(changes) == 17 and all(r['change'] == 'added' for r in changes)
    assert {r['path'] for r in changes} == {r['published_path'] for r in publication}
    git.close()
    for path, original in local_snapshots.items():
        assert Path(path).read_bytes() == original
    assert MAP_PATH.read_bytes() == map_data and PACKAGE_PATH.read_bytes() == package_data

    byte_identities = {'publication_files': publication, 'package_files': package,
                       'queue_RUN_CHANGELOG': unchanged, 'queue_whole_objects': queue,
                       'exact_parent_to_published_tree_differences': changes,
                       'actual_git_objects_read': git.objects,
                       'local_input_manifests': [identity(MAP_PATH, map_data), identity(PACKAGE_PATH, package_data)]}
    identity_path = OUT / 'byte-identities.json'
    identity_path.write_text(json.dumps(byte_identities, indent=2) + '\n')
    report = {
        'status': 'PASS', 'scope': 'Independent byte-only actual-Git publication verification; no semantic review or publication',
        'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'repository': str(REPO), 'published_commit': TARGET, 'actual_published_tree': target_tree,
        'actual_published_parents': parents, 'parent_commit': PARENT, 'actual_parent_tree': parent_tree,
        'actual_publication_subtree': publication_tree['oid'],
        'provenance': {'object_source': 'Actual local Git object database after separately authorized git fetch origin main',
                       'remote_fetch_observation': 'Fetch succeeded from https://github.com/alverstris/PROF-Skill.md-; output reported origin/main updated d1d0874..97e1012.',
                       'git_object_reads': 'git cat-file --batch, exact hexadecimal object IDs only',
                       'commit_objects_opened': [TARGET, PARENT],
                       'older_commits_opened': 0,
                       'git_sha1_recomputed_for_every_object_read': True,
                       'claimed_map_booleans_used_as_evidence': False,
                       'remote_branch_current_state_claim': 'This verifier pins exact fetched commit bytes; it does not make a continuing claim about a moving remote branch.'},
        'counts': {'publication_paths': 17, 'publication_bytes': sum(r['actual_git_bytes'] for r in publication),
                   'package_paths_unchanged': 36, 'package_bytes': sum(r['bytes'] for r in package),
                   'queue_whole_objects_unchanged': 147, 'RUN_and_CHANGELOG_unchanged': 2,
                   'added_paths_in_exact_two_tree_comparison': 17,
                   'modified_or_removed_paths': 0, 'actual_git_objects_read': len(git.objects)},
        'verification': {'published_commit_tree_parent_match_requested_pins': True,
                         'all_17_actual_git_sizes_hashes_blob_ids_match_local_and_map': True,
                         'publication_subtree_has_exactly_the_17_declared_paths': True,
                         'all_36_package_paths_match_declared_identities_and_parent_bytes': True,
                         'queue_entire_blob_and_147_whole_objects_unchanged': True,
                         'RUN_and_CHANGELOG_entire_blobs_unchanged': True,
                         'only_the_17_declared_publication_paths_added': True,
                         'all_local_publication_bytes_reread_unchanged': True,
                         'input_manifests_reread_unchanged': True},
        'limits': ['No teaching, package, RUN or CHANGELOG semantic content was displayed or interpreted.',
                   'Queue JSON was parsed only for structural array selection and whole-object equality/hashes; no queue field meanings were interpreted.',
                   'No checkout, reset, clean, index inspection, status scan, log or older-history inspection was performed.',
                   'No working-tree or index write was performed. Authorized fetch updated Git object storage and remote-fetch metadata.',
                   'No source findings were released, no author contacted, no browser used, and no publication performed.',
                   'The dirty working tree is neither used as Git evidence nor claimed to be clean.',
                   'This report certifies byte provenance and the stated invariants, not mathematical, pedagogical or procedural acceptance.'],
        'artifacts': {'script': identity(Path(__file__), Path(__file__).read_bytes()),
                      'byte_identities': identity(identity_path, identity_path.read_bytes())}}
    report_path = OUT / 'report.json'
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    files = [Path(__file__), identity_path, report_path]
    (OUT / 'CHECKSUMS.sha256').write_text(''.join(sha256(p.read_bytes()) + '  ' + p.name + '\n' for p in files))
    print(json.dumps({'status': report['status'], 'commit': TARGET, 'tree': target_tree, 'parent': PARENT,
                      'counts': report['counts'], 'output_directory': str(OUT),
                      'report_sha256': sha256(report_path.read_bytes()),
                      'byte_identities_sha256': sha256(identity_path.read_bytes()),
                      'script_sha256': sha256(Path(__file__).read_bytes()),
                      'checksums_sha256': sha256((OUT / 'CHECKSUMS.sha256').read_bytes())}, indent=2))


if __name__ == '__main__':
    main()
