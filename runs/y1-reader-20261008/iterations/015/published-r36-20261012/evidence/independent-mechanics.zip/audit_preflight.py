#!/usr/bin/env python3
"""Independent read-only D015 subject-free preflight audit. No fixture execution or views."""
from pathlib import Path
import json,hashlib,base64,collections,datetime,re,os,ast
ROOT=Path('/workspace/scratch/f9c0b7fc7e76');B=ROOT/'d015-clean-r36-20261012/work/launcher-preflight';SOURCE=ROOT/'d015-clean-r36-20261012/inputs/operational-tools/read-step';O=Path(__file__).resolve().parent
LH='d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd';RH='810095332b2be1684e0ac6b8174fc9c405145b0cf84bc6ade816addc4bab22a4';MH='a6c275a9458704acf2e7018ddfa30e49f1e8b57db80349cca73674e00e13213f';FH='e12bebc3911dd3a093d370039e0d794801cc3aa683cd7ca078679e19b8ac2805'
checks=[]
def ck(ok,label):
 checks.append(label)
 if not ok:raise AssertionError(label)
def sha(b):return hashlib.sha256(b).hexdigest()
def unique(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('Duplicate JSON key '+k)
  d[k]=v
 return d
def parse(b):return json.loads(b,object_pairs_hook=unique)
def read(p):
 p=Path(p);ck(p==SOURCE or p.resolve().is_relative_to(B),'read limited to authorized preflight scope '+str(p));return p.read_bytes()
def load(p):return parse(read(p))
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def tm(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
def info(p):
 b=read(p);return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def outinfo(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=True)+'\n')
def chain(ev,label):
 prev='0'*64;last=None
 for i,e in enumerate(ev):
  ck(set(e)=={'index','at','call_id','event','data','previous','sha256'},label+' exact event schema '+str(i));d={k:v for k,v in e.items() if k!='sha256'};ck(e['index']==i and e['previous']==prev and sha(canonical(d))==e['sha256'],label+' chain/index/hash '+str(i));prev=e['sha256'];t=tm(e['at']);ck(t.tzinfo is not None and (last is None or last<=t),label+' timestamp order '+str(i));last=t
 return {'event_count':len(ev),'tail_sha256':prev,'chain_valid':True}
ck(sha(read(SOURCE))==LH,'supplied unchanged launcher SHA');ck(sha(read(B/'results.json'))==RH,'pinned results SHA');ck(sha(read(B/'evidence-manifest.json'))==MH,'pinned evidence manifest SHA')
manifest=load(B/'evidence-manifest.json');inventory=[]
for x in manifest['files']:
 rel=Path(x['path']);ck(not rel.is_absolute() and '..' not in rel.parts,'safe manifest path');p=B/rel;b=read(p);ck(len(b)==x['bytes'] and sha(b)==x['sha256'],'sealed evidence identity '+x['path']);inventory.append(info(p))
ck(len(inventory)==len({x['path'] for x in inventory})==408,'408 unique declared evidence files')
actual={str(p.relative_to(B)) for p in B.rglob('*') if p.is_file()};declared={x['path'] for x in manifest['files']};excluded=sorted(actual-declared)
ck(not declared-actual and excluded==['__pycache__/preflight.cpython-312.pyc','evidence-manifest.json','observer/__pycache__/sitecustomize.cpython-312.pyc'],'only manifest itself and two caches excluded; 411 actual files')
launchers=[]
for p in sorted(B.rglob('read-step')):
 ck(read(p)==read(SOURCE),'all deployed launcher copies identical '+str(p));launchers.append(info(p))
# Inspect all allowed operational Python source, but never import/execute it.
code=[]
for rel in ['preflight.py','prepare_receipt_flow.py','finish_preflight-first-attempt.py','finish_preflight.py','observer/sitecustomize.py']:
 p=B/rel;s=read(p).decode();tree=ast.parse(s);code.append(info(p)|{'lines':len(s.splitlines()),'write_call_lines':[n.lineno for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['write_text','write_bytes','write','rename','unlink','truncate']]})
# All routed source locations in every retained fixture route stay inside the fixture tree.
route_records=[]
for p in sorted(B.rglob('route.json')):
 r=load(p)
 for f in r['files']:ck(Path(f['path']).resolve().is_relative_to(B),'all routed fixture paths in allowed tree '+f['path'])
 route_records.append(info(p)|{'route_id':r['route_id'],'file_paths':[f['path'] for f in r['files']]})
results=load(B/'results.json');ck(results['checks_count']==len(results['checks'])==49,'49 advertised passing checks');initial=load(B/'initial-results.json');fresh_start=load(B/'receipt-flow-pre-view.json');ck(results['checks'][:33]==initial['checks'] and results['checks'][33:39]==fresh_start['checks'],'results retain exact initial33 and fresh pre-view6 records')
reasonmap={
'01-no-argument':'exactly one argument','02-extra-argument':'exactly one argument','03-path-as-argument':'invalid identifier','04-unknown-id':'unknown STEP_ID','05-skipped-baseline':'next scheduled','06-premature-teaching':'next scheduled','07-unread-baseline-revisit':'not yet been read','08-receipt-before-figure':'next scheduled','11-unread-second-revisit':'not yet been read','14-figure-cannot-be-skipped':'next scheduled','16-pending-figure-holds-next':'figure view receipt required','17-missing-view-receipt':'No such file','18-path-hash-not-a-view':'incorrect object fields','20-revisit-does-not-bypass-figure':'figure view receipt required','01-hash-mismatch-content-withheld':'content withheld','02-failed-read-poisons-reuse':'previous access/output failure','21-wrong-receipt-identity':'view receipt identity mismatch','22-wrong-view-invocation':'view invocation mismatch','23-unsuccessful-view-metadata':'successful image tool result','24-invalid-view-result-hash':'invalid SHA-256','25-predispatch-completion-time':'does not follow dispatch','30-completed-route-cannot-restart':'next scheduled'}
invalid_reason={'invalid-type':'invalid integer','bool-integer':'invalid integer','invalid-range':'invalid integer','range-beyond-file':'invalid or oversized byte range','coverage-gap':'missing, overlapping or out-of-order','baseline-after-teaching':'baseline must finish','delayed-figure':'figure delayed','invalid-step-kind':'invalid step kind','route-digest-mismatch':'route identity mismatch','route-id-mismatch':'route identity mismatch','launcher-id-mismatch':'launcher identity mismatch'}
bycase=collections.defaultdict(list);percall=[];all_opens=[];assertion_count=0
for rec in results['checks']:
 root=Path(rec['command'][0]).parent;label=rec['label'];stem=root/'evidence'/label
 persisted=load(Path(str(stem)+'.result.json'));ck(persisted==rec,'exact retained result record '+root.name+'/'+label);events=load(Path(str(stem)+'.events.json'));opens=[parse(x) for x in read(Path(str(stem)+'.opens.jsonl')).splitlines()];stdout=read(Path(str(stem)+'.stdout.bin'));stderr=read(Path(str(stem)+'.stderr.txt'));kinds=[e['event'] for e in events];all_opens.extend(opens)
 ck(events and len({e['call_id'] for e in events})==1,'one actual call UUID '+label);ck(events[0]['event']=='call_attempt' and events[0]['data']=={'argv':rec['command'][1:]} and events[-1]['event']=='call_finished','call argument/finish binding '+label);ck(rec['ledger_event_indexes']==[e['index'] for e in events],'record exact event indices '+label);ck(rec['stdout_bytes']==len(stdout) and rec['stdout_sha256']==sha(stdout) and rec['stderr']==stderr.decode(),'actual stdout/stderr binds result '+label)
 fixture_opens=[x for x in opens if x['event']=='open' and isinstance(x['path'],str) and x['path'].startswith(str(root/'fixtures')+'/')];reads=[e for e in events if e['event']=='subject_read'];access=[e for e in events if e['event']=='actual_access'];rv=[e['data'] for e in events if e['event']=='route_validated'];ck(rec['subject_open_audit_events']==fixture_opens and rec['subject_read_ledger_events']==reads,'observer/read list independently derived '+label)
 route=load(root/'route.json');files={f['id']:f for f in route['files']};steps={s['id']:s for s in route['steps']};revisits={r['id']:r['initial_step_id'] for r in route['revisits']};sid=rec['command'][1] if len(rec['command'])>1 else None;operation=rv[0]['operation'] if len(rv)==1 else None;expected=None
 if rec['exit_code']==0 and operation in ['text','revisit']:
  step=steps[revisits.get(sid,sid)];f=files[step['file_id']];expected=read(Path(f['path']))[step['start']:step['end']];ck(sha(expected)==step['sha256'],'expected frozen fixture slice '+label)
 for e in access:
  a=e['data'];f=files[a['file_id']];raw=read(Path(f['path']))
  if root.name=='changed-content' and label=='01-hash-mismatch-content-withheld':raw=b'X'+raw[1:]
  bounded=raw[a['start']:a['end']];ck(len(bounded)==a['bytes'] and sha(bounded)==a['sha256'],'actual accessed fixture bytes '+label);ck(a['verified']==(a['sha256']==a['expected_sha256']),'verified flag honest '+label)
  rs=[x['data'] for x in reads];ck(len(rs)==1 and rs[0]=={'file_id':a['file_id'],'offset':a['start'],'requested':len(bounded),'returned':len(bounded),'sha256':sha(bounded)},'exact bounded read '+label)
 for en in ['stdout_begin','stdout_complete']:
  for e in [e for e in events if e['event']==en]:ck(e['data']['bytes']==len(stdout) and e['data']['sha256']==sha(stdout),'recorded transport matches saved output '+label)
 if rec['exit_code']:
  ck(not any(e['event'] in ['stdout_begin','stdout_complete','state_commit'] for e in events),'rejection never outputs/commits '+label);ck(events[-1]['data']['outcome']=='rejected' and stderr==('REJECTED: '+events[-1]['data']['reason']+'\n').encode(),'exact rejection reason stdout/stderr '+label)
 else:ck(events[-1]['data']=={'outcome':'success'} and stderr==b'','successful call actual result '+label)
 derived={'exit':rec['exit_code']==rec['expected_exit'],'observer_started':opens[0]=={'event':'observer_started','argv':rec['command']},'rejection_returns_no_content':stdout==b'','no_subject_open_audit_event':not fixture_opens,'no_subject_read_ledger_event':not reads,'no_subject_ledger_open':not any(e['event'] in ['subject_open_attempt','subject_opened','subject_read'] for e in events)}
 if 'reason' in [x['name'] for x in rec['assertions']]:derived['reason']=(invalid_reason[root.name] if label=='reject' else reasonmap[label]) in stderr.decode()
 if expected is not None:
  starts=[e for e in events if e['event']=='stdout_begin'];derived.update(exact_bytes=stdout==expected,receipt_precedes_output=len(access)==len(starts)==1 and access[0]['index']<starts[0]['index'],verified_access=len(access)==1 and access[0]['data']['verified'] is True and access[0]['data']['sha256']==sha(expected),observed_open_and_bounded_read=len(fixture_opens)==1 and bool(reads) and sum(e['data']['returned'] for e in reads)==len(expected))
 # Cursor/operation are independently recomputed against complete valid-route history below.
 for assertion in rec['assertions']:
  assertion_count+=1
  if assertion['name'] in ['cursor','operation']:continue
  ck(assertion['name'] in derived and derived[assertion['name']] is True and assertion['pass_'] is True,'independent named assertion '+label+'/'+assertion['name'])
 bycase[root.name].extend(events);percall.append({'case':root.name,'label':label,'call_id':events[0]['call_id'],'event_indices':[events[0]['index'],events[-1]['index']],'exit_code':rec['exit_code'],'named_assertions':len(rec['assertions']),'stdout_bytes':len(stdout),'stdout_sha256':sha(stdout),'fixture_open_count':len(fixture_opens),'fixture_read_count':len(reads),'outcome':events[-1]['data']['outcome']})
ck(assertion_count==361,'361 named assertions represented by49 records')
# Prove original main saved per-call branch and later shortened branch separately.
main_saved=load(B/'ledger-anomaly-per-call-events.json');ck(main_saved==bycase['main'] and len(main_saved)==96,'saved 96-event branch exactly equals initial20 per-call records');saved_chain=chain(main_saved,'original saved main branch')
observed_raw=read(B/'ledger-anomaly-observed.jsonl');observed=[parse(x) for x in observed_raw.splitlines()];ck(observed_raw==read(B/'cases/main/runtime/ledger.jsonl'),'observed18 branch is retained current main ledger');obs_chain=chain(observed,'shortened observed main branch');ck(len(observed)==18 and observed[:16]==main_saved[:16],'branches share exactly first16 events');ck(observed[16:]!=main_saved[16:18],'observed suffix differs from original next call')
extra=B/'cases/main/evidence/21-wrong-receipt-identity';er=load(Path(str(extra)+'.result.json'));ee=load(Path(str(extra)+'.events.json'));eo=[parse(x) for x in read(Path(str(extra)+'.opens.jsonl')).splitlines()];ck(ee==observed[16:] and er['passed'] is False,'extra failed test attempt exactly matches observed branch suffix');ck([x['name'] for x in er['assertions'] if not x['pass_']]==['reason','cursor','operation'],'failed expectations explicitly reason/cursor/operation');ck(read(Path(str(extra)+'.stdout.bin'))==b'' and not any(x['event'] in ['subject_open_attempt','subject_opened','subject_read','actual_access','stdout_begin','state_commit'] for x in ee),'extra branch attempt safely no subject access/output/commit');ck(not any(x['event']=='open' and isinstance(x['path'],str) and '/fixtures/' in x['path'] for x in eo),'extra attempt observer shows no fixture open');ck(len(list(B.glob('cases/*/evidence/*.result.json')))==50,'all50 retained invocation records accounted for')
an=load(B/'ledger-anomaly.json');ck(an['observed_ledger_sha256']==sha(observed_raw) and an['initial_expected_tail_hash']==saved_chain['tail_sha256'] and an['observed_ledger_events']==18 and an['initial_checks_per_call_events']==96,'anomaly metadata matches both independent chains')
# All other final live fixture ledgers equal concatenated per-call records and hash correctly.
case_chains=[]
for case,ev in bycase.items():
 if case=='main':continue
 p=B/'cases'/case/'runtime/ledger.jsonl';live=[parse(x) for x in read(p).splitlines()];ck(live==ev,'per-call events equal final ledger '+case);case_chains.append({'case':case,'ledger':info(p),**chain(ev,case)})
# Independently reconstruct state on both valid routes, retaining cursor for revisits and rejected calls.
state_records=[]
for case,ev in [('main',main_saved),('receipt-flow',bycase['receipt-flow'])]:
 root=B/'cases'/case;route=load(root/'route.json');stepmap={s['id']:s for s in route['steps']};revisits={x['id']:x['initial_step_id'] for x in route['revisits']};groups=[]
 for e in ev:
  if not groups or groups[-1][0]['call_id']!=e['call_id']:groups.append([])
  groups[-1].append(e)
 cursor=0;pending=None;seen=set();states=[]
 for g in groups:
  args=g[0]['data']['argv'];sid=args[0] if args else None;rv=[e for e in g if e['event']=='route_validated'];commits=[e for e in g if e['event']=='state_commit'];success=g[-1]['data']['outcome']=='success';before=(cursor,pending)
  if rv:
   d=rv[0]['data'];op='revisit' if sid in revisits else 'figure_received' if pending and sid==stepmap[pending]['receipt_step_id'] else 'figure_dispatched' if cursor<len(route['steps']) and route['steps'][cursor]['kind']=='figure' else 'text';ck(len(rv)==1 and d=={'cursor':cursor,'launcher_sha256':LH,'operation':op,'pending_figure':pending,'route_id':route['route_id'],'route_sha256':sha(read(root/'route.json')),'step_id':sid},'independent cursor/pending/op '+case+'/'+str(sid))
   if op=='revisit':ck(revisits[sid] in seen,'only previously read baseline revisit '+case)
   elif op=='figure_received':ck(pending==route['steps'][cursor]['id'],'correct pending receipt '+case)
   else:ck(route['steps'][cursor]['id']==sid,'scheduled initial stage '+case)
  if success:
   ck(len(commits)==1 and len(rv)==1,'one committed successful transition');op=rv[0]['data']['operation'];ck(commits[0]['data']=={'operation':op,'route_sha256':sha(read(root/'route.json')),'step_id':sid},'exact commit identity')
   if op=='figure_dispatched':pending=sid
   elif op=='text':seen.add(sid);cursor+=1
   elif op=='figure_received':pending=None;cursor+=1
  else:ck(not commits,'rejected call leaves state unchanged')
  states.append({'call_id':g[0]['call_id'],'step_id':sid,'success':success,'cursor_before':before[0],'pending_before':before[1],'cursor_after':cursor,'pending_after':pending})
 state_records.append({'case':case,'states':states,'final_cursor':cursor,'final_pending':pending})
 if case=='main':ck(cursor==3 and pending=='F1','original saved branch was waiting for figure receipt')
 else:ck(cursor==len(route['steps'])==6 and pending is None,'fresh full route complete')
# Fresh snapshots and source partition bind to current 123-event ledger.
froot=B/'cases/receipt-flow';fraw=read(froot/'runtime/ledger.jsonl');fe=bycase['receipt-flow'];ck(len(fe)==123 and sha(fraw)==FH,'pinned fresh123-event ledger');snapshots=[]
for p in sorted((froot/'evidence').glob('*.complete-ledger.jsonl')):
 raw=read(p);ck(fraw.startswith(raw),'fresh per-call full-ledger snapshot is exact current prefix '+p.name);snapshots.append(info(p)|{'events':len(raw.splitlines()),'exact_prefix':True})
pre=read(B/'receipt-flow-pre-view-ledger.jsonl');ck(len(pre.splitlines())==66 and fraw.startswith(pre) and sha(pre)==fresh_start['ledger_sha256'],'pre-view66 exact immutable prefix in final123');ck(snapshots[-1]['sha256']==sha(pre),'sixth call snapshot equals independent pre-view snapshot')
route=load(froot/'route.json');files={f['id']:f for f in route['files']};coverage=collections.defaultdict(list);source_sizes={}
for f in route['files']:
 b=read(Path(f['path']));ck(len(b)==f['size'] and sha(b)==f['sha256'],'fresh fixture whole-file identity '+f['id']);source_sizes[f['id']]=len(b)
for s in route['steps']:
 f=files[s['file_id']];a,z=(s['start'],s['end']) if s['kind']=='text' else (0,f['size']);b=read(Path(f['path']))[a:z];ck(sha(b)==s['sha256'],'fresh initial slice identity '+s['id']);coverage[f['id']].append((a,z))
for fid,ranges in coverage.items():ck(ranges[0][0]==0 and ranges[-1][1]==files[fid]['size'] and all(x[1]==y[0] for x,y in zip(ranges,ranges[1:])),'fresh complete source partition '+fid)
# Both retained original image return objects and their exact serialized form/decoded fixture bytes.
views=[]
for prefix,case,events in [('', 'main',main_saved),('receipt-flow-','receipt-flow',fe)]:
 cp=B/(prefix+'actual-view-capture.json');rp=B/(prefix+'actual-view-result.json');pp=B/(prefix+'actual-view-returned-image.png');capture=load(cp);rawresult=read(rp);result=parse(rawresult);ck(set(result)=={'image_url','detail'} and result['detail']=='original','exact actual image object fields '+case);ck(rawresult==(json.dumps(result,separators=(',',':'),ensure_ascii=False)+'\n').encode(),'exact JSON.stringify-style preserved result '+case);u=result['image_url'];match=re.fullmatch(r'data:([^;,]+);base64,([A-Za-z0-9+/=]+)',u);ck(match is not None,'strict actual data URL '+case);decoded=base64.b64decode(match[2],validate=True);imagepath=B/'cases'/case/'fixtures/tile.png';ck(decoded==read(imagepath)==read(pp),'actual result decodes to exact synthetic PNG '+case);ck(capture['invocation']=={'path':str(imagepath),'detail':'original'} and capture['original_object_file']==str(rp),'actual capture invocation/result path '+case);ck(capture['tool_name']=='tools.view_image' and 'no provider tool-call ID' in capture['invocation_id_provenance'],'ID provenance explicit '+case)
 dispatch=next(e for e in events if e['event']=='state_commit' and e['data']['operation']=='figure_dispatched');ck(tm(dispatch['at'])<=tm(capture['started_at'])<=tm(capture['completed_at']),'view timestamps after dispatch '+case)
 view={'case':case,'capture':info(cp),'original_result':info(rp),'returned_png':info(pp),'orchestrator_invocation_id':capture['invocation_id'],'provider_tool_call_id_exposed':False,'started_at':capture['started_at'],'completed_at':capture['completed_at'],'image_url_chars':len(u),'image_url_sha256':sha(u.encode()),'decoded_bytes':len(decoded),'decoded_sha256':sha(decoded),'exact_fixture_byte_match':True}
 if case=='receipt-flow':
  s=next(s for s in route['steps'] if s['id']=='F1');f=files[s['file_id']];receipt={'schema':'sasis-view-result-v1','route_id':route['route_id'],'figure_step_id':'F1','receipt_step_id':'F1_view','image_path':f['path'],'image_sha256':f['sha256'],'tool_name':capture['tool_name'],'tool_call_id':capture['invocation_id'],'completed_at':capture['completed_at'],'invocation':capture['invocation'],'result_metadata':{'success':True,'kind':'image','detail':'original','image_url_sha256':sha(u.encode()),'image_url_chars':len(u),'mime_type':match[1]}};rp2=Path(s['receipt_file']);ck(load(rp2)==receipt and read(rp2)==(json.dumps(receipt,indent=2,sort_keys=True)+'\n').encode(),'receipt derived exactly from preserved actual result')
  accepts=[e for e in fe if e['event']=='figure_receipt_accepted'];ck(len(accepts)==1 and accepts[0]['data']['receipt']==receipt and accepts[0]['data']['receipt_sha256']==sha(read(rp2)),'fresh ledger binds exact derived receipt');ck(tm(capture['completed_at'])<=tm(accepts[0]['at']),'actual completion before acceptance')
  view.update(receipt=info(rp2),accepted_event_index=accepts[0]['index'],accepted_ledger_call_id=accepts[0]['call_id'])
 views.append(view)
# Open observation scope and append flags are inspected without opening observer-referenced runtime libraries.
external_opens=[];ledger_writes=[]
for e in all_opens+eo:
 if e['event']!='open' or not isinstance(e['path'],str):continue
 p=Path(e['path'])
 if not p.is_relative_to(B):external_opens.append(e['path']);ck(e['path'].startswith('/opt/codex/runtimes/') or e['path'].startswith('/usr/'),'observed outside-preflight open limited to runtime library '+e['path'])
 if e['path'].endswith('/runtime/ledger.jsonl') and e['flags']&os.O_WRONLY:
  ck(e['flags']&os.O_APPEND and not(e['flags']&os.O_TRUNC),'observed launcher ledger write is append, never truncate');ledger_writes.append({'path':e['path'],'flags':e['flags']})
probe=load(B/'append-persistence-probe.expected.json');pb=read(B/'append-persistence-probe.log');ck(pb==probe['content'].encode() and len(pb)==probe['bytes'] and sha(pb)==probe['sha256'],'separate append probe final bytes match expected20')
strace=read(B/'strace-unavailable-attempt/evidence/01-no-argument.stderr.txt').decode();ck('PTRACE_TRACEME: Operation not permitted' in strace and read(B/'strace-unavailable-attempt/evidence/01-no-argument.stdout.bin')==b'' and read(B/'strace-unavailable-attempt/evidence/01-no-argument.strace')==b'','strace unavailability preserved with empty outputs')
# End-of-audit identity stability; no running fixture manipulated.
for x in inventory:
 b=read(Path(x['path']));ck(len(b)==x['bytes'] and sha(b)==x['sha256'],'all original preflight files unchanged at audit end '+x['path'])
anomaly={'saved_initial_branch':{'metadata':info(B/'ledger-anomaly-per-call-events.json'),**saved_chain,'call_count':20,'successful_calls':6},'observed_later_branch':{'ledger':info(B/'ledger-anomaly-observed.jsonl'),**obs_chain,'shared_original_prefix_events':16,'later_rejection_events':2},'missing_original_tail_events':80,'extra_attempt':{'result':info(Path(str(extra)+'.result.json')),'ledger_call_id':ee[0]['call_id'],'assertion_failures':['reason','cursor','operation'],'empty_stdout':True,'no_fixture_open_or_read':True},'original96_not_restored_to_runtime':True,'cause_established':False,'specific_truncation_or_restoration_operation_identified':False,'launcher_and_observer_evidence':'Every launcher copy matches supplied original. Audited launcher opens ledger O_APPEND, and all captured writer-open flags have O_APPEND without O_TRUNC. Setup/deployment code contains no operation that restores or truncates a runtime ledger. Evidence is not a kernel-wide trace and cannot rule out unrecorded external actions or environment persistence events.','integrity_limit':'A valid stored prefix plus a new valid call remains a valid hash chain; local chain validation cannot detect loss of an earlier valid tail without a separately retained expected tail/snapshot. This characterizes available evidence and an operational limit, not a cause or launcher defect.','fresh_flow_does_not_repair_or_explain_original_anomaly':True}
limits=['Only the authorized subject-free preflight tree and unchanged supplied launcher were read. No current teaching/source/prompts/findings or later author artifacts inspected.','49 passing named checks contain361 saved assertions;50 invocation-result records exist, including the explicitly preserved failed first completion attempt. No failed attempt is erased or relabeled successful.','Observer evidence consists of CPython audit open events, not kernel syscall coverage. strace was unavailable; no technical confinement or total-environment access claim.','Retained actual tool objects, capture metadata and derived receipt bind exact synthetic image bytes and timing. Capture IDs are explicitly orchestrator-generated, not provider-issued. This is not a cryptographically authenticated platform transcript or proof of semantic inspection.','The initial shortened ledger remains unexplained and unrepaired. Fresh123-event flow and exact prefix snapshots support the current successful mechanism check without repairing or identifying the cause of the prior branch.','No fixture/helper/launcher replay, browser or view_image call was made in this audit.']
pending=['Audit the separately supplied actual whole-frozen route, launcher/helper bytes and seals before real-reader dispatch; bind all frozen complete-file and slice hashes and immutable revision IDs.','Verify full actual baseline-before-teaching coverage, exact byte ranges and declared figure-first-use timing; source semantic placement remains the relevant reviewer\'s responsibility.','Use a fresh runtime and preserve external exact ledger snapshots/tail identities at operational checkpoints, as INTEGRATION.md already specifies. Stop on a mismatch rather than restoring/reconstructing the live ledger.','After the actual reader completes, compare every call/output hash/state transition and complete coverage; correlate each original actual image return and derived receipt with correct invocation/timing/unique local ID provenance.','Seal and compare original final reader reports and any disclosed later metadata operations. Actual reader admission, destination geometry and scientific/learning judgments remain separate.']
report={'schema':'independent-d015-subject-free-preflight-review-v1','mechanism_gate':'SATISFIED_FOR_SUBJECT_FREE_OPERATIONAL_PREFLIGHT_WITH_PRESERVED_ANOMALY_AND_LIMITS','actual_D015_reader_admitted':False,'source':info(SOURCE),'results':info(B/'results.json'),'evidence_manifest':info(B/'evidence-manifest.json'),'declared_evidence_files':408,'actual_tree_files':411,'intentional_manifest_exclusions':excluded,'inventory':inventory,'unchanged_launcher_copies':launchers,'reviewed_code':code,'routed_fixture_paths':route_records,'passing_check_records':49,'passing_saved_assertions':361,'successful_invocations_in_49':16,'rejected_invocations_in_49':33,'total_retained_invocation_records':50,'per_call_verification':percall,'non_main_case_chain_checks':case_chains,'valid_route_state_reconstructions':state_records,'fresh_flow':{'ledger':info(froot/'runtime/ledger.jsonl'),'event_count':123,'call_count':16,'successful_calls':10,'rejected_calls':6,'final_cursor':6,'pending_figure':None,'initial_fixture_bytes':source_sizes,'exact_prefix_snapshots':snapshots,'pre_view_snapshot':info(B/'receipt-flow-pre-view-ledger.jsonl'),'pre_view_events':66,'initial_route_complete':True},'preserved_original_tool_results':views,'anomaly':anomaly,'observer':{'external_open_paths':sorted(set(external_opens)),'observed_append_only_ledger_writes':len(ledger_writes),'zero_observed_ledger_truncating_writes':True,'instrumentation':'CPython audit hook, not kernel tracing'},'append_probe':info(B/'append-persistence-probe.log'),'strace_error':strace,'limits':limits,'remaining_actual_route_and_reader_audits':pending,'independent_check_count':len(checks),'audit_code':outinfo(Path(__file__))}
save('verification.json',report)
(O/'report.md').write_text('D015 subject-free mechanism preflight: satisfied, with the preserved initial ledger anomaly and stated limits. Actual D015 route/reader admission remains pending.\n\nVerified the pinned results and408-file evidence manifest against every actual member; the411-file tree adds only the manifest itself and two excluded Python caches. All deployed launcher copies match SHA256 '+LH+'. Reviewed all five operational Python files (315 lines) and the integration note; no fixture tests or image views were repeated.\n\nThe49 passing named checks contain361 assertions and cover16 successful/33 rejected invocations. Raw stdout/stderr, per-call events, CPython open observations, source byte slices, read hashes, state/cursor behavior and receipt bindings were independently checked. A50th preserved result is the failed initial completion attempt: expected reason/cursor/operation did not match because the shortened ledger caused an earlier scheduled-step rejection. It returned no content and opened/read no fixture.\n\nFresh receipt-flow: all123 event hashes/links and16 calls verify;10 calls succeed and6 reject, with complete initial route, cursor-preserving revisits and one accepted actual-view receipt. The66-event pre-view snapshot and six per-call full-ledger snapshots are exact prefixes of the final ledger. Both original image-result objects decode exactly to their211-byte synthetic PNG; the fresh derived receipt is byte-identical to the ledger-bound receipt. All timestamps follow dispatch → view → receipt → resumed output. Local capture identifiers are not provider-issued IDs.\n\nInitial anomaly: the saved96-event per-call branch is a valid chain. The observed18-event runtime branch contains the first16 original events plus a new two-event rejection; the prior80-event tail is absent. Both branches and the failed invocation remain intact. No cause is established. Audited launcher source uses append mode, captured writer-open flags contain O_APPEND and no O_TRUNC, and the setup code has no runtime-ledger restoration/truncation operation. These observations cannot rule out events outside the captured Python process. A locally valid hash-chain prefix cannot itself prove retention of an earlier tail; retain external expected snapshots/tails as the existing integration note specifies. Fresh-flow success neither repairs the old evidence nor proves a cause. No fabrication or launcher-defect inference is made.\n\nRemaining actual D015 work:\n\n'+''.join('- '+x+'\n' for x in pending)+'\nLimits:\n\n'+''.join('- '+x+'\n' for x in limits)+'\nFresh ledger SHA256: '+FH+'\nFull identities, per-call records and anomaly witnesses: verification.json.\n')
save('output-manifest.json',{'files':[outinfo(O/n) for n in ['audit_preflight.py','verification.json','report.md']]})
print(json.dumps({'gate':report['mechanism_gate'],'checks':len(checks),'declared_files':408,'passing_check_records':49,'retained_invocations':50,'fresh_events':123,'outputs':[outinfo(O/n) for n in ['report.md','verification.json','output-manifest.json']]}))
