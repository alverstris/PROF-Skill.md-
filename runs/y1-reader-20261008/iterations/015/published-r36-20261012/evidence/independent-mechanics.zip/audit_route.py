#!/usr/bin/env python3
"""Read-only pinned D015 route audit. No launcher execution or live runtime access.
Subject bytes are used only for identities, bounded-slice hashes, UTF-8 boundary
checks, and image-path markup locations. No subject prose is emitted.
"""
from pathlib import Path
import hashlib,json,re,datetime
BASE=Path('/workspace/scratch/f9c0b7fc7e76/d015-clean-r36-20261012')
OUT=Path('/workspace/scratch/f9c0b7fc7e76/root-independent-reader-mechanics/d015-r36')
PINS={'author/whole-freeze.json':'0f52edf74fe3bf9794a061880c201e423fbc37faa71416828c6c2bf682c2f3bb','reader/route.json':'862bf62a76c06706588c45f84597e16c84a93a5c8234fca5599723485d70c4d6','reader/route-seal.json':'a3a27e00875e6b340da393b9f94dbbb0a1f6ceff904a2c1b96b6f95ad2d804b5','reader/read-step':'d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd','inputs/operational-tools/read-step':'d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd'}
checks=[]
def check(ok,name,**witness):
    checks.append(dict(check=name,pass_=bool(ok),**witness))
    if not ok: raise AssertionError(name)
def sha(b):return hashlib.sha256(b).hexdigest()
def pairs(items):
    d={}
    for k,v in items:
        if k in d:raise ValueError('duplicate JSON key')
        d[k]=v
    return d
def load(b):return json.loads(b,object_pairs_hook=pairs)
def exact(o,keys,name):check(type(o) is dict and set(o)==set(keys),name)
def ident(s,name):check(type(s) is str and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,127}',s) is not None,name)
def digest(s,name):check(type(s) is str and re.fullmatch('[0-9a-f]{64}',s) is not None,name)
def regular(p):
    check(p.is_absolute() and p.is_file() and not p.is_symlink() and all(not a.is_symlink() for a in p.parents),'regular nonsymlink path',path=str(p))
    return p.read_bytes()
controls={}
for p,h in PINS.items():
    raw=regular(BASE/p);check(sha(raw)==h,'pinned control identity',path=p,bytes=len(raw),sha256=sha(raw));controls[p]=raw
freeze=load(controls['author/whole-freeze.json']); route=load(controls['reader/route.json']);seal=load(controls['reader/route-seal.json'])
check(controls['reader/read-step']==controls['inputs/operational-tools/read-step'] and len(controls['reader/read-step'])==25227,'actual launcher equals provided preflighted launcher')
expected_paths={'teaching/main.md','teaching/hints.md','teaching/solutions.md','teaching/figures/gaussian.png','teaching/figures/tangent-ray.png','teaching/figures/perpendicular-families.png'}
check(len(freeze['files'])==freeze['count']==6 and {f['path'] for f in freeze['files']}==expected_paths,'exact six frozen file identities')
frozen={}; rawfiles={}
for f in freeze['files']:
    p=BASE/f['path'];check(str(p)==f['absolute_path'],'freeze relative absolute agreement',path=f['path']);raw=regular(p)
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    check(len(raw)==f['bytes'] and sha(raw)==f['sha256'] and blob==f['git_blob'],'actual frozen bytes hash and git blob',path=f['path'],bytes=len(raw),sha256=sha(raw),git_blob=blob)
    frozen[str(p)]=f;rawfiles[str(p)]=raw
check(sum(f['bytes'] for f in freeze['files'])==freeze['bytes']==186982,'complete teaching bytes')
exact(route,['schema','route_id','artifacts','files','steps','revisits'],'route fields')
exact(seal,['schema','route_id','route_sha256','launcher_sha256'],'seal fields')
check(route['schema']=='sasis-fixed-route-v1' and seal['schema']=='sasis-route-seal-v1' and route['route_id']==seal['route_id']=='D015-r36-frozen','route schema and identity')
check(seal['route_sha256']==PINS['reader/route.json'] and seal['launcher_sha256']==PINS['reader/read-step'],'sealed route launcher linkage')
exact(route['artifacts'],['baseline','teaching'],'artifact fields')
for key,a in route['artifacts'].items():
    exact(a,['id','revision'],'artifact identity fields');check(type(a['id']) is str and bool(a['id']),'nonempty artifact id')
check(route['artifacts']['baseline']['revision']=='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5' and route['artifacts']['teaching']['revision']==PINS['author/whole-freeze.json'],'revisions bind full baseline and frozen generation')
files={};paths=set();file_records=[]
for f in route['files']:
    exact(f,['id','artifact','kind','path','size','sha256'],'file fields');ident(f['id'],'file id');digest(f['sha256'],'file digest')
    check(f['id'] not in files and f['path'] not in paths,'unique file path and id')
    check(type(f['size']) is int and f['size']>0,'positive integer file size')
    if f['artifact']=='teaching':
        check(f['path'] in frozen,'teaching path in frozen six');z=frozen[f['path']]
        check(f['sha256']==z['sha256'] and f['size']==z['bytes'] and f['kind']==('image' if z['path'].endswith('.png') else 'text'),'route matches actual frozen file')
    else:
        check(f['id']=='baseline' and f['artifact']=='baseline' and f['kind']=='text' and f['path']==str(BASE/'inputs/student-baseline.txt') and f['size']==247840 and f['sha256']==route['artifacts']['baseline']['revision'],'only full baseline as additional subject file')
        rawfiles[f['path']]=regular(Path(f['path']))
    b=rawfiles[f['path']];check(len(b)==f['size'] and sha(b)==f['sha256'],'route file actual bytes',file_id=f['id'],bytes=len(b),sha256=sha(b))
    files[f['id']]=f;paths.add(f['path']);file_records.append(f)
check(len(files)==7 and {f['path'] for f in files.values() if f['artifact']=='teaching'}==set(frozen),'route exact full seven files')
coverage={k:[] for k in files};seen={};allids=set();receiptpaths=set();expanded=[];step_records=[];figures=[];teaching_started=False
for index,s in enumerate(route['steps']):
    check(s.get('kind') in ['text','figure'],'known retrieval kind')
    exact(s,['id','kind','file_id','start','end','sha256'] if s['kind']=='text' else ['id','kind','file_id','sha256','receipt_step_id','receipt_file','first_use'],'step fields')
    ident(s['id'],'step id');digest(s['sha256'],'step digest');check(s['id'] not in allids and s['file_id'] in files,'unique valid step id');allids.add(s['id'])
    f=files[s['file_id']];raw=rawfiles[f['path']]
    if f['artifact']=='teaching':teaching_started=True
    else:check(not teaching_started,'all baseline before teaching')
    expanded.append(s['id'])
    if s['kind']=='text':
        check(f['kind']=='text' and type(s['start']) is int and type(s['end']) is int and 0<=s['start']<s['end']<=len(raw) and s['end']-s['start']<=1024*1024,'bounded text range',step_id=s['id'])
        chunk=raw[s['start']:s['end']];check(sha(chunk)==s['sha256'],'actual text slice hash',step_id=s['id'],bytes=len(chunk),sha256=sha(chunk))
        chunk.decode('utf-8');coverage[f['id']].append([s['start'],s['end']])
        step_records.append(dict(index=index,**s,bytes=len(chunk),actual_sha256=sha(chunk),utf8_boundary_valid=True))
    else:
        check(f['kind']=='image' and f['artifact']=='teaching' and len(raw)<=128*1024*1024 and s['sha256']==sha(raw),'complete actual figure bytes',step_id=s['id'])
        ident(s['receipt_step_id'],'receipt id');check(s['receipt_step_id'] not in allids,'unique receipt id');allids.add(s['receipt_step_id']);expanded.append(s['receipt_step_id'])
        rp=Path(s['receipt_file']);check(rp.is_absolute() and rp.parent==BASE/'reader/view-results' and rp.suffix=='.json' and str(rp) not in paths and str(rp) not in receiptpaths,'fixed external unique receipt path');receiptpaths.add(str(rp))
        exact(s['first_use'],['text_step_id','position'],'first-use fields');tid=s['first_use']['text_step_id']
        check(s['first_use']['position']=='after' and tid in seen and seen[tid]['kind']=='text' and files[seen[tid]['file_id']]['artifact']=='teaching','first-use prior teaching text')
        ti=next(i for i,x in enumerate(route['steps']) if x['id']==tid)
        check(all(x['kind']=='figure' for x in route['steps'][ti+1:index]),'no later text before first-use image',step_id=s['id'])
        # Mechanical first-use only: scan src references, emit offsets not text/alt.
        target='figures/'+Path(f['path']).name
        occurrences=[]
        for tf in files.values():
            if tf['artifact']!='teaching' or tf['kind']!='text':continue
            for m in re.finditer(rb'<img\b[^>]*\bsrc\s*=\s*[\"\x27]([^\"\x27]+)[\"\x27][^>]*>',rawfiles[tf['path']],re.I):
                if m.group(1).decode()==target:occurrences.append(dict(file_id=tf['id'],start=m.start(),end=m.end()))
        check(len(occurrences)==1,'exact one HTML source image reference',step_id=s['id'],occurrences=occurrences)
        o=occurrences[0];t=seen[tid]
        check(o['file_id']==t['file_id'] and t['start']<=o['start']<o['end']<=t['end'],'source image markup contained in declared first-use text slice',step_id=s['id'],text_step_id=tid,markup_start=o['start'],markup_end=o['end'])
        coverage[f['id']].append([0,len(raw)])
        record=dict(index=index,**s,actual_bytes=len(raw),actual_sha256=sha(raw),markup_occurrences=occurrences)
        figures.append(record);step_records.append(record)
    seen[s['id']]=s
for fid,ranges in coverage.items():
    cursor=0
    for start,end in ranges:check(start==cursor,'contiguous ordered coverage',file_id=fid,start=start,expected_start=cursor);cursor=end
    check(cursor==files[fid]['size'],'complete exact-once coverage',file_id=fid,covered_bytes=cursor)
revisits=[]
for rv in route['revisits']:
    exact(rv,['id','initial_step_id'],'revisit fields');ident(rv['id'],'revisit id');check(rv['id'] not in allids,'unique revisit id');allids.add(rv['id'])
    check(rv['initial_step_id'] in seen and seen[rv['initial_step_id']]['kind']=='text' and files[seen[rv['initial_step_id']]['file_id']]['artifact']=='baseline','revisit confined to bounded initial baseline step')
    revisits.append(rv)
check(len(revisits)==11 and {r['initial_step_id'] for r in revisits}=={s['id'] for s in route['steps'] if s['file_id']=='baseline'},'each baseline step has one declared revisit')
check(len(route['steps'])==33 and len(expanded)==36 and len(figures)==3,'independent retrieval and receipt stage counts')
result={'schema':'d015-independent-mechanical-route-admission-v1','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outcome':'SATISFIED_FOR_PINNED_CURRENT_ROUTE_OPERATIONAL_ADMISSION','chronology':'Parent reported author dispatched the fresh SASIS run after author validation, while this independent route audit was pending. This admission is post-dispatch; it is not independent pre-dispatch clearance. No active runtime or reader report was opened.','input_pins':PINS,'file_records':file_records,'step_records':step_records,'expanded_required_success_order':expanded,'revisits':revisits,'coverage':coverage,'counts':{'frozen_files':6,'route_files':7,'frozen_bytes':186982,'baseline_text_steps':11,'baseline_bytes':247840,'teaching_text_steps':19,'teaching_text_bytes':28990,'figure_dispatch_steps':3,'figure_bytes':157992,'figure_receipt_steps':3,'route_retrieval_steps':33,'expanded_required_success_stages':36,'declared_baseline_revisits':11},'receipt_mechanism':{'launcher_exact_preflighted_bytes':True,'cursor_held_until_fixed_receipt_step':True,'baseline_revisits_allowed_if_already_seen_while_pending':True,'no_later_teaching_advance_while_pending':True,'required_tool':'tools.view_image','required_detail':'original','fixed_figure_path_and_sha256':True,'requires_unique_receipt_call_id_and_completion_after_dispatch':True,'receipt_itself_is_not_authenticated_platform_transcript':True,'semantic_inspection_proven_by_launcher':False},'limits':['This is mechanical identity, exact coverage, source-image markup placement and receipt routing review only. No teaching prose or image semantic interpretation.','No actual run ledger, outputs, image tool results or final report has been inspected by this current-route audit. Full actual reader evidence remains required after completion.','First-use is mechanically verified against the first/only literal HTML image reference and its containing text slice, not a semantic teaching judgment.','Receipt metadata must be corroborated with retained actual result objects and exact decoded image bytes after completion; generated correlation IDs must not be relabeled platform IDs.','Initial synthetic preflight ledger-shortening anomaly remains preserved with cause unresolved. External recorded ledger tails/snapshots are necessary for detecting loss of a valid suffix.'], 'checks':checks,'checks_count':len(checks),'all_checks_pass':True}
(OUT/'route-admission.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'outcome':result['outcome'],'checks':len(checks),'counts':result['counts'],'route_admission_sha256':sha((OUT/'route-admission.json').read_bytes())},indent=2))
