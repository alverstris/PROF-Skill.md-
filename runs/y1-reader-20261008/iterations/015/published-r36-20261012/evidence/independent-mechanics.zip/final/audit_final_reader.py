#!/usr/bin/env python3
"""Independent read-only D015 final-reader mechanics audit; never subject review.
No launcher, browser, view_image, fixture, or reader helper is executed.
"""
from pathlib import Path
import base64,collections,datetime,hashlib,json,re
BASE=Path('/workspace/scratch/f9c0b7fc7e76/d015-clean-r36-20261012')
R=BASE/'reader';OUT=Path('/workspace/scratch/f9c0b7fc7e76/root-independent-reader-mechanics/d015-r36/final')
checks=[];loaded={}
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate JSON key')
  d[k]=v
 return d
def loadbytes(p):
 p=Path(p);assert p.is_file() and not p.is_symlink()
 if str(p) not in loaded:loaded[str(p)]=p.read_bytes()
 return loaded[str(p)]
def js(p):return json.loads(loadbytes(p),object_pairs_hook=pairs)
def check(ok,label,**witness):
 checks.append({'check':label,'pass':bool(ok),**witness})
 if not ok:raise AssertionError((label,witness))
def dt(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
pins={'author/whole-freeze.json':'0f52edf74fe3bf9794a061880c201e423fbc37faa71416828c6c2bf682c2f3bb','reader/route.json':'862bf62a76c06706588c45f84597e16c84a93a5c8234fca5599723485d70c4d6','reader/route-seal.json':'a3a27e00875e6b340da393b9f94dbbb0a1f6ceff904a2c1b96b6f95ad2d804b5','reader/read-step':'d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd','inputs/operational-tools/read-step':'d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd','reader/report.md':'848e53c923a129e13c281e99194f58454017a22d6fc0eb3bebab48a74880b279','reader/reconstruction.md':'d2384fa3260d6075af981bec132d6ec47aeedaef725f1eb4bd552284a93103a8'}
for rel,h in pins.items():check(sha(loadbytes(BASE/rel))==h,'exact pinned input',path=rel,sha256=h)
seal=js(BASE/'evidence/reader-original-seal.json');check(len(seal['files'])==2,'original seal exact two artifacts')
for f in seal['files']:
 b=loadbytes(BASE/f['path']);check(len(b)==f['bytes'] and sha(b)==f['sha256']==pins[f['path']],'original final report/record bytes',**f)
check(len(loadbytes(R/'report.md'))==22442 and len(loadbytes(R/'reconstruction.md'))==14319,'original report and reconstruction sizes')
freeze=js(BASE/'author/whole-freeze.json');route=js(R/'route.json');route_seal=js(R/'route-seal.json');files={f['id']:f for f in route['files']}
for f in freeze['files']:
 b=loadbytes(BASE/f['path']);check(len(b)==f['bytes'] and sha(b)==f['sha256'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['git_blob'],'frozen six unchanged',path=f['path'],bytes=len(b),sha256=sha(b))
for f in files.values():check(len(loadbytes(f['path']))==f['size'] and sha(loadbytes(f['path']))==f['sha256'],'route file exact current bytes',file_id=f['id'])
check(route_seal['route_sha256']==pins['reader/route.json'] and route_seal['launcher_sha256']==pins['reader/read-step'],'route seal bindings')
raw=loadbytes(R/'runtime/ledger.jsonl');lines=raw.splitlines(keepends=True);events=[json.loads(x,object_pairs_hook=pairs) for x in lines]
previous='0'*64;last_at=None;groups=[];bycall={}
for i,e in enumerate(events):
 check(set(e)=={'index','at','call_id','event','data','previous','sha256'},'event exact schema',index=i)
 o={k:v for k,v in e.items() if k!='sha256'}
 check(e['index']==i and e['previous']==previous and sha(canonical(o))==e['sha256'],'complete chronological hash chain',index=i)
 check(lines[i]==canonical(e)+b'\n','ledger exact canonical serialization',index=i)
 t=dt(e['at']);check(t.tzinfo is not None and (last_at is None or t>=last_at),'monotonic event timestamp',index=i);last_at=t;previous=e['sha256']
 if not groups or e['call_id']!=groups[-1][0]['call_id']:
  check(e['call_id'] not in bycall,'no reopened/interleaved call id',index=i)
  groups.append([]);bycall[e['call_id']]=groups[-1]
 groups[-1].append(e)
check(len(events)==384 and len(groups)==36,'independent actual events and calls',events=len(events),calls=len(groups))
steps={s['id']:s for s in route['steps']};expected=[]
for s in route['steps']:
 expected.append((s['id'],'text' if s['kind']=='text' else 'figure_dispatched',s))
 if s['kind']=='figure':expected.append((s['receipt_step_id'],'figure_received',s))
check(len(expected)==36,'expanded frozen route stages')
coverage={f:[] for f in files};call_records=[];figure_records=[];cursor=0;pending=None;raw_exec_names=set();rawchunkids=set();local_viewids=set();boundaries=[0];running_bytes=0
for ordinal,(g,exp) in enumerate(zip(groups,expected),1):
 sid,op,s=exp;fid=s['file_id'];f=files[fid];data=loadbytes(f['path']);ev={e['event']:e for e in g}
 names=[e['event'] for e in g]
 expected_events=['call_attempt','route_validated']+(['figure_receipt_accepted'] if op=='figure_received' else ['subject_open_attempt','subject_opened','subject_read','subject_closed','actual_access'])+['stdout_begin','stdout_complete','state_commit','call_finished']
 check(names==expected_events,'exact per-call chronological event vocabulary/order',step=sid,events=names)
 check(ev['call_attempt']['data']=={'argv':[sid]},'exact fixed step invocation',step=sid)
 check(ev['route_validated']['data']=={'cursor':cursor,'launcher_sha256':pins['reader/read-step'],'operation':op,'pending_figure':pending,'route_id':route['route_id'],'route_sha256':pins['reader/route.json'],'step_id':sid},'exact replay cursor pending and pinned route',step=sid)
 if op=='figure_received':
  rp=Path(s['receipt_file']);receipt_bytes=loadbytes(rp);receipt=js(rp);accepted=ev['figure_receipt_accepted']['data']
  check(pending==s['id'] and sid==s['receipt_step_id'],'receipt immediately resolves pending figure',step=sid)
  check(accepted=={'figure_step_id':s['id'],'receipt':receipt,'receipt_file':str(rp),'receipt_sha256':sha(receipt_bytes),'semantic_inspection_proven':False,'tool_call_id':receipt['tool_call_id']},'actual accepted receipt exact on-disk original bytes',step=sid)
  expected_receipt_keys={'schema','route_id','figure_step_id','receipt_step_id','image_path','image_sha256','tool_name','tool_call_id','completed_at','invocation','result_metadata'}
  check(set(receipt)==expected_receipt_keys,'receipt exact schema',step=sid)
  check(receipt['schema']=='sasis-view-result-v1' and receipt['route_id']==route['route_id'] and receipt['figure_step_id']==s['id'] and receipt['receipt_step_id']==sid and receipt['image_path']==f['path'] and receipt['image_sha256']==f['sha256'] and receipt['tool_name']=='tools.view_image','receipt fixed identities',step=sid)
  viewmeta=js(R/f"raw-results/{s['id']}-capture.json");resultpath=R/f"raw-results/{s['id']}-result.json";resultbytes=loadbytes(resultpath);result=js(resultpath)
  check(set(result)=={'image_url','detail'} and result['detail']=='original','retained original view result schema',step=sid)
  check(set(viewmeta)=={'invocation','tool_call_id','started_at','completed_at','identity_provenance','raw_result'},'view capture metadata exact schema',step=sid)
  invocation={'path':f['path'],'detail':'original'}
  check(receipt['invocation']==viewmeta['invocation']==invocation and viewmeta['raw_result']==resultpath.name and receipt['tool_call_id']==viewmeta['tool_call_id'] and receipt['completed_at']==viewmeta['completed_at'],'actual result/receipt invocation binding',step=sid)
  check(viewmeta['identity_provenance']=='local capture identifier; provider ID not exposed' and viewmeta['tool_call_id'] not in local_viewids,'local view ID provenance and uniqueness',step=sid);local_viewids.add(viewmeta['tool_call_id'])
  m=re.fullmatch(r'data:([^;,]+);base64,([A-Za-z0-9+/=]+)',result['image_url']);check(m is not None,'original result complete base64 data URL',step=sid)
  image=base64.b64decode(m[2],validate=True)
  check(image==data and sha(image)==f['sha256'] and len(image)==f['size'] and image[:8]==b'\x89PNG\r\n\x1a\n','decoded original result exact frozen PNG',step=sid,bytes=len(image),sha256=sha(image))
  expected_metadata={'success':True,'kind':'image','detail':'original','image_url_sha256':sha(result['image_url'].encode()),'image_url_chars':len(result['image_url']),'mime_type':m[1]}
  check(receipt['result_metadata']==expected_metadata,'receipt metadata derived from exact original result URL',step=sid,**expected_metadata)
  dispatch=groups[ordinal-2][-2]
  check(dispatch['event']=='state_commit' and dispatch['data']['step_id']==s['id'] and dt(dispatch['at'])<=dt(viewmeta['started_at'])<=dt(viewmeta['completed_at'])<=dt(g[0]['at'])<=dt(ev['figure_receipt_accepted']['at']),'dispatch before actual view before receipt chronology',step=sid)
  helper=js(R/f"raw-results/{s['id']}-make-receipt-exec.json")
  check(helper['exit_code']==0 and json.loads(helper['output'])=={'receipt':str(rp),'raw_bytes':len(resultbytes),'raw_sha256':sha(resultbytes),'decoded_original_image_sha256':sha(image)},'retained receipt-helper returned result binding',step=sid)
  next_step=route['steps'][cursor+1]['id'] if cursor+1<len(route['steps']) else None
  output=canonical({'status':'figure_tool_receipt_recorded','figure_step_id':s['id'],'next_step_id':next_step,'semantic_inspection_proven':False})+b'\n';kind='operational_receipt_ack'
  figure_records.append({'figure_step_id':s['id'],'receipt_step_id':sid,'image_path':f['path'],'image_bytes':len(image),'image_sha256':sha(image),'result_path':str(resultpath),'result_bytes':len(resultbytes),'result_sha256':sha(resultbytes),'image_url_sha256':expected_metadata['image_url_sha256'],'image_url_chars':expected_metadata['image_url_chars'],'mime_type':m[1],'receipt_sha256':sha(receipt_bytes),'tool_call_id':viewmeta['tool_call_id'],'identity_provenance':viewmeta['identity_provenance'],'started_at':viewmeta['started_at'],'completed_at':viewmeta['completed_at'],'dispatch_call_id':dispatch['call_id'],'receipt_call_id':g[0]['call_id'],'receipt_event_index':ev['figure_receipt_accepted']['index'],'decoded_bytes_match':True})
  cursor+=1;pending=None
 else:
  start,end=(s['start'],s['end']) if op=='text' else (0,len(data));chunk=data[start:end]
  check(sha(chunk)==s['sha256'],'exact frozen retrieval slice hash',step=sid)
  check(ev['subject_open_attempt']['data']=={'end':end,'file_id':fid,'path':f['path'],'start':start},'only authorized subject path and range',step=sid)
  opened=ev['subject_opened']['data'];check(set(opened)=={'device','file_id','inode','size'} and opened['file_id']==fid and opened['size']==len(data) and type(opened['device']) is int and type(opened['inode']) is int,'opened file metadata and fixed size',step=sid)
  check(ev['subject_read']['data']=={'file_id':fid,'offset':start,'requested':len(chunk),'returned':len(chunk),'sha256':sha(chunk)},'every actual read exact bytes offset and hash',step=sid)
  check(ev['subject_closed']['data']=={'file_id':fid},'subject closed before verification',step=sid)
  check(ev['actual_access']['data']=={'bytes':len(chunk),'content_displayed':False,'end':end,'expected_sha256':s['sha256'],'file_id':fid,'path':f['path'],'sha256':sha(chunk),'start':start,'verified':True},'verified actual access before any output',step=sid)
  coverage[fid].append([start,end])
  if op=='text':output=chunk;kind='subject_text_exact_bytes';cursor+=1
  else:
   output=canonical({'status':'figure_requires_actual_view','figure_step_id':s['id'],'image_path':f['path'],'image_sha256':f['sha256'],'image_bytes':f['size'],'view_tool':'tools.view_image','view_detail':'original','receipt_step_id':s['receipt_step_id'],'receipt_file':s['receipt_file'],'cursor_held':True})+b'\n';kind='image_path_only_not_image_display';pending=s['id']
 for en,status in [('stdout_begin','not_observable_by_launcher'),('stdout_complete','transport_written_not_proof_of_reader_display')]:
  check(ev[en]['data']=={'bytes':len(output),'display_status':status,'kind':kind,'sha256':sha(output)},'all output bytes/hash/kind match exact expected output',step=sid,event=en)
 rawpath=R/f'raw-results/{sid}-exec.json';raw_exec_names.add(rawpath.name);wrapper=js(rawpath)
 check(set(wrapper)=={'chunk_id','wall_time_seconds','exit_code','original_token_count','output'} and wrapper['exit_code']==0 and wrapper['output'].encode('utf-8')==output,'retained actual exec output exact untruncated bytes',step=sid,chunk_id=wrapper['chunk_id'])
 check(wrapper['chunk_id'] not in rawchunkids,'unique retained exec chunk ID',step=sid);rawchunkids.add(wrapper['chunk_id'])
 check(ev['state_commit']['data']=={'operation':op,'route_sha256':pins['reader/route.json'],'step_id':sid} and ev['call_finished']['data']=={'outcome':'success'},'only successful complete expected state commit',step=sid)
 call_records.append({'ordinal':ordinal,'step_id':sid,'operation':op,'call_id':g[0]['call_id'],'raw_exec_chunk_id':wrapper['chunk_id'],'first_event_index':g[0]['index'],'last_event_index':g[-1]['index'],'first_at':g[0]['at'],'last_at':g[-1]['at'],'raw_exec_bytes':len(loadbytes(rawpath)),'raw_exec_sha256':sha(loadbytes(rawpath)),'output_bytes':len(output),'output_sha256':sha(output),'all_checks_pass':True})
 running_bytes=sum(len(x) for x in lines[:g[-1]['index']+1]);boundaries.append(running_bytes)
check(cursor==len(route['steps'])==33 and pending is None,'full route completion without omitted/bypassed/pending stage')
check({p.name for p in (R/'raw-results').glob('*-exec.json')}==raw_exec_names|{f'F{i:02}-make-receipt-exec.json' for i in range(1,4)},'all retained exec wrappers accounted for')
for fid,ranges in coverage.items():
 pos=0
 for start,end in ranges:check(start==pos,'actual contiguous exact-once subject coverage',file_id=fid,start=start,prior_end=pos);pos=end
 check(pos==files[fid]['size'],'actual full subject file coverage',file_id=fid,bytes=pos)
check(len(coverage['baseline'])==11 and files['baseline']['size']==247840,'actual full baseline chunk count and bytes')
check(sum(len(v) for k,v in coverage.items() if files[k]['kind']=='text' and files[k]['artifact']=='teaching')==19 and sum(f['size'] for f in files.values() if f['artifact']=='teaching' and f['kind']=='text')==28990,'actual all teaching text slices and bytes')
check(sum(f['size'] for f in files.values() if f['artifact']=='teaching')==186982,'actual all teaching bytes including figures')
checkpoint_records=[];snapshots=sorted((R/'checkpoints').glob('*-ledger.jsonl'));check(len(snapshots)==37,'checkpoint count equals initial plus every successful call')
prior=b''
for i,(p,bound) in enumerate(zip(snapshots,boundaries),1):
 b=loadbytes(p);check(p.name==f'{i:03}-ledger.jsonl' and b==raw[:bound] and b.startswith(prior),'each checkpoint is exact final-ledger prefix at every call boundary',snapshot=p.name,bytes=len(b),events=len(b.splitlines()),sha256=sha(b))
 checkpoint_records.append({'snapshot':p.name,'bytes':len(b),'events':len(b.splitlines()),'sha256':sha(b),'exact_final_prefix':True});prior=b
latest=js(R/'checkpoints/latest.json');check(latest['number']==37 and latest['snapshot']==snapshots[-1].name and latest['bytes']==len(raw) and latest['events']==len(events) and latest['sha256']==sha(raw) and latest['prefix_preserved'] is True and dt(latest['time'])>=dt(events[-1]['at']),'latest checkpoint exact final complete ledger')
check(not (R/'checkpoints/ledger-mismatch.json').exists() and not (R/'checkpoints/ledger-mismatch-observed.jsonl').exists(),'no retained current-run checkpoint mismatch artifact')
check(dt(seal['sealed_at'])>=dt(latest['time']),'final original seal after completed route/checkpoint')
# Report contents are never interpreted; only the reconstruction's operational disclosure is extracted.
reconstruction=loadbytes(R/'reconstruction.md').decode();disclosures=[line for line in reconstruction.splitlines() if line.startswith('After the report was written, one attempt')]
check(len(disclosures)==1 and 'multiple operations target' in disclosures[0] and 'transcribed' in disclosures[0] and 'Separate sequential Delete and Add operations' in disclosures[0],'original reconstruction discloses post-reading edit failure as transcription not raw object')
check('apply_patch' not in collections.Counter(e['event'] for e in events),'operational editing failure is not mislabeled a launcher failure')
admission=js(BASE/'evidence/reader-access-admission.json')
check(admission['events']==len(events) and admission['successful_stages']==len(groups) and admission['stages']==[s[0] for s in expected] and admission['text_output_count']==30 and admission['actual_access_count']==33 and admission['checkpoints']==37 and admission['unresolved_launcher_failure_calls']==[],'author mechanical admission agrees with independent raw verification')
for af in admission['files']:
 s=steps[af['step']];check(af['file_id']==s['file_id'] and af['sha256']==s['sha256'] and af['bytes']==(s['end']-s['start'] if s['kind']=='text' else files[s['file_id']]['size']),'author per-step identity matches independently verified route',step=s['id'])
for af,fr in zip(admission['figures'],figure_records):check(af['id']==fr['figure_step_id'] and af['original_result_sha256']==fr['result_sha256'] and af['image_sha256']==fr['image_sha256'] and af['image_url_sha256']==fr['image_url_sha256'] and af['local_identity_provenance']==fr['identity_provenance'],'author figure identity agrees with exact retained result',figure=fr['figure_step_id'])
# Opaque inventory only for every retained reader file; no student-role or report prose emitted.
reader_inventory=[]
for p in sorted(R.rglob('*')):
 if p.is_file():
  b=loadbytes(p);reader_inventory.append({'path':str(p.relative_to(BASE)),'bytes':len(b),'sha256':sha(b)})
for p,b in loaded.items():check(Path(p).read_bytes()==b,'audit inputs unchanged throughout review',path=str(Path(p).relative_to(BASE)))
result={'schema':'d015-final-independent-reader-mechanics-v1','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outcome':'PASS_MECHANICAL_INTEGRITY_WITH_EXPLICIT_AUTHENTICATION_AND_SEMANTIC_LIMITS','pins':pins,'counts':{'events':len(events),'successful_calls_and_stages':len(groups),'failed_launcher_calls':0,'text_outputs':30,'actual_subject_accesses':33,'baseline_chunks':11,'baseline_bytes':247840,'teaching_text_steps':19,'teaching_text_bytes':28990,'teaching_figures':3,'figure_bytes':157992,'total_frozen_teaching_files':6,'total_teaching_bytes':186982,'required_figure_receipts':3,'checkpoints':len(snapshots),'actual_revisits':0},'event_counts':dict(collections.Counter(e['event'] for e in events)),'ledger':{'path':str(R/'runtime/ledger.jsonl'),'bytes':len(raw),'sha256':sha(raw),'first_at':events[0]['at'],'last_at':events[-1]['at'],'final_chain_tail':events[-1]['sha256'],'full_hash_chain_valid':True},'calls':call_records,'figures':figure_records,'coverage':coverage,'checkpoints':checkpoint_records,'original_final_seal':{'path':str(BASE/'evidence/reader-original-seal.json'),'bytes':len(loadbytes(BASE/'evidence/reader-original-seal.json')),'sha256':sha(loadbytes(BASE/'evidence/reader-original-seal.json')),'record':seal},'post_reading_edit_disclosure':{'record_path':str(R/'reconstruction.md'),'original_record_sha256':pins['reader/reconstruction.md'],'verbatim_operational_disclosure':disclosures[0],'classification':'Reader-disclosed post-reading apply_patch editing failure affecting only reader-authored reconstruction; no launcher failure or invented raw-result object. The failed patch tool transcript itself is not retained as a structured original object; the disclosure is a transcription.','independently_proved':'Final original report/reconstruction identities, unchanged frozen subjects and current raw ledger/output integrity; this audit does not independently authenticate the absent failed-patch invocation.'},'helper_code_review':{'checkpoint.py':'Reads only ledger and prior checkpoint, stops and preserves mismatch, writes numbered snapshot and latest metadata; no subject retrieval or ledger rewrite. All 37 actual saved prefixes independently verified.','make-receipt.py':'Fixed F01/F02/F03 only; reads static route and retained original result/capture; strict original-detail wrapper; decodes URL and checks frozen figure SHA; derives metadata; refuses existing receipt. Does not invoke view_image, prove display, or authenticate result provenance.'},'chronology_note':'Independent current-route admission was post-dispatch and is not mislabeled pre-dispatch. This final audit occurred after the original final report/record seal.','limitations':['A retained locally generated ledger, checkpoint and returned-result object are not a cryptographically authenticated platform transcript. Local view correlation IDs are explicitly distinct from provider IDs; retained exec chunk IDs are recorded as supplied in returned wrappers.','Exact access, output and decoded-image integrity do not prove semantic comprehension, absence of pretraining, cold-reader isolation, actual visual attention, or scientific correctness.','No additional browser/view_image/launcher/fixture invocation was performed. No original input, report, reconstruction, runtime or receipt was altered.','All retained current-run checkpoints are exact monotone prefixes; no current-run shortening was found. The separate initial preflight anomaly remains unresolved and preserved, and is not erased by this result.','Absence of an event outside retained ledger/wrappers cannot establish absence of all possible external accesses; the claimed instruction-confinement route and retained operational evidence are the audited scope.'],'reader_inventory':reader_inventory,'checks':checks,'checks_count':len(checks),'all_checks_pass':True}
OUT.mkdir(parents=True,exist_ok=True);(OUT/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
manifest={'files':[{'path':str(Path(p).relative_to(BASE)),'bytes':len(b),'sha256':sha(b)} for p,b in sorted(loaded.items())],'scope':'All exact actual inputs read by independent final audit; includes opaque reader file identity inventory, without semantic review.'}
(OUT/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'verified-ids.json').write_text(json.dumps({'calls':call_records,'figures':figure_records,'id_provenance':'Launcher call UUIDs and reader-provided local view correlation IDs are not provider-authenticated identities. Exec chunk IDs are retained returned-wrapper values.'},indent=2)+'\n')
print(json.dumps({'outcome':result['outcome'],'counts':result['counts'],'checks':len(checks),'verification_sha256':sha((OUT/'verification.json').read_bytes()),'ledger':result['ledger'],'input_files':len(loaded)},indent=2))
