D015 subject-free mechanism preflight: satisfied, with the preserved initial ledger anomaly and stated limits. Actual D015 route/reader admission remains pending.

Verified the pinned results and408-file evidence manifest against every actual member; the411-file tree adds only the manifest itself and two excluded Python caches. All deployed launcher copies match SHA256 d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd. Reviewed all five operational Python files (315 lines) and the integration note; no fixture tests or image views were repeated.

The49 passing named checks contain361 assertions and cover16 successful/33 rejected invocations. Raw stdout/stderr, per-call events, CPython open observations, source byte slices, read hashes, state/cursor behavior and receipt bindings were independently checked. A50th preserved result is the failed initial completion attempt: expected reason/cursor/operation did not match because the shortened ledger caused an earlier scheduled-step rejection. It returned no content and opened/read no fixture.

Fresh receipt-flow: all123 event hashes/links and16 calls verify;10 calls succeed and6 reject, with complete initial route, cursor-preserving revisits and one accepted actual-view receipt. The66-event pre-view snapshot and six per-call full-ledger snapshots are exact prefixes of the final ledger. Both original image-result objects decode exactly to their211-byte synthetic PNG; the fresh derived receipt is byte-identical to the ledger-bound receipt. All timestamps follow dispatch → view → receipt → resumed output. Local capture identifiers are not provider-issued IDs.

Initial anomaly: the saved96-event per-call branch is a valid chain. The observed18-event runtime branch contains the first16 original events plus a new two-event rejection; the prior80-event tail is absent. Both branches and the failed invocation remain intact. No cause is established. Audited launcher source uses append mode, captured writer-open flags contain O_APPEND and no O_TRUNC, and the setup code has no runtime-ledger restoration/truncation operation. These observations cannot rule out events outside the captured Python process. A locally valid hash-chain prefix cannot itself prove retention of an earlier tail; retain external expected snapshots/tails as the existing integration note specifies. Fresh-flow success neither repairs the old evidence nor proves a cause. No fabrication or launcher-defect inference is made.

Remaining actual D015 work:

- Audit the separately supplied actual whole-frozen route, launcher/helper bytes and seals before real-reader dispatch; bind all frozen complete-file and slice hashes and immutable revision IDs.
- Verify full actual baseline-before-teaching coverage, exact byte ranges and declared figure-first-use timing; source semantic placement remains the relevant reviewer's responsibility.
- Use a fresh runtime and preserve external exact ledger snapshots/tail identities at operational checkpoints, as INTEGRATION.md already specifies. Stop on a mismatch rather than restoring/reconstructing the live ledger.
- After the actual reader completes, compare every call/output hash/state transition and complete coverage; correlate each original actual image return and derived receipt with correct invocation/timing/unique local ID provenance.
- Seal and compare original final reader reports and any disclosed later metadata operations. Actual reader admission, destination geometry and scientific/learning judgments remain separate.

Limits:

- Only the authorized subject-free preflight tree and unchanged supplied launcher were read. No current teaching/source/prompts/findings or later author artifacts inspected.
- 49 passing named checks contain361 saved assertions;50 invocation-result records exist, including the explicitly preserved failed first completion attempt. No failed attempt is erased or relabeled successful.
- Observer evidence consists of CPython audit open events, not kernel syscall coverage. strace was unavailable; no technical confinement or total-environment access claim.
- Retained actual tool objects, capture metadata and derived receipt bind exact synthetic image bytes and timing. Capture IDs are explicitly orchestrator-generated, not provider-issued. This is not a cryptographically authenticated platform transcript or proof of semantic inspection.
- The initial shortened ledger remains unexplained and unrepaired. Fresh123-event flow and exact prefix snapshots support the current successful mechanism check without repairing or identifying the cause of the prior branch.
- No fixture/helper/launcher replay, browser or view_image call was made in this audit.

Fresh ledger SHA256: e12bebc3911dd3a093d370039e0d794801cc3aa683cd7ca078679e19b8ac2805
Full identities, per-call records and anomaly witnesses: verification.json.
