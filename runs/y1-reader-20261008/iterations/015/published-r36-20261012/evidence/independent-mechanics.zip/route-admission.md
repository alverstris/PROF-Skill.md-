# D015 r36 independent current-route admission

Outcome: satisfied for the pinned current route’s operational admission. All 447 mechanical checks passed. This is not a teaching-semantic, source-science, or final SASIS acceptance verdict.

Chronology: the parent reported that the author had already dispatched the fresh reader after the author’s validation while this independent audit was pending. This is explicitly post-dispatch independent admission, not independent pre-dispatch clearance. The active runtime, live reader outputs and reader report were not opened.

| Verified scope | Result |
|---|---|
| Frozen teaching files | All 6 actual files; 186,982 bytes; SHA256 and Git blob identities match whole freeze |
| Full baseline | 247,840 bytes; 11 ordered, contiguous, nonoverlapping exact-hash UTF-8 slices |
| Teaching text | 28,990 bytes; 19 ordered, contiguous, nonoverlapping exact-hash UTF-8 slices |
| Figures | 3 complete PNGs; 157,992 bytes; exact frozen and route digests |
| Required route | 33 retrieval steps plus 3 figure receipt steps = 36 successful stages |
| Optional revisits | 11 declared unique bounded baseline revisits, one per initial baseline slice |
| Launcher | Exact provided/preflighted 25,227 bytes, unchanged SHA256 d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd |

All baseline retrieval precedes teaching. The seven route files are exactly the full baseline and frozen six, with no extra subject paths. All 30 text slice digests were recomputed from actual source bytes; all boundaries decode as UTF-8. This audit emitted no subject prose or image content.

| Figure | First-use text slice | Source image markup byte range | Required receipt |
|---|---|---|---|
| F01 | M01 | 4922–5101 (half-open) | F01R |
| F02 | M04 | 9944–10164 (half-open) | F02R |
| F03 | M06 | 13963–14208 (half-open) | F03R |

Each figure’s first and only literal HTML image reference lies fully within its declared first-use text slice; its figure dispatch immediately follows that slice. This establishes mechanical markup placement, not a semantic judgment about the teaching’s first conceptual use. Receipt destinations are fixed, unique JSON files under reader/view-results. These destinations were checked as route strings only; their current contents were not read.

The unchanged launcher requires tools.view_image with detail=original, the exact figure path/hash, a unique call identity, and a completion timestamp after dispatch. Its cursor remains on the figure until its receipt step succeeds; later teaching cannot advance. Already-read baseline revisits are explicitly allowed while a figure is pending. The launcher reports semantic_inspection_proven=false. Its receipt validation is not a cryptographically authenticated platform transcript.

After completion, the actual-run audit still must verify the entire chronological hash chain and independently retained ledger tails/snapshots; each text read/output against the exact routed bytes; actual figure dispatch/result/receipt ordering; retained original view result objects and data URLs decoded to all three frozen PNGs; receipt URL lengths/digests and call-ID provenance; and the final report/access record identities and permitted scope. These are pending evidence obligations, not current failures.

The earlier subject-free preflight gate and its report remain unchanged. The initial synthetic ledger-shortening anomaly remains preserved with cause unresolved; a locally valid hash chain cannot by itself detect loss of an earlier valid suffix. No fixture or launcher was rerun for this route audit.

Pinned input identities:

| Input | SHA256 |
|---|---|
| author/whole-freeze.json | 0f52edf74fe3bf9794a061880c201e423fbc37faa71416828c6c2bf682c2f3bb |
| reader/route.json | 862bf62a76c06706588c45f84597e16c84a93a5c8234fca5599723485d70c4d6 |
| reader/route-seal.json | a3a27e00875e6b340da393b9f94dbbb0a1f6ceff904a2c1b96b6f95ad2d804b5 |
| reader/read-step | d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd |
| inputs/operational-tools/read-step | d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd |

Evidence: route-admission.json contains every independent check, file identity, ordered slice, first-use markup offset and expanded required stage. audit_route.py contains the independent read-only checker. The separate route-admission-output-manifest.json binds this report, JSON and checker; it does not replace the earlier preflight output manifest.
