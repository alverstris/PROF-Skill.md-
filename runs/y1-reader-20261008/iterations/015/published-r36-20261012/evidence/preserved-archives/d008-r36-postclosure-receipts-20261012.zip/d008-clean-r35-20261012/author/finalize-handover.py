from pathlib import Path
import json,hashlib,shutil,datetime
w=Path(__file__).resolve().parents[1];n=w.parent/'d015-clean-r36-20261012';H=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((w/'evidence/closure-publication-readback.json').read_text());assert r['all_bytes_match'];pin=r['pin'];tree=r['tree'];remote=Path(r['actual_readback_directory']);pmanifest=json.loads((w/'evidence/outgoing-package-manifest.json').read_text());old=json.loads((w/'audit-inputs/queue.json').read_text());q=json.loads((remote/'runs/y1-reader-20261008/queue.json').read_text())
assert len(q['sessions'])==147 and sum(s['readability']['eligible'] for s in q['sessions'])==76 and sum(s['status']=='closed' for s in q['sessions'])==15
assert all(a==b for i,(a,b) in enumerate(zip(old['sessions'],q['sessions'])) if i!=7)
assert [(s['id'],s['order'],s['material_id'],s['readability']) for s in q['sessions']]==[(s['id'],s['order'],s['material_id'],s['readability']) for s in old['sessions']]
assert q['active_material_id']=='D015';pending=[s['material_id'] for s in q['sessions'] if s['readability']['eligible'] and s['status']!='closed'];assert pending[:2]==['D015','D016'] and len(pending)==61
for name in ['RUN.md','CHANGELOG.md']:assert (remote/'runs/y1-reader-20261008'/name).read_bytes().endswith((w/'audit-inputs'/name).read_bytes())
for f in pmanifest['files']:
 b=(remote/f['path']).read_bytes();assert len(b)==f['bytes'] and H(b)==f['sha256'];p=n/'inputs/prof'/f['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
pm={'repository':'alverstris/PROF-Skill.md-','branch':'main','commit':pin,'tree':tree,'version':'2026-10-12-r36','count':36,'bytes':907146,'files':pmanifest['files']};(n/'inputs/prof-package-manifest.json').write_text(json.dumps(pm,indent=2)+'\n')
template=json.loads((n/'author-queue-template.json').read_text());keys=set(template['sessions'][0])-{'eligible'};filtered={'counts':{'total_original_records':147,'eligible':76,'excluded':71,'accepted':15,'remaining':61},'active_material_id':'D015','sessions':[{**{k:s[k] for k in keys if k in s},'eligible':s['readability']['eligible']} for s in q['sessions']]}
# Match the original operational whitelist across every row; no original review fields pass through.
allowed=set().union(*(set(s) for s in template['sessions']))-{'eligible'}
filtered['sessions']=[{**{k:s[k] for k in allowed if k in s},'eligible':s['readability']['eligible']} for s in q['sessions']]
assert [(s['id'],s['material_id'],s['order'],s['status'],s['eligible']) for s in filtered['sessions']]==[(s['id'],s['material_id'],s['order'],s['status'],s['readability']['eligible']) for s in q['sessions']]
(n/'inputs/operational-queue.json').write_text(json.dumps(filtered,indent=2)+'\n')
h=json.loads((n/'author-handover-template.json').read_text());root=pm['files'][0];assert root['path']=='SKILL.md'
h.update(verified_current_main=pin,verified_tree=tree,operative_prof_version='2026-10-12-r36',complete_package_files=36,complete_package_bytes=907146,root_skill=root,publication_ownership='Sole GitHub publication ownership transfers to the fresh D015 coordinator on explicit root dispatch after final independent verification. The predecessor then stops all mutations. Root remains read-only for GitHub and sole actual browser QA owner.',remaining_access_limits='No prior publication gate remains. Independently admit the current published complete package and all internal declarations. Root holds all prior and D015 prepared audits until whole new teaching freeze.',final_package_path_hash_manifest='inputs/prof-package-manifest.json',final_closure_readback_identity={'pin':pin,'paths':r['paths'],'bytes':r['total_bytes'],'sha256':H((w/'evidence/closure-publication-readback.json').read_bytes()),'scope':'Operational identity only; predecessor receipt is not an allowed pre-freeze semantic input.'},counts_status='Verified actual canonical queue at supplied final pin;15accepted61remaining76eligible71excluded147total.',publication_owner='Fresh D015 coordinator only after explicit root ownership transfer.',evidence_prefix_status='Canonical destination for this active material; all package bytes verified at final pin.')
h['allowed_before_freeze'][0]='This operational handover, filtered operational queue and byte/hash identity manifests only.'
h['workflow'][0]='Independently fetch minimal current git/ref; use only the explicit final whitelisted package paths and compare full bytes/size/SHA256/Gitblob. Verify every declared internal bundled hash. Then read full SKILL.md and all required references.'
h['workflow'][-1]='After clean closure or verified-failure repair, publish/readback first; coordinate with root to spawn the next fresh author/coordinator fork:none with only operational/original inputs, then explicitly transfer sole GitHub publication ownership. Predecessor stops all mutations. Notify root exact identity/pin/counts and finish while successor continues. Continue the entire76-session corpus; do not stop after one lecture.'
for k in ['template_state','finalization_requirement','candidate_prof_version','candidate_release_directory','operational_queue_template']:h.pop(k,None)
assert 'PENDING_FINAL_PIN' not in json.dumps(h) and 'PENDING_EXPLICIT_TRANSFER' not in json.dumps(h)
(n/'inputs/operational-handover.json').write_text(json.dumps(h,indent=2)+'\n')
files=[]
for p in sorted((n/'inputs').rglob('*')):
 if p.is_file():
  b=p.read_bytes();files.append({'path':str(p.relative_to(n)),'bytes':len(b),'sha256':H(b)})
assert len(files)==54,len(files);identities={'verified_package_commit':pin,'files':files,'count':len(files),'bytes':sum(x['bytes'] for x in files),'scope':'Only original D015 inputs, full baseline, current package, filtered operational queue/handover and subject-free launcher. No old teaching or audit findings.'};(n/'input-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
for f in files:assert H((n/f['path']).read_bytes())==f['sha256']
receipt={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pin':pin,'tree':tree,'actual_readback':str(w/'evidence/closure-publication-readback.json'),'all147_identity_order_eligibility_unchanged':True,'all146_other_session_objects_unchanged':True,'accepted':15,'remaining':61,'excluded':71,'eligible':76,'active':'D015','next':'D016','package_files':36,'internal_declarations':34,'next_workspace':str(n),'clean_input_count':len(files),'input_identities_sha256':H((n/'input-identities.json').read_bytes()),'handover_sha256':H((n/'inputs/operational-handover.json').read_bytes()),'package_manifest_sha256':H((n/'inputs/prof-package-manifest.json').read_bytes()),'only_ownership_transfer_remains':True}
(w/'evidence/final-canonical-and-clean-handover-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
# Retain preparation templates with predecessor operational evidence, outside clean author workspace.
for name in ['author-handover-template.json','author-queue-template.json','handover-template-mechanical-check.json']:
 p=n/name;dest=w/'publication'/('d015-'+name);shutil.move(str(p),str(dest))
