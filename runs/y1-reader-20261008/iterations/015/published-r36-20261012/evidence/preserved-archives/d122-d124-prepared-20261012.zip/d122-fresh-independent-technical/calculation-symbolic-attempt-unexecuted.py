"""Independent D122 calculations; inputs are constants in allowed source/baseline.
No external data. Symbolic identities use mu*eps*c**2=1. Numerical examples
retain the source's rounded c, eps and mu and disclose that approximation.
"""
import json
import math
from pathlib import Path
import sympy as s

OUT = Path(__file__).resolve().parent
x,t,k,c,mu,E0,A,C,phi = s.symbols('x t k c mu E0 A C phi', real=True, nonzero=True)
w=k*c
eps=1/(mu*c*c)
theta=k*x-w*t
Ey=E0*s.cos(theta)
Bz=Ey/c
checks={}
def zero(label, expression):
    result=s.simplify(s.expand_trig(expression))
    assert result == 0, (label,result)
    checks[label]=str(result)
zero('travelling_Faraday',s.diff(Ey,x)+s.diff(Bz,t))
zero('travelling_Ampere_Maxwell',s.diff(Bz,x)+mu*eps*s.diff(Ey,t))
zero('travelling_wave_equation',s.diff(Ey,x,2)-s.diff(Ey,t,2)/c**2)
zero('travelling_equal_energy_densities',eps*Ey**2/2-Bz**2/(2*mu))
Es=2*E0*s.sin(k*x)*s.sin(w*t)
Bs=2*E0/c*s.cos(k*x)*s.cos(w*t)
Ss=Es*Bs/mu
us=eps*Es**2/2+Bs**2/(2*mu)
zero('standing_Faraday',s.diff(Es,x)+s.diff(Bs,t))
zero('standing_Ampere_Maxwell',s.diff(Bs,x)+mu*eps*s.diff(Es,t))
zero('standing_energy_conservation',s.diff(us,t)+s.diff(Ss,x))
zero('standing_flux_double_angle',Ss-E0**2/(mu*c)*s.sin(2*k*x)*s.sin(2*w*t))
u=s.symbols('u',real=True)
mean=lambda q:s.simplify(s.integrate(s.expand_trig(q),(u,0,2*s.pi))/(2*s.pi))
assert mean(s.cos(u)**2)==s.Rational(1,2)
assert mean(s.sin(2*u))==0
checks['cos_squared_mean']='1/2'
checks['standing_signed_flux_mean']='0'
co=(A*s.cos(u)+C*s.cos(u+phi))**2/(mu*c)
co_mean=(A*A+C*C+2*A*C*s.cos(phi))/(2*mu*c)
zero('copropagating_interference_mean',mean(co)-co_mean)
counter=(A*A*s.cos(u)**2-C*C*s.cos(u+phi)**2)/(mu*c)
zero('counterpropagating_net_mean',mean(counter)-(A*A-C*C)/(2*mu*c))
Q,I,h,R,r,a,l,sigma,n = s.symbols('Q I h R r a l sigma n',positive=True)
Ecap=Q/(eps*s.pi*R**2)
Bcap=mu*I*r/(2*s.pi*R**2)
Scap=-Ecap*Bcap/mu
Ucap=Q**2*h/(2*eps*s.pi*R**2)
Pin_cap=-Scap.subs(r,R)*2*s.pi*R*h
zero('capacitor_inward_power_equals_storage',Pin_cap-s.diff(Ucap,Q)*I)
zero('capacitor_outward_flux_plus_storage',Scap.subs(r,R)*2*s.pi*R*h+s.diff(Ucap,Q)*I)
Ewire=I/(sigma*s.pi*a**2)
Bwire=mu*I/(2*s.pi*a)
Pin_wire=Ewire*Bwire/mu*2*s.pi*a*l
zero('resistor_power',Pin_wire-I**2*l/(sigma*s.pi*a**2))
Ip=s.symbols('Ip',real=True)
Ssol=-mu*n*n*r*I*Ip/2
Usol=mu*n*n*I*I*s.pi*r*r*l/2
zero('solenoid_inward_power_equals_storage',-Ssol*2*s.pi*r*l-s.diff(Usol,I)*Ip)
b=s.symbols('b',positive=True)
Ecoax=-Q/(2*s.pi*eps*l*r)
Bcoax=-mu*I/(2*s.pi*r)
Scoax=Ecoax*Bcoax/mu
Pcoax=s.integrate(Scoax*2*s.pi*r,(r,a,b))
Vcoax=Q*s.log(b/a)/(2*s.pi*eps*l)
zero('coax_power_equals_VI',Pcoax-Vcoax*I)
rho,D=s.symbols('rho D',positive=True)
K=D*E0/(rho+D*c*mu/2)
Et=E0-c*mu*K/2
zero('finite_sheet_self_consistency',K-D*Et/rho)
zero('perfect_sheet_current_limit',s.limit(K,rho,0,dir='+')-2*E0/(c*mu))
zero('perfect_sheet_field_limit',s.limit(Et,rho,0,dir='+'))
instant_pressure=2*E0**2*s.cos(u)**2/(mu*c*c)
zero('mirror_mean_pressure',mean(instant_pressure)-E0**2/(mu*c*c))
zero('polarization_vector_norm_factor',s.Matrix([E0,E0,0]).dot(s.Matrix([E0,E0,0]))-2*E0**2)

c_num=3.0e8
eps_num=8.85e-12
mu_num=4*math.pi*1e-7
G=6.67e-11
solar_I=1350.0
solar_R=1.50e11
solar_P=4*math.pi*solar_R**2*solar_I
solar_E=math.sqrt(2*solar_I/(eps_num*c_num))
bulb_I=100/(4*math.pi)
bulb_E=math.sqrt(2*bulb_I/(eps_num*c_num))
numbers={
 'constants':{'c_rounded_m_s':c_num,'epsilon0_F_m':eps_num,'mu0_H_m':mu_num,'G_SI':G},
 'c_from_mu_epsilon_m_s':1/math.sqrt(mu_num*eps_num),
 'source_equation_13_4_15_printed_c_m_s':2.997e8,
 'solar_example':{'E_peak_V_m':solar_E,'B_peak_T':solar_E/c_num,'power_W':solar_P},
 'solar_sail':{'mass_kg':1650,'area_per_solar_mass_m2_kg':2*math.pi*c_num*G*1650/solar_P,'numeric_solar_mass':'Not supplied in allowed inputs; retain M_sun symbol.'},
 'bulb_example':{'intensity_W_m2':bulb_I,'E_peak_V_m':bulb_E,'B_peak_T':bulb_E/c_num,'K_peak_A_m':2*bulb_E/(mu_num*c_num)},
 'solar_pressure':{'absorption_Pa':solar_I/c_num,'reflection_Pa':2*solar_I/c_num,'energy_density_J_m3':solar_I/c_num},
 'rms_problem':{'E_rms_V_m':0.03,'area_m2':1e-4,'time_s':3600,'intensity_W_m2':eps_num*c_num*0.03**2,'energy_J':eps_num*c_num*0.03**2*1e-4*3600},
 'ferrite_problem':{'wavelength_m':3,'frequency_Hz':1e6,'phase_speed_m_s':3e6,'B_peak_T':300/3e6,'B_direction':'-y for E phase coefficient +z and propagation +x','vacuum_wavelength_m':c_num/1e6,'relative_medium_speed_check':c_num/math.sqrt(1000*10)},
 'prs_wavenumber_per_m':2*math.pi/4,
}
result={'symbolic_checks':checks,'symbolic_check_count':len(checks),'numerical_results':numbers,'convention':'c=3e8, epsilon0=8.85e-12 and mu0=4*pi*1e-7 are rounded source data; minor equivalent-form numerical differences are rounding, not new physics.'}
(OUT/'calculation-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'symbolic_check_count':len(checks),'all_zero_checks_passed':True,'numeric_cases':len(numbers)}))
