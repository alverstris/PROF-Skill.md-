"""D122 independent numerical verification, using only Python's standard library.
Analytic derivations are in calculations.md. No outside data are imported.
The CAS attempt is preserved separately and is explicitly unexecuted.
"""
import json
import math
from pathlib import Path

out=Path(__file__).resolve().parent
checks=[]
def equal(name,actual,expected,tol=1e-9):
    error=abs(actual-expected)/max(1,abs(actual),abs(expected))
    assert error<tol,(name,actual,expected,error)
    checks.append({'name':name,'actual':actual,'expected':expected,'scaled_error':error,'tolerance':tol})
def mean(fun,N=256):
    return sum(fun(2*math.pi*i/N) for i in range(N))/N
def d(fun,x,t,axis,step=1e-5):
    return ((fun(x+step,t)-fun(x-step,t)) if axis=='x' else (fun(x,t+step)-fun(x,t-step)))/(2*step)
def d2(fun,x,t,axis,step=1e-4):
    return ((fun(x+step,t)+fun(x-step,t)) if axis=='x' else (fun(x,t+step)+fun(x,t-step)))-2*fun(x,t)

# Dimensionless sample values test the analytic identities; they are not
# additional physical constants. Relations mu*eps*c**2=1 and omega=k*c hold.
c,mu,k,E0=2.0,3.0,1.7,2.3
eps=1/(mu*c*c)
w=k*c
E=lambda x,t:E0*math.cos(k*x-w*t)
B=lambda x,t:E(x,t)/c
Es=lambda x,t:2*E0*math.sin(k*x)*math.sin(w*t)
Bs=lambda x,t:2*E0/c*math.cos(k*x)*math.cos(w*t)
S=lambda x,t:Es(x,t)*Bs(x,t)/mu
U=lambda x,t:eps*Es(x,t)**2/2+Bs(x,t)**2/(2*mu)
for j,(xx,tt) in enumerate(((.13,.24),(.61,.37),(1.31,.11))):
    equal(f'travelling Faraday {j}',d(E,xx,tt,'x'),-d(B,xx,tt,'t'),1e-8)
    equal(f'travelling Ampere-Maxwell {j}',d(B,xx,tt,'x'),-mu*eps*d(E,xx,tt,'t'),1e-8)
    equal(f'travelling PDE {j}',d2(E,xx,tt,'x')/1e-8,d2(E,xx,tt,'t')/(1e-8*c*c),1e-6)
    equal(f'standing Faraday {j}',d(Es,xx,tt,'x'),-d(Bs,xx,tt,'t'),1e-8)
    equal(f'standing energy balance {j}',d(U,xx,tt,'t'),-d(S,xx,tt,'x'),1e-8)
equal('cycle mean cos squared',mean(lambda u:math.cos(u)**2),.5)
equal('standing signed flux cycle mean',mean(lambda u:math.sin(2*u)),0)
for phase in (0,.7,math.pi):
    A,C=2.4,1.1
    equal(f'co-propagating mean phase {phase}',mean(lambda u:(A*math.cos(u)+C*math.cos(u+phase))**2/(mu*c)),(A*A+C*C+2*A*C*math.cos(phase))/(2*mu*c))
    equal(f'counter-propagating mean phase {phase}',mean(lambda u:(A*A*math.cos(u)**2-C*C*math.cos(u+phase)**2)/(mu*c)),(A*A-C*C)/(2*mu*c))
equal('mirror pressure mean has half peak',mean(lambda u:2*E0**2*math.cos(u)**2/(mu*c*c)),E0**2/(mu*c*c))

Q,I,h,R,r,a,l,sigma,n,Ip=2.2,.6,.3,1.8,.7,.4,3.1,2.7,4.2,.8
Ecap=Q/(eps*math.pi*R**2)
Bcap_edge=mu*I/(2*math.pi*R)
Sout_cap=-Ecap*Bcap_edge/mu
equal('capacitor inward power and dU/dt',-Sout_cap*2*math.pi*R*h,Q*I*h/(eps*math.pi*R**2))
equal('resistor inward power and I squared R',I/(sigma*math.pi*a*a)*mu*I/(2*math.pi*a)/mu*2*math.pi*a*l,I*I*l/(sigma*math.pi*a*a))
Ssol=-mu*n*n*r*I*Ip/2
equal('solenoid inward power and dU/dt',-Ssol*2*math.pi*r*l,mu*n*n*math.pi*r*r*l*I*Ip)
b=1.2
# Midpoint integration of annular S*dA independently checks logarithm.
N=100000
dr=(b-a)/N
P_num=sum((Q*I/(4*math.pi**2*eps*l*(a+(i+.5)*dr)**2))*2*math.pi*(a+(i+.5)*dr)*dr for i in range(N))
equal('coax annular power integral and VI',P_num,Q*math.log(b/a)/(2*math.pi*eps*l)*I,1e-9)
rho,D=.4,.07
K=D*E0/(rho+D*c*mu/2)
Et=E0-c*mu*K/2
equal('finite sheet total field Ohm law',K,D*Et/rho)
equal('perfect conductor current limit',D*E0/(1e-12+D*c*mu/2),2*E0/(c*mu),1e-9)

c_num=3.0e8
eps_num=8.85e-12
mu_num=4*math.pi*1e-7
G=6.67e-11
solar_I=1350.0
solar_R=1.50e11
solar_P=4*math.pi*solar_R**2*solar_I
solar_E=math.sqrt(2*solar_I/(eps_num*c_num))
bulb_I=100/(4*math.pi)
bulb_E=math.sqrt(2*bulb_I/(eps_num*c_num))
numbers={
 'constants':{'c_rounded_m_s':c_num,'epsilon0_F_m':eps_num,'mu0_H_m':mu_num,'G_SI':G},
 'c_from_mu_epsilon_m_s':1/math.sqrt(mu_num*eps_num),
 'source_equation_13_4_15_printed_c_m_s':2.997e8,
 'solar_example':{'E_peak_V_m':solar_E,'B_peak_T':solar_E/c_num,'power_W':solar_P},
 'solar_sail':{'mass_kg':1650,'area_per_solar_mass_m2_kg':2*math.pi*c_num*G*1650/solar_P,'numeric_solar_mass':'Not supplied in allowed inputs; retain M_sun symbol.'},
 'bulb_example':{'intensity_W_m2':bulb_I,'E_peak_V_m':bulb_E,'B_peak_T':bulb_E/c_num,'K_peak_A_m':2*bulb_E/(mu_num*c_num)},
 'solar_pressure':{'absorption_Pa':solar_I/c_num,'reflection_Pa':2*solar_I/c_num,'energy_density_J_m3':solar_I/c_num},
 'rms_problem':{'E_rms_V_m':0.03,'area_m2':1e-4,'time_s':3600,'intensity_W_m2':eps_num*c_num*0.03**2,'energy_J':eps_num*c_num*0.03**2*1e-4*3600},
 'ferrite_problem':{'wavelength_m':3,'frequency_Hz':1e6,'phase_speed_m_s':3e6,'B_peak_T':300/3e6,'B_direction':'-y for E phase coefficient +z and propagation +x','vacuum_wavelength_m':c_num/1e6,'relative_medium_speed_check':c_num/math.sqrt(1000*10)},
 'prs_wavenumber_per_m':2*math.pi/4,
}
result={'numerical_identity_checks':checks,'check_count':len(checks),'numerical_results':numbers,'method':'Analytic derivations separately recorded; checks use central differences and quadrature, not symbolic CAS.','convention':'c=3e8, epsilon0=8.85e-12 and mu0=4*pi*1e-7 are rounded source data; equivalent-form numerical differences below 0.1 percent are rounding.'}
(out/'calculation-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'check_count':len(checks),'all_checks_passed':True,'numerical_cases':len(numbers)}))
