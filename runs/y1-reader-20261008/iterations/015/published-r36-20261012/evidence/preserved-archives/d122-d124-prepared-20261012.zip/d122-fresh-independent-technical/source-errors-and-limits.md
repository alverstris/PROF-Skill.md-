# Private source verification and access limits

Every location below was checked against the original-resolution PNG as well as its TXT. PDF page numbers are used. Findings are withheld from the parent until the parent expressly releases the semantic hold after the future fresh whole teaching freeze.

| Location | Verified observation | Independent resolution and significance |
|---|---|---|
| PRS9-10 | The increasing-charge choice is numbered5 on the question, but its answer page says Answer1. | Geometry, Ampere-Maxwell and inward S imply increasing charge. Choice5 in the actual displayed list is physically correct; the answer number is inconsistent. |
| PRS10 and12 | Poynting expression is abbreviated as S=(E cross B), omitting1/mu0. | Direction reasoning remains correct because mu0 is positive. The dimensional equality needs S=(E cross B)/mu0, as explicitly supplied elsewhere in original sources. |
| Reading45 equation13.12.19 | Closed-surface integral S dot dA is equated to positive capacitor charging power despite inward S and the earlier outward-normal convention. | Outward flux is negative. Pin=-closed integral=QIh/(epsilon0 pi R²)=dUE/dt. A minus sign is required unless a different inward normal is explicitly chosen. |
| Reading46 equation13.12.24 | The same sign inconsistency occurs for inward resistor power. | Pin=-closed outward flux=I²R. The source's positive magnitude is right; its signed integral is not consistent with Reading20. Fields are steady, so the energy is dissipated in matter rather than accumulating as field energy. |
| Reading37 equations13.10.5-.6 | E0 and B0 are previously amplitude constants; the force expression omits the time factors. | Literal amplitude product gives peak pressure. Instantaneous force/area has cos²(omega t); cycle mean is half the peak and equals2I/c. The identity2S/c is valid if S is instantaneous, but switching amplitude and instantaneous notation obscures the distinction. This is recorded as a time-dependence/notation problem, not an assertion that the correctly stated mean2I/c elsewhere is wrong. |
| Reading35 momentum summary | Reflection is listed beneath text calling DeltaU energy absorbed. | For perfect reflection DeltaU in2DeltaU/c must mean incident energy; energy absorbed can be zero despite nonzero momentum transfer. Reading22's context supplies the intended incident-energy interpretation. |
| Reading26 vs24 | 'Quarter-wave antenna' has wavelength twice its tip-to-tip length, while Reading24 names a two-rod total half-wavelength antenna with each rod lambda/4. | The supplied text mixes antenna naming conventions. Retain the explicit dimensional description; do not infer an external antenna configuration absent from the images. No external research used. |
| Reading10 equation13.4.15 | Direct evaluation of stated mu0=4pi e-7 and epsilon0=8.85e-12 gives2.99863380466e8 m/s; printed value is2.997e8. | Small numerical discrepancy, about0.0545 percent. It has no effect on the intended rounded3e8 calculation; record rather than exaggerate it. |
| Reading38 | The text under equation13.10.9 says it used that same equation in the last substitution. | The substitution actually uses13.10.8, K=D Etotal/rho. Minor cross-reference error. |
| Reading32 | Figure caption is13.9.4 but the prose calls it13.8.11. | Minor figure-number mismatch. The displayed sheet-field directions agree with the equations. |
| Reading51 | Exercise part labels skip from(e) to(g). | Cosmetic numbering gap; all supplied parts analyzed, with no invented missing(f). |

## Suspicions rejected after image inspection

* Reading14 equations13.5.9-.10 are correct: final expression is (n/2+1/4)lambda. TXT layout made it look potentially like (n+1/2)lambda/4, but the PNG resolves it. There is **no standing-node factor error** in those equations.
* Reading33 says magnetic-field jump magnitude mu0|K|, with absolute-value bars. It does not claim vector equality to mu0 K; there is **no demonstrated vector-direction error** there.
* The two standing-field pairs on Reading13-15 and19 differ in spatial/time phase convention. Each satisfies Maxwell and has zero mean signed flux; their different trigonometric forms are not inconsistent.
* The ferrite problem's E/B ratio is not c in vacuum. Its given phase implies v=3e6 and B=E/v. The supplied medium constants are compatible with that speed; no source contradiction is established by the differing velocity.

## Operational and mathematical limits

The entire actual page scope is available and fully inspected. Linked animations remain external; their screenshots and surrounding text are read, but the animations themselves were not viewed. Presentation13 is a still placeholder, and presentation22/26 contain headings without their exercise statements. No missing exercise was fabricated or retrieved elsewhere.

The solar-sail problem lacks a numerical solar mass in the allowed inputs. Its exact area formula and distance cancellation are derived, with the numerical coefficient per kilogram of solar mass. The pulse question leaves signs of a,b unspecified and only stipulates total half-energy reflection/transmission. Its propagation direction is therefore sign dependent, and a detailed force-time history is not determined without more optical timing information. The conventional constant-plateau pressure is labeled with the needed assumption; eventual impulse is determined.

Idealizations carried explicitly: uniform parallel-plate E and negligible fringing; long solenoid; infinitely long/edge-free coax; uniform resistor current; vacuum exterior for travelling-wave and pressure formulas; normal incidence; isotropic source for bulb/sun inverse-square estimates; uniform thin conducting-sheet model; ignored atmospheric attenuation when the source requests a near-surface solar-energy estimate from the upper-atmosphere intensity.

The original PDFs were hashed, not separately claimed as semantically read through a PDF parser. Their required content was read in the complete original PNG and TXT derivatives named by the identity. No source or baseline file was modified. Tools could access the files; the only output limitations were explicitly recorded truncations, recovered for required semantic coverage. Two later broad ancillary baseline keyword searches also truncated; they add no credit and do not invalidate the previously complete bounded baseline read.

No external research was needed to complete the technical preparation within its limits. SymPy was unavailable in both Python runtimes tested. The failed symbolic attempt is preserved and uncredited; analytic derivations plus a successful standard-library numerical verifier provide the calculation record.
