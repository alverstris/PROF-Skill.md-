"""Mechanical verification only: hashes and already-observed read-log coverage.
This script cannot create semantic reading credit or replace image inspection.
"""
import hashlib
import json
from pathlib import Path
from collections import Counter

base=Path(__file__).resolve().parent.parent
dossier=Path(__file__).resolve().parent
source=base/'original-inputs/D122'
baseline=base/'d013-clean-r34-20261012/inputs/student-baseline.txt'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((dossier/'source-identity.json').read_text())
assert digest(dossier/'source-identity.json')==digest(source/'source-identity.json')
hashes=json.loads((dossier/'input-hashes.json').read_text())
for row in hashes:
    p=base/row['path']
    assert p.stat().st_size==row['bytes'],row['path']
    assert digest(p)==row['sha256'],row['path']
assert baseline.stat().st_size==247840
assert digest(baseline)=='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'

log=[json.loads(line) for line in (dossier/'read-log.jsonl').read_text().splitlines() if line.strip()]
txtlog={x['path']:x for x in log if x['kind']=='TXT'}
pnglog={x['path']:x for x in log if x['kind']=='PNG'}
expected_txt=set()
expected_png=set()
scope=[]
for asset in identity['assets']:
    assert digest(source/asset['local_pdf'])==asset['sha256']
    required=asset['required_pdf_pages']
    pages={x['page']:x for x in asset['page_derivatives']}
    assert set(required)==set(range(1,asset['page_count']+1))
    for page in required:
        row=pages[page]
        assert row['contains_assigned_portion'] is True
        for key,kind in [('text','TXT'),('image','PNG')]:
            p=source/row[key+'_file']
            assert digest(p)==row[key+'_sha256'],str(p)
            rel=str(p.relative_to(base))
            (expected_txt if kind=='TXT' else expected_png).add(rel)
            read=(txtlog if kind=='TXT' else pnglog)[rel]
            if kind=='TXT':
                assert read['chars_half_open']==[0,len(p.read_text())]
            else:
                assert read['detail']=='original'
                assert read['dimensions']==row['image_dimensions']
    scope.append({'role':asset['role'],'pages_required':len(required),'txt_read':len(required),'png_original_inspected':len(required),'pdf_sha256':asset['sha256']})
assert set(txtlog)==expected_txt and len(txtlog)==96
assert set(pnglog)==expected_png and len(pnglog)==96
assert len([x for x in log if x['kind']=='TXT'])==96
assert len([x for x in log if x['kind']=='PNG'])==96

def contiguous(ranges,start,stop,inclusive=False):
    at=start
    for low,high in sorted(ranges):
        assert low==at,(low,high,at)
        at=high+1 if inclusive else high
    assert at==(stop+1 if inclusive else stop),(at,stop)
metadata_ranges=[x['lines_inclusive'] for x in log if x['kind']=='metadata' and 'lines_inclusive' in x]
metadata_lines=len((source/'source-identity.json').read_text().splitlines())
contiguous(metadata_ranges,1,metadata_lines,True)
baseline_ranges=[x['chars_half_open'] for x in log if x['kind']=='baseline']
baseline_chars=len(baseline.read_text())
contiguous(baseline_ranges,0,baseline_chars)
calc=json.loads((dossier/'calculation-results.json').read_text())
report={'status':'PASS','input_files_rehashed':len(hashes),'source_identity_bytes':(source/'source-identity.json').stat().st_size,'source_identity_lines':metadata_lines,'source_identity_sha256':digest(source/'source-identity.json'),'baseline_bytes':baseline.stat().st_size,'baseline_normalized_characters':baseline_chars,'baseline_read_ranges':len(baseline_ranges),'baseline_sha256':digest(baseline),'txt_count':len(txtlog),'png_count':len(pnglog),'roles':scope,'numerical_checks_passed':calc['check_count'],'read_log_sha256':digest(dossier/'read-log.jsonl'),'uncredited_entries':sum('UNCREDITED' in x['kind'] or 'TRUNCATED' in x.get('result','') for x in log),'required_truncated_output_unrecovered':0,'source_mutations_detected':0,'mechanical_check_only':'The recorded actual tool reads/views supply semantic evidence; hashing alone does not.'}
(dossier/'coverage-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','input_files_rehashed','source_identity_lines','baseline_bytes','baseline_normalized_characters','txt_count','png_count','numerical_checks_passed','required_truncated_output_unrecovered','source_mutations_detected']}))
