# Independent D123 calculations — private

All derivations below use the assigned original source laws, the declared baseline, and explicit mathematical reasoning. No authored teaching or other-case answer was consulted. Reference labels Rpp are reading PDF/PNG pages; Ppp are presentation pages; Qpp are PRS pages. Cartesian vectors use a right-handed basis; cylindrical r,phi,z also form a right-handed triad. A surface integral without an explicitly reversed normal uses outward normals on a closed boundary.

## 1. Displacement current and Maxwell component derivation (R3–12, P12,19–27)

Parallel capacitor: Q=epsilon0 E A and I=dQ/dt imply epsilon0 d(EA)/dt=I. Thus adding Id=epsilon0 dPhiE/dt to Ampere's circulation makes the wire-spanning and gap-spanning surfaces give the same result. This is not physical conduction through the ideal insulating gap. Both J and epsilon0 partial_t E can coexist in a conducting region with time-varying E; an ohmic leaky gap gives the simple example J=sigma E and nonzero partial_t E.

In vacuum with no charge or conduction current, take E=Ey(x,t)yhat and B=Bz(x,t)zhat. A Faraday rectangle in xy, with positive normal z, has circulation [Ey(x+dx)−Ey(x)] l and flux approximately Bz l dx. The dx→0 limit gives Ey,x=−Bz,t. An Ampere rectangle in xz chosen with normal +y has circulation [Bz(x)−Bz(x+dx)]l; its electric flux is Ey l dx. Thus Bz,x=−mu0 epsilon0 Ey,t. Signs follow the same right-hand pairing of loop direction and normal, not independent arrow guesses.

Differentiate Ey,x=−Bz,t in x, commute continuous mixed derivatives, and substitute Bz,x: Ey,xx=−partial_t Bz,x=mu0 epsilon0 Ey,tt. Differentiating Bz,x in x and substituting Ey,x similarly gives Bz,xx=mu0 epsilon0 Bz,tt. Write c=1/sqrt(mu0 epsilon0). For f(x−vt), partial_xx f=f'' and partial_tt f=v² f'', so the nontrivial traveling profile requires v²=c². A constant or affine profile f''=0 alone cannot determine v by cancelling f''; the wave-speed identification is for a general nontrivial wave.

For Ey=E0 cos(kx−omega t), Bz=B0 cos(kx−omega t), Faraday gives kE0=omega B0 and Ampere gives kB0=mu0 epsilon0 omega E0; hence omega=ck and E0=cB0 for k,omega>0. The equality E=cB is understood in the aligned signed-component convention or in magnitudes for a single traveling wave; the ratio E/B is undefined at their common zeros. With propagation unit vector n, B=n×E/c and E=−c n×B. Cross products are ordinary component calculations from FM19. The zero-field instants do not change the propagation direction determined by the phase.

Wavelength=2pi/k, frequency=omega/(2pi), period=2pi/omega, speed=omega/k=lambda f. Fixed phase kx−omega t=C moves at +omega/k; kx+omega t=C moves at −omega/k. Here positive k and omega are conventions, not mandatory algebraic properties of an arbitrary supplied phase.

## 2. Standing fields, nodes and energy (R13–19; P7–10)

For R13's incident and reflected fields:
Ei=E0 cos(kx−omega t)y; Bi=(E0/c)cos(kx−omega t)z.
Er=−E0 cos(kx+omega t)y; Br=(E0/c)cos(kx+omega t)z.
Addition gives E=2E0 sin(kx) sin(omega t)y and B=2E0/c cos(kx) cos(omega t)z. E nodes x=n lambda/2; E antinodes x=lambda/4+n lambda/2. B nodes coincide with E antinodes and vice versa. At fixed generic x, E and B are one-quarter-cycle apart; at nodes the corresponding field is identically zero, so assigning that field an oscillation phase there is not meaningful. Adjacent loops have opposite signed amplitude. E vanishes everywhere at t=nT/2; B vanishes everywhere at t=T/4+nT/2.

Presentation's scalar addition uses E1=E0 sin(kx−omega t) and E2=E0 sin(kx+omega t), giving E=2E0 sin kx cos omega t. If these are y-polarized vacuum waves, their B signs are opposite: B1=E0/c sin(kx−omega t)z and B2=−E0/c sin(kx+omega t)z, so B=−2E0/c cos kx sin omega t z. This is a phase-shifted standing field, not a contradiction of R13.

The different pair in Example 13.2, R19, E=2E0 cos kx cos omega t y and B=2B0 sin kx sin omega t z with B0=E0/c, also satisfies both coupled Maxwell equations. Its Sx=(E0 B0/mu0)sin(2kx)sin(2omega t). Therefore time-average signed Sx=0. The mean magnitude is generally 2E0 B0 |sin(2kx)|/(pi mu0), not zero. For R13's pair, the same sin(2kx)sin(2omega t) flux results. The energy alternates locally between electric and magnetic contributions and flows back and forth. An ideal standing pattern's zero net transport does not mean S vanishes at every instant.

One-way wave: uE=epsilon0 E²/2, uB=B²/(2mu0), and E=cB imply uE=uB and u=uE+uB=epsilon0 E². S=E×B/mu0 has magnitude E²/(mu0 c)=cu. For a sinusoid, average of sin² or cos² over its full period is 1/2, from cos²=(1+cos2theta)/2 and FM30. Hence I=E0²/(2mu0 c)=epsilon0 c E0²/2=cB0²/(2mu0). Erms=E0/sqrt2 and I=epsilon0 c Erms². These equal-energy and S=cu formulas need the single one-way vacuum model; generally |S|<=cu follows from 2ab<=a²+b² with a=sqrt(epsilon0)|E| and b=|B|/sqrt(mu0), and perpendicularity is needed for equality.

The signed local conservation identity is partial_t u + div S = −J·E. It follows by dotting Ampere-Maxwell with E and Faraday with B/mu0 and subtracting, using div(E×B)=B·curl E−E·curl B. Its integrated form is dUfield/dt=−closed_integral S·dA−integral J·E dV. In a source-free volume the work term vanishes. This distinction resolves why steady resistive fields deliver heat although field energy is constant.

Solar example R18: I=1350 W/m², epsilon0=8.85e−12 F/m, c=3.00e8 m/s yield E0=sqrt(2I/(epsilon0 c))≈1008 V/m, B0≈3.36 microtesla. P=4pi(1.50e11 m)²I≈3.82e26 W. These are the monochromatic-equivalent amplitude conventions used by the source's estimate; real solar broadband fields need an rms interpretation.

## 3. Inductor, capacitor and resistor flux (R20–21,43–46)

Long ideal solenoid with radius r, length l, turns per length n, positive axial B=mu0 n I: Faraday around its rim gives Ephi(2pi r)=−pi r² mu0 n I', so Ephi=−mu0 n r I'/2. At the curved surface S_r=Ephi B/mu0=−mu0 n² r I I'/2. Inward power=−S_r 2pi r l=mu0 n² pi r² l I I'. Magnetic energy U=mu0 n² pi r² l I²/2 has exactly this derivative. The influx is positive when I I'>0; for I>0 this means I'>0. Decreasing |I| sends energy outward. The induced opposing emf has magnitude mu0 n² pi r² l |I'|, and the positive charging power is I|emf| under the stated positive increasing-current convention.

Charging capacitor with radius R, gap h and charge Q>0, Q'=I>0: E=Q/(epsilon0 pi R²)z. A circle r<R encloses displacement current I r²/R², so B=mu0 I r/(2pi R²)phi. Then S=−Q I r/(2epsilon0 pi² R⁴)rhat. The flux through the outward cylindrical side r=R is −Q I h/(epsilon0 pi R²); caps contribute zero. Inward power equals Q I h/(epsilon0 pi R²). With C=epsilon0 pi R²/h, U=Q²/(2C)=Q²h/(2epsilon0 pi R²), giving U'=Q I h/(epsilon0 pi R²). A decreasing positive Q reverses flux. This is the source's quasistatic ideal plate model; it accounts for electrostatic energy and neglects edge fields, retardation and any varying magnetic-energy correction.

Steady uniform conducting wire radius a, length l, conductivity sigma, current I z: J=I/(pi a²)z and E=J/sigma. Outside or at the surface, B=mu0 I/(2pi r)phi. At r=a, S=−I²/(2sigma pi² a³)rhat. Inward side power=I²l/(sigma pi a²)=I²R, R=l/(sigma pi a²). J·E volume integral gives the same result. Ufield'=0 for this steady setup; dU/dt can denote accumulating dissipated/internal energy only if that is what U is explicitly defined to mean. Reverse current reverses E and B together and leaves S inward.

## 4. Momentum and pressure (R22,35,37,40)

For normal incidence in vacuum, absorbed incident energy DeltaU transfers momentum DeltaU/c along incidence; perfect reflection reverses outgoing photon/field momentum and transfers 2DeltaU/c. Here DeltaU in the reflection case is incident energy, not absorbed energy (which is zero for an ideal reflector). Force is momentum-transfer rate: p_abs=I/c, p_refl=2I/c. For incident intensity I and reflected/transmitted energy fractions R,T into vacuum with no absorption, p=(1+R−T)I/c=2RI/c since R+T=1. With absorption fraction A and R+T+A=1, p=(A+2R)I/c. This result assumes normal incidence and compares incoming and outgoing vacuum fluxes; finite sheet storage can require a transient momentum term.

For a harmonic perfect reflector at x=0, K=2E0/(mu0 c) cos omega t y and incoming B=B0 cos omega t z. Surface force uses the incoming field (equivalently the average of the limiting total fields across the sheet), avoiding a self-field factor of two. Instantaneous pressure is 2E0 B0 cos²omega t/(mu0 c); peak is 2E0 B0/(mu0 c); mean is E0 B0/(mu0 c)=2I/c. Distinguish all three when comparing appendix expressions using amplitude E0,B0.

## 5. Radiation generation and current sheet (R23–33)

The assigned source states accelerated charges radiate, and describes a sinusoidally driven dipole with far-zone E and B proportional to 1/r, energy flux proportional to sin²theta/r², vanishing on the dipole axis and largest transverse to it. Total power is therefore finite as sphere area grows like r². Near the source, reactive stored energy can move back and forth and field directions/ratios need not be those of a far-zone one-way plane wave. The small-dipole angular law must not be silently promoted to every antenna geometry. The pictured rods' total length is approximately half a wavelength in the source's antenna discussion.

Infinite positive sheet in yz initially at rest: static Ex=sign(x)sigma_charge/(2epsilon0). Suddenly moving the positive sheet at −v y produces K=−sigma_charge v y. The newly disturbed region extends to |x|<ct. In this region the transverse wave E1=+sigma_charge v/(2epsilon0 c)y=−mu0 c K/2 on both sides. B1=+mu0 sigma_charge v/2 z on the right, negative on the left. Thus each wave's E×B points away from the sheet. A stationary negative sheet cancels the static Ex, leaving these wave fields. External force must oppose E1 on the moving positive charges, so external power/area=sigma_charge v E1=sigma_charge²v²/(2epsilon0 c). Each side carries sigma_charge²v²/(4epsilon0 c), and the sum agrees.

For a general current history K(t) in the plane, E1(x,t)=−mu0 c K(t−|x|/c)/2. B1=sgn(x) xhat×E1/c. Explicitly for K=K_y y, right Bz=−mu0 K_y/2 and left Bz=+mu0 K_y/2; B_right−B_left=−mu0 K_y z. This is consistent with xhat×(B_right−B_left)=mu0 K. Retarded time determines direction before sine/cosine rewriting. A sinusoidal K produces outgoing harmonic waves; reversal of its sign reverses both fields, not the direction of outgoing energy.

## 6. Thin resistive sheet and perfect reflection (R35–39; P28)

Appendix geometry: incident Einc=E0 cos(omega t−kx)y from x<0, Binc=(E0/c)cos(omega t−kx)z; sheet at x=0. Its emitted field is −mu0 c K(t−|x|/c)/2, and local Ohm's law is K=D Etotal(0,t)/rho. Solve Etotal=Einc−mu0 c K/2:
Etotal(0,t)=Einc(0,t)/(1+mu0 c D/(2rho));
K(t)=D Einc(0,t)/(rho+mu0 c D/2).
The perfect-conductor limit rho→0 gives Etotal(0,t)→0 but finite K=2Einc(0,t)/(mu0 c). This is a limiting relation, not division of exact zero by zero. For x>0 the emitted field cancels incidence. For x<0 Er=−E0 cos(omega t+kx)y, Br=+(E0/c)cos(omega t+kx)z, and total fields are E=2E0 sin omega t sin kx y, B=2E0/c cos omega t cos kx z. The tangential B discontinuity supplies the surface current. The source explicitly assumes a thin sheet and uniform-through-thickness current; no claim about all finite-conductivity slabs follows.

Presentation 28, fully solved in its own axes (five requested parts): incident E=E0 cos(kz−omega t)x approaches the conductor in the xy plane at z=0 from z<0. Treat conductor interior as z>0 with no transmitted time-varying field.
1. Tangential total E(0,t)=0.
2. Er=−E0 cos(kz+omega t)x, which travels toward −z and cancels incidence at z=0.
3. Bi=(E0/c)cos(kz−omega t)y and Br=(E0/c)cos(kz+omega t)y; check x×y=+z for incidence and (−x)×y=−z for reflection.
4. Etot=2E0 sin kz sin omega t x; Btot=2E0/c cos kz cos omega t y; B(0,t)=2E0/c cos omega t y.
5. Use outward normal from conductor into vacuum n=−z. K=n×Bvac/mu0=+2E0/(mu0 c)cos omega t x. Its magnitude is 2E0|cos omega t|/(mu0 c), peak 2E0/(mu0 c); direction reverses each half-cycle. Calling it a constant +x current would be incorrect.

Presentation 10's “Do Problem 2” is only a reference with the superposition formula and illustration. No additional problem statement exists among the assigned assets. The displayed standing-wave addition was solved above; no missing handout is invented.

## 7. PRS and the solved traveling-wave examples

Q1/Q2: E=E0 sin(kz+omega t)y propagates −z, so B=+(E0/c)sin(kz+omega t)x (option 1). y×x=−z. Options with z-polarization violate transversality; the negative x option gives the wrong energy direction.

Q3/Q4: B=B0 sin(ky−omega t)z propagates +y, so E=−cB0 sin(ky−omega t)x (option 4). (−x)×z=+y. The final source answer line omits E0; the option and correct dimensional expression require it.

R39–42: E=E0 sin(kz−omega t)x or cos(kz−omega t)x travels +z; companion B=(E0/c) same profile y. Faraday's component is Ex,z=−By,t. Wave-equation check for F=F0 cos(kx−omega t): Fxx=−k²F and Ftt=−omega²F; Fxx−Ftt/c²=(−k²+omega²/c²)F=0 for omega=ck. The same applies to E and B separately, but arbitrary independent amplitudes that satisfy these second-order equations are not necessarily a Maxwell pair.

## 8. All seven conceptual questions (R46–47)

1. Yes, conduction and displacement contributions can both be nonzero; changing E in a finite-conductivity region supplies the direct example J=sigma E and epsilon0 partial_t E.
2. The source radiation model attributes radiation to accelerated charges/time-varying currents, illustrated by dipole and sheet. Static fields and steady ideal currents do not produce the pictured outward radiative wave.
3. A conductive body touching an antenna can participate in the induced current and change its effective coupling/geometry, so reception may improve. The source's “usually” is not a universal consequence; detailed reception depends on geometry, orientation and losses. The allowed sources support this as a qualitative conductor/antenna inference, not a computed gain claim.
4. Incident time-varying E drives currents in steel conductors; their secondary fields reflect/suppress transmission. A real frame contains openings and is not the infinite perfect sheet; reception need not vanish completely. No quantitative shielding factor is implied.
5. Both display frequency, wavelength, superposition, interference, reflection and standing patterns. Ordinary sound needs a material medium and is longitudinal in a fluid; EM is transverse in the source's vacuum plane-wave model and propagates in vacuum. Sound speed is medium-dependent; vacuum EM speed is c. A general solid can also carry transverse elastic waves, so “all sound is longitudinal” would overstate the comparison.
6. Nonzero parallel E and B do not make a single propagating vacuum plane EM wave: transversality and B=n×E/c forbid it and E×B would be zero. This is not a ban on arbitrary static or superposed field configurations containing parallel components.
7. Holding medium and wave type fixed, I proportional E0²: halving E0 quarters I and doubling E0 quadruples I.

## 9. All ten additional problems (R47–51)

### 13.14.1 Solar sailing

For ideal normal perfect reflection, Frad=2IA/c. With isotropic solar luminosity L, I=L/(4pi r²), so Frad=LA/(2pi c r²). Gravity is GM_sun m/r². Equality gives A=2pi c GM_sun m/L. Using R18's I_E=1350 W/m² and r_E=1.50e11 m gives A=c GM_sun m/(2I_E r_E²), m=1650 kg. The distance cancels under those assumptions (outside Sun, negligible attenuation, solar gravity only, fixed sail orientation and total mass).

No numerical M_sun or GM_sun is supplied in the allowed source/baseline text. Therefore the exact source-supported result remains symbolic with the numeric coefficient A/(GM_sun). One can state an additional explicit approximation: take Earth's orbit circular with radius 1 AU and period one year, then use baseline T²=4pi²r³/(GM) and supplied year=3.16e7 s. This yields GM≈1.334e20 m³/s² and A≈1.087e6 m², square-side≈1.043 km. This estimate is conditional on that Earth-orbit model; it is not represented as a given solar mass or required memorized datum.

### 13.14.2 Reflections of True Love

(a) Assume the bulb radiates isotropically; at r=1 m, I=100/(4pi r²)=7.9577 W/m². In the source's sinusoidal plane-wave approximation, E0=sqrt(2I/(epsilon0 c))≈77.4 V/m, B0=E0/c≈2.58e−7 T.
(b) A normally illuminated perfect reflector requires K0=2B0/mu0=2E0/(mu0 c)≈0.411 A/m. The current is tangential along the incident electric-field polarization and reverses with it. This is surface current per transverse length, not a total current in amperes. Broadband real light is being approximated by the exercise's harmonic field-amplitude model.

### 13.14.3 Coaxial cable and power flow

Choose +z along the inner conductor's conventional current, from load toward battery for the given negative inner and positive outer charges. Let 0<a<b and l≫b; neglect end/fringing effects; treat both shells as ideal thin hollow conductors. Between shells a<r<b, cylindrical Gauss law gives E=−Q/(2pi epsilon0 l r)rhat. E=0 in the inner hollow r<a and outside the outer shell r>b in the ideal long balanced model. At an ideal charged shell distinguish the limiting values; a single continuous surface value is not defined.

Ampere gives B=mu0 I/(2pi r)phi for a<r<b, and zero in r<a and r>b because the net enclosed currents there are zero. Again surface limits differ. Thus S=−QI/(4pi²epsilon0 l r²)z between conductors and zero elsewhere in this idealization. The negative z direction is from source to load with the chosen axis; if +z is instead chosen source→load, inner current is −z and S is +z.

Potential outer minus inner is epsilon=−integral_a^b E_r dr=Q ln(b/a)/(2pi epsilon0 l)>0. Power toward the load is integral_a^b |S_z|2pi r dr=QI ln(b/a)/(2pi epsilon0 l)=epsilon I. Since I=epsilon/R, this equals I²R, precisely load dissipation. Field energy moves through the dielectric annulus although conventional current travels along the conductors. The source's phrase “down the inner” does not fix a Cartesian sign by itself and is not an error.

### 13.14.4 Superposition

Let A=E10 cos(kx−omega t), C=E20 cos(kx−omega t+phi). For codirectional +x waves, E=(A+C)y, B=(A+C)z/c. S=(A+C)² x/(mu0 c). Expand and average: I=(E10²+E20²+2E10E20 cos phi)/(2mu0 c). At equal amplitudes, in-phase gives four times one wave's intensity; opposite phase gives zero. This assumes coherence, so phi is fixed.

For the second wave reversed, C=E20 cos(kx+omega t+phi), B=(A−C)z/c and E=(A+C)y. Then S=(A²−C²)x/(mu0 c), with cross terms cancelling. The signed average flux is (E10²−E20²)/(2mu0 c), independent of phi; a negative value means net transport −x. If “intensity” means magnitude of net flux, take its absolute value. Mean |S| is a different quantity. Equal counterpropagating amplitudes yield a standing pattern with zero mean signed flux and potentially nonzero instantaneous local flow.

### 13.14.5 Vector sinusoid

E=E0 cos(kz−omega t)(x+y) has maximum magnitude sqrt2 E0, not E0. With propagation +z, B=(E0/c)cos(kz−omega t)(y−x). Hence S=2E0² cos²(kz−omega t)z/(mu0 c), and mean I=E0²/(mu0 c). Perfect reflection at normal incidence gives mean pressure 2E0²/(mu0 c²)=2epsilon0 E0². Instantaneous pressure is 4epsilon0 E0² cos² at the surface. The answer must state whether mean or instantaneous pressure is being reported; source section 13.7 uses mean pressure.

### 13.14.6 Radiation pressure and energy density

With E0=cB0 and c²=1/(mu0 epsilon0), uE=epsilon0 E0² sin²phase/2=B0² sin²phase/(2mu0)=uB pointwise. Mean total energy density is epsilon0 E0²/2=B0²/(2mu0). For total normal absorption, pressure I/c=<u>. At I=1350 W/m², <u>=4.50e−6 J/m³ and pressure=4.50e−6 Pa. Equal dimensions follow J/m³=N/m².

### 13.14.7 Wave energy

(a) Erms=3.0e−2 V/m, area=1.00e−4 m², time=3600 s. I=epsilon0 c Erms²≈2.3895e−6 W/m², so U=IAt≈8.60e−7 J. Do not insert an extra factor 1/2 after using rms.
(b) U=(I/c)V=1350/(3.00e8)×1.00≈4.50e−6 J, using the exercise's atmosphere-neglecting estimate. Its stated upper-atmosphere intensity does not supply an actual ground-level attenuation measurement.

### 13.14.8 Rotated wave equations

For E=Ez(x,t)z and B=By(x,t)y, curl E has y component −Ez,x. Faraday gives −Ez,x=−By,t, so Ez,x=By,t. Curl B has z component By,x; Ampere-Maxwell gives By,x=mu0 epsilon0 Ez,t. Differentiate and substitute to obtain the same second-order wave equation. The changed component signs are required by the changed polarization ordering. For a +x traveling wave with positive Ez coefficient, By must have the opposite sign, consistent with z×(−y)=+x.

### 13.14.9 Rectangular pulse and partial reflection

B=B0 f(ax+bt)y, f=1 for 0<u<1 and 0 otherwise. Assume a nonzero and b nonzero for a traveling pulse. Fixed argument moves at v=−b/a. Vacuum compatibility requires b²=c²a² (equivalently |b/a|=c). A general companion is E=(b/a)B0 f(ax+bt)z, because Ez,x=By,t. Its direction is sign(b/a) z for B0>0. For the usual a,b>0 case it points +z (out of the paper as stated), and the pulse travels −x.

S=−(b/a)B0² f² x/mu0. Its plateau magnitude is cB0²/mu0, and it points with propagation. There is no harmonic averaging factor 1/2 for a constant rectangular plateau. With half the incident energy reflected, half transmitted into vacuum, and none absorbed, the effective pressure during a steady interacting plateau is 2(1/2)Sinc/c=B0²/mu0 along incidence. Integrated impulse/area for the full pulse follows the same momentum balance. Finite slab delay or temporarily stored momentum can alter instantaneous leading/trailing-edge force; the question does not provide enough material data to resolve that transient.

Since f has jump edges, ordinary classical derivatives fail exactly at the edges. The Maxwell/wave relations hold away from edges and in the weak/distributional ideal-pulse sense when the same speed and jump relation are used. This is a stated idealization, not permission to differentiate the step as a smooth function.

### 13.14.10 Ferrite sinusoid

Phase=(2pi/3)x−2pi(10^6)t, E along +z polarization with amplitude 300 V/m.
(a) Wave travels +x.
(b) k=2pi/3 m−1 ⇒ lambda=3 m.
(c) omega=2pi×10^6 s−1 ⇒ f=1.00e6 Hz.
(d) v=omega/k=3.00e6 m/s. The given relative factors 1000 and 10 are consistent with c/sqrt(1000×10)=c/100 under the nondispersive homogeneous medium model.
(e) Faraday gives B=(1/v)n×E, so B=−(1.00e−4 T)cos[(2pi/3)x−2pi10^6t]y. Its amplitude is E0/v; using E0/c would be wrong in the ferrite.
(g) Frequency is preserved at a stationary boundary (baseline refraction rule), so emerging vacuum wavelength is c/f=300 m. The source labels skip (f); no missing question is invented.
