"""Reproducible independent math checks, limited to dossier output.
Constants are rounded values visible in allowed source/baseline.
No external files are needed by the calculation itself.
"""
from pathlib import Path
import json, math
out=Path(__file__).resolve().parent
pi=math.pi
c=3e8; eps=8.85e-12; mu=4*pi*1e-7
sun_I=1350.; sun_r=1.5e11; ship_m=1650.; year=3.16e7
bulb_I=100/(4*pi)
bulb_E=math.sqrt(2*bulb_I/(eps*c))
solar_GM_orbit=4*pi*pi*sun_r**3/year**2
r={
 'constants':{'c_m_s':c,'epsilon0_F_m':eps,'mu0_H_m':mu,'source_note':'Rounded c and epsilon0 from allowed baseline; mu0=4pi e-7 source convention.'},
 'solar_example':{'E0_V_m':math.sqrt(2*sun_I/(eps*c)),'B0_T':math.sqrt(2*sun_I/(eps*c))/c,'luminosity_W':4*pi*sun_r**2*sun_I},
 'solar_sail':{'A_per_GM_s2_m':c*ship_m/(2*sun_I*sun_r**2),'conditional_GM_circular_one_year_orbit_m3_s2':solar_GM_orbit,'conditional_area_m2':c*solar_GM_orbit*ship_m/(2*sun_I*sun_r**2),'conditional_square_side_m':math.sqrt(c*solar_GM_orbit*ship_m/(2*sun_I*sun_r**2)),'limitation':'No numerical solar GM/M directly supplied; orbital estimate explicitly conditional.'},
 'bulb':{'I_W_m2':bulb_I,'E0_V_m':bulb_E,'B0_T':bulb_E/c,'K0_A_m':2*bulb_E/(mu*c)},
 'solar_energy':{'mean_density_J_m3':sun_I/c,'absorber_pressure_Pa':sun_I/c,'one_m3_energy_J':sun_I/c},
 'rms_energy':{'Erms_V_m':.03,'I_W_m2':eps*c*.03**2,'area_m2':1e-4,'time_s':3600,'energy_J':eps*c*.03**2*1e-4*3600},
 'ferrite':{'lambda_m':3.,'frequency_Hz':1e6,'speed_m_s':3e6,'B0_T':300/3e6,'B_basis':'negative y','vacuum_lambda_m':300.}
}
# Independent numerical substitutions into the analytically derived identities.
# These complement calculations.md; they do not claim a computer algebra proof.
checks=[]
def eq(name,a,b):
    residual=a-b
    assert math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10),(name,a,b,residual)
    checks.append({'name':name,'lhs':a,'rhs':b,'residual':residual})
def cross(u,v):
    return (u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
for j,(x,t,k,v,E0,mu0) in enumerate([(0.31,0.27,1.3,2.1,1.7,.8),(.9,.13,.7,3.2,2.3,1.1),(-.42,.89,1.9,1.7,.6,2.2)]):
    w=k*v; eps0=1/(mu0*v*v); phase=k*x-w*t
    Ex=-k*E0*math.sin(phase); Bt=w*E0/v*math.sin(phase)
    Bx=-k*E0/v*math.sin(phase); Et=w*E0*math.sin(phase)
    eq(f'travel_faraday_{j}',Ex,-Bt)
    eq(f'travel_ampere_{j}',Bx,-mu0*eps0*Et)
    eq(f'travel_wave_{j}',-k*k*E0*math.cos(phase),-w*w*E0*math.cos(phase)/(v*v))
    E=2*E0*math.sin(k*x)*math.sin(w*t)
    B=2*E0/v*math.cos(k*x)*math.cos(w*t)
    Ex=2*E0*k*math.cos(k*x)*math.sin(w*t)
    Bt=-2*E0/v*w*math.cos(k*x)*math.sin(w*t)
    Bx=-2*E0/v*k*math.sin(k*x)*math.cos(w*t)
    Et=2*E0*w*math.sin(k*x)*math.cos(w*t)
    eq(f'standing_faraday_{j}',Ex,-Bt)
    eq(f'standing_ampere_{j}',Bx,-mu0*eps0*Et)
    eq(f'standing_flux_{j}',E*B/mu0,E0*E0/(mu0*v)*math.sin(2*k*x)*math.sin(2*w*t))
    eq(f'standing_energy_{j}',eps0*E*Et+B*Bt/mu0,-(Ex*B+E*Bx)/mu0)
    Ealt=2*E0*math.cos(k*x)*math.cos(w*t)
    Balt=2*E0/v*math.sin(k*x)*math.sin(w*t)
    Exalt=-2*E0*k*math.sin(k*x)*math.cos(w*t)
    Btalt=2*E0/v*w*math.sin(k*x)*math.cos(w*t)
    Bxalt=2*E0/v*k*math.cos(k*x)*math.sin(w*t)
    Etalt=-2*E0*w*math.cos(k*x)*math.sin(w*t)
    eq(f'alternate_standing_faraday_{j}',Exalt,-Btalt)
    eq(f'alternate_standing_ampere_{j}',Bxalt,-mu0*eps0*Etalt)
    eq(f'mirror_E_total_{j}',E0*(math.cos(k*x-w*t)-math.cos(k*x+w*t)),E)
    eq(f'mirror_B_total_{j}',E0/v*(math.cos(k*x-w*t)+math.cos(k*x+w*t)),B)
    normal=(0,0,-1);K=cross(normal,(0,2*E0/v*math.cos(w*t),0))
    eq(f'mirror_surface_current_{j}',K[0]/mu0,2*E0/(mu0*v)*math.cos(w*t))
    eq(f'counterprop_cross_cancellation_{j}',(Ealt+Balt)*(Ealt-Balt),Ealt*Ealt-Balt*Balt)
# Nonzero sample values retain the signs in cylindrical energy balances.
Q,I,Rcap,h,eps0=1.9,2.4,1.2,.7,.6
cap_Sr=-Q*I*Rcap/(2*eps0*pi*pi*Rcap**4)
eq('capacitor_influx',-cap_Sr*2*pi*Rcap*h,Q*I*h/(eps0*pi*Rcap**2))
a,l,sigma=.31,2.2,3.7
wire_Sr=-I*I/(2*sigma*pi*pi*a**3)
eq('wire_influx',-wire_Sr*2*pi*a*l,I*I*l/(sigma*pi*a*a))
mu0,n,radius,Idot=.9,2.1,.7,.4
sol_Sr=-mu0*n*n*radius*I*Idot/2
eq('solenoid_influx',-sol_Sr*2*pi*radius*l,mu0*n*n*pi*radius*radius*l*I*Idot)
b=.8;coax_voltage=Q*math.log(b/a)/(2*pi*eps0*l)
eq('coax_integrated_power',Q*I*math.log(b/a)/(2*pi*eps0*l),coax_voltage*I)
eq('PRS1_direction',cross((0,1,0),(1,0,0))[2],-1)
eq('PRS2_direction',cross((-1,0,0),(0,0,1))[1],1)
eq('vector_sinusoid_flux_factor',cross((1,1,0),(-1,1,0))[2],2)
r['substitution_checks']=checks
r['substitution_checks_passed']=len(checks)
r['verification_limits']='Analytic derivations in calculations.md plus numeric substitutions here; SymPy was unavailable in both Python runtimes and no symbolic-computation success is claimed.'
out.joinpath('calculation-results.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'results_file':'calculation-results.json','solar':r['solar_example'],'sail':r['solar_sail'],'bulb':r['bulb'],'rms':r['rms_energy']},indent=2))
