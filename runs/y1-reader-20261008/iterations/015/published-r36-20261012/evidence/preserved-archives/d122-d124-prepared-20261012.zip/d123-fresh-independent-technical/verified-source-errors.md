# Original-source checks — private

These checks were made independently against allowed TXT and original-resolution PNG views and the explicit laws in those same originals. They are not imported audit findings. R denotes reading PDF/PNG page (printed page is one less); P presentation page; Q PRS page. A scope qualification is distinguished from a typographical mistake. Image corroboration matters because the PDF text extraction rearranges mathematical symbols.

## Directly verified slips

| Location | Visible source statement | Independent check and correction | Scope |
|---|---|---|---|
| P23 derivation middle equality | After Ey,xx the displayed chain has +partial_x(partial_t Bz), then −partial_t(partial_x Bz) | Its own first line says Ey,x=−Bz,t. Differentiating requires −partial_x(partial_t Bz). The source's final wave equation is correct; this intermediate equality is missing a minus | Mathematical sign slip, confirmed PNG |
| P25 prose above derivation | Says take the x derivative of the first equation | First equation is Bz,t=−Ey,x and the shown next line starts partial_t(partial_t Bz)=Bz,tt. The displayed derivation takes a time derivative of the first equation, then substitutes the second. Changing “x” to “t” makes the prose agree | Instruction typo, confirmed PNG; resulting wave equation correct |
| Q4 answer formula | E(y,t)=−ihat sin(ky−omega t) | Q3 option 4 includes E0, and dimensional/Maxwell checking requires E=−E0 sin(...)ihat with E0=cB0. The selected option and direction reasoning are correct | Missing amplitude, confirmed PNG |
| R38 text immediately after Eq13.10.9 | Says Eq13.10.9 was used for the last step of Eq13.10.9 | The substitution K=D E(0,t)/rho is Eq13.10.8, displayed immediately above. Correct reference is13.10.8 | Cross-reference typo, confirmed PNG |
| R45 Eq13.12.19 | Closed integral S·dA is set equal to positive inward charging power | R44 gives S_r<0 for Q>0,Q'>0; R20 establishes outward convention with a minus. For outward dA, integral is negative. Correct energy-entry expression is −closed_integral S·dA=QIh/(epsilon0 pi R²), or explicitly redefine normals inward | Orientation/sign inconsistency under the established convention, confirmed PNG |
| R46 Eq13.12.24 | P=dU/dt=closed_surface_integral S·dA=positive I²R | R46 Eq13.12.23 says S is inward. For outward normals the flux is −I²R and inward power is its negative. Correct P_in=−integral S·dA=I²R | Same orientation/sign inconsistency; energy-variable qualification below |
| R35 summary, and corresponding momentum discussion | Momentum transfer is described as related to “energy absorbed,” including a perfect-reflection line 2DeltaU/c | For ideal reflection absorbed energy is zero, but momentum transfer is nonzero. DeltaU in the reflection formula must mean incident/intercepted energy, not absorbed energy | Wording error with a physically consequential interpretation; formulas work with corrected meaning |

## Ambiguous notation or model scope requiring explicit qualification

1. **R36–37 appendix current and force amplitudes.** Eq13.10.1 explicitly defines scalar E0,B0 as harmonic amplitudes. Eq13.10.3 writes K=|Kvector|=2E0/(c mu0), while the later correct time-resolved Eq13.10.12 is Kvector=2E0 cos(omega t)y/(c mu0). The earlier scalar K must be a peak amplitude, not the instantaneous magnitude. Correspondingly Eqs13.10.5–6 show force/area 2E0B0/(c mu0) without cos². This equals peak pressure; instantaneous pressure needs cos² and mean pressure is half that peak. The final relation p=2S/c is valid when S and p use matching instantaneous or averaged conventions. Do not read the amplitude product as mean pressure. Classify as amplitude/time ambiguity unless the relevant source quantity is explicitly claimed to be mean.

2. **R19 standing-wave “intensity.”** The calculation obtains the zero time average of the signed flux component. R17 had described S as a magnitude. An actual magnitude is nonnegative and its average generally does not vanish. The physical claim of zero *net* transport is correct. Write <Sx>=0, not <|S|>=0. This distinction also applies to R48 counterpropagating superposition.

3. **R20 Eq13.6.16 and R46 energy variable.** The pure dU/dt=−integral S·dA relation for field energy assumes no J·E transfer to matter inside the volume. The resistor has steady fields, so dUfield/dt=0 while incoming power is I²R and becomes heat. The R46 dU/dt symbol can be consistent only if U is energy received/dissipated, not the unchanged field energy. This is resolved directly by the source Maxwell laws plus energy bookkeeping; no external theorem is required.

4. **R12/P16 E/B and phase claims.** Appropriate for a single one-way vacuum plane wave, not all superpositions, near fields, or matter. Ratios at simultaneous zeros are undefined; the proportionality identity remains usable. Stating field polarization +y does not imply the vector never reverses.

5. **R44 charging-capacitor inward direction.** Source explicitly treats charge accumulated on the positive plate, Q>0. “Q'>0 means inward” is valid in that context. Generalized signed charge conventions require QQ'>0, as do the corresponding II' energy signs for the inductor.

6. **R50 rectangular pulse.** The question does not declare signs of a,b. The general speed is −b/a and the vacuum condition is b²=c²a². The often intended +z E/−x travel answer requires a,b of the same sign. Step edges need a weak ideal-pulse interpretation, and finite slab transient force cannot be reconstructed from a half-energy reflection statement alone. Plateau/integrated momentum answers are retained with those assumptions.

7. **R47 numerical solar sail.** Solar GM/M is not directly tabulated in the allowed text. The symbolic result is complete. An optional circular one-year Earth-orbit estimate uses a stated approximation; it is not a supplied solar mass. No lookup was performed.

8. **P10 absent group prompt.** “Do Problem 2” has a formula and illustration but no full problem statement in the three assigned assets. This is a content limitation, not a failed file read and not authority to invent the original question.

9. **R51 part labels.** The final problem's sequence is (a),(b),(c),(d),(e),(g). No (f) text occurs. This is numbering, not evidence of an inaccessible page.

## Candidates explicitly not treated as errors

- R19's E proportional cos(kx)cos(omega t) and B proportional sin(kx)sin(omega t) form a valid Maxwell standing pair. It uses a different phase/spatial convention from R13; the zero mean signed flux calculation remains valid.
- R48 coax prose “down the inner conductor” does not define an absolute axis. With negative inner charge and positive outer charge, choose the inner-current direction from load to source; E×B then points to load. No contradiction need be asserted.
- Rotated polarization R50 has positive signs in Ez,x=By,t and By,x=mu0epsilon0 Ez,t. These differ correctly from the Ey/Bz ordering; they are not sign errors.
- Ferrite source phase gives v=3e6m/s and the product of relative parameters is10,000, consistent with c/100 in the stated ideal-medium interpretation.
- Numerical changes between using rounded c,epsilon0 and mu0 are rounding-level effects; do not claim a fundamental inconsistency from independently rounded constants.
- PDF text extraction fragments vector arrows, subscripts and fractions; no error is inferred solely from TXT ordering where the original PNG is sound.
