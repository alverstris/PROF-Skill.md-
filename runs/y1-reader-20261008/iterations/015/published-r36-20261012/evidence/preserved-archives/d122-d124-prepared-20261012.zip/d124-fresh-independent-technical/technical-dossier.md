# D124 independent original-source technical dossier

Preparation date: 2026-10-12 UTC. Preparer: /root/technical_d124_prepared.

Status: source preparation only. Semantic findings are held for a future explicit frozen-teaching release. This is neither student teaching nor a PROF/SASIS review. No candidate teaching, previous diagnosis, review output, queue, or other agent's semantic work was admitted.

## 1. Admitted evidence and scope

The complete original assignment is MIT 8.02T Spring 2005 session 32, material D124, titled “Hour 1 Generating Electromagnetic Waves Plane EM Waves Electric Dipole EM Waves Hour 2 Experiment 12: Microwaves Review Exam 3 Results.” The identity metadata specifies source revision 54ebb635d842f1d65c2508b8f921fd32819f5f0c. Its identity-basis path and historical cache paths are metadata only; those locations were not opened.

Admitted original assets are chapter 13, all 51 PDF pages; presentation presentati_w14d1, all 36 PDF pages; and PRS prs_w14d1, all 8 PDF pages. Every original TXT derivative was read in full and every original PNG was displayed through view_image at original detail and inspected. Three source PDFs were byte-hash verified. Chapter PDF page p is printed chapter page p−1. Presentation labels P32-p and PRS PDF page numbers are used below.

The only baseline is the complete 247840-byte student-baseline.txt, SHA256 3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5. All bytes were read in bounded ranges. It supplies four subject baselines, not a license to assume university electromagnetism from earlier sessions.

input-manifest.json preserves the full original identity metadata, exact local paths, source URLs, every original PDF/TXT/PNG hash, baseline hash, byte counts, and image dimensions. read-coverage.json preserves individual page coverage and full read ranges. All 195 admitted files (193 asset files, identity metadata, baseline) were hash recorded; all 193 asset hashes agree with supplied identity expectations. All 95 images agree with expected dimensions. External subject-source admissions: none. No browser or external retrieval was used.

The initial large metadata output was visibly truncated and was not accepted as complete coverage. Four later bounded line ranges recovered all 1518 lines. There were no image-display failures, no undisplayed pages, and no image crops used as substitutes for original full pages.

## 2. Baseline capability boundary

The complete baseline supports scalar and vector algebra; Cartesian components; scalar and vector products, including the component cross-product definition; trigonometric addition identities; radians; ordinary differentiation and integration; chain rules; function means; linear second-order ordinary differential equations; elementary waves, superposition, standing waves, polarization, phase, frequency, wavelength and v=fλ; SI units; force, momentum, power, pressure and energy; inverse-square gravitation; current as charge flow; E=F/q; potential; capacitance and capacitor energy; resistance and resistivity; magnetic forces; magnetic flux; and Faraday induction at the baseline level.

The following are not assumed ready-made baseline operations: partial derivatives and PDEs; vector fields as functions of position and time; oriented line/surface/volume integrals; divergence and curl; the integral/differential Maxwell system; displacement current; electromagnetic field energy density; Poynting transport; self-inductance formulas and LC resonance; surface current density; radiation pressure; cylindrical unit-vector conventions; retarded-time source fields; radiation-zone approximations; constitutive Maxwell equations in a medium. These are source demands or explicit reconstruction premises, not imported prior attainments.

The baseline provides c≈3.0×10^8 m/s, ε0≈8.85×10^−12 F/m, G≈6.67×10^−11 N m²/kg² and the astronomical unit approximately 1.50×10^11 m. The original chapter supplies μ0=4π×10^−7 in SI. Source numerical rounding is retained. A solar mass or solar gravitational parameter is not supplied in the admitted exercise context or frozen constants; the sail exercise is therefore completed symbolically with that missing numerical datum identified.

## 3. Notation, units, orientation and domains

Cartesian basis vectors obey xhat×yhat=zhat, yhat×zhat=xhat, zhat×xhat=yhat. Reversing product order changes the sign. In cylindrical coordinates rhat points radially out and phihat follows increasing azimuth, so rhat×phihat=zhat and zhat×phihat=−rhat. Dot/cross symbols in the source graphics denote out of/into the page.

E has units V/m or N/C; B tesla; ε0 F/m; μ0 H/m; c m/s; k rad/m (radian dimensionless); ω rad/s; f Hz; λ m; electric volume charge density C/m³; electric surface charge density C/m²; conduction J A/m²; surface current K A/m; conductivity S/m; resistivity Ω m; capacitance F; inductance H; u J/m³; S W/m²; pressure N/m²=J/m³. The source reuses σ for surface charge density and conductivity; each calculation below states which meaning applies. I is current in circuit examples and intensity in radiation examples; they must not be interchanged.

A scalar such as Ey can be signed. “E amplitude” is nonnegative, while instantaneous E can point either way along its polarization axis. E=cB as signed component equality applies to the specified axes of one travelling vacuum wave. A ratio E/B is undefined at a common node; the equality of fields or amplitudes is the safe statement. S is a vector; its signed normal component, its magnitude, and its time average are distinct quantities. Counterpropagating waves can have zero mean net transport with nonzero local field energy and nonzero average magnitude of local transport.

All closed-surface fluxes below use the outward normal. Inward electromagnetic power is −∮S·n dA. All Maxwell surfaces must have boundaries with compatible right-hand orientation. Source-free means local charge/current vanish in the modeled region, not merely that their totals accidentally cancel. Smooth-wave derivative arguments require appropriate differentiability; the rectangular pulse requires weak/distributional interpretation at its fronts.

## 4. Reconstructed governing relations

### 4.1 Displacement current and Maxwell equations

Evidence: chapter pp3–6. A changing ideal parallel-plate capacitor has Q=ε0EA, so ε0 dΦE/dt=dQ/dt=I for the surface through the gap. This reconciles two spanning surfaces of the same magnetic loop. The reconstructed Maxwell–Ampère law is ∮B·dl=μ0(Ienc+ε0 dΦE/dt), with Ienc and ΦE evaluated on the same oriented spanning surface. Displacement current is not the assertion that free charge crosses the vacuum gap.

Vacuum integral laws are ∮E·dA=Qenc/ε0, ∮B·dA=0, ∮E·dl=−dΦB/dt, and the preceding Maxwell–Ampère law. In local notation: div E=ρ/ε0, div B=0, curl E=−∂tB, curl B=μ0J+μ0ε0∂tE. The differential forms require the definitions of div/curl and the integral-to-local passage. A source-free region sets ρ=0 and J=0. Magnetic flux through a closed surface vanishes; open-surface magnetic flux need not.

### 4.2 Plane-wave differential relations and speed

Evidence: chapter pp7–12. For E=Ey(x,t)yhat and B=Bz(x,t)zhat with no y/z variation, oriented rectangular loops give ∂xEy=−∂tBz and ∂xBz=−μ0ε0∂tEy. Differentiate and eliminate the other field to obtain Fxx=μ0ε0Ftt for either component. A C² travelling function F=f(x−vt) has Fxx=f'' and Ftt=v²f'', so a nontrivial profile obeys v²=1/(μ0ε0). Define c=1/√(μ0ε0). Functions f(x+ct) travel toward −x; f(x−ct) toward +x. Constant fields alone cannot determine v from f''=0.

For Ey=E0 cos(kx−ωt), the coupled first-order equations require ω=ck and Bz=(E0/c)cos(kx−ωt), with k,ω positive under this direction convention. k=2π/λ and ω=2πf. The derivative check verifies both the PDE and the coupling. S=E×B/μ0 points +x; when the cosine changes sign both fields reverse, leaving the propagation direction unchanged. For a single plane wave with unit propagation vector nhat, B=(nhat×E)/c. Vacuum transversality and in-phase fields are single travelling radiation-wave properties, not universal properties of arbitrary superpositions or near fields.

For the exercise orientation E=Ez(x,t)zhat, B=By(x,t)yhat, the curl components change sign: ∂xEz=∂tBy and ∂xBy=μ0ε0∂tEz. A +x wave then has negative By relative to positive Ez.

### 4.3 Standing waves and reflection boundaries

Evidence: chapter pp13–15, p19, pp35–39. Superposing incident Ey=E0 cos(kx−ωt), Bz=B0 cos(kx−ωt) with reflected Ey=−E0 cos(kx+ωt), Bz=+B0 cos(kx+ωt), E0=cB0, gives Ey=2E0 sin(kx)sin(ωt), Bz=2B0 cos(kx)cos(ωt). The conducting boundary at x=0 has tangential E=0 and doubled B. Electric nodes are x=nλ/2; magnetic nodes are x=(n/2+1/4)λ. Adjacent nodes of the same field are λ/2 apart; an electric node and nearest magnetic node are λ/4 apart. In a cavity with both appropriate conductor boundaries, L=nλ/2 with n a positive integer. A full-line coordinate allows all integer node indices.

The chapter's other standing-wave phase choice is Ey=2E0 cos(kx)cos(ωt), Bz=2B0 sin(kx)sin(ωt). It also satisfies Maxwell and has Sx=(E0B0/μ0)sin(2kx)sin(2ωt), whose time average is zero. A phase origin swaps node locations without changing the physics. At a node the phase of the zero field is not defined. Elsewhere the local electric and magnetic oscillations are in temporal quadrature.

### 4.4 Field energy and Poynting balance

Evidence: chapter pp15–22 and solved capacitor/conductor pp43–46. uE=ε0E²/2 and uB=B²/(2μ0); u=uE+uB. For a single travelling vacuum wave E=cB, uE=uB and |S|=cu. For a sinusoidal wave, ⟨cos²⟩=1/2 gives I=⟨|S|⟩=E0B0/(2μ0)=cε0E0²/2=cB0²/(2μ0), and ⟨u⟩=ε0E0²/2=B0²/(2μ0). For rms E, I=cε0Erms², with no extra factor 1/2.

The general local vacuum/macroscopic-conduction energy balance is ∂tu+div S=−J·E. It follows from Maxwell with the component identity div(E×B)=B·curl E−E·curl B. Integrated: dUfield/dt=−∮S·n dA−∫J·E dV. Thus dUfield/dt=−∮S·n dA only where the volume does no electrical work on matter. A steady resistor has constant stored electromagnetic energy and inward electromagnetic flux equal to Joule heating. Its heating must not be mislabeled as increasing steady field energy.

The source equations 13.12.19 (chapter p45) and 13.12.24 (p46) display a positive flux expression for energy entering a volume. With outward dA, each requires a minus sign. They are correct as inward-flux magnitudes or if an inward orientation is explicitly adopted, but cannot retain the earlier outward orientation silently.

### 4.5 Radiation momentum and pressure

Evidence: chapter p22 and p37. Normal incident energy ΔU carries momentum ΔU/c along propagation. Absorption transfers ΔU/c; ideal reversal transfers 2ΔU/c. With incident time-mean intensity I, mean pressures are I/c and 2I/c respectively. For reflection ΔU denotes incident energy, not zero net absorbed energy. More generally in vacuum, normal lossless reflection/transmission fractions R,T give pressure (1+R−T)I/c, assuming steady completed transport or an integrated pulse balance. For R=T=1/2 this is I/c. Transmission through a finite slab can delay outgoing flux; an exact leading/trailing transient force is not fixed by total energy fractions alone.

Source p37 writes 2E0B0/(μ0c). If E0,B0 denote peak sinusoidal amplitudes, this is peak pressure; instantaneous pressure includes cos²(ωt) and the time mean is E0B0/(μ0c)=2I/c. If they denote instantaneous incident magnitudes, the expression is already instantaneous. Preserve that distinction.

### 4.6 Driven infinite charge sheet and radiation reaction

Evidence: chapter pp26–33 and presentation pp6–14. Let a positive sheet σq at x=0 have tangential velocity vvec=−v yhat. Its electrostatic field is sgn(x)σq/(2ε0)xhat. A start at t=0 produces fronts |x|=ct. The geometric kink gives transverse E1=σqv/(2ε0c)yhat, and Ampère gives B1=sgn(x)μ0σqv/2 zhat within the outgoing disturbance. E1/B1 in magnitude is c. The tangential surface current is K=σqvvec=−σqv yhat.

The outgoing-sheet relation, including retardation, is E1(x,t)=−(Z0/2)K(t−|x|/c), with Z0=μ0c and B1=sgn(x)xhat×E1/c. It verifies the source's t−x/c on the right and t+x/c on the left. For sinusoidal velocity the field at a given x samples retarded velocity, not the sheet's present velocity.

At the sheet, electrical force/area σqE1 opposes vvec. Required external work/area/time is σq²v²/(2ε0c). Radiation-only S through each outward side has magnitude σq²v²/(4ε0c); the two sides sum to that work. The full static-plus-radiative E×B also has tangential terms; the stated outward radiation result uses the transverse radiative component. A coincident stationary opposite-charge sheet can cancel the static E without changing the moving-sheet radiation calculation.

The “100% efficiency” statement on presentation p12 means the ideal external work against this radiation reaction is accounted for by outgoing EM energy. It is not a statement about a real antenna's electrical-to-radiation efficiency or startup kinetic energy. The infinite coherent sheet's E proportional to velocity must not be conflated with the far field of a single localized accelerated charge. Infinite geometry has neither spherical spreading nor finite total radiated power over its whole area.

### 4.7 Conducting sheet and perfect-reflector limit

Evidence: chapter pp35–39. Let sheet thickness D, resistivity ρΩ and uniform tangential current density J be a stipulated thin-sheet model, K=DJ. Its emitted field at the sheet is −Z0K/2. Ohm's law must use total E: K=(D/ρΩ)Etotal. Hence Etotal=Ei/[1+Z0D/(2ρΩ)] and K=DEi/[ρΩ+Z0D/2]. As ρΩ→0, Etotal→0 while K→2Ei/Z0, yielding reflected electric amplitude −Ei and zero transmission.

Uniform current is an extra model assumption: D small compared with the external wavelength alone does not guarantee penetration throughout an arbitrary good conductor. The limiting surface-current boundary result is sound independently of that oversimplified finite-thickness argument.

An independent energy closure uses g=Z0D/(2ρΩ), r=−g/(1+g), t=1/(1+g). For a sheet between identical vacuum half-spaces, power fractions R=g²/(1+g)², T=1/(1+g)² and A=2g/(1+g)² sum to 1. Ohmic power/area equals A times incident intensity. Limits g→0 and g→∞ yield full transmission and full reflection. The fields acting on the sheet's magnetic force use the average external B across the sheet; self-field must not be double-counted. In the perfect limit that average is the incident B and K×B gives the preceding pressure.

### 4.8 Dipole radiation, reception and source geometry

Evidence: chapter pp23–26; presentation pp15–20, pp25–34; PRS pp3–8. A time-varying localized electric dipole radiates; for the short-dipole far-field approximation its field amplitude varies sinθ/r and intensity sin²θ/r², θ measured from the dipole axis. The radiation zone requires r large compared with source size and wavelength. This gives zero radiation along the axis and maximum broadside at equal r. Exact half-wave antenna patterns need not equal the short-dipole sin²θ form, though the axial null and broadside maximum remain compatible with the supplied idealization.

The diagrams label each of two antenna arms λ/4, so their tip-to-tip length is approximately λ/2. A single arm's quarter-wave label must not be silently applied to the entire two-arm dipole. Static charge-distribution fields and radiation fields have different near/far behavior. Source still frames show electric field-line topology, not charge trajectories. The source's dipole visualizations contain reactive near-region energy that can move inward and outward; the far outgoing radiation has outward mean transport.

A short receiving electric element samples the component E·uhat along its straight axis. At fixed location, fixed loading and small element size, received voltage scales cosα and received power cos²α. Alignment with the local E maximizes pickup; this is a separate factor from transmitter angular radiation distribution. The source's reception answer is conditioned on its broadside receiver placement. An exact wire-loop detector response, impedance match, gain, or nonideal room pattern is not supplied.

### 4.9 Lumped LC and spark-gap reconstruction

Evidence: presentation pp21–24. The p23 schematic labels parallel-plate overlap 2d, separation d, depth h; cylindrical-inductor radius d and depth h. Under its intended ideal parallel-plate and long-cylinder model, Aplate=2dh, C=ε0Aplate/d=2ε0h, sheet current per depth I/h, B=μ0I/h, flux Φ=Bπd², and L=Φ/I=μ0πd²/h. Therefore LC=2πμ0ε0d², ω0=c/[√(2π)d], f0=c/[2π√(2π)d]. Units: C in F, L in H, ω0 in s^−1. Height cancels. The drawing alone does not determine exact fringing or magnetic cross-section corrections. In particular a width 2d and gap d does not furnish a strongly controlled negligible-fringing limit. These are intended ideal-model answers, not an exact resonator calculation.

The oscillator relation follows from ideal charge conservation and KVL, Lq''+q/C=0, so q(t) is sinusoidal and ω0²=1/(LC). This use of self-inductance and KVL must be supplied; “Recall” on the source slide is not evidence that the frozen baseline includes it.

On p24, R=4.5×10^6 Ω and C=33×10^−12 F give RC=1.485×10^−4 s, agreeing with 1.5×10^−4 s. Each 31 mm arm gives λ≈4l=124 mm and f≈c/(4l)=2.419×10^9 Hz, agreeing with 2.4 GHz. The RC charging/repetition time, breakdown transient (~10^−7 s in the graphic) and radio oscillation period (~4.13×10^−10 s) are distinct. Breakdown threshold and drive voltage are absent, so RC does not uniquely determine the repetition interval. The decaying pulse graph is qualitative; no damping coefficient is provided.

## 5. Every chapter worked example and solved problem checked

| Item and original page | Independent check and result | Required qualifications |
|---|---|---|
| Example 13.1, pp17–18: sunlight | With I=1350 W/m², E0=√(2I/(cε0))=1.0084×10^3 V/m; B0=E0/c=3.3615×10^−6 T. P=4π(1.50×10^11 m)²I=3.8170×10^26 W. Agrees with printed rounding. | The exercise explicitly assumes a local sinusoidal plane wave; global source is isotropic/spherical. A unique optical peak is not inferred for unrestricted broadband sunlight. |
| Example 13.2, p19: standing-wave flux | Cross product of 2E0 coskx cosωt yhat and 2B0 sinkx sinωt zhat gives Sx=(E0B0/μ0)sin2kx sin2ωt; ⟨Sx⟩=0. | Zero signed mean flux does not mean zero energy or zero ⟨|S|⟩. |
| Solenoid example, pp20–22 | For radius r, length l, n turns/m: B=μ0nI zhat; Eφ(r)=−μ0nr I'/2; Sr=−μ0n²rII'/2; inward flux=μ0πn²r²lII'=d[μ0πn²r²lI²/2]/dt. L=μ0n²πr²l. | Long ideal solenoid, quasi-static flux model, ignore ends. Inward transport requires II'>0, not I'>0 alone. |
| Strategy example, pp39–40 | E=E0 sin(kz−ωt)xhat propagates +z; B=(E0/c)sin(kz−ωt)yhat; S=(E0²/(μ0c))sin²(kz−ωt)zhat; I=E0²/(2μ0c); mean perfect-reflector pressure ε0E0². | Positive k,ω; vacuum; normal reflection. Field direction reverses with sine; polarization axis is fixed. |
| 13.12.1, p41 | E=E0 cos(kz−ωt)xhat gives +z and B=(E0/c)cos(kz−ωt)yhat. Derivatives satisfy ∂zEx=−∂tBy. | B is along +y only when cosine is positive. |
| 13.12.2, p42 | For each sinusoidal component, Fxx=−k²F and Ftt=−ω²F; wave residual is (−k²+ω²/c²)F=0. | Passing scalar wave equation alone does not verify relative E/B direction, amplitude or phase; Maxwell coupling also needed. |
| 13.12.3(a), pp43–44 | For circular radius R, charge Q, current Q', gap h: E=Q/(πε0R²)zhat; inside r<R, B=μ0rQ'/(2πR²)phihat; S=−QrQ'/(2π²ε0R^4)rhat. | Quasi-static, uniform gap E, neglected fringing. Radially inward for QQ'>0. |
| 13.12.3(b), p45 | At r=R, inward flux QhQ'/(πε0R²)=VQ'=d[Q²h/(2πε0R²)]/dt. | Minus outward flux, as explained above. |
| 13.12.4(a–d), pp45–46 | Conductivity σc: E=I/(σcπa²)zhat; B just outside r=a is μ0I/(2πa)phihat; Ssurface=−I²/(2π²σca³)rhat; inward power=I²l/(σcπa²)=I²R. | Uniform steady current; long cylinder; no confusion between heat production and stored steady field energy. |

## 6. Every conceptual question checked

Chapter 13.13, pp46–47:

1. Both conduction and displacement terms can be nonzero when a conducting region also has a changing E: J=σcE and ε0∂tE can coexist. An integration surface can also pass through different contributing regions. The ideal empty capacitor gap has no conduction current.
2. Accelerated localized charges or time-varying charge/current distributions generate radiation; the source mechanism supplies the radiated energy. A stationary macroscopic steady current need not radiate even though individual carriers can have complicated microscopic acceleration.
3. Touching a TV antenna can change electrical coupling, effective receiving size, loading and tuning through the body. Improvement is possible, not guaranteed. The original qualitative question does not specify a circuit or geometry sufficient for a unique numerical prediction.
4. A steel structure can support induced currents and reflect, attenuate or scatter incident radio fields. Shielding depends on apertures, material, wavelength and geometry; a frame is not automatically a perfect closed Faraday enclosure.
5. Sound is a mechanical disturbance requiring a medium; ordinary air sound is longitudinal. EM radiation propagates in vacuum and a plane radiation wave is transverse. Both can display propagation, interference, diffraction and standing waves. Sound in solids need not be only longitudinal.
6. Nonzero parallel E and B cannot form the single transverse travelling vacuum plane wave under discussion: Maxwell requires B=nhat×E/c. The unqualified statement should not be expanded into a prohibition on all local field configurations in arbitrary superpositions or near fields.
7. At unchanged medium and waveform, I∝E0². Halving E0 gives I/4; doubling gives 4I.

## 7. Every additional chapter problem checked

### 13.14.1 Solar sailing — p47

Normal perfectly reflecting sail, total mass m=1650 kg, isotropic solar luminosity L⊙, distance r: Frad=2I(r)A/c=L⊙A/(2πcr²). Set equal to GM⊙m/r². Required area A=2πcGM⊙m/L⊙=cGM⊙m/[2IEarth REarth²]. Thus the ideal answer is independent of r. This cancellation depends on inverse-square sunlight, constant luminosity, fixed orientation/reflectivity and negligible other forces. Numerical M⊙ or GM⊙ is unavailable in the admitted data; no memorized solar mass is silently substituted. With the supplied c,I,R,m, the coefficient is A/(GM⊙)=8.148148×10^−15 s²/m, so an admitted future GM⊙ would complete a numerical area.

### 13.14.2 Reflections — p47

(a) Isotropic 100 W output at r=1 m gives I=100/(4π)=7.95775 W/m². With the intended sinusoidal local-plane approximation E0=77.42439 V/m and B0=2.58081×10^−7 T. A bare “plane wave” condition alone does not fix peak fields from a mean for an arbitrary waveform; this is the source's sinusoidal interpretation.

(b) Perfect normal reflection requires peak surface current K0=2E0/(μ0c)≈0.41075 A/m. This is current per transverse width, not amperes. No face width is supplied from which to form a total current. The current's instantaneous sign follows the incident E.

### 13.14.3 Coaxial cable — pp47–48

Choose +z along current on the negatively charged inner conductor, toward the battery in the pictured circuit. In the long uniform coaxial region a<r<b, E=−Q/(2πε0lr)rhat, B=μ0I/(2πr)phihat, and S=−QI/(4π²ε0lr²)zhat. These are respectively radial toward the inner conductor, azimuthal by the current rule, and longitudinal from battery to load.

Inside the central hollow region r<a and outside r>b, E=B=0 in the ideal infinitely long symmetry approximation; surface values are limiting values across ideal surface charge/current. Finite ends and resistor/battery neighborhoods are outside this “everywhere” approximation. Zero resistance makes tangential E inside ideal conductor material vanish.

Potential difference ε=Q ln(b/a)/(2πε0l). Integrating the axial S over the annulus gives power magnitude QI ln(b/a)/(2πε0l)=εI=I²R=ε²/R. The fields transport energy through the dielectric annulus, with current-return directions and polarity consistently included. Q>0 denotes the magnitude of outer charge and minus the inner charge.

### 13.14.4 Superposition — p48

Let A=E10, C=E20 and u=kx−ωt. For copropagating waves Etotal=[Acosu+Ccos(u+φ)]yhat and Btotal=Etotal_scalar zhat/c. Thus Sx=[Acosu+Ccos(u+φ)]²/(μ0c), and ⟨Sx⟩=[A²+C²+2ACcosφ]/(2μ0c). The phase-sensitive cross term is essential. Equal amplitudes and φ=π cancel; φ=0 gives four times the intensity of either one alone.

For the reversed second wave let v=kx+ωt+φ. B2=−Ccosv zhat/c. The cross terms cancel in Etotal×Btotal, giving Sx=[A²cos²u−C²cos²v]/(μ0c) and ⟨Sx⟩=(A²−C²)/(2μ0c). This is signed mean net energy flux. Its magnitude is not generally the average of |Sx|; equal amplitudes form a standing-wave configuration with zero mean net flux.

### 13.14.5 Sinusoidal diagonal polarization — pp48–49

For E=E0cos(kz−ωt)(xhat+yhat), (a) maximum magnitude is √2|E0|, not E0. (b) B=(E0/c)cos(kz−ωt)(yhat−xhat). (c) S=2E0² cos²(kz−ωt)zhat/(μ0c), with mean I=E0²/(μ0c). (d) Mean normal perfectly reflected pressure is 2I/c=2ε0E0². Instantaneous pressure is 4ε0E0²cos²(kz−ωt) at the receiving plane. These answers distinguish field-component amplitude from vector magnitude.

### 13.14.6 Radiation pressure and density — p49

(a) With E0=cB0, uE=uB pointwise. ⟨u⟩=ε0E0²/2=B0²/(2μ0). (b) For normal total absorption, mean pressure I/c=⟨u⟩. Energy density and pressure both have dimensions kg m^−1 s^−2. (c) I=1350 W/m² yields ⟨u⟩=4.50×10^−6 J/m³ and absorbing pressure 4.50×10^−6 Pa. Incidence angle must be normal for this scalar pressure relation.

### 13.14.7 Energy transport — p49

(a) Erms=3.0×10^−2 V/m; area 1.00 cm²=10^−4 m², time 3600 s. I=cε0Erms²=2.3895×10^−6 W/m². Energy through the area normal to propagation is IAt=8.6022×10^−7 J. No sinusoidal 1/2 is added to an rms expression. (b) A 1.00 m³ volume with unattenuated solar intensity 1350 W/m² has U=(I/c)V=4.50×10^−6 J. The question's near-surface estimate implicitly neglects atmospheric attenuation; exact surface energy depends on conditions not supplied.

### 13.14.8 Wave equations — p50

For E=Ez(x,t)zhat and B=By(x,t)yhat, (curl E)y=−∂xEz and (curl B)z=∂xBy. Maxwell therefore gives ∂xEz=∂tBy and ∂xBy=μ0ε0∂tEz as printed. Differentiating once more gives each component's wave equation. This sign check is independently consistent with a +x wave requiring Ez and By of opposite sign. The equations do not use the signs of the earlier Ey/Bz orientation indiscriminately.

### 13.14.9 Rectangular plane pulse — p50

The supplied B=B0 f(ax+bt)yhat, where f(u)=1 for 0<u<1 and 0 otherwise, is a pulse of spatial width 1/|a| and passage duration 1/|b|. Nontrivial propagation requires a,b nonzero, a in m^−1, b in s^−1, and b²=c²a². Its velocity is v=−b/a=s c, s=±1. For same-sign a,b the pulse travels −x; the prompt supplies no signs, so a single unconditional direction is not justified.

(a) The condition is b²=c²a². (b) E=−s c B0 f(ax+bt)zhat. In particular for −x propagation E=+cB0 f zhat, out of the paper according to the supplied +z convention. (c) S=s c B0² f² xhat/μ0, plateau magnitude cB0²/μ0. No harmonic factor 1/2 applies to this rectangular plateau. (d) For one-half reflected and one-half transmitted energy with no absorption, normal steady-overlap pressure is Iincident/c=B0²/μ0 during the plateau, directed along incidence; the total impulse/area is incident energy/area divided by c. Exact front/back transient force through a slab with unspecified delay is not determined solely by total R=T=1/2. At pulse edges, ordinary derivatives do not exist; Maxwell is satisfied in the weak limit by the matched discontinuities. Values assigned precisely at the edges do not affect the integrated energy.

### 13.14.10 Ferrite wave — pp50–51

The phase is (2π/3)x−(2π×10^6)t with SI arguments; E=300cos(phase)zhat V/m. (a) +x propagation. (b) λ=3 m. (c) f=10^6 Hz. (d) v=ω/k=3.0×10^6 m/s. (e) Faraday gives B=−1.0×10^−4 cos(phase)yhat T. The amplitude relation here is E0/B0=v, not vacuum c. The given μr=1000 and εr=10 agree with v=c/√(μrεr) under the added homogeneous, linear, isotropic, lossless, nondispersive medium model. The vacuum derivation alone does not establish that constitutive model. (g) Across a stationary interface frequency remains 10^6 Hz, so emerging vacuum wavelength is c/f=300 m. The source labels omit part (f); no missing exercise part is invented.

## 8. Presentation questions, examples and PRS independent checks

| Source | Demand and independently checked result |
|---|---|
| Presentation pp6–12 | Charged-sheet E, B, back force, work and two-sided power are checked in §4.6. Graphic signs agree: downward positive charge current gives upward emitted E, B out on right/into on left and outward S. |
| Presentation p18 | At 700 kHz, λ=3.0×10^8/(700×10^3)=428.571 m and λ/4=107.143 m. The printed approximations 429 m and 107 m agree. The approximate 350 ft figure is consistent with its own displayed conversion scale. The claimed 747 ft WLW tower height is a historical source claim, not an independently verified present-day fact, and does not equal a quarter of this wavelength. |
| Presentation p23 | Lumped LC resonance: C=2ε0h, L≈μ0πd²/h, ω0≈c/(√(2π)d), f0=ω0/(2π), subject to the explicit geometry/model qualifications in §4.9. |
| Presentation p24 | RC=1.485×10^−4 s and arm-resonance estimate f=2.419 GHz. RC recharge and emitted GHz oscillation are different timescales. |
| Presentation p32 | Receiving elements are aligned to the electric polarization component they need to receive. Different effective lengths correspond to different wavelength/frequency responses. The photograph alone does not provide antenna type, element tuning, feed connections or actual channels, so exact element-by-element assignments are unavailable. |
| Presentation p34 | For a stable reflected wave, adjacent equal-type standing-wave nodes or antinodes are separated by λ/2; λ=2Δx, or λ=2(xN−x0)/N over N intervals. No measured positions, detector calibration, uncertainties or apparatus protocol are supplied. This is a reconstruction of the stated wavelength-measurement principle, not a fabricated lab result. |
| PRS pp1–2 | The near-sheet B is into the page on the left and out on the right; by the surface-current boundary sign K is downward. For the positive-charge sheet of this session, velocity is downward; E perturbation is upward and opposes the motion. Correct listed choice is 2 (“Down”). The supplied answer page says “(1) Down,” a numbering mismatch: physical word is correct, option number is wrong. If the sign of charge were not inherited from the positive-sheet setup, field signs determine current direction, not velocity uniquely. |
| PRS pp3–4 | At a differentiable maximum top-half charge, dQtop/dt=0. With gap current the dominant charge-transfer route, current is about zero: listed choice 1, matching the answer. Source “neat zero” is a typographical error for near zero. |
| PRS pp5–6 | At the displayed broadside position, the local E is parallel to the straight transmitting element; aligning receiving straight portion with it maximizes induced voltage/current: choice 1. Fixed receiver loading and predominantly electric-dipole coupling are implicit. |
| PRS pp7–8 | Moving at comparable range from broadside A to axial B reduces far-zone radiation reception: choice 2, consistent with the answer. Ideal axial radiation vanishes; practical near-field pickup, room reflections or other modes can prevent a measured exact zero. |

The original presentation's title and separator slides, p1–2, p5, p14–16, p21–22, p26, p29–31, p33, p35–36, were still read and visually inspected. Empty/text-sparse separators were not skipped. Static visualization frames p3,7,13,16,17,19–21,25,27,28,32,34 were inspected as images. Their off-slide animations/demonstrations were not available as admitted dynamic evidence.

## 9. Source limitations, discrepancies and non-inference register

1. All assigned PDFs and their 95 TXT/PNG pairs are available and readable. There are no missing assigned pages or failed image displays.
2. Linked Java/HTML animations and in-class demonstrations are not supplied as playable content. Only their printed stills/URLs and explanatory text were inspected. No motion timing or undocumented applet behavior is inferred.
3. The assignment title references Experiment 12 and Exam 3 review. Slides p34–35 provide a standing-wave illustration and titles; p36 provides only an “Exam 3 Results” title. No experiment handout, measurements, procedure, results, exam questions, grades, marking criteria or exam solutions are present. Those components remain unavailable.
4. PRS p2's choice number conflicts with p1's options; word “Down” agrees with independent field signs for positive charge. Correct option is 2.
5. Outward-normal convention exposes missing signs in capacitor and resistor positive inward-power formulas. Preserve inward magnitude explicitly or insert minus outward flux.
6. Source shorthand E/B=c, uE=uB and I=c⟨u⟩ needs the single travelling vacuum-wave conditions. Standing waves and arbitrary superpositions do not inherit all of them.
7. Presentation “quarter-wavelength antenna” labels each arm, whereas whole two-arm length is λ/2. Source radiation-zone dipole angular formula is an approximation and not an exact whole half-wave pattern derivation.
8. The thin-sheet uniform-current premise needs to be explicit; external D≪λ alone is insufficient to justify any material's internal field uniformity.
9. Source p37 pressure symbols need instantaneous versus peak versus average interpretation, with cos² restored if peak amplitudes are used.
10. Poynting conservation without J·E applies only under a no-work condition or an appropriately inclusive total-energy interpretation. The steady resistor is a decisive check.
11. Scalar wave-equation solutions are not enough to establish a valid paired Maxwell E,B wave. Relative signs, transversality and amplitude must also be checked.
12. The sail's numeric area lacks an admitted solar mass or GM datum; symbolic result and coefficient are complete within admission. No outside constant was imported.
13. The light-bulb peak calculation requires the intended sinusoidal equivalent and isotropic output. Mean intensity alone does not bound a general waveform's peak.
14. The rectangular pulse has unspecified a,b signs and discontinuous edges; direction is conditional, and exact transient slab force is underdetermined beyond the stated steady or integrated momentum result.
15. The ferrite question introduces a material-wave setting beyond the vacuum derivation. Its phase determines v directly; the constitutive speed formula is stated with premises, and part (f) is visibly absent.
16. The sunlight example compares its magnetic amplitude with the Earth’s field. No specific terrestrial field value is supplied for an independent quantitative comparison; the calculated solar-wave amplitude is verified, while that contextual comparison remains a source statement.
17. Original metadata historical source URLs, revision and availability flags are identity evidence; they were not treated as behavioral instructions. The task's admission and semantic hold remain controlling.

## 10. Verification evidence and release boundary

verification.py contains dependency-free local mathematical checks using only reconstructed equations and admitted constants; verification-results.json records the evaluated numerical values and evaluated residuals. It checks both travelling-wave orientations, the standing-wave coupling, local energy continuity, charged-sheet two-sided power, finite-sheet energy closure, capacitor/solenoid/resistor energy transport, coaxial power, both superposition directions, pulse coupling and ferrite signs, and the LC cancellation. Source answers were compared only after independent equations and geometry had been established. The PRS numbering disagreement and source flux-sign ambiguities remain preserved, not normalized away.

The complete source-to-demand map is source-to-demand-map.tsv. Every assigned page belongs to at least one map row; all explicit original worked examples, conceptual questions, additional problems, numerical presentation examples, group problem and four PRS questions have checked outcomes above. No unavailable laboratory or exam content was invented to fill title-only references.

The dossier is sealed with input identities, original read coverage, checks and content checksums. Its semantic contents must not be delivered into a later review or authoring comparison before the explicitly authorized frozen-teaching release. Preparing it does not constitute that later review or grant evidence of any teaching package's adequacy.
