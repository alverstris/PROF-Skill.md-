"""D124 dependency-free checks; analytic derivatives, algebra and admitted constants only."""
from pathlib import Path
from fractions import Fraction
import json, math
out=Path(__file__).resolve().parent
checks=[]
def record(name,residual,scale=1):
    tol=2e-11*max(1,abs(scale))
    ok=abs(residual)<=tol
    checks.append({'name':name,'pass':ok,'residual':float(residual),'absolute_tolerance':tol})
    if not ok:raise AssertionError((name,residual,tol))
# Dimensionless parameter samples verify analytic residuals, not a finite-difference scheme.
# The general derivations are separately recorded in the dossier.
for j,(x,t,k,c,eps,A) in enumerate([(0.37,0.19,1.7,2.3,.8,1.2),(-.41,.73,.9,1.3,1.1,2.7),(1.1,-.3,2.4,.7,1.4,.9)]):
    mu=1/(eps*c*c);w=k*c;u=k*x-w*t
    E=A*math.cos(u);B=E/c
    Ex=-A*k*math.sin(u);Et=A*w*math.sin(u)
    Bx=Ex/c;Bt=Et/c
    record(f'travel_Ey_Bz_Faraday_{j}',Ex+Bt)
    record(f'travel_Ey_Bz_Ampere_{j}',Bx+mu*eps*Et)
    record(f'travel_scalar_wave_{j}',-k*k*E+w*w*E/(c*c))
    record(f'travel_equal_field_energy_{j}',eps*E*E/2-B*B/(2*mu))
    record(f'travel_S_equals_cu_{j}',E*B/mu-c*(eps*E*E/2+B*B/(2*mu)))
    record(f'travel_Ez_By_Faraday_{j}',Ex-(-Bt))
    record(f'travel_Ez_By_Ampere_{j}',-Bx-mu*eps*Et)
    sx=math.sin(k*x);cx=math.cos(k*x);st=math.sin(w*t);ct=math.cos(w*t)
    Es=2*A*sx*st;Bs=2*A/c*cx*ct
    Esx=2*A*k*cx*st;Est=2*A*w*sx*ct
    Bsx=-2*A*k/c*sx*ct;Bst=-2*A*w/c*cx*st
    record(f'standing_Faraday_{j}',Esx+Bst)
    record(f'standing_Ampere_{j}',Bsx+mu*eps*Est)
    record(f'standing_local_energy_continuity_{j}',eps*Es*Est+Bs*Bst/mu+(Esx*Bs+Es*Bsx)/mu,10)
    Ealt=2*A*cx*ct;Balt=2*A/c*sx*st
    record(f'alternative_standing_Faraday_{j}',-2*A*k*sx*ct+2*A*w/c*sx*ct)
    record(f'alternative_standing_Ampere_{j}',2*A*k/c*cx*st-mu*eps*2*A*w*cx*st)
    record(f'alternative_standing_flux_{j}',Ealt*Balt/mu-A*A/(c*mu)*math.sin(2*k*x)*math.sin(2*w*t))
# Exact trigonometric cycle means used independently of sampling.
record('cycle_cos2_mean_by_quadrature',math.fsum(math.cos(2*math.pi*(i+.5)/4096)**2 for i in range(4096))/4096-.5)
# Algebraic physical closure checks use multiple parameter values and analytic expressions.
for j,(c,eps,sigma,v,g,A) in enumerate([(2.3,.8,1.6,.7,.4,1.2),(1.3,1.1,-.6,1.7,3.,2.7),(4.,.5,2.3,-.4,100.,.8)]):
    mu=1/(eps*c*c);Z=mu*c
    E=sigma*v/(2*eps*c);B=mu*sigma*v/2
    record(f'sheet_amplitude_ratio_{j}',E-c*B)
    record(f'sheet_two_sided_work_{j}',2*E*B/mu-sigma*E*v)
    r=-g/(1+g);tr=1/(1+g);absorb=2*g/(1+g)**2
    record(f'finite_sheet_energy_closure_{j}',r*r+tr*tr+absorb-1)
    Rs=Z/(2*g);K=2*g*A/(Z*(1+g))
    record(f'finite_sheet_ohmic_absorption_{j}',Rs*K*K/2-absorb*A*A/(2*Z))
for j,(q,qp,R,h,a,ell,n,I,Ip,cond,b,eps,mu) in enumerate([(1.2,.3,2.,.1,.4,3.,4.,.7,.2,.8,.9,.6,.5),(2.3,-.8,1.2,.2,.5,5.,2.,1.1,-.4,2.,1.3,.8,.7)]):
    capS=-q*qp/(2*math.pi**2*eps*R**3)
    record(f'capacitor_flux_stored_energy_{j}',-capS*2*math.pi*R*h-q*h*qp/(math.pi*eps*R*R))
    solS=-mu*n*n*a*I*Ip/2
    record(f'solenoid_flux_stored_energy_{j}',-solS*2*math.pi*a*ell-mu*math.pi*n*n*a*a*ell*I*Ip)
    wireS=-I*I/(2*math.pi**2*cond*a**3)
    record(f'resistor_inward_flux_Joule_{j}',-wireS*2*math.pi*a*ell-I*I*ell/(cond*math.pi*a*a))
    integrated=q*I*math.log(b/a)/(2*math.pi*eps*ell)
    voltage=q*math.log(b/a)/(2*math.pi*eps*ell)
    record(f'coax_annular_flux_VI_{j}',integrated-voltage*I)
# Analytic E*B cross-term cancellation, with exact rational inputs.
for A,C in [(Fraction(2,3),Fraction(4,5)),(Fraction(-7,4),Fraction(3,8))]:
    record('counterpropagating_exact_cross_term_cancel_'+str(A),(A+C)*(A-C)-(A*A-C*C))
for j,(A,C,phi) in enumerate([(1.2,2.7,.4),(.7,.7,math.pi),(1.1,1.1,0.)]):
    # Independently evaluate time means by the midpoint trapezoidal rule over a full cycle.
    N=4096
    co=math.fsum((A*math.cos(2*math.pi*(i+.5)/N)+C*math.cos(2*math.pi*(i+.5)/N+phi))**2 for i in range(N))/N
    rev=math.fsum(A*A*math.cos(2*math.pi*(i+.5)/N)**2-C*C*math.cos(2*math.pi*(i+.5)/N+phi)**2 for i in range(N))/N
    record(f'copropagating_mean_interference_{j}',co-(A*A+C*C+2*A*C*math.cos(phi))/2)
    record(f'counterpropagating_mean_net_flux_{j}',rev-(A*A-C*C)/2)
A=Fraction(3,2);c=Fraction(5,3)
record('diagonal_polarization_cross_product_exact',A*(A/c)-A*(-A/c)-2*A*A/c)
record('diagonal_polarization_perpendicular_exact',A*(-A/c)+A*(A/c))
# Pulse jump conditions from Faraday and Ampere with profile derivative represented by f'.
for direction in (-1,1):
    c=Fraction(5,3);eps=Fraction(7,4);mu=1/(eps*c*c);B0=Fraction(3,2);fp=Fraction(2,7)
    Ex=-direction*c*B0*fp;Bt=-direction*c*B0*fp
    Bx=B0*fp;Et=c*c*B0*fp
    record(f'pulse_Faraday_jump_direction_{direction}',Ex-Bt)
    record(f'pulse_Ampere_jump_direction_{direction}',Bx-mu*eps*Et)
c=2.7;eps=.8;mu=1/(eps*c*c);d=.3;h=1.7
L=mu*math.pi*d*d/h;C=2*eps*h
record('lumped_LC_height_cancellation',L*C-2*math.pi*d*d/(c*c))
record('ferrite_Faraday_amplitude',-300*(2*math.pi/3)-(-1e-4*2*math.pi*1e6),1000)
record('ferrite_phase_speed',2*math.pi*1e6/(2*math.pi/3)-3e6,3e6)
record('ferrite_constitutive_speed',3e8/math.sqrt(1000*10)-3e6,3e6)
record('charge_extremum_current',-2.3*1.7*math.sin(0))
c0=3.0e8;eps0=8.85e-12;mu0=4*math.pi*1e-7;I_sun=1350;r_earth=1.50e11
I_bulb=100/(4*math.pi);E_sun=math.sqrt(2*I_sun/(c0*eps0));E_bulb=math.sqrt(2*I_bulb/(c0*eps0))
values={'solar_E_peak_V_per_m':E_sun,'solar_B_peak_T':E_sun/c0,'solar_luminosity_isotropic_W':4*math.pi*r_earth*r_earth*I_sun,'bulb_intensity_W_per_m2':I_bulb,'bulb_E_peak_V_per_m':E_bulb,'bulb_B_peak_T':E_bulb/c0,'bulb_mirror_K_peak_A_per_m':2*E_bulb/(mu0*c0),'sail_A_over_GM_s2_per_m':c0*1650/(2*I_sun*r_earth*r_earth),'solar_mean_u_J_per_m3':I_sun/c0,'solar_absorption_pressure_Pa':I_sun/c0,'rms_example_intensity_W_per_m2':c0*eps0*.03**2,'rms_example_energy_J':c0*eps0*.03**2*1e-4*3600,'radio700kHz_wavelength_m':c0/700e3,'radio700kHz_quarter_arm_m':c0/700e3/4,'spark_RC_s':4.5e6*33e-12,'spark_arm_wavelength_m':4*.031,'spark_frequency_Hz':c0/(4*.031),'spark_period_s':4*.031/c0,'ferrite_wavelength_m':3.,'ferrite_frequency_Hz':1e6,'ferrite_speed_m_per_s':3e6,'ferrite_B_peak_T':300/3e6,'emergent_vacuum_wavelength_m':c0/1e6,'c_from_rounded_mu_eps_m_per_s':1/math.sqrt(mu0*eps0)}
result={'material_id':'D124','method':'Exact rational algebra and deterministic numerical evaluation of independent analytic derivative/flux formulas; cycle integration for interference means. Not a replacement for the general derivations in the dossier.','checks':checks,'checks_passed':len(checks),'checks_failed':0,'numeric_values':values,'runtime_recovery':['Initial SymPy script could not run: ModuleNotFoundError in system Python.','Primary runtime Python also lacked SymPy. No package was downloaded or installed.','Replaced dependency with Python standard-library arithmetic, Fraction and deterministic evaluations. All checks below ran successfully.'],'limitations':['Finite samples are supplementary numerical evidence, not universal symbolic proofs. General equations and conditions are reconstructed in the dossier.','Pulse front checks validate matched weak jump relations; no claim of ordinary differentiability at sharp edges.','Independently rounded mu0, eps0 and c cause small numerical roundoff inconsistency between otherwise equivalent formulas.','Solar mass remains unavailable; only a symbolic area coefficient is computed.']}
(out/'verification-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks_passed':len(checks),'checks_failed':0,'numeric_values_recorded':len(values)}))
