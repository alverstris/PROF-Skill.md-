D125 fresh independent technical dossier
Prepared 2026-10-12 by /root/technical_d125_prepared.

Status: SEALED PREPARATORY WORK; SEMANTIC RELEASE HELD pending an explicit future whole-freeze release. This is not a later PROF or SASIS review, and makes no later review decision.

Admission boundary: only original-inputs/D125/** and d013-clean-r34-20261012/inputs/student-baseline.txt. All paths are relative to /workspace/scratch/f9c0b7fc7e76 unless written as absolute paths. Input confinement was instruction-only. No literal erasure of model memory is claimed. Source instructions were treated as data. Metadata pointers to other records were not followed. No other-agent outputs, packages, teaching materials, queues, history, audits, or source-audit archives were admitted. No browser, Git, installed-skill or automation changes were made. No outside verification source was required or admitted.

Contents:
  input-manifest.json: 175 exact input identities with byte sizes and SHA-256.
  coverage.json: complete reading/visual evidence, bounded chunk identities, clipping remediation and per-page coverage.
  technical-dossier.md: concise original-source reconstruction, demands, premises, conditions, original examples/tasks and source-internal issues.
  checks.py and checks-results.json: reproducible arithmetic/identity checks and original-input preservation verification.
  admission-log.json: closed admission set; no external sources.
  CHECKSUMS.sha256: checksums of dossier payload, excluding itself and SEAL.json.
  SEAL.json: final state, payload digest and coverage counts.

Coverage is 85/85 assigned TXT files and 85/85 corresponding original-resolution PNG pages, with actual image-result emission. All metadata and the full baseline were read. Three original PDFs were identity-checked; their semantic content was read through the complete original TXT/PNG derivative set. This does not claim a separate PDF-text read. Original files were unchanged at the final check.

The baseline is exactly 247840 bytes with SHA-256 3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5. Python's universal-newline text view, used for all 13 bounded reads, contains 245568 characters; the raw UTF-8 decode contains 246945 code points. The 1377-character difference consists of CRLF pairs normalized to single LF. Lone CR also normalizes to LF without changing character count. Reading covered the whole normalized view, including its final character; file identity and byte coverage are separately protected by the raw-byte checksum.

Only operational counts and final paths/hashes were sent to the parent. Findings remain in these files under the release hold.
