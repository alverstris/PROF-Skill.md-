"""D125 checks from admitted originals and elementary algebra/calculus only.
No network access. Does not modify any input. Output is deterministic JSON.
"""
from pathlib import Path
import hashlib, json, math

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()

def bisect(f, a, b):
    fa = f(a)
    assert fa * f(b) < 0
    for _ in range(100):
        c = (a+b)/2
        if fa*f(c) <= 0:
            b = c
        else:
            a, fa = c, f(c)
    return (a+b)/2

def sinc(x):
    return 1.0 if x == 0 else math.sin(x)/x

def main():
    manifest = json.loads((OUT/'input-manifest.json').read_text())
    changes = [i['path'] for i in manifest
               if len((ROOT/i['path']).read_bytes()) != i['bytes']
               or sha((ROOT/i['path']).read_bytes()) != i['sha256']]
    meta = json.loads((ROOT/'original-inputs/D125/source-identity.json').read_text())
    discrepancies = []
    for asset in meta['assets']:
        for path, expected in [(asset['local_pdf'], asset['sha256'])] + [
            (p[k],p[h]) for p in asset['page_derivatives']
            for k,h in [('text_file','text_sha256'),('image_file','image_sha256')]]:
            if sha((ROOT/'original-inputs/D125'/path).read_bytes()) != expected:
                discrepancies.append(path)
    baseline = (ROOT/'d013-clean-r34-20261012/inputs/student-baseline.txt').read_bytes()
    assert len(baseline) == 247840
    assert sha(baseline) == '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
    assert not changes and not discrepancies
    pi = math.pi
    u1 = bisect(lambda u: math.sin(u)-u*math.cos(u), pi+1e-8,1.5*pi-1e-8)
    u2 = bisect(lambda u: math.sin(u)-u*math.cos(u),2*pi+1e-8,2.5*pi-1e-8)
    # Direct finite sum compared with the corrected closed form, including phase.
    finite_errors = []
    for N in [2,3,7,20]:
        for q in [.17,.5,1.1]:
            t=.37
            direct = sum(math.sin(t+j*q) for j in range(N))
            closed = math.sin(N*q/2)/math.sin(q/2)*math.sin(t+(N-1)*q/2)
            finite_errors.append(abs(direct-closed))
    # Unequal coherent fields averaged over an integer cycle.
    a,b,phase=2.,3.,.73
    avg = sum((a*math.sin(2*pi*j/20000)+b*math.sin(2*pi*j/20000+phase))**2
              for j in range(20000))/20000
    expected=(a*a+b*b+2*a*b*math.cos(phase))/2
    assert max(finite_errors) < 1e-12 and abs(avg-expected)<1e-11
    # Product-profile stationary positions; t=d sin(theta)/lambda, a/d=1/4.
    def product(t):
        return math.cos(pi*t)**2*sinc(pi*t/4)**2
    def amplitude_derivative(t):
        u=pi*t/4
        return (-pi*math.sin(pi*t)*sinc(u) + math.cos(pi*t)*(pi/4)*
                (u*math.cos(u)-math.sin(u))/(u*u))
    intervals=[(.5,1.5),(1.5,2.5),(2.5,3.5),(3.5,4.),(4.,4.5),(4.5,5.5)]
    extrema=[]
    for lo,hi in intervals:
        t=bisect(amplitude_derivative,lo+1e-7,hi-1e-7)
        extrema.append({'t':t,'theta_deg':math.degrees(math.asin(t/5.6)),
                        'I_over_I0':product(t)})
    data={
      'inputs':{'manifest_entries':len(manifest),'baseline_bytes':len(baseline),
                'baseline_raw_utf8_codepoints':len(baseline.decode()),
                'baseline_universal_newline_characters_read':len((ROOT/'d013-clean-r34-20261012/inputs/student-baseline.txt').read_text()),
                'baseline_sha256':sha(baseline),
                'changed_inputs':changes,'metadata_hash_discrepancies':discrepancies},
      'finite_sum_max_absolute_error':max(finite_errors),
      'unequal_field_mean_square_error':abs(avg-expected),
      'superposition_14_1':{'amplitude':math.sqrt(5+2*math.sqrt(2)),
          'phase_rad':math.atan2(math.sqrt(2),1+math.sqrt(2)),
          'first_positive_zero_rad':pi-math.atan2(math.sqrt(2),1+math.sqrt(2))},
      'example_14_1':{'delta_small_angle_m':.000150*.02/1.2,
          'delta_far_field_m':.000150*.02/math.hypot(1.2,.02),
          'delta_over_lambda_small_angle':.000150*.02/1.2/833e-9},
      'example_14_3':{'L_m':.0008*.001/600e-9,'central_width_m':.002},
      'problem_14_11_1':{'strict_order_bound':.00032*math.sin(pi/4)/500e-9,
                         'm_max':452,'bright_orders_count':905},
      'problem_14_11_2':{'a_phase_rad':2*pi*.0001*math.sin(math.radians(.8))/500e-9,
          'b_phase_rad_small_angle':2*pi*.0001*.004/500e-9,
          'c_theta_deg':math.degrees(math.asin((1/3)*500e-9/(2*pi*.0001))),
          'd_theta_deg':math.degrees(math.asin(500e-9/(4*.0001)))},
      'problem_14_11_4':{'phase_rad':2*math.acos(math.sqrt(.6)),
          'path_difference_m':500e-9*math.acos(math.sqrt(.6))/pi},
      'problem_14_11_5':{'midpoint_estimate_wavelength_m':.0008*.0016/(2.5*.8),
          'exact_sinc_root_small_angle_wavelength_m':pi*.0008*.0016/(u2*.8)},
      'problem_14_11_6':{'nominal_positive_orders':[
          {'m':m,'theta_deg':math.degrees(math.asin(m/5.6)),
           'I_over_I0':sinc(pi*m/4)**2} for m in range(6)],
          'positive_interior_product_maxima':extrema,
          'interior_product_maxima_total':2*len(extrema)+1,
          'note':'13 interior mathematical maxima of the admitted product profile; source counts 9 nominal nonmissing interference orders. Visibility threshold and grazing endpoints are not specified.'},
      'problem_14_13_1':{'fringe_spacing_m':500e-9*1.2/.01,'y3_m':3*500e-9*1.2/.01},
      'problem_14_13_2':{'ratio_d_over_a':.2/.01,'nominal_central_order_count':39},
      'problem_14_13_3':{'unit_minimum_spacing_m':450e-9*1.2/(3*.0001),
          'positive_minima_n':[1,2,4,5,7,8]},
      'problem_14_13_5':{'u_roots':[u1,u2],'beta_roots':[2*u1,2*u2],
          'midpoint_u':[1.5*pi,2.5*pi],'residuals':[math.tan(u1)-u1,math.tan(u2)-u2]},
      'presentation_23':{'given_microwave_lambda_m':.15,'given_red_lambda_m':6.54e-7,
          'wavelength_ratio_mw_over_red':.15/6.54e-7,
          'd_ratio_mw_over_optical':.24/.0001,
          'y_ratio_optical_over_mw_fixed_L':(6.54e-7/.0001)/(.15/.24),
          'y_ratio_using_claimed_lambda_factor_10000':(.24/.0001)/10000},
      'PRS_7_options_I_over_I0':{'1_half_path_lambda_over_4':sinc(pi/2)**2,
                                '2_half_path_lambda_over_2':sinc(pi)**2,
                                '3_half_path_lambda':sinc(2*pi)**2},
      'status':'PASS: arithmetic, corrected identities and input preservation checks; discrepancies are recorded source findings, not failed input checks.'
    }
    (OUT/'checks-results.json').write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'status':'PASS','input_files':len(manifest),'changed_inputs':changes,
                      'metadata_hash_discrepancies':discrepancies,'checks_results':'checks-results.json'}))

if __name__ == '__main__':
    main()
