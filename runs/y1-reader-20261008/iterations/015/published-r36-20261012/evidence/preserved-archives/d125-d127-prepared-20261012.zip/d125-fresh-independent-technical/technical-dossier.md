# D125 original-source technical reconstruction

Release held. This is concise technical evidence prepared from the complete admitted original set and full student baseline. It is not a teaching package or a later review. R denotes reading PDF page, P presentation page, and Q PRS page; physical PDF pages are used throughout. R printed page numbers are one less than PDF page numbers. Every page has both TXT and original-resolution PNG coverage in coverage.json.

## Identity and scope

The original metadata identifies MIT 8.02T, Spring 2005, class 33, `mit-8-02t-spring2005-S33`, D125: “Hour 1 Interference Hour 2 Experiment 13: Interference”. Source revision is `54ebb635d842f1d65c2508b8f921fd32819f5f0c`. The assigned reading is all Chapter 14, R1–35; the presentation is P1–38; PRS is Q1–12. The three PDF sizes/hashes and all 170 derivative identities are preserved in input-manifest.json and independently compared with source-identity.json. All match. URLs in original metadata are identity evidence, not newly fetched sources.

The material combines two-source interference, intensity and coherence, Huygens/Fraunhofer diffraction, single-slit intensity, finite-width double slits, multi-slit gratings, complex and phasor summation, solved problems, conceptual questions, additional problems, six PRS question/answer pairs, and four outline-level laboratory tasks. It contains demonstration and applet/video pointers, but no linked media or experiment spreadsheet is admitted. It contains no recorded measurements for the laboratory tasks.

## Shared notation and usable conditions

Use SI consistently: λ, a, d, L, y and path differences have units of length; k=2π/λ has units rad m⁻¹; φ and β are phases in radians; m and N are integers; f is Hz and ω=2πf is rad s⁻¹. Source a is slit width, d slit-center separation, L normal screen distance, y signed transverse screen position, and θ angle from the central normal. Baseline Young notation uses a for separation, so symbols must be mapped by meaning, not copied mechanically.

All scalar field-sum/intensity formulas require the corresponding fields to overlap and have the common polarization represented by the scalar model. Equal-amplitude formulas further require equal illumination/contributions. Complete cancellation needs equal amplitudes as well as opposite phase. Initial relative source phase is zero in the usual bright/dark path formulas; otherwise it adds to the propagation phase. The detector measures a time-averaged squared field, not a snapshot displacement. Incoherence eliminates the time-averaged cross term; a coherent pair can also have a zero cross term at a particular phase, so a nonzero cross term is not a universal definition of coherence.

Far-field path difference δ≈d sinθ requires approximately parallel outgoing rays, supplied in the source as L≫d. Replacing sinθ by y/L additionally needs |y|≪L or |θ|≪1 rad. The inequality d≫λ alone does not justify small angles at arbitrarily high order. On a flat screen y=L tanθ; if sinθ=s is already known and |s|<1, then y=Ls/√(1−s²). An order exists only when its sine argument lies in [−1,1]; a finite flat screen cannot contain θ=±90°. Strict versus inclusive angle ranges must be respected when counting integers.

Single-slit and finite-width formulas assume uniform illumination and Fraunhofer propagation as modeled in R13–22. Exact electromagnetic near-field/aperture corrections are not supplied. The single-slit expression at β=0 is defined by its continuous limit, not by evaluating 0/0. A central-envelope boundary is a zero, excluded when counting nominal bright orders inside that envelope. “Bright fringe/order” in several worked examples is an approximate interference-order convention; actual local maxima of a product with a varying envelope need not occur at those order positions.

## Core reconstruction and source-local evidence

| Original locus | Result independently reconstructed | Demand and conditions |
|---|---|---|
| R2–4, §14.1; P6,8,10–13,17 | Add displacement/field components before interpreting the result. For ψ₁=sin x and ψ₂=2sin(x+π/4), ψ=(1+√2)sin x+√2 cos x=√(5+2√2)sin(x+φ), φ=atan2(√2,1+√2)=0.529903 rad. | Trig addition, phase quadrant, interpretation of snapshot versus persistent interference. Amplitude 2.797933; first positive zero x=π−φ=2.611690. An instantaneous zero is not by itself zero time-averaged intensity. |
| R4–7, §14.2; P20–21,25; Q3–4 | δ=r₂−r₁≈d sinθ; bright δ=mλ; dark δ=(m+1/2)λ. Small-angle positions y_b=mλL/d and y_d=(m+1/2)λL/d, m∈ℤ. | Recover right-triangle projection, distinguish separation from screen distance, maintain sign conventions and approximation conditions. R6 Fig.14.2.4 caption reverses δ relative to surrounding text. |
| R8–10, §14.3 | I∝〈\|E₁+E₂\|²〉. Equal coherent scalar fields yield E=2E₀cos(φ/2)sin(ωt+φ/2), I/I₀=cos²(φ/2), φ=2πδ/λ, I₀=4I_single. Incoherent average gives I₁+I₂. | Squaring, trig identity, average over a cycle, intensity normalization. Distinguish one-slit I_single from central two-slit I₀. |
| R11–12, Example14.2 | Three equally spaced equal-amplitude slits: E=E₀(1+2cosφ)sin(ωt+φ), I/I_primary=(1+2cosφ)²/9. | Add three phases and classify extrema. Primary maxima φ=2πm; secondary φ=(2m+1)π; zeros cosφ=−1/2. Secondary/primary=1/9; primary/secondary=9. The original problem wording and reported ratio orientation differ. |
| R13, §14.4 | Huygens construction: unobstructed wavefront points supply secondary waves, and the new front is their tangent envelope. Fraunhofer observation uses parallel rays/far field or a lens focal plane. | New physical model explicitly supplied by reading; qualitative wavefront/geometry interpretation. No general wave-equation or Fourier theory is required. |
| R14–15, §14.5; P29–31; Q7–8 | Pair contributions separated a/2: first zero when (a/2)sinθ=λ/2. General single-slit zeros a sinθ=mλ, m≠0. | Continuum of equal contributions, cancellation, integer orders, exclusion of m=0. A two-half argument alone gives odd orders; even orders need finer subdivision or the intensity formula. |
| R16–18, §14.6 | For N zones, Δy=a/N, q=Δβ=2πΔy sinθ/λ, β=Nq. Exact sum Σ(j=0..N−1)sin(ωt+jq)=sin(Nq/2)/sin(q/2) · sin[ωt+(N−1)q/2]. Taking N→∞ at fixed β gives I/I₀=[sin(β/2)/(β/2)]². | Finite trig sum or complex geometric sum, correct indexing, normalized limiting process, sin h/h→1. The phase between first and last zone centers is (N−1)q, while phase across the full slit width is Nq. |
| R19–20, §14.7; P34–35; Q9–12 | Two finite equal slits: I/I₀=cos²(πd sinθ/λ)[sin(πa sinθ/λ)/(πa sinθ/λ)]². The wide envelope scale is λ/a, fine fringe scale λ/d. | Multiplication of aperture and interference amplitudes then squaring; separate zero sets. Missing nominal order when m=(d/a)n is integer for nonzero diffraction order n. For d/a=M integer, nominal orders strictly inside central envelope are −(M−1)..M−1, count 2M−1. |
| R20–22, §14.8 | N narrow equally spaced equal coherent slits have principal maxima d sinθ=mλ. Normalized factor [sin(Nφ/2)/(N sin(φ/2))]², φ=2πd sinθ/λ, tends to 1 at principal maxima. | Same finite sum with d as slit spacing. More slits narrow peaks; near a principal maximum the neighboring zeros are separated in sinθ by λ/(Nd). Peak comparison depends on whether per-slit or total illumination is fixed. |
| R23–26, §14.10 | Euler/complex sum and planar phasor constructions provide equivalent representations of the finite sum. q_c=e^{iΔβ}; Σ(j=0..N−1)q_c^j=(1−q_c^N)/(1−q_c), q_c≠1; at q_c=1 the sum is N. | Use existing complex arithmetic and Euler relation; finite sum does not require \|q_c\|<1. Phasor length is amplitude and its rotating projection is instantaneous field. Arc approximations require the continuum limit. |

## Original numerical and symbolic tasks

All numbers below were reconstructed from the original supplied values; machine-check details are in checks-results.json. Where the source gives rounded or approximate answers, the approximation is identified.

| Task and locus | Given information and independently checked outcome | Required operations / necessary qualification |
|---|---|---|
| Example14.1, R7–8 | d=0.150 mm, L=120 cm, λ=833 nm, y=2.00 cm. δ≈dy/L=2.50 μm≈3.0012λ, hence approximately the third bright order at input precision. | Convert all lengths; use small angle. The far-field value without tan≈sin is 2.49965 μm. The rounded data do not give exact integer equality. |
| Example14.2, R11–12 | Three-slit intensity and extrema as above. | Symbolic trig addition, square/time average, solve 1+2cosφ=0 and classify extrema; distinguish inverse ratios. |
| Example14.3, R15–16 | λ=600 nm, a=0.800 mm, first zero y=1.00 mm: L≈ay/λ=1.33 m; central maximum width 2y=2.00 mm. | First zero rather than a bright side maximum; symmetric pair of zeroes. |
| 14.11.1, R26–27 | d=0.320 mm, λ=500 nm, −45°<θ<45°. \|m\|<452.54834, so m=−452..452; 905 bright orders. | Strict angular inequality, inverse sine domain and count both sides plus center. |
| 14.11.2(a), R27–28 | d=0.100 mm, L=1.00 m, λ=500 nm; θ=0.800° gives φ=17.5454 rad≈17.5 rad. | Degrees for sin, radians for phase. Phase can also be reduced modulo 2π if the convention is stated. |
| 14.11.2(b), R27–28 | y=4.00 mm gives φ≈5.02655 rad. | δ≈dy/L and φ=2πδ/λ. |
| 14.11.2(c), R27–28 | φ=1/3 rad gives θ=asin[φλ/(2πd)]=0.0151982°. | Invert phase-to-path and geometry; phase not one-third cycle. |
| 14.11.2(d), R27–28 | δ=λ/4 gives θ=asin[λ/(4d)]=0.0716197°. | Path fraction and angle conversion. |
| 14.11.3, R28–29 | Incident angle θ₁ and outgoing angle θ₂, with directions defined by the drawn rays: d(sinθ₁−sinθ₂)=mλ for constructive interference. | Account for incident as well as outgoing phase. Reversing δ changes m's sign, not the set of bright directions. For θ₁=0 recover ordinary maxima. |
| 14.11.4, R29 | I=0.60I₀: least nonnegative phase φ=2acos√0.60=1.369438 rad=78.46°; for λ=500 nm, δ=108.976 nm≈109 nm. | Inverse trig has periodic/sign branches. “Minimum phase” must mean magnitude or least nonnegative phase; signed phase has no global minimum over all equivalent branches. |
| 14.11.5, R30 | a=0.800 mm, L=0.800 m, second side bright maximum at y=1.60 mm. Source midpoint estimate gives λ≈640 nm. | The second side maximum is only approximately midway between the second and third zeroes. Solving tan u=u gives u₂=7.725252 and λ≈650.665 nm in the same small-angle geometry. This exact correction follows from 14.13.5. |
| 14.11.6(a), R30–32 | λ=500 nm, a=0.700 μm, d=2.80 μm, semicylindrical screen: nominal interference m=−5..5 because \|m\|≤5.6. Angles for m=0..5: 0°,10.2866°,20.9248°,32.3924°,45.5847°,63.2345°. m=±4 coincide with envelope zeroes; source reports nine nonmissing nominal orders. | Use sinθ exactly, not y/L. Finite-width product peaks are displaced from these nominal angles. Mathematical local maxima and visible nominal fringes are distinct. |
| 14.11.6(b), R31–32 | At surviving nominal m=0,±1,±2,±3,±5, I/I₀=1,0.810569,0.405285,0.0900633,0.0324228 respectively. | Evaluate sinc envelope at nominal interference maxima; values are not the exact local peak intensities. |
| 14.13.1, R33 | d=1.00 cm, L=1.20 m, λ=500 nm: adjacent bright spacing 60.0 μm=0.0600 mm; third bright distance 180 μm=0.180 mm. | Use integer order, small-angle spacing, unit conversion. |
| 14.13.2, R33 | a=0.010 mm, d=0.20 mm, λ=600 nm: d/a=20; source order-count convention gives 39 nominal central-envelope bright orders. | Exclude missing boundary orders m=±20; this is an order count, not an exact count of all tiny local maxima of the product. |
| 14.13.3(a), R34 | Three-slit minima: y≈nλL/(3d), n∈ℤ not divisible by 3. | From cosφ=−1/2; positive sequence n=1,2,4,5,7,8,… plus reflected negative positions. L≫d alone does not ensure small angle at every n. |
| 14.13.3(b), R34 | L=1.20 m, λ=450 nm, d=0.100 mm: unit λL/(3d)=1.80 mm. Successive positive-minimum gaps alternate 1.80 and 3.60 mm; central gap is 3.60 mm. | The minima are not uniformly spaced; distinguish nearest-neighbor gaps from the base unit. |
| 14.13.4, R34 | E₁=E₁₀sinωt, E₂=E₂₀sin(ωt+φ): I=I₁+I₂+2√(I₁I₂)cosφ. Thus I_max/min=(√I₁±√I₂)². | Same polarization, common frequency, stable phase and positive amplitudes. Derive the cross average; no zero minimum unless amplitudes match. |
| 14.13.5(a–c), R34–35 | f(u)=(sin u/u)², u=β/2. f′=2sin u(u cos u−sin u)/u³ away from zero. Secondary maxima satisfy tan u=u, u≠0; first two positive roots 4.49340946 and 7.72525184, β=8.98681892 and 15.45050367. | Differentiation, stationary classification, removable limit at 0, numerical/graph root finding. Roots lie below approximate numerator maxima 3π/2 and 5π/2. sin u=0 gives minima, not the requested maxima. |
| 14.13.6, R35 | Seven observed central bright fringes: conventional answer d/a=4 assumes the fourth interference order is the missing boundary order. If only seven nominal integer-order maxima are specified, the full condition is 3<d/a≤4. | A count without a stated commensurate/missing-order condition does not uniquely fix a ratio. Actual product-peak counting or a visibility threshold is a different measurement convention. |

## Reading conceptual questions, R33

1. With other quantities fixed, increasing separation d decreases fringe spacing; decreasing λ decreases spacing; increasing L increases spacing. State the small-angle geometry behind Δy=λL/d.
2. A shared white-light source can give a white central fringe and colored neighboring fringes, with longer wavelengths farther from the center for a fixed order; overlap can wash out distant contrast. This is inconsistent with reading monochromaticity as a necessary condition for any interference whatsoever. Coherence is required over the relevant path/time interval; a sum of wavelength components need not be a single monochromatic wave.
3. Two ordinary car headlights do not maintain a fixed relative optical phase, so their time-averaged cross term does not give a stationary observable fringe system in the simple setup. Coherent intensity addition must not be transferred to independently phased lamps.
4. Increasing single-slit width a narrows the central diffraction maximum; y_first≈λL/a.
5. Decreasing a broadens the pattern. If a<λ there is no nonzero minimum satisfying |sinθ|≤1. Absolute brightness cannot be inferred from a normalized I/I₀ plot without specifying whether incident irradiance, transmitted power or I₀ is fixed.
6. Coherent contributions require addition of fields before squaring and averaging; adding their separate intensities drops the cross term.

## Presentation-only work and experimental demands

P1 gives the class/lab outline. P2 converts microwave f=2×10⁹ Hz into λ=15 cm and red f≈4.6×10¹⁴ Hz into λ≈6.54×10⁻⁵ cm (the frequency is rounded). P3–5 contrasts wave spreading/superposition with the classical bullet illustration and displays an applet snapshot. P7,9,18–19,24,27,28,32,36 are demonstration, image or transition pages; they add no numerical observations. P11,26,33 point to PRS questions. These pages were still fully read and visually checked.

P14–16 shows iridescence examples and a film of thickness d, a reflected top ray and a ray traversing the film and returning. It asserts extra path≈2d and constructive 2d=mλ / destructive 2d=(m+1/2)λ. As a path-only illustration this needs near-normal geometry, λ interpreted in the film, and zero net additional phase difference at the boundaries. No refractive indices or boundary phase rule are supplied. From supplied phase addition alone, the conditional expression is φ_total=2π(2d/λ_film)+ρ at normal incidence, with unknown relative boundary phase ρ. For ρ=0 its displayed conditions hold; for ρ=π their constructive/destructive roles swap. This dossier does not admit an outside reflection-phase law or determine ρ for the unnamed materials. A quantitative prediction for bubbles/coatings requires those missing material and boundary premises; P16 is not a universally specified coating calculation.

P22 asks the class to estimate microwave λ and f using L≈1.16 m, d≈0.24 m and the measured first minimum y. The y value is explicitly “? m”. Therefore the reproducible answer is λ≈2dy/L and f=c/λ, conditional on a measurement; no numerical measured answer can be recovered from the originals. Also L/d≈4.83, so the accuracy of far-field and small-angle approximations deserves an explicit check if measured data are later supplied.

P23 argues that replacing microwaves with light keeps the fringes measurable by decreasing d to 0.1 mm. That qualitative conclusion is supported, but the slide's numerical scaling is inconsistent: from P2, 0.15 m / 6.54×10⁻⁷ m≈229358, while d shrinks by 2400. At fixed L, optical y/microwave y≈0.010464, or about 95.6 times smaller. Even using the slide's asserted wavelength factor 10000 gives 0.24, about 4.17 times smaller, not its stated factor 10. Do not import a different screen distance to repair an unstated calculation.

P37 supplies Babinet's principle through a slit and its complementary filling and claims opposite fields/equal intensities. For a usable scalar far-field reconstruction, complementary transmitted-aperture fields add to the unobstructed field. Away from the direct beam that field vanishes in the ideal model, leaving E_obstacle=−E_slit and equal diffracted intensities. The direct-beam exception and ideal complementarity are necessary; the source's “fill up slit, get nothing” language by itself does not justify cancellation of all total fields at all screen locations. This is an explicitly supplied new physical model, not prior baseline knowledge.

P38 supplies four lab goals, without the external spreadsheet, measured zero positions, numeric slit widths/spacings, screen distances or CD incidence geometry:

| Lab task | Reconstructable model and needed observations | Demand |
|---|---|---|
| Four single slits | For known a and signed zero order m≠0, λ=a sinθ/m≈a\|y_m\|/(\|m\|L). Need a, L, center and zero coordinates for each slit. | Identify diffraction minima; measure symmetric positions or multiple spacings; combine four estimates and assess uncertainty. |
| Human hair | Under the supplied Babinet idealization, hair width h=\|m\|λ/sin\|θ_m\|≈\|m\|λL/\|y_m\|, using λ from the first task. | Transfer the aperture-width parameter to an obstacle; identify order and propagated measurement uncertainty. |
| Four double slits | For known d and interference-zero order m≥0 on one side, λ=d sinθ/(m+1/2)≈d\|y_m\|/[(m+1/2)L]. | Distinguish fine interference zeroes from envelope zeroes; use center/order correctly; compare wavelength estimates. |
| CD track spacing | At stated normal incidence, d=mλ/sinθ for diffracted order m. Actual reflective geometry requires specified incident/output angles and sign convention before using a generalized path difference. | Treat CD tracks as a grating, measure angles, select an accessible order, infer length units. No CD spacing can be numerically inferred from these originals alone. |

The source's instructions to download media/spreadsheet or perform an experiment are descriptions of student tasks. They were not executed as agent instructions, and absent data were not invented.

## PRS tasks reconstructed from both text and figures

| Pages | Original demand and independent result | Figure/answer qualification |
|---|---|---|
| Q1–2 | Classify interference at P for two illustrated coherent waves: minimum, choice 2. | The displayed opposite phases and the answer both establish phase difference π. Zero intensity further needs equal scalar amplitudes; “minimum” remains the correct relative-phase classification. |
| Q3–4 | Select approximate path difference for two slits: d sinθ, choice 1. | Yellow triangle projects d onto the propagation direction. Far-field rays are treated as parallel. |
| Q5–6 | Same slit spacing, A has more widely spaced wavefronts/fringes than B. At equal wave speed, λ_A>λ_B and f_A<f_B: choice 2 on Q5. | Q6 correctly says “A smaller than B” but labels it “(1)”; this is an answer-number error confirmed in PNG, not a TXT/OCR repair. |
| Q7–8 | Intended first single-slit minimum from paired halves: (a/2)sinθ=λ/2, choice 2. | As written, choice 3, (a/2)sinθ=λ, also gives a full-slit minimum at a sinθ=2λ whenever physically accessible. Half-separated pairs are then in phase, but quarter-pair cancellation works. The question does not say “first minimum” or restrict to the displayed pairing. Choice 1 gives a sinθ=λ/2 and I/I₀=(2/π)²≈0.405, not a zero. The original key's unique-choice claim requires a wording restriction. |
| Q9–10 | Identify the part determined by finite width a≪d: broad envelope/length A, choice 1. | Fine spacing B is set by d; length comparisons are inverse because angular scales are λ/a and λ/d. |
| Q11–12 | Estimate d/a from plotted rapid oscillations within the first envelope zero: about 8, choice 4. | Figure has about eight positive-side fine minima before the first envelope zero, consistent with the answer. This is an approximate graphical inference, not an exact metrological determination from axis labels. |

## Demand map against the complete supplied baseline

The full baseline was read, including all Mathematics, Further Mathematics, Physics and Chemistry content and explicit limits. The following map records usable premises and new source demands; it does not decide a later student-support or review outcome.

| Demand family | Already available in the supplied baseline | Added or requiring explicit source premises |
|---|---|---|
| Length/frequency/angle arithmetic | SI conversions, dimensions, algebra, v=fλ, radians/degrees, trig, inverse trig and domain checks. | Source geometry defines a,d,L,y,θ; each use must map notation and maintain medium wavelength. |
| Phase and coherence | Physics wave phase 2πΔx/λ and 2πΔt/T, fixed relative phase/common frequency, initial-phase conditions, equal-amplitude cancellation, intensity∝amplitude². | Initial or boundary phase beyond simple in-phase models must be specified; thin-film boundary phase is not granted. |
| Small-angle interference | Physics explicitly supplies Young spacing and its D≫separation/small-angle assumptions; grating d sinθ=mλ and \|mλ/d\|≤1. | Deriving path geometry is ordinary trig reasoning. Arbitrary order does not automatically satisfy the small-angle condition. |
| Superposition/intensity derivations | Algebraic expansion, trig addition/product identities, integration/mean over intervals, vector scalar product from FM. | Electric-field normalization and cross-term averaging are supplied in reading; detector/illumination/polarization premises belong to the physical model. |
| N-wave sum | Finite sums, geometric summation, complex arithmetic, Euler form, modulus/conjugates, induction and trigonometry are supplied. | The spatial array model and phase step are original physical premises. Complex Taylor-series theory need not be presumed: the baseline Euler relation already supplies the representation. |
| Continuous slit | Limits including sin h/h→1, differentiation/integration and elementary numerical methods are available. | Huygens/Fraunhofer picture, equal aperture contributions and the continuum passage are source-added. Neither general Fourier transforms nor PDE methods are needed or assumed. |
| Extrema and counting | Derivatives, stationary classification, numerical root solving, inequalities and integer counting are supplied. | Distinguish product-profile extrema, nominal interference orders, envelope boundaries and visibility. “Seven fringes” needs a counting convention for a unique inferred ratio. |
| Reading graphical questions | Interpreting axes, scales, proportional changes and diagrams is available. | PRS figures provide actual wavelength/spacing/count evidence; answer numbering is checked against the figure/question instead of memorized. |
| Laboratory estimation | Measurements, repeated readings, gradients, uncertainty and practical judgment are supplied; laser-eye considerations appear in Physics. | Babinet and reflective CD geometry are not inferred from baseline topic names. Numeric apparatus/data remain missing in this original set. |

Stable baseline locators in the universal-newline text view: FM Pure Core begins around character 50400; FM02–04 supplies complex form around 51500–52500, and later FM entries extend it; FM27 Maclaurin begins at character 63469. Physics wave/refraction/superposition/Young/grating material is in characters 114800–118400. The baseline's explicit permission for valid deductions from given premises is retained: absence of a named advanced topic does not prohibit a derivation using already supplied mathematics. The Chemistry packet adds no premise needed for these optical calculations, but was fully read rather than omitted.

## Source-internal corrections and limitations to retain

These findings are evidence about the originals. They do not authorize altering them, and they were not used as an answer key from another audit.

| Locus | Observed issue | Technically controlled treatment |
|---|---|---|
| R2–4, R8–10; P6 | Monochromaticity phrased as necessary for interference; coherent cross term described too absolutely; instantaneous cancellation can be confused with an intensity minimum. | Use the defined monochromatic model for its equations; preserve separate treatment of white light and time averaging. A zero coherent cross term at φ=π/2 is an immediate counterexample to “always nonzero.” |
| R6 Fig14.2.4 | Caption δ sign conflicts with surrounding derivation. | Declare δ=r₂−r₁; sign only reverses order labels in the symmetric in-phase pattern. |
| R11–12 Example14.2 | Requested primary/secondary ratio versus stated secondary/primary result. | Supply both 9 and 1/9 with named numerator and denominator. |
| R17–18 Eqs14.6.8–10 | Telescope/index/sign transcription errors; first-to-last phase described as NΔβ. | Reconstruct the N-term sum shown above; distinguish center-to-center span (N−1)Δβ from full-width β=NΔβ. Direct numerical sums verify the corrected identity to <4×10⁻¹⁵ absolute error for checked cases. |
| R20 Eq14.7.3 | Printed expression uses 2(m+1)+1=2m−1, while prose counts m−1 on each side. | Correct arithmetic is 2(m−1)+1=2m−1 under the integer missing-order premise. |
| R22 grating notation | Width/spacing phase symbols risk carrying single-slit a into an array-spacing argument. | Define array phase with d; define aperture envelope phase separately with a. |
| R24 Eq14.10.4 | Finite geometric sum carries a \|a\|<1 restriction and inconsistent dummy/index exponent. | Finite sum requires q≠1 only, with separate q=1 limit. For N terms use (1−q^N)/(1−q), crucial because q=e^{iΔβ} has modulus one. |
| R25–26 phasors | t=0 projection can be confused with amplitude; polygon arc expression NE₁₀=Rβ treats chords as arcs. | Amplitude is the vector length. Exact finite-chord relation is E₁₀=2Rsin(Δβ/2); NE₁₀≈Rβ is the continuum/small-step limit. |
| R30, 14.11.5 | Side maxima approximated by numerator maxima. | Retain λ≈640 nm as the source's midpoint estimate; exact sinc maximum gives ≈650.7 nm with the same small-angle approximation. |
| R30–32,14.11.6; R33,14.13.2; R35,14.13.6 | Nominal interference orders treated as exact product-profile maxima; a bare count may be underdetermined. | Product extrema shift. For 14.11.6 the admitted product formula has thirteen interior mathematical maxima (including four very weak extra peaks near the two missing nominal orders), while the worked answer counts nine nominal nonmissing orders. No visibility threshold is supplied. Checks-results.json lists positive interior extrema and intensities. |
| P16 | Film path-only conditions omit medium wavelength, angle and boundary phase. | Keep conditions explicitly conditional; no numeric universal film prediction is licensed. |
| P20–21 | Some approximate equalities printed as exact and d≫λ used as a blanket angle condition. | Retain independent far-field and small-angle requirements. |
| P23 | Scale factors contradict its inputs and its own claimed factors. | Use the checked ratios above; do not invent a screen-distance change. |
| P30; Q7–8 | Two-half pairing insufficient for all minima; Q7 has two valid destructive conditions. | State first-minimum restriction for intended choice 2, or accept choice 3 as second minimum when accessible. |
| P31 | Figure labels below center show positive sinθ values despite negative y labels. | For signed θ/y, lower minima have sinθ=−λ/a and −2λ/a; alternatively labels must explicitly denote magnitudes. |
| P37 | Babinet equal-total-field claim lacks direct-beam exception. | Use complementary scalar diffraction and exclude the undeflected beam when claiming equal diffraction intensity. |
| Q6 | Choice number 1 conflicts with text “A smaller than B” and Q5 options. | Correct choice number is 2. |

## Verification limits

All mathematical checks use the admitted originals plus arithmetic, finite summation, averaging and elementary calculus. No external scientific claims or updated course materials were admitted. checks.py recomputes original hashes, finite-sum identities, intensity cross average, original numerical examples, side-maximum roots, phase/intensity values, scaling ratios, and the PRS alternative-minimum condition. It is a technical cross-check, not a validation of real experimental data or an electromagnetic boundary-value solver. Formula-profile maxima do not by themselves decide which weak peaks a real observer would report. The originals were preserved byte-for-byte.
