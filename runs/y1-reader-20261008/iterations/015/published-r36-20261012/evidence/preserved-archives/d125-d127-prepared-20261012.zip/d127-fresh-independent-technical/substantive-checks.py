#!/usr/bin/env python3
"""Original/baseline-derived arithmetic checks. No external sources or dependencies."""
from math import sin,cos,pi,sqrt
from itertools import permutations
from pathlib import Path
import json

results=[]
def close(name,actual,expected,atol=1e-9,rtol=1e-9,premises=""):
    error=abs(actual-expected)
    passed=error <= atol+rtol*abs(expected)
    results.append(dict(check=name,actual=actual,expected=expected,absolute_error=error,
                        absolute_tolerance=atol,relative_tolerance=rtol,passed=passed,premises=premises))
    if not passed: raise AssertionError((name,actual,expected,error))

def simpson(f,a,b,n=10000):
    if n%2: n+=1
    h=(b-a)/n
    return (f(a)+f(b)+4*sum(f(a+(2*i-1)*h) for i in range(1,n//2+1))+
            2*sum(f(a+2*i*h) for i in range(1,n//2)))*h/3

# k=1 throughout, as in D127. Arbitrary test parameters are explicitly synthetic.
# 1. External Coulomb work along a spiral, evaluated as a Cartesian dot product.
Q,q=2.0,3.0
r1,r2=2.0,1.0
radial=simpson(lambda r:-Q*q/r**2,r1,r2)
def spiral_work(t):
    r=r1+(r2-r1)*t; dr=r2-r1
    theta=5*pi*t; omega=5*pi
    x,y=r*cos(theta),r*sin(theta)
    dx,dy=dr*cos(theta)-r*omega*sin(theta),dr*sin(theta)+r*omega*cos(theta)
    return (-Q*q*x/r**3)*dx+(-Q*q*y/r**3)*dy
work_expected=Q*q*(1/r2-1/r1)
close('work_radial_vs_endpoint',radial,work_expected,premises='p2: F_I=-Qq rhat/r² and one-dimensional definite integral')
close('work_spiral_vs_endpoint',simpson(spiral_work,0,1),work_expected,premises='p2–3: dot-product work; baseline chain rule and Cartesian components')
close('work_closed_radial_return',radial+simpson(lambda r:-Q*q/r**2,r2,r1),0,premises='p3: reversed endpoints cancel')
close('external_work_sign_like_inward',float(work_expected>0),1,premises='p2: r2<r1 and Qq>0')

# 2. Independent sequential assembly, unique-pair and half ordered-sum calculations.
charges=[2.,-3.,4.,-1.]
points=[(0.,0.,0.),(2.,0.,0.),(0.,3.,0.),(1.,1.,2.)]
def dist(i,j):return sqrt(sum((a-b)**2 for a,b in zip(points[i],points[j])))
unique=sum(charges[i]*charges[j]/dist(i,j) for i in range(4) for j in range(i+1,4))
ordered=.5*sum(charges[i]*charges[j]/dist(i,j) for i in range(4) for j in range(4) if i!=j)
close('energy_half_double_sum',ordered,unique,premises='p3: each unordered pair occurs twice in ordered sum')
max_assembly_error=0
for order in permutations(range(4)):
    assembly=sum(charges[order[k]]*sum(charges[order[j]]/dist(order[k],order[j]) for j in range(k)) for k in range(4))
    max_assembly_error=max(max_assembly_error,abs(assembly-unique))
close('energy_all_24_assembly_orders',max_assembly_error,0,premises='p3: sequential work from infinity includes each prior pair once')

# 3. Direct Coulomb element sum for the ring; check both signs and centre.
R,Q=2.,3.
for z in (0.,.7,-.7,20.):
    N=4096
    force=[0.,0.,0.]
    for j in range(N):
        theta=2*pi*(j+.5)/N
        displacement=(-R*cos(theta),-R*sin(theta),z)
        sep=sqrt(R*R+z*z)
        for a in range(3):force[a]+=(Q/N)*displacement[a]/sep**3
    expected=Q*z/(R*R+z*z)**1.5
    close(f'ring_z_{z}_axial',force[2],expected,premises='p1 Coulomb superposition + p5 uniform ring geometry')
    close(f'ring_z_{z}_transverse_norm',sqrt(force[0]**2+force[1]**2),0,premises='p5: opposing element components cancel')

# 4. Disk: independent quadrature of the ring contributions and closed form.
def disk(R,sigma,z):
    assert z!=0
    return 2*pi*sigma*((1 if z>0 else -1)-z/sqrt(R*R+z*z))
R,sigma=2.,1.5
for z in (.1,.7,3.,-.1,-.7,-3.):
    quad=simpson(lambda u:2*pi*sigma*z*u/(u*u+z*z)**1.5,0,R)
    close(f'disk_quadrature_z_{z}',quad,disk(R,sigma,z),atol=2e-9,premises='p5–6: dq=2πσu du and ring axial field')
# Derivative of proposed primitive checked numerically at nonsingular points.
for u,z in ((.4,.7),(1.3,-.2),(2.5,3.)):
    h=1e-5
    derivative=(-1/sqrt((u+h)**2+z*z)+1/sqrt((u-h)**2+z*z))/(2*h)
    close(f'disk_primitive_derivative_u_{u}_z_{z}',derivative,u/(u*u+z*z)**1.5,atol=2e-9,premises='p6 and baseline chain rule: derivative of -(u²+z²)^(-1/2)')
close('disk_odd_in_z',disk(2,1.5,.7)+disk(2,1.5,-.7),0,premises='p6: retain |z| in lower endpoint')

# 5. Infinite-sheet limit, far-field leading term and first correction.
for z in (1.,-1.):
    val=disk(1e7,sigma,z)
    expected=2*pi*sigma*(1 if z>0 else -1)
    close(f'disk_large_R_sheet_z_{z}',val,expected,atol=1e-6,premises='p6: fixed σ, fixed z; inverse root tends to zero')
R,z,sigma=2.,200.,1.5
Q=pi*R*R*sigma
exact=disk(R,sigma,z)
leading=Q/z**2
first=leading*(1-3*R*R/(4*z*z))
close('far_disk_leading_relative_limit',exact/leading,1,atol=8e-5,premises='p7: x=(R/z)² and binomial to first nonzero term')
close('far_disk_first_correction',exact,first,atol=4e-12,premises='p7 plus baseline binomial coefficient 3/8: cancellation leaves x/2-3x²/8')
close('far_disk_correction_improves',float(abs(exact-first)<abs(exact-leading)),1,premises='Retaining next term is materially more accurate at R/z=0.01')

# 6. Oriented flux and Gauss examples.
E,A=7.,3.
faces=[-E*A,0,E*A]
close('uniform_cylinder_total_flux',sum(faces),0,premises='p9: outward normals, uniform axial E, side normal perpendicular')
for radius in (.5,1.,4.):
    q=-2.
    close(f'centred_point_flux_radius_{radius}',(q/radius**2)*(4*pi*radius**2),4*pi*q,premises='p11: point E and sphere area; q is signed')
R,rho=2.,3.
Q=4*pi*rho*R**3/3
inside=lambda r:4*pi*rho*r/3
outside=lambda r:Q/r**2
close('solid_sphere_boundary_continuity',inside(R),outside(R),premises='p12–13: constant ρ and Q=4πρR³/3')
close('solid_sphere_origin',inside(0),0,premises='p13: continuous radial-vector extension')
for r in (.2,.8,1.5):
    close(f'solid_sphere_inside_Gauss_r_{r}',inside(r)*4*pi*r*r,4*pi*(4*pi*rho*r**3/3),premises='p13: Q_enc=ρ·volume and Φ=4πQ_enc')
R,sigma=2.,1.5
Q=4*pi*R*R*sigma
close('shell_one_sided_field_jump',Q/R**2-0,4*pi*sigma,premises='p14: outside point field and inside zero')
A=3.;E=2*pi*sigma
close('sheet_two_caps_Gauss',2*E*A,4*pi*sigma*A,premises='p14: outward cap normals aligned with corresponding symmetric fields')
close('zero_flux_not_zero_field',float(sum(faces)==0 and 7.!=0),1,premises='p9 explicit counterexample to inferring E=0 from total flux alone')

# All checks are synthetic verification, not source-provided numerical exercises.
report={'status':'pass','external_sources':[], 'source_parameters':'Synthetic arithmetic samples; originals contain no numerical parameter set.',
        'substantive_check_count':len(results),'checks':results}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'pass','substantive_check_count':len(results)}))
