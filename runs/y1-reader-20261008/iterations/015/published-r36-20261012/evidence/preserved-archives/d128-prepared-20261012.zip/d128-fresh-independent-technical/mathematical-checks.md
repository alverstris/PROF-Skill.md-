# D128 independent mathematical reconstruction — withheld

Status: prepared from the original D128 PDF and exact full four-subject baseline only. No future teaching, assessment, author response or review was inspected. This document is not a verdict on unseen teaching and must remain withheld until root explicitly releases it after the future whole-teaching freeze.

All equations below use the source's electrostatic Gaussian convention unless SI is explicitly named. `a` denotes a shell radius where using `r` for both field position and object radius would obscure the argument. These are analytical reconstructions, not empirical verification of the proposed demonstrations.

## M01. Units and pair energy (slides 2, 8, 11–12)

From the source force law F=qQ/r², charge squared has dimensions force times length squared. Thus qQ/r has energy dimensions; E=F/q has dimensions force/charge; E² times volume has energy dimensions; φ=work/charge has potential dimensions. The pair sum is U=sum_(i<j) q_i q_j/r_ij. A sum over every ordered i,j with i≠j counts each physical pair twice, hence U=(1/2)sum_i sum_(j≠i)q_iq_j/r_ij. Adding a charge q_j to the potential of already placed charges reproduces the same unordered-pair sum.

The baseline uses SI: E=Q/(4πε₀r²), φ=Q/(4πε₀r), volt=J/C and E units N/C=V/m. The source's `Volt=N/C` on slide 8 is dimensionally incorrect; N/C is a field-strength unit. `statvolt=erg/esu` is consistent with energy/charge. The source's approximate 1 statvolt≈3×10² V is recorded as a supplied conversion, not independently measured here. Do not combine Gaussian factors with numerical SI charges or ε₀. In SI the corresponding Gauss and field-energy formulas are flux=Q_encl/ε₀, div E=ρ/ε₀ and u=ε₀E²/2.

## M02. Solid-angle flux and the any-shape qualification (slide 3)

For a patch at distance R from a point charge, its oriented projected area is dA cos θ, where θ is between outward normal and the radial direction. Define signed solid angle dΩ=(cos θ)dA/R². Then E·dA=(q/R²)cos θ dA=q dΩ. On a sphere centered on the charge, the integral of dΩ is (4πR²)/R²=4π, giving 4πq. With a closed surface enclosing the source, rays crossing several patches must count outward and inward crossings with opposite signs; net signed coverage is one sphere. A source outside has net signed coverage zero. Summing point-source fields gives 4π times enclosed charge. These signed-crossing and external-charge steps complete the source's pictorial one-cone argument; the drawing itself treats the simple one-hit case.

For a trial radial field C R^(-p), patch flux is C R^(2-p)dΩ. Independence from R for arbitrary changes of boundary follows specifically when p=2. The source's claim is about the electrostatic point-charge Coulomb law, not about the divergence theorem (which holds for many differentiable vector fields). Tangent patches with cos θ=0 should be handled by the projected-area relation, not by literal division by zero in the slide's rearranged expression.

## M03. Spherical and cylindrical shells; what symmetry contributes (slides 4–5)

For a uniform spherical shell of total charge Q and radius a, symmetry requires a radial field constant in magnitude on a concentric test sphere. Therefore 4πr²E_r=4πQ_encl. This gives E_r=0 at r<a and Q/r² at r>a. Zero enclosed charge alone would establish only zero net flux; symmetry supplies pointwise vanishing. Exterior radial field and φ=Q/r have derivative connection E_r=-dφ/dr. A neon tube aligned along an equipotential direction experiences no ideal electrostatic potential difference along that direction, whereas radial alignment can produce one; a tube's light is qualitative evidence, not by itself an exponent measurement.

For an infinitely long uniform cylindrical shell with line charge λ, cylindrical symmetry plus a coaxial Gaussian cylinder of length L gives E_r(2πrL)=4πλL, hence E_r=2λ/r outside and zero inside. End-cap flux vanishes because E is radial. A finite open cylindrical shell, as visually suggested in slide 5, does not have this exact translational symmetry: end fields generally penetrate its interior. A closed conducting cavity at electrostatic equilibrium is a different model, also requiring stated conditions. The source's finite apparatus may approximate an ideal shielding demonstration, but no geometry or measured data were supplied to quantify that approximation.

In an external field, free charges in two contacting isolated conductors can separate; separating the conductors while the inducing field remains yields opposite charges. The total charge of their isolated pair is conserved. Contact/separation order matters. The source says the sequence will be explained on the board, so this PDF does not contain an independently reproducible complete D26 protocol.

## M04. Shell pressure and compression work (slides 6–7)

Set σ=Q/(4πa²). The exterior field just outside is Q/a²=4πσ and interior field is zero. A surface element must be acted on by the field of the other charges, excluding its own field. A locally planar charged patch contributes equal and opposite limiting normal self-fields on its two sides; their average is zero. Thus the other-charge field at the patch is the average of the two total limiting fields: E_act=(E_out+E_in)/2=2πσ. The outward electrical force per area is σE_act=2πσ²=E_out²/(8π)=Q²/(8πa⁴). An equal inward applied pressure can compress the shell quasi-statically.

Let δa>0 be the inward radial decrease. The applied force magnitude is pressure times 4πa², and displacement is inward along the applied force, so δW_ext=Q²δa/(2a²)>0 at first order. The newly field-filled volume is δV=4πa²δa at first order. Consequently δW_ext=E_out²δV/(8π). Writing δa as a positive squeeze magnitude avoids confusion with the signed coordinate change da=-δa. The slide's parenthetical `V=4πr²dr` denotes a thin-shell volume element; it is not the total sphere volume.

Independent finite check: the field energy outside a shell is U(a)=integral_a^∞ [Q²/(8πr⁴)]4πr²dr=Q²/(2a). Compression to a-δa changes it by ΔU=(Q²/2)[1/(a-δa)-1/a], whose leading term is Q²δa/(2a²), agreeing with the force calculation. Exterior field at a fixed r>a is unchanged when Q is fixed, and field appears only in the newly exterior annulus. Fixed Q is essential to this account.

## M05. All-space field energy and the unspecified charged sphere (slide 7)

The shell calculation gives U=Q²/(2a), with every nonzero contribution lying outside the charge-bearing surface. Integrating only where the charges reside would miss it. If the slide's unworked phrase `charged sphere` instead means a uniformly volume-charged solid sphere, the answer differs. With Q=4πKa³/3, the radial field is Qr/a³ inside and Q/r² outside. Therefore U_inside=Q²/(10a), U_outside=Q²/(2a), and U_total=3Q²/(5a). The source does not specify which interpretation its unworked example intends; the preceding model suggests a shell, but that inference must be explicit.

## M06. Work, potential and reference (slides 8–9)

For a small quasi-static displacement, the applied force balancing the electric force is F_ext=-qE. Summing work gives W_ext=-q∫E·ds. In general, W_ext=ΔK+ΔU, so equating external work and potential-energy change requires ΔK=0 and no other transfers. Potential difference is Δφ=φ(P2)-φ(P1)=W_ext/q=-∫_(P1)^(P2) E·ds. This is well defined as a point function for electrostatics; path independence is a condition of the potential construction, not a general property of any time-dependent electric field.

A radial path for a point charge Q gives φ(r)-φ(b)=-∫_b^r Q/s² ds=Q/r-Q/b. Taking b→∞, which converges, yields φ(r)=Q/r when the reference is zero at infinity. Thus Δφ=Q/r2-Q/r1. For positive Q, moving inward raises potential; a positive test charge requires positive external work and a negative test charge requires negative work. Adding any common constant C to φ leaves E and potential differences unchanged. The source's use of q for the source in slide 9 and for the test particle in slide 8 needs context, not an assumption that the roles are identical.

## M07. Superposition, continuous sources and infinite-line failure (slides 10–11)

For observation position x and source positions x_i, φ(x)=sum_i q_i/|x-x_i|. A continuum limit replaces q_i by ρ(x′)dV′, σ(x′)dA′ or λ(x′)dl′; every denominator is |x-x′|. The unprimed r in the source is shorthand for this source-to-observer distance, not a variable that may be pulled out when the separation varies. Charges and densities can be signed. Sufficient convergence and a chosen common reference are required.

For an infinite uniform line, M03 gives E_r=2λ/r. A finite reference b yields φ(r)-φ(b)=-2λ ln(r/b). The integral from infinity diverges logarithmically for nonzero λ, so φ(∞)=0 cannot define a finite potential. A finite line does allow a zero-at-infinity reference. Thus the source's `line of charges` example needs its infinite/nondecaying qualification.

Potential φ is energy per unit test charge; a particle's interaction energy in a prescribed external potential is qφ. The energy of the entire set of source charges is not sum_j q_j φ_other(r_j) without the one-half correction, because that would count each pair twice.

## M08. Charge-energy to field-energy identity and self-energy limits (slide 12)

For discrete sources, define φ_other(r_j)=sum_(i≠j)q_i/r_ij. Then U_interaction=(1/2)sum_j q_j φ_other(r_j). For a regular finite charge distribution, the continuum assembly expression is U=(1/2)∫ρφ dV. Using div E=4πρ and E=-grad φ, the componentwise product rule gives div(φE)=grad φ·E+φ div E=-E²+4πρφ. Integrating over a finite enclosing volume and using the divergence theorem gives

U_V=(1/8π)∫_V E²dV+(1/8π)∮_(∂V) φE·dA.

For a localized distribution with φ~Q/r and E~Q/r² at large r, the outer boundary term is O(1/r) and vanishes. This proves the all-space equality under decay/convergence conditions. Merely naming φ(∞)=0 does not replace checking the boundary term for arbitrary infinite distributions. Changing reference by C changes (1/2)∫ρφ by CQ_total/2, while E² does not change; the boundary term accounts for that when it does not vanish.

An ideal point charge has E²~q²/r⁴ near its position, so its self-field energy behaves as (q²/2)∫_ε r^(-2)dr and diverges as ε→0. The finite pair-interaction sum excludes those self-energies. It cannot be equated directly to the nonnegative total ∫E_total²/(8π) over all space for ideal points without subtracting or regularizing self-contributions. Opposite charges can have negative pair energy; the total unregularized field energy is nonnegative and divergent. The source moves from point pairs to a continuum without developing this distinction.

## M09. Partial derivatives, gradient and total differential (slides 13–14)

A partial derivative ∂φ/∂x differentiates the x dependence while keeping y,z fixed, so the baseline's single-variable differentiation rules can be applied once this operation is defined. For a differentiable scalar field, the first-order change is dφ=(∂xφ)dx+(∂yφ)dy+(∂zφ)dz. Define grad φ to be the vector of those derivatives. Comparing dφ=grad φ·dr with dφ=-E·dr for arbitrary coordinate displacements yields E_x=-∂xφ, E_y=-∂yφ and E_z=-∂zφ. For the point source, φ=Q/r and ∂x r=x/r give E_x=Qx/r³, similarly y,z, reconstructing E=(Q/r²)rhat away from r=0.

For any unit direction u, the directional rate is grad φ·u=|grad φ|cos θ. Its largest value is |grad φ| at u parallel to grad φ; its smallest is -|grad φ| opposite. This establishes steepest ascent and descent using the supplied real scalar product. At grad φ=0 this argument specifies no preferred direction. A one-dimensional gradient is f′(x)xhat, so it includes a sign and vector direction, not merely the nonnegative steepness.

## M10. Sinusoidal example and displayed figures (slides 15–16)

With φ=sin x sin y, holding y fixed gives ∂xφ=cos x sin y, and holding x fixed gives ∂yφ=sin x cos y. Thus E=(-cos x sin y,-sin x cos y). At (0,π/2), grad φ=(1,0); at (π/2,0), it is (0,1); at (π/2,π/2), grad φ=0 and φ=1; at (-π/2,π/2), grad φ=0 and φ=-1. Near the origin, φ≈xy, so the origin is a saddle rather than a maximum or minimum. The surface, arrows and contours are qualitatively consistent with these features.

Along a differentiable equipotential curve x(t), φ(x(t)) is constant, so its derivative is grad φ·x′(t)=0. Consequently a nonzero gradient and E are normal to the level curve, and tangential displacement does zero electrostatic work. At critical points the gradient vanishes; the zero-level axes cross at the origin, illustrating why a unique normal need not exist there. Since the example is two-dimensional, its pictured curves are equipotential lines; if extended independent of z, they extrude into equipotential surfaces. The coordinate arguments of sin require dimensionless coordinates or an implicit length scale; the source uses a mathematical demonstration without physical units.

## M11. Flux additivity and the printed sign (slide 17)

Let two adjacent volumes V1,V2 share interface I. Their outward normals satisfy n2=-n1 there. Then ∮_(∂V1)E·dA+∮_(∂V2)E·dA equals flux through the exterior boundary plus ∫_I E·n1 dA+∫_I E·n2 dA. The two interface integrals cancel, yielding Φ=Φ1+Φ2. The final black line on the original slide instead places a minus sign before the S2 integral while immediately equating it to the red Φ1+Φ2. The consistent expression is a plus sign. This is confirmed from the actual PNG; it is not merely text-extraction order corruption.

## M12. Divergence theorem reconstruction (slide 18)

For a small volume surrounding a point, define divergence as outward flux per volume in the shrinking-volume limit, for a sufficiently regular vector field and a regular family of shrinking regions. Splitting a large volume into small cells gives Φ_boundary=sum_i Φ_i exactly because all internal interfaces cancel. Write Φ_i=V_i(Φ_i/V_i). As cell sizes shrink, Φ_i/V_i tends to the local divergence and the sum tends to ∫_V div E dV, establishing ∮_(∂V)E·dA=∫_V div E dV. The surface must be the oriented closed boundary of the volume. This theorem is mathematical and does not assume Coulomb's inverse-square law. Singular charges require care: exclude small regions and track their boundaries or use the corresponding generalized description.

## M13. Box flux and Cartesian component formula (slides 20–21)

On z faces of a box centered at (x,y,z), normals are ±zhat. Their leading flux is ΔxΔy[F_z(z+Δz/2)-F_z(z-Δz/2)]. Dividing by ΔxΔyΔz gives the symmetric difference quotient tending to ∂zF_z. The x and y pairs similarly give ∂xF_x and ∂yF_y. Thus div F=∂xF_x+∂yF_y+∂zF_z. Variation across each face is negligible only to the indicated leading order as every side shrinks; the finite-face value-at-center approximation is not an exact finite-box identity.

Checks: a constant field has zero divergence; F=(ax,by,cz) has divergence a+b+c and exact box flux (a+b+c)volume. The scalar result measures local net outward flux, not the field magnitude. A nonzero field can have zero divergence, as the point-source field does everywhere away from its charge.

## M14. Differential Gauss law (slide 19)

Integral Gauss law gives ∮ E·dA=4π∫ρdV; the divergence theorem gives the same flux as ∫div E dV. Hence the integral of g=div E-4πρ vanishes over every admissible volume. For continuous g, if it were positive at a point it would remain positive in a sufficiently small neighborhood, giving positive integral, a contradiction; negative values are similarly excluded. Therefore div E=4πρ locally. This argument needs every small volume, not just one convenient surface. For regular points, ρ=(div E)/(4π). Where sources are concentrated on surfaces or points, ordinary derivatives alone away from the source do not capture the concentrated charge.

## M15. Complete reconstruction of the source-inversion task (slide 22)

Let A=4πK/3 and B=4πKR³/3. Inside, E=A r rhat=A(x,y,z), so div E=A+A+A=4πK and ρ=K. Outside, E=B(x,y,z)/r³. Since ∂x(xr^(-3))=r^(-3)-3x²r^(-5), summing the x,y,z derivatives gives 3r^(-3)-3r²r^(-5)=0. Hence ρ=0 outside.

The total volume charge is Q=K(4πR³/3)=B. Exterior field Q/r² agrees with the specified coefficient. At r=R, E_r^-=AR=4πKR/3 and E_r^+=B/R²=4πKR/3: the normal field is continuous. A thin pillbox and integral Gauss law give E_n^+-E_n^-=4πσ, so σ=0 at the interface. No hidden sheet charge is needed. At the origin the interior vector field is A(x,y,z), which smoothly tends to zero; no point charge is hidden there either. Values of a bounded volume density assigned on the single boundary surface do not alter total volume charge. This completes the slide's Cartesian ellipsis and its boundary omission.

An optional consistency potential, derived from the same field and φ(∞)=0, is φ(r)=Q/r for r≥R and φ(r)=Q/(2R)(3-r²/R²) for r≤R. Its value and radial derivative agree at R. This expression is a check here, not an extra source-taught task or assumed baseline fact.

## Result boundaries

There are 15 independently reconstructed mathematical checks above. Exact source slips, shorthand, incomplete demonstration details and idealization conditions are recorded separately in source-ambiguities.json. The material does not include observations proving the demos, a general proof of electrostatic path independence, a complete singular-source theory, or the next-lecture topics announced on slide 23. Those boundaries describe the original PDF alone; no conclusion about future teaching completeness or student performance is being made.
