from pathlib import Path
import hashlib,json,datetime
root=Path(__file__).resolve().parent
p=root/'runtime/ledger.jsonl'
b=p.read_bytes() if p.exists() else b''
latest=root/'checkpoints/latest.json'
old=json.loads(latest.read_text()) if latest.exists() else None
if old:
 prior=(root/'checkpoints'/old['snapshot']).read_bytes()
 if not b.startswith(prior):
  failure={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':'LEDGER_PREFIX_MISMATCH_STOP','current_bytes':len(b),'prior_bytes':len(prior),'sha256':hashlib.sha256(b).hexdigest()}
  (root/'checkpoints/ledger-mismatch.json').write_text(json.dumps(failure,indent=2)+'\n')
  (root/'checkpoints/ledger-mismatch-observed.jsonl').write_bytes(b)
  raise SystemExit('LEDGER_PREFIX_MISMATCH_STOP; original discrepancy saved. Do not repair or advance.')
number=old['number']+1 if old else 1
name=f'{number:03}-ledger.jsonl'
(root/'checkpoints'/name).write_bytes(b)
rec={'number':number,'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'snapshot':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'events':len(b.splitlines()),'prefix_preserved':True}
latest.write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps(rec))
