from pathlib import Path
import json,hashlib,re,sys,base64
root=Path(__file__).resolve().parent
if len(sys.argv)!=2 or sys.argv[1] not in ['F01','F02','F03']:raise SystemExit('Only fixed figure ID accepted')
fid=sys.argv[1]
route=json.loads((root/'route.json').read_text())
step=next(s for s in route['steps'] if s['id']==fid)
f=next(f for f in route['files'] if f['id']==step['file_id'])
rawpath=root/'raw-results'/(fid+'-result.json')
r=json.loads(rawpath.read_text())
meta=json.loads((root/'raw-results'/(fid+'-capture.json')).read_text())
assert set(r)=={'image_url','detail'} and r['detail']=='original'
url=r['image_url'];m=re.match(r'^data:([^;,]+);base64,(.*)$',url,re.S);assert m
assert hashlib.sha256(base64.b64decode(m[2],validate=True)).hexdigest()==f['sha256']
assert meta['invocation']=={'path':f['path'],'detail':'original'}
receipt={'schema':'sasis-view-result-v1','route_id':route['route_id'],'figure_step_id':fid,'receipt_step_id':step['receipt_step_id'],'image_path':f['path'],'image_sha256':f['sha256'],'tool_name':'tools.view_image','tool_call_id':meta['tool_call_id'],'completed_at':meta['completed_at'],'invocation':meta['invocation'],'result_metadata':{'success':True,'kind':'image','detail':r['detail'],'image_url_sha256':hashlib.sha256(url.encode()).hexdigest(),'image_url_chars':len(url),'mime_type':m[1]}}
dest=Path(step['receipt_file']);assert not dest.exists()
dest.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(dest),'raw_bytes':rawpath.stat().st_size,'raw_sha256':hashlib.sha256(rawpath.read_bytes()).hexdigest(),'decoded_original_image_sha256':f['sha256']}))
