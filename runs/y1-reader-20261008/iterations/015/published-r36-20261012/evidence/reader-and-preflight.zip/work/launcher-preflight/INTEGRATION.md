# Operational launcher preflight

The unmodified supplied launcher passed 49 subject-free checks, including a complete fresh route with a real `tools.view_image` return, saved original returned object, accepted receipt, and resumed exact-byte teaching output. The initial fixture's runtime ledger unexpectedly shortened between calls; its original evidence is preserved and the cause remains unestablished. No source-code cause or launcher defect was demonstrated. Do not erase that limitation when reporting the fresh successful checks.

Original launcher SHA-256: `d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd`.

Only the supplied operational launcher and permitted PROF/SASIS operational files were inspected. All fixture text and images are synthetic; no baseline, teaching, source, history, or sibling content was accessed. No GitHub/browser access occurred.

## Deployment and invocation

Copy the launcher unchanged into its dedicated deployment directory. Put `route.json` and `route-seal.json` beside it. The launcher creates `runtime/ledger.jsonl`; reserve `view-results/` for exact fixed receipt paths. Seal hashes are SHA-256 of the actual complete file bytes. Do not reuse another reading's runtime directory or reseal a live reading.

The only per-step command is `/absolute/deployment/read-step STEP_ID`. Resolve content paths and byte ranges only from the sealed route. Text ranges are zero-based, start-inclusive, end-exclusive binary byte ranges. Every text file must be covered contiguously exactly once by initial route steps, in file order. Complete all baseline steps before teaching. A figure immediately follows its first-use teaching text (only other figures may intervene). Predeclare bounded baseline revisit IDs; each is enabled only after its initial step and leaves the document cursor unchanged.

Use the actual route to audit coverage and first-use timing before dispatch. The schema validation establishes structural coverage, not the semantic correctness of first-use placement. Record the immutable artifact revisions and complete-file hashes separately from byte-slice hashes. The launcher verifies the bytes it returns against each slice hash; an auditor must also verify the frozen complete-file identities and final complete coverage.

## Exact JSON field sets

Objects reject undeclared or missing fields. `id`/step IDs match `[A-Za-z][A-Za-z0-9_.-]{0,79}`; hashes are lowercase 64-character SHA-256. Numeric fields must be actual integers, not booleans. Paths are canonical absolute paths; symlinks are rejected.

| Object | Required fields |
| --- | --- |
| Route seal | `schema: "sasis-route-seal-v1"`, `route_id`, `route_sha256`, `launcher_sha256` |
| Route | `schema: "sasis-fixed-route-v1"`, `route_id`, `artifacts`, `files`, `steps`, `revisits` |
| `artifacts` | `baseline`, `teaching`; each has `id`, `revision` (nonempty strings) |
| File | `id`, `artifact: "baseline" or "teaching"`, `kind: "text" or "image"`, `path`, `size`, `sha256` |
| Text step | `id`, `kind: "text"`, `file_id`, `start`, `end`, `sha256` (hash of exact slice) |
| Figure step | `id`, `kind: "figure"`, `file_id`, `sha256` (complete image), `receipt_step_id`, `receipt_file`, `first_use` |
| `first_use` | `text_step_id`, `position: "after"` |
| Revisit | `id`, `initial_step_id` (initial baseline text step) |
| View receipt | `schema: "sasis-view-result-v1"`, `route_id`, `figure_step_id`, `receipt_step_id`, `image_path`, `image_sha256`, `tool_name: "tools.view_image"`, `tool_call_id`, `completed_at`, `invocation`, `result_metadata` |
| View invocation | `path` (exact routed image path), `detail: "original"` |
| View result metadata | `success: true`, `kind: "image"`, `detail: "original"`, `image_url_sha256`, `image_url_chars`, `mime_type` |

Text slices are at most 1 MiB. Figures are complete image files at most 128 MiB. Receipts are at most 64 KiB, so preserve the complete raw tool return separately and put only derived metadata in the launcher receipt. Figure receipt files must be unique `.json` files directly inside the deployment's `view-results/` directory. `completed_at` must be timezone-aware, after figure dispatch, and no later than the launcher's current time.

The complete generated example schema is `cases/receipt-flow/route.json`, its exact seal is `cases/receipt-flow/route-seal.json`, and its successful real receipt is `cases/receipt-flow/view-results/F1.json`.

## Real view capture, without reconstructed tool results

After the figure step returns its fixed image path, invoke the actual tool with that path and original detail. In the same `functions.exec` call, keep the returned object in a variable, serialize that object directly, and send the serialized text to `tools.apply_patch`. Call `image(result.image_url, "original")` so the actual image is displayed. This preflight used the following mechanism; paths below are placeholders for predeclared operational locations, never extra reader launcher arguments:

```javascript
const invocation = {path: exactRoutedImagePath, detail: "original"};
const invocationId = "view-" + Date.now(); // explicitly local capture identifier
const startedAt = new Date().toISOString();
const result = await tools.view_image(invocation);
const completedAt = new Date().toISOString();
await tools.apply_patch("*** Begin Patch\n*** Add File: " + exactRawResultPath
  + "\n+" + JSON.stringify(result) + "\n*** End Patch");
image(result.image_url, "original");
```

Save invocation and capture metadata separately, including the actual arguments, start/completion times, original-object filename, and identity provenance. This runtime's returned object contained exactly `image_url` and `detail`. No provider tool-call ID was exposed, so `tool_call_id` in the launcher receipt is the explicitly recorded orchestrator-issued identifier for that actual invocation. Do not call it a provider-issued ID.

Derive receipt metadata from the preserved raw object: SHA-256 of the UTF-8 data URL string, its character length, its MIME header, actual result detail, and completion time. Preserve data-URL bytes; do not print the full base64 result into conversational output. This preflight decoded the saved data URL, and the resulting image bytes exactly matched the frozen fixture PNG. Derive `success: true` only after the tool has actually returned a valid complete image object; do not synthesize a successful object.

The receipt is an operational attestation: the launcher checks its exact identity, schema, invocation metadata, time, and uniqueness, but does not independently authenticate the tool provider or recompute its `image_url_sha256` from a raw-result file. The independent audit must correlate the preserved actual tool return, capture metadata, receipt, and ledger. A checksum/path alone fails the receipt schema. A receipt does not prove semantic inspection.

If receipt production occurs while a reader is active, keep it as predeclared operational result handling; do not add subject-path/range interpreter retrieval commands or allow future text access. Advance only by invoking the fixed `receipt_step_id` after the real view result is displayed and captured. Preserve every unsuccessful invocation and result.

## Evidence and limitations

`results.json` contains all 49 passing assertions and the preserved anomaly qualification. The cases cover missing/extra/path arguments, unknown/skipped steps, incomplete baseline, unread and already-read revisits, revisit cursor preservation, figure skip/bypass and missing/path-only receipts, invalid types/ranges/coverage/order, mismatched launcher and route identities, changed content with output withheld and failed-read reuse blocked, invalid receipt identity/invocation/status/hash/time, actual receipt acceptance, resumed exact bytes, and route exhaustion.

Each invocation has `.stdout.bin`, `.stderr.txt`, `.opens.jsonl`, `.events.json`, and `.result.json` evidence. A CPython `sys.addaudithook` observer logs every Python open attempt independently of the launcher's ledger. Rejections requiring no content access have zero fixture-open events and zero subject-open/read ledger events. Successful text checks compare exact binary output with the intended fixture slice and verify an actual-access receipt precedes output. Reads/hashes are instrumented by the launcher; this is not a kernel syscall trace. `strace` failed because ptrace is unavailable, before any launcher execution, and that raw failure is saved under `strace-unavailable-attempt/`.

The successful fresh flow is `cases/receipt-flow/`; `final-ledger-audit.json` verifies its 123-event hash chain, exact commit order, complete route, accepted actual view receipt, and cursor-preserving revisits. Its ledger was checked unchanged across separate tool calls before view, after view, and after completion. All fixture bytes were treated as data, including a code-shaped line that was returned literally.

The first fixture's discrepancy is recorded in `ledger-anomaly.json`, `ledger-anomaly-observed.jsonl`, and `ledger-anomaly-per-call-events.json`. Its first 96 saved per-call events form a valid hash chain, but the observed live ledger later contained only the first 16 plus a new rejected call. The first ledger was not reconstructed. The parent reports no modification of this directory; no restoring/truncating operation was found in the setup code. A separate append-persistence probe passed. The fresh flow's success does not retrospectively repair the first condition or establish the unexplained cause. Preserve an external exact ledger snapshot/hash at operational checkpoints and verify it before subsequent access; a mismatch should stop that reader rather than be silently repaired.

`evidence-manifest.json` records the exact relative paths, sizes, and SHA-256 of the deliverable evidence files (excluding itself and Python cache files). This preflight does not claim technical isolation, erased pretraining, subject review, reader admission, or human learning.
