#!/usr/bin/env python3
"""Derive receipt only from the saved actual tool return; finish synthetic checks."""
import base64
import copy
import json
from pathlib import Path
from preflight import ROOT, SOURCE, sha, save_json, load_json, invoke, fixture_bytes

root=ROOT/"cases/main"
route=load_json(root/"route.json")
capture=load_json(ROOT/"actual-view-capture.json")
raw_result=(ROOT/"actual-view-result.json").read_bytes()
result=json.loads(raw_result)
assert set(result)=={"image_url","detail"}
assert result["detail"]=="original"
url=result["image_url"]
header,payload=url.split(",",1)
assert header.startswith("data:") and header.endswith(";base64")
mime=header[5:-7]
decoded=base64.b64decode(payload,validate=True)
(ROOT/"actual-view-returned-image.png").write_bytes(decoded)
figure=next(s for s in route["steps"] if s["id"]=="F1")
image_file=next(f for f in route["files"] if f["id"]==figure["file_id"])
assert capture["invocation"]==dict(path=image_file["path"],detail="original")
assert decoded==Path(image_file["path"]).read_bytes()
receipt=dict(schema="sasis-view-result-v1",route_id=route["route_id"],figure_step_id=figure["id"],receipt_step_id=figure["receipt_step_id"],image_path=image_file["path"],image_sha256=image_file["sha256"],tool_name=capture["tool_name"],tool_call_id=capture["invocation_id"],completed_at=capture["completed_at"],invocation=capture["invocation"],result_metadata=dict(success=True,kind="image",detail=result["detail"],image_url_sha256=sha(url.encode("utf-8")),image_url_chars=len(url),mime_type=mime))
assert len(json.dumps(receipt).encode())<65536
checks=[]
for label,mutator,reason in [
    ("21-wrong-receipt-identity",lambda r:r.update(route_id="not-this-route"),"view receipt identity mismatch"),
    ("22-wrong-view-invocation",lambda r:r["invocation"].update(detail="high"),"view invocation mismatch"),
    ("23-unsuccessful-view-metadata",lambda r:r["result_metadata"].update(success=False),"successful image tool result"),
    ("24-invalid-view-result-hash",lambda r:r["result_metadata"].update(image_url_sha256="not-a-hash"),"invalid SHA-256"),
    ("25-predispatch-completion-time",lambda r:r.update(completed_at="2000-01-01T00:00:00+00:00"),"does not follow dispatch"),
]:
    invalid=copy.deepcopy(receipt)
    mutator(invalid)
    save_json(root/"view-results/F1.json",invalid)
    save_json(root/"evidence"/(label+".submitted-receipt.json"),invalid)
    checks.append(invoke(root,label,["F1_view"],2,reason=reason,no_open=True,cursor=3,operation="figure_received"))
save_json(root/"view-results/F1.json",receipt)
checks.append(invoke(root,"26-actual-view-receipt-accepted",["F1_view"],0,no_open=True,cursor=3,operation="figure_received"))
checks.append(invoke(root,"27-next-teaching-after-view",["T2"],0,expected=fixture_bytes(root,"T2"),cursor=4,operation="text"))
checks.append(invoke(root,"28-baseline-revisit-after-view",["RB2"],0,expected=fixture_bytes(root,"B2"),cursor=5,operation="revisit"))
checks.append(invoke(root,"29-final-text-cursor-preserved",["T3"],0,expected=fixture_bytes(root,"T3"),cursor=5,operation="text"))
checks.append(invoke(root,"30-completed-route-cannot-restart",["T1"],2,reason="next scheduled",no_open=True))

events=[json.loads(x) for x in (root/"runtime/ledger.jsonl").read_text().splitlines()]
previous="0"*64
for i,event in enumerate(events):
    assert event["index"]==i and event["previous"]==previous
    unhashed={k:v for k,v in event.items() if k!="sha256"}
    assert sha(json.dumps(unhashed,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode("ascii"))==event["sha256"]
    previous=event["sha256"]
commits=[(e["data"]["step_id"],e["data"]["operation"]) for e in events if e["event"]=="state_commit"]
expected=[("B1","text"),("RB1","revisit"),("B2","text"),("T1","text"),("F1","figure_dispatched"),("RB1","revisit"),("F1_view","figure_received"),("T2","text"),("RB2","revisit"),("T3","text")]
assert commits==expected
accepts=[e for e in events if e["event"]=="figure_receipt_accepted"]
assert len(accepts)==1 and accepts[0]["data"]["receipt"]==receipt
assert accepts[0]["data"]["receipt_sha256"]==sha((root/"view-results/F1.json").read_bytes())
route_access=[e["data"] for e in events if e["event"]=="actual_access"]
assert all(a["verified"] is True for a in route_access)
save_json(ROOT/"final-ledger-audit.json",dict(status="PASS",route_sha256=sha((root/"route.json").read_bytes()),ledger_sha256=sha((root/"runtime/ledger.jsonl").read_bytes()),ledger_events=len(events),ledger_tail_sha256=previous,actual_commits=commits,expected_commits=expected,initial_baseline_before_teaching=True,complete_route_in_order=True,baseline_revisits_do_not_advance=True,figure_dispatched_before_actual_view_capture=True,actual_view_receipt_before_next_teaching=True,figure_receipt_count=1,actual_view_capture_id=capture["invocation_id"],provider_tool_call_id_exposed=False,original_object_sha256=sha(raw_result),original_object_serialization="JSON.stringify actual tool return; trailing LF supplied by apply_patch",image_url_sha256=sha(url.encode("utf-8")),image_url_chars=len(url),decoded_image_sha256=sha(decoded),decoded_image_equals_frozen_fixture=True,semantic_inspection_proven=False))
initial=load_json(ROOT/"initial-results.json")
save_json(ROOT/"results.json",dict(status="PASS",scope="subject-free operational launcher preflight only",checks_count=len(initial["checks"])+len(checks),checks=initial["checks"]+checks,launcher_source=str(SOURCE),launcher_sha256=sha(SOURCE.read_bytes()),launcher_unmodified=SOURCE.read_bytes()==(root/"read-step").read_bytes(),opened_content_scope="generated synthetic fixtures only",instrumentation="CPython audit hook records all Python open attempts; launcher ledger records bounded reads and hashes. strace unavailable because ptrace forbidden; initial failure preserved.",limits=["Not a technical sandbox or proof of semantic inspection.","view_image returned no provider tool-call ID; tool_call_id is an explicitly documented orchestrator-issued invocation ID.","Launcher verifies receipt metadata structure, identity and time, but does not independently authenticate tool origin or validate its data URL hash against raw result; auditor must do that using preserved returned object."] ))
print(json.dumps(dict(status="PASS",checks=len(initial["checks"])+len(checks),launcher_sha256=sha(SOURCE.read_bytes()),actual_image_result_preserved=True,ledger_events=len(events)),indent=2))
