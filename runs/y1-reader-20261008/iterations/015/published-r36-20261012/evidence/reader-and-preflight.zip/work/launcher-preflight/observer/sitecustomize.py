"""Operational observer only: record Python audit open events, without reading content."""
import json
import os
import sys

_path = os.environ.get("PREFLIGHT_OPEN_LOG")
if _path:
    _fd = os.open(_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    def _hook(event, args):
        if event == "open":
            path, mode, flags = args
            if isinstance(path, bytes): path = os.fsdecode(path)
            os.write(_fd, (json.dumps(dict(event=event,path=path,mode=mode,flags=flags),sort_keys=True)+"\n").encode())
    os.write(_fd, (json.dumps(dict(event="observer_started",argv=sys.argv),sort_keys=True)+"\n").encode())
    sys.addaudithook(_hook)
