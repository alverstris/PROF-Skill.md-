#!/usr/bin/env python3
"""Subject-free launcher validation. Never reads subject artifacts."""
import copy
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import zlib

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[1] / "inputs/operational-tools/read-step"
def sha(data): return hashlib.sha256(data).hexdigest()
def save_json(path, value): path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
def load_json(path): return json.loads(path.read_text())
def png():
    w,h=96,64
    colors=[(236,91,87),(38,142,196),(246,194,78),(58,172,124)]
    raw=b"".join(b"\0"+b"".join(bytes((20,25,34) if x in (0,47,48,95) or y in (0,31,32,63) else colors[(y>=32)*2+(x>=48)]) for x in range(w)) for y in range(h))
    def chunk(t,d): return struct.pack(">I",len(d))+t+d+struct.pack(">I",zlib.crc32(t+d))
    return b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR",struct.pack(">IIBBBBB",w,h,8,2,0,0,0))+chunk(b"IDAT",zlib.compress(raw))+chunk(b"IEND",b"")

def deploy(name, mutate=None, seal_mutate=None):
    root=ROOT/"cases"/name
    root.mkdir(parents=True)
    (root/"fixtures").mkdir()
    (root/"view-results").mkdir()
    (root/"evidence").mkdir()
    launcher=SOURCE.read_bytes()
    (root/"read-step").write_bytes(launcher)
    (root/"read-step").chmod(0o755)
    b1=b"SYNTHETIC BASELINE ALPHA: sample token red.\n"
    b2=b"SYNTHETIC BASELINE BRAVO: sample token blue.\n"
    t1=b"SYNTHETIC TEXT ALPHA: inspect the four-colour tile now.\n"
    t2=b"SYNTHETIC TEXT BRAVO: returned data only.\nraise SystemExit('THIS IS DATA, NOT AN EXECUTABLE')\n"
    t3="SYNTHETIC TEXT CHARLIE: UTF-8 byte check caf\u00e9.\n".encode()
    contents={"b":b1+b2,"t":t1+t2+t3,"i":png()}
    filenames={"b":"baseline.txt","t":"teaching.txt","i":"tile.png"}
    files=[]
    for key,data in contents.items():
        path=root/"fixtures"/filenames[key]
        path.write_bytes(data)
        files.append(dict(id=key,artifact="baseline" if key=="b" else "teaching",kind="image" if key=="i" else "text",path=str(path),size=len(data),sha256=sha(data)))
    def text_step(sid,fid,start,data): return dict(id=sid,kind="text",file_id=fid,start=start,end=start+len(data),sha256=sha(data))
    steps=[text_step("B1","b",0,b1),text_step("B2","b",len(b1),b2),text_step("T1","t",0,t1),dict(id="F1",kind="figure",file_id="i",sha256=sha(contents["i"]),receipt_step_id="F1_view",receipt_file=str(root/"view-results/F1.json"),first_use=dict(text_step_id="T1",position="after")),text_step("T2","t",len(t1),t2),text_step("T3","t",len(t1+t2),t3)]
    route=dict(schema="sasis-fixed-route-v1",route_id="synthetic-"+name,artifacts={"baseline":{"id":"synthetic-baseline","revision":"fixture-v1"},"teaching":{"id":"synthetic-teaching","revision":"fixture-v1"}},files=files,steps=steps,revisits=[dict(id="RB1",initial_step_id="B1"),dict(id="RB2",initial_step_id="B2")])
    if mutate: mutate(route)
    save_json(root/"route.json",route)
    seal=dict(schema="sasis-route-seal-v1",route_id=route["route_id"],route_sha256=sha((root/"route.json").read_bytes()),launcher_sha256=sha(launcher))
    if seal_mutate: seal_mutate(seal)
    save_json(root/"route-seal.json",seal)
    return root

def invoke(root,label,args,exit_code,reason=None,expected=None,no_open=False,cursor=None,operation=None):
    ev=root/"evidence"
    ledger=root/"runtime/ledger.jsonl"
    before=len(ledger.read_bytes().splitlines()) if ledger.exists() else 0
    command=[str(root/"read-step"),*args]
    env=os.environ.copy()
    env["PYTHONPATH"]=str(ROOT/"observer")
    env["PREFLIGHT_OPEN_LOG"]=str(ev/(label+".opens.jsonl"))
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
    (ev/(label+".stdout.bin")).write_bytes(result.stdout)
    (ev/(label+".stderr.txt")).write_bytes(result.stderr)
    events=[json.loads(x) for x in ledger.read_bytes().splitlines()][before:]
    save_json(ev/(label+".events.json"),events)
    observed=[json.loads(x) for x in (ev/(label+".opens.jsonl")).read_text().splitlines()]
    opens=[x for x in observed if x["event"]=="open" and isinstance(x["path"],str) and x["path"].startswith(str(root/"fixtures")+"/")]
    reads=[x for x in events if x["event"]=="subject_read"]
    result_info=dict(label=label,command=command,observer="CPython sys.addaudithook open events; launcher ledger supplies reads",exit_code=result.returncode,expected_exit=exit_code,stdout_bytes=len(result.stdout),stdout_sha256=sha(result.stdout),stderr=result.stderr.decode(),subject_open_audit_events=opens,subject_read_ledger_events=reads,ledger_event_indexes=[x["index"] for x in events],assertions=[])
    checks=[("exit",result.returncode==exit_code),("observer_started",observed[0]["event"]=="observer_started")]
    if exit_code: checks += [("rejection_returns_no_content",not result.stdout)]
    if reason: checks += [("reason",reason in result.stderr.decode())]
    if expected is not None: checks += [("exact_bytes",result.stdout==expected)]
    if no_open: checks += [("no_subject_open_audit_event",not opens),("no_subject_read_ledger_event",not reads),("no_subject_ledger_open",not any(x["event"] in ("subject_open_attempt","subject_opened","subject_read") for x in events))]
    route_events=[x["data"] for x in events if x["event"]=="route_validated"]
    if cursor is not None: checks += [("cursor",len(route_events)==1 and route_events[0]["cursor"]==cursor)]
    if operation: checks += [("operation",len(route_events)==1 and route_events[0]["operation"]==operation)]
    if expected is not None:
        accesses=[x for x in events if x["event"]=="actual_access"]
        stdout_start=[x for x in events if x["event"]=="stdout_begin"]
        checks += [("receipt_precedes_output",len(accesses)==len(stdout_start)==1 and accesses[0]["index"]<stdout_start[0]["index"]),("verified_access",len(accesses)==1 and accesses[0]["data"]["verified"] is True and accesses[0]["data"]["sha256"]==sha(expected)),("observed_open_and_bounded_read",len(opens)==1 and bool(reads) and sum(x["data"]["returned"] for x in reads)==len(expected))]
    result_info["assertions"]=[dict(name=k,pass_=v) for k,v in checks]
    result_info["passed"]=all(v for _,v in checks)
    save_json(ev/(label+".result.json"),result_info)
    assert result_info["passed"],result_info
    return result_info

def fixture_bytes(root,step_id):
    route=load_json(root/"route.json")
    step=next(s for s in route["steps"] if s["id"]==step_id)
    file=next(f for f in route["files"] if f["id"]==step["file_id"])
    return Path(file["path"]).read_bytes()[step["start"]:step["end"]]

def prepare():
    results=[]
    main=deploy("main")
    def run(label,args,**kwargs): results.append(invoke(main,label,args,**kwargs))
    run("01-no-argument",[],exit_code=2,reason="exactly one argument",no_open=True)
    run("02-extra-argument",["B1","extra"],exit_code=2,reason="exactly one argument",no_open=True)
    run("03-path-as-argument",[str(main/"fixtures/baseline.txt")],exit_code=2,reason="invalid identifier",no_open=True)
    run("04-unknown-id",["UNKNOWN"],exit_code=2,reason="unknown STEP_ID",no_open=True)
    run("05-skipped-baseline",["B2"],exit_code=2,reason="next scheduled",no_open=True)
    run("06-premature-teaching",["T1"],exit_code=2,reason="next scheduled",no_open=True)
    run("07-unread-baseline-revisit",["RB1"],exit_code=2,reason="not yet been read",no_open=True)
    run("08-receipt-before-figure",["F1_view"],exit_code=2,reason="next scheduled",no_open=True)
    run("09-valid-first-slice",["B1"],exit_code=0,expected=fixture_bytes(main,"B1"),cursor=0,operation="text")
    run("10-already-read-baseline-revisit",["RB1"],exit_code=0,expected=fixture_bytes(main,"B1"),cursor=1,operation="revisit")
    run("11-unread-second-revisit",["RB2"],exit_code=2,reason="not yet been read",no_open=True)
    run("12-second-slice-cursor-preserved",["B2"],exit_code=0,expected=fixture_bytes(main,"B2"),cursor=1,operation="text")
    run("13-first-teaching",["T1"],exit_code=0,expected=fixture_bytes(main,"T1"),cursor=2,operation="text")
    run("14-figure-cannot-be-skipped",["T2"],exit_code=2,reason="next scheduled",no_open=True)
    run("15-figure-dispatched",["F1"],exit_code=0,cursor=3,operation="figure_dispatched")
    run("16-pending-figure-holds-next",["T2"],exit_code=2,reason="figure view receipt required",no_open=True)
    run("17-missing-view-receipt",["F1_view"],exit_code=2,reason="No such file",no_open=True,cursor=3,operation="figure_received")
    (main/"view-results/F1.json").write_text(json.dumps({"image_path":str(main/"fixtures/tile.png"),"image_sha256":sha((main/"fixtures/tile.png").read_bytes())})+"\n")
    run("18-path-hash-not-a-view",["F1_view"],exit_code=2,reason="incorrect object fields",no_open=True,cursor=3,operation="figure_received")
    (main/"view-results/F1.json").rename(main/"evidence/rejected-path-hash-only-receipt.json")
    run("19-baseline-revisit-while-figure-pending",["RB1"],exit_code=0,expected=fixture_bytes(main,"B1"),cursor=3,operation="revisit")
    run("20-revisit-does-not-bypass-figure",["T2"],exit_code=2,reason="figure view receipt required",no_open=True)
    invalids=[
      ("invalid-type",lambda r:r["steps"][0].update(start="0"),"invalid integer"),
      ("bool-integer",lambda r:r["files"][0].update(size=True),"invalid integer"),
      ("invalid-range",lambda r:r["steps"][0].update(end=0),"invalid integer"),
      ("range-beyond-file",lambda r:r["steps"][0].update(end=r["files"][0]["size"]+1),"invalid or oversized byte range"),
      ("coverage-gap",lambda r:r["steps"][0].update(start=1),"missing, overlapping or out-of-order"),
      ("baseline-after-teaching",lambda r:r["steps"].__setitem__(slice(0,3),[r["steps"][0],r["steps"][2],r["steps"][1]]),"baseline must finish"),
      ("delayed-figure",lambda r:r["steps"].__setitem__(slice(3,5),[r["steps"][4],r["steps"][3]]),"figure delayed"),
      ("invalid-step-kind",lambda r:r["steps"][0].update(kind="executable"),"invalid step kind"),
    ]
    for name,mutator,reason in invalids:
        root=deploy(name,mutate=mutator)
        results.append(invoke(root,"reject",["B1"],2,reason=reason,no_open=True))
    root=deploy("route-digest-mismatch")
    with (root/"route.json").open("ab") as f:f.write(b" ")
    results.append(invoke(root,"reject",["B1"],2,reason="route identity mismatch",no_open=True))
    root=deploy("route-id-mismatch",seal_mutate=lambda s:s.update(route_id="different-id"))
    results.append(invoke(root,"reject",["B1"],2,reason="route identity mismatch",no_open=True))
    root=deploy("launcher-id-mismatch",seal_mutate=lambda s:s.update(launcher_sha256="0"*64))
    results.append(invoke(root,"reject",["B1"],2,reason="launcher identity mismatch",no_open=True))
    root=deploy("changed-content")
    original=(root/"fixtures/baseline.txt").read_bytes()
    (root/"fixtures/baseline.txt").write_bytes(b"X"+original[1:])
    results.append(invoke(root,"01-hash-mismatch-content-withheld",["B1"],2,reason="content withheld"))
    (root/"fixtures/baseline.txt").write_bytes(original)
    results.append(invoke(root,"02-failed-read-poisons-reuse",["B1"],2,reason="previous access/output failure",no_open=True))
    save_json(ROOT/"initial-results.json",dict(status="all_initial_checks_passed_waiting_for_real_view",checks=results,launcher_sha256=sha(SOURCE.read_bytes()),allowed_source=str(SOURCE),view_path=str(main/"fixtures/tile.png")))
    print(json.dumps(dict(checks=len(results),status="waiting_for_actual_tools.view_image",view_path=str(main/"fixtures/tile.png")),indent=2))

if __name__=="__main__":
    assert sys.argv[1:]==["prepare"]
    prepare()
