"""Fresh synthetic route after preserved unexplained ledger shortening; no repair of prior ledger."""
from preflight import ROOT,deploy,invoke,fixture_bytes,save_json,sha
root=deploy("receipt-flow")
checks=[]
for label,sid,cursor,operation in [("01-B1","B1",0,"text"),("02-RB1","RB1",1,"revisit"),("03-B2","B2",1,"text"),("04-T1","T1",2,"text"),("05-F1","F1",3,"figure_dispatched"),("06-RB1-pending","RB1",3,"revisit")]:
    expected=None if sid=="F1" else fixture_bytes(root,"B1" if sid=="RB1" else sid)
    checks.append(invoke(root,label,[sid],0,expected=expected,cursor=cursor,operation=operation))
    (root/"evidence"/(label+".complete-ledger.jsonl")).write_bytes((root/"runtime/ledger.jsonl").read_bytes())
raw=(root/"runtime/ledger.jsonl").read_bytes()
(ROOT/"receipt-flow-pre-view-ledger.jsonl").write_bytes(raw)
save_json(ROOT/"receipt-flow-pre-view.json",dict(checks=checks,ledger_sha256=sha(raw),ledger_events=len(raw.splitlines()),view_path=str(root/"fixtures/tile.png")))
print(dict(ledger_sha256=sha(raw),ledger_events=len(raw.splitlines()),status="fresh_fixture_pending_actual_view"))
