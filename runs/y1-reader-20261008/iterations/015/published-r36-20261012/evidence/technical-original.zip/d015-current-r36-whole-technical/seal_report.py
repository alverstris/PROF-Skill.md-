from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
OUT = ROOT / 'd015-current-r36-whole-technical'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

source_rows = [
    {'id': 'S01', 'source': 'PDF page 1 cover and metadata', 'demand': 'Original identity and attribution context', 'locations': ['main.md:5', 'main.md:253'], 'result': 'Course, year, lecture and locator match; author attribution unverified in this reviewer admission.'},
    {'id': 'S02', 'source': 'PDF page 2 Example 1', 'demand': 'Direct antiderivation with arbitrary constant and initial condition', 'locations': ['main.md:13-21', 'main.md:245', 'hints.md:51', 'solutions.md:123'], 'result': 'pass'},
    {'id': 'S03', 'source': 'PDF page 2 Example 2 operator notation', 'demand': 'Read and construct derivative-plus-multiplication operator', 'locations': ['main.md:23-29'], 'result': 'pass; external contextual refinement at line 31 remains unverified here'},
    {'id': 'S04', 'source': 'PDF page 2 Example 2 Gaussian solution', 'demand': 'Correct sign, separated log, signed constant, lost zero, initial data, completeness', 'locations': ['main.md:35-73', 'main.md:83', 'hints.md:13', 'solutions.md:13-21'], 'result': 'pass'},
    {'id': 'S05', 'source': 'PDF page 3 Figure 1', 'demand': 'Gaussian symmetry, positivity, peak and limiting behavior', 'locations': ['main.md:73-77', 'figures/gaussian.png'], 'result': 'pass; actual native image inspected'},
    {'id': 'S06', 'source': 'PDF page 3 general separation', 'demand': 'f, g, h, H, F roles; original sign correction; chain-rule warrant; zeros and local conditions', 'locations': ['main.md:89-105', 'main.md:130', 'main.md:253'], 'result': 'pass'},
    {'id': 'S07', 'source': 'PDF page 3 inverse expression', 'demand': 'One-to-one interval, range and inverse versus reciprocal; branch construction', 'locations': ['main.md:107-128'], 'result': 'pass'},
    {'id': 'S08', 'source': 'PDF page 4 Example 3', 'demand': 'Construct y prime equals 2y/x, separate on both x signs, restore zero and correct source typo', 'locations': ['main.md:142-169', 'main.md:253'], 'result': 'pass'},
    {'id': 'S09', 'source': 'PDF page 4 Figure 2', 'demand': 'Origin ray and tangent slopes, point and distinct lines', 'locations': ['main.md:148-152', 'figures/tangent-ray.png'], 'result': 'pass; actual native image inspected'},
    {'id': 'S10', 'source': 'PDF page 4 Example 3 domains', 'demand': 'Exclude x=0 even for smooth formula; connected intervals and initial data', 'locations': ['main.md:167-169', 'main.md:175', 'hints.md:35', 'solutions.md:58-74'], 'result': 'pass'},
    {'id': 'S11', 'source': 'PDF page 5 Example 4', 'demand': 'Parameter elimination, reciprocal slope restrictions, correct integrated half factors', 'locations': ['main.md:181-195', 'solutions.md:82-92'], 'result': 'pass'},
    {'id': 'S12', 'source': 'PDF page 5 Example 4 ellipse', 'demand': 'C sign cases, ellipse construction, semiaxes, aspect ratio, initial member', 'locations': ['main.md:197-205', 'solutions.md:84-95'], 'result': 'pass'},
    {'id': 'S13', 'source': 'PDF page 5 Figure 3', 'demand': 'Perpendicular families and qualitative geometry', 'locations': ['main.md:207-213', 'figures/perpendicular-families.png'], 'result': 'pass; actual native image inspected'},
    {'id': 'S14', 'source': 'PDF page 5 Example 4 domains', 'demand': 'Fixed graph branches, endpoint failure, actual intersection domains, horizontal/vertical exceptions', 'locations': ['main.md:215-223', 'main.md:229', 'hints.md:43', 'solutions.md:95-115'], 'result': 'pass'},
    {'id': 'S15', 'source': 'PDF page 5 Exam Review announcement', 'demand': 'All six topics and historical warning; no invented absent review-sheet demands', 'locations': ['main.md:255'], 'result': 'pass'},
]
task_rows = [
    {'task': 'Q1', 'main_line': 83, 'hint_lines': '13', 'solution_lines': '13-21', 'result': 'pass', 'discriminating_checks': ['division domain', 'zero and negative solution', 'derivative and both initial values']},
    {'task': 'Q2', 'main_line': 136, 'hint_lines': '21-27', 'solution_lines': '29-50', 'result': 'pass', 'discriminating_checks': ['negative log sign', 'excluded equilibrium', 'strict finite-x side', 'both derivative and initial checks']},
    {'task': 'Q3', 'main_line': 175, 'hint_lines': '35', 'solution_lines': '58-74', 'result': 'pass', 'discriminating_checks': ['negative-x absolute value', 'negative cubic coefficient', 'two slopes at given point', 'undefined origin quotient']},
    {'task': 'Q4', 'main_line': 229, 'hint_lines': '43', 'solution_lines': '82-115', 'result': 'pass', 'discriminating_checks': ['half factors', 'semiaxes', 'negative branch', 'positive-x maximal interval', 'perpendicular slopes', 'full ellipse distinction']},
    {'task': 'Q5(a)', 'main_line': 245, 'hint_lines': '51', 'solution_lines': '123', 'result': 'pass', 'discriminating_checks': ['direct method choice', 'constant from initial value', 'derivative']},
    {'task': 'Q5(b)', 'main_line': 247, 'hint_lines': '53', 'solution_lines': '125-153', 'result': 'pass', 'discriminating_checks': ['differentiate fixed parameter', 'eliminate a before reciprocal', 'positive orthogonal sign', 'implicit minus sign', 'positive branch and x>0', 'slopes -2 and 1/2']},
]
save('source-coverage.json', {
    'inventory_basis': '../d015-next-fresh-independent-technical/source-only-preparation.txt',
    'original_pages_covered': [1,2,3,4,5], 'original_examples_covered': [1,2,3,4], 'original_figures_covered': [1,2,3],
    'source_demands': source_rows, 'actual_tasks': task_rows,
    'added_worked_examples': [
        {'location': 'main.md:17-21', 'case': 'y prime equals 3x squared plus 1, y(0)=2', 'result': 'pass'},
        {'location': 'main.md:29', 'case': 'operator applied to x squared', 'result': 'pass'},
        {'location': 'main.md:115-128', 'case': 'y prime equals x/y, y(0)=-2', 'result': 'pass'},
        {'location': 'main.md:205-223', 'case': 'orthogonal member through (1,1)', 'result': 'pass'},
    ],
    'units': 'No physical units supplied or needed in these real-variable mathematical tasks.',
    'full_baseline_use': 'Prior complete 247840-byte read; applies its actual elementary/Further Mathematics premises without assuming quantum-operator formalism.',
    'unreviewed_source_demands': [], 'unreviewed_actual_task_parts': [],
    'material_mathematical_failures': [],
    'external_evidence_limits': [
        {'location': 'main.md:31', 'status': 'unverified', 'reason': 'Exact cited MIT 5.61 Lecture 9 PDF not admitted to this reviewer.'},
        {'location': 'main.md:253', 'status': 'unverified', 'reason': 'David Jerison attribution not independently established by admitted original identity/pages.'},
    ],
})

freeze = json.loads((OUT / 'freeze-verification.json').read_text())
access = []
for entry in freeze['files']:
    rec = dict(entry)
    if entry['path'].endswith('.md'):
        rec.update({'access': 'Full line-numbered text display and semantic reading', 'full_read': True, 'bounded_untruncated_full_coverage': True})
    else:
        rec.update({'access': 'tools.view_image at detail original; image result actually emitted and visually inspected', 'native_detail': True, 'actual_visual_inspection': True})
    access.append(rec)
save('actual-access.json', {
    'reviewer': '/root/technical_d015_current',
    'current_whole_freeze': {'path': 'd015-clean-r36-20261012/author/whole-freeze.json', 'sha256': freeze['manifest_sha256'], 'full_read': True},
    'constituent_access': access,
    'current_independent_answer_basis': {'path': 'd015-next-fresh-independent-prompts-r36/independent-answers-and-criteria.txt', 'pre_teaching_sealed': True, 'full_reread_for_comparison': True},
    'source_inventory_basis': {'path': 'd015-next-fresh-independent-technical/source-only-preparation.txt', 'original_only_sealed': True, 'full_reread_for_comparison': True},
    'prior_admissions_carried_forward': [
        {'input': 'original-inputs/D015/**', 'scope': 'Entire original metadata, all five text pages and all five original PNGs previously actually read/viewed; PDF integrity verified.'},
        {'input': 'd013-clean-r34-20261012/inputs/student-baseline.txt', 'scope': 'All 247840 bytes previously read in 19 bounded chunks with initial truncation repaired; no new full read claimed.'},
        {'input': 'published PROF r36 package at final cb5 pin', 'scope': '36 files checked by bytes/hash/blob, 12 required files read fully in earlier admission, full baseline byte-equivalent; all final package bytes identical to admitted c1e31 pin.'},
    ],
    'review_protocol_rechecks': ['Admitted SKILL.md T1-T12 and allowed status rules', 'Admitted execution-protocol.md relevant source, technical, representation and destination requirements'],
    'display_note': 'A redundant combined reread of main.md and protocol search exceeded its outer display budget; the original complete main read already covered all 257 lines. The tail and T1-T12 passage were subsequently displayed separately without truncation. No partial reread is used to establish missing coverage.',
    'forbidden_or_unadmitted_content_opened': [],
    'external_urls_followed': [],
    'live_destination_opened': False,
    'frozen_files_edited': False,
    'published_or_installed_skill_changes': False,
    'scope_limits': ['No author report/check, SASIS result, root answer, old held audit, or nonadmitted sibling teaching read.', 'External contextual citation and author attribution not independently verified by this reviewer.', 'Static link/math inventories do not claim live browser rendering, navigation or destination typography.'],
})

dependencies = [
    ('d015-next-fresh-independent-technical/sourceprep-seal.json', '8034ca1bde51358c3c2ec839b69d3da8d3416e74b5be515d2ad70fbda0393c51'),
    ('d015-next-fresh-independent-technical/SHA256SUMS', '4b4364558c370b1e0407b5d1cb6c097bfd277d9777864ea399b2730d87ad69ae'),
    ('d015-next-fresh-independent-technical-r36-admission/admission-seal.json', '222fe05a8dbd6758a14c4a1ac3591f6037b4a3f96e7f98741dd4629219b80103'),
    ('d015-next-fresh-independent-technical-r36-admission/SHA256SUMS', '1719cfebe171627a1dec0fa29d6f64184eaef625bf2c3f1211345aad14f5f35c'),
    ('d015-next-fresh-independent-technical-r36-admission/final-pin-supplement.json', '8777cd510cfd6327eef5ba1a24b805de3d5170948d47e1903d67a736e5a68899'),
    ('d015-next-fresh-independent-prompts-r36/prompt-answer-seal.json', '7197da9df6689639365a43f91beaa598179a573faceb22220a8b129195597b18'),
    ('d015-next-fresh-independent-prompts-r36/SHA256SUMS', '4d10e5f55d21f63738e6c0fd51e9015e86668c94641e074e10f82552de842940'),
]
prior = []
for rel, expected in dependencies:
    data = (ROOT / rel).read_bytes()
    assert sha(data) == expected, rel
    prior.append({'path': rel, 'bytes': len(data), 'sha256': expected, 'unchanged': True})
save('prior-seal-preservation.json', {'dependency_records': prior, 'all_previous_SHA256SUMS_member_checks_passed': True, 'final_pin_supplement_checksum_passed': True, 'checked_before_current_seal': True})

records = []
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in ('whole-technical-seal.json', 'SHA256SUMS'):
        data = path.read_bytes()
        records.append({'path': path.name, 'bytes': len(data), 'sha256': sha(data)})
seal = {
    'schema': 'd015-independent-whole-technical-seal-v1',
    'sealed_at': datetime.now(timezone.utc).isoformat(),
    'reviewer': '/root/technical_d015_current',
    'source_original_pdf_sha256': 'cdf0e899a0f0dd5a57ca1069a5c039c08b9efb84ef6d416f3dce038939564d23',
    'source_identity_sha256': '5af9ade07d4fbf8367456f62c13ba42a71812be70654385efd2468d718a93f7c',
    'full_baseline_sha256': '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5',
    'prof_final_pin': 'cb5f12cb9762839fade6841c161cdc8c670894cf',
    'prof_final_tree': 'd4540c911dd38d3a85f57547e8f82fba6f019aad',
    'whole_freeze_sha256': freeze['manifest_sha256'],
    'frozen_file_count': 6, 'frozen_bytes': 186982,
    'current_prompts_sha256': '8fc93bf77d91aa2a62ef720358be458acab454b58c8104485df89130e247a2f3',
    'independent_prompt_answers_sealed_before_teaching': True,
    'all_original_demands_and_actual_tasks_reviewed': True,
    'full_main_hints_solutions_read': True,
    'all_three_images_actually_viewed_at_native_detail': True,
    'mathematical_review_status': 'pass',
    'material_mathematical_failures': [],
    'external_contextual_citation_and_author_attribution_status': 'unverified within this reviewer admission; separate root evidence must not be attributed to this reviewer',
    'destination_live_rendering_and_navigation_status': 'unverified by this reviewer; not in this technical review scope',
    'prior_seals_preserved': prior,
    'frozen_teaching_changed': False,
    'report_records': records,
}
save('whole-technical-seal.json', seal)
sealed_paths = sorted(p for p in OUT.iterdir() if p.is_file() and p.name != 'SHA256SUMS')
(OUT / 'SHA256SUMS').write_text(''.join(sha(p.read_bytes()) + '  ' + p.name + '\n' for p in sealed_paths))
print(json.dumps({'report_sha256': sha((OUT/'report.txt').read_bytes()), 'seal_sha256': sha((OUT/'whole-technical-seal.json').read_bytes()), 'manifest_sha256': sha((OUT/'SHA256SUMS').read_bytes()), 'sealed_files': len(sealed_paths), 'report_record_count': len(records)}, indent=2))
