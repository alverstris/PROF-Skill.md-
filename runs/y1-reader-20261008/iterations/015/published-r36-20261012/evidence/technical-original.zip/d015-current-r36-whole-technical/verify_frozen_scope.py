from pathlib import Path
import hashlib
import json
import re
import struct

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
OUT = ROOT / 'd015-current-r36-whole-technical'
BASE = ROOT / 'd015-clean-r36-20261012'
MANIFEST = BASE / 'author/whole-freeze.json'
PROMPTS = BASE / 'author/prompts-only.md'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

assert sha(MANIFEST.read_bytes()) == '0f52edf74fe3bf9794a061880c201e423fbc37faa71416828c6c2bf682c2f3bb'
assert sha(PROMPTS.read_bytes()) == '8fc93bf77d91aa2a62ef720358be458acab454b58c8104485df89130e247a2f3'
manifest = json.loads(MANIFEST.read_text())
verified = []
texts = {}
for entry in manifest['files']:
    path = Path(entry['absolute_path'])
    assert path == BASE / entry['path']
    data = path.read_bytes()
    actual = {
        'path': entry['path'], 'bytes': len(data), 'sha256': sha(data),
        'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
    }
    for key in ('bytes', 'sha256', 'git_blob'):
        assert actual[key] == entry[key], (entry['path'], key)
    if path.suffix == '.md':
        texts[entry['path']] = data.decode()
        actual['lines'] = len(texts[entry['path']].splitlines())
    else:
        assert data[:8] == b'\x89PNG\r\n\x1a\n'
        actual['native_width'], actual['native_height'] = struct.unpack('>II', data[16:24])
    verified.append(actual)
assert len(verified) == manifest['count'] == 6
assert sum(v['bytes'] for v in verified) == manifest['bytes'] == 186982
save('freeze-verification.json', {'manifest_sha256': sha(MANIFEST.read_bytes()), 'files': verified, 'all_match': True})

anchors = {path: set(re.findall(r'<a id="([^"]+)"', body)) for path, body in texts.items()}
all_anchor_names = [anchor for group in anchors.values() for anchor in group]
assert len(all_anchor_names) == len(set(all_anchor_names))
links = []
external = []
math_items = []
for path, body in texts.items():
    for match in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)', body):
        label, href = match.groups()
        line = body.count('\n', 0, match.start()) + 1
        if href.startswith('https://'):
            external.append({'source': path, 'line': line, 'label': label, 'url': href, 'external_target_read': False})
            continue
        file_part, _, fragment = href.partition('#')
        target = str(Path(path).parent / file_part) if file_part else path
        assert target in texts, (path, href)
        assert not fragment or fragment in anchors[target], (path, href)
        links.append({'source': path, 'line': line, 'label': label, 'target': target, 'fragment': fragment, 'static_target_valid': True})
    for match in re.finditer(r'\$`(.*?)`\$|```math\n(.*?)\n```', body, re.S):
        math_items.append({'source': path, 'start_line': body.count('\n', 0, match.start())+1, 'end_line': body.count('\n', 0, match.end())+1, 'type': 'inline' if match.group(1) is not None else 'display', 'expression': match.group(1) if match.group(1) is not None else match.group(2), 'semantic_inspection': 'covered in full-file review', 'destination_rendering': 'not inspected by this reviewer'})
images = []
for match in re.finditer(r'<img src="([^"]+)" alt="([^"]+)" width="(\d+)" height="(\d+)">', texts['teaching/main.md']):
    rel, alt, width, height = match.groups()
    rec = next(v for v in verified if v['path'] == 'teaching/' + rel)
    assert int(width) == rec['native_width'] and int(height) == rec['native_height']
    images.append({'source': 'teaching/main.md', 'line': texts['teaching/main.md'].count('\n', 0, match.start())+1, 'path': rec['path'], 'alt': alt, 'reserved_dimensions_match_native': True, 'native_image_actually_viewed_and_emitted': True})
assert len(images) == 3
save('static-routes-and-math-inventory.json', {'scope': 'Static source checks only; no live destination navigation or formula rendering claimed.', 'links': links, 'external_citations': external, 'images': images, 'unique_anchors': all_anchor_names, 'math_count': len(math_items), 'math_items': math_items})

paragraphs = [p for p in PROMPTS.read_text().split('\n\n') if p.strip()]
actual_task_paragraphs = [p.strip() for p in paragraphs if not p.startswith('D015 prompts only.') and not re.match(r'^Q[1-5] — ', p)]
main = texts['teaching/main.md']
matches = []
for paragraph in actual_task_paragraphs:
    assert main.count(paragraph) == 1
    index = main.index(paragraph)
    matches.append({'main_line': main.count('\n', 0, index)+1, 'paragraph_sha256': sha(paragraph.encode()), 'exact_match': True})
assert len(matches) == 7
save('prompt-equality.json', {'prompt_sha256': sha(PROMPTS.read_bytes()), 'question_groups': 5, 'task_parts': 6, 'paragraphs_including_Q5_timing': 7, 'all_exact_matches': True, 'matches': matches})
print(json.dumps({'frozen_files': len(verified), 'frozen_bytes': sum(v['bytes'] for v in verified), 'static_links': len(links), 'images': len(images), 'math_expressions': len(math_items), 'prompt_paragraphs_equal': len(matches), 'all_checks_passed': True}))
