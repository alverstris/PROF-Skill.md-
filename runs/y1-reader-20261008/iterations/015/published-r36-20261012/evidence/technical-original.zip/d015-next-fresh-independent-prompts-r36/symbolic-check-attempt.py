from pathlib import Path
import hashlib
import json
import sympy as sp


x, y, a = sp.symbols('x y a', real=True)
gaussian = sp.exp(-x**2 / 2)
solutions = [
    ('Q1 initial value 0', sp.Integer(0), lambda z: -x*z, 0, 0, 'all real x'),
    ('Q1 initial value -2', -2*gaussian, lambda z: -x*z, 0, -2, 'all real x'),
    ('Q2 initial value 2', 1+gaussian, lambda z: x*(1-z), 0, 2, 'all real x'),
    ('Q2 initial value 1', sp.Integer(1), lambda z: x*(1-z), 0, 1, 'all real x'),
    ('Q3', -2*x**3, lambda z: 3*z/x, -1, 2, 'x < 0'),
    ('Q4 branch', -sp.sqrt(3-x**2/2), lambda z: -x/(2*z), 2, -1, '0 < x < sqrt(6)'),
    ('Q5(a)', x**2+2, lambda z: 2*x, 1, 3, 'all real x'),
    ('Q5(b)', sp.sqrt(x**2+3), lambda z: x/z, 1, 2, 'x > 0'),
]
solution_checks = []
for name, formula, rhs, x0, y0, domain in solutions:
    residual = sp.simplify(sp.diff(formula, x) - rhs(formula))
    initial_residual = sp.simplify(formula.subs(x, x0) - y0)
    assert residual == 0, name
    assert initial_residual == 0, name
    solution_checks.append({
        'task': name,
        'formula': str(formula),
        'required_domain': domain,
        'differential_equation_residual': str(residual),
        'initial_value_residual': str(initial_residual),
    })

algebra_checks = {
    'Q2 branch primitive derivative': sp.diff(-sp.log(y-1), y) - 1/(1-y),
    'Q3 negative-x primitive derivative': sp.diff(3*sp.log(-x), x) - 3/x,
    'Q3 initial ray slope': sp.Rational(2, -1) - (-2),
    'Q3 initial tangent slope': sp.diff(-2*x**3, x).subs(x, -1) - (-6),
    'Q4 family parameter elimination': sp.diff(a*x**2, x).subs(a, y/x**2) - 2*y/x,
    'Q4 implicit identity': x**2 + 2*(-sp.sqrt(3-x**2/2))**2 - 6,
    'Q4 horizontal semiaxis identity': sp.sqrt(6)**2 - 6,
    'Q4 vertical semiaxis identity': 2*sp.sqrt(3)**2 - 6,
    'Q4 semiaxis ratio': sp.sqrt(6)/sp.sqrt(3) - sp.sqrt(2),
    'Q4 initial slopes product plus one': (-1)*1 + 1,
    'Q5(b) family parameter elimination': sp.diff(a/x, x).subs(a, x*y) - (-y/x),
    'Q5(b) negative reciprocal': -1/(-y/x) - x/y,
    'Q5(b) implicit identity': sp.sqrt(x**2+3)**2 - x**2 - 3,
    'Q5(b) initial slopes product plus one': (-2)*sp.Rational(1, 2) + 1,
}
for label, expression in algebra_checks.items():
    residual = sp.simplify(expression)
    assert residual == 0, label
    algebra_checks[label] = str(residual)

assert sp.simplify(2 < sp.sqrt(6)) is sp.true
assert gaussian.is_positive is True
assert (x**2+3).is_positive is True

result = {
    'verification_scope': 'Only the exact admitted Q1-Q4 and Q5(a,b); no generated question battery.',
    'symbolic_tool': 'SymPy ' + sp.__version__,
    'solution_formula_count': len(solution_checks),
    'solution_checks': solution_checks,
    'algebra_checks': algebra_checks,
    'domain_checks': [
        'Q1 and Q2 formulas are differentiable for every real x.',
        'Q2 exp(-x^2/2) is strictly positive for finite real x, so the initial-2 solution remains above 1.',
        'Q3 x<0 supplies a nonzero denominator; a smooth extension at zero does not define 3y/x there.',
        'Q4 y<0 requires 3-x^2/2>0. Intersecting with x>0 gives (0,sqrt(6)), which contains 2.',
        'Q4 endpoint sqrt(6) has y=0, where -x/(2y) is undefined; zero violates the specified x>0 restriction.',
        'Q5(b) x>0 and sqrt(x^2+3)>0 make both required slopes finite and nonzero.',
    ],
    'limits': 'Zero symbolic residuals apply on the stated domains. Domain interpretation and response criteria were independently checked in the accompanying answer record. No teaching or proposed solution was read.',
}
destination = Path(__file__).with_name('symbolic-verification.json')
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({
    'actual_prompt_solution_formulas_checked': len(solution_checks),
    'all_symbolic_and_initial_residuals_zero': True,
    'algebra_checks': len(algebra_checks),
    'verification_file_sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
}, indent=2))
