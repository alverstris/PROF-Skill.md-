from pathlib import Path
import hashlib
import json
import math


class Dual:
    def __init__(self, value, derivative=0.0):
        self.value = float(value)
        self.derivative = float(derivative)

    @staticmethod
    def coerce(other):
        return other if isinstance(other, Dual) else Dual(other)

    def __add__(self, other):
        other = self.coerce(other)
        return Dual(self.value + other.value, self.derivative + other.derivative)

    __radd__ = __add__

    def __neg__(self):
        return Dual(-self.value, -self.derivative)

    def __sub__(self, other):
        return self + (-self.coerce(other))

    def __rsub__(self, other):
        return self.coerce(other) + (-self)

    def __mul__(self, other):
        other = self.coerce(other)
        return Dual(self.value * other.value,
                    self.derivative * other.value + self.value * other.derivative)

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = self.coerce(other)
        return Dual(self.value / other.value,
                    (self.derivative * other.value - self.value * other.derivative)
                    / other.value**2)

    def __rtruediv__(self, other):
        return self.coerce(other) / self

    def __pow__(self, power):
        return Dual(self.value**power,
                    power * self.value**(power - 1) * self.derivative)


def exp(z):
    z = Dual.coerce(z)
    value = math.exp(z.value)
    return Dual(value, value * z.derivative)


def sqrt(z):
    z = Dual.coerce(z)
    value = math.sqrt(z.value)
    return Dual(value, z.derivative / (2 * value))


def check_close(actual, expected, label):
    assert math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12), (label, actual, expected)
    return actual - expected


gaussian = lambda x: exp(-x**2 / 2)
cases = [
    ('Q1 initial 0', lambda x: Dual(0), lambda x, y: -x*y, 0, 0, [-3, -1, 0, 1, 3]),
    ('Q1 initial -2', lambda x: -2*gaussian(x), lambda x, y: -x*y, 0, -2, [-3, -1, 0, 1, 3]),
    ('Q2 initial 2', lambda x: 1+gaussian(x), lambda x, y: x*(1-y), 0, 2, [-3, -1, 0, 1, 3]),
    ('Q2 initial 1', lambda x: Dual(1), lambda x, y: x*(1-y), 0, 1, [-3, -1, 0, 1, 3]),
    ('Q3', lambda x: -2*x**3, lambda x, y: 3*y/x, -1, 2, [-5, -2, -1, -0.25]),
    ('Q4 branch', lambda x: -sqrt(3-x**2/2), lambda x, y: -x/(2*y), 2, -1, [0.25, 1, 2, 2.4]),
    ('Q5(a)', lambda x: x**2+2, lambda x, y: 2*x, 1, 3, [-3, -1, 0, 1, 3]),
    ('Q5(b)', lambda x: sqrt(x**2+3), lambda x, y: x/y, 1, 2, [0.25, 1, 2, 5]),
]
checks = []
for name, formula, rhs, x0, y0, probes in cases:
    initial_value = formula(Dual(x0, 1)).value
    initial_residual = check_close(initial_value, y0, name + ' initial condition')
    samples = []
    for value in probes:
        output = formula(Dual(value, 1))
        residual = check_close(output.derivative, rhs(value, output.value), name + ' ODE')
        samples.append({'x': value, 'y': output.value, 'derivative': output.derivative,
                        'original_equation_rhs': rhs(value, output.value), 'residual': residual})
    checks.append({'task': name, 'initial_residual': initial_residual, 'samples': samples})

geometric_checks = {
    'Q3 ray slope': check_close(2 / -1, -2, 'Q3 ray'),
    'Q3 tangent slope': check_close((-2*Dual(-1, 1)**3).derivative, -6, 'Q3 tangent'),
    'Q4 implicit equation at P': check_close(2**2 + 2*(-1)**2, 6, 'Q4 implicit P'),
    'Q4 x semiaxis': check_close(math.sqrt(6)**2, 6, 'Q4 x semiaxis'),
    'Q4 y semiaxis': check_close(2*math.sqrt(3)**2, 6, 'Q4 y semiaxis'),
    'Q4 semiaxis ratio': check_close(math.sqrt(6)/math.sqrt(3), math.sqrt(2), 'Q4 ratio'),
    'Q4 slopes product': check_close((-1)*1, -1, 'Q4 perpendicular'),
    'Q5(b) implicit equation at P': check_close(2**2-1**2, 3, 'Q5(b) implicit P'),
    'Q5(b) slopes product': check_close((-2)*0.5, -1, 'Q5(b) perpendicular'),
}
for record in checks:
    if record['task'] == 'Q2 initial 2':
        assert all(s['y'] > 1 for s in record['samples'])
    if record['task'] == 'Q4 branch':
        for s in record['samples']:
            assert 0 < s['x'] < math.sqrt(6) and s['y'] < 0
            check_close(s['x']**2+2*s['y']**2, 6, 'Q4 branch implicit identity')
    if record['task'] == 'Q5(b)':
        for s in record['samples']:
            assert s['x'] > 0 and s['y'] > 0
            check_close(s['y']**2-s['x']**2, 3, 'Q5(b) branch implicit identity')
assert 0 < 2 < math.sqrt(6)

result = {
    'scope': 'Only actual Q1-Q4 and Q5(a,b) formulas and their mathematical checks.',
    'method': 'Standard-library forward-mode automatic differentiation of the proposed formulas, compared against each original right side, plus initial, slope and implicit-identity checks.',
    'number_of_solution_formulas': len(checks),
    'number_of_ODE_sample_checks': sum(len(c['samples']) for c in checks),
    'relative_tolerance': 1e-12,
    'absolute_tolerance': 1e-12,
    'all_checks_passed': True,
    'solution_checks': checks,
    'geometric_checks': geometric_checks,
    'limits': 'These are supplementary numerical checks, not symbolic proofs or evidence of unseen teaching adequacy. General identities and exact domain conditions are proved in independent-answers-and-criteria.txt. SymPy was unavailable; its failed attempt is preserved separately.',
}
destination = Path(__file__).with_name('numerical-verification.json')
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({
    'solution_formulas_checked': len(checks),
    'ODE_sample_checks': result['number_of_ODE_sample_checks'],
    'all_checks_passed': True,
    'verification_file_sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
}, indent=2))
