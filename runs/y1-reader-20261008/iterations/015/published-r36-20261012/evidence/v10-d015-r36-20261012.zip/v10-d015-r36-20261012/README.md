# Restricted destination preservation comparator v10

This tool compares one exact frozen Markdown source with one root-captured actual immutable GitHub article DOM. It is preservation QA only, never a scientific, subject-matter or SASIS reviewer. It does not operate a browser or establish navigation, visual clipping, geometry or image loading.

Run without Python optimization:

```sh
python compare_destination_preservation_v10.py --source /absolute/source.md --capture /absolute/capture.json --source-sha256 EXACT_SHA256 --output-dir /absolute/new-report-directory
```

Exit 0 means the supported comparison passed; 1 means a preserved structure/type/prose/link/image/anchor comparison failed; 2 means unsupported or invalid input. Existing reports are not overwritten. Unsupported inputs require explicit inspection; do not silently broaden normalization or waive preservation.

V9 remains unchanged. V10 adds only two witnessed compatibility forms:

- D015 capture records containing exactly ordinal and mathML, with a timestamp named at. The tool recovers each type from the matching actual article math-renderer class and style, requires the witnessed renderer attributes, and separately compares source type and MathML display. It never infers actual type from source. Unknown, inconsistent or duplicate wrapper metadata fails explicitly. Full embedded MathML strings still must equal the capture array in order.
- HTML PNG dimension pairs 900x500, 900x560 and 900x600. Exact source/capture dimensions, alt text, image and wrapper destinations, and height-specific GitHub style remain required. No geometry is inferred. Other new sizes/attributes/styles fail explicitly.

The mathematical parser, tokens, structure comparison and all expression records are byte-for-byte identical to v9. Existing documented v9 normalization still applies; there is no new mathematical equivalence. Whole prose is compared after documented markup/whitespace normalization only. Explicit anchors retain their id/name family and expected GitHub user-content prefix.

The actual main-page witness is frozen D015 r36 main.md and the root-provided DOM at immutable commit 97e10125d66e612e3f0446ab1f8460c6fd4064a5. The v9 initial failure is retained separately in root-review-d015-r36/destination/main/v9-initial/attempt.json. Main v10 compares all 138 expressions, complete prose, 15 text links, 6 anchors and 3 images.

Four targeted synthetic negative checks cover inconsistent renderer class/style, a coherent wrapper type change conflicting with unchanged source/MathML, unknown source width901, and incorrect actual max-height. All fail as required. These temporary modified captures are tests, never live evidence. The test script and exact mutation/results are retained. No browser or view_image call is made.
