#!/usr/bin/env python3
"""Targeted negative checks for v10's observed schema and image-dimension changes.
Only synthetic temporary copies are modified; frozen source/capture remain intact.
"""
from pathlib import Path
import copy,hashlib,json,subprocess,tempfile
ROOT=Path('/workspace/scratch/f9c0b7fc7e76')
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'d015-clean-r36-20261012/teaching/main.md'
CAPTURE=ROOT/'root-review-d015-r36/destination/d015-r36-main-cold-dom.json'
TOOL=HERE/'compare_destination_preservation_v10.py'
def sha(b):return hashlib.sha256(b).hexdigest()
sraw=SOURCE.read_bytes();craw=CAPTURE.read_bytes()
assert sha(sraw)=='cb1798c3320123993edb5bab5f1136037e4367272441576522f11f099de68054'
assert sha(craw)=='cbdf2179c0fc72fdc10a372ad1633e13133f50c4b292aa6998a7a0cb31b5393d'
source=sraw.decode();dom=json.loads(craw)
cases=[('wrong_wrapper_class_style',2,'Unsupported or inconsistent actual renderer class/style'),('consistent_wrapper_type_change',1,None),('unsupported_source_width',2,'Unsupported source HTML image path/dimensions'),('wrong_actual_max_height',2,'Unsupported actual HTML image added style')]
results=[]
with tempfile.TemporaryDirectory(prefix='d015-v10-negatives-') as tmp:
 for name,expected,reason in cases:
  s=source;d=copy.deepcopy(dom)
  if name=='wrong_wrapper_class_style':
   before='class="js-inline-math" style="display: inline-block"';after='class="js-display-math" style="display: inline-block"'
   assert before in d['articleHTML'];d['articleHTML']=d['articleHTML'].replace(before,after,1)
   mutation={'target':'actual first math-renderer class','old':'js-inline-math','new':'js-display-math','style_left_unchanged':True}
  elif name=='consistent_wrapper_type_change':
   before='class="js-inline-math" style="display: inline-block"';after='class="js-display-math" style="display: block"'
   assert before in d['articleHTML'];d['articleHTML']=d['articleHTML'].replace(before,after,1)
   mutation={'target':'actual first math-renderer class/style','old':before,'new':after,'source_and_mathml_left_unchanged':True}
  elif name=='unsupported_source_width':
   assert 'width="900"' in s;s=s.replace('width="900"','width="901"',1)
   mutation={'target':'first source img width','old':'900','new':'901'}
  else:
   assert 'max-height: 500px;' in d['articleHTML'];d['articleHTML']=d['articleHTML'].replace('max-height: 500px;','max-height: 501px;',1)
   mutation={'target':'first actual image style','old':'max-height: 500px;','new':'max-height: 501px;'}
  td=Path(tmp)/name;td.mkdir();sp=td/'source.md';cp=td/'capture.json';sp.write_text(s);cp.write_text(json.dumps(d,ensure_ascii=False));output=td/'output'
  args=['python',str(TOOL),'--source',str(sp),'--capture',str(cp),'--source-sha256',sha(sp.read_bytes()),'--output-dir',str(output)]
  p=subprocess.run(args,capture_output=True,text=True)
  assert p.returncode==expected,(name,p.returncode,p.stdout,p.stderr)
  if reason:assert reason in p.stderr,(name,p.stderr)
  witness={}
  if name=='consistent_wrapper_type_change':
   report=json.loads((output/'math-preservation.json').read_text());first=report['math_records'][0]
   assert report['verdict']=='FAIL' and first['structural_match'] and not first['types_match']
   assert first['type']=='inline' and first['actual_type']=='display' and first['mathml_type']=='inline'
   witness={k:first[k] for k in ['ordinal','type','actual_type','mathml_type','types_match','structural_match']}
  results.append({'name':name,'synthetic_mutation':mutation,'expected_exit':expected,'actual_exit':p.returncode,'expected_error_substring':reason,'stderr':p.stderr,'stdout_sha256':sha(p.stdout.encode()),'witness':witness,'passed':True})
assert SOURCE.read_bytes()==sraw and CAPTURE.read_bytes()==craw
report={'scope':'Synthetic negative checks only for concrete v10 metadata/dimension risks; not independent live destination evidence.','tool_sha256':sha(TOOL.read_bytes()),'source_sha256':sha(sraw),'capture_sha256':sha(craw),'original_inputs_unchanged':True,'tests':results,'all_passed':True}
(HERE/'targeted-negative-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'all_passed':True,'count':len(results),'report_sha256':sha((HERE/'targeted-negative-checks.json').read_bytes())}))
