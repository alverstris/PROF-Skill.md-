# Restricted destination preservation comparator v11

Preservation-only comparison of exact frozen Markdown and actual immutable GitHub DOM. Never SASIS, science, geometry, navigation or semantic-teaching evaluation. No browser/tool invocation is performed.

V11 preserves v10 unchanged and adds only the witnessed D015 hints/solutions capture labels inline/block. Before mapping those strings to legacy js-inline-math/js-display-math metadata, every record must agree with the actual MathML display and exact matching actual renderer class/style. Array order and embedded MathML exact strings remain required. A discrepancy is rejected explicitly; no actual type is inferred from source. V10's ordinal/mathML-only main-page capture support remains present.

No mathematical token, canonical structure, parser, expression record loop or mathematical equality is changed. All other existing restrictions remain. Unsupported syntax/metadata still fails explicitly. Whole-prose, link, image, explicit-anchor, and expression-type comparisons remain required.

Run without optimization:

```sh
python compare_destination_preservation_v11.py --source /absolute/source.md --capture /absolute/capture.json --source-sha256 EXACT_SHA256 --output-dir /absolute/new-report-directory
```

Exit0 means all supported preservation comparisons passed; exit1 means a comparison failed; exit2 means unsupported/invalid input. Existing reports are never overwritten.

Both initial v10 label failures are retained under root-review-d015-r36/destination/{hints,solutions}/v10-initial/attempt.json. V11 actual comparisons cover all13 hints and all62 solution expressions. Two targeted synthetic negative checks demonstrate rejection when captured metadata conflicts with MathML or article wrappers. These modified temporary inputs are never represented as actual evidence. The separately sealed v10 main report still covers all138 main expressions, and its four negative checks remain unchanged.
