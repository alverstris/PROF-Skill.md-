#!/usr/bin/env python3
"""Two synthetic negative checks for the witnessed v11 metadata-label adapter."""
from pathlib import Path
import copy,hashlib,json,subprocess,tempfile
ROOT=Path('/workspace/scratch/f9c0b7fc7e76');HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'d015-clean-r36-20261012/teaching/hints.md';CAPTURE=ROOT/'root-review-d015-r36/destination/d015-r36-hints-dom.json';TOOL=HERE/'compare_destination_preservation_v11.py'
def sha(b):return hashlib.sha256(b).hexdigest()
sraw=SOURCE.read_bytes();craw=CAPTURE.read_bytes();d0=json.loads(craw)
assert sha(sraw)=='213956c9eeea4cc7f9d8ce2a31239bb94c814eecc3e9bf0d7cdbcfa91563e204'
assert sha(craw)=='8e0bf378934887838fcdabb5d07602254adf6fcbc149e25b62d5e405a6854838'
results=[]
with tempfile.TemporaryDirectory(prefix='d015-v11-negatives-') as tmp:
 for name in ['metadata_mathml_conflict','metadata_wrapper_conflict']:
  d=copy.deepcopy(d0)
  if name=='metadata_mathml_conflict':
   assert d['math'][0]['display']=='inline';d['math'][0]['display']='block'
   reason='Capture display metadata differs from actual MathML'
   mutation={'target':'first captured display label','old':'inline','new':'block','mathml_and_wrapper_unchanged':True}
  else:
   before='class="js-inline-math" style="display: inline-block"';after='class="js-display-math" style="display: block"'
   assert before in d['articleHTML'];d['articleHTML']=d['articleHTML'].replace(before,after,1)
   reason='Capture display metadata differs from actual renderer class/style'
   mutation={'target':'first actual renderer class/style','old':before,'new':after,'mathml_and_metadata_unchanged':True}
  td=Path(tmp)/name;td.mkdir();cp=td/'capture.json';cp.write_text(json.dumps(d,ensure_ascii=False))
  args=['python',str(TOOL),'--source',str(SOURCE),'--capture',str(cp),'--source-sha256',sha(sraw),'--output-dir',str(td/'output')]
  p=subprocess.run(args,capture_output=True,text=True)
  assert p.returncode==2 and reason in p.stderr,(name,p.returncode,p.stdout,p.stderr)
  results.append({'name':name,'synthetic_mutation':mutation,'expected_exit':2,'actual_exit':p.returncode,'stderr':p.stderr,'passed':True})
assert SOURCE.read_bytes()==sraw and CAPTURE.read_bytes()==craw
r={'scope':'Synthetic metadata negative checks; never live capture evidence.','source_sha256':sha(sraw),'capture_sha256':sha(craw),'tool_sha256':sha(TOOL.read_bytes()),'original_inputs_unchanged':True,'tests':results,'all_passed':True}
(HERE/'targeted-negative-checks.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'all_passed':True,'tests':len(results),'report_sha256':sha((HERE/'targeted-negative-checks.json').read_bytes())}))
