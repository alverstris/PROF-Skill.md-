from pathlib import Path
import json,re,hashlib,importlib.util,difflib
from html.parser import HTMLParser
p=Path(__file__).parent;r=p.parents[5];commit='a968fe34a61d5b250c6ab35c468156313f68a372';manifest=json.loads((p/'frozen-manifest-copy.json').read_text());spec=importlib.util.spec_from_file_location('h',r/'runs/y1-reader-20261008/iterations/008/render-evidence/r15-v2/dependency-review_helpers.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
class Page(HTMLParser):
 def __init__(self):super().__init__();self.on=False;self.parts=[];self.css=[]
 def handle_starttag(self,t,a):
  a=dict(a)
  if t=='script' and a.get('data-target')=='react-app.embeddedData':self.on=True
  if t=='link' and a.get('rel')=='stylesheet':self.css.append(a.get('href'))
 def handle_endtag(self,t):
  if t=='script':self.on=False
 def handle_data(self,d):
  if self.on:self.parts.append(d)
def save(f,v):
 with f.open('x') as out:json.dump(v,out,ensure_ascii=False,indent=2);out.write('\n')
norm=lambda s:re.sub(r'\s+',' ',s).strip();summary=[];failure=[]
for name in ['teaching','hints','solutions']:
 d=p/name;source=p.parent/'author'/f'{name}.md';s=source.read_text();page=Page();page.feed((d/'github-page.html').read_text());data=json.loads(''.join(page.parts));article=data['payload']['codeViewBlobRoute']['richText'];(d/'github-article.html').write_text(article);a=h.DestinationArticle();a.feed(article);tokens=h.math_tokens(s);actual=a.math_payloads();rawnodes=re.findall(r'<math-renderer\b[^>]*>.*?</math-renderer>',article,re.S)
 for x in tokens:
  x['source_line']=s[:x['span'][0]].count('\n')+1;labels=re.findall(r'^(C\d+\.|P\d+\.|Hint P\d+|Solution P\d+|Figure \d+\.)',s[:x['span'][0]],re.M);x['label']=labels[-1] if labels else 'opening'
 comp=h.compare_math(tokens,actual);save(d/'source-math.json',tokens);save(d/'destination-math.json',actual);save(d/'math-comparison.json',comp)
 meta=next(x for x in manifest['files'] if x['path']==name+'.md');save(d/'destination-identity.json',h.destination_identity(data,source.read_bytes(),commit,str(source.relative_to(r)),meta['sha256']))
 protected=[]
 def replace(m):
  x=tokens[len(protected)];delim='$$' if x['type']=='js-display-math' else '$';protected.append(delim+x['payload']+delim);return 'MATHPLACEHOLDER'+str(len(protected)-1)+'END'
 expected=h.MATH.sub(replace,s);expected=re.sub(r'<a (?:name|id)="[^"]+"></a>','',expected);expected=re.sub(r'!\[[^\]]*\]\([^)]*\)','',expected);expected=re.sub(r'\[([^\]]*)\]\([^)]*\)',r'\1',expected);expected=re.sub(r'^\d+\. ', '',expected,flags=re.M);expected=re.sub(r'MATHPLACEHOLDER(\d+)END',lambda m:protected[int(m[1])],expected);expected=norm(expected);actualtext=norm(''.join(a.text));(d/'expected-prose-math-stream.txt').write_text(expected+'\n');(d/'actual-prose-math-stream.txt').write_text(actualtext+'\n');changes=[dict(operation=op,source=expected[i:j],actual=actualtext[k:l],source_context=expected[max(0,i-60):j+60]) for op,i,j,k,l in difflib.SequenceMatcher(a=expected,b=actualtext,autojunk=False).get_opcodes() if op!='equal'];save(d/'prose-comparison.json',dict(exact_after_whitespace_folding=expected==actualtext,changes=changes,list_marker_scope='Six ordered-list number markers compared separately; HTMLParser text omits generated CSS list numbers.'))
 save(d/'navigation.json',dict(targets=a.targets,links=a.links));save(d/'element-style-evidence.json',dict(tags=a.tags,inline_styles=a.inline_styles,elements=a.elements,css_urls=page.css));save(d/'image-markup.json',[x['attrs'] for x in a.elements if x['tag']=='img'])
 mismatches=[]
 if len(tokens)==len(actual):
  for i,(x,y) in enumerate(zip(tokens,actual),1):
   if (x['type'],x['payload'])!=(y['type'],y['payload']):
    row=dict(file=name+'.md',ordinal=i,label=x['label'],source_line=x['source_line'],source_span=x['span'],source_type=x['type'],destination_type=y['type'],source=x['payload'],actual=y['payload'],raw_HTML=rawnodes[i-1],destination_element=y['element'],literal_entity_instances=re.findall(r'&(?:lt|gt);',y['payload']));mismatches.append(row);failure.append(row)
 save(d/'complete-math-failure-map.json',mismatches);summary.append(dict(file=name+'.md',source_count=len(tokens),destination_count=len(actual),inline_count=sum(x['type']=='js-inline-math' for x in tokens),display_count=sum(x['type']=='js-display-math' for x in tokens),all_math_exact=comp['exact_all'],mismatch_count=len(mismatches),literal_comparison_entities=sum(len(x['literal_entity_instances']) for x in mismatches),prose_math_exact=expected==actualtext,targets=len(a.targets),links=len(a.links),images=a.tags.get('img',0)))
save(p/'parser-summary.json',summary);save(p/'complete-math-failure-map.json',failure);print(json.dumps(summary,indent=2))
