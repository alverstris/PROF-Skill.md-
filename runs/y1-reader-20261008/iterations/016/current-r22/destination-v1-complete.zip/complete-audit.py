from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urljoin,urlparse
import json,re,hashlib,difflib,fitz
from PIL import Image
p=Path(__file__).parent;commit='a968fe34a61d5b250c6ab35c468156313f68a372';prefix='/alverstris/PROF-Skill.md-/blob/'+commit+'/runs/y1-reader-20261008/iterations/016/current-r22/author/';names=['teaching','hints','solutions'];norm=lambda s:re.sub(r'\s+',' ',s).strip()
def read(n):return json.loads((p/n).read_text())
def save(n,v):
 with (p/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
class Pars(HTMLParser):
 def __init__(self):super().__init__();self.on=None;self.parts=[];self.rows=[];self.lists=[]
 def handle_starttag(self,t,a):
  if t in ['p','li']:self.on=t;self.parts=[]
  if t in ['ol','ul']:self.lists.append(dict(tag=t,attributes=dict(a)))
 def handle_data(self,s):
  if self.on:self.parts.append(s)
 def handle_endtag(self,t):
  if t==self.on:self.rows.append(dict(tag=t,text=norm(''.join(self.parts))));self.on=None
nav={n:read(n+'/navigation.json') for n in names};labels=[];prose=[];docs=[];styles=[];images=[]
def mask(text,tokens):
 out='';pos=0
 for i,x in enumerate(tokens):
  delim='$$' if x['type']=='js-display-math' else '$';needle=norm(delim+x['payload']+delim);at=text.find(needle,pos);assert at>=0,(i,needle);out+=text[pos:at]+f'MATHNODE{i:03d}';pos=at+len(needle)
 return out+text[pos:]
regex=r'^(?:C\d+\.|P\d+\.|Hint P\d+|Solution P\d+|Figure \d+\.|Reading route$|Source and scope$|Definition and existence condition\.|Worked case\.)'
for n in names:
 s=(p/'remote'/f'{n}.md').read_text();a=Pars();a.feed((p/n/'github-article.html').read_text());sl=re.findall(regex,s,re.M);dl=[m[0] for row in a.rows if (m:=re.match(regex,row['text']))];labels.append(dict(file=n+'.md',source_paragraph_labels=sl,actual_paragraph_start_labels=dl,exact=sl==dl,source_part_labels=re.findall(r'^\([abc]\)',s,re.M),actual_part_labels=[m[0] for row in a.rows if (m:=re.match(r'^\([abc]\)',row['text']))],actual_lists=a.lists,source_list_markers=re.findall(r'^\s*(?:\d+\.|[-*+]) ',s,re.M)))
 sp=mask((p/n/'expected-prose-math-stream.txt').read_text().strip(),read(n+'/source-math.json'));dp=mask((p/n/'actual-prose-math-stream.txt').read_text().strip(),read(n+'/destination-math.json'));(p/n/'source-prose-with-math-placeholders.txt').write_text(sp+'\n');(p/n/'destination-prose-with-math-placeholders.txt').write_text(dp+'\n');prose.append(dict(file=n+'.md',all_nonmath_prose_exact=sp==dp,complete_prose_math_exact=read(n+'/prose-comparison.json')['exact_after_whitespace_folding']))
 ids=re.findall(r'<a name="([^"]+)"></a>',s);hrefs=re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',s);actual=[x for x in nav[n]['links'] if '/figures/' not in x['href']];expected=[urljoin('https://github.com'+prefix+n+'.md',h).removeprefix('https://github.com') for h in hrefs];docs.append(dict(file=n+'.md',source_ids=ids,actual_targets=nav[n]['targets'],all_targets_exact=[x['value'] for x in nav[n]['targets']]==['user-content-'+i for i in ids],all_targets_unique=len(ids)==len(set(ids)),source_hrefs=hrefs,expected_actual_hrefs=expected,actual_nonimage_links=actual,all_source_hrefs_exact=[x['href'] for x in actual]==expected))
 st=read(n+'/element-style-evidence.json');styles.append(dict(file=n+'.md',tags=st['tags'],inline_styles=st['inline_styles'],no_emphasis_nodes=not any(st['tags'].get(t,0) for t in ['b','strong','i','em','h1','h2','h3','h4','h5','h6','th','dt'])))
 srcimgs=re.findall(r'!\[([^\]]*)\]\(([^)]+)\)',s);actualimgs=read(n+'/image-markup.json');images.append(dict(file=n+'.md',source_images=srcimgs,actual_images=actualimgs,count_equal=len(srcimgs)==len(actualimgs),all_alt_exact=[x[0] for x in srcimgs]==[x.get('alt') for x in actualimgs],all_src_bound=all(x[1] in y.get('src','') and commit in y.get('src','') for x,y in zip(srcimgs,actualimgs))))
save('paragraph-label-list-check.json',labels);save('full-prose-check.json',prose);save('image-reference-check.json',images)
def sec(n,target):
 ts=nav[n]['targets'];start=next(x['element'] for x in ts if x['value']=='user-content-'+target);end=min([x['element'] for x in ts if x['element']>start]+[10**9]);return [x['href'] for x in nav[n]['links'] if start<x['element']<end]
chains=[]
for i in range(1,5):
 q=sec('teaching',f'p{i}');h=sec('hints',f'h{i}');s=sec('solutions',f's{i}');checks=dict(task_to_hint=prefix+f'hints.md#h{i}' in q,hint_to_solution=prefix+f'solutions.md#s{i}' in h,hint_to_task=prefix+f'teaching.md#p{i}' in h,solution_to_task=prefix+f'teaching.md#p{i}' in s);chains.append(dict(task=f'P{i}',checks=checks,all_required_routes=all(checks.values()),observed_links=dict(task=q,hint=h,solution=s)))
resolved=[]
for d in docs:
 for x in d['actual_nonimage_links']:
  if x['href'].startswith(prefix):
   file,_,frag=x['href'][len(prefix):].partition('#');nn=file.removesuffix('.md');count=sum(t['value']=='user-content-'+frag for t in nav[nn]['targets']) if frag else None;resolved.append(dict(from_file=d['file'],href=x['href'],target=file,fragment=frag or None,unique_fragment=count==1 if frag else None,valid=count==1 if frag else nn in names))
save('positive-navigation-audit.json',dict(documents=docs,positive_chains=chains,all4_chains_complete=all(x['all_required_routes'] for x in chains),named_targets=sum(len(x['source_ids']) for x in docs),crossfile_refs=resolved,all_crossfile_refs_valid=all(x['valid'] for x in resolved),global_hints_solutions_link=prefix+'solutions.md' in [x['href'] for x in nav['hints']['links']],help_separation='Distinct immutable hints and solutions files. Task-to-solution is intentionally a two-step matched P→H→S route; no direct per-task P→S link claimed.',mapping_scope='Actual immutable href rewrite and user-content- named target prefix correspondence, not literal fragment/name equality; client mapping/clicks unobserved.'))
positions=[]
for row in read('complete-math-failure-map.json'):
 s=(p/'remote'/row['file']).read_text();at=row['source_span'][0]+2;assert row['source'].replace('<','&lt;').replace('>','&gt;')==row['actual']
 for m in re.finditer('[<>]',row['source']):
  offset=at+m.start();before=s[:offset];positions.append(dict(file=row['file'],math_ordinal=row['ordinal'],line=before.count('\n')+1,column=offset-before.rfind('\n'),character_offset=offset,UTF8_byte_offset=len(before.encode()),source_character=m[0],actual_literal_entity='&lt;' if m[0]=='<' else '&gt;',source_payload=row['source'],actual_payload=row['actual']))
save('comparison-character-failures.json',positions)
css=[]
for f in (p/'css').glob('*.css'):
 for m in re.finditer(r'([^{}]+)\{([^{}]*)\}',f.read_text()):
  sel,body=m.groups()
  if ('markdown-body' in sel or sel.strip() in ['body','p','a','article','li']) and any(x in body for x in ['font-style','font-weight']):css.append(dict(file=f.name,selector=sel,declarations=body))
save('css-font-rules.json',css);save('style-audit.json',dict(documents=styles,fetched_css=len(list((p/'css').glob('*.css'))),scope='Fetched stylesheet rules and actual document nodes; no live computed styles or browser pixels. Inspect css-font-rules.json for applicable base and exceptional selectors.'))
assets=[]
for x in read('initial-fetch.json'):
 if not x['path'].startswith('remote/'):continue
 row=dict(x)
 if x['path'].endswith('.png'):row.update(dimensions=list(Image.open(p/x['path']).size),full_frame_visually_inspected=True)
 assets.append(row)
save('asset-manifest.json',assets)
files=[p/'official-source-lec18.pdf',p/'frozen-source-lec18.pdf',p.parent/'source/lec18.pdf'];shas=[hashlib.sha256(f.read_bytes()).hexdigest() for f in files];doc=fitz.open(files[0]);save('source-PDF-identity.json',dict(files=[str(f) for f in files],hashes=shas,all_three_exact=len(set(shas))==1,bytes=files[0].stat().st_size,pages=len(doc),first_page_text=doc[0].get_text(),identity_scope='Fresh official MIT and immutable repository bytes versus local frozen source; first-page identity text checked. Full source technical reading belongs to root/author evidence, not asserted here.'))
print(json.dumps(dict(labels=[{'file':x['file'],'count':len(x['source_paragraph_labels']),'exact':x['exact']} for x in labels],prose=prose,targets=12,refs=len(resolved),all_routes=all(x['all_required_routes'] for x in chains),css=len(list((p/'css').glob('*.css'))),failures=len(positions),source_identity=len(set(shas))==1),indent=2))
