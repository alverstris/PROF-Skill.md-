from pathlib import Path
import json,subprocess,concurrent.futures,hashlib
p=Path(__file__).parent;commit='a968fe34a61d5b250c6ab35c468156313f68a372';css=sorted({u for n in ['teaching','hints','solutions'] for u in json.loads((p/n/'element-style-evidence.json').read_text())['css_urls'] if u});(p/'css').mkdir();items=[(u,p/'css'/Path(u).name,'css') for u in css];manifest=json.loads((p.parent/'source-manifest.json').read_text());(p/'source-manifest-copy.json').write_text(json.dumps(manifest,indent=2)+'\n');prefix='https://raw.githubusercontent.com/alverstris/PROF-Skill.md-/'+commit+'/runs/y1-reader-20261008/iterations/016/current-r22/'
items += [(manifest['url'],p/'official-source-lec18.pdf','source'),(prefix+'source/lec18.pdf',p/'frozen-source-lec18.pdf','source')]
def get(it):
 url,f,kind=it;q=subprocess.run(['curl','-L','--fail','--max-time','55','--silent','--show-error',url,'-o',str(f)],capture_output=True,text=True);v=dict(url=url,file=str(f.relative_to(p)),kind=kind,exit=q.returncode,stderr=q.stderr)
 if q.returncode==0:v.update(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 return v
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:rows=list(pool.map(get,items))
(p/'support-fetch.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'items':len(rows),'failures':[x for x in rows if x['exit']]}))
