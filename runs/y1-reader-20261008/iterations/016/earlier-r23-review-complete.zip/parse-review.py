from pathlib import Path
from html.parser import HTMLParser
import re,json,importlib.util,hashlib,collections
p=Path(__file__).parent;r=p.parents[4];spec=importlib.util.spec_from_file_location('h',r/'runs/y1-reader-20261008/iterations/008/render-evidence/r15-v2/dependency-review_helpers.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(f,v):
 with f.open('x') as o:json.dump(v,o,ensure_ascii=False,indent=2);o.write('\n')
class Page(HTMLParser):
 def __init__(self):super().__init__();self.on=False;self.parts=[]
 def handle_starttag(self,t,a):
  if t=='script' and dict(a).get('data-target')=='react-app.embeddedData':self.on=True
 def handle_endtag(self,t):
  if t=='script':self.on=False
 def handle_data(self,s):
  if self.on:self.parts.append(s)
summary=[];allcomparisons=[];allfailures=[];allboundaries=[]
for rec in json.loads((p/'accepted-binding.json').read_text()):
 d=p/rec['outdir'];s=(d/'accepted-source.md').read_text();page=Page();page.feed((d/'github-page.html').read_text());data=json.loads(''.join(page.parts));article=data['payload']['codeViewBlobRoute']['richText'];(d/'github-article.html').write_text(article);a=h.DestinationArticle();a.feed(article);src=h.math_tokens(s);actual=a.math_payloads();identity=h.destination_identity(data,(d/'accepted-source.md').read_bytes(),rec['commit'],rec['accepted_path'],rec['sha256']);identity['fresh_raw_exact']=(d/'fresh-raw.md').read_bytes()==(d/'accepted-source.md').read_bytes();save(d/'identity.json',identity)
 correspond=[];comparisons=[];failures=[];counts=collections.Counter();mask=list(s)
 for i,x in enumerate(src):
  y=actual[i] if i<len(actual) else None;line=s[:x['span'][0]].count('\n')+1;row=dict(ordinal=i+1,source_line=line,source_format=x['format'],source_type=x['type'],source_span=x['span'],source_payload=x['payload'],actual=y,exact=y is not None and x['type']==y['type'] and x['payload']==y['payload']);correspond.append(row);counts[x['format']]+=1
  for j in range(*x['span']):
   if mask[j]!='\n':mask[j]=' '
  operators=[dict(offset=m.start(),spelling=m[0],next_character=x['payload'][m.end():m.end()+1],terminated_by_space=x['payload'][m.end():m.end()+1]==' ') for m in re.finditer(r'[<>]|\\(?:lt|gt)(?![A-Za-z])|\\(?:less|greater)',x['payload'])]
  if operators:
   v=dict(case=rec['case'],file=rec['accepted_path'],**row,operators=operators,candidate_conditional_scope=x['format']=='protected');comparisons.append(v);allcomparisons.append(v)
  if not row['exact']:failures.append(row);allfailures.append(dict(case=rec['case'],file=rec['accepted_path'],**row))
 remainder=''.join(mask);boundaries=[]
 for kind,pat in [('HTML',r'<!--.*?-->|</?[A-Za-z][^>]*>'),('fenced_code',r'^(`{3,}|~{3,})[^\n]*\n.*?^\1[ \t]*$'),('inline_code',r'`+[^`\n]*`+')]:
  for m in re.finditer(pat,remainder,re.M|re.S):boundaries.append(dict(kind=kind,line=s[:m.start()].count('\n')+1,span=[m.start(),m.end()],exact_source=s[m.start():m.end()],strict_characters=re.findall('[<>]',s[m.start():m.end()])))
 outside_angles=[dict(line=s[:m.start()].count('\n')+1,offset=m.start(),character=m[0],context=s[max(0,m.start()-35):m.start()+45]) for m in re.finditer('[<>]',remainder)];residual=[dict(line=s[:m.start()].count('\n')+1,text=m[0]) for m in re.finditer(r'\$|`',remainder)]
 save(d/'expression-correspondence.json',correspond);save(d/'math-comparison.json',h.compare_math(src,actual));save(d/'comparison-occurrences.json',comparisons);save(d/'over-application-boundaries.json',dict(nonmath_HTML_code_spans=boundaries,all_outside_math_angle_chars=outside_angles,residual_dollar_backtick_tokens=residual,note='Original bytes are unchanged. Candidate rule targets only protected-inline math; no global replacement was performed. Fenced/displays and plain-dollar math outside conditional scope retained and compared.'))
 rawprotected=[x for x in comparisons if x['candidate_conditional_scope'] and any(y['spelling'] in '<>' for y in x['operators'])];badspace=[x for x in comparisons if x['candidate_conditional_scope'] and any(y['spelling'] in ['\\lt','\\gt'] and not y['terminated_by_space'] for y in x['operators'])]
 v=dict(case=rec['case'],file=rec['accepted_path'],commit=rec['commit'],source_sha256=rec['sha256'],raw_exact=identity['fresh_raw_exact'],identity_checks=identity,source_nodes=len(src),actual_nodes=len(actual),formats=dict(counts),all_math_exact=len(src)==len(actual) and all(x['exact'] for x in correspond),math_failures=len(failures),comparison_payloads=len(comparisons),operator_occurrences=sum(len(x['operators']) for x in comparisons),protected_inline_comparison_payloads=sum(x['candidate_conditional_scope'] for x in comparisons),raw_angles_in_protected_payloads=len(rawprotected),protected_command_payloads_without_literal_space=len(badspace),boundary_spans=len(boundaries),outside_math_angle_characters=len(outside_angles),residual_delimiter_tokens=len(residual),historical_provenance='Generated under earlier controls, not regenerated under candidate r23-1. Fresh candidate-affected read-only source/parser check only.');summary.append(v);allboundaries.append(dict(case=rec['case'],file=rec['accepted_path'],spans=boundaries))
save(p/'full-scan-summary.json',summary);save(p/'all-comparison-occurrences.json',allcomparisons);save(p/'fresh-parser-failures.json',allfailures);save(p/'all-boundary-spans.json',allboundaries)
print(json.dumps([{k:v for k,v in x.items() if k in ['case','source_nodes','all_math_exact','comparison_payloads','operator_occurrences','formats','raw_angles_in_protected_payloads','protected_command_payloads_without_literal_space','boundary_spans','residual_delimiter_tokens']} for x in summary],indent=2))
