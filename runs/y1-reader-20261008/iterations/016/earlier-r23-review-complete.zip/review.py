from pathlib import Path
import json,re,hashlib,importlib.util,subprocess,concurrent.futures,shutil
p=Path(__file__).parent;r=p.parents[4];run=r/'runs/y1-reader-20261008';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
data=[
(1,'teaching-v4.md','0716ea92991d7f9fe2814e137bcc830d91a27511','402485baa2767af9625146721e356f92bad76e4cfb738e5729c6c8b94ea79401'),
(2,'teaching-v1.md','f1c0e91c24e9140049d50c7ca965f41e36f3e1a2','8139080278edb96287576629e7d80933b380c1b82af60d3ede888d500cb68a3a'),
(3,'teaching-v1.md','4cbf83f2dc2859d5123fc01a0c311a268d580483','cd7426a9b70d0ac41aa3ca0418db8c89c391b67304016a7ad38f8379fe98b5a8'),
(4,'teaching-v1.md','197b57555834d36952e948d4100d2f835c86b20c','5adb3e95c2fa47c94b4c665d85dc2fe669e2c0086dbc2ebc194cd59720d5d8ad'),
(5,'teaching-v2.md','32c553f279ac1e5771ff05b78a9951cbff3fee38','4ae6d0f33e2957ebaf3bbd31c34e154c4a7c5eaab4bc3a09a9e909574b1a48e6'),
(6,'regenerated-r13-candidate1/teaching-v3.md','28825d27b93baef43a5751eacecac81fa46841bc','311afdef083a4468f18bcdd11a68975d2e6622661e0be3405a5c9f58b3f3a813'),
(7,'revised-v3/teaching-v3.md','2c0a49dff10d407296675a9d52a2d664be1bb0f0','6dc2823d9f931c1baaa6eb4ce5076ed2aef1859ba29255d5503eed627824ae54'),
(8,'revised-r15-v2/teaching-r15-v2.md','a6b7aaaf2ded04bb6b0c2da2528234d36ca2f6d4','b6e93b986e2a77763c556a4b5fc5cb42f43269742d0af9bd06021d7aa3ad7668'),
(9,'resumption-20261009/author/teaching-r15-recovery-v3.md','9840e70de6aa7d2c718b60dd13ace7e6f795a50e','5c9e307b08931099316a2d12149ab3d1cd3a75ba2ae75bc48ef60a77b562c244'),
(10,'current-r16/author/teaching-v2.md','629feb501ffd69447b70011d852ece5bf8a04641','192609d9d62cc50be534df77b5e5700c6eb7c4a9c32e37c832be6b1ab133742c'),
(11,'current-r17/author/teaching-v3.md','d493bae7f5f680e33f2fa891c5d0310bf43e5d23','bcb390a295a8cce423b8ebfb9d292c45f7e6be3e37b9fbed1e33c6f60153f6fe'),
(12,'current-r18/author/teaching-v2.md','12f468d985cbc1cb462e41948f0f017a161a2099','04355b5ac132bfdaecf6a165cf332d0e04a0ff29bd59b53e03d6c801c9838d59'),
(13,'current-r19/author/learner-v2.md','ea627ac47e24cd309a3e7b75a4ecfd070e54a3b5','d17f77d36f7c30db9777230a85decb363a1fb967bb5c51d60cb5af4cd7b078c0'),
(14,'current-r20/author/teaching-v2.md','40151288dfc73314e6efb7ef74794dfa75a0a5ee','caf74a9a150f61d2531e8b2768abb1448fb7d5304818a9e1fcc73d02bead826b'),
(15,'current-r21/author/v2/teaching.md','f531ccd1a3ec4b4918b96fbab30a7f6d8c03aafa','9ff76d7dde73d2270b511421f428e5e3324176bc1666728ea013ec8f0512c4b4'),
(15,'current-r21/author/v2/hints.md','f531ccd1a3ec4b4918b96fbab30a7f6d8c03aafa','19bf8adb1b6c71a3fdfa65588612e90e8c2431917807c78d7db3ab952fa4f1b5'),
(15,'current-r21/author/v2/solutions.md','f531ccd1a3ec4b4918b96fbab30a7f6d8c03aafa','9f6a2b4117df5902a1d964de411830e6af4e61862d6ef80d5cc38991be766855')]
queue=json.loads((run/'queue.json').read_text());records=[];items=[]
for i,rel,commit,expected in data:
 case=f'D{i:03}';local=run/'iterations'/f'{i:03}'/rel;repo=str(local.relative_to(r));out=p/case/Path(rel).stem;out.mkdir(parents=True,exist_ok=True);q=next(x for x in queue['sessions'] if x.get('material_id')==case);assert q['status']=='closed';assert sha(local)==expected,(case,sha(local),expected)
 record=dict(case=case,accepted_path=repo,commit=commit,sha256=expected,bytes=local.stat().st_size,queue_status=q['status'],queue_document_commit=q.get('document_commit'),queue_document_revision=q.get('document_revision'),historical_incoming_prof=q.get('incoming_prof'),historical_outgoing_prof=q.get('outgoing_prof'),closure=str((run/'iterations'/f'{i:03}'/'closure.md').relative_to(r)),closure_sha256=sha(run/'iterations'/f'{i:03}'/'closure.md'),outdir=str(out.relative_to(p)));records.append(record)
 if q.get('document_commit'):assert q['document_commit']==commit
 shutil.copyfile(local,out/'accepted-source.md');shutil.copyfile(run/'iterations'/f'{i:03}'/'closure.md',p/case/'closure-copy.md')
 items += [('https://raw.githubusercontent.com/alverstris/PROF-Skill.md-/'+commit+'/'+repo,out/'fresh-raw.md'),('https://github.com/alverstris/PROF-Skill.md-/blob/'+commit+'/'+repo,out/'github-page.html')]
(p/'accepted-binding.json').write_text(json.dumps(records,indent=2)+'\n');(p/'queue-selected-copy.json').write_text(json.dumps([x for x in queue['sessions'] if x.get('material_id') in {f'D{i:03}' for i in range(1,16)}],indent=2)+'\n')
def get(it):
 url,f=it;q=subprocess.run(['curl','-L','--fail','--max-time','55','--silent','--show-error',url,'-o',str(f)],capture_output=True,text=True);v=dict(url=url,file=str(f.relative_to(p)),exit=q.returncode,stderr=q.stderr)
 if q.returncode==0:v.update(bytes=f.stat().st_size,sha256=sha(f))
 return v
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:out=list(pool.map(get,items))
(p/'fresh-fetch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'documents':len(records),'fetches':len(out),'failures':[x for x in out if x['exit']]}))
