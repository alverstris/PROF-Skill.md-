from pathlib import Path
import re,json,collections
p=Path(__file__).parent;records=json.load(open(p/'accepted-binding.json'));rows=[]
pattern=re.compile(r'<!--.*?-->|</?[A-Za-z][A-Za-z0-9:-]*(?:\s+[^<>]*?)?\s*/?>',re.S)
for rec in records:
 d=p/rec['outdir'];s=(d/'accepted-source.md').read_text();chars=list(s)
 for x in json.load(open(d/'expression-correspondence.json')):
  for j in range(*x['source_span']):
   if chars[j]!='\n':chars[j]=' '
 remainder=''.join(chars);spans=[]
 for m in pattern.finditer(remainder):
  spans.append(dict(line=s[:m.start()].count('\n')+1,span=[m.start(),m.end()],HTML=m[0]))
  for j in range(m.start(),m.end()):
   if chars[j]!='\n':chars[j]=' '
 other=''.join(chars);outside=[]
 for m in re.finditer('[<>]',other):
  line=s[:m.start()].count('\n')+1;start=s.rfind('\n',0,m.start())+1;end=s.find('\n',m.start());end=len(s) if end<0 else end;outside.append(dict(line=line,offset=m.start(),character=m[0],whole_source_line=s[start:end]))
 rows.append(dict(case=rec['case'],file=rec['accepted_path'],valid_HTML_spans=spans,valid_HTML_span_count=len(spans),angle_characters_in_literal_nonmath_prose=outside,nonmath_code_spans=[],note='Supersedes loose HTML candidate extraction in initial over-application-boundaries.json/all-boundary-spans.json; original unmodified. Strict tag syntax prevents <ln( or <u( prose from consuming subsequent anchors.'))
with (p/'corrected-boundary-inventory.json').open('x') as f:json.dump(rows,f,ensure_ascii=False,indent=2);f.write('\n')
with (p/'boundary-adapter-resolution.json').open('x') as f:json.dump({'original_attempt':'boundary-review.py fed Markdown to HTMLParser and failed anchor mapping','second_attempt':'boundary-review-corrected.py fed initial loose HTML candidate spans; D013 nonmath prose <ln( and <u( still overmatched through subsequent anchors','final_attempt':'boundary-review-final.py uses syntactically constrained HTML tags/comments; all source anchor mappings exact after GitHub user-content- prefix','corrected_inventory':'corrected-boundary-inventory.json','initial_candidate_spans':952,'actual_HTML_spans':sum(x['valid_HTML_span_count'] for x in rows),'literal_nonmath_prose_angle_characters':sum(len(x['angle_characters_in_literal_nonmath_prose']) for x in rows),'code_spans':0,'classification':'Two preserved review-adapter errors, no learner mutation or math comparison failure; complete actual math comparisons were unaffected.'},f,indent=2);f.write('\n')
print(json.dumps({'HTML_spans':sum(x['valid_HTML_span_count'] for x in rows),'prose_angle_characters':sum(len(x['angle_characters_in_literal_nonmath_prose']) for x in rows),'per_case_prose_angles':[(x['case'],len(x['angle_characters_in_literal_nonmath_prose'])) for x in rows if x['angle_characters_in_literal_nonmath_prose']]}))
