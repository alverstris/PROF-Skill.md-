from pathlib import Path
import json,hashlib,base64,datetime,io
from collections import OrderedDict
from PIL import Image

R=Path(__file__).parent; Q=R/'reader-route'
def h(b):return hashlib.sha256(b).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def dt(x):return datetime.datetime.fromisoformat(x)
route=json.loads((Q/'route.json').read_bytes());seal=json.loads((Q/'route-seal.json').read_bytes())
assert h((Q/'route.json').read_bytes())==seal['route_sha256']
assert h((Q/'read-step').read_bytes())==seal['launcher_sha256']
files={f['id']:f for f in route['files']};steps={s['id']:s for s in route['steps']}
revisits={r['id']:r['initial_step_id'] for r in route['revisits']}
for f in files.values():
 b=Path(f['path']).read_bytes();assert len(b)==f['size'] and h(b)==f['sha256']
planned=[]
for s in route['steps']:
 planned.append(s['id'])
 if s['kind']=='figure':planned.append(s['receipt_step_id'])
events=[];calls=OrderedDict();previous='0'*64
raw=(Q/'runtime/ledger.jsonl').read_bytes();assert raw.endswith(b'\n')
for i,line in enumerate(raw.splitlines()):
 e=json.loads(line);digest=e.pop('sha256');assert e['index']==i and e['previous']==previous and h(canon(e))==digest
 e['sha256']=digest;previous=digest;events.append(e);calls.setdefault(e['call_id'],[]).append(e)
actual=[];returned=[];retrieved=0;textbytes=0
result_paths=list((Q/'reader-evidence').glob('*exec-result.json'))
used=set()
for cid,es in calls.items():
 assert es[0]['event']=='call_attempt' and es[-1]['event']=='call_finished'
 assert es[-1]['data']['outcome']=='success',('rejection or incomplete call',cid)
 argv=es[0]['data']['argv'];assert len(argv)==1;sid=argv[0];actual.append(sid)
 rs=[p for p in result_paths if p.name.startswith(sid+'-') and p not in used];assert len(rs)==1,(sid,rs)
 p=rs[0];used.add(p);result=json.loads(p.read_bytes());assert result['exit_code']==0 and 'session_id' not in result
 out=result['output'].encode('utf-8');assert 'Warning: truncated output' not in result['output']
 validation=[e for e in es if e['event']=='route_validated'];assert len(validation)==1
 assert validation[0]['data']['route_sha256']==seal['route_sha256']
 outputs=[e for e in es if e['event']=='stdout_complete'];assert len(outputs)==1
 o=outputs[0];assert len(out)==o['data']['bytes'] and h(out)==o['data']['sha256']
 commit=[e for e in es if e['event']=='state_commit'];assert len(commit)==1 and o['index']<commit[0]['index']
 accesses=[e for e in es if e['event']=='actual_access']
 if sid in steps or sid in revisits:
  initial=revisits.get(sid,sid)
  if sid in revisits:assert initial in actual[:-1]
  s=steps[initial];f=files[s['file_id']];assert len(accesses)==1
  a=accesses[0];start,end=(s['start'],s['end']) if s['kind']=='text' else (0,f['size'])
  b=Path(f['path']).read_bytes()[start:end]
  assert a['data']['path']==f['path'] and a['data']['start']==start and a['data']['end']==end
  assert a['data']['verified'] is True and a['data']['sha256']==h(b)==s['sha256'] and a['data']['bytes']==len(b)
  assert a['index']<next(e['index'] for e in es if e['event']=='stdout_begin')
  retrieved+=len(b)
  if s['kind']=='text':assert out==b;textbytes+=len(b)
  else:assert json.loads(out)['image_sha256']==f['sha256']
 else:
  assert not accesses and sid.startswith('V')
 returned.append({'step_id':sid,'exec_result':str(p.relative_to(R)),'exec_result_sha256':h(p.read_bytes()),'stdout_bytes':len(out),'stdout_sha256':h(out)})
assert [x for x in actual if x not in revisits]==planned,(actual,planned)
assert len(used)==len(result_paths)==len(actual)
figures=[]
for s in route['steps']:
 if s['kind']!='figure':continue
 f=files[s['file_id']];sid=s['id'];receiptpath=Path(s['receipt_file']);receipt=json.loads(receiptpath.read_bytes())
 resultpath=Q/f'view-evidence/{sid}-actual-result.json';result=json.loads(resultpath.read_bytes())
 meta=json.loads((Q/f'view-evidence/{sid}-invocation.json').read_bytes())
 assert result['detail']=='original' and meta['invocation']==receipt['invocation']=={'path':f['path'],'detail':'original'}
 url=result['image_url'];head,payload=url.split(',',1);assert head in ['data:image/png;base64','data:application/octet-stream;base64']
 decoded=base64.b64decode(payload,validate=True);original=Path(f['path']).read_bytes()
 assert decoded==original and h(decoded)==f['sha256']
 image=Image.open(io.BytesIO(decoded));assert image.format=='PNG';image.verify();image=Image.open(io.BytesIO(decoded));size=image.size
 assert receipt['result_metadata']['mime_type']==head.removeprefix('data:').removesuffix(';base64')
 assert receipt['result_metadata']['image_url_sha256']==h(url.encode()) and receipt['result_metadata']['image_url_chars']==len(url)
 assert receipt['tool_call_id']==meta['invocation_receipt_id'] and meta['host_tool_call_id'] is None
 accepted=[e for e in events if e['event']=='figure_receipt_accepted' and e['data']['figure_step_id']==sid];assert len(accepted)==1
 assert accepted[0]['data']['receipt']==receipt and accepted[0]['data']['receipt_sha256']==h(receiptpath.read_bytes())
 dispatch=next(e for e in events if e['event']=='state_commit' and e['data']['step_id']==sid)
 assert dt(dispatch['at'])<=dt(meta['started_at'])<=dt(meta['completed_at'])==dt(receipt['completed_at'])<=dt(accepted[0]['at'])
 figures.append({'step_id':sid,'actual_result':str(resultpath.relative_to(R)),'actual_result_sha256':h(resultpath.read_bytes()),'decoded_bytes':len(decoded),'decoded_sha256':h(decoded),'exact_original_bytes':True,'native_dimensions':list(size),'stored_receipt_matches_actual_result':True,'chronology_verified':True})
report=Q/'reader-evidence/original-reader-report.md';assert report.is_file() and report.stat().st_size>0
res={'status':'PASS: complete actual access and original image-byte reconciliation','route_sha256':seal['route_sha256'],'launcher_sha256':seal['launcher_sha256'],'ledger_sha256':h(raw),'ledger_events':len(events),'calls':len(calls),'scheduled_ids':planned,'retrieved_subject_bytes':retrieved,'complete_text_bytes':textbytes,'returned_call_results':returned,'actual_figures':figures,'reader_report_sha256':h(report.read_bytes()),'limits':['Instruction-confined retrieval is not technical isolation or erased pretraining.','Original serialized tool results and timestamp receipts are preserved; no host tool call ID or cryptographic tool attestation was exposed.','This reconciliation verifies actual saved access/results; semantic admission requires reading the original report and checking its passage-level warrants.']}
(R/'evidence/reader-access-reconciliation.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:v for k,v in res.items() if k not in ['returned_call_results','actual_figures','scheduled_ids']},indent=2))
