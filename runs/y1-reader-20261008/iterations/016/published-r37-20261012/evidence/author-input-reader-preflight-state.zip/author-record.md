D016 author record — r37

Authorization and confinement

The exact operational handover is inputs/operational-handover.json. Root dispatched this fresh fork:none author with sole GitHub publication ownership, root retaining browser ownership and independent review coordination. Only the manifested current package, complete baseline, original six-page source, filtered queue, generic launcher and targeted primary-source research are admitted before whole freeze. No predecessor teaching, findings, raw queue or sibling workspace was opened. This is instruction confinement, not technical isolation or memory erasure.

Input admission and actual reads

evidence/input-admission.json records exact-byte admission of all 55 inputs and actual immutable Git blobs for all 36 package files. Root SKILL.md was read in lines 1–150 then 151–166; the initial combined tool output clipped a short T6/T7 span and lines 76–110 were reread to recover it. Execution protocol, domain patterns, SASIS protocol, profile manifest, reader role/contract, rewrite guide, state-tool, findings/rationale and execution research were read completely. LaTeX guidance is inapplicable to the explicitly repo-native product.

The full 247,840-byte baseline was read in eleven consecutive bounded binary slices, exactly [0,24480), [24480,48485), [48485,72527), [72527,96812), [96812,120715), [120715,145213), [145213,169380), [169380,193738), [193738,218185), [218185,242194), [242194,247840). Receipt hashes and actual raw-LF positions appear in evidence/author-baseline-access.jsonl. All output was visible without clipping. Raw-LF lines count 1–1377; CR CR LF sequences make Python splitlines counts different. Chunk boundaries preserve every byte; adjacent chunks continue any equation spanning the boundary.

Baseline supplied premises: Mathematics raw-LF 99–108 supplies finite sums and ordinary convergence; lines 175–206 supplies integral/antiderivative distinction, rectangle-limit interpretation, signed area, substitution and splitting; lines 228–230 supplies monotone endpoint bounds. FM23 supplies exact sums of i and i². FM30 supplies average value. Further Mathematics' remaining Pure/Statistics/Mechanics, Physics and Chemistry were also read in full; they supply units and physical accumulation but do not add an unstated proof of Riemann integrability or square-pyramid volume. Exact prerequisite locators will be checked against text before final audit; these summaries do not replace it.

All six original PNG/text pairs were read. Saved original view results are evidence/source-view-1.json through source-view-6.json, including returned image_url bytes. The cover is original PDF p1. PDF p2 introduces cumulative totals/averages/areas, generic rectangles and x² sum; p3 contains x² rectangle figure and square staircase geometry; p4 completes the squeeze, line/triangle example and area-derivative pattern; p5 supplies arbitrary sample-point Riemann sums and simple-interest borrowing setup; p6 completes principal and weighted debt integrals. No portion excluded.

Source corrections and bridges

PDF p3 calls the bounding solids prisms, but its drawing and one-third base-area-times-height formula describe pyramids. Teach square pyramids explicitly, with centred cross-section side lengths proving containment. Supply the volume rule as an introduced geometric fact; do not claim to derive it from the same integral being established.

PDF p6 labels the accumulated borrowed amount dollars per year. Multiplying rate dollars/year by time years yields dollars. Correct both the teaching and interpretation. Monthly sampling of a varying continuous borrowing rate is an approximation; a stated constant monthly rate makes that month's product exact. Continuous borrowing and end-of-month lump borrowing are different models.

The source's general definition suppresses existence/sample-independence hypotheses and its area wording suppresses sign. Define Riemann integrability by one finite limit for all allowed samples. Introduce continuous and bounded finite-jump sufficient conditions with their meaning before use. The x² rectangle limit can be checked with baseline sums as well as the assigned geometric squeeze. State that finite-sum changes at a single jump point can be nonzero, then bound them by a constant times mesh width tending to zero.

Targeted research actually read

OpenStax Calculus Volume 1 §5.2, https://openstax.org/books/calculus-volume-1/pages/5-2-the-definite-integral, definition and theorem/remarks at web lines 35–62, retrieved 2026-10-12 (turn139view0). The limit is conditional on existence; continuous closed-interval functions and finitely many jump discontinuities are integrable; nonuniform partitions need maximum width tending to zero. Use only those facts as introduced theorem statements; no new empirical claims.

OpenStax Calculus Volume 1 §6.2, https://openstax.org/books/calculus-volume-1/pages/6-2-determining-volumes-by-slicing, opening and Example 6.6 at web lines 31 and 59–79, retrieved 2026-10-12 (turn140view0). It states the geometric pyramid formula V=Ah/3 and illustrates similar-triangle cross-section scaling. Its calculus derivation is not used to prove the x² integral here. The formula is a supplied geometric premise. Primary textbook identity and official URL were verified with both search engines and the actual page passage.

Coverage and teaching plan

C1 — rate/height times width, equal partition, sample point, sum versus limit, integrand/bounds/dummy variable: opening rectangle construction and P1.
C2 — x² right sum on [0,b], exact sums, finite error, arbitrary-sample bounds: main worked case and P2 shifted interval.
C3 — original square staircase, top/side views, inner/outer pyramids, volume squeeze: separate connected continuation and P3 changed enclosing height.
C4 — x triangle, derivative of area examples and continuous accumulation theorem, signed integral and average: connected second case and P4.
C5 — borrowing function, year/month conversion, principal, simple-interest age, weighted integral, finite versus limiting model: final worked case and P5; P6 revisits construction and transfers to a jump rate.

All capabilities have T5–T8 applicable. P1 is early supported application; P2/P3 change representation/controlling geometry; P4 integrates sign/derivative/average; P5 builds the weighted model; P6 provides later retrieval and a changed rate shape. Each has criterion, separate hint and fully reasoned solution. Ordinary algebra and baseline integration rules are compressed. No observed learner errors are asserted.

Freeze staging

prompts-only.md was frozen before any supplied teaching/solutions were authored: 4178 bytes, SHA256 2aa230e38600fe49787bb8720eedb1c2b82b48c9f130d17b86d78686e828d7dd. Root received the exact packet and will hold independent answers until the complete teaching/help/figure freeze. Generated teaching is preserved unmodified after whole freeze. Current checks are pending; no teaching acceptance is claimed.
