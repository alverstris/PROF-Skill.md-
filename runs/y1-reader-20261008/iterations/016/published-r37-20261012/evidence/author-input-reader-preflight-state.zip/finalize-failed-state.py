from pathlib import Path
import json,hashlib,subprocess,shutil
R=Path(__file__).parent
W=R.parent
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
copies={
'root-final-disposition.md':W/'root-review-d016-r37/final-disposition.md',
'root-destination-review.md':W/'root-review-d016-r37/destination/destination-review.md',
'independent-final-mechanical-report.md':W/'root-independent-reader-mechanics/d016-r37/final/report.md',
'independent-control-recovery-addendum.md':W/'root-independent-reader-mechanics/d016-r37/final/control-recovery-addendum/report.md'}
for name,src in copies.items():
 dst=R/'evidence'/name
 if dst.exists():assert dst.read_bytes()==src.read_bytes()
 else:shutil.copyfile(src,dst)
def witness(name,phrase):
 p=R/'evidence'/name
 assert phrase in p.read_text()
 return {'path':'evidence/'+name,'sha256':sha(p),'locator':{'kind':'text','value':phrase}}
w=witness('root-final-disposition.md','Decision: keep D016 open.')
d=witness('root-final-disposition.md','Actual GitHub preservation covers all 257 mathematics expressions, 47 text links, four images and 21 anchors.')
td=json.loads((R/'evidence/current-topic-dependencies.json').read_text())
topic=R/'.prof-state/topics/definite-integrals.json';t=json.loads(topic.read_text())
for key,status,reason,ev in [
 ('T10','fail','Confirmed general directional claim exceeds its stated parameter domain; correct numerical examples do not validate it. Frozen teaching is preserved; r38 reusable execution repair and fresh complete generation required.',w),
 ('T11','pass','Whole actual GitHub main, hints and solutions inspected; all 257 mathematics expressions, 47 text links, 21 anchors, four figures and 43 actual local click routes verified. Preserved server errors and no observed pending-to-loaded transition remain explicit limits.',d),
 ('T12','pass','Whole source, baseline, teaching/help, independent calculations, native figures, fresh reader, actual returned bytes and destination audits are complete. Failure is reported honestly, no acceptance or human-learning claim. Operational late-preservation/output-recovery limits remain recorded.',w)]:
  t['requirements'][key].update(status=status,reason=reason,evidence=[ev],dependencies=td)
write(topic,t)
mp=R/'.prof-state/manifest.json';m=json.loads(mp.read_text());deps=json.loads((R/'evidence/current-global-dependencies.json').read_text())
for c in m['output_checks']:
 if c['id'] in ['technical','sasis']:
  c.update(status='fail',reason='Whole review complete; verified material general sign/domain claim remains in immutable r37 teaching. The fresh reader and independent/root follow-up support this precise failure. Operational delivery is reconciled separately.',evidence=[w],dependencies=deps)
 elif c['id']=='destination':
  c.update(status='pass',reason='Actual GitHub whole visual, expression/prose preservation and all 43 local routes completed, with errors and observational limits preserved.',evidence=[d],dependencies=deps)
 elif c['id']=='final_review':
  c.update(status='pass',reason='All required whole audits completed and precise failed-generation disposition recorded. This completed review is not teaching acceptance.',evidence=[w],dependencies=deps)
write(mp,m)
(R/'.prof-state/RUN.md').write_text('D016 r37 failed-generation recovery index\n\nIncoming verified PROF: inputs/prof at fa7ba01be035d64a5c72cc5037d484fb9afe245f. Exact task and whitelist remain inputs/operational-handover.json and input-identities.json. Seven frozen teaching files remain unchanged under whole-freeze-manifest.json and teaching commit 4ca83e8b709f1e52a1bd2a3a2d612ab48722c195.\n\nWhole author, independent technical, root source/prompt/whole, admitted chronological fresh reader, actual subject-byte/PNG reconciliation and GitHub destination audits are complete. Root final disposition is evidence/root-final-disposition.md. General sign/domain prose failure makes T10 and global technical/SASIS fail; correct numerical examples and contextual P3 orientation remain valid. Helper NOT_READY is the expected honest result, not a reason to alter frozen teaching.\n\nAll 49 subject launcher results and four actual image returns are preserved. Seven control transcript results were preserved late without rereading, with their provenance and independent targeted addendum; immediate-capture and host-authentication limits remain. The parse-failed report-write attempt and successful original report are retained; root resolved the output-only recovery. All 43 live local routes and complete mathematics/prose/images pass with server errors and observational limits retained.\n\nSubstantive candidate-prof-r38 strengthens existing general qualitative/domain checks through a claim-specific declared-domain/sign-order witness. Provisional metadata-only candidate is separately preserved. Publish complete r38 and evidence, verify actual bytes, then root dispatches a new no-history D016 author with only original inputs and verified current package. Counts remain 16 accepted, 60 pending, 71 excluded; D016 active. Earlier affected-success checks remain independently in progress and block final acceptance until resolved. No corpus completion or human-learning outcome claimed.\n')
for name,args in [('full',[]),('topic',['--topic','definite-integrals'])]:
 p=subprocess.run(['python',str(R/'inputs/prof/scripts/prof_state.py'),'check','--state',str(R/'.prof-state'),*args],capture_output=True,text=True)
 write(R/f'evidence/final-helper-{name}-check.json',{'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 print(name,p.returncode,p.stdout)
