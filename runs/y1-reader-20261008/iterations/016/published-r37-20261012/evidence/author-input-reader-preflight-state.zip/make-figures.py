from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon
import numpy as np

p=Path(__file__).parent/'teaching/figures';p.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.size':12,'font.family':'DejaVu Sans','font.weight':'normal','axes.titleweight':'normal','axes.labelweight':'normal','figure.facecolor':'white','savefig.facecolor':'white'})
blue='#245b96'; orange='#b85319'; green='#24774c'

fig,axs=plt.subplots(1,2,figsize=(10,4),layout='constrained')
x=np.linspace(0,2,300)
for ax in axs:
    ax.plot(x,x*x,color=blue,lw=2,label='curve: y = x²');ax.set(xlim=(-.08,2.12),ylim=(-.2,4.7),xlabel='x',ylabel='y');ax.grid(alpha=.18)
for i in range(1,5):
    c=i/2;axs[0].add_patch(Rectangle((c-.5,0),.5,c*c,facecolor=blue,edgecolor=blue,alpha=.16));axs[0].plot(c,c*c,'o',color=blue,ms=4)
axs[0].set_title('Four right-endpoint rectangles')
axs[0].text(.08,4.25,'width = 1/2',color=blue)
c=1.3;axs[1].add_patch(Rectangle((1,0),.5,c*c,facecolor=orange,edgecolor=orange,alpha=.22));axs[1].plot([c,c],[0,c*c],'--',color=orange);axs[1].plot(c,c*c,'o',color=orange)
axs[1].set_title('One sample inside its own interval')
axs[1].text(c+.06,.24,'c = 1.3',color=orange);axs[1].annotate('height = f(c)',xy=(1.5,c*c),xytext=(.08,3.65),arrowprops={'arrowstyle':'->','color':orange},color=orange)
axs[1].set_xticks([0,1,1.5,2]);axs[0].set_xticks([0,.5,1,1.5,2])
fig.savefig(p/'rectangles.png',dpi=150);plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(10,5),layout='constrained')
for k in [4,3,2,1]:axs[0].add_patch(Rectangle((-k/2,-k/2),k,k,fill=False,lw=1.8,edgecolor=blue))
axs[0].set_aspect('equal');axs[0].set(xlim=(-2.8,2.8),ylim=(-2.6,2.6),xlabel='horizontal coordinate',ylabel='horizontal coordinate');axs[0].set_title('Top view: sides 4, 3, 2, 1');axs[0].set_xticks([-2,0,2]);axs[0].set_yticks([-2,0,2])
for j in range(1,5):
    k=5-j;axs[1].add_patch(Rectangle((-k/2,j-1),k,1,facecolor=blue,edgecolor=blue,alpha=.24))
axs[1].plot([-2,0,2],[0,4,0],color=green,lw=2,label='inner: base side 4, height 4')
axs[1].plot([-2.5,0,2.5],[0,5,0],color=orange,lw=2,label='outer: base side 5, height 5')
axs[1].set(xlim=(-2.9,2.9),ylim=(-.1,5.5),xlabel='horizontal coordinate through axis',ylabel='height z');axs[1].set_title('Central vertical cross-section')
axs[1].legend(loc='upper center',bbox_to_anchor=(.5,-.14),frameon=False,fontsize=10);axs[1].set_yticks([0,1,2,3,4,5]);axs[1].grid(alpha=.15)
fig.savefig(p/'pyramid-stack.png',dpi=150);plt.close(fig)

fig,ax=plt.subplots(figsize=(7,4),layout='constrained')
ax.add_patch(Polygon([(0,0),(2,0),(2,2)],color=blue,alpha=.2));ax.plot([0,2.25],[0,2.25],color=blue,lw=2);ax.plot([2,2],[0,2],color=blue);ax.axhline(0,color='#444',lw=1);ax.axvline(0,color='#444',lw=1)
ax.set(xlim=(-.15,2.65),ylim=(-.15,2.55),xlabel='x',ylabel='y');ax.set_xticks([0,2],['0','b']);ax.set_yticks([0,2],['0','b']);ax.text(.65,.27,'area = b²/2',color=blue);ax.text(1.8,2.35,'y = x',color=blue);ax.set_title('The linear case: base b and height b')
fig.savefig(p/'triangle.png',dpi=150);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,2.7),layout='constrained')
ax.set(xlim=(-.07,1.08),ylim=(-.9,1.15));ax.axis('off')
ax.annotate('',xy=(1.03,0),xytext=(-.03,0),arrowprops={'arrowstyle':'->','lw':1.8,'color':'#444'})
for t,label in [(0,'start: 0'),(.35,'borrow: c'),(1,'repay: T')]:
    ax.plot([t,t],[-.08,.08],color='#444');ax.text(t,-.2,label,ha='center',va='top')
ax.annotate('',xy=(1,.52),xytext=(.35,.52),arrowprops={'arrowstyle':'<->','lw':1.5,'color':orange});ax.text(.675,.62,'age at repayment = T − c',ha='center',color=orange)
ax.text(.35,-.61,'small principal: f(c) Δt',ha='center',color=blue);ax.text(1,-.61,'owes: f(c) Δt [1 + r(T − c)]',ha='right',color=blue)
ax.text(.02,1,'Each contribution has its own remaining interest time',ha='left')
fig.savefig(p/'borrowing-time.png',dpi=150);plt.close(fig)
