from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).parent; W=R.parent; P=R/'publication'
PREFIX='runs/y1-reader-20261008/iterations/016/published-r37-20261012/'
ARCH='runs/y1-reader-20261008/source-audit-archives/'
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()}
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
own=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R)
 if '__pycache__' in rel.parts:continue
 if rel.parts[0]=='publication' and (p.suffix=='.zip' or p.name.endswith('.manifest.json') or 'root-archive-parts' in rel.parts or p.name.startswith('release-') or p.name.startswith('r38-publish-')):continue
 own.append(p)
zpath=P/'author-input-reader-preflight-state.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in own:z.write(p,p.relative_to(R).as_posix())
members=[]
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 for p in own:
  n=p.relative_to(R).as_posix();assert z.read(n)==p.read_bytes();members.append({'path':n,**ident(p)})
write(P/'author-input-reader-preflight-state.manifest.json',{'archive':zpath.name,**ident(zpath),'count':len(members),'member_bytes':sum(x['bytes'] for x in members),'members':members,'all_members_verified':True})
plan=[]
def add(local,dest,kind):
 p=Path(local);plan.append({'local':str(p),'path':dest,'kind':kind,**ident(p)})
package=json.loads((P/'r38-repair-package-check.json').read_text())
for x in package['files']:add(R/'candidate-prof-r38'/x['path'],x['path'],'current_prof_package')
for x in json.loads((P/'staged-blob-plan.json').read_text())[:10]:add(x['local'],x['path'],'preserved_evidence')
for n in ['technical-concern-followup.zip','technical-concern-followup.manifest.json','author-input-reader-preflight-state.zip','author-input-reader-preflight-state.manifest.json']:
 add(P/n,PREFIX+'evidence/'+n,'current_evidence_archive')
for n in ['v12-d016-r37-20261012.zip','v12-d016-r37-20261012-manifest.json','d016-r37-root-review-20261012.manifest.json','d016-r37-reader-recovery-20261012.zip','d016-r37-reader-recovery-20261012.manifest.json','d016-r38-candidate-admission-20261012.zip','d016-r38-candidate-admission-20261012.manifest.json']:
 add(W/'source-audit-archives'/n,ARCH+n,'preserved_evidence')
for p in sorted((P/'root-archive-parts').iterdir()):add(p,ARCH+'d016-r37-root-review-20261012-parts/'+p.name,'lossless_root_evidence_part')
for n in ['root-final-disposition.md','independent-final-mechanical-report.md','independent-control-recovery-addendum.md','final-helper-full-check.json','final-helper-topic-check.json']:
 add(R/'evidence'/n,PREFIX+'evidence/'+n,'current_disposition')
for n in ['r38-repair-package-check.json','r38-repair-internal-hashes.json','r38-repair-quick-validation.json','r38-repair.diff']:
 add(P/n,PREFIX+'repair/'+n,'repair_candidate')
for n in ['teaching/main.md','teaching/hints.md','teaching/solutions.md','teaching/figures/rectangles.png','teaching/figures/pyramid-stack.png','teaching/figures/triangle.png','teaching/figures/borrowing-time.png','whole-freeze-manifest.json','prompts-only.md']:
 add(R/n,PREFIX+n,'unchanged_frozen_publication')
assert len({x['path'] for x in plan})==len(plan)
write(P/'release-publication-manifest.json',{'repository':'alverstris/PROF-Skill.md-','expected_parent':'4ca83e8b709f1e52a1bd2a3a2d612ab48722c195','parent_tree':'2b21552799ed9534486ae841244452720190aa24','release':'2026-10-12-r38','status':'repair publication; D016 failed and requires fresh complete generation; affected earlier checks pending','counts':{'accepted':16,'pending':60,'eligible':76,'excluded':71,'stable_ids':147},'active':'D016','files':plan,'file_count':len(plan),'bytes':sum(x['bytes'] for x in plan)})
print(json.dumps({'archive':ident(zpath),'archive_members':len(members),'publication_paths':len(plan),'publication_bytes':sum(x['bytes'] for x in plan)},indent=2))
