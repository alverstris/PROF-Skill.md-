from pathlib import Path
import sys, json, hashlib, datetime
p = Path(__file__).parent
plan = json.loads((p/'evidence/baseline-read-plan.json').read_text())
n = int(sys.argv[1])
s, e = plan['ranges'][n-1]
b = (p/plan['path']).read_bytes()
q = b[s:e]
record = {'chunk': n, 'start':s,'end':e,'bytes':len(q),'sha256':hashlib.sha256(q).hexdigest(), 'rawLF_start': b[:s].count(b'\n')+1, 'rawLF_end': b[:e].count(b'\n'), 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (p/'evidence/author-baseline-access.jsonl').open('a') as f: f.write(json.dumps(record)+'\n')
print(json.dumps(record))
sys.stdout.flush()
sys.stdout.buffer.write(q)
