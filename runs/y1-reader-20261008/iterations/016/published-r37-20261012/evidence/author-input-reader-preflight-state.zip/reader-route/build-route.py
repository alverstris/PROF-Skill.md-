#!/usr/bin/env python3
"""Byte/structure route construction only; no semantic review or active execution."""
from pathlib import Path
import hashlib,json,re

ROOT=Path(__file__).resolve().parent
RUN=ROOT.parent
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode('ascii')
def save(name,x): (ROOT/name).write_bytes(canonical(x)+b'\n')
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))

freeze_path=RUN/'whole-freeze-manifest.json'
freeze=json.loads(freeze_path.read_bytes())
assert len(freeze['files'])==7
allowed={f['path']:f for f in freeze['files']}
blobs={}
for name,f in allowed.items():
 b=(RUN/name).read_bytes()
 assert len(b)==f['bytes'] and sha(b)==f['sha256']
 blobs[name]=b
baseline=(RUN/'inputs/student-baseline.txt').read_bytes()
baseline.decode('utf8')
files=[dict(id='baseline',artifact='baseline',kind='text',path=str(RUN/'inputs/student-baseline.txt'),size=len(baseline),sha256=sha(baseline))]
for fid,name,kind in [('main','teaching/main.md','text'),('hints','teaching/hints.md','text'),('solutions','teaching/solutions.md','text'),('image01','teaching/figures/rectangles.png','image'),('image02','teaching/figures/pyramid-stack.png','image'),('image03','teaching/figures/triangle.png','image'),('image04','teaching/figures/borrowing-time.png','image')]:
 b=blobs[name]
 files.append(dict(id=fid,artifact='teaching',kind=kind,path=str(RUN/name),size=len(b),sha256=sha(b)))
filemap={f['id']:f for f in files}
steps=[];notes={};revisits=[]
def text_step(sid,fid,b,start,end,note):
 assert start<end
 b[start:end].decode('utf8')
 steps.append(dict(id=sid,kind='text',file_id=fid,start=start,end=end,sha256=sha(b[start:end])))
 notes[sid]=note

paragraph_boundaries=sorted(set([0,len(baseline)]+[m.end() for m in re.finditer(rb'(?:\r*\n)(?:[ \t]*\r*\n)+',baseline)]))
start=0;n=0
while start<len(baseline):
 candidates=[p for p in paragraph_boundaries if start<p<=start+24000]
 assert candidates,'Paragraph exceeds 24000-byte bound; no silent split permitted'
 end=max(candidates);n+=1;sid=f'B{n:03}'
 text_step(sid,'baseline',baseline,start,end,'baseline paragraph-aligned slice')
 revisits.append(dict(id=f'RB{n:03}',initial_step_id=sid))
 start=end

main=blobs['teaching/main.md'];main.decode('utf8')
prompts=[]
for p in range(1,7):
 anchor=re.search(fr'<a id="d016-main-p{p}"></a>'.encode(),main)
 assert anchor
 nav=re.search(fr'(?m)^\[.*hints\.md#d016-hints-p{p}.*solutions\.md#d016-solutions-p{p}[^\n]*(?:\n[ \t]*)*'.encode(),main[anchor.end():])
 assert nav
 prompts.append(dict(id=f'P{p}',start=anchor.start(),end=anchor.end()+nav.end(),anchor=f'd016-main-p{p}',boundary_rule='anchor start through own navigation line and following blank line(s)'))
imgs=[]
for i,m in enumerate(re.finditer(rb'<img\b[^>]*>',main),1):
 src=re.search(rb'\bsrc="([^"]+)"',m.group()).group(1).decode()
 name='teaching/'+src
 assert name in allowed
 fid=next(f['id'] for f in files if f['path']==str(RUN/name))
 imgs.append(dict(id=f'F{i:02}',file_id=fid,start=m.start(),end=m.end(),source_relative_path=src))
assert len(imgs)==4
boundaries=sorted(set([0,len(main)]+[x[k] for x in prompts for k in ('start','end')]+[x['end'] for x in imgs]))
main_n=0
for start,end in zip(boundaries,boundaries[1:]):
 prompt=next((p for p in prompts if p['start']==start and p['end']==end),None)
 assert end-start<=18000
 if prompt: sid=prompt['id'];note=f"isolated {sid} prompt and its own navigation"
 else: main_n+=1;sid=f'M{main_n:03}';note='main text in original byte order'
 text_step(sid,'main',main,start,end,note)
 for im in imgs:
  if im['end']==end:
   rid='V'+im['id'][1:]
   steps.append(dict(id=im['id'],kind='figure',file_id=im['file_id'],sha256=filemap[im['file_id']]['sha256'],receipt_step_id=rid,receipt_file=str(ROOT/'view-results'/f"{im['id']}.json"),first_use=dict(text_step_id=sid,position='after')))
   notes[im['id']]='complete image immediately after its img tag; cursor holds for actual view receipt'
for fid,prefix in [('hints','H'),('solutions','S')]:
 b=blobs[f'teaching/{fid}.md'];b.decode('utf8')
 anchors=[]
 for p in range(1,7):
  matches=list(re.finditer(fr'<a id="d016-{fid}-p{p}"></a>'.encode(),b))
  assert len(matches)==1
  anchors.append(matches[0].start())
 assert anchors==sorted(anchors)
 edges=[0,*anchors,len(b)]
 for n,(start,end) in enumerate(zip(edges,edges[1:])):
  assert end-start<=18000
  text_step(f'{prefix}{n:02}',fid,b,start,end,f'{fid} preamble' if n==0 else f'{fid} group P{n}; includes its original navigation and any final ending')

route=dict(schema='sasis-fixed-route-v1',route_id='D016-clean-r37-20261012',artifacts=dict(baseline=dict(id='OCR-A-4-subjects-r1',revision='sha256:'+sha(baseline)),teaching=dict(id='D016-whole-teaching',revision='whole-freeze-sha256:'+sha(freeze_path.read_bytes()))),files=files,steps=steps,revisits=revisits)
launcher=(RUN/'runner-preflight/deployments/main/read-step').read_bytes()
assert sha(launcher)=='d82d55790f9f0351331d5fc61bb614ee35ece63eb3db7c4593ce52be81c6f9fd'
(ROOT/'read-step').write_bytes(launcher);(ROOT/'read-step').chmod(0o755)
save('route.json',route)
save('route-seal.json',dict(schema='sasis-route-seal-v1',route_id=route['route_id'],route_sha256=sha((ROOT/'route.json').read_bytes()),launcher_sha256=sha(launcher)))
for name in ['view-results','view-evidence','reader-evidence','view-invocations']:
 (ROOT/name).mkdir(exist_ok=True)
assert not (ROOT/'runtime').exists(),'Active route must not have run'
role=(RUN/'inputs/prof/references/sasis/student-role.txt').read_bytes()
(ROOT/'reader-operating-instruction.txt').write_bytes(role)
save('boundary-metadata.json',dict(range_convention='zero-based half-open raw byte intervals [start,end); no newline normalization',baseline_paragraph_boundaries=paragraph_boundaries,baseline_newline_counts=dict(CRCRLF=baseline.count(b'\r\r\n'),CRLF=baseline.count(b'\r\n'),LF=baseline.count(b'\n')),prompts=prompts,images=imgs,step_notes=notes))
schedule=[]
for step in steps:
 row=dict(order=len(schedule)+1,step_id=step['id'],kind=step['kind'],file_id=step['file_id'],range=[step['start'],step['end']] if step['kind']=='text' else [0,filemap[step['file_id']]['size']],sha256=step['sha256'],note=notes[step['id']])
 schedule.append(row)
 if step['kind']=='figure':
  schedule.append(dict(order=len(schedule)+1,step_id=step['receipt_step_id'],kind='view_receipt',file_id=step['file_id'],range=None,sha256=None,note='Only after actual original-detail image view, raw result preservation, inspection, and metadata receipt creation'))
save('chronological-route.json',dict(route_id=route['route_id'],files=files,schedule=schedule,revisits=revisits))
lines=['# D016 frozen chronological reader route','','This is operational routing metadata only. Ranges are zero-based half-open raw byte intervals. Images appear immediately after their img tags and before subsequent bytes. All baseline slices precede teaching.','', '| File ID | Absolute file path | Bytes | SHA-256 |','|---|---|---:|---|']
for f in files: lines.append(f"| {f['id']} | `{f['path']}` | {f['size']} | `{f['sha256']}` |")
lines+=['','| Order | Step | Operation | File | Byte range | SHA-256 |','|---:|---|---|---|---|---|']
for s in schedule: lines.append(f"| {s['order']} | {s['step_id']} | {s['kind']} | {s['file_id']} | {str(s['range']) if s['range'] else 'no subject read'} | {s['sha256'] or 'actual result receipt'} |")
lines+=['','Baseline revisits are optional and never advance the route. Each becomes permitted only after its original baseline step completed.','', '| Revisit | Original |','|---|---|']
lines += [f"| {r['id']} | {r['initial_step_id']} |" for r in revisits]
(ROOT/'chronological-route.md').write_text('\n'.join(lines)+'\n')
save('construction-summary.json',dict(status='constructed; pending independent static validation; active launcher never invoked',manifest=ident(freeze_path),launcher=ident(ROOT/'read-step'),route=ident(ROOT/'route.json'),seal=ident(ROOT/'route-seal.json'),baseline_bytes=len(baseline),teaching_bytes=sum(f['bytes'] for f in freeze['files']),baseline_slices=len(revisits),teaching_text_slices=sum(s['kind']=='text' and s['file_id']!='baseline' for s in steps),figures=len(imgs),scheduled_steps=len(steps),scheduled_calls_including_receipts=len(schedule),largest_baseline_slice=max(s['end']-s['start'] for s in steps if s['file_id']=='baseline'),largest_teaching_slice=max(s['end']-s['start'] for s in steps if s['kind']=='text' and s['file_id']!='baseline')))
print(json.dumps(json.loads((ROOT/'construction-summary.json').read_bytes()),indent=2))
