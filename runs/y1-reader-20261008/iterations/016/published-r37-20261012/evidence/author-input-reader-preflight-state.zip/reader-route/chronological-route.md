# D016 frozen chronological reader route

This is operational routing metadata only. Ranges are zero-based half-open raw byte intervals. Images appear immediately after their img tags and before subsequent bytes. All baseline slices precede teaching.

| File ID | Absolute file path | Bytes | SHA-256 |
|---|---|---:|---|
| baseline | `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/inputs/student-baseline.txt` | 247840 | `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5` |
| main | `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/teaching/main.md` | 22812 | `ee1766a4215bd1f2753267c2ac6d2cdb825c5fe79ef3a37a84ffb134aa8ab405` |
| hints | `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/teaching/hints.md` | 3241 | `d28e23e5d9935ed5af4b20f0df4be3f49f4089b289ca10dafd84d00d2961ffe7` |
| solutions | `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/teaching/solutions.md` | 7752 | `4e31a5b13e746a85ede50087c4619ebd6fa077df8dd1655d2aff69714c2fd40d` |
| image01 | `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/teaching/figures/rectangles.png` | 65725 | `a897cad2e58d989e2623317f2ef5661f392abf8c45fe8fb206da1c577d600260` |
| image02 | `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/teaching/figures/pyramid-stack.png` | 82598 | `8c13757697c359999d985c886e01ad550e0a17cab1225265a5781db9c1835619` |
| image03 | `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/teaching/figures/triangle.png` | 33845 | `329bbd47b19fc0c36329f34983f40a21924be91c4d2865a20ae101574af1dea8` |
| image04 | `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/teaching/figures/borrowing-time.png` | 35111 | `71e70248ee971be9751aa41159299a18923fa9486f41fb10e4775dfb84396b33` |

| Order | Step | Operation | File | Byte range | SHA-256 |
|---:|---|---|---|---|---|
| 1 | B001 | text | baseline | [0, 23842] | 7c5726008a0e387abf12fcd2c578a1c4298f795afc18a22d0bb11761bbe53e6e |
| 2 | B002 | text | baseline | [23842, 47600] | 55b159db18b08d069d425cef3ac8185256e4d1cad597977b441b3d00b8de785f |
| 3 | B003 | text | baseline | [47600, 71126] | 875ee3f56b6c2e646e7b3f65b51778000d35461e4abf3d8756e7ae60748160c8 |
| 4 | B004 | text | baseline | [71126, 95001] | fd16c414d9572aba95b7c1cb025e37d72a3ba04da52d003cefbfc23aed39ab5b |
| 5 | B005 | text | baseline | [95001, 118601] | c203d91b42eb10de47e71e978287fa6a1fc6990c0d8a7f90e9786b3916df9694 |
| 6 | B006 | text | baseline | [118601, 142316] | 976f0b80114c0c7b0b48163475dd4e259ba5dc63d196deda2bd2b7ca72458acc |
| 7 | B007 | text | baseline | [142316, 166061] | fd8823ab4b6d3155d19cd28a0c3be6c366e36b7b8d1d4b9f64ee992e23daa737 |
| 8 | B008 | text | baseline | [166061, 189779] | df83739fddf4fa269b1df6e82cb253810279db851479ff18e5b0b792c7614987 |
| 9 | B009 | text | baseline | [189779, 213341] | 6f27179e71de5b3c3e0106057c8ceafe507e613639929dd47d47f12c6c4a352b |
| 10 | B010 | text | baseline | [213341, 237107] | b918e8e38af179edd46ac2e2e53ab5a1a4ba9a0e56028153c21e9e5e33722e5c |
| 11 | B011 | text | baseline | [237107, 247840] | 159bb6e8ffaf8b02364e8c85ec09ccf5c0c178c248183b37a372e542d6164d4b |
| 12 | M001 | text | main | [0, 3216] | aafab48504ec16f05aaad63ad0a76668670c680f56ce5a1f2487d12b093d93ac |
| 13 | F01 | figure | image01 | [0, 65725] | a897cad2e58d989e2623317f2ef5661f392abf8c45fe8fb206da1c577d600260 |
| 14 | V01 | view_receipt | image01 | no subject read | actual result receipt |
| 15 | M002 | text | main | [3216, 3355] | 610a6bef1e0f3768b990a380aaa849592da606b42875e0569ef91536cd262499 |
| 16 | P1 | text | main | [3355, 3961] | c6afd2bfb40dd2480af3153861bec43fdb192010193f4e10281a60a3b56b8709 |
| 17 | M003 | text | main | [3961, 7419] | 1a8dbdf0901bcc64c06ca74e71d3a9eb46b6fcc004ab17e582c8dc0e0c86ed3c |
| 18 | P2 | text | main | [7419, 8075] | 7dcbda521f7a3664d4be385446c6275a2c25bd56a5212dd83f6f5e27f2cabdfa |
| 19 | M004 | text | main | [8075, 10240] | 48508b9b11ad8949397d3fe667169f18621a7f469f62217f1c95b2ac7349b9d7 |
| 20 | F02 | figure | image02 | [0, 82598] | 8c13757697c359999d985c886e01ad550e0a17cab1225265a5781db9c1835619 |
| 21 | V02 | view_receipt | image02 | no subject read | actual result receipt |
| 22 | M005 | text | main | [10240, 11038] | ca80e880efb4a7c3f4dc8056c2688f80818ebf4a31773708dec895b93da41e37 |
| 23 | P3 | text | main | [11038, 11806] | 924ad6d34982528e6a059b48f13c7ce9ab3abd56fdbb2d39efeb6e56cc04b99a |
| 24 | M006 | text | main | [11806, 12418] | 38b35ef7d3781654a52535d00f2f64a770f3b9786ab2739ea6169e248bfba8e3 |
| 25 | F03 | figure | image03 | [0, 33845] | 329bbd47b19fc0c36329f34983f40a21924be91c4d2865a20ae101574af1dea8 |
| 26 | V03 | view_receipt | image03 | no subject read | actual result receipt |
| 27 | M007 | text | main | [12418, 14749] | 0888f528ea61023d3da26f596e431956225abedfe32bd550fd45f075c5cc9b05 |
| 28 | P4 | text | main | [14749, 15386] | d3dd34fd9a78ec006d3833e1d20bee40d337e016482efe708739caab7237d443 |
| 29 | M008 | text | main | [15386, 17333] | f10c0b78d0321baab5dc9bc3aa05eb0753bc652e52279ece21f2a599882187ad |
| 30 | F04 | figure | image04 | [0, 35111] | 71e70248ee971be9751aa41159299a18923fa9486f41fb10e4775dfb84396b33 |
| 31 | V04 | view_receipt | image04 | no subject read | actual result receipt |
| 32 | M009 | text | main | [17333, 20060] | 2c5d7eeccf9b9b66f644db441bf08e6852b43ecf06778360f96d9ba95dd8d412 |
| 33 | P5 | text | main | [20060, 20709] | ddb70e7cd1711b8410608c79470ff795929e41d73b2974cad07e861d6eca158d |
| 34 | P6 | text | main | [20709, 21720] | 41efe6104f789adf385e4891b42d6171a0f30d56a5b301f012fcac020abf8ef5 |
| 35 | M010 | text | main | [21720, 22812] | 321819266dc650f59edb6d8dd457c4f3f5b71073c2830597670dfeaf491860ff |
| 36 | H00 | text | hints | [0, 217] | a4ae08742fcd819c3fe561e968c4c2717db33a3a494e8afd8266178c25bc6d04 |
| 37 | H01 | text | hints | [217, 749] | d48611255e0bfebea6114f10bbaed1bae26d848861d495f884619307d4c86c25 |
| 38 | H02 | text | hints | [749, 1229] | 0cb89f0ac3046de44d1b3adf79106c3bf07bd90b7a5c8e46f4e474dcea1474b6 |
| 39 | H03 | text | hints | [1229, 1751] | 2c66644c0f71456dae6cab68f58111376157ad9392cb4d6aa52ae60cb83c7c57 |
| 40 | H04 | text | hints | [1751, 2237] | 99eefd8dae426af9f13e3f33c5d2a368a62a7f86f36bd916a9fd84f367eac55d |
| 41 | H05 | text | hints | [2237, 2665] | d919df0ccc6fce3ad1d30ea6b976c8cfd3ea4f07a88f4bb99be78a5b0a00fdc6 |
| 42 | H06 | text | hints | [2665, 3241] | 18b16200a47ad4be36f00d48385ce614a955536cfda8142a74473ab6564b3340 |
| 43 | S00 | text | solutions | [0, 333] | a2b5a7fe13dbfa325b578d3b4a6980cc6d2da53cd877b86da10325c8e5407ea4 |
| 44 | S01 | text | solutions | [333, 1150] | 702a56c87fbb5d168a0448f34f6756a1dad39f4712c48dc1929804d3bc6520cc |
| 45 | S02 | text | solutions | [1150, 2458] | ff01c36c568c25a68af61759c05674794e7430591a0845a13b0aa0a9393274a4 |
| 46 | S03 | text | solutions | [2458, 3617] | 69db17eaa2735d566075c6f0335d4005315770cc8b74c0945b9d844213784ade |
| 47 | S04 | text | solutions | [3617, 4657] | c9b01fcec9197e7bc5b63801013baf8410b266e75f123f528bf38c4bd4f9c2e6 |
| 48 | S05 | text | solutions | [4657, 5911] | 1a83268a9f9a9ff87ee7d0e073819cb76eb165480a0d4b6131f43fddf1caf41a |
| 49 | S06 | text | solutions | [5911, 7752] | 55aab8e0dc9f36506c3e8044da20d53c7fb39d91b47802d7fcae6e7c749d099e |

Baseline revisits are optional and never advance the route. Each becomes permitted only after its original baseline step completed.

| Revisit | Original |
|---|---|
| RB001 | B001 |
| RB002 | B002 |
| RB003 | B003 |
| RB004 | B004 |
| RB005 | B005 |
| RB006 | B006 |
| RB007 | B007 |
| RB008 | B008 |
| RB009 | B009 |
| RB010 | B010 |
| RB011 | B011 |
