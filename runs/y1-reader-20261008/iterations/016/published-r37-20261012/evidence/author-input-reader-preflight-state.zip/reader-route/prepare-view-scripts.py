#!/usr/bin/env python3
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
route=json.loads((ROOT/'route.json').read_bytes())
files={f['id']:f for f in route['files']}
template=(ROOT/'view-template.js').read_text()
for s in route['steps']:
 if s['kind']!='figure':continue
 f=files[s['file_id']]
 fixed=dict(route_id=route['route_id'],figure_step_id=s['id'],receipt_step_id=s['receipt_step_id'],image_path=f['path'],image_sha256=f['sha256'],receipt_file=s['receipt_file'],raw_result_file=str(ROOT/'view-evidence'/f"{s['id']}-actual-result.json"),invocation_metadata_file=str(ROOT/'view-evidence'/f"{s['id']}-invocation.json"))
 (ROOT/'view-invocations'/f"view-{s['id']}.js").write_text(template.replace('FIXED_INVOCATION',json.dumps(fixed,separators=(',',':'))))
print(json.dumps({'prepared_fixed_view_invocations':4,'images_viewed':0,'active_launcher_invoked':False}))
