# Original SASIS reader report — D016 clean r37

This is the original saved report from the fresh dedicated reading of this frozen revision, written before author feedback. It records observed access and content evaluation; it does **not** grant substantive admission or claim that delivery has been independently reconciled. The coordinator must compare the actual native ledger, byte/hash coverage, preserved launcher outcomes and four raw image results.

## Access, preservation and procedural limits

My first subject exposure was B001. I completed B001–B011 before M001. Subject text was obtained only by the fixed launcher, one scheduled ID per command. I made no baseline revisits, alternative subject retrievals, searches, browser calls, source-link visits, out-of-order help reads, or other-agent consultations.

All 49 scheduled launcher invocations returned exit code 0. Each full actual return object was saved immediately, unchanged by direct JSON serialization, to its uniquely named STEP-call-NNN-exec-result.json file in this report's directory. None reported truncation or rejection. The last returned slice included the solutions' final navigation. Observed order:

B001 B002 B003 B004 B005 B006 B007 B008 B009 B010 B011 M001 F01 V01 M002 P1 M003 P2 M004 F02 V02 M005 P3 M006 F03 V03 M007 P4 M008 F04 V04 M009 P5 P6 M010 H00 H01 H02 H03 H04 H05 H06 S00 S01 S02 S03 S04 S05 S06.

The routing metadata identifies 247840 baseline bytes and 251084 teaching bytes across seven constituents. I do not independently attest those totals from direct file inspection. My narrower observation is that every scheduled text result appeared untruncated and every scheduled image was displayed and inspected at first use. Byte/hash reconciliation remains for the coordinator.

| Baseline step | Scheduled bytes [start,end) | Content encountered |
|---|---:|---|
| B001 | [0,23842) | Cover; Mathematics arithmetic, mensuration, proof, algebra/functions, sequences/sums, trigonometry, exponentials, differentiation; integration heading |
| B002 | [23842,47600) | Mathematics integration, numerical methods, vectors, statistics/tests, mechanics through friction |
| B003 | [47600,71126) | Mathematics moments/scope; Further Mathematics FM01–FM40 |
| B004 | [71126,95001) | FM41–FM71; Physics introduction, reference data and units |
| B005 | [95001,118601) | Physics graphs/measurement/practicals, mechanics/materials, circuits and waves through double slits |
| B006 | [118601,142316) | Physics grating/standing waves, photons, thermal physics, oscillations/gravity, cosmology, fields and nuclear topics through radiation descriptions |
| B007 | [142316,166061) | Physics decay/imaging/scope; Chemistry opening through bonding and start of molecular shape |
| B008 | [166061,189779) | Chemistry shape/intermolecular forces, inorganic chemistry, rates/equilibria and opening quantitative acid/base formulae |
| B009 | [189779,213341) | Chemistry acids/buffers, enthalpy/entropy/Gibbs, electrochemistry, organic representation/mechanisms |
| B010 | [213341,237107) | Chemistry remaining mechanisms, transformations, analysis/spectroscopy and practical measurement |
| B011 | [237107,247840) | Chemistry remaining practical methods, scope and references through the ending |

I read the three designated operating documents first and each exact view-Fxx.js control file only at the corresponding pending figure stage. Those seven control-file exec_command results were displayed in the native tool transcript, but were not separately serialized to evidence files at their read time. This differs from immediate separate preservation of all 49 launcher outcomes and must remain visible during procedural reconciliation. The control reads supplied no additional subject input.

Each designated view script was executed as supplied, saved the full actual result including image URL bytes plus invocation metadata and receipt, and displayed the image. I inspected it before Vxx and before later teaching text. No figure was exposed early or inspected late.

| Figure | Actual local invocation receipt timestamp, UTC | Semantic inspection witness |
|---|---|---|
| F01 | 2026-10-12T05:54:18.192Z | Four right rectangles of width 1/2 at heights 1/4, 1, 9/4, 4; second panel retains [1,1.5] while sampling at 1.3 with dashed sample marker and height f(c). |
| F02 | 2026-10-12T05:55:56.047Z | Four centred squares in top view; shaded vertical staircase; green inner triangle with base 4 and height 4; orange outer triangle with base 5, height 5 and extra tip. Axes and legend were readable. |
| F03 | 2026-10-12T05:57:12.165Z | Shaded y=x region from 0 to b, vertical boundary at b, coordinate labels b for height/base, and area b²/2. |
| F04 | 2026-10-12T05:58:29.817Z | Timeline from 0 through c to T; age arrow covers c to T and reads T−c; small principal and debt contribution labels match those times. |

Raw view outcomes are in reader-route/view-evidence/F01-actual-result.json through F04-actual-result.json, with corresponding Fxx-invocation.json files. Host tools.view_image call IDs are not exposed by this interface. Receipt IDs are local invocation-receipt IDs, not asserted host IDs. Each Vxx acknowledgement truthfully returned semantic_inspection_proven:false. A receipt alone does not establish inspection; the witnesses above record the actual displayed content.

After the last subject step, the first attempt to write this report failed at JavaScript parsing with: “SyntaxError: Unexpected identifier 'B001'”. An unescaped backtick in a template string caused the failure before tools.apply_patch ran; it created no report and affected no subject retrieval. The exposed actual error and its limit are preserved in report-write-failure-001.json. This subsequent write uses the authorized report-writing tool and destination. The failed write is not erased or treated as a clean first attempt. Under the dispatch instructions' output-failure rule, substantive admission remains withheld and the coordinator must determine the required recovery. No alternative subject access was attempted.

This was an instruction-confined route, not a technical access boundary or erasure of pretraining. The warrants below are restricted to the supplied inputs and valid deductions from them.

## Actual baseline warrants

The complete four-subject packet was read. The lesson principally uses:

- B001, Mathematics “Prior arithmetic, geometry and mathematical language”: substitution, units, coordinates, similarity, Pythagoras, rectangle/triangle/trapezium/prism mensuration and inequality operations. “Proof and mathematical work” provides deduction and counterexamples.
- B001, “Sequences, series and binomial expansion”: indexed sums, arithmetic sums, convergence and polynomial expansion. “Differentiation” supplies the difference quotient, polynomial derivatives and derivative-sign tests.
- B002, “Integration and elementary differential equations”: antiderivatives, definite evaluation, rectangle-limit interpretation in well-behaved cases, signed area and splitting at crossings. “Numerical methods” supplies monotone endpoint bounds.
- B003, FM23: exact sums of i and i². FM30 supplies the average-value rule, although the lesson reconstructs it. FM11 and B001 geometry/trigonometry make square orientation meaningful.
- B004 FM57 and B005 Physics graph/rate material reinforce dimensional consistency and area units.

The teaching explicitly introduces the integrability guarantees, pyramid-volume premise and simple-interest model. These are usable stated premises, not consequences silently imported through a link. I did not require a derivation of every declared theorem or model law.

## Chronological reconstruction and coverage

### M001, F01/V01, M002, P1: strips, samples and finite contributions

M001 [main 0,3216) supplies n as a positive integer, width (b−a)/n, and boundaries a+iΔx. It defines c_i inside the ith strip, f(c_i) as a height, and f(c_i)Δx as the rectangle contribution. The expanded sigma expression explains the index and its role before use. Midpoint and endpoint choices use baseline coordinates and averages.

For x² on [0,2], width 1/2 gives inputs 1/2,1,3/2,2 and heights 1/4,1,9/4,4. Multiplying their sum by 1/2 gives 15/4. Monotone increase puts each right height above every curve height in its strip, so nonnegativity makes the total an area overestimate. F01 shows those heights and the separate interior sample without changing strip width. M002 [3216,3355) correctly labels a finite approximation rather than an integral.

P1 [3355,3961) is supported before the later limit discussion or help. The construction gives width 1/2, heights 5/2,2,3/2,1, and sum 7/2. The line decreases, so right rectangles lie below the graph. The baseline trapezium rule gives (3+1)·2/2=4. Thus the requested exact comparison is accessible from earlier premises.

### M003, P2: the common limit and square calculation

M003 [3961,7419) defines integrability by a finite common limit independent of permitted samples, including choices varying with n. It distinguishes bounds, integrand, dummy variable, definite number and indefinite antiderivative family.

The continuous-on-a-closed-finite-interval guarantee and bounded finite-piece guarantee are expressly stated without general proofs. Boundedness and finite jumps/one-sided limits are explained. These are clear new premises; the later functions meet their stated conditions. A source link is not needed to supply their content.

For x² on [0,b], b>0, input ib/n and width b/n give (ib/n)²(b/n), hence b³n⁻³Σi². FM23 yields b³/3+b³/(2n)+b³/(6n²), whose last terms vanish with fixed b. Subtracting endpoint sums cancels all common squares and leaves b³/n. Hence both endpoint sums share the limit. Every sample height lies between endpoint heights, and summing preserves these inequalities. The explained squeeze principle supplies sample independence. At b=2, 8/3 is correctly below 15/4.

P2 [7419,8075) requires the changed starting coordinate to be included: c_i=1+2i/n and width 2/n. Expansion and the supplied sums give 26/3+8/n+4/(3n²). Endpoint cancellation leaves (2/n)(9−1)=16/n. Both endpoint sums therefore tend to 26/3, and the prior squeeze reasoning covers every permitted sample. This is an accessible adaptation, not an unexplained new method.

### M004, F02/V02, M005, P3: the staircase pyramid

M004 [8075,10240) gives a square slab side k and height 1, so its volume is k² and the stack volume is Q_n=Σk². The pyramid-volume formula Bh/3 is explicitly an independent supplied premise. Distinguishing it from a constant-section prism prevents circular use of the integral being established.

Similarity gives inner side n−z and outer side n+1−z. For j−1<z<j, these lie on opposite sides of the stack side n−j+1. Crucially, the main text explicitly states that the squares share centre and orientation. Side inequalities therefore establish containment; the outer extra tip covers the space above the stack. F02's top and vertical views agree, and M005's caption prevents confusing triangular sections with triangular slabs.

M005 [10240,11038) translates containment to n³/3<Q_n<(n+1)³/3. Strict inequalities on interior regions support a strictly positive volume gap. For n=4, Q_n=30 lies between 64/3 and 125/3. Division by positive n³ produces bounds tending to 1/3. The already introduced squeeze principle gives Q_n/n³→1/3, then multiplication by fixed b³ recovers the earlier R_n limit. The representation is connected to the sum through actual volumes and containment.

P3 [11038,11806) gives proposed base n+1 and height n, so similarity gives s(z)=(n+1)(1−z/n). Near the apex the stack retains top-layer side 1 while the proposed side tends to zero. The solution's particular z=n−1/4 lies inside the top layer for every n≥1 and gives (n+1)/(4n)≤1/2<1. This failure is supported regardless of orientation. The successful replacement with base and height n+1 is supported under the main construction's shared-orientation condition. A local wording ambiguity about carrying that condition into P3/S03 is recorded below.

### M006, F03/V03, M007, P4: accumulation, sign and average

M006 [11806,12418) constructs b²n⁻²Σi=b²(1+1/n)/2→b²/2. The companion endpoint gap is (b/n)(b−0)=b²/n, so the earlier sample-independence argument applies. Baseline triangle area gives the same result. F03 depicts the relevant region and labels both base and height.

M007 [12418,14749) fixes a and distinguishes moving upper bound b from dummy x. Differentiating the two established area expressions gives b² and b. It then states the general accumulation theorem with continuity and an interior upper bound. Its reason is available: the difference in accumulations is the short signed contribution; division by h gives a height average; continuity places all nearby heights arbitrarily close to f(b), trapping the average there. Negative h reverses both orientation and divisor. This connects the baseline difference quotient to the claimed derivative, without requiring invention of a general analysis theorem. The text explicitly withholds this continuity argument at jumps.

Negative heights then give negative rectangle contributions, consistent with B002. For x on [−1,2], triangle magnitudes 1/2 and 2 produce signed 3/2 but geometric 5/2. The average-value formula follows by solving m(b−a)=the signed integral for m, using b−a>0. For x² it gives b²/3 between 0 and b². Integral units multiply and dividing by interval width restores height units.

P4 [14749,15386) combines these available operations: primitive x²−x gives A(b)=b²−b and A′(b)=2b−1. A(2)=2. Splitting at x=1/2 gives geometric magnitudes 1/4 and 9/4, hence total 5/2 and signed total 2. Average is 1. A′<0 on 0<b<1/2 explains decreasing accumulation despite a growing interval. Each requested result has an identifiable quantity and route.

### M008, F04/V04, M009, P5, P6: timing-weighted contributions

M008 [15386,17333) defines f in dollars/year and time in years. Rate times duration produces dollars; exact constant-strip contributions are distinguished from varying-rate approximations. Taking their limit gives B(T)=∫f under the earlier existence conditions. The monthly example converts 1000 dollars/month to 12000 dollars/year before multiplying by 1/12 year.

Simple interest P(1+rs) is a stipulated model, with no fees, intermediate repayments or interest on interest. A contribution sampled at c_i has age T−c_i, so substitution gives f(c_i)Δt[1+r(T−c_i)]. F04 shows the correct interval for that age and matching contribution labels. The preceding approximation language governs the pictured small contribution.

M009 [17333,20060) sums and limits these contributions into D(T), then distributes the integrand to separate principal and interest. Multiplication by the finite-interval continuous bounded weight retains the continuous or finite-piece condition. Rate per year times years is dimensionless. At t=T the multiplier is 1. The generic word “increases” is conditional on the rate sign, discussed below; the formula itself does not require that word.

For constant 12000 over one year at 0.06, ∫₀¹(1−t)dt=1/2 gives principal 12000, interest 360 and debt 12360 dollars. Charging the entire principal for a year gives 12720 and represents a different borrowing time. Twelve end-of-month lumps have ages 1−i/12; Σi=78 gives 12330. Waiting until each month ends explains the lower interest; the finite discrete model is explicitly distinguished from the continuous limit.

For the finite jump example, piecewise rate times duration gives 2·1/4+6·3/4=5. Changing one fixed finite point value changes only strips sampling that point. At most two adjacent strips can do so, giving bound 2|K|Δt. This need not vanish at finite n but tends to zero as widths shrink. A bounded interest weight supplies only a fixed multiplier. This consequential single-point argument appears before P6.

P5 [20060,20709) consequently has small contribution (6000+6000c)Δt[1+0.08(1−c)]. Integrating the rate gives 9000 principal. The identity (1+t)(1−t)=1−t² gives interest 0.08·6000·(1−1/3)=320 and debt 9320. Whole-year interest would be 720 because it assigns every contribution age 1.

P6 [20709,21720) is presented as a later return; this audit does not claim to enact a student's break or measure retention. Its mathematical demands are already supported. Both plans borrow 9000 dollars. U has interest 270. V's two age integrals are 3/8 and 1/8, giving 0.06(6000·3/8+12000·1/8)=225. Debts are 9270 and 9225. Later borrowing explains the 45-dollar difference, and the already taught fixed-point-change bound supplies the final limit distinction.

M010 [21720,22812) explains recall versus transfer without claiming an actual learning result. Its source/scope paragraph and ending were read. Historical claims about the original MIT lecture's complete contents, terminology, units and original figure ideas cannot be independently checked from the two permitted inputs. I did not access the linked MIT or OpenStax sources. The internal arguments do not depend on granting those historical claims.

### H00–H06: all hints, including endings

H00 gives help navigation. H01 supplies strip width, sample evaluation, decreasing-line comparison and trapezium sides consistent with P1's earlier available route. H02 keeps the initial 1 inside the square, distinguishes constant/i/i² terms and points to endpoint cancellation. H03 uses similarity and the last-layer/apex comparison rather than volume alone. H04 separates antiderivative, crossing, signed average and derivative sign. H05 supplies the correct age and the polynomial simplification. H06 directs the piecewise split and the finite-sum bound. These hints do not retroactively supply a missing mathematical prerequisite for P1, P2, P4, P5 or P6. H06's final main-route link was included.

### S00–S06: all complete solutions, including endings

S00's allowance for equivalent valid constructions agrees with the prompt goals.

- S01 explicitly gives width, samples, heights and 7/2; the decreasing-strip argument and trapezium area justify 7/2<4. Its heights-only total 7 illustrates the missing-width distinction.
- S02 expands the shifted sample, counts n constants, derives 26/3+8/n+4/(3n²), calculates the 16/n gap and supplies the squeeze step. Its antiderivative evaluation is correctly labelled a value check, not a sample-independence proof.
- S03 derives the proposed cross-section, checks z=n−1/4 and n≥1, and demonstrates failure. Its successful replacement inherits the shared-orientation condition from the earlier main construction; the local standalone ambiguity is retained below.
- S04 distinguishes A, A′, signed integral, geometric area and average. Areas 1/4 and 9/4 and the decrease interval agree with the prior witnesses.
- S05 retains approximation language for a short contribution, separates principal and interest, obtains 9000, 320 and 9320, and explains the alternative 9720 by its different age assignment. Its unit explanation uses the specified per-year convention.
- S06 constructs both principal and debt integrals and obtains the stated age integrals and 225 interest. For the changed point it bounds the weight between 1 and 1.06, yielding debt-sum difference at most 2.12|K|Δt alongside the principal bound. Both tend to zero. The final help links and main-route ending were read.

These witnesses evaluate the document's demands and explanations. They do not certify that a real learner would perform them correctly.

## Supported ambiguity and domain qualification

### P3/S03: orientation

Status: local wording ambiguity; the main proof is not defective.

M004 explicitly requires common centre and orientation to infer containment from side length. P3 restates “a solid stack” with a common axis but does not repeat alignment of its square layers and the replacement pyramid. S03 likewise states side-length comparisons and common axis.

On the contextual reading that P3 inherits the preceding construction's orientation, S03's replacement is supported. On the standalone reading that its restated dimensions and common axis are the full conditions, rotated squares are permitted and the success conclusion does not follow.

A concrete baseline-geometric witness distinguishes the readings. For n=1, the replacement has base side 2 and height 2. At z=3/4 its side is 5/4. A centred unit stack square rotated 45 degrees relative to that enclosing square has span √2 along the enclosing square's side direction. Since √2>5/4, it protrudes despite sharing the axis. This uses similarity and ordinary square geometry, not an outside theorem.

The natural question is whether the common-orientation condition is intended to carry into the new wording. I retain it explicitly when calling the replacement supported. This does not affect the proposed height-n pyramid's failure, M004–M005 where alignment is given, either sum limit, or the later sections. It is not a reason to reject the whole main argument.

### M008–M009: sign of r and the word “increases”

Status: narrow qualification of the general prose; the displayed formula and numerical results remain supported.

The symbolic model stipulates fixed r per year without explicitly restricting its sign. M009 says the bracket “increases” an amount according to remaining age. With nonnegative age this holds for positive r, gives no change at zero, and reverses for negative r. The supplied formula itself shows that r=−0.1 and age 1 give multiplier 0.9.

The natural question is whether the symbolic rate is restricted to a nonnegative charge rate. I do not supply an external financial convention to settle it. All numerical examples and prompts use positive rates, so their cost interpretations and comparisons remain justified. The formulas, integrability, unit reasoning and single-point limit argument are not blocked by this wording qualification.

## Disposition and recovery limit

Within the received content, no established incorrect worked numerical result or missing prerequisite blocking the main rectangle/squeeze/accumulation argument was found. The local orientation ambiguity and rate-sign qualification above remain explicit rather than silently repaired. Source-fidelity claims remain independently unverified.

This is **not** a substantive admission. All 49 scheduled launcher outcomes and all four raw view results are available for reconciliation, but seven operational control-read results were not separately archived at their read time, and the first report-write operation failed as preserved above. The coordinator must reconcile access and apply the required output-failure recovery before any claim of complete delivery or admission. No additional subject retrieval is requested or attempted by this reader.

This report does not grade an imagined student, establish human learning or retention, or claim to discover every latent defect.

