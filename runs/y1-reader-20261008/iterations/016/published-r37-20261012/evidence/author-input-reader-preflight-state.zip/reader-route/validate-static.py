#!/usr/bin/env python3
"""Independent static validator. Never executes/imports the active launcher."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RUN=ROOT.parent
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_bytes())
def exact(x,keys):assert type(x) is dict and set(x)==set(keys)
def ident(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
route=load(ROOT/'route.json');seal=load(ROOT/'route-seal.json');freeze=load(RUN/'whole-freeze-manifest.json')
exact(seal,['schema','route_id','route_sha256','launcher_sha256'])
assert seal['schema']=='sasis-route-seal-v1' and seal['route_id']==route['route_id']
assert seal['route_sha256']==sha((ROOT/'route.json').read_bytes())
assert seal['launcher_sha256']==sha((ROOT/'read-step').read_bytes())==sha((RUN/'runner-preflight/deployments/main/read-step').read_bytes())
assert not (ROOT/'runtime').exists(),'Active runtime must not exist before dispatch'
exact(route,['schema','route_id','artifacts','files','steps','revisits'])
assert route['schema']=='sasis-fixed-route-v1'
exact(route['artifacts'],['baseline','teaching'])
for a in route['artifacts'].values():
 exact(a,['id','revision']);assert all(type(v) is str and 0<len(v)<=200 for v in a.values())
allowed={str(RUN/f['path']):f for f in freeze['files']}
allowed[str(RUN/'inputs/student-baseline.txt')]=None
assert {f['path'] for f in route['files']}==set(allowed)
files={};blobs={}
for f in route['files']:
 exact(f,['id','artifact','kind','path','size','sha256'])
 assert f['id'] not in files
 assert f['artifact'] in ('baseline','teaching') and f['kind'] in ('text','image')
 assert type(f['size']) is int and f['size']>0
 p=Path(f['path']);assert p.is_absolute() and str(p)==str(p.resolve()) and not p.is_symlink()
 b=p.read_bytes();assert len(b)==f['size'] and sha(b)==f['sha256']
 if allowed[str(p)]:assert len(b)==allowed[str(p)]['bytes'] and sha(b)==allowed[str(p)]['sha256']
 if f['kind']=='text':b.decode('utf8')
 files[f['id']]=f;blobs[f['id']]=b
ids=set();coverage={fid:[] for fid in files};all_baseline=True;seen={};figures=[]
for s in route['steps']:
 assert type(s) is dict and s['kind'] in ('text','figure')
 assert type(s['id']) is str and re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,79}',s['id']) and s['id'] not in ids
 ids.add(s['id']);f=files[s['file_id']];b=blobs[s['file_id']]
 assert type(s['sha256']) is str and re.fullmatch('[0-9a-f]{64}',s['sha256'])
 if f['artifact']=='teaching':all_baseline=False
 else:assert all_baseline
 if s['kind']=='text':
  exact(s,['id','kind','file_id','start','end','sha256'])
  assert f['kind']=='text' and type(s['start']) is int and type(s['end']) is int and 0<=s['start']<s['end']<=len(b)
  limit=24000 if f['artifact']=='baseline' else 18000
  assert s['end']-s['start']<=limit
  part=b[s['start']:s['end']];part.decode('utf8');assert sha(part)==s['sha256']
  coverage[s['file_id']].append((s['start'],s['end']))
  if f['artifact']=='baseline':
   for edge in [s['start'],s['end']]:
    assert edge in (0,len(b)) or re.search(rb'\r*\n(?:[ \t]*\r*\n)+\Z',b[:edge])
 else:
  exact(s,['id','kind','file_id','sha256','receipt_step_id','receipt_file','first_use'])
  assert f['kind']=='image' and f['artifact']=='teaching' and s['sha256']==f['sha256']
  assert s['receipt_step_id'] not in ids;ids.add(s['receipt_step_id'])
  exact(s['first_use'],['text_step_id','position'])
  assert s['first_use']['position']=='after' and s['first_use']['text_step_id'] in seen
  previous=route['steps'][route['steps'].index(s)-1]
  assert previous['id']==s['first_use']['text_step_id'] and previous['kind']=='text'
  assert str(Path(s['receipt_file']).parent)==str(ROOT/'view-results') and Path(s['receipt_file']).suffix=='.json'
  assert not Path(s['receipt_file']).exists()
  figures.append(s);coverage[s['file_id']].append((0,len(b)))
 seen[s['id']]=s
for fid,ranges in coverage.items():
 pos=0
 for lo,hi in ranges:assert lo==pos;pos=hi
 assert pos==len(blobs[fid])
baseline_ids=[s['id'] for s in route['steps'] if files[s['file_id']]['artifact']=='baseline']
assert len(route['revisits'])==len(baseline_ids)
for r in route['revisits']:
 exact(r,['id','initial_step_id']);assert r['id'] not in ids;ids.add(r['id']);assert r['initial_step_id'] in baseline_ids
assert set(r['initial_step_id'] for r in route['revisits'])==set(baseline_ids)

main=blobs['main']
# Independently locate img tags and require the immediately preceding text range to end at the tag's final byte.
tag_matches=list(re.finditer(rb'<img\b[^>]*>',main))
assert len(tag_matches)==len(figures)==4
for tag,s in zip(tag_matches,figures):
 src=re.search(rb'src="([^"]+)"',tag.group()).group(1).decode()
 assert files[s['file_id']]['path']==str(RUN/'teaching'/src)
 before=seen[s['first_use']['text_step_id']]
 assert before['file_id']=='main' and before['end']==tag.end() and before['start']<=tag.start()
 idx=route['steps'].index(s)
 after=route['steps'][idx+1]
 assert after['kind']=='text' and after['file_id']=='main' and after['start']==tag.end()

# Independent line traversal: prompt begins at its anchor; ends after its own help navigation and blank lines.
line_offsets=[];offset=0
for line in main.splitlines(keepends=True):line_offsets.append((offset,line));offset+=len(line)
prompt_ranges=[]
for n in range(1,7):
 start=next(pos for pos,line in line_offsets if line.startswith(f'<a id="d016-main-p{n}"></a>'.encode()))
 nav_index=next(i for i,(pos,line) in enumerate(line_offsets) if pos>=start and line.startswith(b'[') and f'hints.md#d016-hints-p{n}'.encode() in line and f'solutions.md#d016-solutions-p{n}'.encode() in line)
 end=line_offsets[nav_index][0]+len(line_offsets[nav_index][1]);i=nav_index+1
 while i<len(line_offsets) and not line_offsets[i][1].strip():end=line_offsets[i][0]+len(line_offsets[i][1]);i+=1
 assert seen[f'P{n}']['start']==start and seen[f'P{n}']['end']==end
 assert sum(s['file_id']=='main' and s['kind']=='text' and s['start']<=start<s['end'] for s in route['steps'])==1
 prompt_ranges.append(dict(id=f'P{n}',start=start,end=end))
teaching_sequence=[s['file_id'] for s in route['steps'] if files[s['file_id']]['artifact']=='teaching']
assert teaching_sequence.index('hints')>max(i for i,fid in enumerate(teaching_sequence) if fid=='main' or files[fid]['kind']=='image')
assert teaching_sequence.index('solutions')>max(i for i,fid in enumerate(teaching_sequence) if fid=='hints')
for fid,prefix in [('hints','H'),('solutions','S')]:
 b=blobs[fid];groups=[s for s in route['steps'] if s['file_id']==fid]
 assert len(groups)==7 and groups[0]['start']==0
 for n in range(1,7):
  pos=b.index(f'<a id="d016-{fid}-p{n}"></a>'.encode())
  assert groups[n]['id']==f'{prefix}{n:02}' and groups[n]['start']==pos

# Test only the non-subject hashing helper, stopping before any view invocation; no active route execution.
js="const fs=require('fs'),vm=require('vm'),crypto=require('crypto'); const s=fs.readFileSync(process.argv[1],'utf8'); const fn=s.slice(s.indexOf('function sha256Ascii'),s.indexOf('const invocation=')); const ctx={};vm.createContext(ctx);vm.runInContext(fn,ctx);for(const x of ['', 'abc', 'data:application/octet-stream;base64,QUJDREVGRw==', 'a'.repeat(120001)]){if(ctx.sha256Ascii(x)!==crypto.createHash('sha256').update(x).digest('hex'))throw Error('hash mismatch');}console.log(JSON.stringify({hash_helper_verified:true,vectors:4,active_images_viewed:0}));"
test=subprocess.run(['node','-e',js,str(ROOT/'view-template.js')],capture_output=True)
(ROOT/'hash-helper-check.json').write_text(json.dumps(dict(argv=['node','-e',js,str(ROOT/'view-template.js')],returncode=test.returncode,stdout=test.stdout.decode(),stderr=test.stderr.decode()),sort_keys=True)+'\n')
assert test.returncode==0,test.stderr.decode()
assert not (ROOT/'runtime').exists()
summary=dict(status='PASS: independent static schema, hash, range, order, coverage and boundary validation; no reader execution',active_runtime_exists=False,reader_dispatched=False,source_files_unchanged=True,subject_semantic_review=False,baseline_bytes=len(blobs['baseline']),baseline_chunks=len(baseline_ids),teaching_constituents=len(freeze['files']),teaching_total_bytes=sum(f['size'] for f in files.values() if f['artifact']=='teaching'),teaching_text_chunks=sum(s['kind']=='text' and s['file_id']!='baseline' for s in route['steps']),figures=len(figures),scheduled_calls=len(route['steps'])+len(figures),prompt_ranges=prompt_ranges,baseline_raw_newline_counts=dict(CRCRLF=blobs['baseline'].count(b'\r\r\n'),CRLF=blobs['baseline'].count(b'\r\n'),LF=blobs['baseline'].count(b'\n')),launcher=ident(ROOT/'read-step'),route=ident(ROOT/'route.json'),seal=ident(ROOT/'route-seal.json'),freeze_manifest=ident(RUN/'whole-freeze-manifest.json'),limits=['Static validation establishes identities and complete planned order; it is not evidence that a reader has accessed or understood any input.','Instruction-confined retrieval is not a technical sandbox or pretraining erasure.','Actual runtime ledgers, returned hashes, complete view results and reader report must be reconciled with this entire route before substantive admission.'])
(ROOT/'static-validation.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps(summary,indent=2))
