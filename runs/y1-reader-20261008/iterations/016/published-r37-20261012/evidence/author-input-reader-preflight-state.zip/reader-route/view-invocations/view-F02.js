// @exec: {"max_output_tokens": 1200}
// Operational template only. Use the generated view-Fxx.js for the pending figure.
const fixed = {"route_id":"D016-clean-r37-20261012","figure_step_id":"F02","receipt_step_id":"V02","image_path":"/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/teaching/figures/pyramid-stack.png","image_sha256":"8c13757697c359999d985c886e01ad550e0a17cab1225265a5781db9c1835619","receipt_file":"/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/reader-route/view-results/F02.json","raw_result_file":"/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/reader-route/view-evidence/F02-actual-result.json","invocation_metadata_file":"/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/reader-route/view-evidence/F02-invocation.json"};
function sha256Ascii(s) {
  if ([...s].some(c=>c.charCodeAt(0)>127)) throw new Error('Expected ASCII tool data URL');
  const prime=[],K=[],H=[];
  for(let n=2;prime.length<64;n++) {
    if(prime.every(p=>n%p!==0)) {
      prime.push(n);
      if(H.length<8) H.push((Math.sqrt(n)%1*4294967296)|0);
      K.push((Math.cbrt(n)%1*4294967296)|0);
    }
  }
  const rotr=(x,n)=>(x>>>n)|(x<<(32-n));
  const words=[],bits=s.length*8;
  s+='\x80';while(s.length%64!==56)s+='\x00';
  for(let i=0;i<s.length;i++)words[i>>2]=(words[i>>2]||0)|(s.charCodeAt(i)<<((3-i%4)*8));
  words.push(0,bits);
  let h=H.slice();
  for(let i=0;i<words.length;i+=16){
    const old=h.slice(),w=words.slice(i,i+16);
    for(let j=0;j<64;j++){
      if(j>=16){const a=w[j-15],b=w[j-2];w[j]=((rotr(a,7)^rotr(a,18)^(a>>>3))+w[j-16]+(rotr(b,17)^rotr(b,19)^(b>>>10))+w[j-7])|0;}
      const [a,b,c,d,e,f,g,z]=h;
      const t1=(z+(rotr(e,6)^rotr(e,11)^rotr(e,25))+((e&f)^((~e)&g))+K[j]+w[j])|0;
      const t2=((rotr(a,2)^rotr(a,13)^rotr(a,22))+((a&b)^(a&c)^(b&c)))|0;
      h=[(t1+t2)|0,a,b,c,(d+t1)|0,e,f,g];
    }
    h=h.map((v,j)=>(v+old[j])|0);
  }
  return h.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');
}
if(sha256Ascii('abc')!=='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad') throw new Error('Operational SHA-256 self-check failed');
const invocation={path:fixed.image_path,detail:'original'};
const started_at=new Date().toISOString();
const result=await tools.view_image(invocation);
const completed_at=new Date().toISOString();
const invocation_receipt_id=fixed.route_id+'-'+fixed.figure_step_id+'-view-'+started_at;
const metadata={invocation_receipt_id,host_tool_call_id:null,host_tool_call_id_limit:'No host tools.view_image call ID is exposed by this functions.exec runtime. This is a local invocation-receipt ID, not an asserted host tool ID.',executor:'functions.exec',nested_tool:'tools.view_image',invocation,started_at,completed_at,result_serialization:'Direct JSON.stringify of the actual returned object; complete image_url bytes retained.'};
await tools.apply_patch('*** Begin Patch\n*** Add File: '+fixed.raw_result_file+'\n+'+JSON.stringify(result)+'\n*** Add File: '+fixed.invocation_metadata_file+'\n+'+JSON.stringify(metadata)+'\n*** End Patch');
if(result.detail!=='original'||typeof result.image_url!=='string'||result.image_url.length<24)throw new Error('Actual image result incomplete; raw result preserved, receipt not created');
const match=/^data:([^;,]+);base64,/.exec(result.image_url);
if(!match)throw new Error('Unexpected image data URL; raw result preserved, receipt not created');
const receipt={schema:'sasis-view-result-v1',route_id:fixed.route_id,figure_step_id:fixed.figure_step_id,receipt_step_id:fixed.receipt_step_id,image_path:fixed.image_path,image_sha256:fixed.image_sha256,tool_name:'tools.view_image',tool_call_id:invocation_receipt_id,completed_at,invocation,result_metadata:{success:true,kind:'image',detail:result.detail,image_url_sha256:sha256Ascii(result.image_url),image_url_chars:result.image_url.length,mime_type:match[1]}};
await tools.apply_patch('*** Begin Patch\n*** Add File: '+fixed.receipt_file+'\n+'+JSON.stringify(receipt)+'\n*** End Patch');
image(result.image_url,'original');
text({figure_step_id:fixed.figure_step_id,receipt_step_id:fixed.receipt_step_id,invocation_receipt_id,raw_result_file:fixed.raw_result_file,host_tool_call_id_available:false,status:'Actual result preserved; inspect displayed image before invoking the scheduled receipt step.'});
