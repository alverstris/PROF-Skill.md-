from pathlib import Path
import json,hashlib,subprocess,shutil
R=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def deps(topic=False):
 a=['python',str(R/'inputs/prof/scripts/prof_state.py'),'dependencies','--state',str(R/'.prof-state')]
 if topic:a+=['--topic','definite-integrals']
 return json.loads(subprocess.run(a,check=True,capture_output=True,text=True).stdout)
def witness(p,phrase):return {'path':p,'sha256':sha(R/p),'locator':{'kind':'text','value':phrase}}
src=Path('/workspace/scratch/f9c0b7fc7e76/root-review-d016-r37/whole-teaching-review.md')
dest=R/'evidence/root-whole-teaching-review.md'
if dest.exists():assert dest.read_bytes()==src.read_bytes()
else:shutil.copyfile(src,dest)
td=deps(True);gd=deps()
write(R/'evidence/current-topic-dependencies.json',td);write(R/'evidence/current-global-dependencies.json',gd)
t=json.loads((R/'.prof-state/topics/definite-integrals.json').read_text())
reasons={
'T1':'Continuity, boundedness, finite jumps, sampling roles, pyramid premise and borrowing age have their meanings and first usable cases before dependent use; full chronological author reconstruction and root review agree.',
'T2':'Width, coordinate, sampled height and contribution are mapped separately; three scale factors, centred square cross-sections, integration symbols and interest age are read and constructed explicitly.',
'T3':'Finite-sum identities, pointwise bounds, supplied geometry premise, continuity theorem, signed quantities and simple-interest assumption license the consequential transitions; no circular volume proof or finite-zero claim.',
'T4':'Complete worked rectangle/exact-sum/pyramid/triangle/accumulation/borrowing cases are connected and interpreted. Changed application reconstruction is recorded across all six tasks.',
'T5':'Early decreasing-curve P1, shifted interval P2, changed pyramid P3, integrated P4/P5 and delayed schedule P6 supply meaningful application rather than numerical copying.',
'T6':'Every P1–P6 prompt states the target capability and response criterion and requires the discriminating explanation; prompts were sealed before independent answers.',
'T7':'Every task has a separate useful intermediate hint and complete reasoned solution. Native file/anchor matching is verified; live click navigation remains in T11.',
'T8':'P6 provides a later reconstruction opportunity after a learner-chosen break and genuine transfer to a jumping rate; no universal spacing or observed mastery is claimed.',
'T9':'The complete baseline is used to compress established algebra and integration while sampling, geometric containment and contribution age receive local bridges and precise visual mappings.',
'T10':'Root independently prepared sources and solved prompts before teaching exposure, then reviewed all frozen text and four native figures. Author symbolic results and source corrections agree. A second technical review remains a separate global gate.'}
for rid,reason in reasons.items():
 t['requirements'][rid]={'applicable':True,'status':'pass','reason':reason,'evidence':[witness('evidence/author-whole-audit.md','The next passage defines integrability as sample-independent finite convergence, maps every integral component, and supplies sufficient continuous/finite-piece conditions.'),witness('evidence/root-whole-teaching-review.md','All six solution demands agree with root\'s previously sealed independent calculations: P1 right sum 7/2 versus exact4; P2 right/left sums 26/3±8/n+4/(3n^2), gap16/n and arbitrary-tag squeeze; P3 counterexample height n−1/4 and a working taller outer pyramid in the aligned-square construction; P4 signed2, geometric5/2, average1 and decrease on(0,1/2); P5 principal9000, interest320, debt9320; P6 debt9270 versus9225 with equal principal9000.')],'dependencies':td}
 t['requirements'][rid]['evidence'][0]['locator']={'kind':'lines','start':9,'end':35}
for rid in ['T11','T12']:
 t['requirements'][rid]['reason']='Await complete admitted fresh SASIS/access, independent technical and actual GitHub destination gates; native figure and static navigation/math checks do not substitute.'
write(R/'.prof-state/topics/definite-integrals.json',t)
m=json.loads((R/'.prof-state/manifest.json').read_text())
for c in m['output_checks']:
 if c['id'] in ['coverage','source_correspondence']:
  c.update(status='pass',reason='All six source pages and five original figure ideas map to actual complete teaching; no assigned portion excluded. Full reconstruction is in the author and root whole reviews.',evidence=[witness('evidence/author-whole-audit.md','All five original figure ideas and three substantive source examples are covered; no assigned source portion is excluded.')],dependencies=gd)
 elif c['id']=='publication':
  c.update(status='pass',reason='Actual Git objects at immutable teaching commit match all 11 declared publication paths and seven frozen constituents byte for byte; this does not establish live rendering.',evidence=[witness('evidence/author-whole-audit.md','Actual Git readback at 4ca83e8b709f1e52a1bd2a3a2d612ab48722c195 independently matched all 11 published review paths; destination rendering and click results remain pending.')],dependencies=gd)
write(R/'.prof-state/manifest.json',m)
for scope in [[],['--topic','definite-integrals']]:
 r=subprocess.run(['python',str(R/'inputs/prof/scripts/prof_state.py'),'check','--state',str(R/'.prof-state'),*scope],capture_output=True,text=True)
 write(R/('evidence/interim-helper-topic-check.json' if scope else 'evidence/interim-helper-full-check.json'),{'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 print(r.stdout)
