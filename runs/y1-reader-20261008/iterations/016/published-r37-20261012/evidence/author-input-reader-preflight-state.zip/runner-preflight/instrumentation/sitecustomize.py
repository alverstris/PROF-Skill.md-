"""Synthetic-preflight instrumentation only. No route/config/content mutation."""
import hashlib
import json
import os
import sys
import time

_open, _read, _seek, _close, _write = os.open, os.read, os.lseek, os.close, os.write
_fd = _open(os.environ['PREFLIGHT_ACCESS_TRACE'], os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
_paths = {}

def record(event, **data):
    _write(_fd, (json.dumps(dict(event=event, time_ns=time.time_ns(), **data), sort_keys=True) + '\n').encode())

def opened(path, flags, mode=0o777, *, dir_fd=None):
    name = os.fsdecode(path)
    record('os.open_attempt', path=name, flags=flags, dir_fd=dir_fd)
    try:
        fd = _open(path, flags, mode, dir_fd=dir_fd)
    except BaseException as exc:
        record('os.open_failed', path=name, error=type(exc).__name__)
        raise
    _paths[fd] = name
    record('os.open_returned', path=name, fd=fd)
    return fd

def read(fd, count):
    blob = _read(fd, count)
    record('os.read_returned', fd=fd, path=_paths.get(fd), requested=count, returned=len(blob), sha256=hashlib.sha256(blob).hexdigest())
    return blob

def seek(fd, pos, how):
    result = _seek(fd, pos, how)
    record('os.lseek_returned', fd=fd, path=_paths.get(fd), requested=pos, whence=how, returned=result)
    return result

def close(fd):
    result = _close(fd)
    record('os.close_returned', fd=fd, path=_paths.pop(fd, None))
    return result

def audit(event, args):
    if event == 'open':
        record('python.audit.open', path=os.fsdecode(args[0]) if isinstance(args[0], (str, bytes)) else args[0], mode=args[1], flags=args[2])

record('instrumentation_started', argv=sys.argv, version=sys.version, limitation='Python-level observation; not native syscall tracing or a sandbox')
sys.addaudithook(audit)
os.open, os.read, os.lseek, os.close = opened, read, seek, close
