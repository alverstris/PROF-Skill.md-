#!/usr/bin/env python3
"""Subject-free synthetic runner tests. Does not import or modify launcher."""
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import zlib

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'inputs/operational-tools/read-step'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')

def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(canonical(obj) + b'\n')

def png():
    def chunk(kind, body):
        return struct.pack('>I', len(body)) + kind + body + struct.pack('>I', zlib.crc32(kind + body) & 0xffffffff)
    rows = []
    for y in range(32):
        row = []
        for x in range(48):
            row += (255, 216, 0) if 16 <= x < 32 and 8 <= y < 24 else ((220, 50, 50) if x < 24 else (50, 80, 220))
        rows.append(b'\x00' + bytes(row))
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 48, 32, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(b''.join(rows))) + chunk(b'IEND', b'')

def create():
    fixtures = ROOT / 'fixtures'
    fixtures.mkdir(parents=True, exist_ok=True)
    data = {'baseline.txt': b'fixture-base-A\nfixture-base-B\n', 'text.txt': b'fixture-text-A\nfixture-text-B\n', 'figure.png': png()}
    for name, blob in data.items():
        (fixtures / name).write_bytes(blob)
    base = ROOT / 'deployments/main'
    base.mkdir(parents=True, exist_ok=True)
    (base / 'view-results').mkdir(exist_ok=True)
    launcher = SOURCE.read_bytes()
    (base / 'read-step').write_bytes(launcher)
    (base / 'read-step').chmod(0o755)
    files = [dict(id=fid, artifact=artifact, kind=kind, path=str(fixtures / name), size=len(data[name]), sha256=sha(data[name]))
             for fid, artifact, kind, name in [('baseline', 'baseline', 'text', 'baseline.txt'), ('text', 'teaching', 'text', 'text.txt'), ('image', 'teaching', 'image', 'figure.png')]]
    steps = []
    for fid, name, prefix in [('baseline', 'baseline.txt', 'B'), ('text', 'text.txt', 'T')]:
        end = data[name].index(b'\n') + 1
        for n, (start, stop) in enumerate([(0, end), (end, len(data[name]))], 1):
            steps.append(dict(id=f'{prefix}{n:02}', kind='text', file_id=fid, start=start, end=stop, sha256=sha(data[name][start:stop])))
    steps.insert(3, dict(id='F01', kind='figure', file_id='image', sha256=sha(data['figure.png']), receipt_step_id='VR01', receipt_file=str(base / 'view-results/F01.json'), first_use=dict(text_step_id='T01', position='after')))
    route = dict(schema='sasis-fixed-route-v1', route_id='synthetic-preflight-r37', artifacts=dict(baseline=dict(id='synthetic-baseline-no-subject', revision='1'), teaching=dict(id='synthetic-fixture-no-subject', revision='1')), files=files, steps=steps, revisits=[dict(id='RB01', initial_step_id='B01'), dict(id='RB02', initial_step_id='B02')])
    write_json(base / 'route.json', route)
    seal = dict(schema='sasis-route-seal-v1', route_id=route['route_id'], route_sha256=sha((base / 'route.json').read_bytes()), launcher_sha256=sha(launcher))
    write_json(base / 'route-seal.json', seal)
    for case in ['start-bool', 'start-string', 'start-negative', 'end-oversized', 'route-identity', 'launcher-identity']:
        folder = ROOT / 'deployments' / case
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'view-results').mkdir(exist_ok=True)
        (folder / 'read-step').write_bytes(launcher)
        (folder / 'read-step').chmod(0o755)
        changed = json.loads(json.dumps(route))
        changed['steps'][3]['receipt_file'] = str(folder / 'view-results/F01.json')
        if case == 'start-bool': changed['steps'][0]['start'] = False
        if case == 'start-string': changed['steps'][0]['start'] = '0'
        if case == 'start-negative': changed['steps'][0]['start'] = -1
        if case == 'end-oversized': changed['steps'][0]['end'] = len(data['baseline.txt']) + 1
        write_json(folder / 'route.json', changed)
        altered_seal = dict(seal, route_sha256=sha((folder / 'route.json').read_bytes()))
        if case == 'route-identity': altered_seal['route_sha256'] = '0' * 64
        if case == 'launcher-identity': altered_seal['launcher_sha256'] = '0' * 64
        write_json(folder / 'route-seal.json', altered_seal)
    write_json(ROOT / 'fixture-manifest.json', dict(non_subject=True, launcher_source=str(SOURCE), launcher_sha256=sha(launcher), fixtures=[dict(path=str(fixtures/name), bytes=len(blob), sha256=sha(blob)) for name, blob in data.items()], protocol_inputs=[dict(path=str(ROOT.parent / p), sha256=sha((ROOT.parent / p).read_bytes())) for p in ['inputs/prof/references/sasis.md', 'inputs/prof/references/sasis/student-role.txt']]))

def events(folder):
    path = folder / 'runtime/ledger.jsonl'
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

def run(label, args, expected, deployment='main', want_stdout=None, zero_subject=False):
    folder = ROOT / 'deployments' / deployment
    before = events(folder)
    logs = ROOT / 'calls'
    logs.mkdir(exist_ok=True)
    trace = logs / f'{label}.access.jsonl'
    argv = [str(folder / 'read-step'), *args]
    env = dict(os.environ, PYTHONPATH=str(ROOT / 'instrumentation'), PYTHONDONTWRITEBYTECODE='1', PREFLIGHT_ACCESS_TRACE=str(trace))
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    result = subprocess.run(argv, capture_output=True, env=env)
    completed = dt.datetime.now(dt.timezone.utc).isoformat()
    (logs / f'{label}.stdout.bin').write_bytes(result.stdout)
    (logs / f'{label}.stderr.bin').write_bytes(result.stderr)
    after = events(folder)
    new = after[len(before):]
    subject = [e for e in new if e['event'].startswith('subject_') or e['event'] == 'actual_access']
    observed = [json.loads(line) for line in trace.read_text().splitlines()]
    opened = [event for event in observed if event['event'] == 'os.open_attempt' and str(ROOT / 'fixtures') in event.get('path', '')]
    record = dict(label=label, invocation=argv, instrumentation='Python startup audit/open/read observation; unchanged launcher', instrumentation_env={k:env[k] for k in ['PYTHONPATH', 'PYTHONDONTWRITEBYTECODE', 'PREFLIGHT_ACCESS_TRACE']}, started_at=started, completed_at=completed, returncode=result.returncode, stdout_b64=base64.b64encode(result.stdout).decode(), stderr_b64=base64.b64encode(result.stderr).decode(), stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr), ledger_start=len(before), ledger_end=len(after), launcher_call_ids=sorted(set(e['call_id'] for e in new)), subject_events=subject, traced_fixture_open_calls=opened, trace_path=str(trace), trace_sha256=sha(trace.read_bytes()))
    write_json(logs / f'{label}.json', record)
    with (ROOT / 'call-order.jsonl').open('ab') as f:
        f.write(canonical(record) + b'\n')
    assert result.returncode == expected, record
    if want_stdout is not None: assert result.stdout == want_stdout, record
    if zero_subject: assert not subject and not opened, record
    print(json.dumps(dict(label=label, exit=result.returncode, stdout_bytes=len(result.stdout), fixture_opens=len(opened), ledger_events=len(new), stderr=result.stderr.decode().strip())), flush=True)

def before_view():
    create()
    run('01-extra-args', ['B01', 'extra'], 2, zero_subject=True)
    run('02-skipped', ['B02'], 2, zero_subject=True)
    run('03-unknown', ['UNKNOWN'], 2, zero_subject=True)
    run('04-unread-revisit', ['RB02'], 2, zero_subject=True)
    run('05-valid-exact-slice', ['B01'], 0, want_stdout=b'fixture-base-A\n')
    run('06-read-revisit', ['RB01'], 0, want_stdout=b'fixture-base-A\n')
    run('07-unread-revisit-after-first', ['RB02'], 2, zero_subject=True)
    run('08-next-baseline', ['B02'], 0, want_stdout=b'fixture-base-B\n')
    run('09-first-text', ['T01'], 0, want_stdout=b'fixture-text-A\n')
    run('10-figure-dispatch', ['F01'], 0)
    run('11-figure-bypass-next', ['T02'], 2, zero_subject=True)
    run('12-figure-missing-receipt', ['VR01'], 2, zero_subject=True)
    weak = dict(image_path=str(ROOT / 'fixtures/figure.png'), image_sha256=sha((ROOT / 'fixtures/figure.png').read_bytes()))
    write_json(ROOT / 'deployments/main/view-results/F01.json', weak)
    write_json(ROOT / 'rejected-checksum-path-only-receipt.json', weak)
    run('13-figure-path-checksum-only', ['VR01'], 2, zero_subject=True)
    run('14-still-blocked', ['T02'], 2, zero_subject=True)
    (ROOT / 'deployments/main/view-results/F01.json').unlink()
    for i, case in enumerate(['start-bool', 'start-string', 'start-negative', 'end-oversized', 'route-identity', 'launcher-identity'], 15):
        run(f'{i:02}-{case}', ['B01'], 2, deployment=case, zero_subject=True)

def after_view():
    run('21-actual-view-receipt', ['VR01'], 0, zero_subject=True)
    run('22-post-view-text', ['T02'], 0, want_stdout=b'fixture-text-B\n')
    run('23-complete-route', ['T02'], 2, zero_subject=True)

if __name__ == '__main__':
    {'before-view': before_view, 'after-view': after_view}[sys.argv[1]]()
