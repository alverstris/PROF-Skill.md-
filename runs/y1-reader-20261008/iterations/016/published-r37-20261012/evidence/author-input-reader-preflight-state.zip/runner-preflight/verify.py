#!/usr/bin/env python3
import base64
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def sha(blob): return hashlib.sha256(blob).hexdigest()
def canonical(obj): return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def load(path): return json.loads(path.read_text())
def jsonl(path): return [json.loads(line) for line in path.read_text().splitlines()]
def identity(path): return dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path.read_bytes()))

manifest=load(ROOT/'fixture-manifest.json')
source=Path(manifest['launcher_source'])
assert sha(source.read_bytes())==manifest['launcher_sha256']
ledgers=[]
for path in sorted((ROOT/'deployments').glob('*/runtime/ledger.jsonl')):
    previous='0'*64
    rows=jsonl(path)
    for index,row in enumerate(rows):
        assert row['index']==index and row['previous']==previous
        saved=row['sha256']
        assert sha(canonical({k:v for k,v in row.items() if k!='sha256'}))==saved
        previous=saved
    ledgers.append(dict(**identity(path),events=len(rows),chain_valid=True,final_event_sha256=previous))
    assert sha((path.parent.parent/'read-step').read_bytes())==manifest['launcher_sha256']

calls=jsonl(ROOT/'call-order.jsonl')
assert len(calls)==23
fixture_paths={f['path'] for f in manifest['fixtures']}
for call in calls:
    trace=jsonl(Path(call['trace_path']))
    assert sha(Path(call['trace_path']).read_bytes())==call['trace_sha256']
    assert trace[0]['event']=='instrumentation_started'
    assert trace[0]['argv']==call['invocation']
    observed_opens=[e for e in trace if e['event'] in ('python.audit.open','os.open_attempt') and e.get('path') in fixture_paths]
    if call['returncode']==2:
        assert not call['subject_events'] and not observed_opens
        assert base64.b64decode(call['stdout_b64'])==b''
    for name in ('stdout','stderr'):
        blob=base64.b64decode(call[name+'_b64'])
        assert sha(blob)==call[name+'_sha256']
        assert blob==(ROOT/'calls'/f"{call['label']}.{name}.bin").read_bytes()

main=ROOT/'deployments/main'
route=load(main/'route.json')
seal=load(main/'route-seal.json')
assert sha((main/'route.json').read_bytes())==seal['route_sha256']
assert sha((main/'read-step').read_bytes())==seal['launcher_sha256']
rows=jsonl(main/'runtime/ledger.jsonl')
commits=[e for e in rows if e['event']=='state_commit']
assert [e['data']['step_id'] for e in commits]==['B01','RB01','B02','T01','F01','VR01','T02']
filemap={f['id']:f for f in route['files']}
stepmap={s['id']:s for s in route['steps']}
revisitmap={r['id']:r['initial_step_id'] for r in route['revisits']}
cursor=0
pending=None
coverage={f['id']:[] for f in route['files']}
for commit in commits:
    callrows=[e for e in rows if e['call_id']==commit['call_id']]
    validated=next(e for e in callrows if e['event']=='route_validated')
    assert validated['data']['cursor']==cursor
    assert validated['data']['pending_figure']==pending
    sid=commit['data']['step_id']
    operation=commit['data']['operation']
    if operation=='figure_received':
        assert pending=='F01' and sid=='VR01'
        assert any(e['event']=='figure_receipt_accepted' for e in callrows)
        pending=None
        cursor+=1
        continue
    step=stepmap[revisitmap.get(sid,sid)]
    f=filemap[step['file_id']]
    start,end=(step['start'],step['end']) if step['kind']=='text' else (0,f['size'])
    access=next(e for e in callrows if e['event']=='actual_access')
    output=next(e for e in callrows if e['event']=='stdout_complete')
    assert access['data']['start']==start and access['data']['end']==end
    assert access['data']['sha256']==step['sha256'] and access['data']['verified'] is True
    assert access['index']<next(e['index'] for e in callrows if e['event']=='stdout_begin')<output['index']<commit['index']
    call=next(c for c in calls if commit['call_id'] in c['launcher_call_ids'])
    traced=jsonl(Path(call['trace_path']))
    accesses=[e for e in traced if e['event']=='os.read_returned' and e.get('path')==f['path']]
    assert len(accesses)==1 and accesses[0]['requested']==end-start and accesses[0]['returned']==end-start and accesses[0]['sha256']==step['sha256']
    seeks=[e for e in traced if e['event']=='os.lseek_returned' and e.get('path')==f['path']]
    assert len(seeks)==1 and seeks[0]['returned']==start
    if step['kind']=='text':
        assert output['data']['sha256']==step['sha256'] and call['stdout_sha256']==step['sha256']
    if operation=='revisit':
        assert sid=='RB01' and cursor==1
    else:
        assert route['steps'][cursor]['id']==sid
        coverage[f['id']].append([start,end])
        if operation=='figure_dispatched': pending=sid
        else: cursor+=1
assert cursor==len(route['steps']) and pending is None
for fid,ranges in coverage.items():
    position=0
    for start,end in ranges:
        assert start==position
        position=end
    assert position==filemap[fid]['size']

raw=load(ROOT/'actual-view-result.json')
invocation=load(ROOT/'actual-view-invocation.json')
receipt=load(main/'view-results/F01.json')
assert raw['detail']=='original' and receipt['invocation']==invocation['invocation']
url=raw['image_url']
assert receipt['result_metadata']['image_url_sha256']==sha(url.encode())
assert receipt['result_metadata']['image_url_chars']==len(url)
assert sha(base64.b64decode(url.split(';base64,',1)[1]))==filemap['image']['sha256']
assert receipt['tool_call_id']==invocation['invocation_receipt_id'] and invocation['host_tool_call_id'] is None
accepted=[r for r in rows if r['event']=='figure_receipt_accepted']
assert len(accepted)==1 and accepted[0]['data']['receipt']==receipt
assert accepted[0]['data']['receipt_sha256']==sha((main/'view-results/F01.json').read_bytes())

summary=dict(status='PASS: requested synthetic launcher preflight',non_subject=True,launcher_identity=identity(main/'read-step'),original_launcher_identity=identity(source),route_identity=identity(main/'route.json'),seal_identity=identity(main/'route-seal.json'),call_count=len(calls),successes=sum(c['returncode']==0 for c in calls),expected_rejections=sum(c['returncode']==2 for c in calls),whole_call_outcomes=identity(ROOT/'call-order.jsonl'),ledger_identities=ledgers,complete_main_route_coverage=coverage,final_cursor=cursor,baseline_revisit_cursor_before_and_after=1,actual_view_result=identity(ROOT/'actual-view-result.json'),actual_view_invocation=identity(ROOT/'actual-view-invocation.json'),view_receipt=identity(main/'view-results/F01.json'),limits=['Native ptrace was denied before launcher start; original failed tracer attempt and output preserved in instrumentation-unavailable/ and before-view-exec-result.json. No escalation attempted.','Supplemental instrumentation observes Python audit/open/seek/read operations using a startup module; it is not native syscall tracing. Launcher bytes and executable-plus-step argv remain unchanged.','No host tool-call ID is exposed. Receipt uses a truthful locally assigned invocation-receipt ID tied to actual functions.exec tools.view_image invocation metadata and directly serialized returned object.','The launcher validates receipt structure and claimed metadata; it does not cryptographically attest that a tool ran. Actual raw tool result is retained and compared separately.','Instruction whitelists are not technical access boundaries or erasure of pretraining. A view receipt does not prove semantic inspection or learning.','These fixtures are not teaching or subject content; no actual baseline, teaching, sources, history, sibling files, or additional skills were read.'])
(ROOT/'verification-summary.json').write_bytes(canonical(summary)+b'\n')
report='''Subject-free runner preflight: PASS for all requested behaviors.

The unchanged fixed launcher completed 23 tested calls: 7 successes and 16 expected rejections. Full stdout/stderr bytes and hashes, command argv, timestamps, native launcher call identities, whole native ledgers, and supplemental Python open/seek/read evidence are preserved. Rejections for extra arguments, skipped/unknown steps, unread revisits, absent or path/checksum-only figure receipts, invalid start types/ranges, and mismatched route/launcher identities occurred before any fixture-file open. The valid text slice returned exactly its 15 bytes. The already-read revisit returned that same range at cursor 1, and the following baseline step also began at cursor 1.

The ordered successful route was B01, RB01 (revisit), B02, T01, F01 (dispatch), VR01 (actual view receipt), T02. Whole-route byte coverage, access hashes, returned text hashes, ledger chains and complete call accounting were reconciled. The figure gate held cursor 3 until a receipt derived from the actual tools.view_image(path, detail="original") result was accepted. The complete raw returned object, including image_url bytes, is saved in actual-view-result.json. Its data URL decodes to the exact synthetic PNG. No host tool-call ID was exposed; actual-view-invocation.json explicitly identifies a local invocation-receipt ID and that limitation.

Native syscall tracing was unavailable: ptrace failed before launcher start. That attempt remains in instrumentation-unavailable/ and before-view-exec-result.json. Supplemental Python instrumentation was then used without changing launcher bytes or target argv. It is not a native syscall trace. The launcher cannot cryptographically authenticate a fabricated receipt; acceptance here is supported by the actual preserved view result. An instruction whitelist is not a technical boundary or pretraining erasure; a view receipt does not prove semantic inspection. No subject findings are made.

Exact paths, SHA-256 hashes and detailed verification are in verification-summary.json. calls/ contains every tested launcher result and access trace; call-order.jsonl is the complete ordered call record; deployments/*/runtime/ledger.jsonl preserves all launcher events, including rejections. fixture-manifest.json identifies only synthetic content and the three permitted operational inputs.
'''
(ROOT/'report.txt').write_text(report)
print(json.dumps(summary,indent=2))
