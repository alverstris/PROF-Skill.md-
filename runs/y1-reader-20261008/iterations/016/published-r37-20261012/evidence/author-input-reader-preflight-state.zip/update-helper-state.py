from pathlib import Path
import json, hashlib

R=Path(__file__).parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
M=R/'.prof-state/manifest.json'; T=R/'.prof-state/topics/definite-integrals.json'
m=json.loads(M.read_text()); t=json.loads(T.read_text())
sources=[]; reads=[]
def source(sid,path,locator,note,url=None):
 p=R/path
 s={'id':sid,'path':str(p),'sha256':sha(p),'portions':[{'id':'whole','locator':locator,'disposition':'required','reason':'Required source, operational prerequisite, or read supporting reference.','evidence':[]}]}
 if url:s['url']=url
 sources.append(s)
 reads.append({'source_id':sid,'portion_id':'whole','status':'read','reviewed_sha256':sha(p),'note':note})
source('baseline','inputs/student-baseline.txt','All 247840 raw bytes, all four subjects and both Further Mathematics options.','Read in eleven actual bounded slices before authoring; receipts in evidence/author-baseline-access.jsonl. Exact relevant raw-LF premise locators and reconstruction are in evidence/author-whole-audit.md.')
source('original-pdf','inputs/source/lec18.pdf','Entire six-page PDF, including cover and every original figure.','Read through all six exact rendered PNG/text pairs. Source coverage and terminology/unit corrections are recorded per page in evidence/author-whole-audit.md.','https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/d1b3d809b6505825b5cde0cee823fa0f_lec18.pdf')
for i,note in enumerate(['Original identity and OCW cover.','Cumulative totals/averages/area and rectangle construction; x-squared right sum.','X-squared rectangles and square-staircase top/side figures; pyramid terminology correction.','Normalized volume squeeze, line/triangle case and area-derivative pattern.','Arbitrary sample-point sum and integral definition; borrowing/simple-interest setup.','Principal and remaining-age weighted debt construction; accumulated-unit correction.'],1):
 for ext in ['txt','png']:
  source(f'original-p{i}-{ext}',f'inputs/source/lec18-p{i:02d}.{ext}',f'Entire original PDF page {i}, {ext} representation.',note+(' Exact original image inspected; complete returned object retained.' if ext=='png' else ' Complete extracted text read and checked against original image.'))
refs=['execution-protocol.md','domain-patterns.md','sasis.md','sasis/profile-manifest.json','sasis/student-role.txt','sasis/student-testing-contract.txt','sasis/rewrite-guide.md','state-tool.md','findings-and-rationale.md','execution-research.md']
notes=['Execution, source accounting, reconstruction, current evidence and destination checks.','Applicable mathematical representation, prerequisites, derivation and application patterns.','Explicit iteration mode, fresh-reader two-input confinement and publication-first regeneration.','Complete four-subject baseline identity and current bundled-reference declarations.','Actual chronological reader operating instruction; no exercise-score substitute.','Complete input/access and fresh-reader testing contract.','Whole-report diagnosis and general PROF-only repair workflow.','Strict helper schema, current evidence/dependency snapshots and mechanical limits.','Recovered rationale limits and research-informed teaching obligations.','Source portion, external evidence and recovery controls; engineering inference limits.']
for i,(ref,note) in enumerate(zip(refs,notes),1):source(f'prof-ref-{i}',f'inputs/prof/references/{ref}','Entire current published reference.',note)
source('author-decisions','author-record.md','Complete source, convention, gap-research and coverage record.','Exact required coverage and premises, two inspected primary textbook passages, proposed capabilities C1-C5. Exact baseline locators are corrected in the whole audit; historical freeze-stage pending statements are not current acceptance.')
m['sources']=sources
freeze=json.loads((R/'whole-freeze-manifest.json').read_text())
paths=['teaching/main.md','teaching/hints.md','teaching/solutions.md','teaching/figures/rectangles.png','teaching/figures/pyramid-stack.png','teaching/figures/triangle.png','teaching/figures/borrowing-time.png']
m['outputs']=[{'id':f'teaching-{i}','path':p,'sha256':sha(R/p)} for i,p in enumerate(paths,1)]
m['required_topics'][0]['source_portions']=[{'source_id':s['id'],'portion_id':'whole'} for s in sources]
m['required_topics'][0]['outputs']=[o['id'] for o in m['outputs']]
t['source_reads']=reads
for cid,desc in [('source_correspondence','All six source pages, figure ideas and examples are accounted for.'),('technical','Independent claims, calculations, units and full solutions.'),('sasis','Complete fresh chronological reader and admitted actual access evidence.'),('destination','All actual GitHub prose and math rendering, images, and click routes.'),('publication','Exact Git publication bytes equal the frozen constituents.')]:
 if not any(c['id']==cid for c in m['output_checks']):m['output_checks'].append({'id':cid,'description':desc,'applicable':True,'status':'pending','reason':'Await final independent gate reconciliation.','evidence':[],'dependencies':[]})
put(M,m);put(T,t)
(R/'.prof-state/RUN.md').write_text('D016 / r37 recovery index\n\nExact request: ../inputs/operational-handover.json. Current operative package: inputs/prof at fa7ba01be035d64a5c72cc5037d484fb9afe245f. Frozen seven-file teaching: ../whole-freeze-manifest.json (c392e564d3f15a77a05e2cbfe1a099049cca0cb920d53cf53d4ef34326e93ba2; see file for authoritative full hash). Published exact teaching at 4ca83e8b709f1e52a1bd2a3a2d612ab48722c195; ../publication/teaching-readback.json records actual bytes. Never edit frozen teaching.\n\nSource/coverage/research: ../author-record.md; complete author reconstruction: ../evidence/author-whole-audit.md; exact baseline receipt ranges: ../evidence/author-baseline-access.jsonl. All source and baseline bytes were read before authoring. Current helper declarations bind all sources, read references and seven outputs.\n\nRoot owns browser and independent review coordination; this author alone owns GitHub writes. Reader route sealed in ../reader-route/, awaiting root mechanical admission before fresh reader dispatch. Root provisional whole review finds no material failure. Live GitHub server errors leave destination checks pending.\n\nNext: dispatch fresh reader on route admission; complete independent technical, SASIS/access and live destination gates before disposition. Preserve all actual reports/tool objects. Counts remain16 accepted60 pending; activeD016, nextD018.\n')
print(json.dumps({'sources':len(sources),'outputs':len(paths),'status':'declarations updated; acceptance checks pending'}))
