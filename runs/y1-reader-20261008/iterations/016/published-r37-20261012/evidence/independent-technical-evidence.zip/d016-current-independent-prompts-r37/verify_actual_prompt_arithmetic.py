from fractions import Fraction as F
from pathlib import Path
import json

OUT = Path(__file__).resolve().parent

def integral(coefficients, a, b):
    a, b = F(a), F(b)
    return sum((F(c) * (b**(i+1)-a**(i+1)) / (i+1) for i,c in enumerate(coefficients)), F(0))

def multiply(p, q):
    result = [F(0)] * (len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):
            result[i+j] += F(a)*F(b)
    return result

def as_text(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {k: as_text(v) for k,v in value.items()}
    if isinstance(value, list):
        return [as_text(v) for v in value]
    return value

width = F(1,2)
samples = [i*width for i in range(1,5)]
heights = [3-x for x in samples]
contributions = [width*y for y in heights]
right = sum(contributions)
geometric = F(3+1,2)*2
assert right == F(7,2) < geometric == 4
p1 = {'width': width, 'samples': samples, 'heights': heights, 'contributions': contributions, 'right_sum': right, 'geometric_integral': geometric}

n = 3
width = F(2,n)
right = width*sum((1+i*width)**2 for i in range(1,n+1))
left = width*sum((1+i*width)**2 for i in range(n))
formula = F(26,3)+F(8,n)+F(4,3*n*n)
assert right == formula and right-left == F(16,n)
assert integral([0,0,1],1,3) == F(26,3)
p2 = {'diagnostic_n': n, 'direct_right_sum': right, 'reduced_formula': formula, 'direct_left_sum': left, 'difference': right-left, 'independent_integral_check': integral([0,0,1],1,3)}

p3 = []
for n in (1,4):
    z=F(n)-F(1,4)
    side=(n+1)*(1-z/n)
    assert n-1<z<n and side<1
    p3.append({'n':n,'height':z,'proposed_pyramid_side':side,'stack_top_layer_side':1,'protrusion_detected':True})

negative=integral([-1,2],0,F(1,2))
positive=integral([-1,2],F(1,2),2)
signed=negative+positive
area=-negative+positive
mean=signed/2
assert (negative,positive,signed,area,mean)==(F(-1,4),F(9,4),F(2),F(5,2),F(1))
p4={'negative_signed_part':negative,'positive_part':positive,'signed_integral':signed,'total_area':area,'average_value':mean}

rate=[6000,6000]
weight=[F(27,25),F(-2,25)]
principal=integral(rate,0,1)
debt_poly=multiply(rate,weight)
debt=integral(debt_poly,0,1)
interest=debt-principal
whole_year=principal*F(27,25)
assert (principal,interest,debt,whole_year,whole_year-debt)==(9000,320,9320,9720,400)
p5={'debt_integrand_coefficients_ascending_powers':debt_poly,'principal_dollars':principal,'interest_dollars':interest,'debt_dollars':debt,'whole_year_alternative_dollars':whole_year,'overstatement_dollars':whole_year-debt}

weight=[F(53,50),F(-3,50)]
u_principal=integral([9000],0,1)
u_debt=integral(multiply([9000],weight),0,1)
v_principal=integral([6000],0,F(1,2))+integral([12000],F(1,2),1)
v_debt=integral(multiply([6000],weight),0,F(1,2))+integral(multiply([12000],weight),F(1,2),1)
assert u_principal==v_principal==9000 and u_debt==9270 and v_debt==9225 and u_debt-v_debt==45
finite_changes=[]
for n in (2,3):
    width=F(1,n)
    tags=[i*width for i in range(1,n+1)]
    old=lambda t: F(6000) if t<F(1,2) else F(12000)
    new=lambda t: F(0) if t==F(1,2) else old(t)
    principal_change=width*sum(new(t)-old(t) for t in tags)
    debt_change=width*sum((new(t)-old(t))*(F(53,50)-F(3,50)*t) for t in tags)
    expected=F(-12000,n) if n%2==0 else F(0)
    assert principal_change==expected and debt_change==F(103,100)*expected
    finite_changes.append({'n':n,'fixed_changed_value_K':0,'principal_sum_change_dollars':principal_change,'debt_sum_change_dollars':debt_change})
p6={'U_principal_dollars':u_principal,'U_interest_dollars':u_debt-u_principal,'U_debt_dollars':u_debt,'V_principal_dollars':v_principal,'V_interest_dollars':v_debt-v_principal,'V_debt_dollars':v_debt,'U_minus_V_debt_dollars':u_debt-v_debt,'finite_sum_diagnostics':finite_changes}

result={'scope':'Only calculations demanded by the actual P1-P6 packet; no new question battery.','method':'Exact rational arithmetic, direct finite sums, polynomial multiplication and integration. General geometric containment, sample-independent convergence and finite-point-change limit are proved in the independent answer record.','all_checks_passed':True,'P1':p1,'P2':p2,'P3':p3,'P4':p4,'P5':p5,'P6':p6,'limits':'Finite diagnostic cases support arithmetic and edge-case checks; they do not replace the general proofs. No symbolic engine, external source or proposed teaching solution was used.'}
(OUT/'exact-arithmetic-verification.json').write_text(json.dumps(as_text(result),indent=2)+'\n')
print(json.dumps({'all_checks_passed':True,'actual_prompt_groups_checked':6,'arithmetic':'exact fractions','extra_questions':0}))
