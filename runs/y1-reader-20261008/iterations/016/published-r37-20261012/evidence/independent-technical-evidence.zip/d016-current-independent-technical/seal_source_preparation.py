from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import struct

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
SOURCE = ROOT / 'original-inputs/D016'
OUT = ROOT / 'd016-current-independent-technical'
BASELINE = ROOT / 'd013-clean-r34-20261012/inputs/student-baseline.txt'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

names = ['source-identity.json', 'lec18.pdf']
names += [f'lec18-p{i:02d}.txt' for i in range(1,7)]
names += [f'lec18-p{i:02d}.png' for i in range(1,7)]
assert {p.name for p in SOURCE.iterdir()} == set(names)
records = []
for name in names:
    path = SOURCE / name
    data = path.read_bytes()
    rec = {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': sha(data)}
    if name.endswith('.txt'):
        rec.update({'full_text_read': True, 'read_method': 'Complete cat display in one bounded, untruncated result', 'lines': len(data.decode().splitlines())})
    elif name.endswith('.png'):
        assert data[:8] == b'\x89PNG\r\n\x1a\n'
        width, height = struct.unpack('>II', data[16:24])
        rec.update({'width': width, 'height': height, 'native_view_image_called': True, 'image_result_actually_emitted': True, 'actual_visual_inspection': True, 'detail': 'original'})
    elif name == 'source-identity.json':
        rec['full_metadata_read'] = True
    elif name.endswith('.pdf'):
        rec.update({'full_byte_integrity_checked': True, 'content_inspection_via_all_native_pages': True, 'pdfinfo_pages': 6, 'pdfinfo_bytes': 985183, 'page_points': [612,792]})
        assert len(data) == 985183
    records.append(rec)
identity = json.loads((SOURCE / 'source-identity.json').read_text())
pdf = next(r for r in records if r['path'].endswith('lec18.pdf'))
assert pdf['sha256'] == identity['sha256'] == '3469042c0ca6aa75aa7e420b2bbf726228c31093aea11ddb2fc0044a4404fec0'
assert identity['page_count'] == 6
baseline_data = BASELINE.read_bytes()
assert len(baseline_data) == 247840
assert sha(baseline_data) == '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
baseline = {'path': str(BASELINE.relative_to(ROOT)), 'bytes': len(baseline_data), 'sha256': sha(baseline_data), 'full_read_previously_completed': True, 'current_full_reread_claimed': False, 'current_targeted_warrant_rereads': ['lines 20-40','lines 72-86','lines 172-206','lines 216-230','lines 352-374','lines 408-418'], 'actual_full_prior_coverage': '19 newline-bounded chunks covering all bytes, with the initially truncated combined display repaired by complete rereads in the earlier independent review.'}
save('input-identities-and-access.json', {'material_id': 'D016', 'original_file_count': len(records), 'original_files': records, 'baseline': baseline, 'no_other_subject_input_read': True})
(OUT / 'INPUT-SHA256SUMS').write_text(''.join(r['sha256'] + '  ' + str(ROOT/r['path']) + '\n' for r in records+[baseline]))

coverage = [
    {'page': 1, 'printed_page': None, 'source_portions': ['MIT OCW cover, course/year, attribution and terms links'], 'prep_locations': ['Scope and independence', 'Source-to-demand inventory'], 'complete': True},
    {'page': 2, 'printed_page': 1, 'source_portions': ['Cumulative totals, averages and areas', 'Figure 1 area/rectangle comparison', 'Partition-sum-limit process', 'Example 1 right-endpoint x squared sum'], 'prep_locations': ['1. Rectangle sums and the geometric setting','2. Example 1: x^2 on [0,b]','Figure-by-figure observations'], 'complete': True},
    {'page': 3, 'printed_page': 2, 'source_portions': ['Figure 2 quadratic right rectangles','Figure 3 staircase top and side views','Unit-thickness square layers','Inner/outer comparison geometry and volume bounds'], 'prep_locations': ['2. Example 1: x^2 on [0,b]','3. Staircase solid and the comparison volumes','Figure-by-figure observations'], 'complete': True},
    {'page': 4, 'printed_page': 3, 'source_portions': ['Normalized squeeze limit','Quadratic area','Example 2 linear sum','Figure 4 triangle','Accumulation derivative pattern'], 'prep_locations': ['4. The normalized limit and an independent algebraic check','5. Example 2: x on [0,b] and Figure 4','6. Accumulation and its derivative'], 'complete': True},
    {'page': 5, 'printed_page': 4, 'source_portions': ['Figure 5 tagged rectangle','General partition and sample rule','Expanded/indexed sum and definite-integral limit','Area interpretation','Example 3 simple interest','Borrowing rate conversion','Monthly time grid'], 'prep_locations': ['1. Rectangle sums and the geometric setting','7. Borrowing-rate accumulation and units','8. Simple-interest weighting and total owed','Figure-by-figure observations'], 'complete': True},
    {'page': 6, 'printed_page': 5, 'source_portions': ['Monthly rate-times-width amount','Principal sum and integral','Dimensional interpretation','Remaining-time interest weighting','Final owed integral'], 'prep_locations': ['7. Borrowing-rate accumulation and units','8. Simple-interest weighting and total owed'], 'complete': True},
]
save('coverage.json', {
    'pages': coverage, 'all_original_metadata_read': True, 'all_six_texts_read': True, 'all_six_native_images_viewed_and_emitted': True,
    'numbered_examples': [1,2,3], 'numbered_conceptual_figures': [1,2,3,4,5],
    'conditions_reconstructed': ['a<b and nonnegative-height geometric area','b>0 versus zero or reversed bounds','n positive integer and fixed interval refinement','one sample in each own subinterval','integrability and sample-choice independence','continuity for accumulation derivative','centered aligned square layers of unit thickness','pyramid base area versus prism cross section','rate/time/product units','simple interest, common end time and remaining duration','monthly approximation versus exact lump timing'],
    'source_discrepancies_held': ['prism terminology for comparison pyramids','dollars per year attached to principal integral','unstated positive-b area convention and integrability/continuity qualifications'],
    'source_limitations': ['No learner exercise list in original','Averages named but no developed average example','No unseen review sheet or other lecture imported'],
    'supplementary_independent_check': {'task': '/root/technical_d015_current/d016_geometry_check','admitted_inputs': ['original-inputs/D016/source-identity.json','original-inputs/D016/lec18-p02.txt','original-inputs/D016/lec18-p03.txt','original-inputs/D016/lec18-p04.txt','original-inputs/D016/lec18-p03.png'],'report': 'supplementary-geometry-check.txt','agreement': True,'no_file_mutation_by_child': True},
    'missing_original_portions': [], 'semantic_findings_released_to_author': False,
})
save('verification-record.json', {
    'integrity': 'All 14 original files and exact baseline hashed; PDF SHA matches source identity; pdfinfo confirms six pages and 985183 bytes.',
    'mathematical_checks': [
        {'claim': 'Staircase comparison','method': 'Full cross-section containment for every slab, with independent supplementary reconstruction','result': 'verified under explicit geometry'},
        {'claim': 'Sum of squares limit','method': 'Exact normalized inequality plus independent induction identity and algebraic gap formulas','result': 'verified for every positive integer n'},
        {'claim': 'Quadratic rectangle limit','method': 'Width-times-height construction, left/right gap and normalized sum limit','result': 'verified for b>0, oriented extension separately qualified'},
        {'claim': 'Linear rectangle limit','method': 'Arithmetic progression and independent triangle area','result': 'verified'},
        {'claim': 'Accumulation derivative','method': 'Polynomial differentiation and short-interval averaging under continuity','result': 'verified with conditions'},
        {'claim': 'Borrowed/owed integrals','method': 'Rate-times-duration units, simple-interest slice construction, zero-rate and end-time checks','result': 'verified with model assumptions'},
        {'claim': 'Constant borrowing illustration','method': 'Independent integration and exact discrete-month sum comparison','result': '12360 continuous versus 12330 end-month model; explicitly different timing'},
    ],
    'tool_generated_question_battery': False, 'symbolic_engine_claimed': False, 'extra_numeric_fixtures_created': False,
    'browser_or_external_lookup_used': False, 'older_D016_inputs_read': False,
    'current_package_prompt_teaching_exposed': False,
})

report_records = []
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.name not in ('sourceprep-seal.json','SHA256SUMS'):
        data = path.read_bytes()
        report_records.append({'path': path.name,'bytes': len(data),'sha256': sha(data)})
save('sourceprep-seal.json', {
    'schema': 'd016-current-independent-original-only-seal-v1', 'sealed_at': datetime.now(timezone.utc).isoformat(),
    'reviewer': '/root/technical_d015_current', 'material_id': 'D016', 'lecture': 18,
    'source_pdf_sha256': pdf['sha256'], 'source_pdf_bytes': pdf['bytes'],
    'source_identity_sha256': next(r['sha256'] for r in records if r['path'].endswith('source-identity.json')),
    'original_file_count': 14, 'original_page_count': 6,
    'baseline_sha256': baseline['sha256'], 'baseline_bytes': baseline['bytes'],
    'all_original_metadata_and_text_read': True, 'all_native_page_images_actually_viewed_and_emitted': True,
    'complete_source_to_demand_and_math_reconstruction': True,
    'no_current_package_prompts_or_teaching_used': True,
    'earlier_D016_preparation_and_attempts_excluded': True,
    'semantic_release': 'held until explicit new whole-freeze admission',
    'records': report_records,
})
all_paths = sorted(p for p in OUT.iterdir() if p.is_file() and p.name != 'SHA256SUMS')
(OUT/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in all_paths))
print(json.dumps({'original_files': 14,'original_pages': 6,'original_pdf_bytes': pdf['bytes'],'original_pdf_sha256': pdf['sha256'],'identity_sha256': next(r['sha256'] for r in records if r['path'].endswith('source-identity.json')),'preparation_sha256': sha((OUT/'source-only-preparation.txt').read_bytes()),'seal_sha256': sha((OUT/'sourceprep-seal.json').read_bytes()),'manifest_sha256': sha((OUT/'SHA256SUMS').read_bytes()),'semantic_findings_held': True},indent=2))
