from pathlib import Path
import json,subprocess,concurrent.futures,hashlib
p=Path(__file__).parent;css=sorted({u for n in ['notes','hints','solutions'] for u in json.loads((p/n/'element-style-evidence.json').read_text())['css_urls'] if u});(p/'css').mkdir();items=[(u,p/'css'/Path(u).name,'css') for u in css]
items += [('https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/d1b3d809b6505825b5cde0cee823fa0f_lec18.pdf',p/'official-source-lec18.pdf','source'),('https://raw.githubusercontent.com/alverstris/PROF-Skill.md-/795891699384fc96c5113729db66811c07a42b3b/runs/y1-reader-20261008/iterations/016/current-r22/source/lec18.pdf',p/'frozen-source-lec18.pdf','source'),('https://openstax.org/books/calculus-volume-1/pages/5-2-the-definite-integral',p/'official-openstax-5-2.html','citation')]
def get(it):
 url,f,kind=it;q=subprocess.run(['curl','-L','--fail','--max-time','55','--silent','--show-error',url,'-o',str(f)],capture_output=True,text=True);v=dict(url=url,file=str(f.relative_to(p)),kind=kind,exit=q.returncode,stderr=q.stderr)
 if q.returncode==0:v.update(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())
 return v
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:rows=list(pool.map(get,items))
(p/'support-fetch.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'items':len(rows),'failures':[x for x in rows if x['exit']]}))
