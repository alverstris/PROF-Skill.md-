from pathlib import Path
from html.parser import HTMLParser
import re,json,hashlib,shutil,fitz
p=Path(__file__).parent;norm=lambda x:re.sub(r'\s+',' ',x).strip();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def read(n):return json.loads((p/n).read_text())
def save(n,v):
 with (p/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
class Blocks(HTMLParser):
 def __init__(self):super().__init__();self.current=None;self.parts=[];self.rows=[];self.lists=[]
 def handle_starttag(self,t,a):
  if t in ['p','li']:self.current=t;self.parts=[]
  if t=='ol':self.lists.append(dict(a))
 def handle_data(self,s):
  if self.current:self.parts.append(s)
 def handle_endtag(self,t):
  if t==self.current:self.rows.append(dict(tag=t,text=norm(''.join(self.parts))));self.current=None
rows=[];commands=[];HTML=[]
for name in ['notes','hints','solutions']:
 s=(p/'remote/learner'/f'{name}.md').read_text();a=Blocks();a.feed((p/name/'github-article.html').read_text());regex=r'^(Q[1-6]\.|Figure [1-3]\.|Definition\.|Source and scope$)' if name=='notes' else r'^(Q[1-6] '+('hint' if name=='hints' else 'solution')+r')$';sl=[m[1] for m in re.finditer(regex,s,re.M)];dl=[m[1] for row in a.rows if (m:=re.match(regex,row['text']))];ordered=re.findall(r'^([1-6])\. (.+)$',s,re.M);actualitems=[x['text'] for x in a.rows if x['tag']=='li'];starts=[x.get('start','1') for x in a.lists];rows.append(dict(file=name+'.md',source_labels=sl,actual_paragraph_start_labels=dl,all_exact=sl==dl,source_numbered_labels=ordered,actual_list_item_labels=actualitems,actual_list_starts=starts,all_numbered_labels_exact=[x[1] for x in ordered]==actualitems and [x[0] for x in ordered]==starts))
 for i,t in enumerate(read(name+'/source-math.json'),1):
  if t['format']=='protected':
   ops=[dict(offset=m.start(),command=m[0],following=t['payload'][m.end():m.end()+1],space_terminated=t['payload'][m.end():m.end()+1]==' ') for m in re.finditer(r'\\(?:lt|gt)(?![A-Za-z])',t['payload'])]
   if ops:commands.append(dict(file=name+'.md',ordinal=i,line=t['source_line'],payload=t['payload'],operators=ops,actual_exact=read(name+'/destination-math.json')[i-1]['payload']==t['payload']))
 HTML.append(dict(file=name+'.md',literal_anchor_syntax=re.findall(r'<a name="q[1-6]"></a>',s),actual_targets=read(name+'/navigation.json')['targets'],raw_angle_math_payloads=[t for t in read(name+'/source-math.json') if t['format']=='protected' and re.search('[<>]',t['payload'])]))
save('paragraph-label-list-supplement.json',dict(documents=rows,all_labels_exact=all(x['all_exact'] and x['all_numbered_labels_exact'] for x in rows),explanation='Original paragraph-label-list-check.json used one regex for all three documents. It incorrectly classified notes link-only paragraphs beginning Q1 hint etc as hint section labels. File-specific source/destination label grammar fixes the scope. Original evidence preserved. The six numbered section labels are actual ol/li with correct starts1–6, checked separately. No learner defect.'))
assert all(x['all_exact'] and x['all_numbered_labels_exact'] for x in rows)
save('candidate-inline-instruction-check.json',dict(candidate_skill_path='../candidate-r23-1/SKILL.md',candidate_sha256=sha(p.parent.parent/'candidate-r23-1/SKILL.md'),protected_inline_count=316,strict_payloads=commands,strict_command_count=sum(len(x['operators']) for x in commands),all_space_terminated=all(o['space_terminated'] for x in commands for o in x['operators']),all_strict_payloads_actual_exact=all(x['actual_exact'] for x in commands),all_protected_inline_math_actual_exact=all(x['source_type']!='js-inline-math' for x in read('complete-math-failure-map.json')),HTML_syntax=HTML,literal_HTML_not_globally_substituted=all(len(x['literal_anchor_syntax'])==6 and not x['raw_angle_math_payloads'] for x in HTML),scope='Actual fresh candidate-authored packet and actual destination; all strict protected-inline operators have terminating spaces. Complete destination gate independently detects display thin-space defect. No claim that narrow candidate instruction prevents other parser faults.'))
shutil.copyfile(p.parent.parent/'current-r22/root-navigation-contract.json',p/'root-navigation-contract-copy.json')
source=fitz.open(p/'official-source-lec18.pdf');txt=(p/'openstax-extracted-text.txt').read_text();at=txt.index('Theorem 5.1 Continuous Functions Are Integrable');end=txt.index('It is also worth noting',at);save('citation-identity-check.json',dict(MIT=dict(title_page1=source[0].get_text(),title_page2=source[1].get_text()[:126],official_url='https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/d1b3d809b6505825b5cde0cee823fa0f_lec18.pdf',identity=read('source-PDF-identity.json'),scope='Full fresh byte equality and first two page identity text; whole original technical/visual review not claimed here.'),OpenStax=dict(url='https://openstax.org/books/calculus-volume-1/pages/5-2-the-definite-integral',fetched_HTML_sha256=sha(p/'official-openstax-5-2.html'),page_title='5.2 The Definite Integral - Calculus Volume 1 | OpenStax',actual_read_portion='Theorem5.1 Continuous Functions Are Integrable and immediately following paragraph about a finite number of jump discontinuities',retained_excerpt=txt[at:end],claim_correspondence='The cited theorem supplies continuous-function integrability; following paragraph explicitly extends to otherwise continuous functions with finitely many jump discontinuities. Notes identify these as sufficient results and do not claim a proof.',limits='No whole textbook/page technical review or browser rendering asserted.')))
defs=[]
for f in (p/'css').glob('*.css'):
 for m in re.finditer(r'--base-text-weight-normal\s*:\s*[^;}]+',f.read_text()):defs.append(dict(file=f.name,declaration=m[0]))
save('CSS-normal-weight-definitions.json',defs)
print(json.dumps(dict(paragraph_labels=sum(len(x['source_labels']) for x in rows),numbered_section_labels=sum(len(x['source_numbered_labels']) for x in rows),all_labels_exact=True,strict_commands=sum(len(x['operators']) for x in commands),all_inline_exact=True,all_HTML_preserved=True)))
