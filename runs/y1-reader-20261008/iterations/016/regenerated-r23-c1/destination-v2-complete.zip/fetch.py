from pathlib import Path
import json,subprocess,hashlib,concurrent.futures
p=Path(__file__).parent;commit='80c86f6d11c0cbec403dad2da04ee887ca52ce6f';base='runs/y1-reader-20261008/iterations/016/regenerated-r23-c1/author-v2/';manifest=json.loads((p/'frozen-manifest-copy.json').read_text());items=[]
for x in manifest['constituents']:
 f=p/'remote'/x['relative_path'];f.parent.mkdir(parents=True,exist_ok=True);items.append(('https://raw.githubusercontent.com/alverstris/PROF-Skill.md-/'+commit+'/'+base+x['relative_path'],f,x))
for name in ['notes','hints','solutions']:
 f=p/name/'github-page.html';f.parent.mkdir();items.append(('https://github.com/alverstris/PROF-Skill.md-/blob/'+commit+'/'+base+'learner/'+name+'.md',f,None))
def get(it):
 url,f,meta=it;q=subprocess.run(['curl','-L','--fail','--max-time','55','--silent','--show-error',url,'-o',str(f)],capture_output=True,text=True);v=dict(url=url,path=str(f.relative_to(p)),exit=q.returncode,stderr=q.stderr)
 if q.returncode==0:
  b=f.read_bytes();v.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  if meta:v.update(manifest_exact=v['sha256']==meta['sha256'] and len(b)==meta['bytes'],local_exact=b==(p.parent/'author-v2'/meta['relative_path']).read_bytes())
 return v
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:rows=list(pool.map(get,items))
(p/'initial-fetch.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
