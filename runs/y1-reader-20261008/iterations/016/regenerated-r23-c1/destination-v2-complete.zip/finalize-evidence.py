from pathlib import Path
import json,hashlib,re,datetime
import fitz
p=Path(__file__).parent; v=p/'preview-attempt1'
def read(n):return json.loads((p/n).read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def save(n,d):
 with (p/n).open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
rows=[];allrows=[]
for name in ['notes','hints','solutions']:
 old=json.loads((p.parent/'destination-v1'/name/'source-math.json').read_text());new=read(name+'/source-math.json');actual=read(name+'/destination-math.json');assert len(old)==len(new)==len(actual)
 for i,(o,n,a) in enumerate(zip(old,new,actual),1):
  changed=o['format']!=n['format']; boundary_only=changed and o['format']=='display' and n['format']=='fence' and o['payload']=='\n'+n['payload']+'\n'
  exact=n['payload']==a['payload'] and n['type']==a['type']; preserved=(boundary_only or o['payload']==n['payload']) and o['type']==n['type']
  z=dict(file=name+'.md',ordinal=i,source_line=n['source_line'],source_format=n['format'],old_format=o['format'],actual_exact=exact,underlying_TeX_unchanged=preserved,boundary_LF_only=boundary_only,thinspace_count=n['payload'].count('\\,'))
  allrows.append(z)
  if changed:rows.append(dict(**z,old_source_payload=o['payload'],new_source_payload=n['payload'],actual_payload=a['payload']))
assert len(rows)==14 and sum(x['thinspace_count'] for x in rows)==16
assert all(x['actual_exact'] and x['underlying_TeX_unchanged'] for x in allrows)
save('display-repair-preservation.json',dict(total_expressions=len(allrows),changed_formats=len(rows),changed_thinspace_commands=16,all362_actual_payload_types_exact=True,all_underlying_TeX_unchanged=True,comparison_rule='For exactly14 $$→math-fence conversions, old payload contains one leading and one trailing LF belonging to delimiter boundaries; fenced extraction excludes these syntax LFs. The new source-to-actual payload comparison itself is exact, with no whitespace, punctuation, operator or grouping normalization. All other348 source payloads are byte-identical.',changed_expressions=rows,full_expression_correspondence=allrows))
figtexts={
'rectangles.png':'Full published PNG viewed. Left panel shows the x² region on [0,1]; right panel has four equal-width right-endpoint rectangles, sample dots at right tops, heights 1/16,4/16,9/16,1 and width1/4. Axes, labels and curve are legible; the right rectangles overestimate the increasing curve as explained.',
'staircase.png':'Full published PNG viewed. Plan view shows concentric aligned squares of sides4,3,2,1; side view shows staircase between inner and outer pyramid boundaries. The z=1.5 line and widths2.5,3,3.5 agree with inner≤staircase≤outer comparison. Color key, dimensions and captions legible; no geometry/label mismatch found.',
'sample-rectangle.png':'Full published PNG viewed. Sample c_i lies between x_{i-1} and x_i; height f(c_i) and full interval width Δx are indicated, with dashed construction and axes. The sample point is not forced to an endpoint; labels and arrows agree with the general Riemann-sum explanation.'}
assets=read('asset-manifest.json');save('asset-visual-inspection.json',dict(scope='All three exact freshly fetched immutable PNGs personally viewed in full frames; full preview insertions also viewed on pages2,3,5. No SVG companions in this six-constituent manifest.',figures=[dict(path=x['path'],bytes=x['bytes'],sha256=x['sha256'],full_frame_viewed=True,finding=figtexts[Path(x['path']).name],material_issue=False) for x in assets if x['path'].endswith('.png')]))
observations=[
'Title, route links, section1, rectangle width/height and expanded right sum legible; clear margins and footer.',
'Figure1 complete and legible, caption and left/right sum gap agree; Q1 and both help links visible; section2 and slab setup readable.',
'Pyramid premise and Figure2 complete with legible geometry and containment inequalities. The final divide-by-n³ lead-in continues into the display on page4; no clipping.',
'Opening bound display, squeeze argument, Q2 and help links, then section3 sample-point construction legible.',
'Figure3 complete, caption and sample notation clear; Riemann sum/midpoint and definition displays readable. Definition paragraph continues to page6.',
'Continuation, sufficient integrability conditions and citation, signed area/units, Q3 links, triangle and endpoint discussion readable. Last derivative-display lead-in continues onto page7.',
'Opening derivative display, strip explanation, FTC relation, Q4 and help links, average-value formula, section5 borrowing setup all readable.',
'Borrowing sum/integral, units correction, simple-interest assumptions, loan duration and underbraced factor display clear. Closing sentence continues on page9; body remains above footer.',
'Continuation, continuous versus month-end numerical comparisons, general settlement-time integral, Q5 and its two links readable.',
'Section6, Q6 full task and help links, source/scope paragraph and MIT citation readable. Deliberate file-seam page break leaves blank space below.',
'All six hint labels and complete hint prose/math legible with individual return and solution links. Global solutions link visible; all hints on one page and no worked solutions on it.',
'Solution opening, Q1 complete reasoning/error routes/return/hint links and Q2 start legible. Q2 divide-by-n³ lead-in continues into page13 display.',
'Q2 bounds and final limit with return/hint links, then complete Q3 working and return/hint links readable; no missing expression.',
'Complete Q4 strip/algebra solution and links, Q5 integral evaluation and timing explanation readable. Q5 continues on page15.',
'Q5 units/model conclusion with links, complete Q6 signed displacement/distance/averages/right sum and final return/hint links legible; clean ending.'
]
assert len(observations)==15
pdf=v/'verified-build.pdf';digest=sha(pdf);assert digest=='dd4bf22a876dddc8627578285f876fbbf039153bf179bc2de66535e35d7eb2d3'
save('preview-attempt1/full-page-visual-review.json',dict(canonical_pdf='verified-build.pdf',sha256=digest,all15_pages_personally_viewed=True,method='Each complete page-01.png through page-15.png opened as a full image using view_image, not a montage or text summary. Rasters tied pixel-exact to fresh-open canonical PDF by fresh-document-raster-verification.json.',pages=[dict(page=i,png=f'page-{i:02}.png',png_sha256=sha(v/f'page-{i:02}.png'),full_frame_viewed=True,observation=t,material_issue=False) for i,t in enumerate(observations,1)],pagination_limits='Ordinary sentence continuations and display lead-ins cross pages3/4,5/6,6/7,8/9,12/13,14/15. This is a complete internal fidelity preview, not a polished user-facing PDF.',typography='Normal-weight upright prose and link labels; conventional mathematical italic. Full figures and math legible; no visually observed clipping or overlap.'))
doc=fitz.open(pdf);bounds=[]
for i,page in enumerate(doc,1):
 blocks=[b for b in page.get_text('blocks') if b[6]==0];foot=[b for b in blocks if b[4].strip()==str(i) and b[1]>page.rect.height*.85];assert len(foot)==1
 body=[b for b in blocks if b not in foot and not (b[4].strip()=='Definite integrals' and b[1]<60)]
 maxy=max(b[3] for b in body);bounds.append(dict(page=i,body_text_bottom_pt=maxy,footer_text_top_pt=foot[0][1],clearance_pt=foot[0][1]-maxy,all_text_in_page=all(b[0]>=0 and b[1]>=0 and b[2]<=page.rect.width and b[3]<=page.rect.height for b in blocks),body_above_footer=maxy<foot[0][1]))
assert all(x['all_text_in_page'] and x['body_above_footer'] for x in bounds)
save('preview-attempt1/text-footer-bounds.json',dict(canonical_sha256=digest,all15_text_bounds_pass=True,pages=bounds,scope='Text-block bounding boxes corroborate full-frame visual review; not a substitute for complete ink/figure viewing. No raster generated from this text-extracted PDF instance.'))
assert sha(pdf)==digest and pdf.read_bytes()==(v/'main.pdf').read_bytes() and len(doc)==15
save('preview-attempt1/final-integrity.json',dict(file='verified-build.pdf',bytes=pdf.stat().st_size,sha256=digest,pages=15,EOF=pdf.read_bytes().rstrip().endswith(b'%%EOF'),main_pdf_identical=True,all_fresh_first_render_rasters_exact=read('preview-attempt1/fresh-document-raster-verification.json')['all_fresh_doc_rasters_exact'],checked_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print(json.dumps(dict(repaired_expressions=len(rows),preserved_thinspaces=sum(x['thinspace_count'] for x in rows),viewed_pages=15,pdf_sha256=digest,min_footer_clearance=min(x['clearance_pt'] for x in bounds))))
