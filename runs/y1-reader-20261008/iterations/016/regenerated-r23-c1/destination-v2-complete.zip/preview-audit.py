from pathlib import Path
import json,re,hashlib,fitz,itertools,copy
from PIL import Image
p=Path(__file__).parent;o=p/'preview-attempt1';names=['notes','hints','solutions']
def read(n):return json.loads((p/n).read_text())
def save(n,v):
 with (p/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2,default=str);f.write('\n')
def nodes(x,t):
 if isinstance(x,dict):
  if x.get('t')==t:yield x
  for v in x.values():yield from nodes(v,t)
 elif isinstance(x,list):
  for v in x:yield from nodes(v,t)
def stream(x):
 if isinstance(x,list):return ''.join(stream(v) for v in x)
 if not isinstance(x,dict):return ''
 t=x.get('t');c=x.get('c')
 if t=='Str':return c
 if t in ['Space','SoftBreak','LineBreak']:return ' '
 if t=='Math':
  delim='$$' if c[0]['t']=='DisplayMath' else '$';return delim+c[1]+delim
 if t in ['Link','Span']:return stream(c[1])
 if t in ['RawInline','RawBlock','Image']:return ''
 if t in ['Para','Plain']:return stream(c)+'\n'
 return stream(c)
norm=lambda s:re.sub(r'\s+',' ',s).strip();sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();ast=read('preview-attempt1/preview-ast.json');maps=read('preview-attempt1/conversion-map.json');math=[x for name in names for x in read(name+'/source-math.json')];asts=[read('preview-attempt1/'+name+'-source-ast.json') for name in names];sourceblocks=[block for a in asts for block in a['blocks']];sourcehrefs=[x['c'][2][0] for a in asts for x in nodes(a,'Link')];expectedstream=' '.join((p/name/'expected-prose-math-stream.txt').read_text() for name in names);aststream=stream(ast['blocks']);(o/'AST-prose-math-stream.txt').write_text(aststream)
# Compare the full content AST after reversing only recorded presentation mappings.
reverse_links={x['PDF_href']:x['source_href'] for x in maps['links']};reverse_images={x['PDF']:x['source'] for x in maps['images']}
def canonical(x):
 if isinstance(x,list):return [y for v in x if (y:=canonical(v)) is not None]
 if not isinstance(x,dict):return x
 t=x.get('t');c=x.get('c')
 if t in ['RawInline','RawBlock']:return None
 if t=='Str' and c=='':return None
 if t=='Span' and not c[1]:return None
 obj={k:canonical(v) for k,v in x.items()}
 if t=='Link':obj['c'][2][0]=reverse_links.get(obj['c'][2][0],obj['c'][2][0])
 if t=='Image':obj['c'][2][0]=reverse_images.get(obj['c'][2][0],obj['c'][2][0])
 if t in ['Para','Plain'] and not obj['c']:return None
 return obj
sourcecanonical=canonical(sourceblocks);finalcanonical=canonical(ast['blocks']);(o/'source-content-canonical-AST.json').write_text(json.dumps(sourcecanonical));(o/'preview-content-canonical-AST.json').write_text(json.dumps(finalcanonical))
sourceids=[dict(file=name+'.md',id=i) for name in names for i in re.findall(r'<a name="([^"]+)"></a>',(p/'remote/learner'/f'{name}.md').read_text())];expectedanchors=[name+'--entry' for name in names]+[x['PDF'] for x in maps['anchors']];mappedlinks=[x['PDF_href'] for x in maps['links']];previewlinks=[x['c'][2][0] for x in nodes(ast,'Link')];sourceimgs=[x for a in asts for x in nodes(a,'Image')];previewimgs=list(nodes(ast,'Image'))
proof=dict(complete_prose_math_stream_exact_after_whitespace_folding=norm(aststream)==norm(expectedstream),complete_content_AST_exact_after_recorded_mapping=sourcecanonical==finalcanonical,all362_math_payloads_exact=[x['c'][1] for x in nodes(ast,'Math')]==[x['payload'] for x in math],all362_math_types_exact=[x['c'][0]['t'] for x in nodes(ast,'Math')]==['DisplayMath' if x['type']=='js-display-math' else 'InlineMath' for x in math],all18_source_anchors_mapped=[dict(file=x['source_file'],id=x['source']) for x in maps['anchors']]==sourceids,all21_preview_anchor_names_unique=len(expectedanchors)==len(set(expectedanchors))==21 and sorted(x['c'][0][0] for x in nodes(ast,'Span') if x['c'][0][0])==sorted(expectedanchors),all40_crossfile_links_mapped_in_order=[x for x in previewlinks if x.startswith('#')]==mappedlinks,all42_links_recover_source_hrefs=[reverse_links.get(x,x) for x in previewlinks]==sourcehrefs,all3_image_paths_recover_source=[reverse_images[x['c'][2][0]] for x in previewimgs]==[x['c'][2][0] for x in sourceimgs],all3_image_alts_exact=[x['c'][1] for x in previewimgs]==[x['c'][1] for x in sourceimgs],all3_original_assets_copied_exact=all((o/'figures'/f.name).read_bytes()==f.read_bytes() for f in (p/'remote/learner/figures').iterdir()),source_style_exact=(o/'prof.sty').read_bytes()==(p.parents[5]/'assets/latex/prof.sty').read_bytes(),no_forced_emphasis_nodes=not any(list(nodes(ast,t)) for t in ['Strong','Emph']),no_unexpected_raw_AST_blocks=all(x['c']==['latex',r'\clearpage'] or x['c']==['latex',r'\Needspace{6\baselineskip}'] for x in nodes(ast,'RawBlock')),adaptations=['Protected inline/fenced math converted to Pandoc delimiters, then exact original payloads restored.','All3 files combined in notes→hints→solutions order with PDF-only clearpage at document seams.','18 named anchors prefixed by source document, plus3 file-entry targets for fragment-free file links.','40 crossfile links rewritten to exact mapped native targets; external2 URLs unchanged.','Three original PNGs copied byte-exact and included at full line width; no asset conversion or recreated diagrams.','Current prof.sty; Needspace before section/hint/solution labels; explicit preamble glyph declarations only.'])
save('preview-attempt1/AST-content-check.json',proof)
f=o/'verified-build.pdf';b=f.read_bytes();assert b'%%EOF' in b[-1024:];d=fitz.open(stream=b,filetype='pdf');digest=hashlib.sha256(b).hexdigest();dest=d.resolve_names();links=[dict(from_page=i+1,**x) for i,page in enumerate(d) for x in page.get_links()];named=[x for x in links if 'nameddest' in x];fonts=sorted({sp['font'] for page in d for block in page.get_text('dict')['blocks'] if 'lines' in block for line in block['lines'] for sp in line['spans']});hp={f'q{i}':dest[f'hints--q{i}']['page']+1 for i in range(1,7)};ap={f'q{i}':dest[f'solutions--q{i}']['page']+1 for i in range(1,7)}
pdfproof=dict(canonical_file='preview-attempt1/verified-build.pdf',sha256=digest,bytes=len(b),pages=len(d),digest_matches_successful_build=digest==read('preview-attempt1/preview-check.json')['pdf_sha256'],all21_targets_exist=all(x in dest for x in expectedanchors),all40_logical_links_in_order=['#'+k for k,g in itertools.groupby(x['nameddest'] for x in named)]==mappedlinks,all_native_links_resolve=all(x['nameddest'] in dest and x.get('page')==dest[x['nameddest']]['page'] and 0<=x['page']<len(d) for x in named),all2_external_URLs_preserved=set(x.get('uri') for x in links if x.get('uri'))==set(x for x in sourcehrefs if x.startswith('https:')),hint_pages=hp,solution_pages=ap,hint_solution_page_sets_disjoint=set(hp.values()).isdisjoint(ap.values()),all_solutions_after_hints=min(ap.values())>max(hp.values()),font_inventory=fonts,no_bold_or_italic_prose_font=all(not any(t in x for t in ['Bold','Oblique','Slant']) and ('Italic' not in x or 'Math' in x) for x in fonts),destinations=dest,links=links,scope='Native PDF annotation/destination data; no PDF-viewer clicks; no inference to GitHub client behavior.')
landing=[]
for i in range(1,7):
 for file in names:
  label=f'Q{i}.' if file=='notes' else f'Q{i} '+('hint' if file=='hints' else 'solution')
  key=file+'--q'+str(i);actual_page=dest[key]['page']+1
  pattern=r'(?m)^'+re.escape(label)+(r' ' if file=='notes' else r'$')
  lo=dest[file+'--entry']['page']+1;hi=(dest['hints--entry']['page'] if file=='notes' else dest['solutions--entry']['page'] if file=='hints' else len(d))
  pages=[j+1 for j,page in enumerate(d) if lo<=j+1<=hi and re.search(pattern,page.get_text())]
  landing.append(dict(target=key,label=label,target_page=actual_page,label_pages=pages,correct_target_page=actual_page in pages))
pdfproof['all18_task_help_targets_land_on_label_pages']=all(x['correct_target_page'] for x in landing);pdfproof['target_label_correspondence']=landing
entries=[]
for file in names:
 title=(p/'remote/learner'/(file+'.md')).read_text().splitlines()[0];pages=[i+1 for i,page in enumerate(d) if norm(title) in norm(page.get_text())];ident=file+'--entry';entries.append(dict(target=ident,label=title,target_page=dest[ident]['page']+1,label_pages=pages,correct=dest[ident]['page']+1 in pages))
pdfproof['all3_entry_targets_land_on_titles']=all(x['correct'] for x in entries);pdfproof['entry_correspondence']=entries
save('preview-attempt1/navigation-fonts.json',pdfproof)
rasters=[]
for i,page in enumerate(d,1):
 pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5));im=Image.open(o/f'page-{i:02}.png').convert('RGB');rasters.append(dict(page=i,dimensions_equal=im.size==(pix.width,pix.height),all_RGB_pixels_exact=im.tobytes()==pix.samples,sha256=sha(o/f'page-{i:02}.png')))
save('preview-attempt1/exact-PDF-raster-correspondence.json',dict(canonical_sha256=digest,rasters=rasters,canonical_bytes_stable=f.read_bytes()==b,main_pdf_identical=(o/'main.pdf').read_bytes()==b))
print(json.dumps(dict(AST=proof,PDF={k:v for k,v in pdfproof.items() if k not in ['destinations','links']},all_rasters_exact=all(x['all_RGB_pixels_exact'] for x in rasters)),indent=2))
