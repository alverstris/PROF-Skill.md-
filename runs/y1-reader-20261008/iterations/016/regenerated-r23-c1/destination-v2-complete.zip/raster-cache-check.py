from pathlib import Path
import fitz,json,hashlib
from PIL import Image,ImageChops
p=Path(__file__).parent;o=p/'preview-attempt1';b=(o/'verified-build.pdf').read_bytes();d=fitz.open(stream=b,filetype='pdf');rows=[]
for i,page in enumerate(d,1):
 pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5));im=Image.open(o/f'page-{i:02}.png').convert('RGB');rows.append(dict(page=i,all_RGB_pixels_exact=im.tobytes()==pix.samples,dimensions_equal=im.size==(pix.width,pix.height)))
# Reproduce the only changed operation in earlier validation: extraction of embedded image data before rerasterization.
x=fitz.open(stream=b,filetype='pdf');before=x[1].get_pixmap(matrix=fitz.Matrix(1.5,1.5)).samples
for page in x:page.get_text('dict')
after=x[1].get_pixmap(matrix=fitz.Matrix(1.5,1.5)).samples
record=dict(canonical_sha256=hashlib.sha256(b).hexdigest(),canonical_still_exact=(o/'verified-build.pdf').read_bytes()==b,all_fresh_doc_rasters_exact=all(z['all_RGB_pixels_exact'] for z in rows),rasters=rows,earlier_record='exact-PDF-raster-correspondence.json retained unchanged; after get_text(dict) on its open document image pages2,3,5 differed, other12matched.',diagnostic=dict(page=2,before_and_after_get_text_dict_same=before==after,changed_RGB_bytes=sum(a!=b for a,b in zip(before,after))),interpretation='Freshly opened canonical PDF gives pixel-exact saved PNGs. The earlier comparison used the document after image-containing get_text(dict) extraction; this reproducible in-memory extraction/raster interaction is a review-tool limitation, not a PDF byte change. No PDF rebuild or replacement of original rasters.',root_independent_confirmation='Root separately rerendered all15pages pixel-exact; root-v2-preview-review.json is outside reviewer ownership.')
with (o/'fresh-document-raster-verification.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2))
