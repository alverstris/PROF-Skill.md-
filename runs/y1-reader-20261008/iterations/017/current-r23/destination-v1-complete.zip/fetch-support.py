from pathlib import Path
import json,subprocess,concurrent.futures,hashlib
p=Path(__file__).parent;names=['lesson','hints','solutions'];css=sorted({u for n in names for u in json.loads((p/n/'element-style-evidence.json').read_text())['css_urls'] if u});(p/'css').mkdir();items=[(u,p/'css'/Path(u).name,'css') for u in css]
items += [('https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/817a2c46ddc23e2efda247a79ddeed34_lec19.pdf',p/'official-source-lec19.pdf','source'),('https://raw.githubusercontent.com/alverstris/PROF-Skill.md-/ae08f92832c91a7a5652ca874ffe807afedf38a9/runs/y1-reader-20261008/iterations/017/current-r23/source/lec19.pdf',p/'frozen-source-lec19.pdf','source'),('https://openstax.org/books/calculus-volume-1/pages/5-4-integration-formulas-and-the-net-change-theorem',p/'official-openstax-5-4.html','citation'),('https://openstax.org/books/calculus-volume-1/pages/5-5-substitution',p/'official-openstax-5-5.html','citation'),('https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/resources/lec19/',p/'official-MIT-resource.html','citation')]
def get(it):
 url,f,kind=it;q=subprocess.run(['curl','-L','--fail','--max-time','55','--silent','--show-error',url],capture_output=True);v=dict(url=url,file=str(f.relative_to(p)),kind=kind,exit=q.returncode,stderr=q.stderr.decode(errors='replace'))
 with f.open('xb') as out:out.write(q.stdout)
 if q.returncode==0:v.update(bytes=f.stat().st_size,sha256=hashlib.sha256(q.stdout).hexdigest())
 return v
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:rows=list(pool.map(get,items))
with (p/'support-fetch.json').open('x') as f:json.dump(rows,f,indent=2);f.write('\n')
print(json.dumps({'items':len(rows),'failures':[x for x in rows if x['exit']]}))
