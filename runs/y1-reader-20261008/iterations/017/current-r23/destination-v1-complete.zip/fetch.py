from pathlib import Path
import json,subprocess,hashlib,concurrent.futures
p=Path(__file__).parent;commit='ae08f92832c91a7a5652ca874ffe807afedf38a9';base='runs/y1-reader-20261008/iterations/017/current-r23/author/';manifest=json.loads((p/'frozen-manifest-copy.json').read_text());items=[]
for x in manifest['constituents']:
 f=p/'remote'/x['relative_path'];f.parent.mkdir(parents=True,exist_ok=True);items.append(('https://raw.githubusercontent.com/alverstris/PROF-Skill.md-/'+commit+'/'+base+x['relative_path'],f,x))
for name in ['lesson','hints','solutions']:
 f=p/name/'github-page.html';f.parent.mkdir();items.append(('https://github.com/alverstris/PROF-Skill.md-/blob/'+commit+'/'+base+'learner/'+name+'.md',f,None))
def get(it):
 url,f,meta=it;q=subprocess.run(['curl','-L','--fail','--max-time','55','--silent','--show-error',url],capture_output=True);v=dict(url=url,path=str(f.relative_to(p)),exit=q.returncode,stderr=q.stderr.decode(errors='replace'))
 with f.open('xb') as out:out.write(q.stdout)
 if q.returncode==0:
  b=q.stdout;v.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
  if meta:v.update(manifest_exact=v['sha256']==meta['sha256'] and len(b)==meta['bytes'],local_exact=b==(p.parent/'author'/meta['relative_path']).read_bytes())
 return v
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:rows=list(pool.map(get,items))
with (p/'initial-fetch.json').open('x') as f:json.dump(rows,f,indent=2);f.write('\n')
print(json.dumps(rows,indent=2))
