from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urljoin
import json,re,hashlib,difflib,fitz
from PIL import Image
p=Path(__file__).parent;commit='ae08f92832c91a7a5652ca874ffe807afedf38a9';prefix='/alverstris/PROF-Skill.md-/blob/'+commit+'/runs/y1-reader-20261008/iterations/017/current-r23/author/learner/';names=['lesson','hints','solutions'];norm=lambda s:re.sub(r'\s+',' ',s).strip()
def read(n):return json.loads((p/n).read_text())
def save(n,d):
 with (p/n).open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2);f.write('\n')
class Text(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.text=[];self.parts=[];self.rows=[];self.on=None;self.em=False;self.emtexts=[];self.empl=[]
 def handle_starttag(self,t,a):
  if t in ['p','li']:self.on=t;self.parts=[]
  if t=='em':self.em=True;self.empl=[]
 def handle_data(self,s):
  self.text.append(s)
  if self.on:self.parts.append(s)
  if self.em:self.empl.append(s)
 def handle_endtag(self,t):
  if t==self.on:self.rows.append(dict(tag=t,text=norm(''.join(self.parts))));self.on=None
  if t=='em':self.em=False;self.emtexts.append(''.join(self.empl))
allrows=[];fails=[];chars=[];strict=[];docs=[];prose=[];labels=[];styles=[];images=[];nav={n:read(n+'/navigation.json') for n in names}
for name in names:
 s=(p/'remote/learner'/f'{name}.md').read_text();src=read(name+'/source-math.json');dst=read(name+'/destination-math.json');article=(p/name/'github-article.html').read_text();rawnodes=re.findall(r'<math-renderer\b[^>]*>.*?</math-renderer>',article,re.S)
 # Fault-aware alignment only; each aligned pair is still compared exactly and every source is retained.
 a=[(x['type'],x['payload'].replace('\\,',',')) for x in src];b=[(x['type'],x['payload']) for x in dst];mapping={}
 for op,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
  if op=='equal':mapping.update({ii:kk for ii,kk in zip(range(i,j),range(k,l))})
  else:assert op=='delete' and name=='lesson' and (i,j)==(24,26),(name,op,i,j,k,l)
 for i,x in enumerate(src):
  k=mapping.get(i);y=dst[k] if k is not None else None;exact=y is not None and x['type']==y['type'] and x['payload']==y['payload'];before=s[:x['span'][0]];sec=re.findall(r'^(?:U\d+\..*|P\d+\..*|Hint P\d+|Solution P\d+)$',before,re.M)
  row=dict(file=name+'.md',source_ordinal=i+1,destination_ordinal=k+1 if k is not None else None,source_line=x['source_line'],source_span=x['span'],section=sec[-1] if sec else 'opening',format=x['format'],source_type=x['type'],actual_type=y['type'] if y else None,source_payload=x['payload'],actual_payload=y['payload'] if y else None,exact=exact)
  if not exact:
   row['kind']='spacing_command_backslash_loss' if y else 'math_node_missing_underscore_emphasis_collision';row['raw_HTML']=rawnodes[k] if y else re.search(r'<p[^>]*>The course writes.*?</p>',article,re.S)[0]
   row['implication']='The intended TeX thin space becomes a literal comma token before the differential; expression punctuation is changed, not merely visual whitespace.' if y else 'The endpoint evaluation expression is no longer a math node; its subscript underscore is consumed by Markdown emphasis spanning two expressions and the prose word or. Endpoint grouping/notation is not preserved.'
   fails.append(row)
   if y:
    assert x['payload'].replace('\\,',',')==y['payload'];payloadstart=x['span'][0]+(2 if x['format']=='display' else 1)
    for m in re.finditer(r'\\,',x['payload']):
     at=payloadstart+m.start();assert s[at:at+2]=='\\,';chars.append(dict(file=name+'.md',source_ordinal=i+1,destination_ordinal=k+1,line=s[:at].count('\n')+1,column=at-s.rfind('\n',0,at),character_offset=at,UTF8_byte_offset=len(s[:at].encode()),source_command='\\,',actual=',',source_payload=x['payload'],actual_payload=y['payload']))
  allrows.append(row)
  for m in re.finditer(r'\\(?:lt|gt)(?![A-Za-z])',x['payload']):strict.append(dict(file=name+'.md',source_ordinal=i+1,source_line=x['source_line'],format=x['format'],payload=x['payload'],command=m[0],next_character=x['payload'][m.end():m.end()+1],space_terminated=x['payload'][m.end():m.end()+1]==' ',actual_exact=exact,protected_inline_rule_trigger=x['format']=='protected'))
 expected=(p/name/'expected-prose-math-stream.txt').read_text().strip();actual=(p/name/'actual-prose-math-stream.txt').read_text().strip();explained=expected.replace('\\,',',')
 if name=='lesson':explained=explained.replace('$F(x)|_a^b$','$F(x)|a^b$').replace('$F(x)|_{x=a}^{x=b}$','$F(x)|{x=a}^{x=b}$')
 prose.append(dict(file=name+'.md',literal_prose_math_exact=expected==actual,all_difference_explained_by_recorded_math_faults=explained==actual,nonmath_prose_preserved=explained==actual,method='Counterfactual diagnostic only: compare original expected stream after exactly recorded thin-space losses and two missing underscores. Not accepted preservation, not HTML re-unescape; original full streams and differences retained.'))
 text=Text();text.feed(article);regex=r'^(U\d+\.|P\d+\.|Figure \d+\.|Source route$)' if name=='lesson' else (r'^(Hint P\d+)$' if name=='hints' else r'^(Solution P\d+)$');sl=re.findall(regex,s,re.M);dl=[m[0] for row in text.rows if (m:=re.match(regex,row['text']))];parts=re.findall(r'^\([ab]\)',s,re.M);actualparts=[m[0] for row in text.rows if (m:=re.match(r'^\([ab]\)',row['text']))];labels.append(dict(file=name+'.md',source_labels=sl,actual_labels=dl,all_exact=sl==dl,source_parts=parts,actual_parts=actualparts,parts_exact=parts==actualparts,source_list_markers=re.findall(r'^\s*(?:\d+\.|[-*+]) ',s,re.M)))
 ids=re.findall(r'<a (?:name|id)="([^"]+)"></a>',s);hrefs=re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',s);actualhrefs=[z for z in nav[name]['links'] if '/figures/' not in z['href']];eh=[urljoin('https://github.com'+prefix+name+'.md',h).removeprefix('https://github.com') for h in hrefs];docs.append(dict(file=name+'.md',source_ids=ids,actual_targets=nav[name]['targets'],targets_exact=[t['value'] for t in nav[name]['targets']]==['user-content-'+i for i in ids],targets_unique=len(ids)==len(set(ids)),source_hrefs=hrefs,expected_actual_hrefs=eh,actual_hrefs=actualhrefs,hrefs_exact=[z['href'] for z in actualhrefs]==eh))
 st=read(name+'/element-style-evidence.json');styles.append(dict(file=name+'.md',tags=st['tags'],inline_styles=st['inline_styles'],emphasis_text=text.emtexts,no_emphasis_nodes=not any(st['tags'].get(t,0) for t in ['em','i','b','strong','h1','h2','th','dt'])))
 si=re.findall(r'!\[([^\]]*)\]\(([^)]+)\)',s);di=read(name+'/image-markup.json');images.append(dict(file=name+'.md',source_images=si,actual_images=di,count_exact=len(si)==len(di),alts_exact=[z[0] for z in si]==[z.get('alt') for z in di],immutable_paths_exact=all(z[1] in q.get('src','') and commit in q.get('src','') for z,q in zip(si,di))))
save('full-expression-correspondence.json',allrows);save('aligned-complete-math-failure-map.json',fails);save('all-thinspace-character-failures.json',chars);save('full-prose-diagnosis.json',prose);save('paragraph-label-list-check.json',labels);save('image-reference-check.json',images)
save('strict-comparison-lexical-check.json',dict(all_inline_plain_dollars=True,protected_inline_count=0,strict_command_count=len(strict),non_space_terminated_count=sum(not x['space_terminated'] for x in strict),all_strict_payloads_actual_exact=all(x['actual_exact'] for x in strict),instances=strict,interpretation='Four non-space-terminated commands are lexical observations, not actual payload losses. Current r23 explicitly conditions its terminating-space instruction on GitHub dollar/backtick inline mathematics. This packet uses ordinary dollar inline math throughout, so that conditional is not triggered; do not mislabel this as a proved conditional-rule breach. Overall destination preservation obligation applies and fails independently.'))
def sec(n,id):
 ts=nav[n]['targets'];start=next(t['element'] for t in ts if t['value']=='user-content-'+id);end=min([t['element'] for t in ts if t['element']>start]+[10**9]);return [z['href'] for z in nav[n]['links'] if start<z['element']<end]
globalHS=prefix+'solutions.md' in [z['href'] for z in nav['hints']['links']];chains=[]
for i in range(1,6):
 q,h,a=sec('lesson',f'p{i}'),sec('hints',f'h{i}'),sec('solutions',f's{i}');c=dict(task_hint=prefix+f'hints.md#h{i}' in q,task_solution=prefix+f'solutions.md#s{i}' in q,hint_task=prefix+f'lesson.md#p{i}' in h,solution_task=prefix+f'lesson.md#p{i}' in a,solution_hint=prefix+f'hints.md#h{i}' in a,global_hint_solution=globalHS);chains.append(dict(task=f'P{i}',checks=c,all_required_routes=all(c.values()),hint_solution_scope='Global solutions-file entry followed by matched Solution P label; no per-hint direct solution link claimed.',actual_links=dict(task=q,hint=h,solution=a)))
refs=[]
for d in docs:
 for z in d['actual_hrefs']:
  if z['href'].startswith(prefix):
   file,_,frag=z['href'][len(prefix):].partition('#');n=file.removesuffix('.md');valid=n in names and (not frag or sum(t['value']=='user-content-'+frag for t in nav[n]['targets'])==1);refs.append(dict(from_file=d['file'],href=z['href'],file=file,fragment=frag or None,valid=valid))
save('positive-navigation-audit.json',dict(documents=docs,named_targets=sum(len(d['source_ids']) for d in docs),crossfile_refs=refs,all_refs_valid=all(z['valid'] for z in refs),positive_chains=chains,all5_chains_complete=all(z['all_required_routes'] for z in chains),mapping_scope='Actual server emitted id=user-content-* and rewritten immutable file fragments correspond. This is not literal fragment/id equality and not an observed browser click. Hints and solutions are separate immutable files.'))
css=[];normal=[]
for f in (p/'css').glob('*.css'):
 text=f.read_text()
 for m in re.finditer(r'--base-text-weight-normal\s*:\s*[^;}]+',text):normal.append(dict(file=f.name,declaration=m[0]))
 for m in re.finditer(r'([^{}]+)\{([^{}]*)\}',text):
  sel,body=m.groups()
  if ('markdown-body' in sel or sel.strip() in ['body','p','a','article','li','em']) and ('font-style' in body or 'font-weight' in body):css.append(dict(file=f.name,selector=sel,declarations=body))
save('css-font-rules.json',css);save('CSS-normal-weight-definitions.json',normal);save('style-audit.json',dict(documents=styles,fetched_css=len(list((p/'css').glob('*.css'))),known_failure='One actual em span in lesson line20 crosses malformed mathematical text and prose or. Normal surrounding prose has no forced emphasis nodes; current CSS retained for actual selector assessment.',scope='Server markup and fetched CSS, not live computed style/browser pixels.'))
assets=[]
for x in read('initial-fetch.json'):
 if not x['path'].startswith('remote/'):continue
 x=dict(x)
 if x['path'].endswith('.png'):x.update(dimensions=list(Image.open(p/x['path']).size),full_frame_personally_viewed=True)
 assets.append(x)
save('asset-manifest.json',assets)
files=[p/'official-source-lec19.pdf',p/'frozen-source-lec19.pdf',p.parent/'source/lec19.pdf'];hs=[hashlib.sha256(f.read_bytes()).hexdigest() for f in files];d=fitz.open(files[0]);save('source-PDF-identity.json',dict(files=[str(f) for f in files],sha256=hs,all_three_exact=len(set(hs))==1,bytes=files[0].stat().st_size,pages=len(d),identity_text=[d[i].get_text() for i in range(min(2,len(d)))],scope='Full fresh byte identity and first two page title/course text, not a new entire original source technical review.'))
for f in ['official-openstax-5-4.html','official-openstax-5-5.html','official-MIT-resource.html']:
 t=Text();t.feed((p/f).read_text())
 with (p/(f+'.txt')).open('x') as out:out.write(norm(' '.join(t.text)))
summary=dict(source_math=len(allrows),actual_math=sum(len(read(n+'/destination-math.json')) for n in names),exact=sum(x['exact'] for x in allrows),altered=sum(x['kind']=='spacing_command_backslash_loss' for x in fails),missing=sum(x['kind']=='math_node_missing_underscore_emphasis_collision' for x in fails),thinspace_backslashes_lost=len(chars),all_nonmath_prose_explained=all(x['nonmath_prose_preserved'] for x in prose),labels_exact=all(x['all_exact'] and x['parts_exact'] for x in labels),targets=sum(len(d['source_ids']) for d in docs),refs=len(refs),routes_complete=all(x['all_required_routes'] for x in chains),source_exact=len(set(hs))==1)
save('full-audit-summary.json',summary);print(json.dumps(summary,indent=2))
