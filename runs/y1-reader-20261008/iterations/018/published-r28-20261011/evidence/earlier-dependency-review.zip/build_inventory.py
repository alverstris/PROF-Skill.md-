from pathlib import Path
import subprocess, hashlib, json, re

REPO = '/workspace/scratch/f9c0b7fc7e76/prof-iteration'
COMMIT = 'f8f76d0775051896326fb400ec5782bf1d954971'
BASE = 'runs/y1-reader-20261008/'
OUT = Path('/workspace/scratch/f9c0b7fc7e76/d018-clean-r28/evidence/earlier-rendering')
QUEUE = Path('/workspace/scratch/f9c0b7fc7e76/d018-clean-r28/work/incoming-queue.json')

def read(path):
    return subprocess.check_output(['git', 'show', f'{COMMIT}:{path}'], cwd=REPO)

accepted = {
'D001': [('iterations/001/teaching-v4.md','402485baa2767af9625146721e356f92bad76e4cfb738e5729c6c8b94ea79401')],
'D002': [('iterations/002/teaching-v1.md','8139080278edb96287576629e7d80933b380c1b82af60d3ede888d500cb68a3a')],
'D003': [('iterations/003/teaching-v1.md','cd7426a9b70d0ac41aa3ca0418db8c89c391b67304016a7ad38f8379fe98b5a8')],
'D004': [('iterations/004/teaching-v1.md','5adb3e95c2fa47c94b4c665d85dc2fe669e2c0086dbc2ebc194cd59720d5d8ad')],
'D005': [('iterations/005/teaching-v2.md','4ae6d0f33e2957ebaf3bbd31c34e154c4a7c5eaab4bc3a09a9e909574b1a48e6')],
'D006': [('iterations/006/regenerated-r13-candidate1/teaching-v3.md','311afdef083a4468f18bcdd11a68975d2e6622661e0be3405a5c9f58b3f3a813')],
'D007': [('iterations/007/revised-v3/teaching-v3.md','6dc2823d9f931c1baaa6eb4ce5076ed2aef1859ba29255d5503eed627824ae54')],
'D008': [('iterations/008/revised-r15-v2/teaching-r15-v2.md','b6e93b986e2a77763c556a4b5fc5cb42f43269742d0af9bd06021d7aa3ad7668')],
'D009': [('iterations/009/resumption-20261009/author/teaching-r15-recovery-v3.md','5c9e307b08931099316a2d12149ab3d1cd3a75ba2ae75bc48ef60a77b562c244')],
'D010': [('iterations/010/current-r16/author/teaching-v2.md','192609d9d62cc50be534df77b5e5700c6eb7c4a9c32e37c832be6b1ab133742c')],
'D011': [('iterations/011/current-r17/author/teaching-v3.md','bcb390a295a8cce423b8ebfb9d292c45f7e6be3e37b9fbed1e33c6f60153f6fe')],
'D012': [('iterations/012/current-r18/author/teaching-v2.md','04355b5ac132bfdaecf6a165cf332d0e04a0ff29bd59b53e03d6c801c9838d59')],
'D013': [('iterations/013/current-r19/author/learner-v2.md','d17f77d36f7c30db9777230a85decb363a1fb967bb5c51d60cb5af4cd7b078c0')],
'D014': [('iterations/014/current-r20/author/teaching-v2.md','caf74a9a150f61d2531e8b2768abb1448fb7d5304818a9e1fcc73d02bead826b')],
'D015': [], 'D016': [], 'D017': []}

specs = [
('D015','iterations/015/current-r21/author/v2-evidence/freeze-manifest-v2.json','constituents','iterations/015/current-r21/author/v2/'),
('D016','iterations/016/published-r26-20261010/fresh-r26b/freeze-manifest.json','files','iterations/016/published-r26-20261010/fresh-r26b/'),
('D017','iterations/017/published-r27-20261011/evidence/freeze-manifest.json','files','iterations/017/published-r27-20261011/')]
for case, manifest, key, root in specs:
    for f in json.loads(read(BASE+manifest))[key]:
        if f['path'].endswith('.md'): accepted[case].append((root+f['path'],f['sha256']))

patterns = [
('fenced_math',r'^```math[^\n]*\n(.*?)^```\s*$',re.M|re.S),
('dollar_display',r'\$\$(.*?)\$\$',re.S),
('bracket_display',r'\\\[(.*?)\\\]',re.S),
('protected_inline',r'\$`(.*?)`\$',re.S),
('parenthesis_inline',r'\\\((.*?)\\\)',re.S),
('dollar_inline',r'(?<![\\$])\$(?!\$)([^\n]*?)(?<![\\$])\$(?!\$)',0)]

def parse_math(s):
    found=[]
    for kind, pattern, flags in patterns:
        for m in re.finditer(pattern,s,flags):
            if any(m.start()<x['end_offset'] and m.end()>x['start_offset'] for x in found): continue
            prefix=s[:m.start()]
            detail_depth=len(re.findall(r'<details(?:\s[^>]*)?>',prefix,re.I))-len(re.findall(r'</details>',prefix,re.I))
            payload=m.group(1)
            found.append(dict(kind=kind,start_line=prefix.count('\n')+1,end_line=s[:m.end()].count('\n')+1,
                 start_offset=m.start(),end_offset=m.end(),payload=payload,
                 details_depth=detail_depth,literal_lt=payload.count('<'),literal_gt=payload.count('>'),
                 operatorname=len(re.findall(r'\\operatorname\b',payload)),
                 fenced_math_in_details=kind=='fenced_math' and detail_depth>0))
    return sorted(found,key=lambda x:x['start_offset'])

records=[]
for case,files in accepted.items():
    rec=dict(material_id=case,files=[],feature_counts={})
    for path,expected in files:
        data=read(BASE+path); sha=hashlib.sha256(data).hexdigest()
        assert sha==expected,(case,path,sha,expected)
        s=data.decode(); exprs=parse_math(s)
        rec['files'].append(dict(path=BASE+path,bytes=len(data),sha256=sha,closure_sha256=expected,sha256_matches=True,
             total_math_expressions=len(exprs),expressions=exprs))
    all_expr=[x for f in rec['files'] for x in f['expressions']]
    rec['feature_counts']={k:sum(int(x[k]) for x in all_expr) for k in ['literal_lt','literal_gt','operatorname','fenced_math_in_details']}
    rec['feature_counts']['expressions_with_literal_comparison']=sum(x['literal_lt']+x['literal_gt']>0 for x in all_expr)
    rec['feature_counts']['expressions_with_operatorname']=sum(x['operatorname']>0 for x in all_expr)
    rec['feature_counts']['expressions_total']=len(all_expr)
    records.append(rec)

inventory=dict(audit_kind='source syntax inventory, not a browser-rendering verdict',canonical_commit=COMMIT,
 queue_sha256=hashlib.sha256(QUEUE.read_bytes()).hexdigest(),cases=records,
 coverage=dict(cases=len(records),markdown_constituents=sum(len(x['files']) for x in records)),
 limitations=['Math extraction is a purpose-built delimiter parser, not the GitHub parser.',
 'Syntax presence alone does not prove visual damage; actual destination evidence must be checked.',
 'Images are bound by closure manifests but are outside these three text-math feature families.'])
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'math-feature-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
lines=['# Accepted D001–D017 syntax inventory','',f'Canonical commit: `{COMMIT}`. Exact bytes read by git show; no checkout or worktree reliance.','',
'| Case | Math | Literal < | Literal > | operatorname | Fenced math in details |','| --- | ---: | ---: | ---: | ---: | ---: |']
for r in records:
 c=r['feature_counts'];lines.append(f"| {r['material_id']} | {c['expressions_total']} | {c['literal_lt']} | {c['literal_gt']} | {c['operatorname']} | {c['fenced_math_in_details']} |")
lines.extend(['','Syntax presence is a risk inventory, not proof of rendered damage. All constituent paths, SHA256 bindings, exact expressions, line ranges and delimiter/container types are in the JSON.'])
(OUT/'inventory-summary.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
