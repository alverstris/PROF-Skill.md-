from pathlib import Path
import json, subprocess, io, zipfile, hashlib
from html.parser import HTMLParser

ROOT=Path('/workspace/scratch/f9c0b7fc7e76/d018-clean-r28/evidence/earlier-rendering')
REPO='/workspace/scratch/f9c0b7fc7e76/prof-iteration'
C='f8f76d0775051896326fb400ec5782bf1d954971'
B='runs/y1-reader-20261008/'
inv=json.loads((ROOT/'math-feature-inventory.json').read_text())

class MathParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.math=[]; self.active=None; self.depth=0; self.details=0
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=='details': self.details+=1
        if self.active is not None: self.depth+=1
        elif tag=='math-renderer':
            self.active=dict(tag=tag,attrs=attrs,text='',details_depth=self.details);self.depth=1
    def handle_endtag(self,tag):
        if self.active is not None:
            self.depth-=1
            if self.depth==0:
                x=self.active;t=x.pop('text')
                if t.startswith('$$') and t.endswith('$$'):x['payload']=t[2:-2]
                elif t.startswith('$') and t.endswith('$'):x['payload']=t[1:-1]
                else:x['payload']=t
                self.math.append(x);self.active=None
        if tag=='details':self.details-=1
    def handle_data(self,data):
        if self.active is not None:self.active['text']+=data

specs=[
('D012','iterations/012/current-r18/destination-v2-final.zip','destination-v2/github-article.html','destination-v2/destination-identity.json'),
('D013','iterations/013/current-r19/destination-v2-complete-evidence.zip','destination-v2/github-article.html','destination-v2/destination-identity.json'),
('D015','iterations/015/current-r21/destination-v2-complete.zip','solutions/github-article.html','solutions/destination-identity.json')]
out=[]
for case,arc,article,identity in specs:
    data=subprocess.check_output(['git','show',C+':'+B+arc],cwd=REPO)
    z=zipfile.ZipFile(io.BytesIO(data));html=z.read(article);p=MathParser();p.feed(html.decode())
    ci=next(x for x in inv['cases'] if x['material_id']==case)
    targets=[dict(file=f['path'],**e) for f in ci['files'] for e in f['expressions'] if e['literal_lt']+e['literal_gt']]
    matched=[]
    for t in targets:
        m=[(i,x) for i,x in enumerate(p.math,1) if x['payload'].strip()==t['payload'].strip()]
        matched.append(dict(source_file=t['file'],source_line=t['start_line'],source_kind=t['kind'],
            source_payload=t['payload'],matches=[dict(index=i,**x) for i,x in m],
            exact_payload_after_only_outer_whitespace_normalization=bool(m)))
    out.append(dict(material_id=case,archive_path=B+arc,archive_sha256=hashlib.sha256(data).hexdigest(),
        archive_article=article,article_sha256=hashlib.sha256(html).hexdigest(),
        identity=json.loads(z.read(identity)),math_renderer_count=len(p.math),target_comparison=matched,
        result='All targeted saved server-rendered payloads preserved; live client MathJax/MathML execution unobserved in this evidence.' if all(m['matches'] for m in matched) else 'Missing targeted payload(s); investigate.',
        live_destination_claim=False))
(ROOT/'saved-destination-target-checks.json').write_text(json.dumps(out,indent=2)+'\n')
for x in out:print(x['material_id'],x['math_renderer_count'],len(x['target_comparison']),x['result'])
