import hashlib, html, json, pathlib, re, xml.etree.ElementTree as ET

BASE = pathlib.Path('/workspace/scratch/f9c0b7fc7e76')
OUT = BASE / 'd018-clean-r28/evidence/earlier-rendering'
targets = json.loads((OUT / 'live-targets.json').read_text())
inventory = json.loads((OUT / 'math-feature-inventory.json').read_text())
failures = {
    ('D007',122): ('<x<1.', '−1', 'The entire open-interval condition −1<x<1 is truncated to −1.'),
    ('D007',331): ('<x<1.', '−1', 'The inverse-cosine derivative loses its entire open-interval condition after −1.'),
    ('D008',195): ('<c.', '0≤v', 'The strict upper speed bound v<c is absent.'),
    ('D013',51): ('<c<x.', 'a', 'The interior mean-value point condition a<c<x is absent after a.'),
    ('D013',76): ('<c<b.', 'a', 'The interior mean-value point condition a<c<b is absent after a.'),
    ('D013',147): ('<f(b)-f(a)<U(b-a).', 'L(b−a)', 'Both strict comparisons, the function difference and the upper bound are absent.'),
    ('D013',206): ('<c<1+h.', '1', 'The mean-value point condition 1<c<1+h is absent after 1.'),
    ('D013',209): ('<h.', 'h/(1+h)<ln(1+h)', 'The upper logarithm bound is absent; only the lower comparison remains.'),
    ('D015',75): ('<x<\\sqrt6.', '−√6', 'The positive-square-root branch loses the open interval −√6<x<√6 after −√6.'),
}

def parse(xml):
    # Browser MathML may serialize named HTML entities such as nbsp.
    def entity(m):
        s = html.unescape(m[0])
        return ''.join('&#'+str(ord(c))+';' for c in s) if s != m[0] else m[0]
    return ET.fromstring(re.sub(r'&([A-Za-z]+);', entity, xml))

def structure(xml):
    def rec(e):
        tag=e.tag.split('}')[-1]
        return {'tag':tag, 'text':(e.text or '').strip(), 'children':[rec(c) for c in e]}
    return rec(parse(xml))

def tokens(xml):
    return [{'tag':e.tag.split('}')[-1], 'text':(e.text or '').strip()}
            for e in parse(xml).iter() if not list(e) and (e.text or '').strip()]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

result={'scope':'Independent targeted source-to-live-MathML structural comparison; no independent browser or pixel inspection',
        'canonical_commit':inventory['canonical_commit'], 'source_inventory_sha256':sha(OUT/'math-feature-inventory.json'),
        'indexing':'All expression_index and ordinal values are one-based.', 'cases':[]}
report=['# Additive actual-destination comparison of the 25 flagged expressions', '',
        'This preserves the earlier static inventory and supplements it with the root browser owner’s actual client-hydrated captures. Nine target expressions fail structural preservation, across D007, D008, D013 and D015. Sixteen targets preserve the complete expression. D012 has no demonstrated damage in these two targets. These are current accepted artifacts, not historical failed candidates.', '',
        'The accepted canonical paths and SHA-256 values are those in `math-feature-inventory.json` and `live-targets.json`, pinned to repository object `f8f76d0775051896326fb400ec5782bf1d954971`. Each live capture URL exactly matches its immutable published target URL. Root captured the DOM; this reviewer independently parsed the complete supplied article and ordered MathML array. This is a structural/content verdict, not an independent pixel-legibility verdict.', '',
        '## Alignment and method', '',
        'Source and actual counts agree for all five pages (371, 305, 309, 214, 116). Every inline/display classification agrees at every ordinal. The actual article renderer count agrees with each ordered array, and all ordinals run consecutively from 1. At every target I compared both immediate neighboring expressions against the source and inspected the full target MathML tree, including fractions, roots, powers, subscripts, derivative marks, grouping, comparisons, operands and domain clauses. Thus target identity does not rely on counts or an assumed ordinal alone. The machine record preserves each complete target tree and neighboring source/MathML witnesses.', '',
        'All five captures report zero renderer error elements. This does not detect the nine content losses: those expressions rendered successfully after being truncated.', '',
        '| Case | Actual/source math count | Failed target ordinals | Preserved target ordinals |', '|---|---:|---|---|']

for t in targets:
    ident=t['material_id']; p=BASE/f'root-review-d018-r28/earlier-destination/{ident}.json'
    d=json.loads(p.read_text())
    f=next(f for c in inventory['cases'] for f in c['files'] if f['path']==t['path'])
    expected=['js-display-math' if e['kind'] in ['fenced_math','dollar_display','bracket_display'] else 'js-inline-math' for e in f['expressions']]
    assert len(expected)==len(d['math'])
    assert expected==[m['display'] for m in d['math']]
    assert [m['ordinal'] for m in d['math']]==list(range(1,len(expected)+1))
    assert d['articleHTML'].count('<math-renderer ')==len(expected)
    assert d['url']==t['url']
    case={'material_id':ident, 'source_path':t['path'], 'source_sha256':t['sha256'],
          'capture_path':str(p), 'capture_sha256':sha(p), 'url':d['url'], 'observed_at':d['observedAt'],
          'source_math_count':len(expected), 'actual_math_count':len(d['math']),
          'entire_display_inline_sequence_matches':True, 'errors':d['errors'], 'targets':[]}
    failed=[]; passed=[]
    for z in t['targets']:
        n=z['expression_index']; m=d['math'][n-1]; failure=failures.get((ident,n))
        q={**z, 'actual_mathml':m['mathML'], 'actual_structure':structure(m['mathML']),
           'actual_leaf_tokens':tokens(m['mathML']), 'disposition':'FAIL — truncated' if failure else 'PASS — full structure preserved',
           'neighbor_alignment_independently_inspected':True,
           'neighbors':[{'ordinal':k+1,'source':f['expressions'][k]['payload'],'actual_mathml':d['math'][k]['mathML']}
                        for k in [n-2,n] if 0<=k<len(expected)]}
        if failure:
            q.update(missing_source_suffix=failure[0],remaining_clause=failure[1],demonstrated_effect=failure[2]); failed.append(n)
        else: passed.append(n)
        case['targets'].append(q)
    result['cases'].append(case)
    report.append(f'| {ident} | {len(expected)} / {len(expected)} | '+(', '.join(map(str,failed)) or 'none')+' | '+(', '.join(map(str,passed)) or 'none')+' |')

report += ['', '## Exact failed clauses', '', '| Case / source line / actual ordinal | Original clause or expression | Actual remaining clause | Lost text |', '|---|---|---|---|']
for c in result['cases']:
    for z in c['targets']:
        if z['disposition'].startswith('FAIL'):
            report.append(f"| {c['material_id']} / {z['start_line']} / {z['expression_index']} | `{z['payload'].strip().replace(chr(10),' ')}` | `{z['remaining_clause']}` | `{z['missing_source_suffix']}` |")

report += ['', '## Preserved structures', '',
    'D007 ordinals 184 and 209 preserve all derivative equalities, fractions, powers and the complete x>0 condition. D008 ordinals 73 and 153 preserve both function/approximation expressions and x>−1. D012 ordinals 45 and 269 preserve the full decimal-square bracket and signed polynomial evaluation, including every comparison.', '',
    'D013 ordinals 93, 104, 107, 110, 121, 122, 154, 193 and 201 preserve all operands and comparisons, including both strict bounds in ordinal 154, both negative-input comparisons in ordinal 201, and the powers/factorial/fractions in ordinals 121–122. D015 solutions ordinal 33 preserves the full tangent formula and both sides of −π/2<x²/2<π/2. These are positive preservation findings for the specified expressions only.', '',
    'The failures occur when a literal less-than is followed by a letter within the source payload. The preserved comparison targets include greater-than signs, less-than before numerals, and less-than before a TeX backslash command. This pattern explains these observations but is not a universal parser guarantee; the recorded exact structures, not a heuristic rule, support the dispositions.', '',
    '## Dependency disposition and limits', '',
    'The current accepted D007, D008, D013 and D015 have demonstrated learner-facing content loss and must be reopened for the affected destination preservation dependency. Earlier static wrappers preserved these TeX payloads but did not establish live client rendering. D012’s two flagged targets are structurally preserved in the current capture. The other twelve accepted cases lacked all three specific source features in the complete earlier inventory; no blanket re-review or regeneration claim follows.', '',
    'This reviewer did not operate a browser and does not independently certify pixel placement or visual readability. Root separately owns visual inspection. No GitHub object, frozen teaching document, queue status or acceptance record was changed by this audit.']
result['summary']={'targets':25,'failed':9,'preserved':16,'affected_cases':['D007','D008','D013','D015'],'structurally_preserved_flagged_case':['D012']}
(OUT/'live-target-comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(OUT/'live-target-comparison.md').write_text('\n'.join(report)+'\n')
print(json.dumps(result['summary']))
for name in ['live-target-comparison.json','live-target-comparison.md']: print(name,sha(OUT/name))
