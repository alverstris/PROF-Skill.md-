# D001–D009 accepted-artifact rendering evidence

Read-only audit against canonical commit `f8f76d0775051896326fb400ec5782bf1d954971`. All nine accepted teaching blobs match the queue SHA-256, closure identity and the same path at its frozen document commit. Historical failed versions are excluded. Paths below are relative to `runs/y1-reader-20261008/`.

| Case | Accepted teaching | SHA-256 | Inline / display | Target features present |
|---|---|---|---:|---|
| D001 | `iterations/001/teaching-v4.md` | `402485baa2767af9625146721e356f92bad76e4cfb738e5729c6c8b94ea79401` | 249 / 39 | None |
| D002 | `iterations/002/teaching-v1.md` | `8139080278edb96287576629e7d80933b380c1b82af60d3ede888d500cb68a3a` | 330 / 24 | None |
| D003 | `iterations/003/teaching-v1.md` | `cd7426a9b70d0ac41aa3ca0418db8c89c391b67304016a7ad38f8379fe98b5a8` | 251 / 25 | None |
| D004 | `iterations/004/teaching-v1.md` | `5adb3e95c2fa47c94b4c665d85dc2fe669e2c0086dbc2ebc194cd59720d5d8ad` | 275 / 30 | None |
| D005 | `iterations/005/teaching-v2.md` | `4ae6d0f33e2957ebaf3bbd31c34e154c4a7c5eaab4bc3a09a9e909574b1a48e6` | 280 / 23 | None |
| D006 | `iterations/006/regenerated-r13-candidate1/teaching-v3.md` | `311afdef083a4468f18bcdd11a68975d2e6622661e0be3405a5c9f58b3f3a813` | 291 / 46 | None |
| D007 | `iterations/007/revised-v3/teaching-v3.md` | `6dc2823d9f931c1baaa6eb4ce5076ed2aef1859ba29255d5503eed627824ae54` | 338 / 33 | Four literal-comparison fenced displays, outside details |
| D008 | `iterations/008/revised-r15-v2/teaching-r15-v2.md` | `b6e93b986e2a77763c556a4b5fc5cb42f43269742d0af9bd06021d7aa3ad7668` | 276 / 29 | Three literal-comparison dollar displays, outside details |
| D009 | `iterations/009/resumption-20261009/author/teaching-r15-recovery-v3.md` | `5c9e307b08931099316a2d12149ab3d1cd3a75ba2ae75bc48ef60a77b562c244` | 273 / 12 | None |

No accepted D001–D009 inline expression contains literal `<` or `>`. None of these accepted sources contains `\operatorname` or a `<details>` block, so the fenced-display-inside-details failure class is absent. The single teaching Markdown path per case is the complete accepted Markdown constituent set; D002/D003/D009 also have image constituents, which are not math-source candidates.

Every retained per-expression source and destination payload was independently compared with the current canonical source: D001 288, D002 354, D003 276, D004 305, D005 303, D006 337, D007 371, D008 305, D009 285. They all match exactly, preserving inline/display type within their recorded streams. This is verification of retained actual-destination evidence, not a fresh network observation.

The only targeted source expressions are:

| Case / source location | Payload | Retained actual GitHub evidence |
|---|---|---|
| D007 P046, line 179 | `(\arcsin x)'=\frac1{\sqrt{1-x^2}},\qquad -1<x<1.` | Ordered renderer 122; exact `js-display-math` payload; outside details |
| D007 P074, line 293 | `(\ln x)'=\frac1{e^y}=\frac1x,\qquad x>0.` | Ordered renderer 184; exact `js-display-math` payload; outside details |
| D007 P081, line 322 | `\frac d{dx}x^r =\frac d{dx}e^{r\ln x} =e^{r\ln x}\frac r x =x^r\frac r x =rx^{r-1},\qquad x>0.` | Ordered renderer 209; exact `js-display-math` payload; outside details |
| D007 P143, line 548 | `y'=-\frac1{\sqrt{1-x^2}},\qquad -1<x<1.` | Ordered renderer 331; exact `js-display-math` payload; outside details |
| D008 P017, line 71 | `f(x)=\frac{e^{-2x}}{\sqrt{1+x}}=e^{-2x}(1+x)^{-1/2},\qquad x>-1.` | Ordered renderer 73; exact `js-display-math` payload; outside details |
| D008 P032, line 147 | `\ln(1+x)\approx x-\frac{x^2}{2},\qquad x>-1.` | Ordered renderer 153; exact `js-display-math` payload; outside details |
| D008 P040, line 196 | `T'=\frac{T}{\sqrt{1-v^2/c^2}},\qquad 0\le v<c.` | Ordered renderer 195; exact `js-display-math` payload; outside details |

For D007, this audit independently recovered richText from the saved actual `iterations/007/render-evidence/v3/github-page.html` (SHA-256 `dcc757d34cf8c7a3ee992328499dd89efe76a729fca65031b800b4a432f35181`) and parsed all 371 math elements. For D008, it independently parsed all 305 elements in `iterations/008/render-evidence/r15-v2/github-article.html` (SHA-256 `6f174f85c7c2c88c1a3270b4b7cd52a5cb02fc52c15e8487034bbab28ee4e71b`). All ordered types and payloads equal current accepted source. In particular, the seven literal-comparison displays survived the captured GitHub HTML parse; there is no evidence here that their source syntax damaged that captured destination.

Closure-bound retained comparison records:

- D001: `iterations/001/render-markup-v4.json`; exact record digest and frozen commit in companion JSON.
- D002: `iterations/002/render-markup-v1.json`; exact record digest and frozen commit in companion JSON.
- D003: `iterations/003/render-markup-v1.json`; exact record digest and frozen commit in companion JSON.
- D004: `iterations/004/render-markup-v1.json`; exact record digest and frozen commit in companion JSON.
- D005: `iterations/005/render-evidence/v2/markup-audit.json`; exact record digest and frozen commit in companion JSON.
- D006: `iterations/006/render-evidence/candidate1-v3-recovery/scoped-markup-navigation-audit.json`; exact record digest and frozen commit in companion JSON.
- D007: `iterations/007/render-evidence/v3/scoped-markup-navigation-audit.json`; exact record digest and frozen commit in companion JSON.
- D008: `iterations/008/render-evidence/r15-v2/math-comparison.json`; exact record digest and frozen commit in companion JSON.
- D009: `iterations/009/resumption-20261009/destination-v3/math-comparison.json`; exact record digest and frozen commit in companion JSON.

D008 closure also binds `iterations/008/earlier-parser-regression-r15.json`: it reviews D001–D007 final parser evidence and supplementary D001 preview evidence, expressly as retained historical observations rather than fresh polling or regeneration. It is supporting provenance; this audit’s source/destination equality checks above were rerun directly against preserved objects.

All nine closures explicitly leave live GitHub pixels, client MathJax execution and browser interaction unobserved. The saved evidence supports historical static preservation and the originally recorded secondary-preview scopes. It does not verify current live rendering. No browser or fresh destination fetch was used here, no source/skill/repository state was changed, and no fresh-generation benefit is claimed.
