# Accepted D001–D017 syntax inventory

Canonical commit: `f8f76d0775051896326fb400ec5782bf1d954971`. Exact bytes read by git show; no checkout or worktree reliance.

| Case | Math | Literal < | Literal > | operatorname | Fenced math in details |
| --- | ---: | ---: | ---: | ---: | ---: |
| D001 | 288 | 0 | 0 | 0 | 0 |
| D002 | 354 | 0 | 0 | 0 | 0 |
| D003 | 276 | 0 | 0 | 0 | 0 |
| D004 | 305 | 0 | 0 | 0 | 0 |
| D005 | 303 | 0 | 0 | 0 | 0 |
| D006 | 337 | 0 | 0 | 0 | 0 |
| D007 | 371 | 4 | 2 | 0 | 0 |
| D008 | 305 | 1 | 2 | 0 | 0 |
| D009 | 285 | 0 | 0 | 0 | 0 |
| D010 | 156 | 0 | 0 | 0 | 0 |
| D011 | 201 | 0 | 0 | 0 | 0 |
| D012 | 309 | 1 | 2 | 0 | 0 |
| D013 | 214 | 15 | 12 | 0 | 0 |
| D014 | 346 | 0 | 0 | 0 | 0 |
| D015 | 398 | 4 | 0 | 0 | 0 |
| D016 | 272 | 0 | 0 | 0 | 0 |
| D017 | 248 | 0 | 0 | 0 | 0 |

Syntax presence is a risk inventory, not proof of rendered damage. All constituent paths, SHA256 bindings, exact expressions, line ranges and delimiter/container types are in the JSON.
