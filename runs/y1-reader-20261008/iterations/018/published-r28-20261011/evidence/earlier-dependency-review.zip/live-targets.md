# Exact live-destination targets

D007
https://github.com/alverstris/PROF-Skill.md-/blob/2c0a49dff10d407296675a9d52a2d664be1bb0f0/runs/y1-reader-20261008/iterations/007/revised-v3/teaching-v3.md
SHA256: 6dc2823d9f931c1baaa6eb4ce5076ed2aef1859ba29255d5503eed627824ae54

- Source line 179; ordered expression 122: `(\arcsin x)'=\frac1{\sqrt{1-x^2}},\qquad -1<x<1.`
- Source line 293; ordered expression 184: `(\ln x)'=\frac1{e^y}=\frac1x,\qquad x>0.`
- Source line 322; ordered expression 209: `\frac d{dx}x^r =\frac d{dx}e^{r\ln x} =e^{r\ln x}\frac r x =x^r\frac r x =rx^{r-1},\qquad x>0.`
- Source line 548; ordered expression 331: `y'=-\frac1{\sqrt{1-x^2}},\qquad -1<x<1.`

D008
https://github.com/alverstris/PROF-Skill.md-/blob/a6b7aaaf2ded04bb6b0c2da2528234d36ca2f6d4/runs/y1-reader-20261008/iterations/008/revised-r15-v2/teaching-r15-v2.md
SHA256: b6e93b986e2a77763c556a4b5fc5cb42f43269742d0af9bd06021d7aa3ad7668

- Source line 71; ordered expression 73: `f(x)=\frac{e^{-2x}}{\sqrt{1+x}}=e^{-2x}(1+x)^{-1/2},\qquad x>-1.`
- Source line 147; ordered expression 153: `\ln(1+x)\approx x-\frac{x^2}{2},\qquad x>-1.`
- Source line 196; ordered expression 195: `T'=\frac{T}{\sqrt{1-v^2/c^2}},\qquad 0\le v<c.`

D012
https://github.com/alverstris/PROF-Skill.md-/blob/12f468d985cbc1cb462e41948f0f017a161a2099/runs/y1-reader-20261008/iterations/012/current-r18/author/teaching-v2.md
SHA256: 04355b5ac132bfdaecf6a165cf332d0e04a0ff29bd59b53e03d6c801c9838d59

- Source line 83; ordered expression 45: `1.73205080^2=2.99999997378064<3, \qquad 1.73205081^2=3.0000000084216561>3.`
- Source line 388; ordered expression 269: `f(-3/2)=-\frac{27}{8}+3+2=\frac{13}{8}>0.`

D013
https://github.com/alverstris/PROF-Skill.md-/blob/ea627ac47e24cd309a3e7b75a4ecfd070e54a3b5/runs/y1-reader-20261008/iterations/013/current-r19/author/learner-v2.md
SHA256: d17f77d36f7c30db9777230a85decb363a1fb967bb5c51d60cb5af4cd7b078c0

- Source line 91; ordered expression 51: `f(x)=f(a)+f'(c)(x-a),\qquad a<c<x.`
- Source line 123; ordered expression 76: `f(b)-f(a)=f'(c)(b-a),\qquad a<c<b.`
- Source line 131; ordered expression 93: `b^3-a^3=(b-a)(b^2+ab+a^2)>0.`
- Source line 155; ordered expression 104: `R_0(x)>R_0(0)=0,\qquad\text{so }e^x>1.`
- Source line 159; ordered expression 107: `R_1'(x)=e^x-1=R_0(x)>0\quad\text{for }x>0.`
- Source line 163; ordered expression 110: `e^x>1+x\quad(x>0).`
- Source line 173; ordered expression 121: `e^x>1+x+\frac{x^2}{2}>1+x,\qquad x>0,`
- Source line 175; ordered expression 122: `e^x>1+x+\frac{x^2}{2}+\frac{x^3}{3!},\qquad x>0.`
- Source line 205; ordered expression 147: `L(b-a)<f(b)-f(a)<U(b-a).`
- Source line 211; ordered expression 154: `\frac34<\sqrt4-\sqrt1<\frac32.`
- Source line 297; ordered expression 193: `R_1(0)-R_1(x)=R_1'(c)(0-x)<0.`
- Source line 303; ordered expression 201: `e^x<1+x+\frac{x^2}{2}\quad(x<0).`
- Source line 314; ordered expression 206: `\ln(1+h)-\ln1=\frac{1}{c}h,\qquad 1<c<1+h.`
- Source line 318; ordered expression 209: `\frac{h}{1+h}<\ln(1+h)<h.`

D015
https://github.com/alverstris/PROF-Skill.md-/blob/f531ccd1a3ec4b4918b96fbab30a7f6d8c03aafa/runs/y1-reader-20261008/iterations/015/current-r21/author/v2/solutions.md
SHA256: 9f6a2b4117df5902a1d964de411830e6af4e61862d6ef80d5cc38991be766855

- Source line 29; ordered expression 33: `y=\tan\left(\frac{x^2}{2}\right), \qquad -\frac{\pi}{2}<\frac{x^2}{2}<\frac{\pi}{2}.`
- Source line 78; ordered expression 75: `y=\sqrt{3-\frac{x^2}{2}},\qquad -\sqrt6<x<\sqrt6.`

