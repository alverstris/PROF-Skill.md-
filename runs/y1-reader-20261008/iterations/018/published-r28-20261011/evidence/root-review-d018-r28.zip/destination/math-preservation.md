# D018 destination preservation

**FAIL for the supplied live-GitHub capture.** Of 288 source expressions, 271 preserve their mathematical structure, one is truncated, ten produce explicit renderer errors, and six remain raw math code in this capture. This is preservation QA only, not a scientific or SASIS verdict.

Source SHA-256: `4970a5ae04a73cca02eb62a20de8b5eab8d225c6b9ceb22eee44ec6a6408873c`  
Capture SHA-256: `145f8c0f41a1abfb06057eb4c1eaec03bd4ea62413a80130209934b355b2fc90`  
Capture timestamp: `2026-10-11T21:51:48.627Z`  
Actual destination: https://github.com/alverstris/PROF-Skill.md-/blob/f8f76d0775051896326fb400ec5782bf1d954971/runs/y1-reader-20261008/iterations/018/published-r28-20261011/teaching.md#s1

| Check | Source | Captured destination | Finding |
|---|---:|---:|---|
| Mathematical slots | 288 | 288 | Every source slot mapped in order |
| Native MathML expressions | 288 expected | 272 | 16 have no MathML |
| Inline expressions | 259 | 253 native | Six explicit errors |
| Display expressions | 29 | 19 native | Four explicit errors; six raw-code slots |
| Mathematical structures | 288 | 271 exact matches | One truncated; 16 absent |
| Types of existing MathML | 272 | 272 matches | No additional type mismatch |
| Full nonmath prose with math-slot markers | 22,612 normalized characters | 22,612 | Exact match |
| Textual links | 26 | 26 | Every label and href matches |
| Image alt texts | 2 | 2 | Both exact matches |

The 272 MathML strings in `articleHTML` exactly equal the capture's math array. The array alone is not a complete source-expression inventory. Both disclosures have `open` in the supplied DOM.

The concrete defects are:

1. **Expression 22, source line 28:** the orientation display ends `\quad(x<a).` in source. Actual MathML ends with only `<mo>(</mo><mi>x</mi>`. The comparison loses `<`, `a`, `)` and the terminal period. This is actual token loss in an otherwise rendered expression.
2. **Ten explicit `operatorname` errors:** expressions 123 (line 129), 126 (line 135), 132 (line 139), 133 (line 147), 134 (line 147), 157 (line 175), 160 (line 179), 161 (line 179), 163 (line 181), 165 (line 183). Each slot contains “The following macros are not allowed: operatorname” and raw TeX, with no MathML. The capture's summary field `errors=0` is contradicted by these ten error blocks in its own HTML.
3. **Six solution displays remain raw code in this capture:** expressions 252 (line 297), 258 (line 308), 264 (line 321), 271 (line 331), 281 (line 342), 286 (line 348). These are the Q1 evaluation, Q2 cases, Q3 derivative, Q4 bounds, Q5 derivative, and Q5 added-term integral. Each is `<pre lang="math"><code>…</code></pre>`, without MathML. Their raw TeX equals the source exactly, which does not establish rendered-math preservation. This finding is capture-specific; root is checking the settled visible state and must determine whether a later capture changes it.

The independent v2 comparator preserves operators, operand order, visible delimiters, fractions, script attachment, powers/subscripts, integral bounds, roots and double primes. It adds only demonstrated D018 equivalences to v1: elementary symbol commands, square roots, decimal tokens, double-prime glyph equivalence, spacing, and disclosure markup. Unknown constructs still fail explicitly. `operatorname` and `cases` were not normalized into successful results: they have no corresponding MathML in this capture and retain failed records with full HTML and raw-text evidence.

Prose normalization removes document markup and collapses whitespace, preserving case, wording, punctuation, order and mathematical-slot positions. Disclosure summaries are included. Each of all 288 mathematical slots receives a positional marker solely for this separate nonmath comparison; renderer errors remain explicit math failures. Normalized prose SHA-256: `b35c4d7e10c5f90fe68369d2d5b012aff8160b8fe4c4faec55f89f1053345d5c`. Two additional image-wrapper anchors are recorded separately from the 26 textual links.

`math-preservation.json` contains all 288 source records, complete actual MathML or complete failed-slot HTML, source lines, type and structural checks, canonical trees for the 272 rendered expressions, all prose, links and alt-text comparisons. Example successful v2 witnesses: source 127 (root and nested powers), 130 (infinite integral bounds), 142 (double prime), 176 (nested bounds/fractions/decimal scientific notation), and 186 (decimal coefficient).

The frozen teaching source, D017 reports, original comparator and v1 comparator were not modified. No browser operation or GitHub mutation was performed. Root owns visual geometry and actual navigation.
