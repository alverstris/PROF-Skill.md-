#!/usr/bin/env python3
"""Byte-only verifier of two exact Git snapshots. Does not display payload content."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
REPO = ROOT / 'prof-iteration'
OUT = ROOT / 'root-review-d015-r37-publication/a7ec9c4d0a3ec582aa28ede116f935cf1d68bca1'
TARGET = 'a7ec9c4d0a3ec582aa28ede116f935cf1d68bca1'
EXPECTED_TREE = 'ea2add07c541ee1f437db051d511d307340d9c52'
PARENT = '97e10125d66e612e3f0446ab1f8460c6fd4064a5'
PREFIX = 'runs/y1-reader-20261008/iterations/015/published-r36-20261012/'
LOCAL = ROOT / 'd015-clean-r36-20261012'
MAP_PATH = LOCAL / 'work/publication1-readback.json'
PACKAGE_PATH = LOCAL / 'inputs/prof-package-manifest.json'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def identity(path, data):
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': sha256(data)}


def safe_path(path):
    p = PurePosixPath(path)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in path
    assert p.as_posix() == path
    return p


class ExactGit:
    def __init__(self):
        self.process = subprocess.Popen(
            ['git', '-C', str(REPO), 'cat-file', '--batch'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.cache = {}
        self.objects = []
        self.trees = {}

    def get(self, oid, expected_type=None):
        assert len(oid) == 40 and all(c in '0123456789abcdef' for c in oid)
        if oid not in self.cache:
            self.process.stdin.write((oid + '\n').encode())
            self.process.stdin.flush()
            header = self.process.stdout.readline().decode().strip().split()
            assert len(header) == 3 and header[0] == oid, header
            object_type, size = header[1], int(header[2])
            data = self.process.stdout.read(size)
            assert len(data) == size and self.process.stdout.read(1) == b'\n'
            actual_oid = hashlib.sha1(object_type.encode() + b' ' + str(size).encode() + b'\0' + data).hexdigest()
            assert actual_oid == oid
            self.cache[oid] = (object_type, data)
            self.objects.append({'git_oid': oid, 'type': object_type, 'bytes': size,
                                 'sha256': sha256(data), 'git_object_id_recomputed': actual_oid})
        object_type, data = self.cache[oid]
        assert expected_type is None or expected_type == object_type
        return data

    def commit(self, oid):
        data = self.get(oid, 'commit')
        # Interpret only tree and parent header fields. Do not interpret the message.
        headers = data.split(b'\n\n', 1)[0].splitlines()
        trees = [line[5:].decode() for line in headers if line.startswith(b'tree ')]
        parents = [line[7:].decode() for line in headers if line.startswith(b'parent ')]
        assert len(trees) == 1
        return trees[0], parents

    def tree(self, oid):
        if oid not in self.trees:
            data = self.get(oid, 'tree')
            entries = {}
            i = 0
            while i < len(data):
                j = data.index(b' ', i)
                k = data.index(b'\0', j)
                mode, name = data[i:j].decode(), data[j + 1:k].decode('utf-8')
                assert name not in entries and '/' not in name
                entries[name] = {'mode': mode, 'oid': data[k + 1:k + 21].hex()}
                i = k + 21
            assert i == len(data)
            self.trees[oid] = entries
        return self.trees[oid]

    def resolve(self, tree_oid, path):
        parts = safe_path(path).parts
        for i, part in enumerate(parts):
            entry = self.tree(tree_oid)[part]
            if i < len(parts) - 1:
                assert entry['mode'] == '40000'
                tree_oid = entry['oid']
        return entry

    def blob(self, tree_oid, path):
        entry = self.resolve(tree_oid, path)
        assert entry['mode'] in ('100644', '100755'), (path, entry['mode'])
        return entry, self.get(entry['oid'], 'blob')

    def close(self):
        self.process.stdin.close()
        self.process.wait()
        assert self.process.returncode == 0


def leaves(git, tree_oid, prefix=''):
    result = {}
    for name, entry in git.tree(tree_oid).items():
        path = prefix + name
        if entry['mode'] == '40000':
            result.update(leaves(git, entry['oid'], path + '/'))
        else:
            result[path] = entry
    return result


def tree_differences(git, old_oid, new_oid, prefix=''):
    if old_oid == new_oid:
        return []
    old = git.tree(old_oid) if old_oid else {}
    new = git.tree(new_oid) if new_oid else {}
    changes = []
    for name in sorted(set(old) | set(new)):
        before, after = old.get(name), new.get(name)
        if before == after:
            continue
        path = prefix + name
        if before and after and before['mode'] == after['mode'] == '40000':
            changes.extend(tree_differences(git, before['oid'], after['oid'], path + '/'))
        elif before is None and after['mode'] == '40000':
            changes.extend({'path': p, 'change': 'added', 'parent': None, 'published': e}
                           for p, e in leaves(git, after['oid'], path + '/').items())
        elif after is None and before['mode'] == '40000':
            changes.extend({'path': p, 'change': 'removed', 'parent': e, 'published': None}
                           for p, e in leaves(git, before['oid'], path + '/').items())
        else:
            changes.append({'path': path, 'change': 'added' if before is None else
                            'removed' if after is None else 'changed',
                            'parent': before, 'published': after})
    return sorted(changes, key=lambda r: r['path'])


def object_arrays(node, pointer=''):
    """Structural search only, never return interpreted object fields."""
    found = []
    if isinstance(node, list):
        if len(node) == 147 and all(isinstance(v, dict) for v in node):
            found.append((pointer, node))
        for i, value in enumerate(node):
            if isinstance(value, (dict, list)):
                found.extend(object_arrays(value, pointer + '/' + str(i)))
    elif isinstance(node, dict):
        for key, value in node.items():
            if isinstance(value, (dict, list)):
                found.extend(object_arrays(value, pointer + '/' + key.replace('~', '~0').replace('/', '~1')))
    return found


def canonical_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


import io
import zipfile
import zlib
import collections

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def internal_declarations(new):
    declarations, exclusions = [], []
    def check(df, pointer, path, digest, size=None):
        safe_path(path)
        data = new[path]
        assert sha256(data) == digest and (size is None or len(data) == size), path
        declarations.append(dict(declaration_file=df, field=pointer, path=path, bytes=len(data), sha256=sha256(data)))
    pp='references/sasis/profile-manifest.json'; pb='references/sasis/'
    p=json.loads(new[pp]); bd=str(safe_path(p['file_hashes_base_directory']))
    for path,h in p['file_hashes'].items(): check(pp,'/file_hashes/'+path,pb+bd+'/'+path,h)
    for path,h in p['control_file_hashes'].items(): check(pp,'/control_file_hashes/'+path,pb+path,h)
    for i,r in enumerate(p['subject_files']): check(pp,f'/subject_files/{i}/sha256',pb+r['path'],r['sha256'])
    rb=pb+'ocr-baseline-20261007/'; rp=rb+'release-manifest.json'; r=json.loads(new[rp])
    for i,f in enumerate(r['subjects']): check(rp,f'/subjects/{i}/sha256',rb+f['path'],f['sha256'],f['bytes'])
    check(rp,'/combined_baseline_sha256',rb+'student-baseline.txt',r['combined_baseline_sha256'])
    exclusions.append(dict(declaration_file=rp, field='/archive_sha256',reason='Historical external archive reference, outside the 36-file package.'))
    cp=rb+'chemistry/freeze-manifest.json'; c=json.loads(new[cp])
    for i,f in enumerate(c['files']):
        path=rb+'chemistry/'+f['path']
        if path in new: check(cp,f'/files/{i}/sha256',path,f['sha256'],f['bytes'])
        else: exclusions.append(dict(declaration_file=cp,field=f'/files/{i}',path=path,reason='Historical external file reference, not a current package-local declaration.'))
    assert len(declarations)==34 and len({r['path'] for r in declarations})==22
    return declarations,exclusions

def main():
    planpath=LOCAL/'work/release-plan.json'; planbytes=planpath.read_bytes();plan=json.loads(planbytes)
    assert sha256(planbytes)=='a212d5ea8982263aa1263a59c8cec066ad136c1a5145978232646dd9be79f093'
    assert plan['parent']==PARENT and plan['base_tree']=='ba6828823270f5611674e4bc8b5443a5f2e44583'
    assert len(plan['files'])==101 and sum(r['bytes'] for r in plan['files'])==16512540
    fmap={r['remote']:r for r in plan['files']};assert len(fmap)==101
    cp=ROOT/'root-review-d015-r36/candidate-r37'; ci_bytes=(cp/'byte-identities.json').read_bytes()
    assert sha256(ci_bytes)=='db127218f6d970a5804050c0e2b44bcf5eeca5e177605775a52dbfa8b30e925e'
    assert sha256((cp/'SEAL.json').read_bytes())=='7cb70cdd9cbc114834efeeaf7f676d60714aaf5f173c1b24df6a07da83b857dc'
    candidate=json.loads(ci_bytes)
    git=ExactGit();tree,parents=git.commit(TARGET);assert tree==EXPECTED_TREE and parents==[PARENT]
    parent_tree,_=git.commit(PARENT);assert parent_tree==plan['base_tree']
    actual={};identities=[];local_read={}
    for path,r in sorted(fmap.items()):
        safe_path(path);lp=Path(r['local']);assert lp.is_relative_to(LOCAL) and not lp.is_symlink()
        ld=lp.read_bytes();entry,data=git.blob(tree,path);actual[path]=data;local_read[str(lp)]=sha256(ld)
        assert data==ld and len(data)==r['bytes'] and sha256(data)==r['sha256'] and entry['oid']==r['git_blob'],path
        identities.append(dict(path=path,local=str(lp.relative_to(ROOT)),bytes=len(data),sha256=sha256(data),actual_git_blob=entry['oid'],mode=entry['mode'],exact_local_bytes_equal=True,plan_identity_match=True))
    new={r['path']:actual[r['path']] for r in candidate['actual_file_identities']}
    assert len(new)==36 and sum(map(len,new.values()))==907146
    for r in candidate['actual_file_identities']:
        assert sha256(new[r['path']])==r['candidate_sha256'] and len(new[r['path']])==r['candidate_bytes']
        assert fmap[r['path']]['git_blob']==r['candidate_computed_git_blob']
    declarations,exclusions=internal_declarations(new)
    internal_claim=json.loads(actual[PREFIX+'evidence/package-internal-hashes.json'])
    assert collections.Counter((r['path'],r['bytes'],r['sha256']) for r in declarations)==collections.Counter((r['path'],r['bytes'],r['sha256']) for r in internal_claim['checks'])
    frozenmapbytes=MAP_PATH.read_bytes();frozenmap=json.loads(frozenmapbytes);frozen=[]
    for r in frozenmap['files']:
        path=r['path'];entry,data=git.blob(parent_tree,path)
        assert actual[path]==data and len(data)==r['bytes'] and sha256(data)==r['sha256'] and entry['oid']==r['git_blob'],path
        frozen.append(dict(path=path,bytes=len(data),sha256=sha256(data),parent_git_blob=entry['oid'],published_git_blob=fmap[path]['git_blob'],exact_parent_bytes_equal=True))
    assert len(frozen)==17 and sum(r['bytes'] for r in frozen)==309132
    states=[];queue_objects=[]
    for path in ['runs/y1-reader-20261008/queue.json','runs/y1-reader-20261008/RUN.md','runs/y1-reader-20261008/CHANGELOG.md']:
        pe,pd=git.blob(parent_tree,path);te,td=git.blob(tree,path)
        assert pd==td and pe==te,path
        states.append(dict(path=path,bytes=len(td),sha256=sha256(td),parent_git_blob=pe['oid'],published_git_blob=te['oid'],exact_parent_bytes_equal=True))
        if path.endswith('queue.json'):
            pa=object_arrays(json.loads(pd));ta=object_arrays(json.loads(td));assert len(pa)==len(ta)==1 and pa[0][0]==ta[0][0]
            for i,(p,t) in enumerate(zip(pa[0][1],ta[0][1])):
                pb=canonical_bytes(p);tb=canonical_bytes(t);assert pb==tb
                queue_objects.append(dict(index=i,canonical_bytes=len(tb),parent_sha256=sha256(pb),published_sha256=sha256(tb),exact_object_equal=True))
    changes=tree_differences(git,parent_tree,tree);changed={r['path'] for r in changes}
    expected={p for p in fmap if p.startswith(PREFIX+'evidence/')}|{'SKILL.md','references/sasis.md','references/sasis/student-testing-contract.txt','references/sasis/profile-manifest.json'}
    assert changed==expected and len(changes)==52 and changed=={p for p,r in fmap.items() if r['upload'] is True}
    assert sum(r['change']=='added' for r in changes)==48 and sum(r['change']=='changed' for r in changes)==4
    archives=[]
    for path in sorted(p for p in actual if p.endswith('.zip')):
        data=actual[path];stem=path[:-4];matches=[p for p in actual if p in [stem+'-manifest.json',stem+'.manifest.json']];assert len(matches)==1
        mp=matches[0];md=actual[mp];manifest=json.loads(md)
        declared=manifest['files'] if 'files' in manifest else manifest['members']
        special=Path(path).name.startswith(('v10-','v11-')); prefix=Path(path).stem+'/' if special else ''
        declaredmap={prefix+r.get('archive_member',r.get('path')):r for r in declared};assert len(declaredmap)==len(declared)
        records=[]
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos=z.infolist(); names=[i.filename for i in infos];assert len(names)==len(set(names));assert z.testzip() is None
            for name in names: safe_path(name)
            extra={prefix+'MANIFEST.json'} if special else set()
            assert set(names)==set(declaredmap)|extra
            for info in infos:
                assert not info.is_dir();b=z.read(info);h=sha256(b);crc=zlib.crc32(b)&0xffffffff
                assert len(b)==info.file_size and crc==info.CRC
                if info.filename in extra:
                    assert b==md
                    relation='Embedded manifest is byte-identical to the independently published external manifest.'
                else:
                    row=declaredmap[info.filename];assert len(b)==row['bytes'] and h==row['sha256'],(path,info.filename)
                    if 'archive_member_bytes' in row: assert len(b)==row['archive_member_bytes']
                    if 'compressed_bytes' in row: assert info.compress_size==row['compressed_bytes']
                    relation='Actual member matches declared size and SHA-256.'
                records.append(dict(path=info.filename,bytes=len(b),sha256=h,crc32=f'{crc:08x}',compressed_bytes=info.compress_size,verification=relation))
        if 'archive_sha256' in manifest: assert sha256(data)==manifest['archive_sha256'] and len(data)==manifest['archive_bytes']
        elif 'sha256' in manifest: assert sha256(data)==manifest['sha256'] and len(data)==manifest['bytes']
        for key in ['member_count','members']:
            if isinstance(manifest.get(key),int): assert len(records)==manifest[key]
        if 'archive_properties' in manifest: assert len(records)==manifest['archive_properties']['member_count']
        if 'uncompressed_member_bytes' in manifest: assert sum(r['bytes'] for r in records)==manifest['uncompressed_member_bytes']
        if 'member_bytes' in manifest: assert sum(r['bytes'] for r in records)==manifest['member_bytes']
        archives.append(dict(path=path,bytes=len(data),sha256=sha256(data),manifest_path=mp,manifest_sha256=sha256(md),actual_members=len(records),declared_payload_members=len(declaredmap),crc_all_pass=True,member_identities=records))
    assert len(archives)==11
    for p,h in local_read.items():assert sha256(Path(p).read_bytes())==h,p
    assert planpath.read_bytes()==planbytes and MAP_PATH.read_bytes()==frozenmapbytes and (cp/'byte-identities.json').read_bytes()==ci_bytes
    git.close()
    counts=dict(planned_files=101,planned_bytes=16512540,actual_changed_paths=52,added_paths=48,modified_paths=4,declared_unchanged_paths=49,package_files=36,package_bytes=907146,package_internal_declarations=34,package_unique_internal_targets=22,frozen_publication_files=17,frozen_publication_bytes=309132,unchanged_queue_whole_objects=147,unchanged_state_files=3,archives=len(archives),actual_archive_members=sum(r['actual_members'] for r in archives),declared_archive_payload_members=sum(r['declared_payload_members'] for r in archives))
    report=dict(status='PASS',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_commit=TARGET,actual_tree=tree,actual_parent=PARENT,actual_parent_tree=parent_tree,counts=counts,checks=dict(all_plan_sizes_hashes_git_blob_ids_match_actual_git_and_local_bytes=True,all_local_inputs_reread_unchanged=True,exact_tree_change_set_matches_52_declared_changes=True,no_extra_changed_paths=True,all_36_package_files_match_sealed_r37_candidate=True,all_34_internal_declarations_rederived_from_published_manifest_bytes=True,all_17_frozen_files_identical_to_parent=True,whole_queue_and_RUN_CHANGELOG_byte_identical_to_parent=True,all_147_whole_queue_objects_identical=True,all_11_archives_crc_and_actual_member_hashes_match_published_manifests=True),provenance=dict(access_method='git cat-file --batch; binary object bytes; recomputed Git SHA-1 and independent SHA-256',fetch='Authorized git fetch origin main completed before this exact-pin verification; remote moved from 97e1012 to a7ec9c4 at that observation.',working_tree_or_index_reads_or_changes=False,publication=False,browser=False,semantic_payload_review=False),limits=['This is an exact-commit byte audit, not a claim that the remote main branch remains at this pin.','Instructional body identity is inherited from the sealed metadata-only candidate audit after all 36 actual published package files were matched to its pinned actual-byte identities.','Archive payloads were read as opaque bytes in memory only; no semantic review, extraction or nested source-history claims.','Historical external declarations are not promoted to current package-local assertions.'],inputs=[identity(planpath,planbytes),identity(MAP_PATH,frozenmapbytes),identity(cp/'byte-identities.json',ci_bytes)],candidate_seal_sha256='7cb70cdd9cbc114834efeeaf7f676d60714aaf5f173c1b24df6a07da83b857dc')
    write_json(OUT/'report.json',report)
    write_json(OUT/'byte-identities.json',dict(published_files=identities,exact_tree_changes=changes,frozen_files=frozen,unchanged_state_files=states,whole_queue_object_identities=queue_objects,internal_declarations=declarations,external_historical_exclusions=exclusions,archives=archives,actual_git_objects=git.objects))
    payload=[]
    for name in ['verify_release_bytes.py','report.json','byte-identities.json']:
        d=(OUT/name).read_bytes();payload.append(dict(path=name,bytes=len(d),sha256=sha256(d)))
    (OUT/'CHECKSUMS.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in payload))
    seal=dict(status='PASS',commit=TARGET,tree=tree,parent=PARENT,counts=counts,payloads=payload,checksum_file='CHECKSUMS.sha256',checksum_sha256=sha256((OUT/'CHECKSUMS.sha256').read_bytes()),semantic_review=False,published=False)
    write_json(OUT/'SEAL.json',seal)
    print(json.dumps(dict(status='PASS',commit=TARGET,tree=tree,parent=PARENT,counts=counts,outputs=[identity(OUT/n,(OUT/n).read_bytes()) for n in ['report.json','byte-identities.json','CHECKSUMS.sha256','SEAL.json']]),indent=2))

if __name__=='__main__': main()
