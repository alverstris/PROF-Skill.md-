#!/usr/bin/env python3
"""Byte-only verifier of two exact Git snapshots. Does not display payload content."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
REPO = ROOT / 'prof-iteration'
OUT = ROOT / 'root-review-d015-r37-publication/fa7ba01be035d64a5c72cc5037d484fb9afe245f'
TARGET = 'fa7ba01be035d64a5c72cc5037d484fb9afe245f'
EXPECTED_TREE = 'a3edbaaddcf1cfbaa94091cfbfce0a98dc006127'
PARENT = 'a7ec9c4d0a3ec582aa28ede116f935cf1d68bca1'
PREFIX = 'runs/y1-reader-20261008/iterations/015/published-r36-20261012/'
LOCAL = ROOT / 'd015-clean-r36-20261012'
MAP_PATH = LOCAL / 'work/publication1-readback.json'
PACKAGE_PATH = LOCAL / 'inputs/prof-package-manifest.json'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def identity(path, data):
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': sha256(data)}


def safe_path(path):
    p = PurePosixPath(path)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in path
    assert p.as_posix() == path
    return p


class ExactGit:
    def __init__(self):
        self.process = subprocess.Popen(
            ['git', '-C', str(REPO), 'cat-file', '--batch'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.cache = {}
        self.objects = []
        self.trees = {}

    def get(self, oid, expected_type=None):
        assert len(oid) == 40 and all(c in '0123456789abcdef' for c in oid)
        if oid not in self.cache:
            self.process.stdin.write((oid + '\n').encode())
            self.process.stdin.flush()
            header = self.process.stdout.readline().decode().strip().split()
            assert len(header) == 3 and header[0] == oid, header
            object_type, size = header[1], int(header[2])
            data = self.process.stdout.read(size)
            assert len(data) == size and self.process.stdout.read(1) == b'\n'
            actual_oid = hashlib.sha1(object_type.encode() + b' ' + str(size).encode() + b'\0' + data).hexdigest()
            assert actual_oid == oid
            self.cache[oid] = (object_type, data)
            self.objects.append({'git_oid': oid, 'type': object_type, 'bytes': size,
                                 'sha256': sha256(data), 'git_object_id_recomputed': actual_oid})
        object_type, data = self.cache[oid]
        assert expected_type is None or expected_type == object_type
        return data

    def commit(self, oid):
        data = self.get(oid, 'commit')
        # Interpret only tree and parent header fields. Do not interpret the message.
        headers = data.split(b'\n\n', 1)[0].splitlines()
        trees = [line[5:].decode() for line in headers if line.startswith(b'tree ')]
        parents = [line[7:].decode() for line in headers if line.startswith(b'parent ')]
        assert len(trees) == 1
        return trees[0], parents

    def tree(self, oid):
        if oid not in self.trees:
            data = self.get(oid, 'tree')
            entries = {}
            i = 0
            while i < len(data):
                j = data.index(b' ', i)
                k = data.index(b'\0', j)
                mode, name = data[i:j].decode(), data[j + 1:k].decode('utf-8')
                assert name not in entries and '/' not in name
                entries[name] = {'mode': mode, 'oid': data[k + 1:k + 21].hex()}
                i = k + 21
            assert i == len(data)
            self.trees[oid] = entries
        return self.trees[oid]

    def resolve(self, tree_oid, path):
        parts = safe_path(path).parts
        for i, part in enumerate(parts):
            entry = self.tree(tree_oid)[part]
            if i < len(parts) - 1:
                assert entry['mode'] == '40000'
                tree_oid = entry['oid']
        return entry

    def blob(self, tree_oid, path):
        entry = self.resolve(tree_oid, path)
        assert entry['mode'] in ('100644', '100755'), (path, entry['mode'])
        return entry, self.get(entry['oid'], 'blob')

    def close(self):
        self.process.stdin.close()
        self.process.wait()
        assert self.process.returncode == 0


def leaves(git, tree_oid, prefix=''):
    result = {}
    for name, entry in git.tree(tree_oid).items():
        path = prefix + name
        if entry['mode'] == '40000':
            result.update(leaves(git, entry['oid'], path + '/'))
        else:
            result[path] = entry
    return result


def tree_differences(git, old_oid, new_oid, prefix=''):
    if old_oid == new_oid:
        return []
    old = git.tree(old_oid) if old_oid else {}
    new = git.tree(new_oid) if new_oid else {}
    changes = []
    for name in sorted(set(old) | set(new)):
        before, after = old.get(name), new.get(name)
        if before == after:
            continue
        path = prefix + name
        if before and after and before['mode'] == after['mode'] == '40000':
            changes.extend(tree_differences(git, before['oid'], after['oid'], path + '/'))
        elif before is None and after['mode'] == '40000':
            changes.extend({'path': p, 'change': 'added', 'parent': None, 'published': e}
                           for p, e in leaves(git, after['oid'], path + '/').items())
        elif after is None and before['mode'] == '40000':
            changes.extend({'path': p, 'change': 'removed', 'parent': e, 'published': None}
                           for p, e in leaves(git, before['oid'], path + '/').items())
        else:
            changes.append({'path': path, 'change': 'added' if before is None else
                            'removed' if after is None else 'changed',
                            'parent': before, 'published': after})
    return sorted(changes, key=lambda r: r['path'])


def object_arrays(node, pointer=''):
    """Structural search only, never return interpreted object fields."""
    found = []
    if isinstance(node, list):
        if len(node) == 147 and all(isinstance(v, dict) for v in node):
            found.append((pointer, node))
        for i, value in enumerate(node):
            if isinstance(value, (dict, list)):
                found.extend(object_arrays(value, pointer + '/' + str(i)))
    elif isinstance(node, dict):
        for key, value in node.items():
            if isinstance(value, (dict, list)):
                found.extend(object_arrays(value, pointer + '/' + key.replace('~', '~0').replace('/', '~1')))
    return found


def canonical_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


import io
import zipfile
import zlib
import collections

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def internal_declarations(new):
    declarations, exclusions = [], []
    def check(df, pointer, path, digest, size=None):
        safe_path(path)
        data = new[path]
        assert sha256(data) == digest and (size is None or len(data) == size), path
        declarations.append(dict(declaration_file=df, field=pointer, path=path, bytes=len(data), sha256=sha256(data)))
    pp='references/sasis/profile-manifest.json'; pb='references/sasis/'
    p=json.loads(new[pp]); bd=str(safe_path(p['file_hashes_base_directory']))
    for path,h in p['file_hashes'].items(): check(pp,'/file_hashes/'+path,pb+bd+'/'+path,h)
    for path,h in p['control_file_hashes'].items(): check(pp,'/control_file_hashes/'+path,pb+path,h)
    for i,r in enumerate(p['subject_files']): check(pp,f'/subject_files/{i}/sha256',pb+r['path'],r['sha256'])
    rb=pb+'ocr-baseline-20261007/'; rp=rb+'release-manifest.json'; r=json.loads(new[rp])
    for i,f in enumerate(r['subjects']): check(rp,f'/subjects/{i}/sha256',rb+f['path'],f['sha256'],f['bytes'])
    check(rp,'/combined_baseline_sha256',rb+'student-baseline.txt',r['combined_baseline_sha256'])
    exclusions.append(dict(declaration_file=rp, field='/archive_sha256',reason='Historical external archive reference, outside the 36-file package.'))
    cp=rb+'chemistry/freeze-manifest.json'; c=json.loads(new[cp])
    for i,f in enumerate(c['files']):
        path=rb+'chemistry/'+f['path']
        if path in new: check(cp,f'/files/{i}/sha256',path,f['sha256'],f['bytes'])
        else: exclusions.append(dict(declaration_file=cp,field=f'/files/{i}',path=path,reason='Historical external file reference, not a current package-local declaration.'))
    assert len(declarations)==34 and len({r['path'] for r in declarations})==22
    return declarations,exclusions

def main():
    import copy
    planpath=LOCAL/'work/closure-plan.json';planbytes=planpath.read_bytes();plan=json.loads(planbytes)
    assert sha256(planbytes)=='0aa1e538c1244c0aa3f22e1092d1b794b7747655896f753c511ec1c1e9461ff9'
    assert plan['parent']==PARENT and plan['base_tree']=='ea2add07c541ee1f437db051d511d307340d9c52'
    assert len(plan['files'])==110 and sum(r['bytes'] for r in plan['files'])==17038542
    fmap={r['remote']:r for r in plan['files']};assert len(fmap)==110
    audit_a=ROOT/'root-review-d015-r37-publication'/PARENT
    abytes=(audit_a/'byte-identities.json').read_bytes();asealbytes=(audit_a/'SEAL.json').read_bytes()
    assert sha256(abytes)=='97aca52c487dafd7902bbf40ccdf21746aae3dc36bec5a203c8735417ae40fac'
    assert sha256(asealbytes)=='043b715034de845e41bfec83416221eba57dc1a416abe627de40d6fafa21d16d'
    a=json.loads(abytes);prior={r['path']:r for r in a['published_files']};assert len(prior)==101
    git=ExactGit();tree,parents=git.commit(TARGET);assert tree==EXPECTED_TREE and parents==[PARENT]
    pt,_=git.commit(PARENT);assert pt==plan['base_tree']
    actual={};identities=[];local_read={};preserved=[]
    for path,r in sorted(fmap.items()):
        safe_path(path);lp=Path(r['local']);assert lp.is_relative_to(LOCAL) and not lp.is_symlink()
        local=lp.read_bytes();entry,data=git.blob(tree,path);actual[path]=data;local_read[str(lp)]=sha256(local)
        assert data==local and len(data)==r['bytes'] and sha256(data)==r['sha256'] and entry['oid']==r['git_blob'],path
        identities.append(dict(path=path,local=str(lp.relative_to(ROOT)),bytes=len(data),sha256=sha256(data),actual_git_blob=entry['oid'],mode=entry['mode'],exact_local_bytes_equal=True,plan_identity_match=True))
        if path in prior:
            pe,pd=git.blob(pt,path);ar=prior[path]
            assert data==pd and pe==entry and len(data)==ar['bytes'] and sha256(data)==ar['sha256'] and entry['oid']==ar['actual_git_blob'],path
            preserved.append(dict(path=path,bytes=len(data),sha256=sha256(data),parent_git_blob=pe['oid'],published_git_blob=entry['oid'],exact_bytes_and_mode_equal=True))
    assert len(preserved)==101 and sum(r['bytes'] for r in preserved)==16512540
    package={p:actual[p] for p in prior if not p.startswith(PREFIX)}
    assert len(package)==36 and sum(map(len,package.values()))==907146
    declarations,exclusions=internal_declarations(package)
    changes=tree_differences(git,pt,tree);changed={r['path'] for r in changes};newplan=set(fmap)-set(prior)
    assert changed==newplan=={p for p,r in fmap.items() if r['upload'] is True} and len(changes)==9
    assert sum(r['change']=='added' for r in changes)==6 and sum(r['change']=='changed' for r in changes)==3
    qp='runs/y1-reader-20261008/queue.json';qe,qb=git.blob(tree,qp);pe,pb=git.blob(pt,qp);q=json.loads(qb);p=json.loads(pb)
    assert len(object_arrays(q))==len(object_arrays(p))==1
    assert len(q['sessions'])==len(p['sessions'])==147
    queue_identities=[];different=[]
    for i,(old,new) in enumerate(zip(p['sessions'],q['sessions'])):
        assert (old['id'],old['material_id'],old['order'])==(new['id'],new['material_id'],new['order'])
        ob=canonical_bytes(old);nb=canonical_bytes(new);equal=ob==nb
        if not equal:different.append(new['material_id'])
        queue_identities.append(dict(index=i,id=new['id'],material_id=new['material_id'],order=new['order'],parent_canonical_bytes=len(ob),published_canonical_bytes=len(nb),parent_sha256=sha256(ob),published_sha256=sha256(nb),whole_object_identical=equal))
    assert different==['D015'] and sum(r['whole_object_identical'] for r in queue_identities)==146
    old=next(x for x in p['sessions'] if x['material_id']=='D015');new=next(x for x in q['sessions'] if x['material_id']=='D015')
    oldhistory=old.get('iteration_history',[]);newhistory=new['iteration_history'];assert len(newhistory)==len(oldhistory)+1 and newhistory[:-1]==oldhistory
    archived=newhistory[-1]['previous_record'];assert canonical_bytes(archived)==canonical_bytes(old)
    fields={k for k in set(old)|set(new) if old.get(k)!=new.get(k)}
    assert fields=={'evidence','source_access','current_review_status','incoming_prof','iteration_history','current_iteration','published_commit','status','outgoing_prof'}
    assert new['status']=='closed' and new['incoming_prof']=='2026-10-12-r36' and new['outgoing_prof']=='2026-10-12-r37' and new['published_commit']==PARENT
    assert new['evidence'][:len(old['evidence'])]==old['evidence']
    expected_evidence=['final-adjudication.md','sasis-report.md','technical-report.txt','independent-mechanics-report.md','root-original/final-disposition.md','root-original/destination-review.md','closure.md','release-readback.json','published-archive-readback.json']
    assert new['evidence'][len(old['evidence']):]==['iterations/015/published-r36-20261012/evidence/'+x for x in expected_evidence]
    for path in new['evidence'][len(old['evidence']):]:assert 'runs/y1-reader-20261008/'+path in actual
    altered=copy.deepcopy(p);altered['sessions']=q['sessions'];altered['active_material_id']='D016';altered['active_readability_scope']['closed']=16;altered['active_readability_scope']['remaining']=60
    assert altered==q
    active=q['active_readability_scope'];prioractive=p['active_readability_scope'];ids=active['active_session_ids'];assert ids==prioractive['active_session_ids'] and len(ids)==len(set(ids))==76
    eligible=[r for r in q['sessions'] if r['id'] in set(ids)];excluded=[r for r in q['sessions'] if r['id'] not in set(ids)]
    assert len(eligible)==76 and len(excluded)==71 and active['eligible']==76 and active['excluded']==71
    accepted=[r for r in eligible if r['status']=='closed'];pending=[r for r in eligible if r['status']!='closed'];assert len(accepted)==16 and len(pending)==60 and [r['material_id'] for r in pending[:2]]==['D016','D018'] and q['active_material_id']=='D016'
    entrypath=PREFIX+'evidence/closure.md';entrybytes=actual[entrypath];state_records=[]
    for path in ['runs/y1-reader-20261008/RUN.md','runs/y1-reader-20261008/CHANGELOG.md']:
        before_entry,before=git.blob(pt,path);after=actual[path]
        assert after==entrybytes+before
        state_records.append(dict(path=path,parent_bytes=len(before),published_bytes=len(after),parent_sha256=sha256(before),published_sha256=sha256(after),exact_original_bytes_preserved_as_suffix=True,new_prefix_path=entrypath,new_prefix_bytes=len(entrybytes),new_prefix_sha256=sha256(entrybytes),old_suffix_offset=len(entrybytes)))
    canonical=json.loads(actual[PREFIX+'evidence/canonical-invariants.json'])
    for k,v in dict(release_pin=PARENT,original_records=147,eligible=76,excluded=71,accepted=16,remaining=60,only_changed_session='D015',unchanged_other_sessions=146,active_material_id='D016',next_pending_after_active='D018').items():assert canonical[k]==v
    receipt=json.loads(actual[PREFIX+'evidence/release-readback.json'])
    assert receipt['pin']==PARENT and receipt['tree']==pt and receipt['actual_main']==PARENT and receipt['count']==101 and receipt['bytes']==16512540
    rr={r['path']:r for r in receipt['files']};assert set(rr)==set(prior)
    for path,r in rr.items():
        b=actual[path];assert len(b)==r['bytes'] and sha256(b)==r['sha256'] and fmap[path]['git_blob']==r['git_blob']
    archives=json.loads(actual[PREFIX+'evidence/published-archive-readback.json']);assert archives['pin']==PARENT
    aa={Path(r['path']).name:r for r in a['archives']};archive_receipts=[]
    for r in archives['actual_git_archive_member_checks']:
        ar=aa[r['archive']];assert len(actual[ar['path']])==r['actual_git_bytes'] and sha256(actual[ar['path']])==r['sha256'] and ar['actual_members']==r['all_members_verified']
        archive_receipts.append(dict(path=ar['path'],actual_members=ar['actual_members'],sha256=ar['sha256'],receipt_matches_independent_release_a_audit=True))
    assert len(archive_receipts)==7 and archives['opaque_archive_and_manifest_files']==8
    for path,h in local_read.items():assert sha256(Path(path).read_bytes())==h,path
    assert planpath.read_bytes()==planbytes and (audit_a/'byte-identities.json').read_bytes()==abytes and (audit_a/'SEAL.json').read_bytes()==asealbytes
    git.close()
    counts=dict(planned_files=110,planned_bytes=17038542,actual_changed_paths=9,added_evidence_paths=6,modified_canonical_paths=3,unchanged_release_a_paths=101,unchanged_release_a_bytes=16512540,unchanged_package_files=36,package_bytes=907146,internal_declarations=34,whole_queue_objects=147,unchanged_whole_queue_objects=146,changed_whole_queue_objects=1,eligible=76,excluded=71,accepted=16,remaining=60,preserved_prior_frozen_files=17,unchanged_archives=11,unchanged_archive_members=866,published_archive_receipt_records_crosschecked=7)
    provenance=dict(access_method='git cat-file --batch; actual binary objects; independently recomputed Git SHA-1 and SHA-256',fetch='Authorized git fetch origin main completed before exact-pin verification.',working_tree_or_index_reads_or_changes=False,publication=False,browser=False,semantic_review=False)
    report=dict(status='PASS',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_commit=TARGET,actual_tree=tree,actual_parent=PARENT,actual_parent_tree=pt,counts=counts,active_material_id='D016',next_pending_after_active='D018',checks=dict(all_110_actual_git_blobs_match_actual_local_and_plan_size_sha256_oid=True,all_local_inputs_reread_unchanged=True,exact_tree_change_set_is_six_evidence_additions_and_three_canonical_modifications=True,all_101_release_a_paths_byte_and_mode_identical=True,all_36_package_files_preserved_and_34_internal_declarations_rederived=True,only_D015_whole_queue_object_changes=True,all_146_other_whole_objects_identical=True,all_147_ids_material_ids_and_order_preserved=True,eligibility_and_exclusions_identical=True,complete_prior_D015_object_preserved_in_iteration_history=True,queue_top_level_changes_limited_to_D015_and_active_id_closed_remaining=True,prior_RUN_and_CHANGELOG_exact_bytes_preserved_as_suffix=True,new_prefix_exactly_equals_published_closure_md=True,release_receipt_101_actual_identities_crosschecked=True,seven_archive_receipt_records_crosschecked_against_independent_actual_member_audit=True),provenance=provenance,limits=['This is exact-pin byte verification, not a claim that remote main remains at this commit.','Closure documentation and queue review-status prose are preserved author claims; this audit does not independently repeat semantic acceptance reviews.','The new closure entry is prepended as the byte prefix; every prior RUN and CHANGELOG byte remains as its exact suffix. This is not a tail append.','Archive verification is inherited from the sealed release A member-byte audit because all 11 complete published archive bytes and manifests are independently proven identical in closure B. No repeated semantic or nested source review was performed.','Historical external package declarations remain excluded from the 34 current package-local declarations.'],inputs=[identity(planpath,planbytes),identity(audit_a/'byte-identities.json',abytes),identity(audit_a/'SEAL.json',asealbytes)])
    identities_doc=dict(published_files=identities,exact_tree_changes=changes,release_a_preserved_files=preserved,whole_queue_objects=queue_identities,D015=dict(parent_sha256=sha256(canonical_bytes(old)),archived_previous_record_sha256=sha256(canonical_bytes(archived)),published_sha256=sha256(canonical_bytes(new)),changed_fields=sorted(fields),previous_iteration_history_entries=len(oldhistory),published_iteration_history_entries=len(newhistory),previous_record_complete_canonical_byte_identity=True),canonical_queue_file=dict(path=qp,parent_bytes=len(pb),published_bytes=len(qb),parent_sha256=sha256(pb),published_sha256=sha256(qb),parent_git_blob=pe['oid'],published_git_blob=qe['oid']),run_changelog_preservation=state_records,internal_declarations=declarations,external_historical_exclusions=exclusions,archive_receipt_crosschecks=archive_receipts,actual_git_objects=git.objects)
    write_json(OUT/'report.json',report);write_json(OUT/'byte-identities.json',identities_doc)
    payload=[]
    for name in ['verify_closure_bytes.py','report.json','byte-identities.json']:
        d=(OUT/name).read_bytes();payload.append(dict(path=name,bytes=len(d),sha256=sha256(d)))
    (OUT/'CHECKSUMS.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in payload))
    seal=dict(status='PASS',commit=TARGET,tree=tree,parent=PARENT,counts=counts,payloads=payload,checksum_file='CHECKSUMS.sha256',checksum_sha256=sha256((OUT/'CHECKSUMS.sha256').read_bytes()),release_a_seal_sha256=sha256(asealbytes),semantic_review=False,published=False)
    write_json(OUT/'SEAL.json',seal)
    print(json.dumps(dict(status='PASS',commit=TARGET,tree=tree,parent=PARENT,counts=counts,outputs=[identity(OUT/n,(OUT/n).read_bytes()) for n in ['report.json','byte-identities.json','CHECKSUMS.sha256','SEAL.json']]),indent=2))

if __name__=='__main__':main()
