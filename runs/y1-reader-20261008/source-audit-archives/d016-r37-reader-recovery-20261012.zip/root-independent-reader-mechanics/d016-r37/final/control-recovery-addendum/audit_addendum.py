#!/usr/bin/env python3
"""Targeted late-preservation audit only; no repeated subject audit or retrieval."""
from pathlib import Path
import hashlib,json,datetime
ROOT=Path('/workspace/scratch/f9c0b7fc7e76');B=ROOT/'d016-clean-r37-20261012';R=B/'reader-route';E=R/'reader-evidence';P=ROOT/'root-independent-reader-mechanics/d016-r37/final';O=Path(__file__).resolve().parent
checks=[];inputs={}
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);assert p.is_file() and not p.is_symlink()
 if p not in inputs:inputs[p]=p.read_bytes()
 return inputs[p]
def js(p):return json.loads(read(p))
def ck(ok,name,**w):
 checks.append({'check':name,'pass':bool(ok),**w})
 if not ok:raise AssertionError((name,w))
ck(sha(read(P/'output-manifest.json'))=='05507374e3eff79194d114630e816053cd3541020228aa3f1a777c9f1f0461ef','initial final-audit seal unchanged')
oldmanifest=js(P/'output-manifest.json')
for x in oldmanifest['files']:ck(len(read(P/x['path']))==x['bytes'] and sha(read(P/x['path']))==x['sha256'],'initial audit artifact unchanged',path=x['path'])
report=E/'original-reader-report.md';ledger=R/'runtime/ledger.jsonl'
ck(len(read(report))==23181 and sha(read(report))=='b169f65f634e1206dc4fde728a76f34970c94d1164cc049ae6102ea7909f4d1e','original reader report unchanged at seal')
ck(len(read(ledger))==224520 and sha(read(ledger))=='96b57ce9c6813e3956cb18263891a68a69a1598ed0492c932fd474355c9449f1','actual completed ledger unchanged at prior verified seal')
oldinputs=js(P/'input-manifest.json')['files'];error=E/'report-write-failure-001.json';old_error=next(x for x in oldinputs if x['path']==str(error.relative_to(B)))
ck(len(read(error))==old_error['bytes'] and sha(read(error))==old_error['sha256'],'original parse-failure disclosure unchanged')
packet=js(R/'route-packet-freeze.json');controlpins={x['path']:x for x in packet['files']}
ck(sha(read(R/'route-packet-freeze.json'))=='635c202fa04b7116ff8c0793bd1f4c777a72b80b05885579a09fdf57ebf48fe7','original packet seal unchanged')
provpath=E/'control-recovery-provenance.json';prov=js(provpath)
ck(prov['kind']=='late-control-result-transcript-recovery' and len(prov['files'])==7,'exact seven-entry late transcript-recovery provenance')
ck(prov['retained_runtime_objects'] is False and prov['functions_store_used_during_original_reads'] is False and 'isolates ended' in prov['original_result_object_lifetime_limit'],'provenance does not claim preserved original live objects')
ck('No control or subject file was reread' in prov['method'] and 'no tool command or script was rerun' in prov['method'],'provenance explicitly reports copy from existing exposed transcript only')
ck('does not make the original immediate-preservation requirement retrospectively satisfied' in prov['temporal_limit'],'historical immediate-preservation lapse remains explicit')
ck(prov['original_report_changed'] is False and prov['new_subject_access'] is False and prov['new_semantic_findings'] is False,'provenance records no report/subject/semantic changes')
ck(prov['additional_report_write_error_object_available'] is False and 'none was fabricated' in prov['report_write_error_limit'],'no nonexistent structured parse-error result claimed')
expected=['reader-operating-instruction.txt','dispatch-instructions.txt','chronological-route.md']+[f'view-invocations/view-F{i:02}.js' for i in range(1,5)]
ck([x['original_control'] for x in prov['files']]==expected,'exact permitted three initial and four image-control files')
existingids={x['retained_exec_chunk_id'] for x in js(P/'verified-ids.json')['calls']};seen=set();records=[]
for i,x in enumerate(prov['files'],1):
 p=E/x['filename'];d=js(p);control=R/x['original_control'];pin=controlpins[str(control)];c=read(control)
 ck(p.parent==E and p.name.startswith(f'recovered-control-{i:02}-'),'unique numbered recovery destination',ordinal=i)
 ck(set(d)=={'chunk_id','wall_time_seconds','exit_code','original_token_count','output'},'exact recovered exposed result fields',ordinal=i)
 ck(d['chunk_id']==x['original_chunk_id'] and d['chunk_id'] not in seen and d['chunk_id'] not in existingids,'recovered IDs distinct and agree with provenance',ordinal=i,chunk_id=d['chunk_id']);seen.add(d['chunk_id'])
 ck(d['exit_code']==0 and type(d['output'])is str and type(d['wall_time_seconds'])in [int,float] and d['wall_time_seconds']>=0 and type(d['original_token_count'])is int and d['original_token_count']>=0,'successful recovered exec metadata well formed',ordinal=i)
 ck(len(c)==pin['bytes'] and sha(c)==pin['sha256'],'actual control bytes retain original packet identity',ordinal=i,path=x['original_control'])
 out=d['output'].encode('utf-8');ck(out==c,'entire recovered output equals exact frozen permitted control bytes',ordinal=i,bytes=len(out),sha256=sha(out))
 records.append({'ordinal':i,'file':x['filename'],'file_bytes':len(read(p)),'file_sha256':sha(read(p)),'original_control':x['original_control'],'reported_original_chunk_id':d['chunk_id'],'exit_code':d['exit_code'],'output_bytes':len(out),'output_sha256':sha(out),'frozen_control_sha256':pin['sha256'],'complete_byte_match':True})
ck({p.name for p in E.glob('recovered-control-*.json')}=={x['filename'] for x in prov['files']},'all seven recovered records accounted for; no unlisted recovery extras')
dispositionpath=ROOT/'root-review-d016-r37/final-disposition.md';disposition=read(dispositionpath).decode();decision=next(x for x in disposition.splitlines() if x.startswith('The report also preserves a post-reading report-write'))
ck("Root's output-recovery decision is to retain the exposed failure text and successful pinned original report and accept the recovered report output for audit." in decision,'explicit coordinator output-only recovery disposition exists')
ck('No new reader is required solely by this report-write failure' in decision and 'preserve the initial final audit and reader report' in decision,'coordinator preserves original evidence and narrows output recovery')
for p,b in inputs.items():ck(p.read_bytes()==b,'targeted inputs unchanged during addendum audit',path=str(p.relative_to(ROOT)))
result={'schema':'d016-r37-control-recovery-targeted-addendum-v1','outcome':'RECOVERED_CONTROL_OUTPUT_BYTES_VERIFIED_AND_COORDINATOR_OUTPUT_RECOVERY_RECORDED_WITH_HISTORICAL_LIMITS','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'New late-preservation evidence, frozen control identities and unchanged report/ledger/audit seals only; no rerun of2537-check subject audit.','counts':{'recovered_control_results':7,'complete_matching_control_outputs':7,'total_control_output_bytes':sum(x['output_bytes'] for x in records),'new_subject_retrievals_by_this_auditor':0},'records':records,'provenance':prov,'provenance_sha256':sha(read(provpath)),'coordinator_disposition':{'path':str(dispositionpath),'sha256':sha(read(dispositionpath)),'verbatim_output_recovery_paragraph':decision},'original_preservation':{'initial_audit_manifest_sha256':sha(read(P/'output-manifest.json')),'original_report_sha256':sha(read(report)),'original_ledger_sha256':sha(read(ledger)),'original_parse_failure_sha256':sha(read(error))},'resolved_scope':['The current separate-archive absence is remedied by7 late files containing complete exact permitted control outputs, with distinct reported original chunk IDs and explicit provenance.','The original report/ledger/failure record and initial audit remain byte-for-byte unchanged.','Coordinator explicitly accepts the successful pinned report output for audit while retaining the earlier parse failure.'],'remaining_limits':['These are reader-transcribed copies of already-exposed native result entries, not retained live JavaScript result objects. Provenance explicitly says the original isolates ended and no functions store was used.','This independent auditor has the supplied late records and frozen control files, not independent direct access to the original reader native transcript. It verifies recovered content/identity consistency, not original metadata authenticity, original command argv or per-read time/order. The result objects do not carry command/timestamp fields.','The initial immediate-separate-preservation requirement was not satisfied at read time; late recovery does not rewrite that history.','No extra structured host parse-error object exists according to provenance; the original error-text disclosure remains the honest available evidence.','No technical confinement, authenticated host transcript, semantic comprehension, or substantive teaching acceptance is claimed. Root retains content disposition.'],'checks':checks,'checks_count':len(checks),'all_checks_pass':True,'input_identities':[{'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b)} for p,b in sorted(inputs.items())]}
(O/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'outcome':result['outcome'],'counts':result['counts'],'checks':len(checks),'verification_sha256':sha((O/'verification.json').read_bytes())},indent=2))
