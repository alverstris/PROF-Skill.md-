#!/usr/bin/env python3
"""Byte-only verifier of two exact Git snapshots. Does not display payload content."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
REPO = ROOT / 'prof-iteration'
OUT = ROOT / 'root-review-d016-r38-candidate'
TARGET = '4ca83e8b709f1e52a1bd2a3a2d612ab48722c195'
EXPECTED_TREE = '2b21552799ed9534486ae841244452720190aa24'
PARENT = 'fa7ba01be035d64a5c72cc5037d484fb9afe245f'
PREFIX = 'runs/y1-reader-20261008/iterations/016/published-r37-20261012/'
LOCAL = ROOT / 'd016-clean-r37-20261012'
MAP_PATH = LOCAL / 'publication/teaching-readback.json'
PACKAGE_PATH = LOCAL / 'inputs/prof-package-manifest.json'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def identity(path, data):
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': sha256(data)}


def safe_path(path):
    p = PurePosixPath(path)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in path
    assert p.as_posix() == path
    return p


class ExactGit:
    def __init__(self):
        self.process = subprocess.Popen(
            ['git', '-C', str(REPO), 'cat-file', '--batch'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.cache = {}
        self.objects = []
        self.trees = {}

    def get(self, oid, expected_type=None):
        assert len(oid) == 40 and all(c in '0123456789abcdef' for c in oid)
        if oid not in self.cache:
            self.process.stdin.write((oid + '\n').encode())
            self.process.stdin.flush()
            header = self.process.stdout.readline().decode().strip().split()
            assert len(header) == 3 and header[0] == oid, header
            object_type, size = header[1], int(header[2])
            data = self.process.stdout.read(size)
            assert len(data) == size and self.process.stdout.read(1) == b'\n'
            actual_oid = hashlib.sha1(object_type.encode() + b' ' + str(size).encode() + b'\0' + data).hexdigest()
            assert actual_oid == oid
            self.cache[oid] = (object_type, data)
            self.objects.append({'git_oid': oid, 'type': object_type, 'bytes': size,
                                 'sha256': sha256(data), 'git_object_id_recomputed': actual_oid})
        object_type, data = self.cache[oid]
        assert expected_type is None or expected_type == object_type
        return data

    def commit(self, oid):
        data = self.get(oid, 'commit')
        # Interpret only tree and parent header fields. Do not interpret the message.
        headers = data.split(b'\n\n', 1)[0].splitlines()
        trees = [line[5:].decode() for line in headers if line.startswith(b'tree ')]
        parents = [line[7:].decode() for line in headers if line.startswith(b'parent ')]
        assert len(trees) == 1
        return trees[0], parents

    def tree(self, oid):
        if oid not in self.trees:
            data = self.get(oid, 'tree')
            entries = {}
            i = 0
            while i < len(data):
                j = data.index(b' ', i)
                k = data.index(b'\0', j)
                mode, name = data[i:j].decode(), data[j + 1:k].decode('utf-8')
                assert name not in entries and '/' not in name
                entries[name] = {'mode': mode, 'oid': data[k + 1:k + 21].hex()}
                i = k + 21
            assert i == len(data)
            self.trees[oid] = entries
        return self.trees[oid]

    def resolve(self, tree_oid, path):
        parts = safe_path(path).parts
        for i, part in enumerate(parts):
            entry = self.tree(tree_oid)[part]
            if i < len(parts) - 1:
                assert entry['mode'] == '40000'
                tree_oid = entry['oid']
        return entry

    def blob(self, tree_oid, path):
        entry = self.resolve(tree_oid, path)
        assert entry['mode'] in ('100644', '100755'), (path, entry['mode'])
        return entry, self.get(entry['oid'], 'blob')

    def close(self):
        self.process.stdin.close()
        self.process.wait()
        assert self.process.returncode == 0


def leaves(git, tree_oid, prefix=''):
    result = {}
    for name, entry in git.tree(tree_oid).items():
        path = prefix + name
        if entry['mode'] == '40000':
            result.update(leaves(git, entry['oid'], path + '/'))
        else:
            result[path] = entry
    return result


def tree_differences(git, old_oid, new_oid, prefix=''):
    if old_oid == new_oid:
        return []
    old = git.tree(old_oid) if old_oid else {}
    new = git.tree(new_oid) if new_oid else {}
    changes = []
    for name in sorted(set(old) | set(new)):
        before, after = old.get(name), new.get(name)
        if before == after:
            continue
        path = prefix + name
        if before and after and before['mode'] == after['mode'] == '40000':
            changes.extend(tree_differences(git, before['oid'], after['oid'], path + '/'))
        elif before is None and after['mode'] == '40000':
            changes.extend({'path': p, 'change': 'added', 'parent': None, 'published': e}
                           for p, e in leaves(git, after['oid'], path + '/').items())
        elif after is None and before['mode'] == '40000':
            changes.extend({'path': p, 'change': 'removed', 'parent': e, 'published': None}
                           for p, e in leaves(git, before['oid'], path + '/').items())
        else:
            changes.append({'path': path, 'change': 'added' if before is None else
                            'removed' if after is None else 'changed',
                            'parent': before, 'published': after})
    return sorted(changes, key=lambda r: r['path'])


def object_arrays(node, pointer=''):
    """Structural search only, never return interpreted object fields."""
    found = []
    if isinstance(node, list):
        if len(node) == 147 and all(isinstance(v, dict) for v in node):
            found.append((pointer, node))
        for i, value in enumerate(node):
            if isinstance(value, (dict, list)):
                found.extend(object_arrays(value, pointer + '/' + str(i)))
    elif isinstance(node, dict):
        for key, value in node.items():
            if isinstance(value, (dict, list)):
                found.extend(object_arrays(value, pointer + '/' + key.replace('~', '~0').replace('/', '~1')))
    return found


def canonical_bytes(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


import io
import zipfile
import zlib
import difflib
import collections
import copy

def write_json(path,value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+"\n")

def internal_declarations(new):
    declarations, exclusions = [], []
    def check(df, pointer, path, digest, size=None):
        safe_path(path)
        data = new[path]
        assert sha256(data) == digest and (size is None or len(data) == size), path
        declarations.append(dict(declaration_file=df, field=pointer, path=path, bytes=len(data), sha256=sha256(data)))
    pp='references/sasis/profile-manifest.json'; pb='references/sasis/'
    p=json.loads(new[pp]); bd=str(safe_path(p['file_hashes_base_directory']))
    for path,h in p['file_hashes'].items(): check(pp,'/file_hashes/'+path,pb+bd+'/'+path,h)
    for path,h in p['control_file_hashes'].items(): check(pp,'/control_file_hashes/'+path,pb+path,h)
    for i,r in enumerate(p['subject_files']): check(pp,f'/subject_files/{i}/sha256',pb+r['path'],r['sha256'])
    rb=pb+'ocr-baseline-20261007/'; rp=rb+'release-manifest.json'; r=json.loads(new[rp])
    for i,f in enumerate(r['subjects']): check(rp,f'/subjects/{i}/sha256',rb+f['path'],f['sha256'],f['bytes'])
    check(rp,'/combined_baseline_sha256',rb+'student-baseline.txt',r['combined_baseline_sha256'])
    exclusions.append(dict(declaration_file=rp, field='/archive_sha256',reason='Historical external archive reference, outside the 36-file package.'))
    cp=rb+'chemistry/freeze-manifest.json'; c=json.loads(new[cp])
    for i,f in enumerate(c['files']):
        path=rb+'chemistry/'+f['path']
        if path in new: check(cp,f'/files/{i}/sha256',path,f['sha256'],f['bytes'])
        else: exclusions.append(dict(declaration_file=cp,field=f'/files/{i}',path=path,reason='Historical external file reference, not a current package-local declaration.'))
    assert len(declarations)==34 and len({r['path'] for r in declarations})==22
    return declarations,exclusions

CANDIDATE=LOCAL/'candidate-prof-r38'
PROVISIONAL=LOCAL/'provisional-metadata-only-r38'
CHECK_PATH=LOCAL/'publication/r38-repair-package-check.json'
T10_ADDITION=' For a general directional or comparison claim, record the declared parameter domain, the sign or order warrant, and a relevant admissible zero, sign or boundary check when it discriminates the claim. Put any necessary restriction in the stated premises; a successful special case cannot silently supply it.'
NEW_EXECUTION_PARAGRAPH='When a qualitative summary interprets a formula, check the summary itself against the stated domain, rather than only checking numerical examples. Before accepting a consequential directional or comparison claim, record its exact wording and location, the relation or difference that determines its sign or order, and the parameter domain actually stated before the claim. Derive the claimed direction under that domain and check a relevant admissible zero, sign reversal or boundary value when it discriminates the claim. Positive examples, an expected physical convention or a later special case cannot silently narrow a general parameter. If the direction needs a narrower domain, state that restriction in the relevant premises before use, or state the conditional relation, and recheck affected explanations and help under the active repair mode. An already established sign or order warrant can be cited; do not manufacture unrelated edge-case catalogues or a new example for each sentence. Derive any unit product or comparison from the formula and test a relevant admissible limiting or exceptional case. For example, multiplying by a dimensionless integration variable does not create a new unit; a claim that units necessarily differ needs the dimensional condition. Retain the correct relation without extending its scope.'

def main():
    input_data={}
    for p in [CHECK_PATH,PACKAGE_PATH,LOCAL/'publication/r38-repair-internal-hashes.json',LOCAL/'publication/r38-repair-quick-validation.json',LOCAL/'publication/candidate-package-metadata-check.json']:
        input_data[str(p)]=p.read_bytes()
    cb=input_data[str(CHECK_PATH)];assert sha256(cb)=='fb8058ebc9fc67a87a9297c859c20445d4c7175e97ba98b960819eee2319caee'
    claim=json.loads(cb);pm=json.loads(input_data[str(PACKAGE_PATH)]);hc=json.loads(input_data[str(LOCAL/'publication/r38-repair-internal-hashes.json')]);provisional_claim=json.loads(input_data[str(LOCAL/'publication/candidate-package-metadata-check.json')])
    assert claim['incoming']=='2026-10-12-r37' and claim['candidate']=='2026-10-12-r38' and claim['behavioral_change'] is True
    assert Path(claim['provisional_metadata_candidate_preserved'])==PROVISIONAL
    rows={r['path']:r for r in claim['files']};package_rows={r['path']:r for r in pm['files']};provisional_rows={r['path']:r for r in provisional_claim['files']}
    files={p.relative_to(CANDIDATE).as_posix():p for p in CANDIDATE.rglob('*') if p.is_file()};provisional_files={p.relative_to(PROVISIONAL).as_posix():p for p in PROVISIONAL.rglob('*') if p.is_file()}
    assert all(not p.is_symlink() for d in [CANDIDATE,PROVISIONAL] for p in d.rglob('*'))
    assert set(files)==set(rows)==set(package_rows)==set(provisional_files)==set(provisional_rows) and len(files)==len(claim['files'])==claim['count']==36
    git=ExactGit();tree,parents=git.commit(TARGET);assert tree==EXPECTED_TREE and parents==[PARENT]
    assert pm['commit']==PARENT and pm['tree']=='a3edbaaddcf1cfbaa94091cfbfce0a98dc006127' and pm['version']=='2026-10-12-r37'
    old={};new={};provisional={};identities=[];diff=[];changed=[]
    for path in package_rows:
        safe_path(path);entry,ob=git.blob(tree,path);nb=files[path].read_bytes();vb=provisional_files[path].read_bytes();old[path]=ob;new[path]=nb;provisional[path]=vb
        row=rows[path];pr=package_rows[path];vr=provisional_rows[path];oid=hashlib.sha1(b'blob '+str(len(nb)).encode()+b'\0'+nb).hexdigest();void=hashlib.sha1(b'blob '+str(len(vb)).encode()+b'\0'+vb).hexdigest()
        assert len(ob)==pr['bytes'] and sha256(ob)==pr['sha256'] and entry['oid']==pr['git_blob'],path
        assert len(nb)==row['bytes'] and sha256(nb)==row['sha256'] and oid==row['git_blob'],path
        assert len(vb)==vr['bytes'] and sha256(vb)==vr['sha256'] and void==vr['git_blob'],path
        if ob!=nb:
            changed.append(path);diff.extend(difflib.unified_diff(ob.decode().splitlines(True),nb.decode().splitlines(True),fromfile='actual-r37/'+path,tofile='candidate-r38/'+path))
        assert bool(row['changed_from_r37'])==(ob!=nb)
        identities.append(dict(path=path,r37_bytes=len(ob),r37_sha256=sha256(ob),r37_actual_git_blob=entry['oid'],r37_mode=entry['mode'],candidate_bytes=len(nb),candidate_sha256=sha256(nb),candidate_computed_git_blob=oid,provisional_bytes=len(vb),provisional_sha256=sha256(vb),provisional_computed_git_blob=void,changed_from_r37_by_actual_bytes=ob!=nb,candidate_matches_provisional_by_actual_bytes=nb==vb))
    assert sum(map(len,new.values()))==claim['bytes']==908216 and sum(map(len,old.values()))==907146 and sum(map(len,provisional.values()))==907146
    expected_changed={'SKILL.md','references/execution-protocol.md','references/sasis.md','references/sasis/student-testing-contract.txt','references/sasis/profile-manifest.json'}
    assert set(changed)==set(claim['changed_files'])==expected_changed
    profile='references/sasis/profile-manifest.json';contract='references/sasis/student-testing-contract.txt';sasis='references/sasis.md';execution='references/execution-protocol.md'
    expected_metadata=copy.copy(old)
    expected_metadata['SKILL.md']=old['SKILL.md'].replace(b'  version: "2026-10-12-r37"\r\n',b'  version: "2026-10-12-r38"\r\n',1)
    expected_metadata[sasis]=old[sasis].replace(b'Protocol revision: 2026-10-12-r37.\n',b'Protocol revision: 2026-10-12-r38.\n',1)
    expected_metadata[contract]=old[contract].replace('SASIS reader contract — revision 2026-10-12-r37\n'.encode(),'SASIS reader contract — revision 2026-10-12-r38\n'.encode(),1)
    expected_metadata[profile]=old[profile].replace(b'"protocol_revision": "2026-10-12-r37"',b'"protocol_revision": "2026-10-12-r38"',1).replace(sha256(old[contract]).encode(),sha256(expected_metadata[contract]).encode(),1)
    assert expected_metadata==provisional
    expected=copy.copy(expected_metadata)
    old_t10=next(line for line in expected['SKILL.md'].splitlines(keepends=True) if line.startswith(b'| T10 Technical verification |'))
    assert old_t10.endswith(b' |\r\n');new_t10=old_t10[:-4]+T10_ADDITION.encode()+b' |\r\n';expected['SKILL.md']=expected['SKILL.md'].replace(old_t10,new_t10,1)
    old_exec=next(line for line in old[execution].splitlines(keepends=True) if line.startswith(b'When a qualitative summary interprets a formula,'));assert old_exec.endswith(b'\r\n');new_exec=NEW_EXECUTION_PARAGRAPH.encode()+b'\r\n';expected[execution]=old[execution].replace(old_exec,new_exec,1)
    assert expected==new
    # Preserve CRLF and every other byte; these exact substitutions account for the complete package difference.
    baseprefix='references/sasis/ocr-baseline-20261007/';baseline_paths=sorted(p for p in files if p.startswith(baseprefix));assert all(new[p]==old[p] for p in baseline_paths)
    assert sha256(new[baseprefix+'student-baseline.txt'])=='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5' and len(new[baseprefix+'student-baseline.txt'])==247840
    declarations,exclusions=internal_declarations(new)
    claim_group_bases={'subject_files':'references/sasis/','file_hashes':'references/sasis/','control_file_hashes':'references/sasis/','release-manifest.subjects':baseprefix,'release-manifest.combined_baseline':baseprefix,'chemistry.freeze-manifest.files':baseprefix}
    normalized_claim=[]
    for row in hc['checks']:
        safe_path(row['path']);resolved=claim_group_bases[row['group']]+row['path'];safe_path(resolved)
        normalized_claim.append(dict(group=row['group'],declared_relative_path=row['path'],resolved_package_path=resolved,sha256=row['sha256']))
    assert collections.Counter((r['path'],r['sha256']) for r in declarations)==collections.Counter((r['resolved_package_path'],r['sha256']) for r in normalized_claim) and hc['count']==len(hc['checks'])==34 and hc['candidate_package_manifest_sha256']==sha256(cb)
    np=json.loads(new[profile]);op=json.loads(old[profile]);ep=copy.deepcopy(op);ep['protocol_revision']='2026-10-12-r38';ep['control_file_hashes']['student-testing-contract.txt']=sha256(new[contract]);assert ep==np
    # Admit and execute only the exact previously published validator, after the complete script was read.
    vp=ROOT/'d015-clean-r36-20261012/work/quick_validate.py';vb=vp.read_bytes();assert sha256(vb)=='6fe29dd01a30abac05ef2999cdf8b962cd065cb23b5f7631981ab15544215efb'
    archive_path='runs/y1-reader-20261008/iterations/015/published-r36-20261012/evidence/author-original-inputs-and-state.zip';ae,ab=git.blob(tree,archive_path);assert sha256(ab)=='ff5284f0d72d7ea87bb71395662d680052a121ff2c2bf136b57c67341215d99e'
    with zipfile.ZipFile(io.BytesIO(ab)) as z:
        info=z.getinfo('work/quick_validate.py');published_validator=z.read(info);assert published_validator==vb and len(vb)==info.file_size==3390 and zlib.crc32(vb)&0xffffffff==info.CRC
    command=['python','-B',str(vp),str(CANDIDATE)];run=subprocess.run(command,capture_output=True,text=True);assert run.returncode==0 and run.stdout=='Skill is valid!\n' and run.stderr==''
    validator=dict(command=command,returncode=run.returncode,stdout=run.stdout,stderr=run.stderr,validator_path=str(vp.relative_to(ROOT)),validator_bytes=len(vb),validator_sha256=sha256(vb),actual_current_git_archive_path=archive_path,actual_current_git_archive_blob=ae['oid'],actual_current_git_archive_sha256=sha256(ab),actual_archive_member='work/quick_validate.py',exact_published_member_equals_executed_validator=True,complete_validator_script_read_before_execution=True,scope='Minimal SKILL.md YAML frontmatter existence/shape, allowed keys, required name/description and their lexical/length constraints only; no teaching-quality or semantic-repair certification.',publisher_receipt_separately_recorded=True)
    write_json(OUT/'validator-result.json',validator)
    for path in files:assert files[path].read_bytes()==new[path] and provisional_files[path].read_bytes()==provisional[path]
    for path,data in input_data.items():assert Path(path).read_bytes()==data
    assert vp.read_bytes()==vb
    git.close()
    actual_diff=''.join(diff).encode();existing=OUT/'actual-r37-to-candidate-r38.diff';assert existing.read_bytes()==actual_diff
    scope=dict(status='ADMIT_CANDIDATE',review_scope='Complete independently reconstructed semantic diff; unchanged candidate content verified byte-for-byte against actual published r37.',substantive_locations=[dict(path='SKILL.md',location='T10 Technical verification table row',change='Adds explicit declared parameter domain, sign/order warrant, discriminating admissible zero/sign/boundary check and premise restrictions for general directional or comparison claims.'),dict(path=execution,location='Qualitative-summary verification paragraph',change='Makes consequential-claim verification auditable through exact wording/location, controlling relation, stated domain and a relevant discriminating case; requires restrictions before use and rechecking affected explanation/help under the active repair mode.')],findings=['The trigger is a consequential general directional/comparison interpretation of a quantitative relation, consistent with the existing important-claims technical-verification duty.','The change permits an already established sign/order warrant and explicitly rejects unrelated edge-case catalogues or a new example for every sentence. It does not require new learner-facing examples universally.','It operationalizes an existing declared-domain/qualitative-summary check; it does not alter SASIS reader behavior or the baseline.','No lecture-specific answer, formula, numerical example, solution or D016 identifier is introduced. The integration-variable units example was already present.','No conflicting demand or overbroad new rule identified in the two changed prose locations.','The separate bounded scope reviewer examined the complete exact diff and independently reported no blocking scope defect.'],independent_scope_review=dict(agent='/root/technical_d126_prepared/d016_r38_scope_check',admitted_input='actual-r37-to-candidate-r38.diff',finding='No blocking semantic defect; narrow declared-domain/sign-order verification, no lecture-answer leakage, no compulsory new example per sentence, no conflicting demands.',limits='Diff scope only; byte identity and declarations verified by this parent audit.'),limits=['Candidate admission is not publication authorization.','The change does not itself prove the triggering teaching was repaired or re-audited; subsequent generation and full acceptance gates remain distinct.','No claim of learner outcome, technical-document acceptance, or full pedagogical effectiveness follows from the frontmatter validator.'])
    write_json(OUT/'semantic-scope-review.json',scope)
    counts=dict(candidate_files=36,candidate_bytes=908216,current_r37_files=36,current_r37_bytes=907146,changed_files=5,unchanged_files=31,substantive_prose_locations=2,metadata_only_files=3,internal_declarations=34,unique_internal_targets=22,unchanged_baseline_tree_files=len(baseline_paths),preserved_provisional_files=36,preserved_provisional_bytes=907146,provisional_metadata_changed_files=4,independent_frontmatter_validator_runs=1)
    identities_doc=dict(actual_file_identities=identities,actual_internal_declarations=declarations,publisher_internal_checklist_path_resolution=normalized_claim,external_historical_exclusions=exclusions,baseline_file_paths=baseline_paths,input_description_identities=[identity(Path(p),b) for p,b in input_data.items()],actual_git_object_identities=git.objects)
    write_json(OUT/'byte-identities.json',identities_doc)
    report=dict(status='ADMIT_CANDIDATE',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate='2026-10-12-r38',candidate_directory=str(CANDIDATE.relative_to(ROOT)),current_actual_git_commit=TARGET,current_actual_git_tree=tree,current_package='2026-10-12-r37',counts=counts,checks=dict(all_candidate_file_sizes_sha256_and_computed_git_blob_ids_match_actual_bytes=True,operative_r37_manifest_matches_actual_current_git_blobs=True,all_five_changed_files_accounted_by_exact_substitutions=True,all_31_other_files_exactly_unchanged=True,only_two_substantive_prose_locations_changed=True,revision_metadata_and_dependent_contract_hash_consistent=True,all_34_internal_declarations_reconstructed_and_match_actual_candidate=True,entire_bundled_baseline_tree_byte_unchanged=True,full_common_baseline_247840_bytes_sha256_pin_unchanged=True,provisional_metadata_only_candidate_preserved_with_exact_old_description_bytes=True,provisional_candidate_equals_only_metadata_updates_to_actual_r37=True,all_candidate_provisional_and_input_files_reread_unchanged=True,complete_semantic_diff_review_passed=True,exact_published_frontmatter_validator_admitted_and_independent_run_passed=True),semantic_review='semantic-scope-review.json',harness_correction='initial-audit-attempt.json (explicit group-relative checklist path resolution; no candidate bytes changed)',validator_result='validator-result.json',exact_diff='actual-r37-to-candidate-r38.diff',candidate_description_sha256=sha256(cb),provenance=dict(actual_git_access='git cat-file --batch binary object bytes with independently recomputed Git SHA-1 and SHA-256; exact current teaching pin and immediate parent header only.',fetch='Authorized git fetch origin main completed without reported movement from current teaching pin.',working_tree_index_reset_clean_checkout=False,browser=False,published=False,teaching_or_reader_content_reinterpreted=False),limits=scope['limits']+['Historical external package references remain excluded from the 34 current package-local hash assertions.','The preserved metadata-only r38 candidate is historical, not the current substantive candidate.','The validator checks minimal frontmatter only; substantive scope admission rests on the complete diff review, not its success message.'])
    write_json(OUT/'report.json',report)
    names=['verify_candidate_admission.py','initial-audit-attempt.json','actual-r37-to-candidate-r38.diff','validator-result.json','semantic-scope-review.json','byte-identities.json','report.json'];payload=[]
    for name in names:
        b=(OUT/name).read_bytes();payload.append(dict(path=name,bytes=len(b),sha256=sha256(b)))
    (OUT/'CHECKSUMS.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in payload))
    seal=dict(status='ADMIT_CANDIDATE',candidate='2026-10-12-r38',actual_r37_commit=TARGET,candidate_description_sha256=sha256(cb),counts=counts,payloads=payload,checksum_file='CHECKSUMS.sha256',checksum_sha256=sha256((OUT/'CHECKSUMS.sha256').read_bytes()),published=False,publication_authorized_by_this_audit=False)
    write_json(OUT/'SEAL.json',seal)
    for row in seal['payloads']:
        b=(OUT/row['path']).read_bytes();assert len(b)==row['bytes'] and sha256(b)==row['sha256']
    print(json.dumps(dict(status='ADMIT_CANDIDATE',counts=counts,outputs=[identity(OUT/name,(OUT/name).read_bytes()) for name in ['report.json','semantic-scope-review.json','validator-result.json','byte-identities.json','CHECKSUMS.sha256','SEAL.json']]),indent=2))

if __name__=='__main__':main()
