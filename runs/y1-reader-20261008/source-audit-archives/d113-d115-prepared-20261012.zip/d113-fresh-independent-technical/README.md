# D113 independent technical preparation

This dossier was prepared from the assigned original D113 sources and the full frozen student baseline only. It is independent technical preparation for a later comparison. It is not a teaching document, an authoring assessment, acceptance, or a SASIS conclusion.

Author role: `/root/technical_d113_prepared`. Preparation date: 2026-10-12. No current or installed PROF skill, candidate teaching, prior report, queue, other case, other agent's findings, browser content, or GitHub content was read. No GitHub mutation was performed. Subject claims below are limited to the permitted inputs and deductions stated here.

The source identity assigns all 28 pages of the Chapter 8 reading, all 31 presentation pages, and all 8 PRS pages: 67 page texts and 67 page images. Every page text was actually read and every image was actually inspected using `view_image` with `detail: original`. The 247840-byte student baseline was actually read completely in 15 bounded LF-line intervals, including Mathematics, the Further Mathematics Pure Core and both selected Statistics and Mechanics options, Physics, and Chemistry. Hashing is separate integrity evidence; it is not the basis of the semantic-coverage claim.

Evidence files:

- `baseline-read-log.json`: exact successful line and byte intervals, baseline hash, recovery of two truncated attempts.
- `identity-read-log.json`: full source-identity reading and recovery boundaries.
- `source-read-view-log.json`: per-page successful read/view groups, hashes, original dimensions, and recovered image-output truncation.
- `source-integrity.json`: independent byte/hash comparison against the source identity.
- `source-coverage.md`: semantic and visual observations for all 67 assigned pages.
- `technical-calculations.md`: independently reconstructed laws, worked examples, every conceptual question, all eight end problems, all four PRS questions, units and signs.
- `baseline-to-demands.md`: existing premises, explicit extensions and missing bridges, including absent Experiment 5 instructions.
- `calculation-check.json`: arithmetic evaluations, without treating numerical checks as source reading.
- `SHA256SUMS` and `SEAL.json`: a closed manifest and its digest. The seal does not hash itself.

References in the notes use PDF page numbers, not the reading's inconsistent printed chapter/footer numbering. `R` is the 28-page reading; `P` the 31-page presentation; `Q` the 8-page PRS file. The exact original paths and hashes are recorded in the machine-readable evidence. URLs in the original identity were not visited.

Limits: the supplied materials announce Experiment 5 and display static images of demonstrations/animations. No Experiment 5 manual, instrument specification, raw observations, animation playback, lecture speech, or substantive exam-review handout is supplied. None is reconstructed as an observed source. Current empirical claims are not verified externally; historical numerical values and the course's idealized field models retain that scope. No subsequent teaching generation was inspected or accepted.
