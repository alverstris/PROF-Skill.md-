"""Build integrity evidence from permitted originals and independently recorded reads.

The read/view assertions describe completed model operations, not this script's
hashing. Running this script alone does not perform semantic reading or viewing.
"""
from pathlib import Path
import hashlib
import json
import math
import struct

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
SOURCE = ROOT / 'original-inputs/D113'
OUT = ROOT / 'd113-fresh-independent-technical'
BASELINE = ROOT / 'd013-clean-r34-20261012/inputs/student-baseline.txt'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

identity = json.loads((SOURCE / 'source-identity.json').read_text())
text_groups = {
    'reading': [(1,8),(9,16),(17,24),(25,28)],
    'presentation': [(1,31)],
    'prs': [(1,8)],
}
view_groups = {
    'reading': [(1,4),(5,8),(9,12),(13,16),(17,20),(21,24),(25,28)],
    'presentation': [(1,5),(6,8),(9,11),(12,14),(15,17),(18,20),(21,23),(24,26),(27,29),(30,31)],
    'prs': [(1,3),(4,6),(7,8)],
}

def group_for(groups, page):
    return next(list(g) for g in groups if g[0] <= page <= g[1])

integrity = {'scope': 'Assigned originals plus baseline only', 'identity_sha256': digest(SOURCE / 'source-identity.json'), 'assets': []}
readlog = {
    'agent': '/root/technical_d113_prepared',
    'date': '2026-10-12',
    'assertion_basis': 'Actual complete tool-output reading and original-resolution visual inspection by this agent; distinct from later file hashing.',
    'numbering': 'PDF page numbers, not printed footers',
    'text_method': 'exec_command printed full page TXT files, output actually read',
    'image_method': 'view_image(detail=original) and image(..., original), full page actually inspected',
    'text_groups': text_groups,
    'successful_view_groups': view_groups,
    'truncated_image_attempts': [{'role':'presentation','pages':[6,7,8,9,10], 'tool_result':'Output exceeded the available model context and was truncated', 'counted_as_inspected':False, 'recovery_complete_view_groups':[[6,8],[9,11]]}],
    'additional_inspections': [
        {'role':'reading','pages':[25,26,27],'kind':'second original-resolution image inspection','purpose':'Check problem geometry, labels and directions before recording derivations'},
        {'role':'reading','pages':[24],'kind':'second original-resolution image inspection','purpose':'Confirm the printed acceleration exponent directly in the original image'},
        {'role':'reading','pages':[24],'kind':'second complete page TXT read','purpose':'Check problem data and wording'},
        {'role':'reading','pages':[20,21,22,23],'kind':'targeted TXT heading search','purpose':'Check exact solved-problem section numbers; not counted as full reading'},
    ],
    'pages':[],
}
checks = []
for asset in identity['assets']:
    pdf = SOURCE / asset['local_pdf']
    actual_pdf_sha = digest(pdf)
    row = {'role':asset['role'], 'path':str(pdf.relative_to(ROOT)), 'bytes':pdf.stat().st_size, 'sha256':actual_pdf_sha, 'identity_sha256':asset['sha256'], 'sha_matches':actual_pdf_sha==asset['sha256'], 'bytes_match':pdf.stat().st_size==asset['bytes'], 'assigned_pages':asset['required_pdf_pages'], 'page_derivatives':[]}
    checks += [row['sha_matches'], row['bytes_match']]
    for p in asset['page_derivatives']:
        txt, png = SOURCE / p['text_file'], SOURCE / p['image_file']
        txt_data, png_data = txt.read_bytes(), png.read_bytes()
        txthash, pnghash = hashlib.sha256(txt_data).hexdigest(), hashlib.sha256(png_data).hexdigest()
        dimensions = list(struct.unpack('>II', png_data[16:24]))
        comparison = {'page':p['page'], 'text_file':p['text_file'], 'text_bytes':len(txt_data), 'text_sha256':txthash, 'text_sha_matches':txthash==p['text_sha256'], 'image_file':p['image_file'], 'image_bytes':len(png_data), 'image_sha256':pnghash, 'image_sha_matches':pnghash==p['image_sha256'], 'image_dimensions':dimensions, 'dimensions_match':dimensions==p['image_dimensions']}
        row['page_derivatives'].append(comparison)
        checks += [comparison['text_sha_matches'], comparison['image_sha_matches'], comparison['dimensions_match']]
        readlog['pages'].append({
            'role':asset['role'], 'pdf_page':p['page'],
            'text':{'path':str(txt.relative_to(ROOT)), 'byte_interval':[0,len(txt_data)], 'interval_convention':'start inclusive, end exclusive', 'full_actual_read':True, 'successful_group':group_for(text_groups[asset['role']],p['page']), 'sha256':txthash},
            'image':{'path':str(png.relative_to(ROOT)), 'full_actual_view':True, 'detail':'original', 'dimensions':dimensions, 'successful_group':group_for(view_groups[asset['role']],p['page']), 'sha256':pnghash},
        })
    integrity['assets'].append(row)

baseline_bytes = BASELINE.read_bytes()
integrity['baseline'] = {'path':str(BASELINE.relative_to(ROOT)), 'bytes':len(baseline_bytes), 'sha256':hashlib.sha256(baseline_bytes).hexdigest(), 'expected_sha256':'3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'}
integrity['baseline']['matches_required_identity'] = len(baseline_bytes)==247840 and integrity['baseline']['sha256']==integrity['baseline']['expected_sha256']
checks.append(integrity['baseline']['matches_required_identity'])
integrity['all_integrity_comparisons_match'] = all(checks)
readlog['completed_page_texts'] = len(readlog['pages'])
readlog['completed_original_image_views'] = len(readlog['pages'])
readlog['semantic_notes'] = 'source-coverage.md'
save('source-integrity.json', integrity)
save('source-read-view-log.json', readlog)

e=1.60e-19
me=9.11e-31
K=12000*e
B=5e-5
v=math.sqrt(2*K/me)
r=me*v/(e*B)
L=.20
current_density=8.9e3*9.8/(.5e-4)
save('calculation-check.json',{
    'purpose':'Arithmetic evaluation of independently derived expressions; not semantic source-reading evidence',
    'constants':{'e_C':e,'electron_mass_kg':me,'g_m_s2':9.8},
    '8.11.1':{'energy_J':K,'speed_m_s':v,'acceleration_m_s2':e*v*B/me,'radius_m':r,'small_deflection_m':L*L/(2*r),'exact_deflection_for_forward_displacement_m':r-math.sqrt(r*r-L*L),'exact_deflection_for_pathlength_m':r*(1-math.cos(L/r))},
    '8.11.2':{'current_A':.05*9.8*math.tan(math.radians(20))/(2*.1*.05),'total_upward_pivot_reaction_N':.05*9.8},
    '8.11.7':{'force_N':7*.2*.1*math.sin(math.radians(20)),'max_force_N':7*.2*.1},
    '8.11.8':{'current_density_A_m2':current_density,'heating_W_m3':current_density**2*1.7e-8,'heating_W_cm3':current_density**2*1.7e-8/1e6},
})
print(json.dumps({'page_texts':readlog['completed_page_texts'],'page_views':readlog['completed_original_image_views'],'integrity_matches':integrity['all_integrity_comparisons_match']}))
