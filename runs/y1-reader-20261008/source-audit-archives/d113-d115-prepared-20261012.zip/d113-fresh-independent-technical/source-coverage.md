# Page-by-page source coverage

These are observations following actual complete text reads and full-resolution views, not inferred contents from filenames or hashes. Every row covers the complete assigned page; short title pages and repeated slides remain separate inspected pages. All equations use clarified notation where extracted TXT confused letters, vectors, or length symbols.

## Reading: Chapter 8, PDF pages 1–28

| Page | Observed content and visual check |
|---|---|
| R1 | Contents through §8.11.8, establishing the entire chapter's scope, including worked examples, conceptual questions and problems. |
| R2 | Compass response, N/S poles, attraction/repulsion, dipole after cutting. Pole/compass drawings agree with external field directed away from N and towards S. |
| R3 | Experimental magnetic-force properties and vector law q(v×B). Positive-charge hand/vector picture gives the perpendicular direction; negative charge reverses it. A magnitude requires absolute charge. |
| R4 | Magnitude, tesla/gauss conversion, no-work dot product. Wire photographs/sketches show field out of page: downward current gives left force; upward current gives right force. |
| R5 | Carrier-count derivation of wire force, current and differential curved-wire law. PNG resolves length ℓ where TXT resembles A. Upward drift/current and field into the page give left force. |
| R6 | Integral of directed wire elements, uniform-field endpoint rule, zero total force on a closed loop. Semicircular example begins with a directed path. |
| R7 | Upper semicircle, counterclockwise current and field +y: straight diameter current +x gives +z force; arc gives −z. Parameter θ runs 0 to π along the arc. Forces cancel. |
| R8 | Rectangular current loop with field +x. Top/bottom segments parallel B have zero force; left/right carry opposing out/in-of-page forces. Their torques add in +y. |
| R9 | Area normal, current right-hand orientation, general tilted rectangle, N-turn torque and magnetic moment. θ in the diagram is angle between area normal and B; the phrase angle with the loop must not replace this. |
| R10 | μ=NIA, A m² units, τ=μ×B and energy −μ·B by angular work. Diagram's parallel orientation is stable, antiparallel unstable, under the stated dipole model. |
| R11 | Nonuniform field, aligned dipole drawn on axial side of bar magnet: B points +x and decreases with x, so force points −x. Supplies 1D derivative force and introduces gradient notation. |
| R12 | Definition of ∇ by partial-derivative components. Boston dip needle illustration, Earth field downward and northward; restoring torque and oscillation narrative. Static illustration was viewed; linked animation was not played. |
| R13 | Global dipole/needle interaction and qualitative angular-momentum transfer. Introduction of positive charged-particle motion perpendicular to uniform B. |
| R14 | Circular orbit with B into page, positive q and counterclockwise motion. Radius, period and angular frequency derived. Helix drawing combines parallel advance and perpendicular circle. |
| R15 | Static animation image for moving charge entering magnetic region; moving-charge self-field expression and field stress/momentum narrative. No animation timing or numerical stress model is supplied. |
| R16 | Lorentz law, electron acceleration through potential difference, Thomson apparatus. In selector, electron travels right, E points down, B into page: electric force up and magnetic force down. Work/potential-energy wording requires sign clarification. |
| R17 | Thomson e/m result and course historical numerical value. Bainbridge selector/analyzer diagram: positive ion travels upward through E right/B into page, then turns left in analyzer B₀ into page. |
| R18 | Summary of charged-particle/wire forces, differential force, loop moment/torque and dipole energy. Summary uses single-turn form; N-turn extension is on R9–10. |
| R19 | Summary of positive radius/frequency with |q| and Cartesian cross-product recipe; expanded Lorentz components. Signs match the component formula. |
| R20 | Rolling rod on rails: B into page, current across rod, translation along rails. Supplies rotational kinetic energy and solid-cylinder inertia. Stem says without slipping; solution's phrase with slipping conflicts with its own v=Rω. |
| R21 | Rolling speed result and suspended horizontal rod. Suspended-rod drawing: field out of page, leftward current gives upward magnetic force. |
| R22 | Suspension balance and mass-ratio example: same accelerating voltage, charges q and 2q, radii R and 2R. Ratios imply mA/mB=1/8. |
| R23 | Ring over magnet's north pole. Diagram shows clockwise current viewed from above, and B tilted outward from vertical by θ. Horizontal radial force components cancel, vertical force adds upward. |
| R24 | All five conceptual questions; television electron-beam problem; start of hinged square-loop problem. TV answer's 10⁻¹⁵ m/s² is visibly printed, not merely OCR, and is incompatible with the supplied data. |
| R25 | Hinged-loop diagram and parts (a)–(e), θ from the downward vertical; current/torque/equilibrium/support demands. Sliding inclined bar: vertical upward B, width ℓ visible although the text's length symbol is absent; mass not specified. |
| R26 | Negative particle enters plate gap to right, B into page, plate separation d and finite length l. Downward circular deflection. Second problem: positive-x entry into right-half-plane field out of page, two downward semicircles with radius ratio 2. |
| R27 | Remaining orbit questions; teardrop loop consists of lower semicircle plus isosceles triangle, clockwise current and B right. Wire-force problem gives 0.2 m, 7 A, 0.1 T and 20°. |
| R28 | East–west copper wire at equator, northward Earth field, support by magnetic force. Given mass density, resistivity and g; asks current density and heat per second per cm³. All conversions and diameter cancellation are material. |

## Presentation, PDF pages 1–31

| Page | Observed content and visual check |
|---|---|
| P1 | Session outline: magnetic fields/Experiment 5, then moving charges and exam review. No detailed experiment or review instructions. |
| P2 | New-topic title: magnetic fields. |
| P3 | Gravity/electric create-versus-feel comparison, point-source fields, electric dipole field picture and τ=p×E. Dipole torque is displayed but not independently explained there. |
| P4 | Bar magnets: like poles repel, unlike attract, shown as three magnet pairs. |
| P5 | Demonstration title: magnetic field lines from bar magnet. No procedure/data. |
| P6 | Demonstration title: compass in bar-magnet field. No procedure/data. |
| P7 | Compass arrows follow external bar-magnet field N→S; statement that lines leave N and end at S is an external-field description, not literal endpoints within a magnet. |
| P8 | Dipole creation/alignment, cut magnet becomes two dipoles; isolated-monopole statement. |
| P9 | Repeats P8 as a separately supplied page; same diagram and content inspected. |
| P10 | Electric charge separation versus cut magnet; electric and magnetic Gauss surface integrals shown, with zero closed magnetic flux. Closed surface/area orientation and integral meaning are not taught on this slide. |
| P11 | Comparative gravity/electric/magnetic table: no magnetic monopole source, dipole field, and magnetic torque μ×B. |
| P12 | Question-only transition: what else is magnetic? |
| P13 | Earth dipole picture, S near geographic north/N near geographic south. Terminology is physical magnet pole polarity; avoid conflating it with geographic naming. |
| P14 | Earth field at MIT diagram with geocentric x,z and local r,θ directions; arrows resolve B into components. No component magnitudes or measurement recipe. Local B is downward into Earth and toward north. |
| P15 | Experiment 5 title: bar magnet and Earth's field. No laboratory manual embedded. |
| P16 | Static visualization screenshot and external animation link. Only the pictured field structure was observed, not moving behavior or an apparatus procedure. |
| P17 | Dipole creates field and tends to align; transition asks what else creates/feels B. |
| P18 | TV-in-field demonstration title only. |
| P19 | Positive/negative charges bend oppositely; F=q(v×B), perpendicular to both v and B. Vector/perspective diagrams agree. |
| P20 | Tesla definition N/(A m)=N/(C m/s) and 1 T=10⁴ G. |
| P21 | Cross-product recall title. |
| P22 | Dots mean out of page, crosses into page, using arrowhead/tail analogy. |
| P23 | Cross magnitude AB sinθ and parallelogram area; diagram shows height B sinθ. |
| P24 | Curl right-hand fingers from first to second vector through smaller angle; thumb gives product. Static hand/vector image and link; no animation playback. |
| P25 | Cyclic Cartesian basis products and reversed sign. Bottom equations visually overlap; k×i=j and i×k=−j follow the other displayed identities and baseline component formula. |
| P26 | PRS right-hand-rule transition title. |
| P27 | Lorentz electromagnetic force q(E+v×B). Closing wording about the final force law is limited to electromagnetic force, not an exclusion of weight/contact forces. |
| P28 | Velocity-selector question: v right, E down, B into page. Slit and plates depicted. |
| P29 | Same selector with positive test charge: magnetic up/electric down; straight passage when v=E/B. Charge magnitude cancels; reversing sign reverses both forces. |
| P30 | Hall-effect PRS transition title, with substantive question in Q7–8. |
| P31 | Exam-review title only. No review questions or new content beneath it. |

## PRS, PDF pages 1–8

| Page | Observed content and independent check |
|---|---|
| Q1 | Positive q, v right, B down. With x right/y up/z out, x×(−y)=−z: option 5, into page. |
| Q2 | Supplied answer into page agrees. Its thumb-v/fingers-B/palm-force mnemonic is different from P24's curl/thumb mnemonic; do not combine finger assignments between them. |
| Q3 | Positive q, v right, B up. x×y=z: option 6, out of page. |
| Q4 | Supplied answer out of page agrees. |
| Q5 | Positive q, v left, B dot out of page. (−x)×z=+y: option 1, up. |
| Q6 | Supplied answer up agrees. |
| Q7 | Hall slab: conventional I right, B out, bottom at higher potential. Carrier-sign question; actual diagram resolves the dot and bottom label missing from simple TXT order. |
| Q8 | Answer positive carriers. For either sign, qv is right and magnetic force down; the observed positive bottom accumulation distinguishes positive carriers. Balance with upward Hall electric field verifies the sign. |
