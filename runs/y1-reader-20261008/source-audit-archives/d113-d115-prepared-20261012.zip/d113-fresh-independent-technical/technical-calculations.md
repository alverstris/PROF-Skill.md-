# Independent calculations and sign checks

Only the original sources and supplied baseline are used. Source solutions were read as part of the assignment, but every result below is checked from stated equations and diagram geometry. A supplied numerical answer is not treated as proof. Unless a problem supplies another value, arithmetic checks use baseline e=1.60×10⁻¹⁹ C, mₑ=9.11×10⁻³¹ kg and the problem's g=9.8 m/s² where specified. Charge q is signed in vector laws; |q| is used for positive magnitudes.

## Common mathematical and physical reconstruction

Choose a right-handed Cartesian basis. For ordinary page diagrams take x right, y up and z out of page. The baseline component formula gives i×j=k, j×k=i, k×i=j; interchanging inputs changes sign. Thus |v×B|=vB sinθ, with 0≤θ≤π, can be checked by placing v along x and resolving B into parallel x and perpendicular y components. The parallelogram area is base v times height B sinθ. At θ=0 or π the product is zero and no product direction exists.

R3–4 supplies F_B=q(v×B), hence |F_B|=|q|vB sinθ. Dotting with v gives F_B·v=0. Using the baseline power/work-energy relation gives dK/dt=0 for a particle acted on only by this magnetic force. Direction can change while speed stays fixed; no-work does not imply zero acceleration. The force unit check gives [B]=N/(C m s⁻¹)=N/(A m), since C=A s. One gauss is 10⁻⁴ T.

For one mobile species of charge q, number density n, and drift vector v_d, current along a directed length is represented by n q A v_d; the q sign and drift reversal combine to give conventional current. Summing carrier forces within length ℓ gives F=I ℓ_vector×B, where ℓ_vector points along conventional current. In a nonstraight wire a short segment gives dF=I dr×B. For constant I and uniform B, sum Cartesian increments: ∫dr=r_end−r_start, so F=I(r_end−r_start)×B. A closed path therefore has zero total force. This endpoint deduction needs only a componentwise integral, not assumed prior line-integral theory. Nonuniform B must remain inside the integral.

Torque is r×F, consistent in magnitude and sense with the baseline perpendicular-distance moment. For a planar current loop, the area vector A=A n is normal to its plane, with n fixed by curling right-hand fingers along conventional current. The two equal and opposite forces on a rectangle form a couple and produce τ=I A_vector×B. For N identical turns μ=NI A_vector, τ=μ×B. [μ]=A m²; [μB]=N m=J. θ in |τ|=μB sinθ is between μ and B, not between the loop plane and B. A zero resultant force can coexist with nonzero torque.

For a dipole of fixed μ rotated slowly, the external work for angular increase is ∫ μB sinθ dθ=μB(cosθ₀−cosθ). Setting U(π/2)=0 gives U=−μB cosθ=−μ·B. Parallel alignment is an energy minimum; antiparallel alignment is a maximum although both have zero instantaneous torque. Undamped dynamics can oscillate; “aligns” does not establish settling without dissipation. For fixed axial μ, a slow translation gives F_x=−dU/dx=μ dB/dx. R11's drawn field weakens with increasing x, so force points towards the magnet. General F=∇(μ·B) requires fixed-moment and spatial-derivative conventions; the supplied gradient symbol alone is not a baseline calculus method.

For a charged particle with velocity perpendicular to a uniform field, |q|vB=mv²/r gives r=mv/(|q|B), T=2πr/v=2πm/(|q|B), and angular-speed magnitude |q|B/m. Signs determine the rotational sense separately. Resolve a general initial velocity into v_parallel and v_perp: magnetic force has no parallel component, so parallel speed is constant, the perpendicular component circles with r=m v_perp/(|q|B), and one-turn advance is v_parallel T. A nondegenerate helix requires both components nonzero. Pure parallel motion is straight; pure perpendicular motion is circular.

The supplied Lorentz electromagnetic force is q(E+v×B). It does not include unrelated weight or contact forces. In the depicted perpendicular selector, v right/E down/B into page, positive-charge magnetic force is up and electric force down. Cancellation gives v=E/B independent of charge magnitude and sign. A sign reversal reverses both forces. Off-speed forces initially have sign q(vB−E) in the upward direction.

Thomson setup (R16–17): for an electron accelerated from rest through a positive increase ΔV in electric potential, ΔU=qΔV=−eΔV and ΔK=+eΔV. Therefore v²=2eΔV/m, and setting v=E/B yields e/m=E²/(2ΔVB²). The text's wording that equates ΔU to external work “done in accelerating” needs separation from actual field work: field work is −ΔU. R17's historical precision claim is not a current measurement assertion. In the Bainbridge analyzer, selected speed E/B and radius r=m v/(q B₀) for positive ions give m=q B₀ B r/E; analyzer B₀ and selector B are different fields. The depicted upward incoming velocity and into-page B₀ give a left turn, as drawn.

## Worked source examples

### Semicircle (R6–7)

The straight diameter runs from (−R,0) to (R,0) with current +x, so F_straight=2IRB k for B=B j. On the upper arc current runs from the right endpoint to the left. Parameterize r(θ)=R cosθ i+R sinθ j, 0≤θ≤π. Then dr=R(−sinθ i+cosθ j)dθ and dF=−IRB sinθ k dθ. Integration gives F_arc=−2IRB k. Net force is zero, consistent with the general closed-loop result. The curved length πR must not replace the vector endpoint displacement.

### Rectangular loop and tilt (R8–9)

With B along +x, vertical left side carries −y current and feels +z force IaB; right side carries +y current and feels −z force. Each has lever arm b/2 and both moments are +y, so τ=IabB j. Tilting the normal through θ relative to B reduces torque to IabB sinθ. The image's clockwise/anticlockwise description depends on viewing direction; the vector sign is the invariant statement.

### Rolling rod (R20–21, §8.9.1)

Use J for moment of inertia to avoid the source's I/current symbol collision. Magnetic force magnitude IℓB acts along rails over distance a, so its macroscopic work is IℓBa. Under the source's ideal model, ½mv²+½Jω²=IℓBa. With supplied J=mR²/2 and no-slip relation ω=v/R, total kinetic energy is ¾mv². Therefore v=√(4IℓBa/(3m)). The speed is independent of R in this solid-cylinder idealization. Units under the root are N m/kg=m²/s². The solution's phrase “with slipping” contradicts its no-slip relation and should read “without slipping.” Rotational kinetic energy and J are new supplied premises, not prior baseline facts. A maintained current and macroscopic wire force do not justify claiming that a static magnetic field creates energy or that its force on an individual charge does work; the electrical/mechanical system distinction is a required explanatory bridge.

### Suspended rod (R21–22, §8.9.2)

At zero support tension IℓB=mg=λℓg, so I=λg/B. In the source's out-of-page B, conventional current must run left: (−i)×k=+j gives upward force. The positive magnitude has units (kg/m)(m/s²)/T=A. A current in the opposite direction adds to the rod's weight.

### Accelerated particles (R22, §8.9.3)

For charge magnitude Q accelerated from rest through the same accelerating voltage magnitude ΔV, ½mv²=QΔV and r=mv/(QB), so r²=2mΔV/(QB²), or m/Q∝r². For A: Q=q,r=R. For B: Q=2q,r=2R. Therefore m_B/m_A=(2q/q)(2R/R)²=8, hence m_A/m_B=1/8. Merely assuming equal speeds would give the wrong mass ratio.

### Ring above a magnet (R23, §8.9.4)

Use cylindrical directions defined locally: r_hat outward in the ring plane, φ_hat counterclockwise seen from above, z_hat up. The drawn current is clockwise, so ds_vector=−ds φ_hat. The local field is B sinθ r_hat+B cosθ z_hat. With φ_hat×r_hat=−z_hat and φ_hat×z_hat=r_hat, dF=IB ds(sinθ z_hat−cosθ r_hat). Opposite radial contributions cancel around the circumference; vertical ones add. Thus F=2πrIB sinθ z_hat, upward and repulsive in the shown configuration. A new cylindrical-coordinate theory is unnecessary: these products can be checked with Cartesian vectors at opposite ring points. Reverse current reverses the total force.

## All five conceptual questions (R24)

1. A moving charged particle can have zero magnetic force if v is parallel or antiparallel to B, since v×B=0. A stationary charge is another limiting case, although it is not moving. Other forces are not excluded by this statement.
2. Force perpendicular to velocity changes its direction, hence acceleration, while preserving speed and kinetic energy. Circular motion is the uniform perpendicular-field example.
3. Electric force qE is independent of velocity; magnetic force q(v×B) is odd under velocity reversal and perpendicular to v. For the same location and opposite test velocities, [F(v)+F(−v)]/2=qE and [F(v)−F(−v)]/2=q(v×B), assuming those electromagnetic fields stay fixed. Electric force can do work; magnetic force alone cannot. One instantaneous trajectory/force does not necessarily identify both unknown fields uniquely.
4. A spatially nonuniform field can exert a net force on a dipole. It can be attractive or repulsive depending on moment direction and field gradient; “nonuniform” alone does not guarantee nonzero force at every point. R11's aligned dipole is attracted toward stronger field. Uniform B can still exert a torque.
5. Ideal compass dipole in uniform B has zero net magnetic force. Torque is μ×B, generally nonzero, but zero for parallel or antiparallel alignment (or vanishing μ/B). Parallel is stable and antiparallel unstable under this model.

## Every additional problem, §8.11

### 8.11.1 Television electron beam (R24)

Take x east, y north, z up. v=v j, B=−B k, so v×B=−vB i. Multiplying by electron charge −e gives eastward force and deflection. K=12000×1.60×10⁻¹⁹=1.92×10⁻¹⁵ J, hence v=√(2K/mₑ)=6.4924×10⁷ m/s. Acceleration magnitude evB/mₑ=5.7014×10¹⁴ m/s² and radius mₑv/(eB)=7.3932 m. The source's displayed acceleration of order 10⁻¹⁵ m/s² is an exponent error; it resembles the energy scale, not the acceleration.

For short forward travel L=0.20 m, t≈L/v and sideways deflection ≈½at²=L²/(2r)=0.00270517 m, about 2.7 mm east. Treating 0.20 m as the forward northward displacement gives exact circular sagitta r−√(r²−L²)=0.00270567 m. If it means path length instead, r[1−cos(L/r)]=0.00270501 m. Both support the same requested scale; specify the small-deflection approximation. This is the course's nonrelativistic calculation; no unprovided relativistic formula is silently substituted.

### 8.11.2 Hinged square loop (R24–25)

Use the standard uniform-wire, ideal freely rotating hinge model implicit in the four-segment hint. Let h point horizontally outward from the loop's vertical resting plane, a point along the hinge from A to A′ as drawn, and z point up, with h×a=z. The displaced side vector is ℓ(sinθ h−cosθ z). Field is −B z. Current A→A′ on the hinge makes the lower side current −a, giving outward lower-side force IℓB h. The hinge-side force is the opposite and has zero moment about its own axis. Forces on the two sloping sides are equal and opposite along the axis and have no moment about that axis. They are not each zero: their magnitude is IℓB sinθ.

The lower-side magnetic torque about the hinge is −Iℓ²B cosθ a. Gravity on the hinge segment has zero moment. For uniform wire each segment has mass m/4: the lower segment's horizontal lever arm is ℓ sinθ and each sloping segment's is (ℓ/2)sinθ. The sum is +(mgℓ/2)sinθ a. Thus equilibrium gives Iℓ²B cosθ=(mgℓ/2)sinθ and I=mg tanθ/(2ℓB).

Convert m=0.050 kg, ℓ=0.10 m, B=500 G=0.050 T. With g=9.8 m/s² and θ=20°, I=17.8345 A, consistent with the printed rough 20 A. Uniform-field magnetic forces sum to zero, so the combined pivot reaction on the supported assembly is upward mg=0.490 N. Under symmetric support each pivot carries mg/2; the assembly's force on its pivots is downward. The exact division would otherwise require the support geometry. The dipole route has μ=−Iℓ²(cosθ h+sinθ z), giving μ×(−Bz)=−Iℓ²Bcosθ a, the same magnetic torque. Uniform mass distribution and an ideal hinge must be stated, rather than inferred as an exact consequence of total mass alone.

### 8.11.3 Sliding bar on incline (R25)

Introduce m as the bar's mass because the source does not name or give it. Let x be horizontally uphill, z up, and y chosen so x×y=z. The slope's uphill tangent is t=cosθ x+sinθ z; its outward normal is n=−sinθ x+cosθ z. Choose current along +y, so Iℓ y×Bz=IℓB x has an uphill projection. Force balance along t gives IℓB cosθ=mg sinθ, hence I=mg tanθ/(Bℓ). The corresponding normal reaction is N=mg cosθ+IℓB sinθ=mg/cosθ. Magnetic force points horizontally uphill, not along the incline. The direction reverses if B reverses. No numerical current follows without m,B,ℓ,θ; the missing text length glyph is recoverable from diagram ℓ, whereas a numerical mass is not.

### 8.11.4 Negative particle between plates (R26)

Take x right/y up/z out. With v=+v i, B=−B k, and charge −q where q>0, initial F=−qvB j: downward. Introduce particle mass m, which is needed but not specified by the question. Radius r=mv/(qB). With entry at (0,0), the circle is x²+(y+r)²=r². On the lower plate y=−d/2 this gives x_hit=√(rd−d²/4), measured from the left end, if that point is reached before leaving the finite field region.

The finite length l makes a condition necessary. Parameterize x=r sinφ, y=−r(1−cosφ), starting at φ=0. A lower-plate intersection requires d≤4r and φ_hit=arccos(1−d/(2r))≤π. If d≤2r the hit is before the circle's rightmost point and requires x_hit≤l. If 2r<d≤4r the hit is after the rightmost point and requires l≥r; merely checking x_hit≤l would miss an earlier exit through the right boundary. For d>4r the particle returns through the left side without touching the lower plate. Boundary tangencies need the ideal edge convention. The source provides no values guaranteeing a strike, so the square-root expression is conditional, not a universally existing hit.

### 8.11.5 Orbits in the right half-plane (R26–27)

The field is +B k and initial velocity +v i, so v×B=−vB j. The pictured downward turn therefore means q>0. Equate radial magnetic force qvB to m₁v²/R₁, obtaining R₁=m₁v/(qB), explicitly deriving rather than quoting it. Since both charges and speeds match, R₂/R₁=m₂/m₁=2. Both can travel straight with E=+vB j in the field region: E+v×B=0. The compensating field is independent of mass.

### 8.11.6 Teardrop loop (R27)

The whole closed loop lies in uniform B, so F_net=I(∮dr)×B=0. Let x right/y up/z out of page. The visible current arrow goes upward on the lower-left arc, so traversal is clockwise and μ=−IA k. The area comprises a semicircle and an isosceles triangle: A=πR²/2+ℓ² sinθ/2. The geometry also constrains R=ℓ sin(θ/2); R,ℓ,θ are not independent. With B=B i, τ=−IAB j, downward in the page. Magnitude IB[πR²/2+ℓ² sinθ/2] has units N m. The equivalent triangle area Rℓ cos(θ/2) follows from base 2R and altitude ℓcos(θ/2).

### 8.11.7 Straight wire (R27)

F=IℓB sin20°=7.0×0.20×0.10×sin20°=0.0478828 N, about 0.048 N (source roughly 0.05 N). Direction is perpendicular to the plane of current and B, with sense ℓ_vector×B. An absolute compass/page direction is not specified by just an angle: one valid sketch convention takes I along +x and B tilted from +x toward +y by 20°, giving +z/out of page. Rotate the wire to 90° relative to B, holding length/current/field fixed, to obtain maximum 0.14 N.

### 8.11.8 Levitating copper wire and heating (R28)

Use east x/north y/up z. Current east gives x×y=z, so its force is upward in the supplied northward field. Let A=πd²/4, mass density ρ_m and electrical resistivity ρ_e. Per length, magnetic support is IB and weight is ρ_m A g. Hence J=I/A=ρ_m g/B=8.9×10³×9.8/(0.5×10⁻⁴)=1.7444×10⁹ A/m², directed east. Diameter cancels, although I=Jπd²/4 still depends on it.

For a segment length L, R_e=ρ_eL/A and P=I²R_e. Dividing by AL yields P/volume=ρ_e(I/A)²=ρ_eJ²=5.172983312×10¹⁰ W/m³. Since 1 m³=10⁶ cm³, this is 5.172983312×10⁴ W/cm³, about 5.2×10⁴ J per second per cm³. This is a heat-generation rate in the ideal given-resistivity model, not a supplied equilibrium temperature or evidence that the wire can operate indefinitely.

## All PRS questions, independent component route

| Question | Vector calculation | Choice and meaning |
|---|---|---|
| Q1–2 | q>0; v=v i, B=−B j ⇒ F=−qvB k | 5, into page |
| Q3–4 | q>0; v=v i, B=+B j ⇒ F=+qvB k | 6, out of page |
| Q5–6 | q>0; v=−v i, B=+B k ⇒ F=+qvB j | 1, up |
| Q7–8 | Conventional current +x and B +z give magnetic force down for either charge sign; observed bottom potential higher selects positive accumulating carriers | 1, positive |

For the Hall case, positive carriers move right and have F_B=qv(i×k)=−qvB j. Negative carriers move left, so v×B is upward but multiplication by their negative q again gives downward force. A high-potential bottom relative to top corresponds to an upward transverse electric field. For positive carriers its electric force is up and can balance the down magnetic force; negative carriers would instead accumulate negative charge at the bottom and give the opposite voltage sign. This is the simple single-sign carrier model of the supplied question. The two reversals in the negative-carrier case must both be retained. No semiconductor band theory, multi-carrier Hall model, or unprovided instrument reading is needed.
