# D114 independent original-source technical dossier

Prepared by `/root/technical_d114_prepared` on 2026-10-12. This is a technical preparation record, not a teaching document, authoring output, acceptance decision, or SASIS claim.

The only subject inputs consulted were `original-inputs/D114/**` and the entire specified student baseline. No current or installed PROF, teaching output, previous report, other case, queue, other agent's semantic findings, live website, or GitHub content was consulted. No GitHub mutation was performed. Reports are intended for the parent's Git-backed evidence workflow.

The source identity was actually read in five complete byte intervals after an initial truncated attempt was excluded. All 61 assigned page texts were actually read, and all 61 full-resolution page PNGs were actually inspected using `view_image` with `detail="original"`. One image-output batch was truncated; its four pages were recovered individually. The 247,840-byte baseline was actually read in 16 contiguous decoded-character intervals, with corresponding exact byte intervals retained. Its SHA-256 is `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`.

Hashes establish file identity only. They do not establish semantic or visual reading. `read-log.json` records actual reads/views separately; `source-manifest.json` records file identity and verification. No claim is made to have read the unassigned portions of the 69-page Chapter 9 PDF.

## Assignment boundary

| Asset | Actual assigned inspection |
|---|---|
| Presentation `presentati_w06d2` | All 33 pages, text and original-resolution image |
| PRS `prs_w06d2` | All 16 pages, text and original-resolution image |
| Chapter 9 reading | PDF pages 3–14, sections 9.1–9.2; assignment begins at 9.1 and ends before 9.3 on PDF page 14 |

The whole p14 text and image were inspected to establish its boundary; the visible beginning of section 9.3 is excluded from assigned semantic scope. References to Chapter 8, other sections, lab manuals, demonstrations, and animation URLs are source references, not evidence that those materials were supplied or consulted.

## Contents

- `source-coverage.md`: page-by-page semantic/visual coverage and source limitations.
- `calculations.md`: independent derivations of the lecture, reading, and every PRS problem, including sign, dimensional, and diagram checks.
- `baseline-to-demands.md`: supplied baseline capabilities and bridges demanded by these sources.
- `read-log.json`: actual interval/page read/view records, hashes, dimensions, and truncation recovery.
- `source-manifest.json`: original PDFs, assigned derivatives, identity, and baseline provenance.
- `SHA256SUMS` and `SEAL.json`: fixed dossier integrity records.

Semantic findings were kept inside this dossier during preparation. Only provenance/count updates and the final opaque seal may be sent to the parent until the parent announces that fresh whole teaching has been frozen. Completion of preparation does not initiate another stage.
