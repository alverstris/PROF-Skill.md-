# Independent calculations and technical checks

All derivations below use only the assigned D114 originals and the fully read student baseline. They are a preparer's checks, not a teaching generation. The source's permeability convention is retained: `μ0=4π×10⁻⁷ T m A⁻¹`. No current-metrology claim is needed or made.

## 1. Coordinates, units, and two distinct uses of magnetic field

For a flat page use i right, j up, k out. Then `i×j=k`, `j×k=i`, `k×i=j`; reverse the order to negate. In a Biot–Savart calculation, `r=rP−rsource` points from the source element to the observation point. Thus

`dB = (μ0 I/4π)(ds×rhat)/r² = (μ0 I/4π)(ds×r)/r³`.

Using r in the numerator with r² in the denominator would introduce a length error. A source first creates B; the separate target then experiences `q v×B` or `I L×B`. Reversing q, current, or one cross-product factor reverses that factor's contribution. The target's own field is not inserted as an external force field here.

Dimensional checks:

- `[qvB]=(A s)(m/s)(T)=A m T=N`.
- `[ILB]=A m T=N`.
- `[μ0 I ds/r²]=(T m/A) A m/m²=T`.
- `[μ0 qv/r²]=(T m/A)(A s)(m/s)/m²=T`.
- `[μ0 I/R]=T`; `[μ0 I1 I2/a]=N/m`.

The baseline grants the component cross product, not all its geometric interpretations. The magnitude factor can be derived by resolving one vector into components parallel and perpendicular to the other: the parallel part has zero cross product; the perpendicular part gives magnitude `ab sinθ`. This makes explicit why collinear elements vanish and perpendicular ones have the largest magnitude.

## 2. Charge motion and the current-force bridge

Presentation p5: a positive charge moving right in B into the page has `v×B=i×(−k)=+j`; force is upward. The circle is counterclockwise as drawn. With uniform static B, perpendicular velocity, no other force and nonrelativistic mechanics,

`|q| v B = m v²/r`, so `r=mv/(|q|B)`, `T=2πr/v=2πm/(|q|B)`, and the angular-speed magnitude is `ω=|q|B/m`.

The slide's q expressions are valid for its positive charge. Negative q reverses the turning sense but does not make the radius or period negative. For general velocity, only v perpendicular to B enters the radius; the along-field component is unaffected by magnetic force. This qualification is not needed to solve the pictured perpendicular case. Because `(v×B)·v=0`, magnetic force does no work, consistently preserving speed in the pictured model.

Presentation p7: consider n carriers per volume, signed charge q, cross-section A and wire length L. There are `N=nAL` carriers. Summing carrier forces gives `F=Nq vd×B`. Conventional current includes the sign of q relative to carrier drift: the vector transport factor is `I Lvector = nAL q vd`. Hence `F=I Lvector×B`. For negative carriers, reversing both carrier-charge sign and drift direction preserves conventional-current direction. In a curved conductor or varying B, use `dF=I ds×B` and sum; `I L×B` requires a straight segment in effectively uniform B.

Presentation p9: upward I and into-page B give `j×(−k)=−i`, left. Downward I gives right. Zero I gives zero magnetic force. Mechanical supports and gravity are not thereby declared absent; these are magnetic-force predictions.

## 3. PRS predictions 1–5: original geometries

The diagrams establish the local field; the entire bar-magnet field must not be replaced by one uniform direction.

| PRS question | Calculation | Result |
|---|---|---|
| Prediction 1, p1 | Above north pole B is upward: `(+i)×(+j)=+k`. | Out of screen, option 6. |
| Prediction 2, p3 | In front at the equatorial side the external field runs down: `(+i)×(−j)=−k`. | Into screen, option 5. |
| Prediction 3, p5 | Behind at the same equatorial region B is also down, despite the front/back displacement: `(+i)×(−j)=−k`. | Into screen, option 5. |

Prediction 4, p7: the loop is above north and the field fans outward as well as upward. Let h be the vertical axis, er horizontal radial outward, and eφ the tangent sense shown, which is rightward at the front. On a ring of radius R,

`ds=R dφ eφ`, `B=Br er+Bh eh`, and `dF=IR dφ(Bh er−Br eh)`.

The horizontal terms cancel around the symmetric loop; the vertical terms add. Thus `Fh=−2πIR Br`, downward for the outward radial component above north. Option 2. Equivalently, at the right side ds points into the page, so its radial-field force is down; at the left side both current and radial field reverse, leaving another downward force. Using only Bh would give zero total vertical force and fail to solve this question.

Prediction 5, p9 reverses every ds with the same magnet field, so every magnetic-force contribution reverses. The loop moves upward, option 1. These predictions do not require inventing a field-strength value or treating a larger nonuniform loop as a point dipole.

## 4. Finite straight wire, long-wire limit, and the source's angle error

Reading Example 9.1: take the wire on x, positive current along +i, observation point `(0,a,0)` with a>0, and endpoints xL<xR. At source coordinate x,

`ds=dx i`, `r=−x i+a j`, `ds×r=a dx k`, `r=(x²+a²)¹ᐟ²`.

Therefore

`B = [μ0 I a/(4π)] ∫[xL→xR] dx/(x²+a²)³ᐟ² k`

`  = [μ0 I/(4πa)] [x/(x²+a²)¹ᐟ²]xL→xR k`.

The primitive follows by differentiating `x/√(x²+a²)` to obtain `a²/(x²+a²)³ᐟ²`; no vector line-integral theorem is required.

For xL=−L1 and xR=L2, with nonnegative L1,L2,

`B = [μ0 I/(4πa)] [L1/√(L1²+a²)+L2/√(L2²+a²)] k`.

For symmetric endpoints ±L,

`B = μ0 I L/[2πa√(L²+a²)] k`.

As L→∞, the fraction tends to 1, giving `B=μ0 I/(2πa) k`. At the opposite side of the wire the field reverses. The symmetric finite result tends to zero with L→0 and is smaller than the infinite result, as expected.

The actual image of reading PDF p6 prints `−∫[−θ1→θ2]sinθ dθ` followed by a cosine sum. Direct evaluation instead gives `cosθ2−cosθ1`; `cos(−θ1)=cosθ1`. This is an internal source error, not a text-extraction artifact. It also labels the symmetric case `θ2=−θ1` while using the acute-endpoint sum. For a consistent angle variable satisfying `x=a cotθ`, θ lies between 0 and π; the left-end θ is `π−α1` and the right-end θ is α2, where α1 and α2 are positive acute endpoint angles measured from the wire. Then `−∫[π−α1→α2] sinθ dθ=cosα2+cosα1`, matching the Cartesian result. The valid final wire formulas can be retained; the printed intermediate bounds cannot.

The infinite-wire field wraps around the wire. With current +z, `B=μ0I/(2πρ) eφ`; the grip rule is a compact representation of the cross-product calculation. The φ direction depends on position; it is not one globally fixed Cartesian vector.

## 5. Center of a circular coil

Presentation p23–27: at the center of an ideal circular loop, ds is tangent, r points inward, r=R, and all contributions have the same axial direction. For the illustrated clockwise current that direction is into the page. With `ds=R dθ`,

`Bmag = (μ0I/4πR²)∫[0→2π] R dθ = μ0I/(2R)`.

A radial straight lead has ds collinear or anticollinear with its displacement to the center and hence contributes zero there. The pictured small gap must be treated as negligible for the full 2π integral. If the gap is an appreciable missing angle, the arc formula is instead `μ0 I Δθ/(4πR)` in the common direction; the gap shape and leads would have to be specified. Nothing in the supplied diagram provides data for that exact finite-gap problem.

## 6. Axial coil field: reading and harder lecture group problem

Reading Example 9.2, loop in xy-plane: parameterize

`rsource=(Rcosφ,Rsinφ,0)`, `ds=R(−sinφ,cosφ,0)dφ`, `rP=(0,0,z)`.

Thus `r=(−Rcosφ,−Rsinφ,z)`, `r²=R²+z²`, and

`ds×r = R(zcosφ,zsinφ,R)dφ`.

The denominator is constant around the loop. Integrating φ from 0 to 2π makes both sine and cosine components zero, leaving

`B = μ0 I R²/[2(R²+z²)³ᐟ²] k`.

This demonstrates cancellation; the contributions themselves are not all axial. The center result is recovered at z=0. Normalizing by `B0=μ0I/(2R)` gives `B/B0=[1+(z/R)²]⁻³ᐟ²`, positive, even in z, maximal at zero, and falling as |z|⁻³ far away, consistent with the supplied curve. For example, at |z|=R it is `1/(2√2)` of B0. Reversing current reverses B.

Presentation p29 uses a different orientation: the loop lies in yz and P is on +x. A parameterization consistent with the actual current arrow is

`rsource=(0,Rcosφ,Rsinφ)`, `ds=(0,−Rsinφ,Rcosφ)dφ`, `rP=(x,0,0)`.

Then `r=(x,−Rcosφ,−Rsinφ)` and

`ds×r=(R²,Rx cosφ,Rx sinφ)dφ`.

The y,z integrals cancel and the x terms add:

`B(P)= μ0 I R²/[2(R²+x²)³ᐟ²] i`.

At the +z side, the pictured current points toward −y, so `rsource×ds` points +x, independently checking the sign. This is why the off-center problem is harder than the center problem: the direction of dB varies and a projection/cancellation is needed.

This expression is for the complete ideal loop. Radial lead reasoning used at the center does not make each lead's field vanish on the x axis. If equal opposite currents occupy coincident return/supply paths, their fields cancel; closely spaced leads may be neglected approximately. The finite separated lead artwork does not specify enough geometry for an exact total lead-plus-loop field. This distinction is material, not a reason to withhold the intended ideal-coil solution.

## 7. Force on the reading's axial dipole

Reading p10 supplies the law `Fz=μz dBz/dz` for a prescribed axial moment. Treat signed μz as fixed while differentiating the loop's external field; do not differentiate μz as if it were an induced-moment model. Then

`dBz/dz = −3 μ0 I R² z/[2(R²+z²)⁵ᐟ²]`,

`F = −3 μ0 μz I R² z/[2(R²+z²)⁵ᐟ²] k`.

For positive I in the stated loop orientation and μz>0, the force points toward z=0 on either side. Reversing μ reverses the force, giving repulsion from the loop plane in this axial model. At z=0 the translational force is zero by symmetry. A uniform field also has zero derivative and gives no such translational force.

The reading writes the full gradient notation as background; the actual assigned calculation needs only the supplied one-dimensional derivative relation. The baseline does not grant a general gradient operator or magnetic dipole theory. μz is a magnetic moment, not permeability μ0. Its units can be identified as A m² (equivalently N m/T); `μz dB/dz` then has units N. The interpretation is a small prescribed dipole in an external field slowly varying across it. The earlier Chapter 8 explanation referenced by the source was not supplied and was not consulted.

## 8. PRS bent wire and curved wire

Bent wire, PRS p11: place the corner at origin, P at `(0,−a,0)`, a>0. The horizontal current flows from negative x toward zero, then turns upward. For horizontal source coordinate s≤0,

`ds=ds i`, `r=−s i−a j`, hence `ds×r=−a ds k`.

Every horizontal contribution points into page. On the upward vertical leg, both ds and r are along the y-axis (opposite directions for sources above P), so their cross product is zero. Net B is into page, option 6. The question only needs direction. If the horizontal part is additionally idealized as semi-infinite, its magnitude is `μ0I/(4πa)`; that extra length assumption is not necessary for the answer.

Curved wire, PRS p13: the left semicircle has radius R centered on P, and the two tangent leads extend to the right. The current runs left along the lower lead, clockwise along the semicircle, and right along the upper lead. The semicircle contributes

`B_arc=−μ0I/(4R) k`.

Each semi-infinite tangent lead has closest distance R and contributes `−μ0I/(4πR) k`. For example, the upper lead has ds=dx i and r=−x i−Rj, giving a negative-k cross product; the lower lead reverses both its y offset and current, again giving negative k. Hence

`B_total=−[μ0I/(4R)+μ0I/(2πR)] k`.

Both straight portions together equal the magnitude of one infinite straight wire at R. This is option 2, and contradicts the tempting but false transfer of the radial-lead zero rule to tangent leads. The dashed rightward continuations support the intended semi-infinite geometry.

## 9. Moving charges and two-particle PRS

The reading relates a small volume of carriers to a current element: `dN=nA ds`, and the signed vector relation is `I ds_vector=dN q v`. Substituting into Biot–Savart and taking a single charge gives

`B(P)=μ0 q/(4π) [v×r]/r³`.

This is the source's nonrelativistic approximation, explicitly requiring v much smaller than c and ignoring retardation. It is not an unrestricted field formula for arbitrary moving charges. At points along the velocity line, v and r are collinear so B=0; changing only charge sign reverses B. Multiple charge contributions are added as vectors at the same observation point.

PRS p15: let q1 at `(a,0,0)` move with `v1=−u1 i`; q2 at `(0,b,0)` moves with `v2=−u2 j`; all q1,q2,a,b,u1,u2 are positive. The source-to-target displacement for B2 at q1 is

`r21=a i−b j`.

Thus `v2×r21 = u2 a k`, so

`B2(q1)= μ0 q2 u2 a/[4π(a²+b²)³ᐟ²] k`.

The requested magnetic force is

`F1,mag=q1 v1×B2 = μ0 q1 q2 u1 u2 a/[4π(a²+b²)³ᐟ²] j`.

It points up, option 2. Using the displacement in the reverse direction would flip the answer incorrectly. The particles also have electric interactions, and their prescribed tracks/velocities can entail constraint forces, but neither changes the question's requested magnetic-force component.

## 10. Parallel-current interaction

Reading 9.2: with both currents along +i and wire 1 displaced in +k relative to wire 2, the field from wire 2 at wire 1 is

`B2=−μ0I2/(2πa) j`.

A length ℓ of wire 1 therefore has

`F12=I1 ℓ i×B2=−μ0I1I2ℓ/(2πa) k`,

which points toward wire 2. The same-direction wires attract. Reversing exactly one current reverses the force and makes it repulsive. Reversing both retains attraction. The force per unit length has magnitude `μ0|I1I2|/(2πa)`; no unspecified finite length needs to be invented. The infinite-wire formula presumes wires long relative to separation and observations away from ends.

## 11. Pressure/tension slides and remaining scope

Presentation p32: the external electric field is down; a positive charge has `qE` down. Presentation p33: positive charge moves out of page and external B is down, so `(+k)×(−j)=+i`, right. Both signs agree with their supplied line-pattern illustrations. Pressure transverse to field lines and tension along them are a qualitative interpretive device in these slides. No numerical pressure, stress tensor, or self-field force law is supplied, and none is needed to justify the force directions already determined by the force laws.

The lecture's Experiment 6 and demonstrations have no supplied quantitative experimental problem beyond these force/field predictions. No procedure, measurement, uncertainty value, observed result, or apparatus parameter can be independently calculated from a title slide. The mathematical checks above cover the supplied problems without claiming a laboratory execution.
