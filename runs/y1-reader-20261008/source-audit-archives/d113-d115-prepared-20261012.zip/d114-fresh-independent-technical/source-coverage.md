# Actual source coverage

Each row refers to a page whose complete TXT was read and full-resolution PNG was visually inspected. Page numbers are PDF page numbers. Formula conclusions below were independently checked in `calculations.md`; answer slides were read as source content, not used as a substitute for derivation.

## Presentation: 33/33

| Page | Material actually observed and technical significance |
|---:|---|
| 1 | Hour 1 magnetic force and Experiment 6; Hour 2 creation of fields and Biot–Savart. Establishes both force and field demands. |
| 2 | Previous magnetic-dipole material recap; does not supply a complete dipole theory in this assigned slide. |
| 3 | Bar-magnet/compass imagery and force `q v×B`; magnetic force depends on charge sign and velocity direction. |
| 4 | Prompt asking how charges move in magnetic fields. |
| 5 | Positive-charge circular motion in a field into the page; depicted velocity and force rotate counterclockwise. Radius, period, and angular-frequency expressions assume positive charge and perpendicular motion; general magnitudes require absolute charge. |
| 6 | Transition to force on current-carrying wires. |
| 7 | Passage from `qv` to `IL` and `F=I L×B`; diagram shows current along the wire and transverse force. Requires carrier-sum justification for the replacement. |
| 8 | Jumping-wire demonstration title only; no apparatus procedure or recorded measurements. |
| 9 | Wire in a gap with field into the page; upward current bends left, downward current bends right, zero current has no magnetic deflection. |
| 10 | PRS prediction transition; the accompanying PRS supplies the five geometries. |
| 11 | Experiment 6 title, “Magnetic Force.” No full lab manual, calibration, measurement table, or experimental results are supplied. |
| 12 | Midterm course evaluation, administrative rather than a physics demand. |
| 13 | Current experiences magnetic force; asks what happens when currents are near each other. |
| 14 | Parallel/antiparallel-current demonstration title only. |
| 15 | Moving charge creates field; one wire's field acts on the other. Animation stills/links support an intended visualization, not an observed live experiment. |
| 16 | Transition to calculation of magnetic fields. |
| 17 | Coulomb-field analogy, with displacement from source to field point. |
| 18 | Moving-charge magnetic field and source permeability convention. Upward positive-charge velocity and up-right displacement give an into-page field. |
| 19 | Biot–Savart current element; rightward element and upward displacement give an out-of-page contribution. Unit displacement differs from displacement. |
| 20 | Grip rule and cylindrical vector relation; cylindrical unit vectors require local interpretation. |
| 21 | Moving-charge field animation still; only the supplied still was inspected. |
| 22 | Magnetic field from a wire demonstration title. |
| 23 | Center-of-coil problem: circular conductor with a small right-side opening and two leads. |
| 24 | Biot–Savart setup at center; distance is radius and current element perpendicular to displacement. |
| 25 | Straight portions treated as radial/collinear with center displacement, hence zero contribution in the intended ideal model. |
| 26 | Circle contributions share into-page direction for the illustrated clockwise current. |
| 27 | Scalar integration of the common-direction contributions gives `μ0 I/(2R)`. The wording “No vectors involved” relies on having already established their common direction. |
| 28 | PRS magnetic-field transition. |
| 29 | Coil in the yz-plane, P on the +x axis; arrow gives positive x-axis loop field. Off-center elements have varying contribution directions; transverse components cancel. The two finite separated leads in the artwork require an idealization before using the complete-loop result. |
| 30 | Field pressure/tension transition. |
| 31 | Qualitative pressure transverse to field lines and tension along them. No quantitative stress law supplied. |
| 32 | Electric-field illustration: positive charge in downward external E has downward force; line pattern interpreted using pressure/tension. |
| 33 | Magnetic illustration: positive charge moving out of page in downward B has force right; qualitative field-line distortion accompanies this. |

## PRS: 16/16

Use page-right as +x, page-up as +y, and page-out as +z except where a separate source coordinate system is explicitly shown.

| Question/answer pages | Actual diagram and independent result |
|---|---|
| 1 / 2 | Wire above the north pole, conventional current right and local B up: force out of screen, option 6. |
| 3 / 4 | Wire in front of the magnet, current right and local equatorial B down: force into screen, option 5. |
| 5 / 6 | Wire behind magnet, current right and local B down: force into screen, option 5. |
| 7 / 8 | Horizontal loop above north pole, front current right/back left: divergent field's radial component makes downward forces add, option 2. A purely uniform vertical field would not explain this translation. |
| 9 / 10 | Same loop with reversed current: upward force, option 1. |
| 11 / 12 | Rightward horizontal wire turns upward; P directly below the corner. Vertical element and displacement are collinear, horizontal contributions into page: option 6. |
| 13 / 14 | Left semicircle with two parallel right-extending tangent leads, bottom current left and top current right. Arc and both leads contribute into page; leads equal one infinite straight-wire field at R in magnitude: option 2. They are not radial leads. |
| 15 / 16 | Positive q1 at positive x moves left; positive q2 at positive y moves down. Field of q2 at q1 is out of page, hence magnetic force on q1 points up, option 2. Magnetic force is requested separately from electric and constraint forces. |

## Reading: PDF 3–14, assigned 9.1–9.2

| PDF page | Material actually observed and technical significance |
|---:|---|
| 3 | Section 9.1, Biot–Savart, source-to-field unit displacement, current-element orientation, permeability value/units, inverse-square comparison with Coulomb's law. |
| 4 | Field is sum/integral of differential vectors, explicitly interpreted as three component integrals; current-element simulation still. Example 9.1 finite straight wire, point above it, compensating lead assumption. |
| 5 | Finite-wire source point, field point, displacement, unit vector, cross product and positive out-of-page direction. |
| 6 | Angle substitution and finite-wire result, symmetric finite wire and infinite limit. The displayed signed-angle bounds and their evaluated cosine sum are internally inconsistent; independent Cartesian derivation recovers the valid result without copying the faulty bounds. |
| 7 | Cylindrical symmetry and grip-rule diagrams; Example 9.2 asks axis field of a circular loop and force/reversal for a prescribed axial magnetic dipole. |
| 8 | Loop geometry, source parameter φ, source and field positions, displacement magnitude. Current sense yields +z axis field. |
| 9 | Cross product, dB, component integration and cancellation, closed form for axial field. |
| 10 | Dimensionless axial-field curve, derivative formula for force on a fixed axial dipole, attraction/reversal, and beginning of carrier derivation of moving-charge field. Dipole force law is supplied but its Chapter 8 background is not part of the allowed inputs. |
| 11 | Carrier-to-point-charge field relation; explicit low-speed/nonrelativistic restriction and neglected retardation; superposition of moving point charges. Positive/negative moving-charge stills show reversal. |
| 12 | Four-charge ring field-vector still, discrete superposition and approach to dipole pattern; 30-charge axis-vector-addition still. No animation was run. |
| 13 | Ring field/iron-filings-style simulation still with movable observation point described. Section 9.2 begins: two parallel currents and each wire's force from the other's field; 3D figure consistent with attraction. |
| 14 | `F12=−μ0 I1 I2 ℓ k/(2πa)`, attraction for same current directions and repulsion for opposite; animation stills. The heading 9.3 and its opening paragraph are visible and were inspected solely as the assignment end boundary. |

## Supplied facts, model choices, and missing materials

Supplied here are the force laws, Biot–Savart and low-speed moving-charge laws, current directions, ideal wire/loop geometries, permeability convention, dipole-force expression, and qualitative field-line interpretation. Independent calculations must preserve the supplied coordinate choices or state a consistent replacement.

The ideal complete loop, negligible gap, radial center leads, or mutually cancelling coincident return leads are model choices needed to turn the drawings into standard loop calculations. A lead that gives zero field at the center need not give zero field at an axial point. Treating all straight leads as zero would be contradicted by the curved-wire PRS.

No full Experiment 6 lab manual, equipment settings, operational safety instructions, calibration, measured force/current data, or required laboratory submission format is present. There is enough supplied content to analyze force directions and theoretical dependence, but not to claim a completed experiment or reproduce a specified protocol. Animation and demonstration names do not authorize invented observations. No live animation, linked website, outside chapter, or unassigned Chapter 9 section was read.
