# D115 independent technical preparation

This is an original-source-only technical preparation dossier. It has no authority to accept teaching, represent a student run, or claim SASIS. Its findings were not sent to the parent during preparation; the parent must freeze the fresh whole teaching before unsealing semantic findings.

Allowed subject sources were limited to `original-inputs/D115/**` and the entire `d013-clean-r34-20261012/inputs/student-baseline.txt`. No current or installed PROF, teaching artifact, old report, queue, other case, other agent's findings, browser, or external subject source was used. No GitHub mutation was performed.

The work comprises:

- Complete source-identity reading in seven bounded intervals.
- Complete baseline reading in 21 contiguous byte intervals, including all four subjects and both selected Further Mathematics options.
- Full reading of 59 required TXT pages and full original-resolution inspection of 59 required PNG pages.
- Exact boundary and provenance records, with failed/truncated delivery recovery made explicit.
- Independent problem and PRS calculations, a baseline-to-demand map, and a record of missing lab material.

`source-coverage.md` and `source-coverage.json` map every required page to its actual observation. `calculations.md` contains semantic findings; `baseline-to-demands.md` separates existing prerequisites, supplied facts and needed bridges. `earth-check.json` preserves the worked coordinate calculation. `working-notes.md` is the contemporaneous initial note, retained as provenance.

`SOURCE-SHA256SUMS` identifies the 124 input files used for provenance or actual reading. `SHA256SUMS` seals dossier files, excluding itself and `SEAL`. The seal establishes byte identity of this prepared evidence only. It is not a quality or acceptance seal for any teaching.
