# D115 independent original-source calculations

Prepared from the four supplied D115 source PDFs through their assigned TXT/PNG pages and the entire specified student baseline. No current teaching, installed PROF, previous reports, other cases, other agents' findings, external web content, or lab manual was consulted. This dossier records technical preparation only; it does not constitute authoring, a student run, an acceptance decision, or a SASIS claim.

Page numbers below are PDF page numbers, not the printed chapter footer. Original answer slides were read, but the calculations here use the displayed geometry and supplied laws independently. The answer sequence is corroboration, not a substitute for derivation.

## Current loop, moment, torque, energy

Ch8 pp8–10; presentation pp7–10. Use conventional current, and choose the loop normal by curling right-hand fingers with that current. For N identical turns of area A, μ = NIA n; [μ] = A m². This is a directed normal to the face, not a vector along the coil plane. The angle θ in τ = μB sin θ is the angle between μ and B.

In the Ch8 p8 top view, x is right and y up. Current is −x on top, −y on the left, +x on the bottom, +y on the right. Thus n = +z. With B = +B xhat, the left vertical segment feels +z and the right one −z because dF = I ds × B. Top and bottom are parallel to B and have zero force. The opposite forces cancel, but their moments add along +y. The xz view uses +y into the page, so this same +y torque looks clockwise in that view. Clockwise must always be tied to the stated viewing direction.

For a rectangular loop whose active opposite sides have length b and whose separation has appropriate perpendicular component a sin θ, each force has magnitude IbB. The couple is IbB a sin θ = IAB sin θ; N turns multiply it by N. The direction is μ × B. No net force in uniform B follows more generally from I ∮ ds × B = I(∮ ds) × B = 0: the directed displacements around a closed loop sum to zero. This does not make the torque zero. It implies no translational acceleration due to this magnetic force; the source's 'no motion' wording additionally assumes the coil starts at rest.

For increasing θ, the field's generalized torque is −μB sin θ. Slow external rotation balances it with +μB sin θ, giving Wext = ∫θ0^θ μB sin t dt = μB(cos θ0 − cos θ). Therefore U(θ) = −μB cos θ + constant = −μ·B + constant. Units μB = A m² × N/(A m) = N m = J. Choosing U = 0 at θ = π/2 gives the quoted expression. U is a minimum at θ = 0 (parallel, stable) and a maximum at θ = π (antiparallel, unstable); both have zero instantaneous torque. A perfectly antiparallel dipole does not spontaneously turn in the ideal exact configuration without a perturbation. A dipole released away from equilibrium can overshoot and oscillate; torque alone does not supply damping or guaranteed settling.

Ch8 p11: a dipole to the right of a bar's N pole has μ and B both +x, but dB/dx < 0. Holding the dipole moment fixed while translating it, Fx = −dU/dx = μ dB/dx < 0. Attraction is leftward, while the quasistatic external force is rightward. Reversing μ reverses this force even though B's spatial pattern is unchanged.

## Gradient notation and the presentation's omitted condition

For fixed vector μ, Fi = ∂(μ·B)/∂xi. A partial derivative changes one spatial coordinate while holding the others fixed. This is a new operational tool relative to the baseline, although Ch8 p12 prints the formal gradient definition.

The p19 slide's additional equality ∇(μ·B) = (μ·∇)B is not unconditional. For example, if μ = μ zhat, the gradient form gives (μ ∂x Bz, μ ∂y Bz, μ ∂z Bz), whereas the directional-derivative expression gives (μ ∂z Bx, μ ∂z By, μ ∂z Bz). Equality requires the corresponding cross-derivatives to agree; in the standard vector identity the difference is μ × (∇×B), for constant μ. A static external field in a region without its source currents supplies the needed curl-free condition. The depicted loop lies outside the source magnet, so that application is appropriate, but the slide does not state the condition. The unqualified formula should not be taught as a universal identity. It also does not cover position-dependent induced moments by simply treating μ as constant.

On the symmetry axis in slide20, take +z upward. Bz > 0 weakens as z increases, so dBz/dz < 0; μz > 0 and Fz = μz dBz/dz < 0. The phrase 'the vector derivative is negative' should be operationalized as this axial component statement. The field fans outward, so radial components are present off-axis; replacing the entire external field by a purely vertical Bz(z) everywhere would lose the wire-force explanation.

For a circular ring with current along +phihat, write its external local field as Br rhat + Bz zhat. Then ds = R dφ phihat and dF = IR dφ(Bz rhat − Br zhat). The radial forces cancel around the ring, while Fz = −2πIR Br at the ring (multiply by N if appropriate). In the upward, outward-fanning picture Br > 0, so the vertical force is downward. In the downward picture both the field and current reverse: (−ds) × (−B) = ds × B. Thus the force is still downward, rather than reversing just because the B arrows reverse.

Slide22 explicitly shows the source bar below the loop with N on top. The small dipole is above it and points up. This is axial parallel alignment; unlike arbitrary side-by-side parallel moments, it is attractive. Slides24–25 are stills of coaxial rings, with anti-parallel and parallel alignment respectively. Their linked animations were not run. The supplied stills and labels support identifying the configurations; a trajectory or timing cannot be inferred by pretending the links were played.

## Biot–Savart and finite straight wire

Ch9 pp3–7. Supplied law: dB = (μ0 I/4π) ds × Rhat/R² = (μ0 I/4π) ds × R/R³, where R points from the source element to the observation point. The source uses μ0 = 4π×10⁻⁷ T m/A as its numerical parameter. Adding vector fields means adding each Cartesian component before taking a magnitude. [μ0 I ds/R²] = T.

Example9.1: wire lies on x, current +x, observation P = (0,a,0), a > 0; endpoints xL and xR. The source states that lead contributions cancel. For source x′, R = (−x′,a,0), ds = dx′ xhat, ds×R = a dx′ zhat. Therefore

    Bz = μ0 I/(4π) ∫[xL,xR] a dx′/(a²+x′²)^(3/2)
       = μ0 I/(4πa) [x′/sqrt(a²+x′²)]xL^xR.

All elements point out of the xy page. For xL = −L and xR = L,

    Bz = μ0 I L/[2π a sqrt(L²+a²)].

As L→∞ this tends to μ0 I/(2πa), and as L→0 it vanishes. The unit is T, and reversing I reverses the vector.

The rendered source p6 contains an intermediate angular inconsistency, not merely text extraction damage. Its x = a cot θ, dx = −a csc² θ dθ substitution is compatible with the illustrated generic angle measured from −x to R. At the left endpoint this θ is π−θ1, where θ1 is the acute angle drawn at that endpoint; at the right it is θ2. Integrating −sin θ from π−θ1 to θ2 yields cos θ2 + cos θ1. The printed lower bound −θ1 would instead yield cos θ2 − cos θ1, and cannot yield the displayed sum. The same page's signed-angle wording for the symmetric case is incompatible with treating both drawn endpoint angles as acute. The final sum formula and symmetric/infinite-wire results are correct with consistent angle definitions. The Cartesian calculation above avoids propagating that error.

## Circular loop on its axis and a dipole's force

Ch9 pp7–10, Example9.2. Let the current loop have radius R in the xy plane and current along increasing φ; P = (0,0,z). Source r′ = (R cosφ,R sinφ,0), ds = R(−sinφ,cosφ,0)dφ, and separation = (−R cosφ,−R sinφ,z). Direct cross multiplication gives

    ds × separation = R(z cosφ,z sinφ,R)dφ.

The separation magnitude sqrt(R²+z²) is constant around the loop. Both transverse integrals over 0≤φ≤2π vanish, leaving

    Bz(z) = μ0 I R²/[2(R²+z²)^(3/2)].

It is positive on both sides of the loop for the defined current, even in z, and is maximal at z = 0, where B0 = μ0 I/(2R). For |z|≫R it tends to μ0 I R²/(2|z|³), agreeing with the axial dipole field using μloop = IπR². Differentiate directly:

    dBz/dz = −3μ0 I R² z/[2(R²+z²)^(5/2)],
    Fz = −3μz μ0 I R² z/[2(R²+z²)^(5/2)].

For parallel μz > 0 and z > 0 the force is negative, toward the loop; for z < 0 it is positive, again toward the plane. Reversing μz reverses the force. At the centre the axial force is zero. Symmetry justifies reducing the relevant on-axis fixed-moment gradient to this derivative; it should not be asserted for arbitrary off-axis points. Units: μz dBz/dz = A m² × T/m = N.

## Moving charges and parallel wires

Ch9 pp10–14. The source derives its slow-moving charge expression using I = nAq|v| and dN = nA ds for positive carriers, then gives B = μ0 q(v×Rhat)/(4πR²). For arbitrary signed q use qv as the directed carrier contribution; do not silently use a negative scalar current and an independently reversed ds. The stated domain is v much less than light speed. A single charge moving along its separation direction produces zero B at that point. Negative q reverses the field for fixed v. Superposition is

    B(P) = μ0/(4π) Σ qj vj × (rP−rj)/|rP−rj|³.

The ring-charge stills on pp12–13 show transverse cancellation on the axis and increasingly continuous-looking field patterns for larger charge counts. They are observations of supplied frames, not executed simulations.

PRS pp1–2 use upward wires. Choose page-right x, page-up y, out-of-page z. Wire1 lies left of wire2. For wire1 at wire2, yhat×xhat = −zhat, so B1 is into the page; wire2's force is yhat×(−zhat) = −xhat, toward wire1. At wire1, B2 is out of page, and yhat×zhat = +xhat. Thus choice1, attraction. Magnitude per length for long wires is μ0 I1I2/(2πa), with units N/m. Opposite current directions reverse the interaction to repulsion. Ch9 pp13–14 draw different axes but give the same physical result: current +x in both wires, B2 at wire1 = −y, force on wire1 = −z toward wire2.

## General dipole field and Earth's model

Ch9 pp24–28 supply the point-dipole field

    B(r) = μ0/(4πr³)[3(μ·rhat)rhat − μ].

For a physical small loop this is the dipole/far-field approximation, not the exact finite-loop field at every distance. With μ = −μ zhat, point in yz plane and θ measured from +z,

    By = −C 3 sinθ cosθ,   Bz = −C(3cos²θ−1),
    Br = −2C cosθ,         Bθ = −C sinθ,
    C = μ0 μ/(4πr³),
    rhat = sinθ yhat + cosθ zhat,
    thetahat = cosθ yhat − sinθ zhat.

These follow by dotting Cartesian B into the displayed unit vectors. At the north side the field is inward; at the equator Br = 0 and B is opposite the dipole moment. Br/Bθ = 2 cotθ where the denominator is nonzero. Units μ0 μ/r³ = T. The source refers to a derivation in §9.8, which is outside the assigned reading; the general formula is a supplied fact here.

For the supplied Earth example, the source gives μE = 7.79×10²² A m², θ0 = 169°, φ0 = 109°, MIT latitude42° N and longitude71° W. These are the source's model values, not a current geomagnetic-data claim. Latitude δ maps to colatitude θ = 90°−δ; western longitude −71° maps to φ = 289° in [0,360°). Convert to unit vectors before dotting:

    mhat = (−0.0621213, 0.1804134, −0.9816272),
    rhatMIT = (0.2419443, −0.7026572, 0.6691306).

The angle between −mhat and rhatMIT is exactly37° from these angles, since their azimuths match and their colatitudes are11° and48°. It is not the geographic colatitude48°. The radial component is −1.597271 C_E, and the horizontal magnitude is0.601815 C_E; their magnitude ratio is2.654090. The corresponding dip angle for this model is69.3547° downward from horizontal. The worked source's ratio≈2.65 is consistent. A separate qualitative animation description saying 'about60°' is not a numerical output of these exact model inputs. `earth-check.json` preserves this calculation without introducing an unsupplied Earth radius or a numerical field strength.

## PRS independent answer map and limits

| Question page | Independent result | Decisive geometry/calculation | Answer-page comparison |
|---|---|---|---|
|1|Choice1, attraction|Upward currents: B at right wire into page; right wire forced left; opposite wire forced right.|p2 agrees.|
|3|Choice1, clockwise rotation, no magnetic translational acceleration|B right, μ up-right: μ×B into page. Left segment out-of-page current forces up; right segment into-page current forces down.|p4 agrees; 'no motion' assumes initially at rest.|
|5|Choice2, downward|μ up, upward field stronger lower down; Fz = μz dBz/dz < 0. Ring's outward field component gives downward ds×B contributions.|p6 agrees.|
|7|Choice2, downward|Both current and B reverse relative p5; their cross product is unchanged. With +z up, μz<0 and Bz<0 approaches zero upward, so dBz/dz>0 and product remains negative.|p8 agrees.|
|9|Choice3 in the intended freely rotating, relaxing physical picture|Torque tends to align μ with local B; aligned fixed-magnitude dipole has U = −μ|B| and seeks stronger field; anti-alignment would instead seek weaker field.|p10 agrees, with the dynamical qualifications below.|

For p9, neither 'always attractive independent of orientation' nor 'always toward strong field independent of orientation' follows. The intended choice is3. However, exact anti-alignment has zero instantaneous torque, and undamped inertia can cause oscillation rather than settling. Free rotation plus perturbation and suitable relaxation are implicit in the explanatory cartoon. Translational and rotational responses are distinct; one cannot use net zero force to conclude zero torque.

## What is absent

The full presentation includes a Galvanometer demonstration title, dip-needle/Java-app references, an Experiment7 title, and animation stills. The four supplied assets contain no Experiment7 lab manual, apparatus inventory, assembly instructions, measurement sequence, safety procedure, numerical observations, or analysis/data sheet. No such procedure or result has been invented here. The supplied theory permits conceptual predictions, not an evidence-based claim to have performed or fully prepared the actual lab.
