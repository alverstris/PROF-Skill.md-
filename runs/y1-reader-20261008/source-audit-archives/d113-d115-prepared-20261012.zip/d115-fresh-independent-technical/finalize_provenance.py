from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
OUT = ROOT / 'd115-fresh-independent-technical'
BASE = ROOT / 'original-inputs/D115'
BASELINE = ROOT / 'd013-clean-r34-20261012/inputs/student-baseline.txt'
sha = lambda b: hashlib.sha256(b).hexdigest()
identity_file = BASE / 'source-identity.json'
identity = json.loads(identity_file.read_text())
pages = json.loads((OUT / 'required-pages.json').read_text())

# These supplement provenance for reads already performed. They do not stand in
# for the actual bounded reading or original-detail image inspection.
identity_rows = [json.loads(v) for v in (OUT/'read-log.jsonl').read_text().splitlines()]
identity_lines = identity_file.read_bytes().splitlines(keepends=True)
next_line = 1
for row in identity_rows:
    a,b = row['lines']
    assert a == next_line
    digest = sha(b''.join(identity_lines[a-1:b]))
    if 'sha256' in row:
        assert row['sha256'] == digest
    else:
        row['sha256'] = digest
        row['hash_supplement'] = 'Added at dossier finalization to the already-completed bounded read.'
    next_line = b+1
assert next_line == len(identity_lines)+1
(OUT/'read-log.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in identity_rows))

baseline = BASELINE.read_bytes()
assert len(baseline) == 247840
assert sha(baseline) == '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
baseline_rows = [json.loads(v) for v in (OUT/'baseline-read-log.jsonl').read_text().splitlines()]
next_byte = 0
for row in baseline_rows:
    a,b = row['byte_interval_half_open']
    assert a == next_byte and b > a
    assert row['sha256'] == sha(baseline[a:b])
    row.setdefault('source',str(BASELINE.relative_to(ROOT)))
    next_byte = b
assert next_byte == len(baseline)
(OUT/'baseline-read-log.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in baseline_rows))

texts = [json.loads(v) for v in (OUT/'text-read-log.jsonl').read_text().splitlines()]
views = [json.loads(v) for v in (OUT/'image-view-log.jsonl').read_text().splitlines()]
assert len(texts) == len(views) == len(pages) == 59
text_map = {v['source']:v for v in texts}
view_map = {v['source']:v for v in views}
assert len(text_map) == len(view_map) == 59
source_records = []
for asset in identity['assets']:
    path = BASE/asset['local_pdf']
    data = path.read_bytes()
    assert sha(data) == asset['sha256'] and len(data) == asset['bytes']
    source_records.append({'path':str(path.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data),'use':'Original PDF provenance; semantic reading through assigned text and full-page render pairs.'})
for p in pages:
    for kind,log in [('text',text_map),('image',view_map)]:
        path = BASE/p[f'{kind}_file']; rel = str(path.relative_to(ROOT)); data=path.read_bytes()
        assert sha(data) == p[f'{kind}_sha256'] == log[rel]['sha256']
        if kind == 'text':
            assert log[rel]['byte_interval_half_open'] == [0,len(data)]
        else:
            assert log[rel]['detail'] == 'original' and log[rel]['whole_page'] is True
        source_records.append({'path':rel,'bytes':len(data),'sha256':sha(data),'use':'Actually read in full' if kind=='text' else 'Actually viewed as a full original-resolution page'})
for path,usage in [(identity_file,'Actually read in seven bounded, complete line intervals.'),(BASELINE,'Actually read in 21 bounded contiguous byte intervals; all four subjects and both selected FM options.')]:
    data=path.read_bytes(); source_records.append({'path':str(path.relative_to(ROOT)),'bytes':len(data),'sha256':sha(data),'use':usage})
assert len(source_records)==124
(OUT/'source-manifest.json').write_text(json.dumps(source_records,indent=2)+'\n')
(OUT/'SOURCE-SHA256SUMS').write_text(''.join(f"{v['sha256']}  {v['path']}\n" for v in source_records))

notes8 = {
8:'Loop current, opposite forces, zero net force and nonzero moment; x/y/z orientation checked.',
9:'Coil angle and area normal; N turns; magnetic-moment definition; torque direction.',
10:'Torque vector, external angular work, potential-energy reference and equilibrium orientation.',
11:'Dipole drawn to right of N pole; weakening field, negative field force and positive balancing external force.',
12:'Gradient components and dip-needle restoring rotation/overshoot narrative; formal definition is not an operational bridge.',
13:'Continuation of undamped dip-needle/angular-momentum narrative. Stop controlling content before heading 8.5; remainder observed only as boundary context.'}
notes9 = {
3:'Biot–Savart element law, separation direction, constant and electrostatic analogy.',
4:'Componentwise vector integration; source-element simulation still; finite-wire geometry and cancelling-leads assumption.',
5:'Finite-wire source-to-P vector, unit vector and cross product; out-of-page sign.',
6:'Finite-wire integration and limits; rendered intermediate angular-bound inconsistency independently repaired.',
7:'Infinite-wire circulation/right hand; cylindrical unit vectors; loop example asks axial field and dipole force.',
8:'Loop source and observation position vectors, parameterized element and separation magnitude.',
9:'Loop cross-product components; transverse cancellation and axial integral.',
10:'Even axial-field graph, centre maximum, derivative force sign; beginning of moving-charge derivation.',
11:'Slow-moving charge field, signed-q direction and superposition.',
12:'Moving-charge and 4/8/30-charge ring animation stills; fields evaluated without claiming animation playback.',
13:'Ring superposition continuation and same-current parallel-wire geometry.',
14:'Parallel-wire field/force signs and attraction/repulsion stills. Stop before 9.3; later text boundary context only.',
24:'Toroid material preceding9.5 is boundary context only. Assigned dipole Cartesian/radial geometry starts at heading 9.5.',
25:'Radial/polar dipole components and general vector dipole expression; referenced9.8 derivation unassigned.',
26:'Earth dipole orientation and spherical/latitude/longitude coordinate conventions.',
27:'Earth moment/MIT worked numbers and local-field simulation narrative; magnetic37° distinguished from geographic 48°.',
28:'Local bar/compass field still completes9.5; stop before 9.6, with later magnetic-material discussion boundary context only.'}
slide_notes = [
'Session title: Hour 1 theory and Hour 2 Experiment 7.',
'Biot–Savart previous-session recap.',
'Current-element and moving-charge field equations.',
'Parallel-wire PRS prompt title.',
'Magnetic dipoles: torque and force topic transition.',
'Previous-Friday review transition.',
'Rectangular coil in uniform field: opposite segment forces, no net force.',
'Torque r×F and thumb/rotation direction in the displayed axes.',
'Area vector and coil moment; τ = IA×B.',
'μ = IA normal and τ = μ×B; alignment and electric-dipole analogy.',
'Dip-needle animation reference/still; no executed animation claimed.',
'Java applet wire/compass reference/still; no executed applet claimed.',
'Galvanometer demonstration title only; no procedure supplied.',
'Magnetic moment definition and current-loop field still.',
'PRS torque-in-uniform-field prompt title.',
'Uniform-field rotation versus translation and paired bar-magnet illustration.',
'PRS force-on-dipole prompt title.',
'Nonuniform-field force topic transition.',
'Energy/gradient/directional-derivative formulas; omitted condition on last equality recorded.',
'Upward μ, outward-fanning upward field, negative axial slope and downward force.',
'Same loop/field geometry asks what source makes the pictured field.',
'Source bar below loop with N on top; axial parallel alignment and attraction.',
'Experiment 7 title only; lab manual and procedure absent.',
'Coaxial anti-parallel ring still and repulsion-animation link.',
'Coaxial parallel ring still and attraction-animation link.',
'Closing PRS force-on-dipole prompt title.']
prs_notes = [
'Upward parallel-current diagram and four options; independently gives attraction, choice 1.',
'Answer geometry confirms into-page B at right wire, out-of-page B at left wire and mutual inward forces.',
'Uniform rightward B and up-right μ; independently clockwise torque into page and zero net magnetic force, choice 1.',
'Answer shows upward force left and downward force right, confirming clockwise couple.',
'Upward μ and upward outward-fanning B; stronger below; choice 2 downward.',
'Answer shows outward/downward segment-force arrows whose vertical components add.',
'Both current and field reversed from p5, while strength still larger below; choice 2 downward.',
'Answer force arrows and source bar with S on top confirm downward attraction for reversed aligned moments.',
'Three proposed reasons for free-dipole attraction; intended choice 3 requires the orientation/relaxation distinction.',
'Answer chooses3 and distinguishes anti-aligned motion toward weaker field; dynamical qualifications recorded.'
]
lines=[
'# D115 source coverage',
'',
'Only original-inputs/D115 and the specified entire student baseline supplied subject evidence. The source identity was read completely before completing the assignment. No semantic-read claim is inherited from identity metadata or a hash.',
'',
'| Source | Exact controlling assignment | Actual text/image coverage |',
'|---|---|---|',
'|Ch8|§8.4, from heading on PDFp8 to before §8.5 on PDFp13|6/6 full page texts, 6/6 full original-resolution PNGs|',
'|Ch9|§§9.1–9.2, heading on PDFp3 to before §9.3 on PDFp14; §9.5, after toroid discussion on PDFp24 to before §9.6 on PDFp28|17/17 texts, 17/17 PNGs|',
'|Presentation|Entire PDF, pp1–26|26/26 texts, 26/26 PNGs|',
'|PRS|Entire PDF, pp1–10|10/10 texts, 10/10 PNGs|',
'',
'All boundary pages were read and viewed whole. Material outside the stated section boundaries on those pages is identified as context and does not expand the controlling assignment. Original PDFs were hashed against identity; actual semantic reading used all required full-page text/PNG pairs. No unassigned chapter page was needed for a claim.',
'',
'| Full-page pair | Read/view status | Observed content and technical check |',
'|---|---|---|']
coverage=[]
for p in pages:
    n=p['page']; path=p['text_file']
    if path.startswith('reading-ch8'): note=notes8[n]; label=f'Ch8 p{n}'
    elif path.startswith('reading-ch9'): note=notes9[n]; label=f'Ch9 p{n}'
    elif p['role']=='presentation': note=slide_notes[n-1]; label=f'Presentation p{n}'
    else: note=prs_notes[n-1]; label=f'PRS p{n}'
    lines.append(f'|{label}|Full TXT read; full PNG viewed at original detail|{note}|')
    coverage.append({**p,'actual_text_read':True,'actual_original_png_view':True,'semantic_observation':note})
lines+=['','Read and view logs preserve source paths, intervals and hashes. `delivery-recovery.json` records the failed/truncated deliveries and their recovery; none is counted as a successful read or view by itself. Hash verification and semantic reading are separate evidence.','',
'Baseline: all 247,840 bytes, 21 exact half-open intervals from 0 to 247840, no gaps or overlaps. Mathematics, Further Mathematics with Statistics and Mechanics, Physics, and Chemistry (including its reference content) were all read. `baseline-to-demands.md` states which existing capabilities do and do not close each D115 demand.','',
'The repeated metadata-only print during finalization was truncated but added no reading coverage; the complete identity had already been read in the seven logged intervals. The follow-up metadata print selected only the needed keys.','']
(OUT/'source-coverage.md').write_text('\n'.join(lines))
(OUT/'source-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
report={'identity_lines':len(identity_lines),'identity_read_chunks':len(identity_rows),'baseline_bytes':len(baseline),'baseline_read_chunks':len(baseline_rows),'page_texts_actually_read':len(texts),'full_original_pngs_actually_viewed':len(views),'source_files_hash_verified':len(source_records),'all_required_coverage_complete':True,'verification_kind':'Provenance consistency only; not authoring evaluation, student simulation, acceptance, or SASIS.'}
(OUT/'provenance-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
