from pathlib import Path
import hashlib,json
out=Path(__file__).parent; f=Path('d013-clean-r34-20261012/inputs/student-baseline.txt'); b=f.read_bytes()
start=int((out/'baseline-next.txt').read_text()); probe=min(start+12000,len(b)); end=(b.find(b'\n',probe)+1) if probe<len(b) else len(b)
part=b[start:end]; print(f'BASELINE byte interval [{start},{end}) of {len(b)}'); print(part.decode())
with (out/'baseline-read-log.jsonl').open('a') as log: log.write(json.dumps({'source':str(f),'byte_interval_half_open':[start,end],'sha256':hashlib.sha256(part).hexdigest(),'delivery':'bounded full chunk'})+'\n')
(out/'baseline-next.txt').write_text(str(end))
