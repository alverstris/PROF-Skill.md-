from pathlib import Path
import hashlib,json,sys
out=Path(__file__).parent; base=Path('original-inputs/D115')
pages=json.loads((out/'required-pages.json').read_text())
for p in pages[int(sys.argv[1]):int(sys.argv[2])]:
    f=base/p['text_file']; b=f.read_bytes()
    print('\nPAGE',p['text_file'],'BYTES',len(b),'SHA256',hashlib.sha256(b).hexdigest()); print(b.decode())
    with (out/'text-read-log.jsonl').open('a') as log:
        log.write(json.dumps({'source':str(f),'byte_interval_half_open':[0,len(b)],'sha256':hashlib.sha256(b).hexdigest(),'delivery':'full untruncated page text'})+'\n')
