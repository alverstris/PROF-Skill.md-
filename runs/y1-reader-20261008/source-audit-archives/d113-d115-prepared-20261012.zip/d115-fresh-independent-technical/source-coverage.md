# D115 source coverage

Only original-inputs/D115 and the specified entire student baseline supplied subject evidence. The source identity was read completely before completing the assignment. No semantic-read claim is inherited from identity metadata or a hash.

| Source | Exact controlling assignment | Actual text/image coverage |
|---|---|---|
|Ch8|§8.4, from heading on PDFp8 to before §8.5 on PDFp13|6/6 full page texts, 6/6 full original-resolution PNGs|
|Ch9|§§9.1–9.2, heading on PDFp3 to before §9.3 on PDFp14; §9.5, after toroid discussion on PDFp24 to before §9.6 on PDFp28|17/17 texts, 17/17 PNGs|
|Presentation|Entire PDF, pp1–26|26/26 texts, 26/26 PNGs|
|PRS|Entire PDF, pp1–10|10/10 texts, 10/10 PNGs|

All boundary pages were read and viewed whole. Material outside the stated section boundaries on those pages is identified as context and does not expand the controlling assignment. Original PDFs were hashed against identity; actual semantic reading used all required full-page text/PNG pairs. No unassigned chapter page was needed for a claim.

| Full-page pair | Read/view status | Observed content and technical check |
|---|---|---|
|Ch8 p8|Full TXT read; full PNG viewed at original detail|Loop current, opposite forces, zero net force and nonzero moment; x/y/z orientation checked.|
|Ch8 p9|Full TXT read; full PNG viewed at original detail|Coil angle and area normal; N turns; magnetic-moment definition; torque direction.|
|Ch8 p10|Full TXT read; full PNG viewed at original detail|Torque vector, external angular work, potential-energy reference and equilibrium orientation.|
|Ch8 p11|Full TXT read; full PNG viewed at original detail|Dipole drawn to right of N pole; weakening field, negative field force and positive balancing external force.|
|Ch8 p12|Full TXT read; full PNG viewed at original detail|Gradient components and dip-needle restoring rotation/overshoot narrative; formal definition is not an operational bridge.|
|Ch8 p13|Full TXT read; full PNG viewed at original detail|Continuation of undamped dip-needle/angular-momentum narrative. Stop controlling content before heading 8.5; remainder observed only as boundary context.|
|Ch9 p3|Full TXT read; full PNG viewed at original detail|Biot–Savart element law, separation direction, constant and electrostatic analogy.|
|Ch9 p4|Full TXT read; full PNG viewed at original detail|Componentwise vector integration; source-element simulation still; finite-wire geometry and cancelling-leads assumption.|
|Ch9 p5|Full TXT read; full PNG viewed at original detail|Finite-wire source-to-P vector, unit vector and cross product; out-of-page sign.|
|Ch9 p6|Full TXT read; full PNG viewed at original detail|Finite-wire integration and limits; rendered intermediate angular-bound inconsistency independently repaired.|
|Ch9 p7|Full TXT read; full PNG viewed at original detail|Infinite-wire circulation/right hand; cylindrical unit vectors; loop example asks axial field and dipole force.|
|Ch9 p8|Full TXT read; full PNG viewed at original detail|Loop source and observation position vectors, parameterized element and separation magnitude.|
|Ch9 p9|Full TXT read; full PNG viewed at original detail|Loop cross-product components; transverse cancellation and axial integral.|
|Ch9 p10|Full TXT read; full PNG viewed at original detail|Even axial-field graph, centre maximum, derivative force sign; beginning of moving-charge derivation.|
|Ch9 p11|Full TXT read; full PNG viewed at original detail|Slow-moving charge field, signed-q direction and superposition.|
|Ch9 p12|Full TXT read; full PNG viewed at original detail|Moving-charge and 4/8/30-charge ring animation stills; fields evaluated without claiming animation playback.|
|Ch9 p13|Full TXT read; full PNG viewed at original detail|Ring superposition continuation and same-current parallel-wire geometry.|
|Ch9 p14|Full TXT read; full PNG viewed at original detail|Parallel-wire field/force signs and attraction/repulsion stills. Stop before 9.3; later text boundary context only.|
|Ch9 p24|Full TXT read; full PNG viewed at original detail|Toroid material preceding9.5 is boundary context only. Assigned dipole Cartesian/radial geometry starts at heading 9.5.|
|Ch9 p25|Full TXT read; full PNG viewed at original detail|Radial/polar dipole components and general vector dipole expression; referenced9.8 derivation unassigned.|
|Ch9 p26|Full TXT read; full PNG viewed at original detail|Earth dipole orientation and spherical/latitude/longitude coordinate conventions.|
|Ch9 p27|Full TXT read; full PNG viewed at original detail|Earth moment/MIT worked numbers and local-field simulation narrative; magnetic37° distinguished from geographic 48°.|
|Ch9 p28|Full TXT read; full PNG viewed at original detail|Local bar/compass field still completes9.5; stop before 9.6, with later magnetic-material discussion boundary context only.|
|Presentation p1|Full TXT read; full PNG viewed at original detail|Session title: Hour 1 theory and Hour 2 Experiment 7.|
|Presentation p2|Full TXT read; full PNG viewed at original detail|Biot–Savart previous-session recap.|
|Presentation p3|Full TXT read; full PNG viewed at original detail|Current-element and moving-charge field equations.|
|Presentation p4|Full TXT read; full PNG viewed at original detail|Parallel-wire PRS prompt title.|
|Presentation p5|Full TXT read; full PNG viewed at original detail|Magnetic dipoles: torque and force topic transition.|
|Presentation p6|Full TXT read; full PNG viewed at original detail|Previous-Friday review transition.|
|Presentation p7|Full TXT read; full PNG viewed at original detail|Rectangular coil in uniform field: opposite segment forces, no net force.|
|Presentation p8|Full TXT read; full PNG viewed at original detail|Torque r×F and thumb/rotation direction in the displayed axes.|
|Presentation p9|Full TXT read; full PNG viewed at original detail|Area vector and coil moment; τ = IA×B.|
|Presentation p10|Full TXT read; full PNG viewed at original detail|μ = IA normal and τ = μ×B; alignment and electric-dipole analogy.|
|Presentation p11|Full TXT read; full PNG viewed at original detail|Dip-needle animation reference/still; no executed animation claimed.|
|Presentation p12|Full TXT read; full PNG viewed at original detail|Java applet wire/compass reference/still; no executed applet claimed.|
|Presentation p13|Full TXT read; full PNG viewed at original detail|Galvanometer demonstration title only; no procedure supplied.|
|Presentation p14|Full TXT read; full PNG viewed at original detail|Magnetic moment definition and current-loop field still.|
|Presentation p15|Full TXT read; full PNG viewed at original detail|PRS torque-in-uniform-field prompt title.|
|Presentation p16|Full TXT read; full PNG viewed at original detail|Uniform-field rotation versus translation and paired bar-magnet illustration.|
|Presentation p17|Full TXT read; full PNG viewed at original detail|PRS force-on-dipole prompt title.|
|Presentation p18|Full TXT read; full PNG viewed at original detail|Nonuniform-field force topic transition.|
|Presentation p19|Full TXT read; full PNG viewed at original detail|Energy/gradient/directional-derivative formulas; omitted condition on last equality recorded.|
|Presentation p20|Full TXT read; full PNG viewed at original detail|Upward μ, outward-fanning upward field, negative axial slope and downward force.|
|Presentation p21|Full TXT read; full PNG viewed at original detail|Same loop/field geometry asks what source makes the pictured field.|
|Presentation p22|Full TXT read; full PNG viewed at original detail|Source bar below loop with N on top; axial parallel alignment and attraction.|
|Presentation p23|Full TXT read; full PNG viewed at original detail|Experiment 7 title only; lab manual and procedure absent.|
|Presentation p24|Full TXT read; full PNG viewed at original detail|Coaxial anti-parallel ring still and repulsion-animation link.|
|Presentation p25|Full TXT read; full PNG viewed at original detail|Coaxial parallel ring still and attraction-animation link.|
|Presentation p26|Full TXT read; full PNG viewed at original detail|Closing PRS force-on-dipole prompt title.|
|PRS p1|Full TXT read; full PNG viewed at original detail|Upward parallel-current diagram and four options; independently gives attraction, choice 1.|
|PRS p2|Full TXT read; full PNG viewed at original detail|Answer geometry confirms into-page B at right wire, out-of-page B at left wire and mutual inward forces.|
|PRS p3|Full TXT read; full PNG viewed at original detail|Uniform rightward B and up-right μ; independently clockwise torque into page and zero net magnetic force, choice 1.|
|PRS p4|Full TXT read; full PNG viewed at original detail|Answer shows upward force left and downward force right, confirming clockwise couple.|
|PRS p5|Full TXT read; full PNG viewed at original detail|Upward μ and upward outward-fanning B; stronger below; choice 2 downward.|
|PRS p6|Full TXT read; full PNG viewed at original detail|Answer shows outward/downward segment-force arrows whose vertical components add.|
|PRS p7|Full TXT read; full PNG viewed at original detail|Both current and field reversed from p5, while strength still larger below; choice 2 downward.|
|PRS p8|Full TXT read; full PNG viewed at original detail|Answer force arrows and source bar with S on top confirm downward attraction for reversed aligned moments.|
|PRS p9|Full TXT read; full PNG viewed at original detail|Three proposed reasons for free-dipole attraction; intended choice 3 requires the orientation/relaxation distinction.|
|PRS p10|Full TXT read; full PNG viewed at original detail|Answer chooses3 and distinguishes anti-aligned motion toward weaker field; dynamical qualifications recorded.|

Read and view logs preserve source paths, intervals and hashes. `delivery-recovery.json` records the failed/truncated deliveries and their recovery; none is counted as a successful read or view by itself. Hash verification and semantic reading are separate evidence.

Baseline: all 247,840 bytes, 21 exact half-open intervals from 0 to 247840, no gaps or overlaps. Mathematics, Further Mathematics with Statistics and Mechanics, Physics, and Chemistry (including its reference content) were all read. `baseline-to-demands.md` states which existing capabilities do and do not close each D115 demand.

The repeated metadata-only print during finalization was truncated but added no reading coverage; the complete identity had already been read in the seven logged intervals. The follow-up metadata print selected only the needed keys.
