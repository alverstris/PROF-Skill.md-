"""Build the confined D129 access/coverage records from permitted original inputs."""
from pathlib import Path
import hashlib, json
from datetime import datetime, timezone
import fitz
from PIL import Image

ROOT=Path('/workspace/scratch/f9c0b7fc7e76')
SRC=ROOT/'original-inputs/D129'
BASE=ROOT/'d015-clean-r36-20261012/inputs/student-baseline.txt'
OUT=ROOT/'d129-fresh-independent-technical'
sha=lambda b: hashlib.sha256(b).hexdigest()
write=lambda name,obj: (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
identity=json.loads((SRC/'source-identity.json').read_text())
expected_pdf='21baf0aef68069129e1fe1a55821b8b7089910bd63c309b6f87fcee61a9c0da6'
expected_identity='a72eaa2e240dcdcb7a49bc844dd3d8a609f034e3bcaa2728b91de56aca7062c8'
expected_baseline='3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'
assert sha((SRC/'source.pdf').read_bytes())==expected_pdf==identity['sha256']
assert sha((SRC/'source-identity.json').read_bytes())==expected_identity
b=BASE.read_bytes(); raw_text=b.decode('utf-8'); t=BASE.read_text()
# The inspected chunks used Python universal-newline text reading. Preserve
# a lossless map from those normalized character boundaries to original bytes.
byte_boundaries=[0]; normalized=[]; raw_index=0; raw_byte_offset=0
while raw_index < len(raw_text):
 ch=raw_text[raw_index]
 if ch=='\r':
  consumed='\r\n' if raw_text[raw_index:raw_index+2]=='\r\n' else '\r'
  normalized.append('\n')
 else:
  consumed=ch; normalized.append(ch)
 raw_index+=len(consumed); raw_byte_offset+=len(consumed.encode('utf-8'))
 byte_boundaries.append(raw_byte_offset)
assert ''.join(normalized)==t and raw_byte_offset==len(b)
assert len(b)==247840 and sha(b)==expected_baseline
assert len(t)==245568
inventory=[]
for f in sorted(SRC.rglob('*')):
 if f.is_file():
  raw=f.read_bytes()
  inventory.append({'path':str(f),'relative_path':str(f.relative_to(SRC)), 'bytes':len(raw),'sha256':sha(raw)})
assert len(inventory)==28
inv={v['relative_path']:v for v in inventory}
pages=[]
for p in identity['page_inventory']:
 n=p['pdf_page_number']; im=SRC/p['fullpage_png']; tx=SRC/p['text_file']
 assert sha(im.read_bytes())==p['png_sha256']
 assert sha(tx.read_bytes())==p['text_sha256']
 with Image.open(im) as png:
  png.load(); size=list(png.size); mode=png.mode
 assert size==[1224,1584] and mode=='RGB'
 pages.append({'pdf_page':n,'slides':[1,2] if n==1 else ([25] if n==13 else [2*n-1,2*n]),
  'text':{'path':str(tx),'bytes':tx.stat().st_size,'sha256':sha(tx.read_bytes()),'full_read':True,
          'access_event':'full source identity and all text command; untruncated result chunk 12a962'},
  'png':{'path':str(im),'bytes':im.stat().st_size,'sha256':sha(im.read_bytes()),'dimensions':size,'mode':mode,
         'actually_emitted_and_visually_read':True,'detail':'original','full_page':True,'crop':False,
         'view_group':1 if n<=3 else 2 if n<=6 else 3 if n<=10 else 4},
  'identity_entries_reverified':True})
chunk_ids=['454733','3d397c','49090f','904e48','1872a5','90d53c','5b0294','8ded57','d8222e','8509f6','de2a9b','9eb220','b77213','ad6b87']
chunks=[]
for i,start in enumerate(range(0,len(t),18000)):
 end=min(start+18000,len(t)); normalized_bytes=t[start:end].encode('utf-8')
 original_bytes=b[byte_boundaries[start]:byte_boundaries[end]]
 chunks.append({'index':i+1,'character_start_inclusive':start,'character_end_exclusive':end,
  'byte_start_inclusive':byte_boundaries[start],'byte_end_exclusive':byte_boundaries[end],
  'first_line_1based':t[:start].count('\n')+1,'last_line_1based':t[:end].count('\n')+1,
  'characters':end-start,'bytes':len(original_bytes),'original_span_sha256':sha(original_bytes),
  'normalized_utf8_bytes':len(normalized_bytes),'normalized_utf8_sha256':sha(normalized_bytes),'exec_result_chunk_id':chunk_ids[i],
  'full_output_read':True,'output_truncated':False})
assert len(chunks)==14 and sum(c['bytes'] for c in chunks)==len(b)
markers={'Mathematics':'MATHEMATICS\n','Further Mathematics':'FURTHER MATHEMATICS\n','Physics':'PHYSICS\n','Chemistry':'CHEMISTRY\n',
 'Further Mathematics Pure Core':'Pure Core\n','Further Mathematics Statistics Y542':'Statistics Y542\n',
 'Further Mathematics Mechanics Y543':'Mechanics Y543\n'}
sections={}
for name,needle in markers.items():
 pos=t.index(needle); sections[name]={'start_character':pos,'start_byte':byte_boundaries[pos],'start_line_1based':t[:pos].count('\n')+1,'read_in_full':True}
# The first Pure Core phrase in introductory material is not the heading; fix heading lookup.
pos=t.index('\nPure Core\n')+1
sections['Further Mathematics Pure Core']={'start_character':pos,'start_byte':byte_boundaries[pos],'start_line_1based':t[:pos].count('\n')+1,'read_in_full':True}
# The option heading is likewise located by its standalone heading, not the introductory mention.
for name,needle in [('Further Mathematics Statistics Y542','\nStatistics Y542\n'),('Further Mathematics Mechanics Y543','\nMechanics Y543\n')]:
 pos=t.index(needle)+1
 sections[name]={'start_character':pos,'start_byte':byte_boundaries[pos],'start_line_1based':t[:pos].count('\n')+1,'read_in_full':True}
key_loci={}
for needle in ['Differentiation and its applications','Integration and elementary differential equations','FM14 Determinants.','FM17 Lines and planes.','FM18 Scalar products and angles.','FM19 Vector products.','FM27 Maclaurin expansions.','FM28 Improper integrals.','FM58 Work and energy.','FM65 Equilibrium and stability.','FM69 What is not a prior university formalism.','Current and circuits','Electric fields and potential','[CH-02.02] Ionic, covalent and metallic bonding']:
 pos=t.index(needle)
 key_loci[needle]={'character':pos,'byte':byte_boundaries[pos],'line_1based':t[:pos].count('\n')+1}
input_lines=[f"{v['sha256']}  D129/{v['relative_path']}\n" for v in inventory]
input_lines.append(f'{expected_baseline}  student-baseline.txt\n')
input_text=''.join(input_lines)
(OUT/'INPUT-SHA256SUMS.txt').write_text(input_text)
packet_text=''.join(input_lines[:-1])
doc=fitz.open(SRC/'source.pdf')
manifest={
 'material_id':'D129','status':'held_source_only_independent_preparation',
 'prepared_at_utc':datetime.now(timezone.utc).isoformat(),
 'confinement':{'method':'instruction confinement, not technical isolation',
  'permitted_original_input_root':str(SRC),'permitted_baseline':str(BASE),
  'read_other_workspace_inputs':False,'web_or_browser_used':False,'skills_or_prof_packages_read':False,
  'history_queues_reports_prior_preparations_read':False,'author_contact':False,
  'followed_paths_or_urls_inside_source_identity_or_baseline':False,
  'delegation_attempt':'A focused checker spawn was attempted but rejected by the thread limit; no child was created.',
  'originals_modified':False,'generated_outputs_are_not_additional_source_inputs':True},
 'source_identity':{'path':str(SRC/'source-identity.json'),'sha256':expected_identity,'full_read':True,
  'session_id':identity['session_id'],'lecture_number':4,'page_count':13,'slide_count':25,
  'source_url_as_recorded_only':identity['source_url'],'resource_url_as_recorded_only':identity['resource_url'],
  'published_revision_as_recorded_only':identity['published_project_revision'],
  'metadata':doc.metadata,'source_pdf_sha256':expected_pdf,'source_pdf_bytes':132024,
  'pdf_parsed_page_count':len(doc),'pdf_page_boxes_points':[list(p.rect) for p in doc]},
 'source_inventory':inventory,
 'source_packet_digest':{'algorithm':'SHA-256','definition':'hash of UTF-8 lines <file SHA256><two spaces>D129/<relative path>\n sorted by source path; source packet only', 'sha256':sha(packet_text.encode())},
 'pages':pages,
 'baseline':{'path':str(BASE),'bytes':len(b),'raw_unicode_characters':len(raw_text),
  'characters_after_universal_newline_normalization':len(t),'logical_lines':len(t.splitlines()),'sha256':sha(b),
  'newline_accounting':{'crlf':raw_text.count('\r\n'),'bare_cr':raw_text.count('\r')-raw_text.count('\r\n'),
   'normalization':'CRLF and bare CR become LF for bounded text reads; all chunk byte offsets map to original bytes'},
  'matches_assigned_hash':True,'full_read':True,'bounded_untruncated_chunks':chunks,'sections':sections,'key_loci':key_loci,
  'all_four_subjects_read':True,'both_further_mathematics_options_read':True},
 'access_totals':{'original_files':len(inventory),'original_packet_bytes':sum(v['bytes'] for v in inventory),
  'identity_files_fully_read':1,'pdf_pages':13,'slides':25,'text_pages_fully_read':13,
  'native_png_pages_actually_viewed':13,'baseline_chunks_fully_read':14,'baseline_bytes_fully_read':len(b),
  'missing_pages':0,'unread_pages':0,'missing_extractions':0,'generated_replacement_pages':0},
 'integrity':{'every_source_identity_page_hash_rechecked':True,'source_pdf_hash_rechecked':True,
  'source_identity_hash_rechecked':True,'baseline_hash_rechecked':True,
  'input_checksum_file_sha256':sha(input_text.encode())},
 'hold':{'findings_withheld_from_root':True,'allowed_root_report':'completion statistics, exact paths, hashes only',
  'release_gate':'future D129 whole freeze followed by current-package/prompt-only admission',
  'no_teaching_sasis_or_publication':True}}
write('source-access-manifest.json',manifest)
topics=[
 ('Agenda and recap',['potential line integral and gradient','field energy','differential Gauss law'],['none'],['field conventions and energy integrability']),
 ('Laplacian',['div grad scalar','quadratic example'],['coloured quadratic mesh'],['operator domains','trace meaning']),
 ('Poisson, Laplace, Earnshaw',['Poisson derivation','charge-free Laplace','no stable electrostatic trapping'],['boxed equations'],['harmonic extremum qualification']),
 ('Cube and circulation',['cube-centre equilibrium question','closed line integral and cancellation'],['cube with vertex charges','two-loop shared boundary'],['equal-charge assumption','quartic cube check']),
 ('Curl and Stokes',['normal circulation-density limit','surface patch sum'],['grid with loop arrows','irregular contour'],['curl-component correction','orientation and regularity']),
 ('Electrostatic curl and rectangle',['zero circulation to zero curl','four edge expansions'],['yz rectangle with x/y/z axes'],['generic F versus E','leading-order circulation']),
 ('Cartesian curl and summary',['three-component curl','gradient divergence Gauss Stokes summary'],['determinant mnemonic'],['yz area typo','surface conventions']),
 ('Summary and materials',['Laplacian/Poisson/Laplace summary','conductors and insulators'],['gold/free-electron schematic','Na+/Cl- solution'],['mobile-charge correction']),
 ('Conductor fields',['redistribution','equipotential bulk and surface','surface net charge'],['three-step polarisation diagram'],['negative-charge motion','potential minus sign','equilibrium scope','unverified timescale']),
 ('Cavities',['empty-cavity zero field','induced net inner/outer charge'],['empty irregular cavity','charged cavity and Gaussian surface'],['closed empty cavity','neutral isolated conductor condition']),
 ('Surface relation and uniqueness',['signed normal field jump','difference of Poisson solutions'],['charged cavity with sigma label'],['Poisson sign typo','inhomogeneous superposition correction','uniqueness conditions']),
 ('Uniqueness examples',['constant potential cavity','concentric shell potentials and centre'],['charged hollow conductor','R1 outer/R2 inner shell diagram'],['empty cavity assumption','reversed integration limits','correct final potentials']),
 ('Historical close',['next topics','quiz/lab/problem-set reminders'],['none'],['historical only'])]
coverage=[]
for i,(title,claims,figures,checks) in enumerate(topics,1):
 coverage.append({'pdf_page':i,'slides':pages[i-1]['slides'],'title':title,'text_complete':True,'native_visual_complete':True,
  'claims_examples_questions':claims,'figures':figures,'conditions_and_checks':checks,
  'dossier_anchor':f'PDF page {i}','omitted_content':[]})
write('coverage-manifest.json',{'material_id':'D129','all_original_pages_covered':True,'all_original_slides_covered':True,
 'coverage':coverage,'source_questions_reconstructed':True,'new_assessments_created':False,
 'baseline_read_is_whole_not_search_only':True,'baseline_warrant_file':'baseline-warrants.md',
 'focused_calculation_script':'focused-calculations.py','focused_results':'focused-calculation-results.json',
 'scope':'Held independent technical preparation; no teaching, SASIS, publication or current-package review'})
print(json.dumps({'manifest_written':True,'source_files':len(inventory),'source_packet_bytes':sum(v['bytes'] for v in inventory),
 'pages':13,'slides':25,'baseline_bytes':len(b),'baseline_chunks':len(chunks),'source_packet_sha256':sha(packet_text.encode()),
 'input_checksums_sha256':sha(input_text.encode())}))
