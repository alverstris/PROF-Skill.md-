"""Focused independent D129 checks; no external data or file inputs.

These exact symbolic calculations address specific original-source risks.
They are not student tests and do not read any future teaching package.
"""
import json
from pathlib import Path
import sympy as s

u = s.symbols('u', real=True)
x, y, z = s.symbols('x y z', real=True)
a, k, Q = s.symbols('a k Q', positive=True)
R1, R2, Q1, Q2 = s.symbols('R1 R2 Q1 Q2', positive=True)
r = s.symbols('r', positive=True)

# Source slide 4. a is arbitrary real in the original; differentiation unaffected.
alpha = s.symbols('alpha', real=True)
bowl = alpha * (x*x + y*y) / 4
bowl_second = [s.diff(bowl, v, 2) for v in (x, y, z)]
saddle = x*x-y*y
saddle_second = [s.diff(saddle, v, 2) for v in (x, y, z)]

# Source slide 7, explicit intended reconstruction: eight identical fixed Q,
# vertices (+/- a,+/- a,+/- a). Potentials scaled by kQ/a.
axis = 4/s.sqrt((u-1)**2+2) + 4/s.sqrt((u+1)**2+2)
diagonal = sum(1/s.sqrt((u-i)**2+(u-j)**2+(u-l)**2)
               for i in (-1,1) for j in (-1,1) for l in (-1,1))
axis_series = s.series(axis, u, 0, 6)
diagonal_series = s.series(diagonal, u, 0, 6)
quartic = -s.Rational(28,243)*s.sqrt(3)*(x**4+y**4+z**4-3*(x*x*y*y+x*x*z*z+y*y*z*z))
quartic_laplacian = s.simplify(sum(s.diff(quartic,v,2) for v in (x,y,z)))

# Source slide 9: curl need not align with an arbitrary chosen normal.
F = s.Matrix([-y/2, x/2, 0])
curl_F = s.Matrix([s.diff(F[2], y)-s.diff(F[1], z),
                   s.diff(F[0], z)-s.diff(F[2], x),
                   s.diff(F[1], x)-s.diff(F[0], y)])
yz_normal_component = curl_F.dot(s.Matrix([1,0,0]))

# Source slides 12-13: assemble exactly the stated leading edge terms.
Fy,Fz,Fy_z,Fz_y,dy,dz = s.symbols('Fy Fz Fy_z Fz_y dy dz')
edge_sum = s.expand((Fy-dz*Fy_z/2)*dy + (Fz+dy*Fz_y/2)*dz
                    -(Fy+dz*Fy_z/2)*dy -(Fz-dy*Fz_y/2)*dz)
rectangle_component = s.simplify(edge_sum/(dy*dz))

# Source slide 22: linearity with fixed inhomogeneous forcing.
c1,c2,rho = s.symbols('c1 c2 rho')
combined_poisson = s.expand(c1*(-4*s.pi*rho)+c2*(-4*s.pi*rho))
difference_poisson = s.simplify((-4*s.pi*rho)-(-4*s.pi*rho))

# Source slide 24, preserving source's R1 OUTER and R2 INNER convention.
source_difference = -s.integrate(Q2/r**2, (r,R2,R1))
correct_difference = -s.integrate(Q2/r**2, (r,R1,R2))
phi_outer = (Q1+Q2)/R1
phi_inner = s.simplify(phi_outer+correct_difference)
phi_mid = Q1/R1+Q2/r
phi_ext = (Q1+Q2)/r
continuity_outer = s.simplify(phi_mid.subs(r,R1)-phi_ext.subs(r,R1))
continuity_inner = s.simplify(phi_mid.subs(r,R2)-phi_inner)
field_mid = -s.diff(phi_mid,r)
field_ext = -s.diff(phi_ext,r)

checks = {
 'scope': 'D129 original source only; exact symbolic checks of concrete source risks',
 'assumptions': ['Gaussian-source convention k=1 except scaled cube notation',
                 'R1>R2>0; R1 is outer as drawn',
                 'cube identical fixed vertex charges; a>0; no central source',
                 'cube expansions local at u=0; positive symbols do not restrict sign conclusions obtained by multiplying qQ'],
 'bowl': {'second_derivatives': list(map(str,bowl_second)), 'laplacian':str(sum(bowl_second))},
 'harmonic_nonflat_counterexample': {'function':str(saddle), 'second_derivatives':list(map(str,saddle_second)), 'laplacian':str(sum(saddle_second))},
 'cube': {'axis_scaled_potential':str(axis), 'diagonal_scaled_potential':str(diagonal),
          'axis_series':str(axis_series), 'diagonal_series':str(diagonal_series),
          'quartic_dimensionless_polynomial':str(quartic), 'quartic_laplacian':str(quartic_laplacian),
          'axis_second_derivative_at_zero':str(s.diff(axis,u,2).subs(u,0)),
          'diagonal_second_derivative_at_zero':str(s.diff(diagonal,u,2).subs(u,0)),
          'axis_fourth_derivative_at_zero':str(s.simplify(s.diff(axis,u,4).subs(u,0))),
          'diagonal_fourth_derivative_at_zero':str(s.simplify(s.diff(diagonal,u,4).subs(u,0)))},
 'curl': {'field':str(F.T), 'curl':str(curl_F.T), 'yz_normal_component':str(yz_normal_component)},
 'rectangle': {'leading_circulation':str(edge_sum), 'component_after_correct_area_division':str(rectangle_component)},
 'poisson_linearity': {'general_combination_forcing':str(combined_poisson), 'difference_forcing':str(difference_poisson)},
 'shells': {'printed_source_difference':str(source_difference), 'correct_inner_minus_outer':str(correct_difference),
            'source_difference_plus_correct_difference':str(s.simplify(source_difference+correct_difference)),
            'outer_potential':str(phi_outer), 'inner_and_centre_potential':str(phi_inner),
            'middle_potential':str(phi_mid), 'exterior_potential':str(phi_ext),
            'outer_continuity_residual':str(continuity_outer), 'inner_continuity_residual':str(continuity_inner),
            'middle_radial_field':str(field_mid), 'exterior_radial_field':str(field_ext)}
}
# Assertions are exact arithmetic guardrails for these calculations, not a test suite.
assert sum(bowl_second)==alpha
assert sum(saddle_second)==0
assert quartic_laplacian==0
assert yz_normal_component==0 and curl_F[2]==1
assert rectangle_component==Fz_y-Fy_z
assert difference_poisson==0
assert s.simplify(source_difference+correct_difference)==0
assert phi_inner==Q1/R1+Q2/R2
assert continuity_outer==continuity_inner==0
path = Path(__file__).resolve().parent/'focused-calculation-results.json'
path.write_text(json.dumps(checks, indent=2, ensure_ascii=False)+'\n')
print(json.dumps({'output':str(path),'exact_assertion_groups_passed':9,'status':'complete'}))
