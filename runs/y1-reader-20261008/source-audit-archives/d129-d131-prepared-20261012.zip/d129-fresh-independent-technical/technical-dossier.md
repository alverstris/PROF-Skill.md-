# D129 independent technical dossier — held preparation

Status: source-only preparation, held pending the future D129 whole freeze and explicit current-package/prompt-only admission. This is neither teaching nor a student trial, diagnosis, SASIS run, publication, or an admitted review of a future package. No findings were sent to the root agent. Original inputs were not modified. Confinement was by instruction; no technical isolation is claimed.

## Identity and access

The original identity record labels this D129, session `mit-8-022-fall2004-L04`, MIT 8.022 Physics II (Electricity and Magnetism), Fall 2004, Lecture 4, G. Sciolla. The supplied PDF is 132,024 bytes, SHA-256 `21baf0aef68069129e1fe1a55821b8b7089910bd63c309b6f87fcee61a9c0da6`, 13 US-letter PDF pages carrying 25 lecture slides. The title page is slide 1, slides 2–24 occur two per PDF page, and slide 25 occupies the top of page 13. All pages are 612 × 792 points; each original PNG is 1224 × 1584 pixels. PDF metadata gives author `sciolla`, title `Microsoft PowerPoint - Lecture4.ppt`, creator `PScript5.dll Version 5.2`, PDF 1.3, creation `D:20040921120938-04'00'`, modification `D:20041217202113+05'30'`.

All of `source-identity.json`, all 13 original per-page extracted text files, and all 13 original full-page PNGs were read. Every native PNG was actually emitted and visually inspected at original detail; merely opening/decoding a PNG was not counted as visual reading. The PDF was hashed and parsed for metadata and page boxes. The supplied extraction and native images were complete, so no replacement extraction or rendering was necessary. Garbled ordering and missing mathematical layout in the text extraction were resolved against the images. No external source URL, prior repository path, cached acquisition path, Purcell chapter, history, package, queue, or report mentioned inside the originals was followed.

The whole baseline was read in 14 consecutive bounded, untruncated chunks: character ranges [0,18000), [18000,36000), …, [216000,234000), [234000,245568). UTF-8 size is 247,840 bytes, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`; it contains 246,945 raw Unicode characters, or 245,568 after universal-newline normalization, and 2,561 logical lines. All Mathematics H240, Further Mathematics H245 Pure Core plus Statistics Y542 and Mechanics Y543, Physics H556, and Chemistry H432 sections were read. The full-file hash agrees with the assigned expected hash. Exact input hashes, page access, chunk hashes, and source-page coverage are in the companion manifests.

## Conventions that control every formula

The source uses the electrostatic convention `∇·E = 4πρ`, `φ_point = Q/r`, and field energy density `E²/(8π)`. These are mutually consistent with a Coulomb constant set to one in a Gaussian electrostatic convention. The source does not identify that unit convention on these pages. The baseline's Physics section instead explicitly uses SI: point potential `Q/(4πε₀r)`. Numerical charges and constants must not be transferred unchanged between the systems. It is possible to retain a symbolic Coulomb constant `k`: `E_point = kQ r̂/r²`, `∇·E = 4πkρ`, `∇²φ = −4πkρ`, and `E_n,out−E_n,in = 4πkσ`. Source formulae are recovered by k = 1; the baseline SI forms by k = 1/(4πε₀).

The potential is scalar; E and the generic field F are vectors. The vector line element is tangent and oriented. A vector surface element is `dA_vec = n̂ dA`; its normal and the circulation orientation must obey one compatible right-hand convention. Volume density ρ and surface density σ are different quantities. The source's `E_surface` in a signed charge-density equation must mean a signed normal component, not a nonnegative magnitude. Radii on slide 24 deliberately use index 1 for the OUTER shell and index 2 for the INNER shell: `0 < R₂ < R₁`. The picture, colour labels, and final formulas confirm this; assuming the more familiar R₁ < R₂ would manufacture an error that is not in the source.

Electrostatics means an equilibrium, time-independent electric situation. The conductor conclusions require mobile charges to have settled and no imposed steady current. They are not claims about every current-carrying metal in the baseline's circuit models. Bulk conductor material, its surfaces, and an empty or charged cavity are distinct regions. Point charges and surface layers are singular idealisations where classical derivatives need separate interpretation or exclusion from the smooth domain.

## Full page and slide reconstruction

### PDF page 1: slides 1–2

Slide 1 announces vector-calculus applications to electrostatics: Laplacian, Poisson and Laplace equations, curl and its applications, and introduction to conductors. It contains no worked example or assessment item.

Slide 2 is a prior-lecture recap. It gives `φ(r) = −∫_∞^r E·ds`, `E = −∇φ`, and interprets potential as the work needed to bring a unit charge from infinity. The intended work is external quasistatic work per positive test charge; field work has the opposite sign. Setting the reference at infinity requires the potential difference to exist there; not every charge arrangement permits it. The charge must function as a test charge if the source field is to remain unchanged.

The recap gives `U = (1/2)∫_(charge volume) ρφ dV = ∫_(all space) E²/(8π) dV` and says assembly work is stored in the field. This needs a charge distribution and boundary behaviour for which the integrals and integration-by-parts boundary term are well defined. Ideal point-charge self energies make the all-space E² integral divergent; excluding self interaction from a discrete assembly energy does not automatically make that divergent integral equal to it. No such calculation is assigned on this page. The final recap is `∇·E = 4πρ`, described as a route from E to its generating charge distribution. A field known only away from a singularity cannot recover the singular charge by an ordinary pointwise divergence there.

### PDF page 2: slides 3–4

Slide 3 composes divergence with gradient. The displayed Cartesian computation reduces `∇·∇f` to `∂²f/∂x² + ∂²f/∂y² + ∂²f/∂z²`, and defines the result as `∇²f`. The prompt asks the difference from “grad div f.” For scalar f, divergence of f is not defined by these operations; for a vector F, `grad(div F)` is a vector and is not the scalar Laplacian of f. Treat the prompt as an operator-domain question, not an instruction to commute arbitrary operators. A vector Laplacian would need its own definition and is not supplied here. The compact product of differential-operator vectors is mnemonic: derivatives act on the functions to their right.

Slide 4 supplies the exact example `φ(x,y) = a(x²+y²)/4`. The result is `∇²φ = a/4(2+2) = a`; the omitted z dependence contributes zero if embedded in three dimensions. The illustration is a coloured mesh bowl with x and y roughly from −2 to 2 and nonnegative height, depicting a positive-a case. It does not specify a numerical a; for negative a it would open downward, and for a = 0 it would be flat. The text calls the Laplacian “the curvature.” Technically it is the sum of coordinate second derivatives, or trace of the Hessian, not every directional curvature. For this example each x/y second derivative is a/2 and z is zero. The image uses φ in the problem and f in the calculation; this is a harmless generic-name change.

### PDF page 3: slides 5–6

Slide 5 combines `∇·E = 4πρ` and `E = −∇φ` to obtain the correctly signed `∇²φ = −4πρ` (Poisson). This is a local equation in a smooth region; singular charge sources need distributional treatment or interface conditions, neither independently taught here.

Slide 6 sets ρ = 0 and obtains Laplace's equation `∇²φ = 0`. “Vacuum” is used as shorthand for a charge-free region; vacuum does not itself logically rule out an inserted charge. The slide says the potential's curvature is zero everywhere, hence no local maxima/minima, and states Earnshaw's theorem: electrostatic fields cannot hold a charge in stable equilibrium. Correct scope is an unconstrained nonzero test charge in a charge-free neighbourhood, acted upon by a static electrostatic potential. The energy is `qφ`; positive q would require a minimum of φ, negative q a maximum. A harmonic function has no strict interior extremum; a nonconstant harmonic function on a connected region cannot attain an interior maximum/minimum in the stronger local sense. A constant function is the standard exception to literal non-strict wording and supplies no trapping. Zero Laplacian means zero sum of second derivatives, not a locally flat graph. The example `x²−y²` has Laplacian zero and second derivatives 2 and −2. At a degenerate equilibrium, second-derivative sign tests alone cannot prove Earnshaw; a maximum-principle/mean-value argument is needed. The source states the extremum property without proving that stronger result.

### PDF page 4: slides 7–8

Slide 7 presents “8 charges on a cube and one free in the middle,” asks whether equilibrium is stable, and answers no. The drawing is a perspective cube with identical green vertex dots, a central red test charge, and hidden/back geometry not fully drawn. It conveys eight charges by text even though not every vertex is separately visible. Neither magnitudes nor signs are numerically specified. Centre equilibrium follows from the intended identical fixed vertex charges and symmetry, not from the mere count of eight arbitrary charges. The no-stable-trapping conclusion follows from the stated Earnshaw result for a source-free neighbourhood of the centre.

An independent source-derived check is available using superposition of the baseline point potentials and the supplied binomial/Maclaurin rules. With charges Q at `(±a,±a,±a)`, a > 0, the centre gradient and entire quadratic term vanish by cubic symmetry. The first nonconstant contribution is quartic and changes sign with direction. Along `(au,0,0)`, `φ/(kQ/a) = 8/√3 − (28√3/243)u⁴ + O(u⁶)`; along `(au,au,au)`, it is `8/√3 + (56√3/81)u⁴ + O(u⁶)`. Thus the centre is a degenerate saddle, not a minimum or maximum. For either sign of nonzero qQ, qφ has a downhill direction. This calculation checks the source answer while explaining why a Hessian-only argument would be inconclusive. Equal fixed charges are an explicit reconstruction assumption, not a silently given number.

Slide 8 defines circulation `Γ = ∮_C F·ds`. Its figure splits a red outer loop into two loops by a common black curved segment C′, with opposite arrows on its two copies; outer arrows are compatible with that cancellation. It asserts `Γ = Γ₁ + Γ₂`. The relevant mathematical identity is addition of oriented line integrals: the shared arc contributes `I(C′)` and `I(−C′) = −I(C′)`, leaving only the outside boundary. Some printed C-minus-C′/closed-integral notation is loose; the correct cancellation is supplied explicitly by the subsequent plus/minus terms. A field continuous along the piecewise smooth curves suffices for these line integrals. This is not multiplication of scalar curve labels.

### PDF page 5: slides 9–10

Slide 9 repeats the subdivision to many cells and writes `Γ = ΣΓ_i`. The red boundary encloses a red grid and small circulation arrows. It defines the normal component of curl by shrinking an oriented loop around a point: `(curl F)·n̂ = lim_(A→0) (∮_C F·ds)/A`. The point, normal direction, shape-controlled shrinking, and regularity of the field must be held suitably fixed. The next sentence says that “the curl is a vector normal to the surface A” with right-hand direction. That is genuinely overstrong/incorrect for an arbitrary selected surface: the displayed formula determines its normal COMPONENT. The curl vector is generally not normal to every surface through the point. For `F = (−y/2,x/2,0)`, curl is `(0,0,1)`; its circulation density in a yz-plane loop is zero, although curl itself is nonzero and lies in that plane. The right-hand rule matches loop orientation and chosen normal; it does not erase other curl components.

Slide 10 derives Stokes' theorem by summing patch circulations and taking a limiting surface sum. The boxed statement is `∮_C F·ds = ∫_A (curl F)·dA_vec`. The top figure is an irregular closed red contour C bounding A. Required conditions: an orientable piecewise smooth spanning surface, consistent boundary orientation, and a field with suitable continuous first derivatives on a neighbourhood of the surface. Singularities must not be hidden in the spanning surface. Curl and normal may vary from patch to patch; the notation in a finite sum is understood locally. Internal edges cancel; finite patch averages approach local curl components. “Area enclosed by C” is a planar shorthand, whereas a general spatial curve needs a specified spanning surface.

### PDF page 6: slides 11–12

Slide 11 uses electrostatic conservativeness: circulation is zero for every closed path, so Stokes gives zero curl flux for any admissible surface and hence `curl E = 0` locally. It starts with generic force F and then switches to E. This is legitimate for a nonzero constant test charge with F = qE, but that identification should be explicit. Zero circulation around one loop or zero flux through one finite surface does not force curl to vanish pointwise. Conversely, a curl-free field is not automatically globally conservative on an arbitrary multiply connected domain; here conservativeness is the stated starting physical premise, so that converse is not needed.

Slide 12 derives the x curl component using a small yz rectangle centred at `(x,y,z)`. The axes show z upward, y right, x diagonally down-left; rectangle vertices a bottom-left, b bottom-right, c top-right, d top-left. Path a→b→c→d→a runs +y, +z, −y, −z and has +x normal by the stated convention. The side lengths are Δy horizontally and Δz vertically. Midpoint/Taylor approximations give:

- a→b: `[F_y − (Δz/2)∂_zF_y]Δy`;
- b→c: `[F_z + (Δy/2)∂_yF_z]Δz`;
- c→d: `−[F_y + (Δz/2)∂_zF_y]Δy`;
- d→a: `−[F_z − (Δy/2)∂_yF_z]Δz`.

The sum is `(∂_yF_z−∂_zF_y)ΔyΔz` to leading order. The exact finite-edge equality is not claimed by the use of the approximation symbol; the final component follows after dividing by the area and taking the limit. The term “square” is used although Δy and Δz need not be equal; nothing requires equal sides.

### PDF page 7: slides 13–14

Slide 13 correctly starts from the yz-area result but the boxed quotient prints a denominator `ΔxΔy` and limits `Δx→0`, `Δy→0`. That is an original slide typo, visible in the native image, not extraction damage. It must be `ΔyΔz` with the corresponding y/z limits. The final x component `(∂F_z/∂y−∂F_y/∂z)` is correct, as are the completed components:

`curl F = (∂_yF_z−∂_zF_y)x̂ + (∂_zF_x−∂_xF_z)ŷ + (∂_xF_y−∂_yF_x)ẑ`.

The displayed determinant with coordinate unit vectors in row one, partial derivatives in row two, and F components in row three is a calculation mnemonic for `∇×F`; derivatives act on the entries below them. It is not a determinant of ordinary scalar numbers. FM14 and FM19 supply the determinant/component patterns, but they do not by themselves supply differentiation of fields.

Slide 14 summarises gradient and `E=−∇φ`; divergence and Gauss' theorem `∫_S E·dA = ∫_V ∇·E dV`; differential Gauss law; curl; Stokes; and `∇×E=0`. Surface S must be the closed boundary of V with outward normal. The lack of a closed-surface glyph on S is not a change in the theorem. “Purcell Chapter 2” is a reference label only; its contents were neither accessed nor used as an input.

### PDF page 8: slides 15–16

Slide 15 summarises `∇²φ=∇·∇φ`, Poisson, Laplace, and Earnshaw. It repeats the same convention and the same scope limitations as slides 5–6. A yellow comment box says time and exercise will help with the mathematics; no exercise is supplied there. It again names Purcell Chapter 2.

Slide 16 introduces conductors and insulators. Examples: excellent conductors Au, Ag, Cu, Al; “OK” conductors NaCl in H₂O; organic insulators rubber/plastic and inorganic quartz/glass. The left sketch labels a gold block with red free-electron dots and a free-electron callout. The right blue solution box shows labelled Na⁺ and Cl⁻ populations. The slide's definition “conductor: a material with free electrons” is too narrow for its own ionic-solution example; the relevant category is mobile charge carriers. Physics explicitly says electrolytes conduct by ions, and Chemistry CH-02.02 supplies both metallic delocalised electrons and mobile-ion conduction in melts/solutions. The corresponding ideal-insulator definition concerns the absence of sufficiently mobile carriers, not the literal absence of electrons. The source's examples can be retained with that correction. The schematic electron placement around a block is not a quantitative bulk-carrier model or a claim that conduction electrons exist only on surfaces.

### PDF page 9: slides 17–18

Slide 17 assumes an effectively unlimited supply of movable charge and states E = 0 inside a conductor. It explains that nonzero E moves charges until cancellation. The sequence of three pictures shows an initially placed tilted green body in a rightward uniform field; positive charge moving right and negative charge left; then negative charge on the left and positive charge on the right, with field lines bent outside and absent from the bulk. This is an equilibrium polarisation argument, not permission to create net charge. The finite carrier supply normally allows tiny redistribution in the idealised setting; “infinite” is an approximation, not a literal material fact.

The sentence saying charges move from higher to lower potential is sign-dependent. Positive charges lower qφ by moving to lower φ; negative charges lower qφ by moving to higher φ. The figure's arrows show the two signs correctly. The source quotes a redistribution time `10⁻¹⁷–10⁻¹⁶ s` with “typical resistivity of metals.” Neither metal resistivity numbers nor a validated response model are supplied, so the numerical claim cannot be verified from the allowed packet. It is recorded, not promoted to an independently warranted universal timescale. No external metal data were imported.

Slide 18 derives equipotential behaviour from E = 0. It prints `Δφ = ∫_(P₁)^(P₂) E·ds = 0`; the general potential-difference expression needs a minus sign for `Δφ = φ(P₂)−φ(P₁)`, though both versions give zero here. It says net charge resides only on the surface, external field lines are perpendicular, and the surface is equipotential. The bulk conclusion follows pointwise from `ρ=(∇·E)/(4π)=0` in conductor material at equilibrium. It is not a denial of charge in an insulating cavity or of positive/negative microscopic constituents in a neutral metal. The external tangent field would drive redistribution, so E_tangent = 0 at a smooth equilibrium surface. A field of zero magnitude has no direction, and singular corners need limiting rather than naive normal language. Every connected conductor is at one potential; disconnected conductors need not share it.

### PDF page 10: slides 19–20

Slide 19: a hollow, closed cavity in a conductor, containing no charges, has constant potential and E = 0. The green body has a white irregular inner opening labelled E = 0. Its boundary is equipotential; φ satisfies Laplace inside; the interior must equal that boundary constant. The later uniqueness theorem gives a precise route. The cavity must be a bounded closed region with the stated boundary, not an open passage exposed to external fields or a region bounded by separately biased conductors. No grounding is required for zero field in an empty closed cavity. The field can vanish while its constant potential is nonzero. “Faraday's cage” here means electrostatic shielding; frequency-dependent shielding is not established by this argument.

Slide 20: placing +Q inside a cavity induces −Q on the inner surface and, for an overall neutral isolated conductor, +Q on its outer surface. The native figure shows the inner positive charge, inner negative marks, outer positive marks, and a dashed Gaussian surface entirely in the conducting material. The surface encloses the cavity charge plus the inner induced layer and has zero flux because E = 0 on it: `0=4π(Q+Q_inside)`. Charge conservation then gives `Q_outside=−Q_inside=Q`. The neutrality condition appears explicitly at the end of the slide, even though the headline omits it. In general conductor net charge Q_c gives `Q_outside=Q_c+Q`; grounding can change Q_c. This is an integral charge statement, not uniform surface density. A noncentral charge and irregular cavity need not induce a uniform distribution.

### PDF page 11: slides 21–22

Slide 21 gives `σ_induced = E_surface/(4π)` from the jump `ΔE=4πσ` and zero interior metal field. The figure repeats the charged cavity with the σ label outside. The precise local relation is `(E_nonmetal−E_metal)·n̂ = 4πσ`, where n̂ points out of the metal into the neighbouring region. At equilibrium `σ=E_nonmetal·n̂/(4π)`. The cavity-facing outward normal points into the cavity; for a positive cavity source the normal field is negative and the inner σ negative. An unsigned E magnitude would lose that sign. On the depicted outer surface, positive σ corresponds to a field leaving the metal. The formula is a local relation for total surface charge; “induced” describes the specified preparation, not a separate universal field decomposition. It does not determine σ from Q alone without solving the geometry/field.

Slide 22 states a Dirichlet uniqueness theorem: prescribed ρ in a region and prescribed potential on its boundary determine at most one electrostatic potential, subject to suitable regularity and the necessary condition at infinity for an unbounded domain. The statement alone is not a general existence theorem for arbitrary incompatible or pathological data. Its proof assumes φ₁ and φ₂ satisfy the same Poisson equation and boundary data, subtracts them, obtains harmonic φ₃=φ₂−φ₁, and uses zero boundary values plus the extremum property to conclude φ₃=0.

Two genuine source errors occur. First, both displayed starting Poisson equations have `+4πρ`, contradicting the correct negative sign on slides 5 and 15. Their difference is still zero, so the uniqueness conclusion survives after correction. Second, the sentence “any combination … will be solution” is false for the fixed inhomogeneous equation. `L(aφ₁+bφ₂)=−4π(a+b)ρ`; coefficients summing to 1 preserve the same forcing, while the difference solves the homogeneous equation. If both boundary values are g, a general combination also has boundary `(a+b)g`. The displayed subtraction is the correct operation despite the misleading superposition sentence. A smooth bounded-region alternative check integrates `div(w∇w)=|∇w|²+w∇²w` and uses Gauss plus w=0 on the boundary, obtaining `∫|∇w|²=0`, hence w constant and zero. This is a derivation from supplied product differentiation and the source's divergence theorem, not a separately granted baseline theorem.

### PDF page 12: slides 23–24

Slide 23 charges a hollow conductor until its exterior surface has potential φ₀ relative to infinity, then asks for potential inside the cavity. The drawing has outer positive marks and an uncharged white cavity. Answer: `φ=φ₀` throughout the conductor and the empty cavity. The constant function satisfies the cavity Laplace equation and the constant boundary, so uniqueness supplies the conclusion. “Including the cavity” requires the charge-free cavity assumption represented by the diagram and prior corollary; adding a cavity charge changes that conclusion.

Slide 24 contains the substantial worked spherical-shell example. The text says two concentric thin conductive spherical shells of radii R₁, R₂ carry charges Q₁, Q₂ respectively, with φ(∞)=0. The red OUTER shell carries Q₁ and has radius R₁; the black INNER shell carries Q₂ and has radius R₂. It asks the outer-shell potential, inner-shell potential, and potential at r=0. With `R₁>R₂>0`, its final answers are correct:

`φ₁=(Q₁+Q₂)/R₁`, `φ₂=Q₁/R₁+Q₂/R₂`, and `φ(r)=φ₂` for `r<R₂`.

However the intermediate line has an original sign/endpoint error. It prints `φ₂−φ₁ = −∫_(R₂)^(R₁) E·ds = −∫_(R₂)^(R₁) (Q₂/r²)dr = Q₂/R₁−Q₂/R₂`. That is the negative of the desired inner-minus-outer difference. The limits should be R₁ to R₂, or the leading minus sign should be removed for the printed R₂-to-R₁ radial integral. The correct difference is `Q₂(1/R₂−1/R₁)`. The subsequent final φ₂ formula in the source corresponds to the corrected difference and does not follow from its printed intermediate line. This is verified directly from the native image and by independent integration.

A complete reconstruction is:

- `r>R₁`: `E_r=(Q₁+Q₂)/r²`, `φ=(Q₁+Q₂)/r`;
- `R₂<r<R₁`: `E_r=Q₂/r²`, `φ=Q₁/R₁+Q₂/r`;
- `0≤r<R₂`: `E=0`, `φ=Q₁/R₁+Q₂/R₂`.

Potentials are continuous at each shell. The radial-field jumps are Q₁/R₁² at the outer shell and Q₂/R₂² at the inner shell for the ideal infinitesimal shell model. The finite-thickness version distinguishes faces: the outer conductor carries −Q₂ on its cavity-facing surface and Q₁+Q₂ on its outside, summing to the specified net Q₁; the inner shell has no inner-face net charge in its empty cavity. Those facts reconcile net shell charge with zero field within the metal. For the given thin shells, do not apply `σ=E_out/(4π)` to net charge across two merged conductor faces without distinguishing the adjacent fields. The exterior infinity reference and absence of additional external sources are part of this spherical reconstruction. Uniqueness is specifically invoked to extend the constant inner-shell boundary value into the empty central region.

### PDF page 13: slide 25

The final slide announces more conductor electrostatics and capacitors next time. It says these topics are included in Quiz 1 on Tuesday October 5, “just 2 weeks from now”; Lab 1 “Tomorrow 5–8 pm”; problem set 2 due Friday September 24. These are historical course scheduling statements, not current tasks or calendar instructions. The page contains no hidden continuation, derivation, diagram, or problem to solve. Date metadata and displayed lecture reminders identify historical context; no attempt was made to modernise or verify a current schedule.

## Error and qualification register

| ID | Location | Classification | Finding and consequence |
|---|---|---|---|
| E01 | p3/s6, repeated p8/s15 | Substantive explanatory overstatement | Zero Laplacian is zero trace, not zero curvature in every direction; extremum result needs harmonic-function reasoning and excludes constant/non-strict ambiguity. |
| E02 | p5/s9 | Genuine conceptual error | Arbitrary surface gives a normal component of curl, not a curl vector compelled to be normal to that surface. |
| E03 | p7/s13 | Genuine formula typo | yz-area quotient has x/y denominator and limits; use ΔyΔz and y/z limits. Final curl component/formula are correct. |
| E04 | p8/s16 | Genuine overnarrow definition | Conduction can use ions, as the same slide and both science baselines demonstrate; “free electrons” alone fails. |
| E05 | p9/s17 | Genuine sign-dependent statement | Lower-potential drift claim applies to positive charges; negative charge is driven toward higher potential. Figure is consistent with the corrected sign. |
| E06 | p9/s18 | Genuine formula sign omission | Potential difference is minus the directed E integral. Zero-value conclusion remains correct here. |
| E07 | p11/s22 | Genuine sign typo | Both Poisson equations are printed with +4πρ. Correct −4πρ; homogeneous difference proof remains valid. |
| E08 | p11/s22 | Genuine superposition overclaim | Arbitrary linear combinations do not preserve fixed inhomogeneous density/boundary data; the difference solves homogeneous Laplace. |
| E09 | p12/s24 | Genuine integral limits/sign error | Printed inner-minus-outer difference uses the opposite radial orientation. Correct final values are printed, but cannot follow from that line as written. |
| Q01 | p1/s2 throughout | Convention prerequisite | Gaussian-style factors differ from SI baseline; no evidence of a mistaken physical law when source convention is kept consistent. |
| Q02 | p4/s7 | Underspecified intended example | Identical fixed vertex charges are needed for the stated central equilibrium; no numerical charge values supplied. |
| Q03 | p5–7 | Theorem/domain prerequisites | Oriented surfaces, smooth fields and appropriate loop/surface domains required. Curl-free converse needs additional global conditions. |
| Q04 | p9/s17 | Unverified numerical claim | Quoted equilibration times lack the numerical material data and response derivation needed for permitted-input verification. Not classified as a proven error. |
| Q05 | p9–12 | Physical-domain qualification | E=0 refers to electrostatic conductor material; empty cavity and disconnected-conductor distinctions matter. |
| Q06 | p10/s20 | Condition supplied late | +Q outside assumes overall neutral isolated conductor; source explicitly states neutrality in final line. |
| Q07 | p11/s21 | Signed convention/precision | σ relation uses signed normal component and one-sided field limits, not unsigned magnitude or geometry-free Q-to-σ inference. |
| Q08 | p11/s22 | Theorem scope | Dirichlet uniqueness is at most one admissible solution, requires full boundary conditions, and does not establish arbitrary-data existence. |
| Q09 | p12/s24 | Correct unusual labels | R₁ is outer, R₂ inner. Preserve these labels; do not falsely report the final potentials as swapped. |
| Q10 | p1/s2 | Integrability/singularity qualification | Field-energy formula needs appropriate finite energy/boundary behaviour; point-charge self energy requires separate treatment. |

This register distinguishes exact errors from omissions, modelling limits, intended shorthand and extraction artefacts. No correction has been applied to the original packet. No claims of current-package deficiencies, student performance, or teaching adequacy have been made.

## Boundaries of the present preparation

No assessment tasks were invented. Embedded questions and source worked examples were reconstructed and checked; administrative reminders were recorded. No teaching sequence, hints, learner persona, revision, grade, pass/fail threshold, admission decision, or SASIS conversation was produced. Mathematical checks are focused on concrete source risks: the Laplacian/curvature distinction, curl normal components, the degenerate cube equilibrium, the rectangle limit typo, the Poisson/superposition proof, and the reversed shell integral. No external numerical material properties were used. The package is sealed for later, controlled use only after the future D129 whole freeze.
