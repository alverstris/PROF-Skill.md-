"""D130 source-only technical checks. No student trial or teaching output.

The symbolic premises are supplied by original D130 and the declared baseline.
Numerical geometry values, where used, are analyst-chosen verification values.
No network, external document, or adjacent package is read.
"""
from pathlib import Path
import json
import math
import sympy as sp

OUT = Path(__file__).resolve().parent
Q, q, R, R1, R2, a, b, L, d, A, r, h = sp.symbols(
    'Q q R R1 R2 a b L d A r h', positive=True
)
x, y, z = sp.symbols('x y z', real=True)
s = sp.symbols('s', nonnegative=True)
checks = []

def exact(name, actual, expected, conditions):
    residual = sp.simplify(actual - expected)
    if residual != 0:
        raise AssertionError((name, residual))
    checks.append({
        'name': name,
        'actual': str(sp.simplify(actual)),
        'expected': str(expected),
        'residual': str(residual),
        'conditions': conditions,
        'passed': True,
    })

# 1. Conversion is inferred from the same physical sphere in source and baseline.
eps0_baseline = 8.85e-12
cm_gaussian_in_farad = 4 * math.pi * eps0_baseline * 0.01
assert abs(cm_gaussian_in_farad / 1.11e-12 - 1) < 0.003
checks.append({
    'name': 'one_centimetre_gaussian_capacitance_in_farad',
    'epsilon0_F_per_m': eps0_baseline,
    'capacitance_F': cm_gaussian_in_farad,
    'source_value_F': 1.11e-12,
    'source_rounded_conversion_consistent': True,
    'premises': 'Source C_G=R; baseline C_SI=4*pi*epsilon0*R; 1 cm=0.01 m.',
})

# 2. Isolated-sphere approximation for the two connected spheres.
Q1 = Q * R1 / (R1 + R2)
Q2 = Q * R2 / (R1 + R2)
exact('sphere_partition_total_charge', Q1 + Q2, Q,
      'R1,R2>0; wire charge neglected')
exact('sphere_partition_common_potential', Q1 / R1 - Q2 / R2, 0,
      'Large separation; negligible mutual and wire potential correction')
exact('sphere_surface_density_ratio',
      (Q1 / (4 * sp.pi * R1**2)) / (Q2 / (4 * sp.pi * R2**2)),
      R2 / R1, 'Same isolated-sphere approximation; Q nonzero')

# 3. Spherical shells: radial work and field-energy paths are independent checks.
V_s = sp.integrate(Q / r**2, (r, R1, R2))
C_s = R1 * R2 / (R2 - R1)
exact('spherical_voltage', V_s, Q * (1 / R1 - 1 / R2), '0<R1<R2')
exact('spherical_capacitance', Q / V_s, C_s, '0<R1<R2; Q nonzero')
U_s_field = sp.integrate((Q / r**2)**2 * 4 * sp.pi * r**2 / (8 * sp.pi),
                         (r, R1, R2))
exact('spherical_energy', U_s_field, Q**2 / (2 * C_s), '0<R1<R2')
exact('sphere_outer_radius_infinite_limit', sp.limit(C_s, R2, sp.oo), R1,
      'R1 fixed positive; R2 tends to infinity')
C_gap = sp.simplify(C_s.subs(R2, R1 + d))
exact('spherical_thin_gap_exact_decomposition', C_gap, R1**2 / d + R1,
      'R1,d>0')
exact('spherical_thin_gap_relative_deficit', (C_gap - R1**2 / d) / C_gap,
      d / (R1 + d), 'R1,d>0; leading approximation R1**2/d')

# 4. Coaxial capacitor under infinite/long-cylinder approximation.
E_c = 2 * Q / (L * r)
V_c = sp.integrate(E_c, (r, a, b))
C_c = L / (2 * sp.log(b / a))
exact('coaxial_voltage', V_c, 2 * Q * sp.log(b / a) / L,
      '0<a<b; long concentric cylinders; end corrections neglected')
exact('coaxial_capacitance', Q / V_c, C_c, '0<a<b; L>0; Q nonzero')
U_c_field = sp.integrate(E_c**2 * 2 * sp.pi * r * L / (8 * sp.pi), (r, a, b))
exact('coaxial_energy', U_c_field, Q**2 * sp.log(b / a) / L,
      '0<a<b; L>0; same long-cylinder model')
exact('coaxial_charge_work', sp.integrate(q / C_c, (q, 0, Q)), U_c_field,
      'Fixed geometry and capacitance; quasistatic charging')
exact('coaxial_thin_gap_leading_ratio',
      sp.limit((C_c.subs(b, a + d)) / (L * a / (2 * d)), d, 0, dir='+'),
      1, 'd/a tends to zero from above; a,L fixed positive')

# 5. Parallel plates and independent density accounting for sheet/slab.
E_p = 4 * sp.pi * Q / A
V_p = E_p * d
C_p = A / (4 * sp.pi * d)
exact('parallel_capacitance', Q / V_p, C_p,
      'Vacuum; broad plates; edge fields neglected; A,d>0')
exact('parallel_field_energy', E_p**2 * A * d / (8 * sp.pi),
      Q**2 / (2 * C_p), 'Same model; fixed C')
exact('isolated_slab_versus_total_sheet_density', 4 * sp.pi * Q / (2 * A),
      2 * sp.pi * Q / A,
      'Isolated symmetric slab with charge Q split over two faces, each area A')

# 6. Grounded-plane images: y differentiation and a radial annulus integral.
potential = Q / sp.sqrt(x*x + (y-h)**2 + z*z) - Q / sp.sqrt(x*x + (y+h)**2 + z*z)
exact('image_plane_potential', potential.subs(y, 0), 0,
      'h>0; plane y=0; +Q at y=h, image -Q at y=-h')
E_y_plane = -sp.diff(potential, y).subs(y, 0)
exact('image_plane_normal_field', E_y_plane,
      -2 * Q * h / (x*x + z*z + h*h)**sp.Rational(3, 2),
      'Upper-side limit; Gaussian units; real x,z; h>0')
sigma_radial = -Q * h / (2 * sp.pi * (s*s + h*h)**sp.Rational(3, 2))
induced_charge = sp.integrate(sigma_radial * 2 * sp.pi * s, (s, 0, sp.oo))
exact('total_image_induced_charge', induced_charge, -Q,
      'Infinite grounded plane; annular area 2*pi*s*ds; h>0')

numeric_examples = {
    'status': 'Analyst-chosen verification values, not source data or student tasks.',
    'spherical': {
        'R1': 10.0, 'R2': 10.1,
        'C_exact_gaussian_length_units': 10.0 * 10.1 / 0.1,
        'C_leading_gaussian_length_units': 10.0**2 / 0.1,
        'relative_deficit': 0.1 / 10.1,
    },
    'coaxial': {
        'a': 1.0, 'b': 2.0, 'L': 100.0, 'Q': 3.0,
        'V_gaussian': 2 * 3.0 / 100.0 * math.log(2),
        'C_gaussian_length_units': 100.0 / (2 * math.log(2)),
        'U_gaussian': 3.0**2 / 100.0 * math.log(2),
    },
}
result = {
    'material_id': 'D130',
    'status': 'held_source_only_independent_calculations',
    'external_subject_inputs': [],
    'source_pdf_sha256': '752defdfe953d4cc5eb1239256b41eecaf276a1b416c9458096e81559553a4c3',
    'baseline_sha256': '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5',
    'check_count': len(checks),
    'checks': checks,
    'numeric_examples': numeric_examples,
    'limitations': [
        'Checks establish algebra/calculus within named models, not general finite-edge/end accuracy.',
        'Uniqueness and the electrostatic field-energy identity are source premises, not proved by a few substitutions.',
        'Gaussian and SI charge values are never inserted into one unconverted field equation.',
        'No mesh shielding, breakdown, quantum-capacitance, or dielectric constitutive data were supplied or invented.',
    ],
}
(OUT / 'focused-calculations.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'check_count': len(checks), 'all_completed': True,
                  'output': str(OUT / 'focused-calculations.json')}))
