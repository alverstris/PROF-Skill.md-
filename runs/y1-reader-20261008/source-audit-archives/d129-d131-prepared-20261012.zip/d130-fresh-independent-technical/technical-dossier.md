# D130 — held independent technical dossier

Status: **SEALED PREPARATION; findings held for a future D130 whole freeze.** This is source reconstruction and technical checking only. It is not teaching, a student attempt, a SASIS result, a PROF assessment, an admission decision, or publication. No future trial result is implied. Admission must use the future current package and prompt; this dossier must not be used before the specified whole freeze.

## 1. Evidence boundary and identity

Only two content inputs were accessed:

1. The complete original packet `/workspace/scratch/f9c0b7fc7e76/original-inputs/D130`: original PDF, original identity JSON, nine original page text files, and nine original full-page PNGs.
2. `/workspace/scratch/f9c0b7fc7e76/d015-clean-r36-20261012/inputs/student-baseline.txt`, read completely in bounded untruncated ranges, including Mathematics, Further Mathematics Pure Core, Statistics Y542, Mechanics Y543, Physics, and Chemistry.

Source PDF: 73,305 bytes, SHA-256 `752defdfe953d4cc5eb1239256b41eecaf276a1b416c9458096e81559553a4c3`. Baseline: 247,840 bytes, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`, 2,561 lines. Exact file-level and chunk hashes are in the manifests.

The source identity calls this material D130, session `mit-8-022-fall2004-L06`, lecture number 6. The actual PDF title slide, slide footers, source filename provenance, and PDF metadata identify **8.022 (E&M), Lecture 5**, G. Sciolla, MIT. Its PDF metadata title is `Microsoft PowerPoint - Lecture5.ppt`; the author field is `sciolla`. This is a numbering discrepancy between the packet's session label and the published document, not a reason to substitute another lecture. The supplied source URL ends in `lecture5.pdf`; it was treated as identity metadata and was not opened. Embedded repository references and acquisition paths were also not followed.

There are nine physical PDF pages with two slides each on pages 1–8 and slide 17 alone on page 9. The page PNGs are all 1224 × 1584 pixels. All nine PNGs were individually emitted/viewed with `detail="original"`; no montage or extraction-only proxy substituted for them. The original nine text extractions were read in full, and fresh PyMuPDF extraction from the original PDF matched each supplied text file exactly. No pages or original data needed regeneration. Original input files were not changed.

The only baseline access irregularity was an initial combined lines 611–830 display that was truncated by the tool wrapper. It does **not** count as complete coverage. It was repaired by full, independently bounded displays of lines 611–724 and 725–830. All other declared ranges were untruncated. The coverage manifest records the successful ranges, not an inference of reading from searches.

## 2. Conventions and interpretation control

The source uses electrostatic **Gaussian/cgs** formulae: point/spherical potential proportional to `Q/r`, Gauss flux `4πQ`, conductor exterior normal field `4πσ`, and field energy density `E²/(8π)`. It explicitly calls the cgs capacitance unit a length. The baseline Physics equations use **SI** with `1/(4πε₀)` and capacitance in farads. Those two conventions must not be combined in one substitution without translation.

Throughout this reconstruction, unqualified source equations remain Gaussian. SI counterparts are marked explicitly and follow the baseline SI Coulomb/potential/capacitance expressions. A Gaussian capacitance value expressed as a length in metres has corresponding SI capacitance `4πε₀` times that length. A source length in centimetres must first be converted to metres. With the baseline value `ε₀ = 8.85 × 10⁻¹² F m⁻¹`, one centimetre of Gaussian capacitance is approximately `1.1121 × 10⁻¹² F`, consistent with source slide 9. The source's conversion is **not** a factor-of-ten error.

Notation requires local interpretation:

- `φ` is scalar electric potential; `Φ_E` is electric flux. `V` is a potential difference except in the integration element `dV`, where it means volume. These are different quantities.
- `Q` is the final magnitude of equal opposite conductor charges, and `q` is the variable charge during charging. Surface density `σ` is charge per surface area; volume density `ρ` is charge per volume. These symbols are not the baseline stress, mass density, resistivity, or Stefan constant in this context.
- `R`, `R₁`, `R₂`, `a`, `b`, `d`, `L` and `r` denote geometric lengths. The coaxial logarithm is `ln(b/a)`, a dimensionless ratio. `C` is capacitance, not a coulomb unit symbol or the closed contour label in Stokes' theorem.
- A line element in a potential integral is a directed displacement. A surface element in Gauss' law is an oriented area element. The source's use of a similar `ds` symbol in both contexts must not identify their dimensions.
- `E_surface = 4πσ` means the **normal component immediately outside a smooth conductor surface**, with the normal pointing from conductor into vacuum and the field inside the conductor zero. The vector relation is `E_out = 4πσ n̂`; a negative surface charge reverses the field. It is not a formula for a field value inside the conducting material or an average exactly across a discontinuity.
- Positive capacitance convention is `V = φ_positive − φ_negative > 0`, `Q > 0`, and `C = Q/V > 0`. Source slide 8 defines `V = φ₂ − φ₁` without labeling its conductor drawings 1 and 2. Assigning conductor 2 as the positive one resolves this; the later integrations use the positive-minus-negative convention.

The default physical regime for all of the conductor assertions is electrostatic equilibrium, with rigid fixed geometry and vacuum/air modeled as vacuum. Empty cavities are charge-free. Linear capacitance also requires that material response and geometry not change with charging. The source's schematic cylinders and plates require separate idealization conditions described below.

## 3. Complete page and slide reconstruction

### Physical page 1 — slides 1 and 2

**Slide 1:** Title `8.022 (E&M) – Lecture 5`; topics are more on conductors, many demonstrations, and capacitors. There is no exercise or derivation on this title slide. The design is a bordered white slide, red title, a gray horizontal divider, and blue topic text.

**Slide 2, “Last time…”:** The recap displays curl as `curl F = ∇ × F`; Stokes' theorem as a circulation around `C` equaling the surface integral of curl over `A`; electrostatic `∇ × E = 0`; the Laplacian definition `∇²φ ≡ ∇·∇φ`; Poisson `∇²φ = −4πρ`, followed by Laplace `∇²φ = 0` under a label “in vacuum”; conductor free electrons, internal zero field, `E_surface = 4πσ`, normal field lines/equipotential surfaces, and a uniqueness theorem for specified charge density and boundary conditions.

These are recaps, not operational derivations. Stokes' theorem does not by itself imply zero electric curl: electrostatic zero circulation/conservative-field input is also required. Laplace follows when **ρ = 0 in the region**, not merely from the word vacuum if charges remain in that vacuum. The stated uniqueness result is appropriate when the boundary data actually fix the potential, such as Dirichlet values plus an infinity condition for an unbounded region. Pure normal-derivative data leave an additive potential constant unless a reference is fixed. Conductors carrying steady currents are outside the equilibrium `E = 0` assertion.

The source does not give coordinate definitions of gradient, divergence, curl or the Laplacian, a definition of oriented surface integration, a proof of Stokes, or a proof of uniqueness. No earlier lecture was accessed to fill those omissions.

### Physical page 2 — slides 3 and 4

**Slide 3, charge distribution on a conductor:** A tear-drop-shaped conductor receives charge Q. The first sketch distributes plus symbols roughly evenly and has a question mark; the second concentrates the symbols near its acute tip and has an exclamation mark. The reported experimental answer is nonuniform distribution, `σ_tip ≫ σ_flat`, from demonstration D28. Since the conductor is equipotential but its exterior surface field is `4πσ`, the tip field is correspondingly larger. This is a source-reported demonstration claim; no measured data or demonstration execution is present in the packet.

**Slide 4, connected spheres:** The schematic shows a large green sphere of radius R₁ connected by a thin line to a small green sphere of radius R₂, with `R₁ ≫ R₂`. Charge is deposited and redistributes until the potential is common. The displayed approximation is

`φ₁ = Q₁/R₁ = Q₂/R₂ = φ₂`,

`E₁ = Q₁/R₁² = φ₁/R₁`, `E₂ = Q₂/R₂² = φ₂/R₂`,

giving `E₁/E₂ = R₂/R₁` and `σ₁/σ₂ = R₂/R₁`.

Under this model and total `Q₁ + Q₂ = Q`, reconstruction gives `Q₁ = QR₁/(R₁+R₂)` and `Q₂ = QR₂/(R₁+R₂)`. The larger sphere holds more total charge but has less surface density and weaker local surface field. That distinction is the point of the example.

The equality of conductor potentials is exact in electrostatic equilibrium; the individual `Q_i/R_i` formula is an **isolated-sphere approximation**. A second charged sphere and connecting wire contribute to the potential and distort each surface distribution. The displayed model needs sphere separation large compared with their radii, an effectively negligible wire contribution, and negligible external influence. `R₁ ≫ R₂` alone does not establish those conditions. The drawing does not establish a numerical large-separation limit. “Electric field is stronger where curvature (1/R) is larger” is a useful trend for this controlled comparison and the tear-drop example, not an exact local law `E ∝ curvature` for every conductor in an arbitrary surrounding charge configuration. Demo D29 is named as lightning with a Van de Graaff apparatus; no quantitative breakdown law is supplied.

### Physical page 3 — slides 5 and 6

**Slide 5, shielding:** An irregular green conductor surrounds a white oblong cavity labeled `E = 0`. The statement “in a hollow region inside a conductor E = 0” is the basis of shielding. It is valid for an **empty/charge-free cavity entirely enclosed by an equilibrium conductor**. A cavity containing a charge need not have zero field. The theorem follows in that empty domain from the constant boundary potential and the uniqueness of the constant solution of Laplace's equation; the source relies on the earlier recap rather than proving it here.

The slide asks whether a solid conductor is needed or a mesh suffices, names demo D32 (Faraday cage in Van de Graaff), and asks whether shielding is perfect. It does **not answer** the mesh/perfection questions. An apertured boundary is not the same closed equipotential boundary as the empty-cavity idealization. No mesh dimensions, distance from apertures, geometry, frequency, or tolerated residual field are supplied, so quantitative leakage or universal perfect-mesh shielding cannot be reconstructed from this packet. The static closed-cavity conclusion must not be extended unqualified to arbitrary time-dependent fields.

**Slide 6, method of images setup:** A positive point charge at a distance `y` from an infinite conducting plane induces negative surface charge. The drawing has a horizontal green conductor bar, evenly spaced minus symbols as a schematic sign indication, and curved field lines running from the point charge to the plane, meeting it perpendicularly. “Radial around the charge” means local point-charge behavior near the singular source, not a claim that the total field remains globally radial in the presence of the conductor. The question is the electric potential caused by the point charge plus induced conductor response.

This slide initially does not say “grounded.” The next slide explicitly imposes `φ = 0` on the plane. Thus the reconstructed problem is the grounded/zero-potential infinite-plane boundary problem, with potential also tending to zero far away. An arbitrary isolated finite conductor or a differently biased boundary is not the same problem.

### Physical page 4 — slides 7 and 8

**Slide 7, image construction:** The figure adds a mirror negative charge below the plane to the real positive charge above. Symmetric curved field lines join the two charges and cross the plane normally. The lower charge is mathematical, and the source explicitly says the lower region is not under study. There is no physical negative point charge in the conducting interior. The desired upper-half-space field is obtained from the two-charge potential, justified by uniqueness.

To remove the collision between the source's distance `y` and coordinate `y`, put the plane at `y = 0`, the real charge at `(0,h,0)` with `h > 0`, and its image `−Q` at `(0,−h,0)`. In Gaussian units the reconstruction is

`φ(x,y,z) = Q/[x² + (y−h)² + z²]^(1/2) − Q/[x² + (y+h)² + z²]^(1/2)`,

on `y > 0`, excluding the actual charge location. At `y = 0` the distances are equal, so φ vanishes. At large distance φ tends to zero. The image is outside the physical solution domain. The solution has the correct real-charge singularity and no extra upper-half-space charges. These facts, together with the same Poisson/Laplace equation and the specified boundary data, warrant uniqueness. **Matching boundary conditions alone is not enough for an arbitrary trial function**; the source's shorthand requires the same governing equation and charge distribution in the domain.

The SI counterpart is the entire expression multiplied by `1/(4πε₀)`. From one-variable differentiation in y at fixed x,z, the upper normal field at the plane is `E_y(0+) = −2Qh/(x²+z²+h²)^(3/2)`. The source boundary rule then gives `σ = −Qh/[2π(x²+z²+h²)^(3/2)]`. Its sign is negative everywhere for Q positive, its magnitude is greatest beneath Q, and it is **not uniform**, despite the schematic regular minus symbols. Integration over circular annuli gives total induced charge `−Q` for this infinite grounded-plane idealization. The explicit potential and density are independent technical reconstructions, not equations printed in slides 6–7.

**Slide 8, definition of capacitance:** Two irregular conducting shapes are drawn with `+Q` and `−Q`. Each is equipotential, but their potentials differ. The displayed potential difference is `V ≡ φ₂ − φ₁ = −∫₁² E·ds = Q × (constant depending on geometry)`, then the constant is named `1/C`, giving `Q = CV`. A capacitor is described as two oppositely charged conductors; C is the system capacitance.

For fixed geometry in a linear vacuum model, scaling the charges by λ scales the electrostatic solution and potential difference by λ; uniqueness selects that scaled solution. Consequently V is proportional to Q and C is independent of Q. This does not require a spatially uniform surface charge density. The density may vary strongly around the conductors while its entire pattern scales linearly.

There is a genuine source error in the literal caveat: **“C is proportional to Q only if there is enough Q, uniformly spread…”** This conflicts with `Q = CV` and with slide 12's explicit statement that C depends on geometry, not deposited charge or voltage. Replacing C with V repairs only the first defect; uniform spreading is still not a condition for linear macroscopic capacitance. Discreteness and failure of a macroscopic continuum approximation can require more detailed physics, but the source provides none, and cannot make this printed caveat a valid statement of the displayed electrostatic model.

### Physical page 5 — slides 9 and 10

**Slide 9, units:** `C = Q/V`; SI farad = coulomb/volt; Gaussian capacitance has dimensions of length, expressed as `cm = esu/(esu/cm)`. The conversion `1 cm = 1.11 × 10⁻¹² F ≈ 1 pF` is consistent with the baseline SI sphere formula and ε₀. “1 coulomb is a big charge,” “1 farad is a big capacitance,” and “usual C ~ pF–μF” are qualitative scale/context comments, not exclusive bounds on possible devices.

**Slide 10, isolated sphere:** A conducting sphere of radius R at the origin carries Q. The drawing shows its radius and coordinate axes; it is not an off-centre-charge problem. The review questions ask where charge is located, whether hollow or solid matters and why, and the field everywhere. For an isolated spherical conductor with no internal cavity charge and no external field, rotational symmetry gives uniform charge density on the exterior: `σ = Q/(4πR²)`. A solid conductor has E = 0 inside; a hollow sphere also has zero field in an empty enclosed cavity and in its conducting material. Outside, `E = (Q/r²) r̂` for `r > R`. The surface field has different one-sided limits; assigning the exterior limit as the interior value is incorrect.

With `φ(∞)=0`, `φ(r)=Q/r` outside and `φ=Q/R` throughout the interior, yielding `V = φ_R − φ_∞ = Q/R` and Gaussian `C_sphere = R`. “Infinity” is called a virtual second conductor. It is a reference/limiting construction for self-capacitance rather than a finite physical electrode. The SI result `4πε₀R` is already explicit in the baseline. Neighboring conductors or an imposed nonspherical field would invalidate the isolated uniform-charge distribution and change self-capacitance relative to the environment.

### Physical page 6 — slides 11 and 12

**Slide 11, parallel plates:** The diagram shows broad parallelogram plates of area A separated by d, top positive Q, bottom negative Q, and downward field arrows in the gap. The source explicitly gives `d² ≪ A` as an approximately infinite-plane criterion. For ordinary compact plate shapes this summarizes “separation much smaller than lateral dimensions”; for a very narrow strip, area alone is not enough to ensure both transverse dimensions are large compared with d. The intended approximation neglects edge fields.

The inner-face density is `σ = Q/A`, gap field `E = 4πQ/A`, and positive voltage is `φ_top − φ_bottom = ∫_top^bottom E·ds = 4πQd/A`. A plus sign in this top-to-bottom field integral is correct: the direction follows the field, but V is the **potential drop** rather than final-minus-initial potential. Then `C = A/(4πd)`. The SI results are `E = Q/(ε₀A)`, `V = Qd/(ε₀A)`, `C = ε₀A/d`, all within the same edge-free vacuum model.

**Slide 12, discussion and factor-of-two issue:** The source states that C depends on geometry, not on Q or V. It asks whether conductor-surface field is `2πσ` or `4πσ`. Its two comparison drawings contain plus signs only: one is a thin nonconducting charge plane; the other is a conducting slab with charge on two faces. These are illustrations explaining density conventions, not depictions of a positive/negative plate pair.

Three distinct cases must remain separate:

| Case | Meaning of density | Exterior/gap field in Gaussian units |
|---|---|---|
| Infinite infinitesimal sheet carrying total sheet density s | s is charge per area of that single sheet | `2πs` on each side, directed away for s positive |
| Isolated symmetric conducting slab with total Q over two faces of area A | Each face has `σ_face = Q/(2A)` | At either exterior face `4πσ_face = 2πQ/A`; internal field is zero |
| Equal opposite ideal capacitor plates | Each facing surface has `σ_inner = Q/A`; outer faces carry zero in the ideal limit | Gap `4πQ/A`, exterior zero |

The slide's `σ=Q/(2A)` conductor statement belongs to the **isolated two-face slab** comparison. Applying it to the facing surface of a capacitor would introduce a false factor of two. The compact source notation reuses σ across different meanings, and its red `E=2πσ` label must be read against the total sheet-density comparison. The numerical field laws can be consistent; this is a scope/notation hazard, not a license to change the capacitor answer.

The slide ends with “E outside the capacitor? Zero!” This is exact for the infinite equal-opposite-plane model. Finite plates have fringing fields, so zero outside is not an exact global claim about the pictured finite object.

### Physical page 7 — slides 13 and 14

**Slide 13, nested spherical shells:** The schematic contains concentric circles, the inner sphere marked Q₁ and outer Q₂, with radial outward arrows only in the intervening annulus. The stated charges are inner `+Q` and outer `−Q`, radii `0 < R₁ < R₂`. It asks for fields in `r<R₁`, `R₁<r<R₂`, `r>R₂`, and supplies the Gauss-law solution.

The complete intended result is

`E = 0` for `r<R₁`,

`E = (Q/r²) r̂` for `R₁<r<R₂`,

`E = 0` for `r>R₂`.

Spherical symmetry permits constant radial E on a concentric Gaussian sphere: `Φ_E = E(4πr²) = 4πQ_enclosed`. Zero enclosed charge by itself implies zero **net flux**, not zero field for an arbitrary charge arrangement. It gives zero E here because of symmetry and the absence of an imposed external field. The inner empty cavity also has a constant potential. For physically thick conducting shells, R₁ and R₂ in the gap formula mean the facing outer/inner surface radii; conducting thickness is not part of the vacuum gap.

With the outer conductor's net charge exactly −Q, its inner face carries −Q and its outer face zero in the concentric ideal arrangement. The inner +Q lies on its exterior face when its cavity is empty. If net charges were not equal opposite, the outside field and reference potential would change, so the zero-exterior result must not be carried over silently.

**Slide 14, capacitance:** It uses `V = φ₁ − φ₂ = −∫_(R₂)^(R₁) E·ds = Q/R₁ − Q/R₂`. Both the minus sign and reversed radial limits are required to give positive voltage. Thus `C = R₁R₂/(R₂−R₁)`. With `φ(∞)=0`, the outer region and outer conductor have φ = 0; in the gap `φ(r)=Q/r−Q/R₂`; the inner conductor and cavity have constant `Q/R₁−Q/R₂`.

For `d=R₂−R₁` small compared with either radius, `C ≈ R₁²/d = (4πR₁²)/(4πd) = A_inner/(4πd)`, matching the locally parallel-plate result. More exactly, putting `R₂=R₁+d` gives `C = R₁²/d + R₁`. The leading approximation's fractional deficit relative to exact C is `d/R₂`. The printed condition ends `d << R₂ → 0`; its limiting notation is compressed/ambiguous. The useful condition is `d/R₁ → 0` (or equivalently `d/R₂ → 0`), not an unexplained demand that the sphere radius itself vanish. No numerical gap is supplied. Taking `R₂→∞` recovers the isolated-sphere capacitance R₁.

### Physical page 8 — slides 15 and 16

**Slide 15, capacitor energy:** The drawing shows a positive plate on the left, negative plate on the right, and a small positive charge moved leftward against the field. During quasistatic charging the plates hold ±q. Bringing `dq>0` from the negative to the positive plate requires external work `dW = V(q)dq = (q/C)dq`. The moving charge changes the capacitor's separated charge; it is not a computation holding the final voltage fixed throughout.

For fixed C, integration from uncharged `q=0` to `q=Q` gives `W=Q²/(2C)`, stored energy `U=Q²/(2C)=CV²/2=QV/2`. Work by the electric field during this charging transfer is the negative of this external work. Dissipation, radiation, deformation, dielectric nonlinearity, and energy exchange with a fixed-voltage source during a geometry change are not included in this derivation. Baseline Physics already supplies the same capacitor-energy relations and the distinction between fixed Q and fixed V.

The slide checks the result against `U = (1/8π)∫E² dV`. For ideal parallel plates E is uniform in volume Ad and zero outside, giving `U=E²Ad/(8π)=2πQ²d/A=Q²/(2C)` using `E=4πQ/A` and `C=A/(4πd)`. The general energy-density identity is new source-supplied content; integrating a constant over the already known volume Ad can be reduced to ordinary multiplication without assuming arbitrary multivariable integration.

The notational `∫₀^Q dW` is shorthand for accumulating work while q varies from 0 to Q; the following `∫₀^Q(q/C)dq` makes the actual variable explicit. There is no reason to treat this shorthand as a second mathematical error.

**Slide 16, cylindrical capacitor:** The picture shows concentric inner and outer cylindrical conductors of radii a and b, finite indicated length L, plus symbols on the inner and minus symbols on the outer. The source requests the field, voltage, capacitance, and energy and prints all results.

For `0<a<b`, equal opposite charges ±Q over length L, and an effectively infinite or sufficiently long coaxial arrangement away from ends, cylindrical symmetry yields radial gap field. A concentric Gaussian cylinder has lateral area `2πrL`, vanishing end flux in the translationally invariant ideal model, and `E(2πrL)=4πQ`, hence `E(r)=2Q/(Lr) r̂`. It is zero inside the empty inner region and outside the equal-opposite pair **within that same idealization**. A finite open coaxial object can have end fields; the slide does not supply an aspect ratio or state this limitation.

Taking `V=φ_inner−φ_outer`, `V=∫_a^b E dr=(2Q/L)ln(b/a)`. Therefore `C = L/[2ln(b/a)]`, and `U = Q² ln(b/a)/L`. Since b/a > 1 the logarithm, capacitance, voltage for Q positive, and energy are positive. Swapping the radii or taking `ln(a/b)` without changing the voltage convention would violate the physical setup. A valid arbitrary reference is `φ(b)=0`, giving gap `φ(r)=(2Q/L)ln(b/r)`.

The SI forms are `E=Q/(2πε₀Lr)`, `C=2πε₀L/ln(b/a)`, and `U=Q²ln(b/a)/(4πε₀L)`. Another direct check integrates the source energy density through annular shells with volume `2πrL dr`: `(1/8π)∫_a^b [2Q/(Lr)]²(2πrL)dr = Q²ln(b/a)/L`. The thin-gap limit `b=a+d`, `d/a≪1`, gives `C≈La/(2d)=A_inner/(4πd)`, consistent with the preceding geometries.

### Physical page 9 — slide 17

“Next time…” lists more capacitors, charges in motion/currents, possible help for quiz 1, and review of electrostatics. This is an agenda, not supplied current theory or an actual quiz. The lower half of the physical page is blank. No additional slide 18 or concealed exercise was inferred.

## 4. Source-error and condition register

The categories below deliberately distinguish false printed claims from valid formulae whose conditions or notation are compressed.

| ID | Location | Status | Technical finding and necessary resolution |
|---|---|---|---|
| E01 | p4/s8 caveat | Confirmed substantive error | `C proportional to Q` conflicts with `Q=CV`, the stated fixed geometry, and s12. The proportional pair is V and Q. Uniform spreading is not required for linear capacitance. |
| C01 | p1/s2 Stokes arrow | Missing premise | Stokes plus electrostatic zero circulation yields zero curl. Stokes alone does not set a general vector field's curl to zero. |
| C02 | p1/s2 Laplace arrow | Missing charge-free qualification | ρ=0 in the domain is the sufficient displayed condition; “vacuum” alone is not a prohibition on charges. |
| C03 | p1/s2 uniqueness; p4/s7 | Compressed theorem | Same governing equation and charge distribution, correct singularities, complete boundary data and reference/infinity behavior are required. A trial merely vanishing on the plane is not enough. |
| C04 | p2/s4 connected spheres | Unstated approximation | `φ_i=Q_i/R_i` neglects the other sphere and wire; large separation and negligible connecting-wire effect are required. The resulting curvature trend is not a universal exact local law. |
| C05 | p3/s5 shielding | Essential domain condition omitted from sentence | The cavity must be charge-free and completely enclosed in an equilibrium conductor. The mesh question is unanswered, not an established perfect-shielding result. |
| C06 | p3/s6 to p4/s7 | Boundary condition becomes explicit only on s7 | Read the plane as grounded/zero potential with proper far boundary behavior; do not silently substitute an isolated finite conductor. |
| C07 | p4/s8; p6/s11 | Sign convention requires alignment | V must be positive-plate minus negative-plate potential; the top-to-bottom field integral is a potential drop. No unavoidable contradiction is present. |
| C08 | p6/s11 | Shape qualification | `d²≪A` is a compact-plate proxy. Separation must be small compared with relevant lateral dimensions, and observation should avoid edges. |
| C09 | p6/s12 | Density/context ambiguity | `Q/2A` describes two faces of an isolated symmetric slab; facing capacitor surfaces use `Q/A`. Distinguish these cases before applying 2π and 4π. |
| C10 | p6/s12; p8/s16 | Idealization limit | Zero exterior field holds exactly only in the stated infinite/symmetric models; finite edges and ends produce corrections. |
| C11 | p7/s13 | Symmetry warrant | Zero enclosed charge implies zero flux; concentric symmetry is additionally needed for the displayed zero field inference. |
| C12 | p7/s14 | Ambiguous limiting notation | Small dimensionless gap/radius is the relevant limit; `R₂→0` is not independently required. |
| C13 | p8/s15 | Charging model condition | C fixed and charging quasistatic; external work sign and variable q distinguish the calculation from fixed final V work. |
| C14 | Multiple pages | Boundary values | Ideal surface fields require one-sided limits; electrostatic conductor assertions do not cover steady conduction or arbitrary time variation. |

Two positive controls prevent overdiagnosis: the cgs-to-SI `1 cm ≈ 1 pF` conversion is correct; the parallel-plate top-to-bottom integral's positive sign is correct for the declared voltage drop. Likewise the spherical and cylindrical printed capacitance and energy formulae are algebraically consistent under their intended idealizations.

## 5. Prerequisite warrants from the complete combined baseline

These warrants concern permitted starting premises and the source's actual supplied extensions. They are not judgments of any student's performance or a completed teaching assessment.

| Technical operation | Explicit baseline warrant | Source extension or residual condition |
|---|---|---|
| Algebraic ratios, rearranging C=Q/V, consistent units | Mathematics lines 36–48, 72–108; Physics 879–887; Chemistry 1430–1446 | Gaussian/SI normalization must be identified from source. Dimensional agreement cannot fix an omitted 4π. |
| Sphere/cylinder geometry | Mathematics line 48; Physics line 867 | Oriented differential area and Gaussian surfaces are not the same as knowing total area. |
| Vector direction, radial unit vectors, dot product | Mathematics 442–450; FM18 at 713; FM17 at 711; Physics 895 and 1269 | FM19 gives a cross-product component rule, but does not grant curl or an area-vector integration calculus. |
| Single-variable powers and logs | Mathematics 240–248, 268–308, 336–386 | `∫r⁻²dr`, `∫dr/r`, `∫q dq`, and field paths reduced by symmetry are ordinary allowed calculations. |
| Infinity and limiting cases | Mathematics 132, 336; FM28 at 733; FM27 at 731 | A simple improper radial integral and a small-gap expansion can be derived; arbitrary PDE boundary theory cannot be imported from the word limit. |
| Work and potential-energy signs | Physics 1037, 1077, 1269–1273; FM58 at 797 | Baseline gives 1D variable-force work and potential energy. A fully general path integral of a vector field is new source notation; the selected paths reduce to 1D integrals. |
| SI electrostatics and superposition | Physics 1269–1277 | Point-charge potential/field, scalar potential addition, vector field addition, uniform plate field, sphere exterior and sphere capacitance are already explicit. Gaussian factors come from source, not assumed prior SI knowledge. |
| Capacitor definition and energy | Physics 1253–1257, 1277 | C=Q/V, energy formulae, parallel plates and isolated-sphere SI capacitance are already granted. Nested shell/coaxial derivations and field-energy density extend them. |
| Mobile electrons in a conductor | Physics 1073, 1085; Chemistry 1572, 1576 | These support the physical possibility of charge redistribution. They do not alone grant the full electrostatic conductor boundary theorem or cavity shielding theorem. |
| Local induction/negative surface response | Physics point-charge force/sign at 1269; conductor mobile charges at 1073; Chemistry 1572 | Quantitative image-charge method additionally needs the source uniqueness and boundary claims. |
| Gauss' law and flux | No general electric-flux/Gauss theorem in baseline; Physics 1293 covers only uniform magnetic flux through a flat area | Source s13 supplies `Φ_E=4πQ_enc` and the spherical reduction; s16 uses the cylindrical reduction. Their general geometric/field-theory meaning remains a source extension. |
| Gradient, divergence, curl, Poisson/Laplace, Stokes, uniqueness | FM69 at 819 and Physics 1381 expressly exclude these as prior formalism | Source s2 states relationships as recap, not operational definitions/proofs. Partial differentiation or a full theorem proof cannot be silently credited to baseline. |
| General field-energy integral | Baseline capacitor energy at Physics 1257; ordinary integration in Mathematics | Source s15 supplies `E²/(8π)`. Constant-volume and annular/spherical-shell reductions can be explicit source-plus-geometry deductions. Arbitrary multiple integration is not granted. |

The complete **Further Mathematics Statistics Y542** section (FM37–FM56, lines 751–791) was read. It grants counting, expectation, density integration and statistical inference under stated conditions. It does not supply electric flux, vector calculus or a uniqueness theorem. A probability-density integral is not evidence of prior mastery of electromagnetic surface/volume integrals. No statistical technique is required for the deterministic examples in this lecture; the named demonstrations contain no numerical dataset for inference.

The complete **Further Mathematics Mechanics Y543** section (FM57–FM68, lines 793–817) was read. Dimensions, work as a dot product for constant forces, one-dimensional variable-force integration, conservative-energy accounting and elementary constrained motion are available. Its explicit caveat excludes a general multidimensional variable-field line integral as prior knowledge. That boundary matters for the notation `∫E·ds`, even though the sphere, parallel-plate and coaxial paths here admit one-dimensional reductions.

The complete **Chemistry** section (lines 1391–2561) was read, including its physical-chemistry, organic, spectra and practical sections. Metallic bonding and delocalised carriers are the directly relevant premises. Dipole polarity, ion attraction and electrolyte charge motion are compatible background but do not select a Gaussian unit system or supply conductor boundary conditions. Chemical Gibbs/entropy and equilibrium expressions are not a route to the lecture's field-energy functional. The practical distinctions among observation, model, accuracy and uncertainty reinforce that D28/D29/D32 labels are source reports, not independently observed data. No unrelated chemistry knowledge was silently converted into an electromagnetic theorem.

The complete **Mathematics** and **Physics** sections were read, including probability/mechanics, waves/quantum, thermal, astronomy, nuclear/medical, and practical material. Their broad exposure is preserved. Nevertheless labels such as field, flux, energy and differential equation do not add formal rules beyond the operational entries. Conversely, capacitor energy and the SI sphere/plate formulas must not be treated as wholly new merely because they appear in an undergraduate lecture.

## 6. Independent reconstructions and focused calculations

`focused-calculations.py` and its output implement a small set of source-relevant checks using permitted formulas and algebra/calculus. They are not a general test suite or an assessment attempt:

1. Gaussian-to-SI centimetre capacitance conversion from the baseline ε₀ and source sphere relation.
2. Connected-sphere charge partition and the distinction between total charge and surface density under the stated isolated-sphere approximation.
3. Spherical voltage, capacitance, energy, isolated-sphere limit and quantified thin-gap deficit.
4. Coaxial voltage, capacitance, energy and agreement with the field-energy integral.
5. Parallel-plate voltage/capacitance/energy consistency and the independent sheet-versus-surface-density factor of two.
6. Image potential boundary cancellation, normal surface field/density and total induced charge by an annular one-variable integral.

All example numeric values in that file are **analyst-chosen verification values**, not invented source data. They are explicitly labeled as such and do not create new exercise claims. Exact symbolic expressions and sign/domain conditions are primary. No dielectric data, breakdown voltage, mesh leakage constants or end corrections were fabricated.

## 7. Closure and access discipline

Complete source coverage comprises all 17 slides, all nine physical pages, all original text and all native page images. The dossier reconstructs every source example and question, including the unanswered mesh questions and the end-of-lecture agenda. It does not infer an unseen quiz, demonstration measurement, earlier lecture proof, or later continuation.

No web, browser, author contact, personal history, other material packet, PROF package, queue, previous preparation, prior trial/report, or adjacent workspace content was used. Input URLs and paths were recorded only as inert provenance. No generated teaching, student simulation, evaluation score, or publication was made. The seal binds the original-input hashes, full baseline hash, coverage manifest, technical dossier and focused calculation record. Findings remain held pending the future D130 whole freeze and prompt-only admission.
