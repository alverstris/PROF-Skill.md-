"""D131 independent source-derived arithmetic; stdlib only; no external inputs."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/f9c0b7fc7e76/original-inputs/D131')

def record(x):
    return {'exact': str(x), 'decimal': float(x)}

C_wire = Fraction(100, 1_000_000)
V_wire = 4000
C_bank = 12 * Fraction(80, 1_000_000)
R_rated_model = Fraction(120**2, 60)
bank = []
for voltage in (100, 200, 300):
    bank.append({
        'V_initial_V': voltage,
        'energy_J': record(C_bank * voltage**2 / 2),
        'charge_C': record(C_bank * voltage),
        'current_A_if_constant_rated_R': record(Fraction(voltage) / R_rated_model),
        'power_W_if_constant_rated_R': record(Fraction(voltage**2) / R_rated_model),
        'energy_and_initial_power_ratio_to_100_V_if_same_R': record(Fraction(voltage**2, 100**2)),
        'power_ratio_to_60_W_if_constant_rated_R': record(Fraction(voltage**2, 120**2)),
    })

results = {
    'scope': 'Original D131 packet only; derived values are explicitly distinct from printed values.',
    'wire_example': {
        'capacitance_F': record(C_wire),
        'voltage_V': V_wire,
        'energy_J': record(C_wire * V_wire**2 / 2),
        'charge_C': record(C_wire * V_wire),
        'printed_800_J_verified': C_wire * V_wire**2 / 2 == 800,
        'wire_explosion_prediction': 'Not numerically determined by the supplied length alone.'
    },
    'bank_example': {
        'capacitance_F': record(C_bank),
        'capacitance_uF': record(C_bank * 1_000_000),
        'printed_960_uF_verified': C_bank * 1_000_000 == 960,
        'rated_operating_resistance_ohm_derived_from_120V_60W': record(R_rated_model),
        'tau_s_if_that_resistance_is_constant': record(C_bank * R_rated_model),
        'voltage_cases': bank,
        'fixed_fraction_discharge_time': 't = R C ln(1/f), independent of V_initial for constant R,C',
        'fixed_absolute_threshold_discharge_time': 't = R C ln(V_initial / V_threshold), dependent on V_initial',
        'real_lamp_dynamics': 'No resistance law or thermal data are supplied.'
    },
    'source_sha256': {
        str(p.relative_to(SOURCE)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(SOURCE.rglob('*')) if p.is_file()
    }
}
assert results['wire_example']['printed_800_J_verified']
assert results['bank_example']['printed_960_uF_verified']
assert [v['energy_J']['exact'] for v in bank] == ['24/5', '96/5', '216/5']
assert [v['energy_and_initial_power_ratio_to_100_V_if_same_R']['exact'] for v in bank] == ['1', '4', '9']
(HERE / 'results.json').write_text(json.dumps(results, indent=2) + '\n')

