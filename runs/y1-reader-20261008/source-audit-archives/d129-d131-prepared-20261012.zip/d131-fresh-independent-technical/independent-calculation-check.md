# D131 independent calculation check — held technical record

Status: local, independent, source-only technical findings. No teaching work, prerequisite claims, SASIS analysis, or publication. Semantic content is held for the future D131 whole freeze.

## Inputs and method

The only documentary input was `/workspace/scratch/f9c0b7fc7e76/original-inputs/D131`: the original 13-page packet, its extracted page text, and original full-page PNGs. All 13 PNGs were visually inspected, including equations and diagrams. No outside workspace files, previous preparation, history, skills, or web sources were consulted. Source file hashes are recorded by `calculations.py` in `results.json`. Python standard-library arithmetic and hashing were used only as runtime facilities.

Locations below use **PDF page / printed slide**. Each PDF page contains two slides. “Direct” means an arithmetic, algebraic, or logical consequence of printed equations or an inconsistency visible in the source. “Conditional” identifies an assumption required for the statement; it does not assert that the demonstration failed experimentally. Reconstructed formulas are reviewer deductions and are not represented as additional printed source content.

## Unit convention and reconstructed formula audit

The symbolic electrostatic formulas consistently use the convention with Coulomb constant equal to one: `F = q1 q2 r_hat/r²`, `div E = 4πρ`, and energy density `E²/(8π)`. These are mutually consistent Gaussian electrostatic formulas. The capacitor demonstrations use farads, volts, joules, and watts. Their numerical energy arithmetic is consistent in SI. This is a change of unit convention within the packet, not a factor-of-4π error in the printed formulas. Geometric capacitance formulas must not be combined numerically with the SI example inputs without a consistent unit conversion.

| Location | Reconstructed formula | Independent result and necessary scope |
|---|---|---|
| p.1/s.2; p.13/s.25 | `C = Q/V`; `U = Q²/(2C) = CV²/2` | Algebraically consistent for a two-terminal capacitor with a fixed linear capacitance, with Q the magnitude on either conductor and V the potential difference. From charging work, `U = integral_0^Q V(q) dq`; the printed quadratic forms follow when `V(q)=q/C`. |
| p.3/s.5; p.5/s.9 | `E = 4πσ`; `C = Q/V = Q/(Ed) = A/(4πd)` | Correct for the ideal vacuum parallel-plate interior, negligible edge effects, and `σ=Q/A`. The depicted dielectric contribution must be distinguished from the bare/free-charge field: after polarization, the total gap field is reduced at fixed Q. |
| p.4/s.7 | `V=V1+V2`; `Q=Q1=Q2`; `1/C=1/C1+1/C2`; `C=(sum_i 1/C_i)^(-1)` | Correct ideal series network. The source explicitly supplies the initially neutral connecting conductor, which is the condition needed for equal charge magnitudes on its two capacitor faces. External stray coupling is omitted by the ideal circuit model. Energy addition independently gives `sum_i Q²/(2C_i)=Q²/(2C)`. |
| p.4/s.8 | `V=V1=V2`; `Q=Q1+Q2`; `C=sum_i C_i` | Correct ideal parallel network. Energy addition gives `sum_i C_i V²/2 = C V²/2`. |
| p.6/s.12 | `F_2 = q1 q2 r_hat_21/abs(r_21)²` | Correct when `r_21=r2-r1`. The slide’s discrete two-charge arrow convention supports that direction. |
| p.7/s.13 | `F_Q=sum_i q_i Q r_hat_i/r_i²`; `F_Q=integral Q dq r_hat/r²` | Correct when the displacement points from source charge to the observation/test charge. The continuous-charge diagram has a direction ambiguity/inconsistency recorded separately below. |
| p.8/s.15 | `E=F_q/q=Q r_hat/r²`; `φ(P)=-integral_infinity^P E·ds` | Correct for a nonperturbing test charge and source-to-field-point displacement. The printed note explicitly requires `φ(infinity)=0`. The integral also must converge. |
| p.8/s.16 | `W_1→2=-integral_1^2 F_C·ds` | The sign is correct for external quasistatic work/change in electrostatic potential energy. Work done by the Coulomb force is the opposite sign. The slide labels W as work needed to move charges, compatible with this convention. |
| p.8/s.16 | `U=(1/2) integral ρφ dV = integral E²/(8π) dV` | Correct for suitable total charge distributions with finite self-energy and vanishing boundary term, or appropriate limiting conventions. Point-charge self-energies and dielectric interpretation need the qualifications below. |
| p.9/s.18 | `E=integral dq r_hat/r²`; `closed_integral_S E·dA=4π Q_enc=4π integral_V ρ dV` | Correct. V is the enclosed volume and dA points outward. In matter, ρ must mean total charge for the E form. |
| p.10/s.19 | `φ=q/r`; `φ=integral dq/r`; `φ2-φ1=-integral_1^2 E·ds` | Correct with source-to-field-point separation magnitude, stated infinity reference where it exists, and electrostatic path independence. |
| p.10/s.20; p.11/s.22 | `E=-grad φ`; `laplacian φ=-4πρ`; `div E=4πρ` | Signs and factors agree: taking the divergence of `E=-grad φ` immediately gives Poisson’s equation. Derivatives need a distributional interpretation at ideal surface or point charges. The summary arrows match their formula directions. |
| p.12/s.23 | `E_inside=0`; `E_surface=4πσ` | Correct for electrostatic equilibrium inside conducting material, with `E_surface` meaning the signed outward normal component just outside a smooth vacuum interface; tangent E is zero. The “inside” statement does not imply zero field in every cavity containing charges. |

## Numerical checks

### p.3/s.6: 100 μF at 4 kV

`U = (1/2)(100×10^-6 F)(4000 V)² = 800 J`, exactly agreeing with the slide. The corresponding stored charge, a derived value, is `Q=CV=0.4 C`.

The printed wire length is 12 inches. The packet does not give wire diameter/mass, resistivity or its temperature dependence, capacitor internal resistance, contact resistance, inductance, or thermal data. Therefore the 800 J arithmetic is verified, but a quantitative current, temperature, discharge duration, or proof of wire explosion cannot be extracted from these inputs alone. The assertion that virtually all energy goes into the wire is an idealized consequence of the stated dominance of wire resistance; the packet provides no numerical resistance comparison.

### p.5/s.10: twelve 80 μF capacitors in parallel

`C_total=12×80 μF=960 μF`, exactly agreeing with the slide.

| Initial voltage | Derived stored charge | Derived stored energy | Energy ratio to 100 V |
|---:|---:|---:|---:|
| 100 V | 0.096 C | 4.8 J | 1 |
| 200 V | 0.192 C | 19.2 J | 4 |
| 300 V | 0.288 C | 43.2 J | 9 |

The source’s 1:4:9 energy scaling is exact at fixed capacitance.

Only under a constant-resistance model, the printed 60 W at 120 V rating yields an operating-point resistance `R=120²/60=240 Ω`. If that same resistance is used throughout all three discharges, `RC=0.2304 s` and the following initial values result:

| Initial voltage | Initial current | Initial power | Power/rated 60 W |
|---:|---:|---:|---:|
| 100 V | 0.416666… A | 41.666666… W | 0.694444… |
| 200 V | 0.833333… A | 166.666666… W | 2.777777… |
| 300 V | 1.25 A | 375 W | 6.25 |

Thus “power increases by a factor 9” is correct comparing 300 V with 100 V at the same resistance; it is not a factor 9 relative to the 120 V rating. These operating-point calculations do not establish that a real lamp’s resistance stays constant. No resistance or thermal evolution law is supplied, so lamp survival is undetermined by the packet’s numbers.

## Direct errors, internal contradictions, and incomplete inferences

### IC-01 — Incorrect location of induced negative charge

**Location:** p.12/s.23. **Confidence:** high. **Type:** direct physical/label error.

The printed text places `-Q` on the “inner surface of inner cylinder.” Under the same slide’s stated `+Q` on the inner shell, neutral outer shell, and zero field within conductor material, a Gaussian surface within the outer conducting shell encloses zero net charge. It already encloses `+Q`, so the charge on the **inner surface of the outer cylinder** must be `-Q`. The neutral outer conductor then has `+Q` on its outer surface. The drawing itself places the minus signs along the inward side of the outer conductor, supporting this correction. The first printed “inner cylinder” should therefore be “outer cylinder.”

For ideal infinitely long coaxial shells, or the long-cylinder approximation away from ends, let the inner/outer gap radii be a and b and let the inner-shell charge per unit length be λ. The printed Gauss law gives `E(r) 2πrL=4πλL`, hence `E(r)=2λ/r` for `a<r<b`. The total Q alone, with no length or geometry, does not supply a numerical field. No explicit field solution is printed on the slide.

### IC-02 — “Capacitance depends only on geometry” is not generally compatible with this packet

**Location:** p.1/s.2 and p.13/s.25, compared with p.3/s.5 and p.5/s.9. **Confidence:** high. **Type:** unqualified claim/internal contradiction.

The packet explicitly says that adding dielectric between otherwise unchanged plates increases C. Consequently “only on geometry” needs fixed material/environment assumptions. Within the source’s own model, it is geometry **and dielectric conditions**, independent of the amount of charge when the response is linear. This correction follows from the packet without an external material model.

### IC-03 — The dissection energy argument does not force charge to remain on dielectric

**Location:** p.2/s.4. **Confidence:** high for the logical defect; experimental mechanism not adjudicated. **Type:** incomplete causal inference.

The printed inference uses `U=Q²/(2C)` and falling C during separation, implying that charge stays on dielectric because otherwise stored energy would increase. The increase itself is allowed: mechanical work used to separate charged conductors can supply it. Combining the packet’s ideal parallel-plate formulas at fixed Q gives `U=2πQ²d/A`, so increasing d produces `ΔU=2πQ²Δd/A>0`. There is no energy-conservation contradiction if external separation work supplies that amount.

The reported no-spark/reassembly-spark observations are not numerically testable from this packet. The arithmetic demonstrates that the given energy argument alone is insufficient to establish where charge resides or which transfer/trapping mechanism occurs. This record does not replace it with an unsupported experimental mechanism.

### IC-04 — “Potential is always continuous” requires exclusion of singular charge locations

**Location:** p.11/s.21, compared with p.10/s.19. **Confidence:** high. **Type:** false if literally unrestricted; ordinary-surface statement valid.

The packet’s own point-charge formula `φ=q/r` diverges as `r→0` for nonzero q, so it does not define a finite continuous potential at the point-charge location. The universal statement needs a regularity/domain qualification. Across an ordinary surface-charge sheet with finite one-sided field limits, the intended continuity statement is consistent: `φ(+δ)-φ(-δ)=-integral_-δ^δ E_n dn` tends to zero, while Gauss’s law permits `E_n^+ - E_n^- = 4πσ`.

This is a qualification of the universal wording, not a claim that potential jumps at an ordinary finite sheet of surface charge. No unsupported jump is inferred.

### IC-05 — Boundary values alone do not establish electrostatic uniqueness

**Location:** p.12/s.24. **Confidence:** high. **Type:** theorem stated with essential conditions omitted.

The source says a solution satisfying boundary conditions is THE solution. It must also solve the same electrostatic field equation with the same specified source in the domain, with adequate boundary data and the relevant behavior at infinity. A direct counterexample to the boundary-only wording follows from the packet’s Poisson equation: in a ball of radius R, both `φ=0` and `φ=A(R²-r²)` vanish on the boundary, but their Laplacians are 0 and `-6A`. They correspond to different volume charge densities, so boundary agreement alone is not sufficient. This does not refute the correctly conditioned uniqueness theorem.

### IC-06 — “Time of discharge will not change with V” needs a definition of discharge time

**Location:** p.5/s.10. **Confidence:** high. **Type:** ideal-model qualification and ambiguous wording.

Using the source’s `Q=CV`, `I=V/R`, and the definition `I=-dQ/dt`, a constant R,C discharge gives `V(t)=V0 exp[-t/(RC)]`. The time constant RC and time to reach a fixed **fraction** of V0 are independent of V0. Time to reach a fixed **absolute** nonzero voltage threshold is `RC ln(V0/V_threshold)` and depends on V0; exact zero is reached only asymptotically in this ideal model. Thus the printed sentence is defensible for the time constant or equal fractional discharge, not all meanings of “time of discharge.” No actual lamp time can be verified without a resistance model.

## Additional conditions and graphical ambiguity

### IC-07 — Direction shown in the continuous-charge diagram

**Location:** p.7/s.13. **Confidence:** medium. **Type:** graphical direction inconsistency; equation correct under standard displacement convention.

The line labeled r in the lower continuous-charge picture visibly has an arrowhead near the source element q_i, pointing from the test charge Q toward the source. The displayed positive-sign integrand `Q dq r_hat/r²` requires the unit vector from source to Q. If the drawn arrow defines the same r, its direction is reversed; if it is only a nondefining distance marker, the formula is not contradicted but the arrow invites an opposite definition. No correction is asserted for the formula itself. The upper discrete summation lacks an explicit direction arrow and is otherwise consistent.

### IC-08 — Field energy: boundary term, point self-energy, and matter

**Location:** p.8/s.16. **Confidence:** high. **Type:** necessary scope, not an algebraic sign error.

Substituting `ρ=div E/(4π)` and `grad φ=-E` into the first energy expression yields

`(1/2) integral_V ρφ dV = (1/8π) integral_V E² dV + (1/8π) closed_integral_boundary φ E·dA`.

The equality printed for all space therefore requires the limiting surface term to vanish and the integrals to be well defined. For one ideal point charge, the printed `E=q/r²` gives the field energy outside a small cutoff sphere of radius ε as `q²/(2ε)` (with the upper radial limit sent to infinity), which diverges as `ε→0`. A finite point-charge interaction energy cannot be equated directly to the full positive field integral while silently discarding this self-energy.

In a dielectric, the symbols in `div E=4πρ` and `(1/2) integral ρφ` require a clear total-charge versus free-charge interpretation. The packet does not state one here. No material energy law is derived or numerically asserted in this independent source-only check.

The sentence that assembling charges “costs energy” is also sign-dependent for interaction energy: bringing q opposite in sign to Q from infinity gives `ΔU=qQ/r<0` by the packet’s own work and potential formulas. External work can be negative. This does not contradict nonnegative full field energy when self-energy is retained.

### IC-09 — Gaussian surfaces, conductor limits, and images

**Locations:** p.9/s.18; p.12/s.23–24. **Confidence:** high for the mathematical conditions. **Type:** scope qualifications.

The source’s “E constant on the surface” is a useful sufficient simplification in some geometries, not a complete criterion for extracting E from flux. The integrand is the normal component `E·n`; a cylindrical or planar construction can have constant normal flux density on selected faces and zero flux through other faces. Gauss’s law itself does not require symmetry, as the slide correctly states.

The conductor boundary value is the field just outside the conductor, not a unique field value on an ideal charged mathematical surface. The cavity issue in IC-01 and the distinction between metal and empty regions are necessary when applying `E_inside=0`.

The images sketch is consistent with a +q above an infinite plane and an image -q at the mirrored point below, when the plane has the corresponding zero-potential boundary condition. At plane points the distances to the two charges are equal, so the printed superposition formula directly gives `φ=q/r-q/r=0`. The image is a mathematical source outside the physical solution region; the lower half of the dipole picture is not the physical field inside a conducting half-space. The packet does not explicitly state grounding, infinity conditions, or whether the drawn slab is an ideal plane/half-space. The picture alone is insufficient to claim the same two-point-charge replacement for every finite or isolated conductor.

## Items intentionally left unresolved

- p.2/s.3 asks about connecting “the outer and the outer surface.” With two jars mentioned but one sketched, the circuit/contact intent is ambiguous. No unique circuit result is reconstructed or silently substituted.
- p.3/s.5 describes dielectric molecules as not spherically symmetric, but provides no molecular model. This independent mathematical check does not treat that description as a proved prerequisite or supply a microscopic mechanism beyond the source.
- p.7/s.14 gives no dimensionality, radii, density law, or numerical observation position for the charge-with-holes sketch. Linear superposition supports subtraction of the missing-region distributions, but no numerical force is determined. Treating the sketch as definitely a sphere, cylinder, or planar lamina would introduce an unsupported assumption.
- p.12/s.23 supplies neither dimensions nor a finite-length/end-condition model for the cylinders; only the conditional long-cylinder formula and induced total-charge accounting are reconstructed.
- Experimental outcomes, actual resistance variation, material failure, and dielectric charge-transfer mechanisms are not independently verified by the supplied equations alone.

## Reproducibility and hold

Run `python calculations.py` in this directory to reproduce the exact rational arithmetic, assertions, and source-file SHA-256 manifest in `results.json`. The source files are read-only inputs. The calculation script imports only standard-library modules and does not access network services or any other workspace source.

This file and companion calculation results are local preparatory material. No semantic findings should be distributed before the future D131 whole freeze.
