# D131 — held independent technical dossier

Status: independent technical preparation only, sealed for a future D131 whole-freeze admission. This is neither teaching material nor a student trial, SASIS run, evaluation of an unseen teaching package, or publication. No proposed teaching sequence or assessment has been authored here. Semantic findings must remain held until the specified future admission.

## 1. Evidence boundary and identity

The only subject inputs were the complete original packet at `/workspace/scratch/f9c0b7fc7e76/original-inputs/D131` and the complete four-subject baseline at `/workspace/scratch/f9c0b7fc7e76/d015-clean-r36-20261012/inputs/student-baseline.txt`. Cross-references inside those inputs were not followed. No prior preparation, teaching package, trial, history, external research, browser, PROF package, author contact, or other material supplied subject premises. This is instruction confinement; no claim of technical isolation is made.

The packet contains one 13-page PDF, its identity record, 13 original full-page PNGs, and 13 original page text extractions: 28 files. All identity text was read, all extracted page text was read, and every native PNG was opened and emitted for actual visual inspection. Each PDF page contains two lecture slides, numbered 1–26. All source-image and source-text hashes match the identity record; the PDF has 13 pages and matches the recorded bytes and SHA-256. No missing page needed regeneration. Originals were preserved.

The supplied identity calls this material `D131`, session `mit-8-022-fall2004-L07`, lecture number 7. The actual PDF title and recurring footer explicitly say **8.022 (E&M) — Lecture 6**, G. Sciolla, MIT; its source URL filename is `lecture6.pdf`. Both identities are retained without silently changing the PDF's printed lecture number. The packet's URL, repository revision and acquisition history are provenance strings, not additionally consulted evidence. The PDF itself does not establish a bachelor-year classification; no separate classification claim was independently researched.

Source PDF: 108,268 bytes; SHA-256 `0cea3f0bd944685f8079b5ada3ddbbea54af51f56d2ba45ed58bf4cadfc9b571`.

Baseline: 247,840 bytes, 246,945 Unicode characters; SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. It was read in 13 contiguous, untruncated character ranges: twelve of 20,000 characters and a final 6,945. This includes Mathematics H240, Further Mathematics H245 Pure Core plus **both Statistics Y542 and Mechanics Y543**, Physics H556, and Chemistry H432, including their limitations and reference-availability statements. The initial combined display that was truncated is not relied on for baseline coverage; its reading was replaced by the complete bounded sequence. Source pages 6–13 were also reread separately after the combined display truncated.

All source hashes, page-access evidence and baseline chunk hashes are in `source-access-manifest.json`; complete input checksum lines are in `input-checksums.sha256`. `baseline-reading-log.json` records the full read rather than a keyword-only search. Specific warrant locations are separately indexed in `baseline-warrant-locations.json`.

## 2. Global technical conventions

The lecture's electrostatic formulas use a Coulomb normalization with coefficient one: point-charge force `q1 q2 rhat/r²`, field `q rhat/r²`, potential `q/r`, Gauss flux `4π Q`, parallel-plate capacitance `A/(4πd)`, and vacuum field energy density `E²/(8π)`. These are mutually consistent Gaussian-style formulas. The baseline uses SI, with `1/(4πε0)` in the point-charge laws and `ε0 A/d` for vacuum parallel plates. This is a change of unit convention, not evidence that either set of formulas is wrong. Numerical examples explicitly using farads, volts and joules must be evaluated consistently in SI. It would be wrong to substitute dimensions in metres into `A/(4πd)` and label the resulting number farads.

The following notation is used in this dossier to remove source ambiguities: `x` is an observation position; `x'` a source position; `R=x−x'`, `R=|R|>0`, and `Rhat=R/R`; `φ` is electric potential; `Δφ` or capacitor `V` is a voltage; `d³x'` is volume element. The source also uses `V` as a volume integration region and uses `Q` as either a source, a test charge or capacitor charge depending on the slide. These roles must not be merged. A positive capacitance uses positive plate-charge magnitude and positive corresponding voltage magnitude, or consistent signed quantities with `Q=C V`.

The electrostatics review concerns fixed source arrangements and equilibrium conductors. Static superposition applies to fields and potentials from specified charge distributions. For conductors the final surface charge is itself an unknown constrained by equipotential boundaries; simply superposing an unchanged pre-existing conductor charge pattern with a new nearby charge does not solve that induced-charge problem.

Potential is determined only up to a common additive constant. An infinity-zero convention is available only when the relevant limit and integral exist. Charge density, field and potential are linked, but density alone does not specify a unique field in a region without boundary information. A differential relation is not by itself a complete boundary-value problem.

## 3. Complete page, slide and figure reconstruction

### Page 1, slides 1–2

Slide 1 introduces further capacitor material and a short electrostatics review for Quiz 1. Slide 2 recalls a capacitor as a system of charged conductors, `C=Q/V`, and `U=Q²/(2C)=CV²/2`; its illustration is a pair of irregular turquoise conductors, one labeled `+Q` with positive marks, the other `−Q` with negative marks. It is a general two-conductor drawing, not a pair of parallel plates.

For a fixed linear capacitor, charging quasistatically gives `dU=V(q)dq=(q/C)dq`; integrating from 0 to Q gives the displayed energy. Thus fixed geometry and a fixed linear material response are implicit. The claim that C depends “only on geometry” is incomplete in the presence of the dielectric later introduced on slide 5: it also depends on the medium. It can be retained only with that medium held fixed. The charge/voltage/energy identities themselves are already explicit baseline Physics §6 premises.

### Page 2, slides 3–4

Slide 3 identifies a Wimshurst machine charging two Leyden jars and calls each jar a cylindrical capacitor. Its drawing shows an outer cylindrical conductor, an inner conductor with central terminal rod and black top sphere, and a green annular insulator separating the conductors. The prompt literally asks what happens when connecting “the outer and the outer surface.” No complete two-jar wiring diagram, initial charge signs, grounding condition, or connecting sequence is supplied.

That wording is unresolved, not automatically a proven replacement of one “outer” with “inner”: two outer surfaces could refer to the two jars. Connecting both terminals of one charged jar would discharge it, whereas connecting the outer conductors of two jars is a different circuit problem. No unique outcome can be reconstructed from the displayed schematic alone. The source supplies no numerical Leyden-jar example or measured spark result on this slide.

Slide 4 is the dissectible Leyden jar demonstration: charge a jar, ask whether charge resides on conductors or dielectric, remove and short the conductors (“Nothing happens!”), reassemble (“Bang!”). Its figure is an exploded cylindrical assembly with the red inner conductor lifted upward from a green-topped insulating/outer assembly. The supplied explanation says charges prefer staying on the dielectric, since separating plates reduces C and, at fixed Q, `U=Q²/(2C)` would increase.

The fixed-Q energy comparison has the right sign but does not establish a charge-transfer mechanism or forbid an energy increase: mechanical separation can supply work. Also, the ideal isolated two-terminal capacitor formula cannot by itself track all potentials and charge distributions while the dielectric and conductors become separate objects. The observed demonstration is reported by the source; neither a physical observation nor an exact charge-transfer process was independently established here. The technical conclusion supported by the record is that the simple energy argument is insufficient as a universal explanation, and the outcome is apparatus/process dependent. It must not be transformed into a general claim that all capacitor charge is located on the dielectric, or that ordinary bound polarization charge and retained net surface charge are identical.

### Page 3, slides 5–6

Slide 5 shows two vertical plates with positive charge on the left, negative charge on the right, and a dielectric slab between them. The applied/capacitor E arrow points right; seven small horizontal dipoles have minus at the left and plus at the right; the dielectric contribution arrow points left. It gives `E=4πσ` and `C=Q/V=Q/(Ed)=A/(4πd)`, then says adding dielectric reduces V at fixed Q or increases Q at fixed V, hence increases C.

For broad vacuum plates, uniform surface charge density `σ=Q/A` and negligible edge fields give the displayed formula. The displayed `E=4πσ` is the field of the paired vacuum plates, or the field contribution due to their free charge; it must not be reused as the total dielectric-filled field at the same free σ. A linear dielectric filling the gap can be represented by a stated factor κ, yielding `C'=κC`; then fixed Q gives `V'=V/κ`, and fixed V gives `Q'=κQ`. Those deductions use the baseline's explicit permittivity result. At fixed Q, `U'=U/κ`; at fixed V, capacitor energy `U'=κU`, with exchange with the source. Those are different constraints.

The source's universal claim that dielectric molecules are not spherically symmetric is overbroad. The baseline Chemistry explicitly allows spherical s orbitals and induced dipoles in all atoms/molecules, and distinguishes bond dipoles from the vector sum determining permanent molecular polarity. Non-spherical shape alone does not imply a permanent dipole. The picture supports charge separation/orientation as a qualitative model, but supplies neither a microscopic constitutive law nor a quantitative κ. “Charges are not free to move” describes bound rather than conducting response; it does not mean no small displacement occurs.

Slide 6 charges a 100 μF oil-filled capacitor to 4 kV and discharges it through a 12-inch iron wire. The circuit drawing has an oil-filled plate pair, connecting wire and an open switch. `U=(1/2)(100×10⁻⁶)(4000)²=800 J` is correct. `Q=CV=0.4 C` follows. The slide claims the wire's resistance is small but dominates the rest of the circuit, concentrating dissipation in a short time and causing an explosion.

The available numerical data fix initial stored energy, not current history, peak temperature or a guaranteed explosion. A wire diameter/mass, resistance evolution, circuit resistance/inductance and thermal data are absent. In an ideal resistive discharge, the share of dissipated energy in a fixed wire resistance is `Rwire/Rtotal`; “all” is an approximation when this ratio is near one and other losses are negligible. A short time requires appropriate circuit dynamics as well as a small resistance. The source is a demonstration prediction, not a fully specified quantitative thermal calculation.

### Page 4, slides 7–8

Slide 7 draws two series capacitors with nodes A, B and C; B is the floating intermediate conductor. A red box isolates B and states that it starts electrically neutral. The voltage spans satisfy `V1+V2=V`, and equality of the opposite charges on the two faces of the isolated neutral node gives equal capacitor charge magnitudes `Q1=Q2=Q`. Therefore `1/C=V/Q=1/C1+1/C2`, extended to `C=(Σ_i 1/Ci)⁻¹`.

The equal-charge condition is supported explicitly by the figure, not a universal statement about arbitrary precharged series networks. With nonzero initially trapped node charge, algebraic charge constraints must retain that charge; simple equal magnitudes need not hold. The ideal lumped-capacitor treatment neglects stray capacitance to other conductors. For positive C1,C2, `C=C1C2/(C1+C2)` is positive and smaller than either component. The smaller capacitor bears the larger voltage for the same charge.

Slide 8 shows two capacitor branches joined to the same upper and lower nodes, giving `V1=V2=V`, `Q=Q1+Q2`, and `C=C1+C2`, extended to the sum over all branches. Charges are terminal charges in a common polarity convention. The equivalence concerns the external terminal charge-voltage law; it does not imply equal component charges when their capacitances differ. Both series and parallel rules, including the ordinary initial-state limitation on series equality, are already given in Physics §6.

### Page 5, slides 9–10

Slide 9 lists capacitor applications: storing substantial energy and releasing it rapidly; at a given voltage, larger C stores more energy. It proposes increasing plate area, decreasing separation, adding dielectric or adding capacitors in parallel. These statements follow from the formulas under their fixed-voltage, fixed-material and ideal-geometry conditions. The energy comparison reverses at fixed Q. The source supplies no breakdown-field limit, so arbitrarily decreasing a real gap or raising voltage cannot be extrapolated as an unlimited engineering design rule.

Slide 10 draws twelve 80 μF capacitors in parallel, a charging supply/switch and a 60 W lamp. `Ctotal=960 μF` is correct. At 100, 200 and 300 V, initial stored energies are 4.8, 19.2 and 43.2 J; charges are 0.096, 0.192 and 0.288 C. Ratios are `1:4:9` for energy. The slide argues that R stays the same, discharge time stays the same, and power increases by nine, then asks if a bulb designed for 120 V survives.

For constant R,C, `V(t)=V0 exp(−t/RC)`, `I(t)=V0 exp(−t/RC)/R`, and `P(t)=V0² exp(−2t/RC)/R`; the same *fractional* voltage decay has the same time constant, while amplitudes scale as stated. Time to a common absolute threshold is `RC ln(V0/Vthreshold)` and depends on V0. A filament lamp is not constant-R during appreciable heating/cooling; the baseline expressly states that filament resistance increases with temperature. Thus the fixed-R argument is a declared idealization, not an accurate universal lamp model.

If the nominal hot resistance is approximated by `120²/60=240 Ω`, the idealized time constant is 0.2304 s and initial powers at 100, 200, 300 V are approximately 41.67, 166.67, 375 W. The “nine” comparison is 300 V versus 100 V, not 300 V versus the lamp's nominal 120 V power; 375 W is 6.25 times 60 W. These conditional calculations do not decide survival: thermal transients and component limits are missing.

### Page 6, slides 11–12

Slide 11 explicitly says the review covers only main concepts/formulas and has no time for worked examples; it directs students to recitation notes and problem sets, which are absent and were not accessed. Consequently this packet is not evidence that those omitted examples or earlier material have been supplied to the future reader.

Slide 12 gives the Coulomb force on charge q2 due to q1: `F2=q1q2 rhat21/|r21|²`. The drawing places q1 lower-left and q2 upper-right; `rhat21` points from q1 toward q2, while `rhat12` points the reverse way. With `r21=r2−r1`, signs produce repulsion for equal signs and attraction for opposite signs. Separation must be nonzero; the point-charge law is singular at coincidence. A finite extended charge is not automatically replaceable by a point charge at every observation position.

The claim that everything follows from Coulomb's law and superposition is a high-level organizing statement. Actual deductions also require mathematical definitions, boundary/regularity conditions, charge conservation and material/equilibrium premises. Coulomb's law alone does not supply a dielectric response, the microscopic mechanism of a Leyden-jar demonstration, or the initial conditions of a circuit.

### Page 7, slides 13–14

Slide 13 shows many source points q1,…,qN around a red test charge Q and gives `FQ=Σ qi Q rhat_i/ri²`. A second drawing contains a green extended source volume with a small cube labeled qi, a separated red Q, and a connecting line labeled r. Its arrowhead appears directed toward the source cube. If that arrow is intended as the vector r used in the force formula, its direction conflicts with the positive-charge force convention: the formula needs source-to-test direction. If it merely labels separation, a directional convention remains missing. Preserve this as a figure ambiguity, not a reason to change Coulomb's sign.

The continuous formula is `FQ=∫_V Q dq Rhat/R²=∫_V Qρ(x') Rhat/R² d³x'`, with observation point held fixed. Source/observation distinction is consequential; using the same position variable for both can erase direction or distance dependence. A point test charge is an idealization that does not disturb the specified source distribution. The integral's convergence and exclusion/handling of singular coincident source points matter. Volume density does not automatically describe a sheet or line unless a corresponding charge element/model is supplied.

Slide 14 draws a green circular region with positive marks and **three white circular empty regions**, with a red test charge q outside to its right. There are no radii, distances, density symbol, axes, or explicit statement that the pictured object is a sphere, long cylinder or lamina. Its precise general reconstruction is subtraction: take a complete charge distribution of the intended outer shape, subtract copies of the charge distribution that would fill each empty region, then add their vector fields/forces. Algebraically `ρactual=ρfull−Σρremoved,j` and `Fact=q(Efull−ΣEremoved,j)`.

A numerical force or a uniquely specified point-charge shortcut is unavailable. If additional conditions identify a uniform sphere and spherical cavities, and q lies outside each sphere, the baseline's exterior uniformly charged sphere law permits `F=q[Q0(x−c0)/|x−c0|³−ΣQj(x−cj)/|x−cj|³]` in the source normalization, with `Qj=4πρ aj³/3`. This is a conditional specialization, not an assertion that the unlabeled source figure already specifies spheres. A charged lamina, for example, does not generally have that exterior point-charge field.

### Page 8, slides 15–16

Slide 15 introduces `E=Fq/q=Q rhat/r²` to remove dependence on the probe charge, then `φ(P)=−∫∞^P E·ds`, explicitly noting `φ(∞)=0`. It calls φ the work required to bring a unit charge from infinity to P. The consistent interpretation is external quasistatic work per unit positive test charge with source configuration fixed and no change of kinetic energy. Electric-field work has the opposite sign. Scalar potential superposition avoids vector-component addition but may still require a nontrivial integral.

The infinity convention fails for some ideal extended sources: an infinite uniform plane's nonzero constant field gives an unbounded potential difference to infinity; the infinite-line field proportional to 1/r gives a logarithmic divergence. Finite-reference potential differences remain meaningful. This follows directly by the baseline's ordinary and improper integrals once those field forms are established.

Slide 16 depicts P1 and P2 connected by three differently shaped paths, indicating path independence in electrostatics. The displayed `W1→2=−∫1^2 FC·ds` is work by an external agent against Coulomb force, not work done by that force. The slide gives `U=(1/2)∫charges ρφ dV=∫all space E²/(8π) dV`.

The factor 1/2 prevents double counting pair interactions during assembly. For a continuous finite-energy vacuum configuration, the equality follows from Poisson/Gauss plus an integration-by-parts/divergence relation whose boundary term must vanish or be retained. Those vector-calculus steps are not available from the baseline alone. These expressions are not automatically finite for point charges: `E~q/r²` makes near-source field energy behave as `∫dr/r²`, which diverges. Removing divergent self-energies leaves a distinct interaction-energy convention; opposite charges can have negative interaction energy, so “assembling costs energy” is not universally positive under that convention. The displayed vacuum field density must not be silently reused as a complete dielectric-material energy law.

### Page 9, slides 17–18

Slide 17 places `ρ(x,y,z)`, `E(x,y,z)` and `φ(x,y,z)` at the corners of a triangular conceptual arrangement and describes problems as conversion among these descriptions. This is a useful map only with the appropriate source, boundary, reference and regularity information.

Slide 18 gives direct field superposition and the Gaussian flux laws `ΦE=4πQenc` and `∮_S E·dA=4π∫_VρdV`. Its drawing shows a central +Q, radial outward blue arrows, a red circular surface S1 and an irregular enclosing black/green surface S. These two closed surfaces have the same enclosed charge and flux despite different local field magnitudes and orientations.

The Gaussian surface is an imagined integration boundary, not necessarily a physical conductor. Its vector area is outward normal. The enclosed charge includes all relevant signed charge; outside charges can produce field on the surface while contributing zero net closed-surface flux. Zero enclosed charge does not in general mean zero field.

The source says choose a surface on which E is constant. This is sufficient in some symmetric arrangements but stronger than necessary: a cylindrical surface around a long line has constant radial E on its curved side and zero flux through its end caps. What is needed is enough symmetry to evaluate the *normal component flux* and isolate the desired E, not global constancy of E everywhere. Gauss's law remains true without useful symmetry; one flux number then generally cannot determine every local field component.

### Page 10, slides 19–20

Slide 19 gives point potential `φ=q/r` and continuous superposition `φ=∫dq/r`, explicitly with zero at infinity. It also gives `φ2−φ1=−∫1^2 E·ds`, using a convenient path after obtaining E by symmetry/Gauss. Point formula requires r>0; density integration requires an appropriate distribution and convergent reference. A scalar potential can be negative; r is nonnegative distance, not a signed coordinate substituted without absolute values.

Slide 20 gives `E=−∇φ`, `∇²φ=−4πρ`, and the alternative route `∇·E=4πρ`. Their consistency is immediate once the operators are defined: `∇·(−∇φ)=−∇²φ`. In Cartesian coordinates, the needed definitions are `E_i=−∂φ/∂x_i`, divergence `Σ_i ∂E_i/∂x_i`, and Laplacian `Σ_i ∂²φ/∂x_i²`. The slide does not define partial differentiation or any of these operators, nor their cylindrical/spherical-coordinate forms. “One derivative” means one gradient operation, potentially several partial derivatives; it does not reduce an arbitrary field to a single ordinary derivative.

The pointwise equations hold in smooth regions; sheets and point charges require separate boundary/singular treatments. `ρ=0` gives Laplace's equation but does not mean φ or E vanish; nonzero fields can be selected by boundary data. For radial or translationally symmetric situations, ordinary derivatives and flux balance can yield specialized formulas without assuming a general multivariable calculus already exists in the baseline.

### Page 11, slides 21–22

Slide 21 asserts that φ is “always continuous” and E can jump at surface charge, with a reference to Pset 2 problem 1. That problem is unavailable. The surface-charge statement is correct for the usual finite-sheet model: with bounded one-sided field limits, the line integral through a vanishing thickness tends to zero, so φ stays continuous; a small Gaussian pillbox gives `(Eout−Ein)·n=4πσ`. The electrostatic tangential field remains continuous under the regular sheet model.

The unconditional “always” is false on the source's own point-charge model: `φ=q/r` has no finite continuous extension to r=0. Singular charge models must be excluded or explicitly qualified. The correction need not invoke more advanced ideal dipole layers, which the source and baseline do not teach.

Slide 22 is the full triangular summary: `ρ→E` by integral Gauss; `E→ρ` by divergence; `ρ→φ` by the source potential integral; `φ→ρ` by Poisson; `E→φ` by potential-difference line integral; `φ→E` by minus gradient. All six directed relationships are visible. The diagram is a formula map, not a replacement for each arrow's domain, boundary conditions or mathematical definition.

### Page 12, slides 23–24

Slide 23 lists equilibrium-conductor properties: equipotential surfaces, perpendicular external field, zero field inside, and `Esurface=4πσ`. “Inside” must mean conducting material, not every cavity or gap enclosed by a conductor. Each connected conductor has one potential, but distinct conductors can have different potentials. Surface field denotes the limiting vacuum field just outside the conductor, with vector form `Eout=4πσ n` and outward normal n; the field is discontinuous across the charged boundary, so an unqualified value precisely on an ideal surface is ambiguous.

The source example is **concentric cylindrical shells**, not spheres. An inner shell receives +Q; the outer shell receives no net charge. The cross-sectional drawing shows positive charge associated with the inner shell, negative charge on the facing inner surface of the outer shell, positive charge outside the outer shell, and a red dashed Gaussian circle within outer conducting material.

The bullet saying “−Q induced on inner surface of inner cylinder” is a genuine location error. The figure and Gauss's law require **−Q on the inner surface of the outer cylinder**. A Gaussian surface within outer metal encloses +Q plus its inner-surface induced charge and has zero flux; their sum is zero. Since the outer conductor remains neutral, its outer surface carries +Q. An empty inner cavity has zero net induced charge in the ordinary no-internal-source equilibrium arrangement.

For long coaxial cylinders with negligible end effects, define inner exterior radius a, outer interior radius b>a, charge per length λ=Q/L and observation radius a<r<b. A coaxial Gaussian cylinder gives `E(r)2πrℓ=4πλℓ`, hence `E(r)=2λ/r` radially outward for positive λ. The source supplies no L, radii or infinitely-long/end-effect assumption, so no unique numerical field can be given. Finite cylinders retain the charge-total constraints, but their local gap field need not equal the infinite-cylinder expression. Corresponding voltage `φ(a)−φ(b)=2λ ln(b/a)` and ideal capacitance `C=L/[2 ln(b/a)]` reconstruct the natural cylindrical capacitor continuation under the stated approximation.

Slide 24 proposes uniqueness and image charges for charges near conductors. The drawing shows a real positive point above a horizontal green conductor, negative marks along its top and a mirror negative point below, with field curves drawn in both half-spaces. The lower point/curves are a fictitious mathematical continuation. They must not be interpreted as physical nonzero field inside an equilibrium conductor.

A concrete reconstruction consistent with this figure is a point q at height a>0 above an **infinite grounded plane** z=0, with an image −q at z=−a. This grounding/infinite-plane statement is a necessary condition supplied by the reconstruction; it is not explicit in the slide text. For physical z>0, `φ=q/[s²+(z−a)²]^(1/2)−q/[s²+(z+a)²]^(1/2)`. It has φ=0 on the plane, the correct real source singularity, and zero at infinity. At the plane, `Ez=−2qa/(s²+a²)^(3/2)`; `σ=−qa/[2π(s²+a²)^(3/2)]`, integrating to −q on the infinite plane. The attractive force on q is the image field at q: `Fz=−q²/(4a²)` in source units. These are conditional analytical reconstructions, not hidden numerical source data.

The source phrase “a solution that satisfies boundary conditions is THE solution” omits that it must also solve the correct field equation with the correct sources in the physical domain, within a class where the uniqueness statement applies. Having visually similar field lines is insufficient to fix field magnitude or potential. The image charge must lie outside the physical solution region. A finite plane, an isolated conductor with prescribed total charge, or nonzero boundary potential may require a different construction.

### Page 13, slides 25–26

Slide 25 repeats two oppositely charged conductors, `C=Q/V`, “only geometry,” and `U=Q²/(2C)=CV²/2`. The same fixed-linear-medium qualification applies. It expects strong parallel-plate knowledge and the ability to derive other standard geometries, but provides no worked general derivation on this page.

Beyond the coaxial reconstruction already justified, a conditional concentric-spherical case follows from spherical symmetry/Gauss: in a vacuum gap a<r<b, `E=Q/r²`, `V=Q(1/a−1/b)` and `C=ab/(b−a)`; b→∞ gives isolated-sphere C=a in the lecture units. In SI these capacitances gain the appropriate `4πε0` factor, and the baseline already grants `C=4πε0 a` for the isolated sphere. These are relevant possible “standard geometries,” not a claim that the slide names them individually.

Slide 26 says Quiz 1 covers up to this lecture, Purcell chapters 1/2/3; the next lecture concerns currents and currents are excluded from the quiz. The external book chapters and quiz were not supplied or accessed. The capacitor demonstrations mention current and resistance, but the final scope statement does not provide a new general currents course. No unseen exercise, numerical datum, prior lecture explanation or quiz criterion is admitted by these references.

## 4. Baseline prerequisite warrant register

This register records premises and limits, not presumed measured student mastery. A result outside the baseline is not forbidden if an explicit valid deduction from admitted premises is available.

| Required operation or premise | Actual baseline warrant | Consequence for this source |
|---|---|---|
| Algebra, ratios, signs, prefixes and dimensions | Mathematics arithmetic/algebra; Physics §1; FM57 | Capacitor sums, μF/kV/J calculation, voltage/energy scaling and consistency checks are available. Dimensional agreement alone does not determine a missing 4π coefficient or a physical law. |
| Ordinary calculus, definite/improper integrals, exponentials | Mathematics differentiation/integration; FM28, FM32 | Charging-energy integral, radial potential integral, RC exponentials and infinity-limit checks are available. Not a grant of arbitrary multivariable, line or surface integration. |
| Components, unit vectors, distance and scalar products | Mathematics vectors; FM17–20, particularly FM18 | Discrete force superposition, directions, `F·s`, normal projections and geometric coordinate reasoning are available. A vector-field integration operation still needs definition. |
| Constant-force and one-dimensional variable-force work | Physics §2; FM58; FM60 | Sign conventions and `U=qφ` can support radial/straight-path calculations. FM58 expressly withholds general variable-field line integrals. |
| Charge conservation, conductors/carriers, circuit node/loop reasoning | Physics §3; Chemistry CH-02.02 | Series floating-node charge and parallel common-voltage arguments are available. Detailed electrostatic conductor equilibrium and induction are new source premises, not automatically a full boundary theory. |
| C, capacitor energy, series/parallel, fixed Q versus fixed V | Physics §6 | Most capacitor algebra is explicitly prior. Source's “only geometry” must respect the same baseline's dielectric permittivity dependence. |
| RC charging/discharge, current, electrical power, filament resistance | Physics §§3 and 6; FM32 optional derivation | Ideal constant-R transient comparison is prior; temperature-dependent lamp resistance is also prior and limits the source demonstration claim. |
| Point E, force and potential, scalar/vector superposition | Physics §6 | Core inverse-square/potential and positive-test-charge sign reasoning are prior in SI. The coefficient-one convention is new notation/units and requires a bridge. |
| Uniform parallel-plate E and capacitor permittivity | Physics §6 | `E=ΔV/d`, `C=εA/d`, and dielectric increase of C are prior. Polarization constitutive theory and retained Leyden-jar charge mechanisms are not. |
| Exterior uniform sphere E and isolated sphere C | Physics §6 plus elementary sphere geometry | A *specified* spherical subtraction construction can be derived; an unlabeled circle cannot be assumed to supply the requisite geometry. |
| Flux for a flat surface in uniform field | Physics §6 gives magnetic `BA cosθ` | Supports the geometric dot-product analogy only. General electric flux, closed curved surfaces, Gauss's law, and divergence theorem are not already granted. |
| Charge density integrals | Source slide 13 supplies `dq=ρ dV`; FM42/43 give one-variable density integrals in probability; FM63 gives selected one-variable mass integrals | Density-as-weighted-sum is accessible, but the statistics/mass precedents do not supply a general three-dimensional charge integral, arbitrary Jacobian, or Coulomb-kernel result. |
| Gradient, divergence, Laplacian and Poisson | FM69 explicitly excludes these; Mathematics excludes partial/multiple calculus; Physics §8 excludes Maxwell formalism | All operators and their physical relationships require source/new definitions. The source displays the identities but does not define the operations. Radial specializations can be reconstructed using admitted ordinary calculus and explicitly given Gauss law. |
| Electrostatic path independence and uniqueness | Source slides 16,19,24 | These are university source assertions. Their exact domains and boundary requirements are not a baseline theorem. A formal uniqueness proof would need additional mathematical premises. |
| Microscopic dipoles, bound charge and conductor distinction | Chemistry CH-02.02–03; Physics §6 | Permanent/induced dipoles, vector cancellation and mobile-charge distinctions support a qualitative critique of slide 5. They do not supply κ, a polarization field equation, or a universal mechanism for the dissectible jar. |
| Statistics Y542 in full | FM37–56 | Provides probability, density and inference techniques but no extra electrostatic law. No actual sampling inference or probability model is required by this lecture. Reading this option does not entitle importing arbitrary distributions or advanced field mathematics. |
| Mechanics Y543 in full | FM57–68 plus FM69–71 limits | Supplies work/energy, dot products, dimensional reasoning, selected density integrals and differential equations. Its selected mechanics grants must not be shortened to H240-only assumptions, nor enlarged into general field calculus. |
| Other Chemistry and Physics material | Complete baseline read, including thermodynamics, spectroscopy, practical reasoning, nuclear/astrophysical models and scope limits | Offers no missing electrostatic boundary theorem merely through a familiar term such as potential, entropy, density or equilibrium. No chemistry Gibbs criterion proves the Leyden-jar charge-transfer explanation. |

## 5. Error, qualification and underspecification register

| ID | Source location | Classification | Evidence-based disposition |
|---|---|---|---|
| E01 | p12 s23 | Definite source location error | Negative induced charge belongs to the inner surface of the **outer** cylinder. Figure, neutrality and Gauss law agree against the printed “inner cylinder.” |
| E02 | p11 s21 | Definite overstatement | “Potential always continuous” fails at the point-charge singularity already present in `q/r`; qualify to finite ordinary interfaces away from singular sources. |
| E03 | p1 s2; p13 s25 | Incomplete universal statement | C depends on geometry **and material response**. Slide 5 and baseline `C=εA/d` give a direct counterexample at fixed geometry. |
| E04 | p3 s5 | Overbroad microscopic explanation | Non-spherical molecules are not a necessary general definition of a dielectric, nor a sufficient condition for permanent polarity. Baseline induced-dipole and dipole-cancellation premises supply the relevant distinction. |
| E05 | p2 s4 | Insufficient causal argument | Fixed-Q energy rises on plate separation, but external mechanical work can supply that rise; the formula does not establish why charge remains on the disassembled dielectric. |
| Q01 | p5 s10 | Model limitation | Ninefold power and unchanged fractional decay time are correct at fixed R; a heated lamp does not generally satisfy fixed R, and fixed absolute-threshold time is not unchanged. |
| Q02 | p9 s18 | Unnecessarily strong shortcut | Constant E over an entire closed surface is not required; symmetry must make normal flux computable, with possible zero-flux pieces. |
| Q03 | p12 s24 | Incomplete theorem statement | Must satisfy governing equation, source data, full appropriate boundary data and admissibility conditions. Field-line resemblance alone is insufficient. |
| Q04 | p8 s16 | Domain restriction | Continuous finite-energy vacuum density identity is valid under boundary conditions; ideal point self-energies diverge, and interaction energies after subtraction may be negative. |
| A01 | p2 s3 | Unresolved wording/circuit | “Outer and outer” may refer to two jars; no complete circuit justifies silently replacing one word or choosing a unique discharge outcome. |
| A02 | p7 s13 | Direction ambiguity in figure | The r arrow seems sourceward; the force formula needs a declared source-to-observation unit vector. |
| A03 | p7 s14 | Underspecified example | Three holes are visible, but density, size and 3D geometry are not. Exact superposition subtraction is reconstructible; a numerical or unique point-source force is not. |
| A04 | p3 s6; p5 s10 | Demonstration outcome not calculable from packet | Initial capacitor energy is known; explosion/survival requires omitted electrical/thermal parameters. |
| A05 | p12 s23–24 | Geometry/boundary conditions missing | Long-cylinder formula needs an end-effect approximation; familiar image construction needs grounded infinite plane and physical-region restriction. |
| I01 | identity versus printed PDF | Provenance-label mismatch | Metadata says lecture 7/session L07; PDF consistently says Lecture 6. Preserve both; do not alter source or claim a different lecture was read. |

Typographical grammar (“thought” for “through,” “filed” for “field,” “loose” for “lose,” etc.) has no effect on the retained equations and is not inflated into a physical error. Flattened extracted equations were resolved against the native page image, not treated as source mathematical mistakes.

## 6. Focused validation and residual limits

Independent checks target consequential uncertainty only: energy/prefix arithmetic; series/parallel algebra and constraints; fixed-R discharge scaling; charge allocation in coaxial conductors; source-unit consistency; image-plane boundary/field reconstruction; and singularity/continuity caveats. This dossier does not claim an experimentally verified demonstration, a complete lecture transcript, an evaluated student, or a hidden complete course. The child calculation check is a current-run independent derivation from the same original packet, retained in this output directory; it is not an additional source or prior preparation.

No full proof of electrostatic uniqueness, microscopic dielectric law, distributional calculus, multidimensional integration theory, or dynamic discharge with inductance was imported as student prior knowledge. Conditions needed by the reconstructed examples are identified explicitly rather than attributed to the source. No recitation, problem-set, Purcell or neighboring lecture content was inspected. All 26 slides are accounted for above, including administrative scope, demonstrations, drawings and repeated summary formulas.

The dossier is held. It may be consulted only at the future D131 whole-freeze/current-package-and-prompt-only admission specified by the parent task. The parent receives completion statistics, exact file paths and hashes only, not these semantic findings.
