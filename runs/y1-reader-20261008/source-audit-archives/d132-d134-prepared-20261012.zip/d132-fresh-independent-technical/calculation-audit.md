# D132 independent calculation audit

Scope of the subsidiary pass: read source-identity.json and every original text page, and actually viewed all nine original fullpages PNGs, exclusively under original-inputs/D132. Originals were not modified. The subsidiary pass consulted no student baseline, other workspace content, history, packages, PROF, web, or browser. The parent preparer, who separately read the entire authorized baseline, corrected the unit-conversion paragraph below before sealing; that correction is explicitly identified. This is an internal source audit, not a teaching document.

Identity: the supplied metadata calls the item session mit-8-022-fall2004-L08 and lecture_number 8, while the visible title and footers say “8.022 (E&M) – Lecture 7”; the recorded source URL also ends in lecture7.pdf. Preserve that mismatch rather than silently relabelling the source. The nine PDF pages contain slides 1–17, two per page except page 9.

1. Current, density, and continuity (pages 1–4, slides 2–7)

- I = dQ/dt is correct when Q means signed charge transported across the specified oriented surface, not charge stored inside a volume. The separate enclosed-charge relation has the required minus sign: ∮ J·dA = −dQ_inside/dt for outward dA.
- The prism construction gives ΔQ = qnA uΔt cosθ and I = qn u·A correctly for uniform density and velocity over the swept prism. The figure distinguishes the velocity displacement and oriented area normal; θ is between them. J = nq u and the species/velocity-average generalizations are correct. Negative charge reverses the relation between carrier velocity and conventional current.
- SI current A = C/s and 1 A ≈ 2.998 × 10^9 esu/s are dimensionally and numerically consistent. J has SI units A/m²; volume charge density has C/m³.
- The differential continuity equation ∇·J + ∂ρ_charge/∂t = 0 follows for a fixed arbitrary volume. Slide 7's dρ/dt should be read as the local partial derivative. Steady charge density implies ∇·J = 0; it does not imply ρ_charge = 0 or absence of a static surface charge.

2. Ion figure discrepancy (page 3, slide 5)

The left electrode is explicitly marked positive and the right electrode negative; the battery's longer plate is also on the left. The drawn Cl− arrow points right, toward the negative electrode, while the Na+ arrow points left, toward the positive electrode. If these are ion-motion arrows, both directions are reversed for field-driven drift under the depicted polarity. The field points right, so Na+ drifts right and Cl− drifts left; both species then contribute conventional current to the right. Calling the two drawn arrows conventional-current arrows would not rescue the drawing, because the Na+ contribution would still be wrong. No competing imposed flow is shown. This is a visible figure inconsistency, not a text-extraction artifact.

3. Ohm's law, dimensions, and source wording (pages 4–6, slides 8–12)

- J = σE is the scalar, local, isotropic Ohmic constitutive assumption used throughout. Constant cross section A, uniform material σ, axial uniform E, and V defined as the potential drop along current give I = σAV/L and R = L/(σA) = ρ_resistivity L/A. The sign convention V = EL must mean upstream potential minus downstream potential.
- The listed unit labels are consistent: R is Ω in SI and s/cm in Gaussian electrostatic cgs; resistivity is Ω·m in SI and s in cgs, and conductivity is S/m or s⁻¹ respectively. The numerical table is not consistent with those units: its cgs entries use approximately 1.11 × 10⁻⁹ times the SI numerical values, but the correct multiplier is approximately 1.1126 × 10⁻¹⁰. The cgs entries are about ten times too large. The parent independently re-viewed the native page and derived the conversion from the source's 1 A = 2.998 × 10⁹ esu/s plus potential as energy per charge and 1 cgs mechanical energy unit = 10⁻⁷ J. This gives 1 electrostatic potential unit = 299.8 V, 1 electrostatic resistance unit = 8.988004 × 10¹¹ Ω, and 1 cgs resistivity unit = 8.988004 × 10⁹ Ω·m. The original subsidiary draft mistakenly accepted the observed table multiplier as a valid conversion; that draft statement was corrected before sealing. This checks internal conversion, not empirical values at an unspecified temperature.
- Slide 10 says resistance is the proportionality constant “between V and R”; the intended pair is V and I. Slide 8 visibly retains a yellow “More stuff here pleas…” editing note.
- The symbol ρ changes from volume charge density to resistivity at slide 10. They have different dimensions and must not be conflated. Likewise σ is conductivity whereas σ_q on slide 14 is surface charge density.
- “Describes how fast electrons can travel” is loose wording: the later formula relates resistivity to carrier density, charge, mass, and relaxation time. The temperature plot is schematic, with neither scale nor material specified; its plateau and increasing branch must not be treated as a universal quantitative law.

4. Spherical-shell resistance (page 7, slide 13)

For 0 < a < b, constant positive conductivity σ in the shell, steady radial current, and equipotential boundaries φ(a) = V, φ(b) = 0, the source's results are correct:

\[
\phi(r)=\frac{Vab}{b-a}\left(\frac1r-\frac1b\right),\qquad
\mathbf E(r)=\frac{Vab}{(b-a)r^2}\hat{\mathbf r},\qquad
\mathbf J(r)=\sigma\mathbf E(r),
\]

\[
I=4\pi r^2J_r=\frac{4\pi\sigma Vab}{b-a},\qquad
R=\frac{b-a}{4\pi\sigma ab}
=\frac{\rho_{\rm resistivity}}{4\pi}\left(\frac1a-\frac1b\right).
\]

The boundary values, derivative sign, radius-independent I, and dimensions all check. For V > 0, E and conventional current point outward. Independent integration dR = ρ_resistivity dr/(4πr²) gives the same expression. The thin-shell limit b − a ≪ a yields R ≈ ρ_resistivity(b − a)/(4πa²), and b → ∞ yields ρ_resistivity/(4πa).

Two compressed source steps need care: spherical symmetry alone gives φ = φ(r), not necessarily A + B/r; the latter also uses steady continuity and constant σ, hence Laplace's equation in the shell. Also the printed intermediate ∫ J·dA = J·A cannot literally factor a single constant vector J out over the whole sphere: its direction varies and the net vector area is zero. The correct reduction is J_r(r) times scalar spherical area 4πr². Neither issue changes the final answer.

5. Piecewise cylindrical conductor (page 7, slide 14)

Take the interface normal from material 1 (left) to material 2 (right), the same direction as the positive drawn current I. With equal cross sections and steady one-dimensional flow, J = I/A and E_i = I/(Aσ_i) = Iρ_i/A are correct signed axial components. Here ρ_i denotes resistivity.

The displayed Gaussian-cgs relation is correct with its implicit convention:

\[
\sigma_q=\frac{E_{2n}-E_{1n}}{4\pi}
=\frac{I(\rho_2-\rho_1)}{4\pi A}.
\]

If downstream conductivity is lower, ρ₂ > ρ₁ and the interfacial charge is positive; reversing that inequality makes it negative. No numerical conductivities are supplied, so the figure itself does not choose a charge sign. The source's E_surface must mean the field jump, not the one-sided field of an isolated sheet.

The factor 4π identifies Gaussian units. In SI with the same vacuum/background permittivity ε₀ on both sides, σ_q = ε₀(E₂n − E₁n) = ε₀I(ρ₂ − ρ₁)/A, in C/m². For a macroscopic free-charge boundary condition with different dielectric responses, the general SI expression is σ_free = ε₂E₂n − ε₁E₁n; one cannot silently transplant the vacuum form. In cgs the source has surface-charge units esu/cm² because Iρ/A has (esu/s)·s/cm². The established interfacial charge is static in steady flow; continuing accumulation would contradict equal currents. The derivation is a planar, axial-field idealization, without end/fringing or contact-resistance effects.

6. Collision-time averaging and conductivity (pages 8–9, slides 15–17)

The momentum expression p_i = m u_i,random + qE t_i is consistent if t_i is elapsed time since the most recent momentum-randomizing collision and E is constant over that flight. Averaging gives m⟨u⟩ = qE⟨t_age⟩ when the postcollision random velocity has zero ensemble mean. For electrons q < 0, the drift is opposite E, while J = nq⟨u⟩ is along E.

Slide 16 explicitly writes ∑ u_i → 0 for large N. The justified statement is (1/N)∑ u_i → 0 under the assumed unbiased averaging, not that the unnormalized sum approaches zero. Its earlier momentum equation includes 1/N, so the intended average is identifiable.

The source then labels τ = (1/N)∑ t_i “the average time between 2 collisions.” The instantaneous ensemble average in this derivation is instead the mean age since the last collision. Identifying it with the mean full collision interval requires a collision model. For stationary Poisson collisions of mean interval τ, both means equal τ and σ = nq²τ/m follows. For fixed full intervals T sampled at random phases, mean age is T/2, not T; more generally the stationary renewal mean age is ⟨T²⟩/(2⟨T⟩), provided those moments exist. Thus neither an automatic factor 1/2 correction nor unconditional equality of the two means is justified from the slide alone. The printed conductivity formula is consistent with the usual momentum-relaxation interpretation of τ, but the averaging explanation omits its assumption.

The final conductivity has the correct positive q² dependence and SI dimensions S/m (Gaussian cgs s⁻¹). The multiple-carrier sum is physically additive under the same independent linear-response assumptions, σ = ∑_k n_k q_k²τ_k/m_k. Slide 17's summation index is printed i = 1 while all summand subscripts are k; this is an index typo. Its upper N must count carrier species in this expression, rather than the N electrons used in slide 16.

Completion: all nine original text pages and all nine original fullpage PNGs were substantively read/viewed. The audit distinguishes incorrect source statements or figure directions from correct equations that require additional assumptions. No external action or teaching was performed.
