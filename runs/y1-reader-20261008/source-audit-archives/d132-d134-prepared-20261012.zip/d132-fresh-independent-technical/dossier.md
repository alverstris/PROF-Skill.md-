# D132 independent technical dossier

Status: held technical preparation for ongoing76materialPROFiteration. This is an internal source reconstruction and prerequisite audit. It is not a teaching package, student trial, SASIS run, admission decision, publication, or authorization to use findings before the future D132 whole freeze. Reopening is restricted to a later current-package/prompt-only admission. No bold or italic prose is used.

## 1. Evidence boundary and identity

The sole subject-content inputs were the entire original packet at `/workspace/scratch/f9c0b7fc7e76/original-inputs/D132` and the full baseline at `/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/inputs/student-baseline.txt`. No external links were opened. No other workspace source, prior preparation, report, queue, history, PROF package, author material, web page, or browser supplied premises. Source-identity metadata contains historical repository paths and an acquisition cache path; those strings were read as metadata and none of those locations was accessed. Originals were preserved unchanged.

The supplied identity says material D132, session `mit-8-022-fall2004-L08`, series `mit-8-022-fall2004`, and lecture_number 8. The native source visibly says `8.022 (E&M) – Lecture 7`; all content-slide footers repeat Lecture 7, and the recorded resource/source URL is lecture7. This is an identity-label discrepancy to preserve, not a basis for silently changing the supplied material ID. The supplied published-project revision is `54ebb635d842f1d65c2508b8f921fd32819f5f0c`.

The exact PDF is 103541 bytes, SHA-256 `6d9dc979afd3cb0d057ffd03dd7a181c4619ae8cdfcca3a1200d07a74fa0578a`. It has nine physical pages and seventeen slide panels: two slides on pages 1–8, one on page 9. PDF metadata: title `Microsoft PowerPoint - Lecture7.ppt`, author `sciolla`, PDF 1.3, creator `PScript5.dll Version 5.2`, producer `Acrobat Distiller 6.0 (Windows)`, creation `D:20040929223407-04'00'`, modification `D:20041214194953+05'30'`. These are file facts, not researched author history.

The original packet contains twenty files, 1100426 bytes total: the PDF, source identity, nine page-text files, and nine native full-page PNGs. All native PNGs were actually emitted/viewed at their full-page aspect ratio. Page 6 was viewed a second time at original detail to resolve its numerical table. All original text pages were read in full. Independent PDF parsing confirmed nine pages and that re-extraction of every page equals its supplied text file. No missing extraction or replacement rendering was needed.

The baseline is 247840 bytes, 246945 decoded Unicode characters, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. Its complete four-subject text was read, including both Further Mathematics options. The read ledger covers all original bytes in eleven contiguous successful displays. One oversized attempted display of lines 601–900 was truncated and is excluded from coverage; that entire interval was reread in two untruncated displays. Line references in this dossier use the ledger's explicitly recorded `str.splitlines(keepends=True)` convention, preserving original CR/CRLF bytes.

## 2. Notation and dimensions

The source reuses symbols in ways that matter to its argument. In this dossier, rho_q denotes volume charge density and rho_R electrical resistivity; sigma denotes conductivity and sigma_q surface charge density. The source itself prints rho for both densities and resistivity, and A for both area and a potential integration constant.

| Quantity | Meaning and sign | SI unit | Source electrostatic-cgs convention |
|---|---|---|---|
| Q_cross | signed charge transported through an oriented surface | C | esu |
| Q_inside | signed charge stored in a fixed enclosed volume | C | esu |
| I | signed charge flow per time | A = C/s | esu/s |
| n_k | number of carriers of species k per volume, nonnegative | m^-3 | cm^-3 |
| q_k | signed charge per carrier | C | esu |
| u_k | carrier velocity; drift is an ensemble mean | m/s | cm/s |
| J | conventional current density | A/m^2 | esu/(s cm^2) |
| rho_q | signed volume charge density | C/m^3 | esu/cm^3 |
| E | force per positive unit charge | V/m = N/C | electrostatic field unit |
| sigma | scalar local conductivity | S/m | s^-1 |
| rho_R | reciprocal conductivity | ohm m | s |
| R | V_drop/I in an Ohmic geometry | ohm | s/cm |
| sigma_q | signed interfacial surface charge per area | C/m^2 | esu/cm^2 |
| tau | effective drift relaxation time; age/interval interpretation needs a model | s | s |

The source's `1 A = 2.998 × 10^9 esu/s` is a rounded current/charge conversion. Its later interfacial `4 pi` formula is Gaussian/electrostatic cgs and must not be substituted using SI numerical electric fields or SI resistivities without conversion. The resistivity table has a separate numerical conversion problem, detailed in section 7; the printed unit labels themselves are dimensionally coherent.

## 3. Complete page and slide reconstruction

### Page 1, slides 1 and 2: scope and current

Slide 1 is a title panel. Its three topics are electrical currents, conductivity and resistivity, and microscopic/macroscopic Ohm's law. There are no hidden numerical questions or extra figures in the panel.

Slide 2 defines current as charge per unit time through a specified surface, writes I = dQ/dt, and gives SI and cgs units plus the current conversion above. The visual is a horizontal green cylinder with black carrier dots and rightward arrows, including carriers at its circular right cross section. It represents directed transport; it does not display a microscopic thermal-velocity distribution or an explicit electrode circuit. The sign convention of an oriented crossing must distinguish this Q from the later stored Q_inside. For a negative carrier moving right, q u points left: dots/arrows alone do not fix conventional current unless the carrier sign is specified.

### Page 2, slide 3: current density from a swept prism

The source specifies carrier number density n and common velocity u, with each carrier charge q. Over a time interval Delta t, the carriers crossing a flat area A occupy a prism of volume A u Delta t cos(theta). The chain of equalities is

    I = Delta Q/Delta t = q Delta N/Delta t
      = q n V_prism/Delta t = q n A u cos(theta)
      = q n u dot A = J dot A,
    J = q n u = rho_q u.

The diagram separates a green carrier cylinder and a skew prism whose red face is the crossing surface. A red vector A is normal to that face, the displacement u Delta t is marked along the prism, and theta is the angle between velocity and the area normal. The normal, not a tangent to the area, controls cos(theta). A parallel-to-face velocity produces zero normal flux; reversing the selected normal reverses signed I.

Conditions are local uniform n, q and u over the swept region, a fixed flat surface, and a sufficiently appropriate interval for the uniform construction. The surface has an orientation; A as a scalar area is nonnegative, whereas the area vector includes its selected direction. Number density times signed q gives species charge density. For multiple species, total charge density can vanish while their charge-weighted velocities yield nonzero current; J = rho_total times one arbitrary common velocity must not be inferred.

### Page 2, slide 4: species, averages and arbitrary surfaces

The slide explicitly relaxes three assumptions: one carrier kind, the same particle velocity, and a regular surface with constant J. It writes

    J = sum_k q_k n_k u_k = sum_k rho_k u_k,
    <u_k> = (1/N_k) sum_i (u_k)_i,
    J = sum_k q_k n_k <u_k> = sum_k rho_k <u_k>,
    I = integral_S J dot dA.

The example is a solution with different ions; a positive ion moving with u is equivalent in current contribution to a negative ion of equal charge magnitude moving with -u. The printed equality presumes the corresponding number densities/charge magnitudes when comparing total contributions. The last expression introduces a field-dependent, oriented surface integral rather than merely a named dot product. dA includes the local normal and positive patch area. A physically useful continuum mean averages enough carriers while retaining the spatial resolution of J; the source gives no averaging-scale prescription.

### Page 3, slide 5: ionic-current example and the native diagram problem

The text identifies electrons in a conductor as only one current example and names NaCl solution and Demo F5. The diagram shows a pale-blue rectangular electrolyte, two green electrodes joined to a battery, a positive left electrode and negative right electrode, a red Cl-minus ion with a rightward arrow, and a black Na-plus ion with a leftward arrow. The cell symbol's longer plate is also on the left. Thus the indicated ionic motions point toward electrodes of like sign. Under the depicted field-driven transport, both arrows are reversed: the electric field and Na-plus drift are rightward; Cl-minus drift is leftward. Both correct species contributions to conventional current are rightward. No pressure-driven flow, concentration-gradient forcing, or other alternative mechanism is specified. This is a source-image discrepancy, not OCR damage. Demo F5 is named only; its procedure and result are not supplied and cannot be reconstructed as an additional accessible resource.

### Page 3, slide 6: integral and differential conservation

The green irregular closed-surface sketch has arrows entering on the left and leaving on the right/lower side, labelled J, with S in the interior. The questions ask what happens to entering charge: it accumulates inside or leaves. With outward area vectors,

    integral_closed_S J dot dA = - partial Q_inside/partial t.

The source then displays the divergence theorem and charge integral, leading to

    integral_V [div J + partial rho_q/partial t] dV = 0,
    div J + partial rho_q/partial t = 0.

This uses a fixed control volume with closed boundary S, charge conservation, Q_inside = integral_V rho_q dV, sufficient regularity for differentiation under the integral/divergence theorem, and validity for every suitable volume to infer a pointwise vanishing integrand. At a discontinuity the integral form is the safe direct statement; a separate interface statement accounts for surface charge. The text names Gauss's theorem and shows its integral equality but does not define partial derivatives, divergence, local vector-field differentiation or general volume/surface integration. Those are substantive prerequisites, distinct from arithmetic and ordinary one-dimensional integration.

### Page 4, slide 7: steady currents

The same closed-surface sketch accompanies the continuity equation. The source identifies it as conservation of electric charge in the presence of currents and sets d rho/dt = 0 for no accumulation in steady conditions, concluding div J = 0. Here the intended derivative is the partial time derivative at fixed position. A constant stored charge in one chosen volume alone does not imply local stationarity everywhere; the local inference concerns arbitrary volumes or pointwise stationarity. Neither div J = 0 nor steady flow requires rho_q = 0, no interfacial charge, or zero current. A time-independent surface charge is compatible with the later two-material example.

### Page 4, slide 8: local Ohm's law

The slide says an electric field causes charges to move and supplies the empirical proportionality J = sigma E, with sigma named conductivity. It states that this relation holds point by point. This is a constitutive law for the scalar isotropic Ohmic response used in the lecture, not a replacement for charge conservation or a universal conclusion from F = qE. Its use assumes local response with the material conditions held fixed. Different temperatures or fields that change the material response need not share one constant sigma. The panel visibly retains a yellow editing note reading `More stuff here pleas...` at the lower right. That note is a source artifact and supplies no missing physics.

### Page 5, slide 9: from local to terminal law

The sketch is an axially extended conductor with cross-sectional area A, length L, rightward J and E. The stated assumptions are uniform material and uniform axial electric field, E parallel to L. With V the upstream-minus-downstream potential drop, V = EL. Constant cross section and uniform axial J then give

    I/A = sigma V/L,
    V = I R,
    R = L/(sigma A).

The scalar positive resistance requires L > 0, A > 0, and finite sigma > 0. V and I may both reverse sign consistently. In a varying geometry or material the single uniform-wire formula cannot be applied by inserting one arbitrary A or sigma. The figure's irregularly drawn end shape does not require a circular cross section: only its area and constancy are used.

### Page 5, slide 10: resistance

The slide gives R = L/(sigma A) = rho_R L/A; SI ohm = V/A; cgs s/cm; R proportional to length, inversely proportional to area, and inversely proportional to conductivity at fixed other quantities. Its opening prose says proportionality between V and R, which is a typo: the intended pair is V and I. The displayed equation and the previous slide make that repair unambiguous. Here rho changes meaning from volume charge density to resistivity; the quantities are not interchangeable.

### Page 6, slide 11: resistivity table and material properties

The slide defines rho_R = 1/sigma, calls it a descriptor of how fast electrons travel, gives SI ohm m and cgs s, and names material chemistry and temperature as dependencies. The speed wording is incomplete: drift at a given E depends on response per carrier, and resistivity additionally depends on carrier number density and charge. The later Drude expression makes those distinctions explicit. It is not a statement about every individual electron's speed or the speed at which a circuit signal propagates.

The table is visible in the PNG but absent from the supplied page-text extraction. Every row is transcribed here exactly in numerical content; the cgs column is not silently repaired:

| Material | Source SI resistivity (ohm m) | Source cgs resistivity (sec) |
|---|---:|---:|
| Silver | 1.6 × 10^-8 | 1.8 × 10^-17 |
| Copper | 1.7 × 10^-8 | 1.9 × 10^-17 |
| Gold | 2.4 × 10^-8 | 2.6 × 10^-17 |
| Iron | 1.0 × 10^-7 | 1.1 × 10^-16 |
| Sea water | 0.2 | 2.2 × 10^-10 |
| Polyethylene | 2.0 × 10^11 | 220 |
| Glass | approximately 10^12 | approximately 10^3 |
| Fused quartz | 7.5 × 10^17 | 8.3 × 10^8 |

The table provides no temperature, purity, salinity or other measurement conditions. Its SI numbers are source data, not independently verified contemporary material constants. Its cgs column is about a factor ten too large relative to its SI column under the source's own electrostatic charge convention; see the explicit conversion calculation in section 7. Demos F1 and F4 are named without accessible procedures.

### Page 6, slide 12: temperature dependence

The graph is an unscaled schematic of rho against T: a positive horizontal low-temperature plateau joins an increasing straight branch. It does not depict a zero-resistance transition, negative-temperature-coefficient material, fit data, or a numerical crossing temperature. Text explains room-temperature increase by more collisions; low-temperature mean free path is said to be dominated by impurities/defects, giving approximate temperature independence; some sufficiently pure metals are said to become superconductors. This is a qualitative metallic model. The baseline itself contains thermistors and semiconductors with decreasing resistance as temperature rises, so this slide cannot warrant a universal positive coefficient. The source supplies no superconductivity theory, critical temperature or proof that purity alone determines whether a material superconducts. No such missing content is inferred.

### Page 7, slide 13: spherical-shell example

The native figure is a cross-sectional annulus: an inner sphere radius a at potential V, a yellow resistive shell extending to radius b, and an outer red boundary at potential zero connected to a ground symbol. The shell is labelled rho; the inner white region shows V. The construction is concentric, and a and b are radii from the same centre, not thicknesses. The explicit question is the resistance R. It is a worked example, with the result displayed on the same slide; there is no supplied numerical a, b, V or material value.

The source assumes microscopic Ohm and writes a spherical potential phi = A + B/r. Boundary conditions phi(a) = V and phi(b) = 0 give

    phi(r) = V [ab/((b-a)r) - a/(b-a)]
           = Vab/(b-a) [1/r - 1/b],
    E(r) = Vab/[(b-a)r^2] r_hat,
    J_r(r) = sigma Vab/[(b-a)r^2],
    I = 4 pi sigma Vab/(b-a),
    R = (b-a)/(4 pi sigma ab)
      = rho_R/(4 pi) (1/a - 1/b).

These final formulas check for 0 < a < b, a <= r <= b, constant positive isotropic sigma, steady radial current, and equipotential spherical contacts. E and conventional current are outward when V > 0. The field derivative is negative-gradient: differentiating the decreasing positive potential produces outward E. I is independent of r because area 4 pi r^2 cancels the inverse-square density.

Two source compressions must remain visible. Spherical symmetry alone only establishes phi(r); the A+B/r form additionally needs the steady conservation/material equation, or an equivalent no-volume-source Laplace argument. And the printed integral reduction to `J dot A` is not a legitimate factorization of one globally constant vector J over a sphere: radial J changes direction, and the sphere's vector area sums to zero. The valid evaluation uses J_r times scalar surface area, locally parallel J and outward normal. The source's resulting I and R are nevertheless correct.

### Page 7, slide 14: two materials in series and interfacial charge

A cylindrical conductor is split transversely into a left blue region sigma_1 and right yellow region sigma_2; I points right. Equal cross-sectional area A and steady current give

    I = A sigma_1 E_1 = A sigma_2 E_2,
    E_i = I rho_Ri/A,
    sigma_q = (E_2 - E_1)/(4 pi)
            = I(rho_R2-rho_R1)/(4 pi A).

Choose the interface normal from region 1 to region 2 and interpret E_i as its signed normal component. Conductivities that differ imply different E for nonzero I. Lower downstream sigma means larger rho_R2, a positive field jump and positive sigma_q in the source convention. No numerical conductivities are given, so the drawing does not independently fix the sign. Equal conductivities or zero current give zero jump in this model.

The displayed `E_surface` must mean the jump E_2-E_1, not one side's field from an isolated sheet. The `4 pi` expression uses electrostatic cgs and total electric-charge boundary conditions in the adopted material model. An SI expression with vacuum/background permittivity would be sigma_q = epsilon_0(E_2-E_1); if free charge and different macroscopic dielectric responses are intended, the normal displacement-field jump needs specified permittivities. The source gives none. These distinctions delimit the equation; no extra dielectric model is admitted as prior knowledge.

The explanatory line says charge can accumulate where conductivity changes, necessary for steady flow. There is a transient establishment and then a static interfacial charge; equal steady currents forbid ongoing net accumulation. The derivation assumes axial fields, a simple transverse interface, no side leakage, and neglect of end/fringing/contact effects. Potential can remain continuous while its normal derivative and E jump; the source does not claim a finite potential step.

### Page 8, slide 15: the apparent acceleration/drift conflict

The panel contrasts a constant field and steady drift with Newton's law and acceleration. It gives J = sigma E, then E proportional to velocity versus E proportional to acceleration. The point is sustained average drift under scattering, with a terminal-speed skydiver analogy. The figure is a rectangular lattice-like region with green circular centres in two rows, a zigzag path between red end dots, and E rightward. It illustrates interruptions of free acceleration; it supplies no collision angle distribution or identifiable time marks.

The prose says charges bump into nuclei and scatter. For this level the operational content is momentum interruption/randomization by the medium. Literal collisions with bare nuclei are not a complete general microscopic explanation of material resistivity; the baseline's lattice-scattering description is more carefully limited. The source does not supply the microscopic theory required to replace the model. The skydiver analogy concerns a balance in average motion, not equality of mechanical air drag and electronic scattering laws.

### Page 8, slide 16: momentum average

The source considers N electrons in E and writes a random postcollision momentum m u_0 plus electric impulse q E t. For each particle i, the consistent microscopic expression is

    p_i = m u_random,i + q E t_i,
    m <u> = (m/N) sum_i u_random,i + (qE/N) sum_i t_i.

The last displayed expression becomes m<u> = qE tau after vanishing random mean and tau = (1/N) sum_i t_i. Here t_i in the impulse is age since the last momentum-resetting collision. The source also calls tau the average time between two collisions, which is not generally the same average. The figure-free panel does not specify a collision-time distribution or a momentum-relaxation law to establish that identification.

The printed statement `sum_i u_i -> 0` for large N omits the normalization. The meaningful unbiased-average claim is `(1/N) sum_i u_random,i -> 0`, subject to sampling assumptions; an unnormalized random sum need not shrink. The earlier averaging equation includes the missing normalization, so the intended repair is identifiable. The source uses u for both random and total/mean motion; those roles must remain distinct. For electrons q is negative, so <u> is opposite E while J = nq<u> has the same direction as E.

### Page 9, slide 17: single- and multi-carrier conductivity

Combining J = nq<u> with m<u> = qE tau gives

    J = (n q^2 tau/m) E,
    sigma = n q^2 tau/m.

The multiple-carrier generalization is

    sigma = sum_k n_k q_k^2 tau_k/m_k.

Each contribution is nonnegative for positive number density, mass and relaxation time, regardless of carrier charge sign. This assumes independent additive linear responses to the same local field. The summation is over carrier species; N in the preceding slide counted electrons, so reusing N without clarification changes its meaning. The printed lower summation index is i = 1 while the summand uses k, an index typo. Page 9's lower half is blank and contains no omitted second panel or exercise.

## 4. Baseline prerequisite warrants and boundaries

The following are warrants about supplied premises, not a claim of measured student performance. All four subjects were read rather than only searching the electrically relevant words. The baseline treats completed courses as a provisional competence assumption and permits explicit cross-subject deduction. Its source links are provenance, not extra lookup resources.

| Source operation | Available baseline warrant | What the warrant does and does not establish |
|---|---|---|
| Current as charge rate; I = nqAu for aligned drift | Physics current/circuits, line 1073; Mathematics rates/calculus | Charge sign, conventional current, metallic/electrolyte carriers, and swept-length carrier counting are already available. The derivative notation extends the rate model using supplied calculus. |
| n times volume counts particles | Mathematics prism/cylinder volumes and proportions; Physics number density; Chemistry mole counting CH-01.03 | Counting and dimensions are available. A field-dependent three-dimensional density integral still needs its measure/interpretation. |
| q n u dot A | FM18, line 713; Mathematics component vectors; Physics flat magnetic flux, line 1293 | Real scalar products, cos of the normal angle and flat uniform flux analogy are available. An oriented area vector and arbitrary surface integral are not silently pre-taught. |
| Species and particle sums/averages | Mathematics sigma notation and descriptive mean; FM38/FM45, lines 755/769 | Linear sum/average operations are available; weighted species contributions follow the supplied charges. A physical velocity-distribution model and scale of coarse graining are additional premises. |
| Continuity conservation intuition | Physics Kirchhoff junction law, line 1089; Chemistry charge-balanced equations | Charge conservation and equal steady series currents are available. Local divergence, partial time derivative, Gauss theorem and arbitrary-volume localization are not granted by the topic label. |
| General div, grad, partial derivatives and field surface/volume integrals | FM69, line 819; Mathematics inventory's stated multivariable limits; Physics concluding scope | Explicitly outside the starting formalism. Source displays equations involving them but gives no full definitions. Ordinary one-variable calculus alone does not license treating them as already understood. |
| Local Ohm's law and conductivity | Physics R = V/I with constant-condition Ohm law, line 1081; uniform-wire resistivity, line 1085 | R, rho_R and macroscopic temperature conditions are available. J = sigma E and its local/isotropic meaning are supplied by this source. |
| V = EL and uniform-wire R | Physics broad parallel-plate field, line 1273; work/charge and algebra | Uniform scalar field-to-drop relation and algebra support the rod result with declared orientation and uniform geometry. A signed arbitrary-field line integral is a further formulation. |
| SI dimensions and numerical precision | Mathematics elementary units; FM57, line 795; Physics quantities/constants; CH-01.01 | SI checks and powers/prefixes are available. Electrostatic-cgs normalization is not established merely by knowing SI electric units. The source gives some cgs facts but not a full system conversion account. |
| Metal carriers, ionic carriers, and scattering | Physics current/circuits and resistivity, lines 1073/1085; Chemistry CH-02.02, lines 1564/1572 | Mobile ions in melts/solution, mobile electrons in metals, conventional-current signs and metal-versus-semiconductor thermal contrasts are available. No detailed electron-band or superconductivity theory follows. |
| Cell polarity in ion figure | Physics circuit symbols, line 1081; F=qE, line 1269 | Long cell plate positive and positive-charge field direction make the source arrow discrepancy decidable from the actual baseline. Chemistry galvanic anode/cathode terminology alone must not be transplanted indiscriminately to an externally driven cell. |
| Radial sphere geometry | Mathematics sphere surface area 4 pi r^2; Physics point/exterior spherical field and potential, lines 1269/1273 | Area, inverse-square/r potential examples and differentiation are available. They do not prove phi=A+B/r for arbitrary radial conducting material or general rho_q. |
| Solve two potential boundary conditions | Mathematics simultaneous equations; power differentiation and integration | Determining A,B and checking derivative/boundary signs is available once the potential form is warranted. |
| Radial steady-current shell route | Source I surface integral, continuity, local Ohm; baseline area, ordinary integration and series resistances | A scalar radial route can be reconstructed without assuming a memorized Laplacian. Its steps must explicitly use conservation and geometry; symmetry alone is insufficient. |
| Electric-field jump at a material interface | Source slide 14 formula | Baseline electric field and Coulomb law do not grant the general Gaussian boundary theorem. The source formula may be used with its units/sign/domain supplied, but its derivation is not established by prior curriculum. |
| Electric impulse and drift | Physics F=qE, acceleration, momentum/impulse; FM61, line 803 | Constant-force impulse qEt and signed charge response follow directly. Zero-mean random postcollision motion and resetting are model premises, not consequences of the impulse rule alone. |
| Mean relaxation time and limiting averages | FM38/FM43/FM45/FM46, lines 755/765/769/771; ordinary statistics | Sample and distribution means and sample-mean variance are available. They distinguish normalized mean from sum, but do not select a physical collision distribution. |
| Constant-rate random collision countermodel | FM41/FM44, lines 761/767 | Poisson counts and exponential waiting times are explicitly supplied. Applying them to electron scattering requires an additional stated physical assumption; the baseline does not assert that real collisions obey it. |
| Uniform-phase periodic collision countermodel | FM44 uniform density plus FM30 mean, lines 767/737 | A hypothetical fixed flight interval with uniform observed phase has mean age T/2 by baseline integration. It is a counterexample to unconditional age=interval, not a proposed actual material law. |
| Possible transient relaxation calculation | FM32 and FM68, lines 741/817 | A supplied linear drag/relaxation equation could be solved. Having the solving method does not supply the absent relaxation equation or its physical tau. No such extension is required to reconstruct the original slides. |

The Chemistry baseline was not merely nominally present: its complete quantities, electron/bonding, inorganic, rates/equilibrium, acids/buffers, enthalpy/entropy, electrochemistry, organic, spectroscopy and practical sections were read through CH-REF. Its directly relevant warrants are the charge of ions/electrons, metallic/ionic conductivity, counting particles from moles, charge balance and separation of electron and ionic transport. The remaining sections do not provide missing vector calculus, microscopic electronic transport distributions, Gaussian electric units, or a general interface theorem. The full Mathematics and both Further Mathematics options similarly supply substantial calculus and probability, but FM69 explicitly preserves the multivariable/field-integral boundary.

## 5. Independent reconstruction checks

These calculations verify consequential source steps or resolve a concrete source ambiguity. They are not new assessment questions or a teaching sequence. Numeric examples below are declared verifier fixtures, not source data.

### 5.1 Spherical shell

Steady radial current through a concentric sphere is I = 4 pi r^2 J_r. Combining J_r = sigma E_r with E_r = -dphi/dr gives dphi/dr = -I/(4 pi sigma r^2). Integration from a to b yields V = I/(4 pi sigma)(1/a-1/b), and hence the source R. This uses only the source field/conservation relation with the baseline's one-dimensional power integral and sphere area, once their radial meaning is explicitly stated.

The boundary checks are phi(a)=V and phi(b)=0. Differentiation gives the displayed E_r. The dimension is resistivity/length, therefore ohms in SI. The thin-shell limit b=a+d, d/a small, gives R approximately rho_R d/(4 pi a^2); the limiting outer radius b to infinity gives rho_R/(4 pi a). The a to zero limit diverges at fixed rho_R, showing that a point electrode is outside a finite-resistance substitution. Taking b=a exactly removes the resistive thickness and also makes the intermediate potential expressions singular; it is a limit, not a permitted substitution in those expressions. At V=0 the source's literal quotient V/I is 0/0, while the linear-response coefficient R is the limiting ratio or constitutive coefficient.

### 5.2 Interface sign and conservation

With rightward normal and current, E_2-E_1 = (I/A)(rho_R2-rho_R1). Thus the sign is fixed by the resistivity contrast and chosen normal, not by the color of the materials. Integrated conservation on a vanishing pillbox gives d sigma_q/dt = J_1n-J_2n in the no-side-flux idealization; equal currents make the established surface charge static. This is the precise compatibility between slides 7 and 14. The source Gaussian jump law then determines the static charge, but the needed electrostatic field law is separate from current conservation.

### 5.3 Random sum and age versus interval

For independent random postcollision velocities with zero component mean and finite component variance s^2, the mean of N samples has variance s^2/N by the baseline's sampling rule, whereas the unnormalized sum has variance Ns^2. The source's intended cancellation belongs to the mean, not the bare sum.

A fixed flight duration T and uniform observation phase on [0,T] give mean age integral_0^T t dt/T = T/2. Thus a flight interval's mean cannot be identified with the instantaneous mean age purely by the word average. Under a declared constant-rate Poisson collision model the no-collision probability over a preceding interval t is exp(-t/tau), giving an exponential age of mean tau, equal to the exponential waiting-time mean. These are different conditional models, both compatible with the algebra until a collision law is specified. The source's formula sigma=nq^2tau/m is consistent with tau as momentum-relaxation time or a Poisson age mean; neither automatically inserting 1/2 nor asserting equality for every collision process is justified.

The general stationary-renewal expression mentioned in the subsidiary audit can be reconstructed as a conditional mathematical check rather than prior physical content: each full interval T contributes age integral T^2/2 and elapsed time T, so long-run time averaging gives E(T^2)/(2E(T)) where the moments and stationary averaging exist. That statement is not used to assume any real collision process and is not required to accept the source's explicitly declared relaxation model if supplied later.

### 5.4 Conductivity dimensions and carrier sign

Substituting the signed q into drift produces J=nq(qE tau/m), and hence q^2 rather than q. The density/charge/time/mass expression has SI dimensions C^2 s/(kg m^3) = S/m. In electrostatic cgs, q^2 has dimensions g cm^3/s^2, giving sigma in s^-1 and rho_R in s. With tau finite and positive, electrons contribute a positive conductivity even though their velocity is opposite the field. As an algebraic model tau tending to infinity predicts no finite steady drift; the steady-response assumption then fails rather than defining ordinary resistance-free accelerating electrons by the same stationary argument.

### 5.5 Resistivity table conversion

This check defines the cgs mechanical unit rather than presuming an unavailable conversion table. The source uses electrostatic charge units. One cgs energy unit is g cm^2/s^2, which is 10^-7 J from gram and centimetre conversion. Potential is energy/charge, supplied by the baseline. The source current conversion gives one esu = 1/(2.998 × 10^9) C. Consequently

    1 electrostatic potential unit = 299.8 V,
    1 electrostatic resistance unit = 8.988004 × 10^11 ohm,
    1 cgs resistivity unit = (1 cgs resistance unit)(1 cm)
                          = 8.988004 × 10^9 ohm m,
    rho_R,cgs [s] = 1.1125940753920448 × 10^-10 rho_R,SI [ohm m].

This also agrees at the baseline's precision with the factor 4 pi epsilon_0 = approximately 1.1121 × 10^-10 in compatible SI numerical units, though no independent electrostatic unit theorem is needed for the work/charge calculation. The source table instead uses approximately 1.11 × 10^-9 seconds per ohm metre. Its entries are therefore about ten times the correct cgs numerical values for their own SI column. The discrepancy is systematic across metals, sea water and insulators, not an isolated exponent misreading. The code/result artifact records each predicted conversion and ratio. This check does not establish the empirical accuracy of the SI material values.

## 6. Source exercise and figure inventory

There is one explicit quantitative worked geometry question: spherical-shell resistance, with its full answer printed on slide 13. There is one qualitative/two-material application asking what changes when sigma is not constant, also answered on slide 14. The remaining questions are prompts about charge accumulation, continuity, temperature dependence and drift versus acceleration; they are not independent numerical assessment items. No separate problem set, answer key, rubric, or unsolved numerical data accompanies this packet.

Figure access is complete: carrier cylinder on slide 2; carrier cylinder and inclined swept prism on slide 3; ionic circuit on slide 5; closed-current surface on slide 6; reused closed-current surface on slide 7; uniform-conductor geometry on slide 9; resistivity table on slide 11; temperature sketch on slide 12; spherical-shell cutaway and grounded outer sphere on slide 13; two-material cylinder on slide 14; scattering-path illustration on slide 15. Slides 1, 4, 8, 10, 16 and 17 have no additional independent scientific figure beyond equations/text. The source's page footers and slide numbering were distinguished throughout.

## 7. Error, ambiguity and limitation register

| ID | Location | Classification | Evidence and bounded resolution |
|---|---|---|---|
| D132-E01 | identity versus all visible footers | identity discrepancy | Metadata says L08/lecture_number 8; source says Lecture 7 and lecture7. Preserve both without reassigning D132. |
| D132-E02 | p3/s5 ionic circuit | visible physical inconsistency | Both ion-motion arrows are reversed for shown electrode/battery polarity. Baseline charge/field direction decides the correction. |
| D132-E03 | p4/s8 | editorial artifact | Yellow incomplete editing note supplies no physics and must not be silently treated as substantive content. |
| D132-E04 | p5/s10 | prose typo | Resistance is proportionality between V and I, not V and R; displayed equation fixes intent. |
| D132-E05 | p2 through p7 | notation hazard | rho changes from charge density to resistivity; sigma and sigma_q are different dimensional quantities. |
| D132-E06 | p6/s11 | systematic numerical unit error | Source cgs resistivity column is approximately tenfold its values inferred from the source SI column and current-unit convention. All eight rows checked; no empirical external lookup used. |
| D132-E07 | p6/s11 | loose physical language | Resistivity is not solely a speed; later n,q,m,tau expression supplies the specific dependence. |
| D132-E08 | p6/s12 | unspecified domain/qualitative model | The increasing rho(T) branch is a schematic metallic regime; no universal law, numerical fit or superconducting critical data are supplied. |
| D132-E09 | p7/s13 | missing warrant | Symmetry alone does not yield A+B/r. Steady current conservation plus constant sigma and radial field supply the needed inverse-square step. |
| D132-E10 | p7/s13 | invalid vector shorthand with correct final result | Global J dot A over the sphere cannot replace the integral literally; use local radial component times scalar area. |
| D132-E11 | p7/s14 | unit and boundary convention omission | 4 pi is cgs; normal and definition of surface charge/background permittivity must be fixed. E_surface denotes a jump, not a one-sided field. |
| D132-E12 | p7/s14 | temporal wording ambiguity | Established interface charge may be static; ongoing accumulation is incompatible with equal steady currents. |
| D132-E13 | p8/s15 | model simplification | Nucleus-collision/viscous analogy does not constitute a detailed microscopic resistivity theory. Its intended content is momentum scattering and average drift. |
| D132-E14 | p8/s16 | mathematical normalization error | The source prints a bare random sum approaching zero; the normalized mean is the meaningful statement. |
| D132-E15 | p8/s16 | missing stochastic/model premise | Age since last collision is used in impulse but called mean full interval. Equality requires a model; fixed-period uniform-phase counterexample gives T/2. |
| D132-E16 | p9/s17 | index and symbol typo | Lower summation index i conflicts with summand k; number of species must be distinguished from number of electrons. |
| D132-E17 | p3/s6 and p4/s7 | notation/regularity compression | Partial versus total time derivative, fixed control volume, arbitrariness of volume and differentiability are unstated conditions for the displayed local continuity equation. |
| D132-E18 | p6 table and demos | access/content limit | All table rows require visual access because extraction omitted them; F1/F4/F5 are names only, and no missing demo behavior can be supplied from memory. |

The corrected arithmetic and warrant boundaries do not invalidate the correct shell-resistance formula, local Ohm algebra, continuity conservation sign, species conductivity sum, or source cgs interface formula within its stated convention. They specify exactly which premises and repairs those conclusions require. No outcome about future student trials or package admissibility is claimed.

## 8. Held handoff

The payload includes this dossier, the independent subsidiary calculation audit, focused executable calculations and results, complete original-input checksums, an input inventory, the full-baseline read ledger, and a page/access coverage manifest. The subsidiary audit initially repeated the table's apparent conversion factor; the parent independent unit calculation corrected that statement before sealing and the correction is explicitly recorded there. No unresolved computation was hidden by agreement between agents.

The source packet and baseline hashes were rechecked during sealing. The payload manifest records checksums of all delivered files. The seal binds that manifest and records the held state; its own detached checksum avoids a circular self-hash. Findings are not communicated semantically to the root before the future D132 whole freeze. Root receives only completion statistics, paths and hashes. This dossier remains sealed pending a later current-package/prompt-only admission instruction.
