"""Focused source checks for held D132 preparation; no external data or packages.

Original table numbers are transcribed from original PNG page 6, slide 11.
The geometry fixture is independently chosen and is not an original example.
The original packet and baseline are not modified.
"""
from pathlib import Path
import hashlib
import json
import math

OUT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/scratch/f9c0b7fc7e76/original-inputs/D132/source.pdf')
BASELINE = Path('/workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/inputs/student-baseline.txt')

assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == '6d9dc979afd3cb0d057ffd03dd7a181c4619ae8cdfcca3a1200d07a74fa0578a'
assert hashlib.sha256(BASELINE.read_bytes()).hexdigest() == '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'

# Source current conversion plus mechanical g/cm/s energy and V = W/Q.
coulombs_per_esu = 1 / (2.998e9)
joules_per_cgs_energy = 1e-3 * (1e-2)**2
volts_per_cgs_potential = joules_per_cgs_energy / coulombs_per_esu
ohms_per_cgs_resistance = volts_per_cgs_potential / coulombs_per_esu
ohm_metres_per_cgs_resistivity = ohms_per_cgs_resistance * 1e-2
seconds_per_ohm_metre = 1 / ohm_metres_per_cgs_resistivity

table = [
    ('Silver', 1.6e-8, 1.8e-17, False),
    ('Copper', 1.7e-8, 1.9e-17, False),
    ('Gold', 2.4e-8, 2.6e-17, False),
    ('Iron', 1.0e-7, 1.1e-16, False),
    ('Sea water', 0.2, 2.2e-10, False),
    ('Polyethylene', 2.0e11, 220.0, False),
    ('Glass', 1e12, 1e3, True),
    ('Fused quartz', 7.5e17, 8.3e8, False),
]
rows = []
for material, si, printed, approximate in table:
    predicted = si * seconds_per_ohm_metre
    rows.append({
        'material': material,
        'source_si_ohm_m': si,
        'source_cgs_seconds': printed,
        'source_uses_approximate_sign': approximate,
        'calculated_cgs_seconds': predicted,
        'printed_divided_by_calculated': printed / predicted,
    })

# Declared verifier fixture: SI a,b, sigma,V; no source numerical data implied.
a, b, sigma, voltage = 0.02, 0.05, 4.0, 2.0
coef = voltage * a * b / (b - a)
phi = lambda r: coef * (1 / r - 1 / b)
er = lambda r: coef / r**2
resistance_direct = (b - a) / (4 * math.pi * sigma * a * b)
resistance_integrated = (1 / sigma) * (1 / a - 1 / b) / (4 * math.pi)
rs = [a, (a + b) / 2, b]
currents = [4 * math.pi * r**2 * sigma * er(r) for r in rs]
assert math.isclose(phi(a), voltage, rel_tol=1e-12)
assert math.isclose(phi(b), 0.0, abs_tol=1e-12)
assert math.isclose(resistance_direct, resistance_integrated, rel_tol=1e-12)
assert all(math.isclose(i, voltage / resistance_direct, rel_tol=1e-12) for i in currents)

results = {
    'scope': 'Focused source consistency calculations, held; fixture values are not original source data.',
    'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'baseline_sha256': hashlib.sha256(BASELINE.read_bytes()).hexdigest(),
    'resistivity_unit_conversion': {
        'coulombs_per_esu': coulombs_per_esu,
        'joules_per_cgs_energy': joules_per_cgs_energy,
        'volts_per_cgs_potential': volts_per_cgs_potential,
        'ohms_per_cgs_resistance': ohms_per_cgs_resistance,
        'ohm_metres_per_cgs_resistivity': ohm_metres_per_cgs_resistivity,
        'seconds_per_ohm_metre': seconds_per_ohm_metre,
        'source_table_rows': rows,
        'finding': 'Printed cgs values are approximately tenfold conversion-consistent values; empirical SI values not externally checked.'
    },
    'spherical_shell_fixture': {
        'fixture_not_source_data': True,
        'units': 'SI',
        'a_m': a, 'b_m': b, 'conductivity_S_per_m': sigma, 'V': voltage,
        'phi_at_a_V': phi(a), 'phi_at_b_V': phi(b),
        'test_radii_m': rs, 'currents_A': currents,
        'direct_resistance_ohm': resistance_direct,
        'integrated_radial_resistance_ohm': resistance_integrated,
        'boundary_and_conservation_checks_passed': True,
    },
    'collision_age_countermodels': {
        'fixed_interval_T_uniform_observation_phase': 'mean age = integral_0^T t dt/T = T/2, while mean full interval is T',
        'stationary_constant_rate_poisson_rate_1_over_tau': 'P(age>t)=exp(-t/tau), hence exponential mean age tau and mean waiting time tau',
        'physical_status': 'Explicit hypothetical collision models; neither inferred as actual material behavior from the baseline alone.',
    },
    'random_average_check': {
        'conditions': 'Independent zero-mean component samples with finite variance s^2',
        'mean_variance': 's^2/N',
        'unnormalized_sum_variance': 'N*s^2',
        'finding': 'The source cancellation belongs to normalized mean, not unnormalized sum.',
    },
}
(OUT / 'focused-calculations.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'completed': True, 'source_table_rows_checked': len(rows), 'sphere_fixture_checks_passed': True}))
