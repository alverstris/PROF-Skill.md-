"""Focused D133 checks, from the permitted original circuit data only.

Illustrative equal-parameter values for the two-loop counterexample are declared
explicitly and are not represented as source data. No input files are read.
"""
from fractions import Fraction
import json


def focused_calculations():
    V = Fraction(3, 2)
    R = Fraction(912)
    RL = Fraction(1580)
    Req = R + 1 / (1 / R + 1 / (R + RL))
    I0 = V / RL
    I = V / Req
    U = V - I * R
    Ishunt = U / R
    Iload = U / (R + RL)
    # Independent node equation, solved as a linear scalar balance.
    U_node = (V / R) / (2 / R + 1 / (R + RL))
    if U != U_node:
        raise ArithmeticError('F12 series/parallel and node results differ')
    if not (I == Ishunt + Iload and V - I * R - Iload * (R + RL) == 0):
        raise ArithmeticError('F12 conservation residual is nonzero')

    # Slide 20: compare its printed formulas with its own loop equations.
    R1 = R2 = R3 = Fraction(1)
    V1 = V2 = Fraction(1)
    D = R1 * R2 + R1 * R3 + R2 * R3
    I1 = (V1 * R3 + (V1 - V2) * R2) / D
    printed_I2 = ((V1 - V2) * R2 + V2 * R1) / D
    corrected_I2 = ((V1 - V2) * R2 - V2 * R1) / D

    def residuals(first, second):
        return [V1 - first * R1 - (first - second) * R2,
                -V2 - second * R3 - (second - first) * R2]

    printed_residuals = residuals(I1, printed_I2)
    corrected_residuals = residuals(I1, corrected_I2)
    if corrected_residuals != [0, 0]:
        raise ArithmeticError('Corrected two-loop formulas fail source equations')

    # Half-equation count/charge audit of the original p3 reactions.
    # Count tuples are (Pb, H, S, O, net charge); e- contributes -1 charge.
    species = {
        'Pb': (1, 0, 0, 0, 0),
        'PbO2': (1, 0, 0, 2, 0),
        'HSO4-': (0, 1, 1, 4, -1),
        'PbSO4': (1, 0, 1, 4, 0),
        'H+': (0, 1, 0, 0, 1),
        'e-': (0, 0, 0, 0, -1),
        'H2O': (0, 2, 0, 1, 0),
        'H2SO4': (0, 2, 1, 4, 0),
    }

    def atom_charge_total(terms):
        return tuple(sum(coeff * species[label][i] for label, coeff in terms.items())
                     for i in range(5))

    reactions = [
        ({'Pb': 1, 'HSO4-': 1}, {'PbSO4': 1, 'H+': 1, 'e-': 2}),
        ({'PbO2': 1, 'H+': 3, 'HSO4-': 1, 'e-': 2}, {'PbSO4': 1, 'H2O': 2}),
        ({'Pb': 1, 'PbO2': 1, 'H2SO4': 2}, {'PbSO4': 2, 'H2O': 2}),
    ]
    chemistry_balances = [atom_charge_total(lhs) == atom_charge_total(rhs)
                          for lhs, rhs in reactions]
    if not all(chemistry_balances):
        raise ArithmeticError('Original lead-cell atom/charge balance failed')

    return {
        'F12': {
            'V_volts': str(V), 'R_ohms': str(R), 'RL_ohms': str(RL),
            'equivalent_R_exact': str(Req), 'equivalent_R_ohms': float(Req),
            'first_total_current_mA': float(1000 * I0),
            'second_total_current_mA': float(1000 * I),
            'junction_voltage_V': float(U),
            'shunt_current_mA': float(1000 * Ishunt),
            'load_branch_current_mA': float(1000 * Iload),
            'load_voltage_V': float(Iload * RL),
            'total_current_change_percent': float(100 * (I - I0) / I0),
            'KCL_exact': I == Ishunt + Iload,
            'KVL_branch_exact': V - I * R - Iload * (R + RL) == 0,
            'independent_node_solution_matches_exactly': U_node == U,
        },
        'two_loop_counterexample': {
            'chosen_values': 'R1=R2=R3=1 ohm; V1=V2=1 V',
            'source_I1_A': str(I1), 'source_I2_A': str(printed_I2),
            'source_left_loop_residual_V': str(printed_residuals[0]),
            'source_right_loop_residual_V': str(printed_residuals[1]),
            'correct_I1_A': str(I1), 'correct_I2_A': str(corrected_I2),
            'correct_shared_R2_current_downward_A': str(I1 - corrected_I2),
            'correct_loop_residuals_V': [int(x) for x in corrected_residuals],
        },
        'lead_cell_stoichiometry': {
            'species_count_tuple': ['Pb', 'H', 'S', 'O', 'net charge'],
            'both_half_reactions_and_overall_atoms_and_charge_balanced': chemistry_balances,
            'source_energy_eV_per_written_reaction': '4.4',
            'electrons_per_written_reaction': 2,
            'conditional_voltage_if_full_energy_is_electrical_work_V': float(Fraction(44, 10) / 2),
            'energy_value_or_thermodynamic_identity_independently_verified': False,
        },
        'scope': 'Focused source-derived calculations only; equal-parameter counterexample is not source data. No optional numerical sweep or test suite.',
    }


if __name__ == '__main__':
    print(json.dumps(focused_calculations(), ensure_ascii=False, indent=2))
