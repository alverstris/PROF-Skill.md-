# D133 fresh independent technical dossier

Status: held source-only preparation. Prepared in ongoing76materialPROFiteration on 2026-10-12. This is not a student teaching document, SASIS activity, publication, trial, or admission decision. All semantic findings remain held until the future D133 whole-freeze. Later use requires the then-current package and prompt; this sealed preparation alone is not authority to proceed.

## Scope and evidence boundary

Only the complete original packet at /workspace/scratch/f9c0b7fc7e76/original-inputs/D133 and the complete four-subject file /workspace/scratch/f9c0b7fc7e76/d016-clean-r37-20261012/inputs/student-baseline.txt supplied subject premises. No other workspace content, other material, prior preparation, report, queue, history, PROF package, skill package, web page, browser, or author contact was consulted. Confinement was instructional, not a claim of technical isolation. Standard local parsing, image decoding, hashing, file writing and arithmetic were operational tools, not further subject sources.

All source-identity.json content was read. All 12 original text files were read in full. Every one of the 12 original native PNGs was actually viewed and emitted through the image tool, in four consecutive three-page batches. The original PDF was independently parsed as 12 pages; fresh in-memory text extraction exactly matched all 12 supplied text files. No extraction or rendering replacement was needed. Original files were preserved.

The entire 2,561-line baseline was read, sequentially, in 15 bounded and untruncated chunks. This included the cover, Mathematics A H240, Further Mathematics A H245 Pure Core Y540/Y541 and both selected options Statistics Y542 and Mechanics Y543, Physics A H556, and Chemistry A H432. The full line/chunk coverage and every original file hash are in access-coverage-manifest.json. Baseline exposure is an explicit competence assumption; it is not measured student mastery.

Input anchors:

| Input | Bytes | SHA-256 |
|---|---:|---|
| Original source.pdf | 103687 | 3b301472dae82e7c7efa486dbbe240b184e1a0f68c4eadd735ca9c96e9cade7c |
| Original source-identity.json | 12520 | d6311453e4cfe0cd0c94c93bf328767f1b54c505edbe3132f5ef79fb73c07f2b |
| Complete student-baseline.txt | 247840 | 3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5 |

The identity labels the session mit-8-022-fall2004-L10 and lecture_number 10. The actual PDF cover and every footer call it 8.022, Lecture 8, with G. Sciolla–MIT attribution. The identity's source/resource URLs also name lecture8. These are distinct recorded identifiers, not grounds to replace the source or silently renumber the material. The original PDF is the hash-matched object assigned to D133. There are 12 physical PDF pages and 23 visible slides: slide 1, then slides 3 through 24. No slide labelled 2 is present. This is an observed numbering gap, not an unread physical page. The historical URLs and repository/acquisition references inside identity were read as provenance only and were not followed.

## Notation and model ledger

The source uses V for a battery voltage/emf, resistor drop magnitudes, and sometimes a general potential difference. The baseline distinguishes source emf ℰ, terminal voltage V, and signed potential differences. In this dossier ℰ denotes the ideal source value where needed, V_X is a node potential, V_XY = V_X − V_Y, and ΔV along a traversal is V_end − V_start. A positive resistance drop magnitude IR equals minus the signed change when following a positive current. Source notation is retained when reconstructing a displayed equation, and the interpretation is stated separately.

The current arrow is an assigned positive direction, not a prior assertion that the physical current follows it. Negative solutions reverse the physical direction. For a resistor with its current reference running from a to b, V_a − V_b = IR. Traversing a to b contributes −IR to a sum of signed potential changes; traversing b to a contributes +IR. A source traversed from negative to positive contributes +ℰ; the reverse traversal contributes −ℰ.

The elementary circuit examples assume lumped components, ideal connecting wires, negligible node charge accumulation, a consistent electrostatic/quasistatic potential description, and no unaccounted changing magnetic flux linked by the loop. Series means the same branch current must pass through each component without an intervening branch. Parallel means both terminals join the same pair of nodes. Shape or adjacency on the drawing does not define either relation. Resistance comparisons below presume finite positive passive resistances and a fixed applied voltage. Current-dependent, temperature-dependent or other nonlinear states must be separately specified.

The source does not explicitly teach all these formal domain limits. Some are already warranted by the baseline's circuit rules, energy and charge accounting, induction, and model-evaluation instructions; others are the limits needed to prevent its shorthand from being overgeneralised. They are recorded here as technical distinctions, not as an already-delivered student explanation.

## Full source reconstruction and page coverage

### PDF page 1: slide 1, cover

The cover is headed 8.022 (E&M) – Lecture 8. The two announced topics are electromotive force and circuits/Kirchhoff's rules. It is a single bordered slide surrounded by broad blank margins. No numerical task, circuit or hidden second slide is present. The course/lecture identity discrepancy with the supplied metadata is retained above.

### PDF page 2: slides 3 and 4

Slide 3, Quiz 1: thoughts, reports average 59 and RMS 16, compares the preceding year's average 64, and calls the test slightly harder than average. It says Problem 1 had subtleties and intimidating-looking mathematics. Grades below 40 are described as very serious danger, with TEAL recommended; 40 < grade < 50 prompts changes/more work. It describes 8.022 as hard, suggests discussion with the lecturers, bringing the exam and problem sets, and gives a historical exam-posting time of 12:30 PM. These statements are course administration and commentary. They establish neither this student's competence nor a diagnostic rule for this task. The cohort difficulty inference is not established by the two means alone. If RMS means root mean square of raw scores, 16 is incompatible with a mean of 59; a centred rms/standard deviation would be coherent, but the slide does not specify centring.

Slide 4, Last time, displays:

- I = dQ/dt.
- J = q n u = ρ u, with J and u vectors.
- ∇·J + ∂ρ/∂t = 0.
- Microscopic Ohm law J = σE; macroscopic V = IR.
- Conductivity σ = nq²τ/m.
- R = L/(σA).

The visual reading resolves symbols that the text extraction interleaves. Here q is the signed carrier charge, n a number density, u a drift velocity, and ρ = qn a charge density for a single carrier population. For several mobile species the single-product expression cannot silently represent all separate drift velocities. The source's conductivity expression is a prior-lecture recall, with τ and m not defined on this slide. Its use requires a carrier mass and an applicable relaxation-time transport model; knowing a label such as conductivity does not establish that model. The scalar relation J = σE presumes a locally linear, isotropic constitutive description. R = L/(σA) applies to a uniform conductor of constant cross-section, length L along the current, uniform relevant conductivity, and negligible contact/end contributions. Charge density ρ here is not the electrical resistivity ρ_electrical in the Physics baseline; uniform scalar conductivity would give σ = 1/ρ_electrical.

The baseline supplies I = ΔQ/Δt, carrier counting I = nAe v_drift, calculus, vector arithmetic, R = ρ_electrical L/A, and Ohm's law with its state conditions. Thus the derivative form and the uniform normal-flow current-density relation can be supported by explicit deductions. The baseline does not supply divergence or partial-derivative calculus; ∇·J + ∂ρ/∂t = 0 is not operationally taught by being printed without definitions. The baseline already provides circuit charge conservation, so one does not need to pretend this continuum equation was mastered to use Kirchhoff's junction rule later.

### PDF page 3: slides 5 and 6

Slide 5, EMF: Electromotive force, asks what makes circuit charges flow and names a potential difference plus a source of charges. It says emf supplies these, explicitly warns that emf is not a force, and gives a battery as a device maintaining charge separation between two electrodes. Internal current is attributed to electrochemical reactions producing ΔV.

The baseline already defines emf as energy supplied per charge and potential difference as energy transferred per charge. The phrase source of charges needs care: neither the stated redox chemistry nor the baseline makes a battery a source creating net charge. Conducting components already contain mobile carriers; the battery transfers chemical energy and participates in charge redistribution and electrode reactions. The supplied half-equations conserve charge.

Slide 6, Car Battery, shows a positive PbO₂ electrode on the left and a negative porous Pb electrode on the right immersed in H₂SO₄. A leftward arrow labelled H⁺ lies in the electrolyte. The source calls the first material lead oxide and the second porous lead. Its line about reaction at the lead oxide says electron where electrode is intended. The native slide, unlike the jumbled extraction, gives the following equations:

Pb + HSO₄⁻ → PbSO₄ + H⁺ + 2e⁻.

PbO₂ + 3H⁺ + HSO₄⁻ + 2e⁻ → PbSO₄ + 2H₂O.

Pb + PbO₂ + 2H₂SO₄ → 2PbSO₄ + 2H₂O + 4.4 eV.

Every atom and charge balances in each half-equation. The Pb electrode loses two electrons and is oxidised from 0 to +2 in PbSO₄; Pb in PbO₂ is reduced from +4 to +2. Adding the half-equations gives Pb + PbO₂ + 2H⁺ + 2HSO₄⁻ → 2PbSO₄ + 2H₂O. The written molecular overall equation accounts for the same elemental quantities with two sulfuric-acid units. It is the supplied reaction, not a grant of a full acid-speciation model. The two electrons transfer through the external circuit from the negative Pb electrode to the positive PbO₂ electrode during discharge. Conventional external current is opposite.

The source supplies 4.4 eV as released energy but supplies neither a thermodynamic derivation, reference electrode data nor operating conditions for that number. Conditional energy-per-charge accounting gives 4.4 eV divided by 2e = 2.2 V if that entire quoted energy per written reaction is available as electrical work. This is a conditional inference, not an independently verified cell potential or evidence about the number of cells in an assembled car battery. Nothing in this packet warrants importing a familiar nominal car-battery voltage.

The H⁺ arrow is a schematic indication associated with the chemical account. It does not prove all current inside the electrolyte is carried only by H⁺, give a transport rate, or specify a field profile. General ionic conduction and charge balance are baseline facts; a detailed quantitative electrochemical transport model is absent.

### PDF page 4: slides 7 and 8

Slide 7 adds an external resistor between the same electrodes. PbO₂ remains positive on the left, Pb negative on the right. In the electrolyte E points right, while H⁺ points left. Text says disconnected terminals have no electron flow; the internal field prevents H⁺ flow and inhibits the reaction. On connection, electrons flow, the field is reduced, H⁺ can flow and reaction proceeds.

This is a qualitative battery picture, not a supplied solution for the internal charge distribution or reaction kinetics. A positive ion's electric force points with E; the displayed H⁺ direction is against that electric force. Chemical driving and species distributions must therefore matter to any faithful account. The packet does not give equations establishing when the field is reduced or a quantitative on/off criterion for the reaction. The baseline's distinction between feasibility and reaction rate also prevents treating an energetically favoured reaction as automatically unrestricted current.

The slide then identifies battery emf with φ(positive terminal) − φ(negative terminal), described as ΔV available to drive the circuit, and prints:

EMF = integral from negative terminal to positive terminal of E·ds.

For E as the electrostatic field shown on the figure, this has the wrong sign for the stated potential difference. Even the uniform-segment sign test is decisive: ds from the right-hand negative electrode towards the left-hand positive electrode is opposite the drawn E, so E·ds is negative, while φ₊ − φ₋ is positive. The electrostatic-field form compatible with that potential convention is φ₊ − φ₋ = −∫₋⁺ E·ds. Calling E a non-electrostatic driving force per unit charge could give an energy-supply interpretation, but the slide explicitly draws and discusses the electric field and supplies no such redefinition. This is a source-level inconsistency, not an extraction artefact.

In addition, terminal potential difference equals emf only for the ideal/no-loss limit, or when open-circuit conditions make internal voltage loss negligible. The source later introduces internal resistance, and the baseline explicitly gives terminal V = ℰ − Ir during discharge. The slide's earlier equality cannot be used unconditionally for a loaded real source.

Slide 8, Convention, draws the cell symbol with a long positive bar, short negative bar, and an upward current arrow leaving its positive terminal. It says conventional current flows from positive to negative and warns this can feel counterintuitive when thinking about electrons. The symbol and external discharging-circuit convention are already in the baseline. The qualification external matters: within a discharging source the conventional current completes its path from the negative terminal toward the positive terminal. The statement is not a rule that current always goes from + to − through every element, including the interior of an energy-supplying source or a source being charged.

### PDF page 5: slides 9 and 10

Slide 9, Kirchhoff's second rule, has an ideal source V on the left, a single resistor R on the right, and clockwise I across the top. It gives I = V/R and a resistor signed potential change ΔV = −IR. The boxed loop rule says the sum of emf and potential drops around any closed loop is zero. It calls this equivalent to electrostatic conservativity and displays ∮E·ds = 0.

For this steady lumped resistive model, the loop is +V − IR = 0. The field's zero closed integral describes electrostatic potential, whereas the energy supplied by battery chemistry is not work by a conservative electric force creating a net rise around a closed spatial path. A signed circuit potential accounting can be consistent while the emf denotes supplied non-electrical energy per charge. The wording must not identify all driving agency with electrostatic E or extend the electrostatic condition to a loop with unaccounted changing magnetic flux. The Physics baseline contains induction and Lenz's law as well as the ordinary loop law, so the restricted context can be distinguished without removing known circuit competence.

Slide 10, Solving circuits, has V on the left and three resistors in a single clockwise loop: R₁ across the top, R₂ down the right, R₃ across the bottom. It asks for all currents and voltages, states that current must be equal everywhere to avoid charge accumulation, and writes a voltage drop in resistor i as ΔVᵢ = −IRᵢ. The displayed loop calculation is V − ΣVᵢ = V − IΣRᵢ = 0, hence I = V/(R₁ + R₂ + R₃), with i = 1,2,3.

The display is coherent if Vᵢ means the positive magnitude IRᵢ while ΔVᵢ denotes the signed traversal change −IRᵢ. If one treats Vᵢ and ΔVᵢ as the same signed quantity, its signs become inconsistent. The source leaves this distinction implicit; it is a notation hazard rather than proof that the correct resulting series formula is false. Equal current assumes the steady/no-accumulation circuit model, not that charges could never redistribute during switch-on.

### PDF page 6: slides 11 and 12

Slide 11 repeats the three-resistor calculation and replaces the left-hand series chain by one R_eq connected to the same source. The two drawings share the same applied V and total I; R_eq = ΣRᵢ is boxed. The equivalence is a two-terminal current–voltage equivalence under the adopted resistor model, not identity of all internal voltage drops or heat locations.

Slide 12 labels the same rectangle's corners A (top left), B (top right), C (bottom right), D (bottom left); V is the source between D and A with positive at A. It asks for V_AB, V_BC, V_CD, V_DA, V_AC, and so on. The printed answers are:

V_AB = IR₁ = VR₁/(R₁ + R₂ + R₃).

V_BC = IR₂ = VR₂/(R₁ + R₂ + R₃).

V_CD = IR₃ = VR₃/(R₁ + R₂ + R₃).

V_AC = I(R₂ + R₁) = V(R₂ + R₁)/(R₁ + R₂ + R₃).

These establish the implicit convention V_XY = V_X − V_Y, not potential change on travelling X to Y. Set V_D = 0; then V_A = V, V_C = IR₃, V_B = I(R₂ + R₃). The requested but unprinted V_DA is −V. Under this convention V_AD = V, V_BD = I(R₂ + R₃), and reversing any pair changes its sign. The VAC numerator's order R₂ + R₁ is equivalent to R₁ + R₂, not an error. R_total must be nonzero for the displayed quotients; the intended passive case has all Rᵢ > 0.

### PDF page 7: slides 13 and 14

Slide 13, Application (F13), asks about measuring resistances of electrical components. A single series loop has five zigzag-labelled components: R₅ and R₄ across the top, R₃ down the right, R₁ and R₂ across the bottom, and a battery at left. Its component list is saline solution, resistor, diode (spelled Diod), light bulb, and fluorescent light (spelled Fluoreschent). It does not assign the listed physical components to particular R-number labels. The prompt says the current is 135 mV and supplies a voltmeter.

mV is a unit of voltage, so the stated current value is dimensionally invalid. The original native PNG confirms that exact unit; it is not caused by extraction. Nothing in the packet establishes whether mA was intended or whether 135 mV belongs to a missing reference-resistor measurement. No numerical resistance can be recovered without a valid current value and the measured p.d. across each component. The warranted conditional operation is to connect a voltmeter across a selected component, obtain its operating voltage magnitude Vᵢ, and calculate its operating ratio Rᵢ = Vᵢ/I using a valid common branch current. A high input resistance/minimal loading condition is needed to treat the original series current as unchanged. For nonlinear elements, that operating ratio is not automatically a fixed ohmic resistance or a differential resistance. The baseline explicitly includes this distinction for component characteristics, diode behaviour, filament heating and meter connections. No new numerical demonstration results are invented.

Slide 14, Kirchhoff's first rule, draws R₁ and R₂ as parallel vertical branches between a top and bottom rail, with source V at the left. I enters top node N from the left; I₁ points down R₁ and I₂ down R₂. It states current divides into two pieces and boxes total current in = total current out. Thus I = I₁ + I₂. It describes this as no charge accumulation in the circuit. The quantitative conservation statement for a finite node region would be dQ_node/dt = I_in − I_out; setting the left side to zero is the model underlying the displayed equality. This scalar balance is obtainable from baseline current/charge reasoning and calculus without assuming knowledge of ∇·J.

### PDF page 8: slides 15 and 16

Slide 15 solves the same parallel circuit. Because each resistor shares both source nodes, V = I₁R₁ and V = I₂R₂. It obtains I₁ = V/R₁, I₂ = V/R₂, and I = I₁ + I₂ = V(1/R₁ + 1/R₂).

Slide 16 places that drawing alongside an ideal source with one R_eq. The same terminal V and total I imply 1/R_eq = Σᵢ1/Rᵢ. For two finite nonzero resistors this also gives R_eq = R₁R₂/(R₁ + R₂), provided the denominator is nonzero. The intended positive-resistance case avoids cancellation singularities. An ideal short must be treated by its limiting topology rather than direct substitution into 1/0; an open branch is a zero-conductance limit. The source does not ask for such limiting cases, but they delimit use of its displayed algebra. Equal voltage follows from common endpoints, not from equal current in the branches; equal currents need equal R in this ideal model.

### PDF page 9: slides 17 and 18

Slide 17 compares series and parallel. Its series sketch has one path through successive resistors; adding positive series resistance at fixed source V increases R_eq and decreases total I. With at least two finite strictly positive series terms, R_eq exceeds every individual term. Its parallel sketch has additional branches across the same endpoints; adding a finite positive conductance increases total current at fixed V and lowers R_eq. With at least two finite positive branches, R_eq is smaller than every individual branch resistance. These are conditional comparisons, not universal statements for active/negative-resistance devices, an imposed fixed current, or arbitrary source behaviour.

Slide 18, Application (F12), compares two circuits. The first is a source V = 1.5 V, a series ammeter on the return lead, and a load R_L = 1580 Ω. The source states ammeter reading 0.94 mA. In the second circuit the same V symbol supplies a resistor R on the upper-left path to junction X. From X, one R runs directly down to the return rail. The alternative branch from X goes through an upper-right R and then R_L down the right edge to the same return rail. The ammeter stays in the common lower-left return lead. Its reading is total source current, not current solely through R_L. Given R_L = 1580 Ω and each R = 912 Ω, it asks for the ammeter reading.

The topology is R in series with [R parallel (R + R_L)], hence

R_eq = R + R(R + R_L)/(2R + R_L)
     = (3R² + 2RR_L)/(2R + R_L)
     = 1344288/851 Ω
     ≈ 1579.65687426557 Ω.

Assuming the same ideal 1.5 V source and ideal ammeter, the first predicted current is 1.5/1580 A ≈ 0.9493670886 mA, and the second is ≈ 0.9495733057 mA. The total currents are almost equal: the second is about 0.0217215% larger with these supplied resistor values. Their conventional two-significant-figure rounding is 0.95 mA. The slide's reported 0.94 mA can be treated as an observed reading with unspecified measurement/model precision; it does not exactly follow by rounding the ideal supplied numbers and does not justify replacing 1.5 V by an invented effective source value. Without meter/source precision, the small discrepancy cannot be uniquely diagnosed.

The junction voltage is about 0.6339891452 V. Current through the direct shunt R is about 0.6951635364 mA. Current through the R + R_L branch is only about 0.2544097693 mA, and the load voltage is about 0.4019674355 V. Exact fraction arithmetic verifies both branch KVL and KCL. Equal or almost equal ammeter readings therefore do not imply equal current or voltage at the load.

A conditional algebraic observation explains the chosen values: R_eq = R_L simplifies to 3R² = R_L², giving R = R_L/√3 for positive R. R_L/√3 ≈ 912.213 Ω; the printed 912 Ω is close. The source does not state this design intention, so it remains an independently derived explanation of the numerical near-equality, not a recovered oral claim.

### PDF page 10: slides 19 and 20

Slide 19, Slightly harder circuits, has a left voltage source V₁ whose positive terminal connects through R₁ to an upper junction U; R₂ connects U to the lower-left common node L. The right source V₂ has its positive terminal at U; its lower terminal connects through bottom-right R₃ to L. The slide says simple resistor series/parallel reduction does not work because of the second emf and suggests applying Kirchhoff's first rule at nodes and second rule around loops.

The explanation is specific to this topology: R₂ is not in simple parallel with a bare R₃, because V₂ lies in that path; R₁ and R₂ do not have the same forced current because of the branch. The bare presence of a second source is not, by itself, a universal prohibition on every circuit simplification or on other derived equivalent-source methods. Such advanced methods are not required for this example.

The first drawing places the I₁ label on a downward arrow by R₂, whereas the solution drawing on slide 20 places I₁ on a rightward arrow through R₁. The solution's equations use the latter meaning. The first figure's I₁ placement cannot simultaneously denote the shared-branch current under those equations. Both show I₂ directed to the right across the top of the right loop.

Slide 20 assigns I₁ rightward through R₁ and I₂ rightward across the top of the right loop, down through V₂ and leftward through R₃. Therefore the downward current through R₂ is I₁ − I₂. Its two printed loop equations are:

V₁ − I₁R₁ − (I₁ − I₂)R₂ = 0.

−V₂ − I₂R₃ − (I₂ − I₁)R₂ = 0.

Equivalently,

(R₁ + R₂)I₁ − R₂I₂ = V₁,

−R₂I₁ + (R₂ + R₃)I₂ = −V₂.

Let D = R₁R₂ + R₁R₃ + R₂R₃. For positive finite R₁,R₂,R₃, D > 0 and the solution is unique. The source prints:

I₁ = [V₁R₃ + (V₁ − V₂)R₂]/D.

I₂ = [(V₁ − V₂)R₂ + V₂R₁]/D.

The first is correct. The second has an incorrect plus sign before V₂R₁. Solving the source's own displayed equations gives:

I₂ = [(V₁ − V₂)R₂ − V₂R₁]/D.

The source expression differs from this by 2V₂R₁/D. Substitution of both printed formulas leaves first-loop residual 2V₂R₁R₂/D and second-loop residual −2V₂R₁(R₂ + R₃)/D. They are nonzero in the generic intended positive-parameter case. This is confirmed on the native PNG, not inferred from mangled extracted text.

An independent node-potential reconstruction reaches the same conclusion. Set V_L = 0 and V_U = U. Then I₁ = (V₁ − U)/R₁, current downward through R₂ is U/R₂, and I₂ = (U − V₂)/R₃. Charge balance gives (V₁ − U)/R₁ = U/R₂ + (U − V₂)/R₃, so U = R₂(V₁R₃ + V₂R₁)/D. Back substitution gives the corrected I₁ and I₂ and I_R2 = (V₁R₃ + V₂R₁)/D downward.

A focused counterexample uses R₁ = R₂ = R₃ = 1 Ω and V₁ = V₂ = 1 V as illustrative check values, not original source data. The source formulas give I₁ = I₂ = 1/3 A, making the central current zero while the left loop residual is 2/3 V and the right residual −4/3 V. The corrected values are I₁ = 1/3 A, I₂ = −1/3 A and downward central current 2/3 A, with both residuals zero. A negative I₂ is valid: its initially chosen arrow reverses, as the source itself says assigned directions are arbitrary.

The yellow procedure box correctly allows arbitrary current directions and either clockwise or anticlockwise traversal. It gives emf positive from − to + and negative from + to −. Its final statement, V always drops on R, is incomplete as a traversal rule. Potential drops along the actual conventional current in a passive resistor, but a loop traversed opposite the assigned positive current contributes +IR rather than −IR. The source's shared-resistor equations already require this distinction.

### PDF page 11: slides 21 and 22

Slide 21, Internal resistance, attributes current inside the battery to ionic motion, recalling H⁺ in the previous example, and says internal dissipation makes the battery hot and removes energy otherwise available to the circuit. It replaces the battery by an ideal source V with a series resistor r. It states I_max = V/r and suggests shorting a little battery with wire as homework to observe heating.

The source's linear model, combined with the already supplied baseline, gives I = ℰ/(R_external + r), terminal V = ℰ − Ir, internal dissipation I²r, and input chemical/electrical-source power ℰI. For ℰ > 0, r > 0 and nonnegative external resistance, current is bounded by ℰ/r within that fixed-parameter model; the equality is the ideal R_external → 0 limit. It is not a universal physical maximum for every battery independent of state, temperature, chemistry or transient behaviour. The model predicts large short-circuit internal dissipation ℰ²/r; its own premises therefore explain why the suggested uncontrolled experiment can cause damaging heating. No physical experiment was performed. The source supplies no current limit, battery specification or safe procedure; its homework sentence is recorded as a source issue, not an instruction to carry out.

The source's reference to chemical reaction dissipation should not obscure the distinction between energy supplied by the reaction and losses represented by r. The baseline already supplies internal power loss I²r and source emf as supplied energy per charge; no detailed microscopic dissipation mechanism is established by this equivalent circuit.

Slide 22, Power dissipated in resistors, gives dW = Vdq and then P = dW/dt = Vdq/dt = VI. With Ohm's law it displays P = VI = RI². The dimensions are energy/time; it names cgs erg/s and SI J/s. It associates power with light and heat output.

For a resistor, take V as the drop magnitude corresponding to the current direction, so VI is absorbed power and is nonnegative for positive R. Signed general element voltages/current require a consistent passive sign convention; a supplying source is not necessarily dissipating VI under every chosen direction. P = V²/R follows by substitution when R ≠ 0 and is already baseline knowledge. Instantaneous P = V(t)I(t) does not require time-independent values; W = VIt does require the relevant constants, otherwise integrate power. The erg-to-joule conversion is not supplied in this packet/baseline and is not presumed for a numerical cgs calculation. No numerical power task is stated on the source slide.

### PDF page 12: slides 23 and 24

Slide 23, Dependence of R on T (F16), says Ohm's law V = RI is valid in any resistor, asks whether a given voltage implies time-constant I, notes power RI² and R = f(T), then recalls increasing T → increasing R → decreasing I. It proposes a sawtooth voltage applied to a light bulb and asks what will be observed. It says filament warming changes R and hence the slope of I versus V changes over time. There is no plotted waveform, I–V trace, material law, thermal capacity, loss function, ramp amplitude or period on the native page.

The baseline explicitly distinguishes the definition R = V/I at an operating state from Ohm's proportionality at fixed conditions. It also distinguishes a warming filament's increasing R from an NTC thermistor's decreasing R. Thus valid in any resistor is defensible only as a state-dependent ratio definition for nonzero I, not as a universal constant-R ohmic law. Increase T → increase R is specific to the intended filament/ordinary-metal context, not a universal material rule. At fixed applied V, increasing positive R decreases I. During a changing sawtooth V(t), I can increase even while R increases; the rates of both changes matter.

If a sweep follows I(V) = V/R(T(V)) on a differentiable segment, calculus gives dI/dV = 1/R − [V/R²](dR/dT)(dT/dV). Consequently the actual tangent slope along a heating trace is not generally 1/R; that reciprocal describes the fixed-temperature ohmic relation. The baseline directly warns about operating V/I versus tangent slope for nonlinear components. The qualitative statement that the trace changes during warming is supported, but the exact curve or hysteresis requires further thermal/time data. A changing resistance with time at constant voltage and a nonlinear I–V sweep are related but different statements. No precise trace is reconstructed from missing data.

Slide 24, Summary and outlook, names Kirchhoff's laws, series/parallel resistors and resistor power as today's topics. It previews RC circuits and time evolution next time, and repeats historical advice to discuss quiz marks below 50, arrange appointments, and meet a Friday add deadline. The baseline already includes RC charging/discharging relations and relevant calculus, but this source only previews them; it does not teach or assess RC behaviour here. Historical deadlines and lecturer contact invitations do not authorise present contact.

## Prerequisite warrants from the entire baseline

The table separates positive usable premises from a bridge that the source would still have to establish. Line numbers refer to the exact fully read baseline, not to a searched-only extract. References to irrelevant subject areas here certify scope review rather than granting unrelated content.

| Source operation or claim | Actual baseline warrant | Boundary for this source |
|---|---|---|
| Signed arithmetic, units, rearrangement, fractions and physical consistency | Mathematics lines 36–44, 92, 96; Physics 879–887; Chemistry 1430–1446 | 135 mV cannot be silently made a current; missing measurements stay missing. |
| Summed drops and reciprocal resistances | Mathematics 136; Physics 1089 | Summation notation is available; state which terms are magnitudes and which are signed. |
| Solving two linear loop equations | Mathematics 92; FM16 line 709, with FM14–15 lines 705–707 | Direct elimination is already warranted; matrices are optional, not an extra precondition. D > 0 in the intended positive-resistance model proves uniqueness. |
| Vector arrows and E·ds scalar product | Mathematics 442–450; FM18 line 713; Physics 895, 1269–1273 | Dot products are supplied by Further Mathematics. Variable-field line integrals, divergence and partial derivatives are explicitly not granted by FM58/FM69 lines 797, 819. A dot symbol alone is not the difficult new operation. |
| Current as rate and carrier transport | Physics 1073; Mathematics 256–308 | I = dQ/dt follows from the rate limit. Uniform J = I/A and signed-carrier qnu can be reconstructed from carrier counting if definitions/directions are specified; a general field J and continuum conservation require new definitions. |
| Charge conservation at nodes | Physics 1089 and 1073 | Already usable for circuits. Scalar dQ_node/dt = I_in − I_out can be derived; no need to assume operational knowledge of the printed ∇ equation. |
| Ohmic constitutive and geometric resistance | Physics 1081, 1085 | Fixed-state Ohm law, resistance ratio, temperature behaviour and R = ρL/A are known. The relaxation time τ and σ = nq²τ/m are not derived or physically defined in this source. |
| Emf, potential difference and work | Physics 1077, 1269–1273; FM58 line 797 | Supplied energy per charge versus field work signs support detecting the p4 inconsistency. A fully operational spatial line-integral treatment is not pre-taught. |
| Ordinary loop/series/parallel rules and multiple sources | Physics 1089 | Most of the circuit algebra is already baseline material even though this is a university lecture. No reason to classify the entire lecture as new formalism. |
| Internal resistance and loaded voltage | Physics 971, 1093, 1097 | ℰ − Ir, equivalent series r and I²r are granted. State-dependent electrochemical dynamics and a universal physical maximum are not. |
| Meter connections and component characteristics | Physics 945–949, 967–973, 1081 | Ammeter in series and voltmeter across component are known. The physical R-number mapping, valid F13 current, individual voltages and instrument precision are absent. |
| Power and heating | Physics 1037–1041, 1097, 1165; FM58/FM60 lines 797, 801 | P = VI and its resistor forms are granted. Numerical temperature-time prediction needs capacities, losses and R(T), none supplied for F16. |
| Tangent versus operating ratio | Mathematics 256–328 and product/chain rules 296–308; Physics 899, 1081 | A nonlinear trace's inverse tangent is not automatically V/I. No exact bulb trace is recoverable without thermal dynamics and drive details. |
| Electron/ion carriers, electrode polarity and charge balance | Physics 1073, 1077; Chemistry 1454, 1478–1486, 1564, 1572 | Conductors' carriers and ionic conduction are known. Battery-as-charge-creation and electrolyte electron conduction are not warranted. |
| Lead-cell redox equations | Chemistry 1638–1646; electrochemistry 2104–2124 | Given half-equations can be balanced, added, classified and connected to anode/cathode directions. The baseline does not grant a catalogue of lead-cell properties or missing standard potentials. |
| Reaction energy versus voltage | Physics 855, 863, 1077; Chemistry 1486, 2120 | Two electrons per written reaction and energy/charge give a conditional 2.2 V from the supplied 4.4 eV. The chemical energy number and its status as available electrical work are not independently established. No memorised ΔG = −nFE is assumed. |
| Reaction favourability and running current | Chemistry 1792–1832, 2046–2076, 2120–2124 | Feasibility is distinct from rate; no kinetic or full electrochemical transport model is supplied. |
| Temperature-response restrictions | Physics 1081–1085; Chemistry rate-temperature discussion 1836–1844 | Filament/metal and NTC trends differ. A temperature trend in resistance is not licensed solely by the word resistor, and chemical Arrhenius behaviour cannot replace a missing R(T) law. |
| Electrostatic KVL scope versus induction | Physics 1089 and 1293–1297 | Changing flux can induce emf; the electrostatic ∮E·ds = 0 assertion has a restricted domain. General Maxwell calculus is not baseline knowledge. |
| RMS terminology and test comparisons | Mathematics 466–474; FM38–39 lines 755–757; measurement/model interpretation throughout | RMS(raw)² = variance + mean²; RMS(raw) = 16 with mean 59 is inconsistent. Means alone do not prove different test difficulty. No student diagnostic conclusion is authorised by historical marks. |

The complete Further Mathematics Statistics option supplies distribution and moment reasoning but does not supply circuit premises. Its Mechanics option does supply dot-product work/power and several calculus-based mechanics deductions, while explicitly excluding general field line integrals. These two options were both read and are not conflated. Additional Pure, Discrete, MEI, abstract eigenmode methods and any unnamed university course were not assumed.

The rest of the full baseline was also read: mathematical proof, functions, calculus, numerical methods, trigonometry, statistics and mechanics; Further Mathematics complex arithmetic, matrices, geometry, expansions, ODEs, Statistics and Mechanics; Physics measurement, mechanics, waves, quantum phenomena, thermal physics, gravity, cosmology, capacitance, fields, induction, nuclear/particle physics and imaging; and Chemistry quantities, structure, inorganic chemistry, rates/equilibrium, acids/buffers, energetics, electrochemistry, organic methods, analysis and practical reasoning. These sections do not supply a missing field-divergence definition, lead-cell numerical reference data, bulb thermal model, a particular F13 unit correction, or source-specific demonstration observations. Reading them does not make those absences disappear.

## Source issue register

The levels here distinguish a verifiable defect from shorthand or unavailable evidence. They are technical findings held for later admission, not edits to the original source.

| ID | Source location | Classification | Finding and consequence |
|---|---|---|---|
| D133-01 | Metadata versus PDF cover/footer | Identity discrepancy | Metadata L10/lecture_number 10 versus actual Lecture 8; preserve both and the exact PDF hash. |
| D133-02 | PDF p1–p2 numbering | Observed gap | Slide 2 absent; all 12 PDF pages and all 23 present slides inspected. No claim to have read an absent slide. |
| D133-03 | p2 slide 3 | Terminology ambiguity | RMS 16 cannot be raw-score rms with mean 59. A centred rms is plausible but unstated. |
| D133-04 | p2 slide 3 | Unsupported inference | Mean 59 versus last year's 64 alone does not establish test difficulty independent of cohorts and other conditions. Administrative advice is historical. |
| D133-05 | p2 slide 4 | Recall-only formalism | Divergence, partial derivative and relaxation-time formula printed without operational definitions/derivation; no silent baseline grant. |
| D133-06 | p3 slide 5 | Misleading physical phrasing | Battery as source of charges must not mean creation of net charge. Baseline and shown chemistry conserve charge. |
| D133-07 | p3 slide 6 | Typographical wording | Lead oxide electron should be electrode. Native chemistry itself balances; extraction obscures several coefficients and charges. |
| D133-08 | p3 slide 6 | Missing numerical warrant | 4.4 eV is supplied but not derived or qualified thermodynamically; 2.2 V is only the stated conditional energy/charge inference. |
| D133-09 | p4 slide 7 | Schematic mechanism limit | Electric-field reduction and H⁺ motion account is not a complete ionic-transport or reaction-rate model. E and positive-ion arrows oppose. |
| D133-10 | p4 slide 7 | Definite sign inconsistency | ∫₋⁺E·ds has opposite sign to φ₊ − φ₋ for the electrostatic E described/drawn. |
| D133-11 | p4 slide 7 | Missing regime qualification | Loaded terminal voltage need not equal emf; internal resistance later appears and baseline already distinguishes them. |
| D133-12 | p4 slide 8 | Direction scope | Positive-to-negative conventional current describes external discharge path, not every source interior or charging situation. |
| D133-13 | p5 slides 9–10 | Scope and notation | Electrostatic field statement needs its non-induction domain; Vᵢ drop magnitude is not signed ΔVᵢ. |
| D133-14 | p7 slide 13 | Definite unit error | A current of 135 mV is invalid; intended current cannot be reconstructed uniquely. |
| D133-15 | p7 slide 13 | Missing mapping/data | No R-number/component mapping, measured voltages, valid current or device characteristics. Operating V/I does not establish universal constant resistance. |
| D133-16 | p9 slide 17 | Model qualification | Increase/decrease claims require positive passive resistance and a fixed applied-voltage comparison. |
| D133-17 | p9 slide 18 | Numerical precision tension | Ideal first current is 0.949367 mA, normally 0.95 mA at two significant figures; reported 0.94 mA has no uncertainty explanation. Do not invent a correction. |
| D133-18 | p10 slide 19 | Diagram-label inconsistency | I₁ arrow sits by R₂ in the initial figure but means current through R₁ in the solution. Shared branch uses I₁ − I₂. |
| D133-19 | p10 slide 20 | Definite algebraic error | I₂ numerator must contain −V₂R₁, not +V₂R₁. Source equations and independent node calculation agree on the correction. |
| D133-20 | p10 slide 20 box | Incomplete sign rule | Resistor potential falls along current, rises in reverse traversal; arbitrary loop direction precludes always subtracting IR. |
| D133-21 | p11 slide 21 | Model qualification | ℰ/r is the fixed-r ideal short-circuit limit, not a state-independent universal battery maximum. |
| D133-22 | p11 slide 21 homework | Unsafe unbounded source suggestion | Source asks for an uncontrolled short but supplies no current limit/procedure. Its own heating model motivates the concern. No experiment performed. |
| D133-23 | p11 slide 22 | Sign/context qualification | VI is absorbed or supplied power according to voltage/current conventions; a resistor's positive dissipation interpretation needs consistent signs. |
| D133-24 | p12 slide 23 | Definitional overreach | V = IR as an operating ratio is not a universal constant-R Ohm law; material temperature trends differ. |
| D133-25 | p12 slide 23 | Incomplete quantitative demonstration | Tangent slope is not generally 1/R along a heating trace; no thermal/drive parameters or actual graph establish a unique prediction. |

## Focused calculations and stopping point

The accompanying focused-calculations.json stores exact-fraction evaluation of the F12 network and a minimal two-loop counterexample, including conservation residuals. The accompanying calculations.py is a reproducible calculation record using only the reconstructed source data and explicitly labelled illustrative values. The two-loop corrected equations, symbolic residuals and node derivation are given above. These checks target concrete source ambiguities; no general test suite or optional numerical sweep was created.

Questions remaining at the original-source boundary are specific: what quantity/unit was intended by 135 mV; which component occupies each F13 label and what voltages were measured; whether RMS is centred; how the 0.94 mA reading was obtained and rounded; what thermodynamic/operating meaning supports 4.4 eV; and what waveform timing, temperature law and thermal losses applied in F16. The supplied evidence cannot decide these uniquely. No external answer, remembered lecture demonstration or author clarification was imported.

The source establishes ordinary circuit material already substantially present in the four-subject baseline. Its genuinely unsupported formal bridges are local field current density/continuity notation, microscopic conductivity/relaxation-time modelling, a complete field-line-integral account of battery emf, and quantitative electrochemical/thermal details. This is a source-and-prerequisite finding, not a teaching sequence or judgment about an actual student's performance.

All work stops at the sealed dossier. No future D133 admission, material teaching, trial continuation, whole-freeze declaration or release is implied by its existence. Only completion statistics, output paths and integrity hashes may be sent to the coordinating root until the later D133 whole-freeze.
