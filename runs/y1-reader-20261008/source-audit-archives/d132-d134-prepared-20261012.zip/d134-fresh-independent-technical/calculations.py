"""D134 focused independent calculations. Held; not a student trial or teaching.

Only source values and direct algebra/calculus from the admitted baseline are used.
This script performs no input retrieval, network access or parameter discovery.
All output is written beside this script in the specifically authorised directory.
"""

from pathlib import Path
import json
import math

out = Path(__file__).resolve().parent

v_e9, c_e9, r_e9 = 3.0, 1.3, 11.7
tau_e9 = r_e9 * c_e9
fraction_remaining = math.exp(-1)
fraction_charged = 1 - fraction_remaining

r1_e8, r2_e8, c_e8, v_e8 = 100.0, 400.0, 0.3e-6, 5.0
r_e8 = r1_e8 + r2_e8
r2_new = 2 * r_e8 - r1_e8

v_e13, r_e13, c_e13 = 1000.0, 2.5e6, 0.1e-6
tau_e13 = r_e13 * c_e13

record = {
    "status": "HELD_UNTIL_FUTURE_D134_WHOLE_FREEZE",
    "kind": "Focused arithmetic and explicit algebraic consistency record",
    "source_pages": [3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    "source_e9_page_7_slide_13": {
        "inputs": {"source_V": v_e9, "C_F": c_e9, "R_ohm": r_e9},
        "tau_s": tau_e9,
        "Q_final_coulomb": c_e9 * v_e9,
        "I_initial_ampere": v_e9 / r_e9,
        "V_at_exact_tau_volt": v_e9 * fraction_charged,
        "Q_at_exact_tau_coulomb": c_e9 * v_e9 * fraction_charged,
        "I_at_exact_tau_ampere": (v_e9 / r_e9) * fraction_remaining,
        "V_at_source_rounded_time_15_2_s_volt": v_e9 * (1-math.exp(-15.2/tau_e9)),
        "source_rounding": "15.2 s and 1.9 V agree with the displayed model to their stated digits."
    },
    "source_e8_pages_7_8_slides_14_15": {
        "condition": "Intended series R1+R2 model inferred from the source text and 10 mA graph label; literal diagram leaves drive wiring unresolved.",
        "inputs": {"step_V": v_e8, "C_F": c_e8, "R1_ohm": r1_e8, "R2_ohm": r2_e8},
        "R_total_ohm": r_e8,
        "tau_s": r_e8*c_e8,
        "initial_I_ampere": v_e8/r_e8,
        "initial_voltage_slope_V_per_s": v_e8/(r_e8*c_e8),
        "double_C": {
            "C_F": 2*c_e8,
            "tau_s": 2*r_e8*c_e8,
            "initial_I_ampere": v_e8/r_e8,
            "initial_voltage_slope_V_per_s": v_e8/(2*r_e8*c_e8),
            "time_to_each_fixed_normalized_level_multiplier": 2,
            "source_direction_claim": "The words twice as fast conflict with the correctly doubled time constant."
        },
        "double_total_R_at_fixed_C": {
            "R2_new_ohm": r2_new,
            "correct_equation": "R1+R2_new = 2*(R1+R2_old)",
            "tau_s": (r1_e8+r2_new)*c_e8,
            "initial_I_ampere": v_e8/(r1_e8+r2_new),
            "comparison": "Same capacitor voltage curve and tau as doubled C; half the initial current."
        }
    },
    "source_thevenin_pages_9_10_slides_17_19": {
        "domain": "V constant; R1,R2,C positive and finite; capacitor initially uncharged for the displayed source result.",
        "port_KCL": "(V-v)/R1 = v/R2 + i_load",
        "port_solution": "v = V*R2/(R1+R2) - (R1*R2/(R1+R2))*i_load",
        "VOC": "V*R2/(R1+R2)",
        "Ishort": "V/R1",
        "RT": "R1*R2/(R1+R2)",
        "tau": "C*R1*R2/(R1+R2)",
        "Q_source": "C*V*R2/(R1+R2)*(1-exp(-t/tau))",
        "derivative": "dQ/dt = (V/R1)*exp(-t/tau)",
        "printed_I_native_page_10": "(V/R1)*exp(+t/tau)",
        "difference_printed_minus_derivative": "(V/R1)*(exp(t/tau)-exp(-t/tau))",
        "consequence": "For V>0 and t>0 the printed current exceeds the derivative, grows without bound and does not have the required zero DC limit.",
        "correct_branch_currents": {
            "capacitor": "(V/R1)*exp(-t/tau)",
            "R2": "V/(R1+R2)*(1-exp(-t/tau))",
            "R1_source": "V/(R1+R2)+V*R2/(R1*(R1+R2))*exp(-t/tau)",
            "KCL_residual": "i_R1-i_R2-i_C = 0 exactly after collecting constant and exponential terms"
        },
        "Norton": {"IN": "V/R1", "RT": "R1*R2/(R1+R2)", "capacitor_equation": "C*dv/dt = IN-v/RT"}
    },
    "source_e13_page_11_slides_21_22": {
        "inputs": {"source_V": v_e13, "R_ohm": r_e13, "C_F": c_e13},
        "tau_charge_s": tau_e13,
        "reciprocal_tau_per_s": 1/tau_e13,
        "off_state_charge_time": "R*C*ln((V-V_low)/(V-V_high)) for V_low<V_high<V",
        "on_state_equilibrium": "V*r/(R+r) for the explicitly assumed fixed conducting lamp resistance r",
        "on_state_tau": "C*R*r/(R+r)",
        "on_state_discharge_time": "tau_on*ln((V_high-v_on_inf)/(V_low-v_on_inf)); requires v_on_inf<V_low<V_high",
        "actual_frequency": "Not determined by supplied source data; ignition/reset information is absent.",
        "conditional_1_Hz_scale_illustration": {
            "assumptions": "Zero reset voltage and negligible discharge duration; this is not a measured or source-provided lamp model.",
            "charging_duration_s": 1.0,
            "duration_in_tau": 1.0/tau_e13,
            "required_trigger_fraction": 1-math.exp(-1.0/tau_e13),
            "required_trigger_volt": v_e13*(1-math.exp(-1.0/tau_e13))
        },
        "trigger_domain": "Exactly V is approached only asymptotically from below; a trigger above V cannot be reached by the stated ideal charging model."
    },
    "omissions": "No simulation of an unspecified lamp, no invented pulse frequency, no broad test suite, no student trial."
}

(out / "calculations.json").write_text(json.dumps(record, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
