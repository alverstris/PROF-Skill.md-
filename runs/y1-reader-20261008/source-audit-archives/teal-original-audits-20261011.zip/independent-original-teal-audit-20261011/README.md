Independent original-source TEAL audit, D106–D125

Status: 20/20 sessions complete; 1668 assigned page occurrences; 0 unread occurrence records.

This audit is confined to the authorized original packets and preparation-manifest identities/boundaries, with bounded primary-source verification where listed. It is a physics/mathematics source audit for root post-freeze review. It is not SASIS, teaching acceptance, or PROF defect finding.

Every Dxxx.json records original file identity, assigned portions, one unit per required page occurrence, actual semantic/visual extent, exact reuse identities, source findings with locators and deductions, independent checks and unread limits. Unassigned chapters are retained but not counted as assigned reading. External animations and experiments were not performed.

The audit-index.json validates occurrence identity and record completeness. coverage-occurrences.json preserves all per-session page occurrences, including reused occurrences. These indexes do not convert extraction or hash verification into reading.

There are 226 occurrence records containing exact prior-original reuse; 1 of these also contain newly read page portions. Finding counts include repeated source findings and model/notation qualifications; they must not be presented as unique source-error totals.

| ID | Source session | Assigned occurrences | Reuse records | Unread | Finding records |
| --- | --- | ---: | ---: | ---: | ---: |
| D106 | mit-8-02t-spring2005-S02 | 99 | 0 | 0 | 12 |
| D107 | mit-8-02t-spring2005-S04 | 65 | 0 | 0 | 10 |
| D108 | mit-8-02t-spring2005-S05 | 108 | 0 | 0 | 21 |
| D109 | mit-8-02t-spring2005-S07 | 104 | 10 | 0 | 25 |
| D110 | mit-8-02t-spring2005-S08 | 108 | 56 | 0 | 26 |
| D111 | mit-8-02t-spring2005-S10 | 77 | 0 | 0 | 17 |
| D112 | mit-8-02t-spring2005-S12 | 57 | 8 | 0 | 12 |
| D113 | mit-8-02t-spring2005-S14 | 67 | 0 | 0 | 15 |
| D114 | mit-8-02t-spring2005-S15 | 61 | 0 | 0 | 6 |
| D115 | mit-8-02t-spring2005-S17 | 59 | 18 | 0 | 15 |
| D116 | mit-8-02t-spring2005-S18 | 124 | 0 | 0 | 9 |
| D117 | mit-8-02t-spring2005-S20 | 82 | 0 | 0 | 3 |
| D118 | mit-8-02t-spring2005-S21 | 81 | 32 | 0 | 4 |
| D119 | mit-8-02t-spring2005-S24 | 86 | 0 | 0 | 3 |
| D120 | mit-8-02t-spring2005-S25 | 37 | 0 | 0 | 1 |
| D121 | mit-8-02t-spring2005-S26 | 93 | 0 | 0 | 11 |
| D122 | mit-8-02t-spring2005-S28 | 96 | 0 | 0 | 3 |
| D123 | mit-8-02t-spring2005-S30 | 84 | 51 | 0 | 4 |
| D124 | mit-8-02t-spring2005-S32 | 95 | 51 | 0 | 3 |
| D125 | mit-8-02t-spring2005-S33 | 85 | 0 | 0 | 17 |

Ownership: D106–D115 were audited by independent_original_teal_audit; D116–D125 by the fresh source-only child original_teal_d116_d125. The two assigned ranges did not exchange findings for authoring. Full sources and their original derivatives were not edited.

No GitHub writes or queue mutations were made. Findings are held for root review after generation freeze.
