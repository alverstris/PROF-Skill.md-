#!/usr/bin/env python3
"""Restricted D017/D018/D007/D008/D013-derived preservation comparator v11. See README.md. Never a scientific/SASIS evaluator."""
import sys
try:
 import re,json,hashlib,html,xml.etree.ElementTree as ET
 from pathlib import Path
 from html.parser import HTMLParser
 from collections import Counter
 import difflib
 import argparse,sys
 from urllib.parse import urljoin
 cli=argparse.ArgumentParser(description="Restricted source-to-live-DOM preservation QA only; never SASIS or scientific validation.")
 cli.add_argument('--source',required=True,type=Path)
 cli.add_argument('--capture',required=True,type=Path)
 cli.add_argument('--source-sha256',required=True)
 cli.add_argument('--output-dir',required=True,type=Path)
 args=cli.parse_args()
 if sys.flags.optimize:
  raise ValueError("Optimized Python disables parser assertions; run without -O")
 SRC=args.source.resolve();DOM=args.capture.resolve();OUT=args.output_dir.resolve()
 EXPECTED=args.source_sha256.lower()
 if not re.fullmatch(r'[0-9a-f]{64}',EXPECTED):
  raise ValueError("--source-sha256 must contain exactly 64 hexadecimal characters")
 if hashlib.sha256(SRC.read_bytes()).hexdigest()!=EXPECTED:
  raise ValueError("Frozen source SHA-256 mismatch")
 if (OUT/'math-preservation.json').exists():
  raise ValueError("Refusing to overwrite an existing math-preservation.json; select a new output directory")
 if (OUT/'math-preservation.json') in (SRC,DOM):
  raise ValueError("Output would overwrite an input")
 source=SRC.read_text();dom=json.loads(DOM.read_text())
 if not re.search(r'/blob/[0-9a-f]{40}/',dom['url']):
  raise ValueError("Capture URL must identify an immutable full Git commit")
 PAT=re.compile(r'```math\s*\n(.*?)\n```|\$`(.*?)`\$',re.S)
 exprs=[{'ordinal':i+1,'type':'display' if m.group(1) is not None else 'inline','source_line':source.count('\n',0,m.start())+1,'source_latex':m.group(1) if m.group(1) is not None else m.group(2)} for i,m in enumerate(PAT.finditer(source))]
 residual=PAT.sub('',source)
 if '$' in residual or '`' in residual or re.search(r'\\(?:\[|\]|\(|\))',residual):
  raise ValueError("Unsupported or malformed source math/code delimiter remains outside recognized expressions")
 if not exprs:
  raise ValueError("No supported mathematical expressions found; manual inspection required")
 SLOT_PAT=re.compile(r'<math-renderer\b.*?</math-renderer>|<pre\b[^>]*\blang="math"[^>]*>.*?</pre>',re.S)
 slots=[m.group() for m in SLOT_PAT.finditer(dom['articleHTML'])]
 if len(exprs)!=len(slots):
  raise ValueError(f"Source-expression/article-slot count differs: source={len(exprs)} slots={len(slots)}; manual alignment required")
 embedded=re.findall(r'<math(?:\s[^>]*)?>.*?</math>',dom['articleHTML'],re.S)
 if embedded!=[m['mathML'] for m in dom['math']]:
  raise ValueError("Article MathML does not exactly equal the capture math array")
 # v10: the witnessed D015 capture omits per-node display metadata. Recover it
 # only from actual article renderer attributes, never from the source expression.
 capture_schema_adaptation=None
 if all(set(m)=={'ordinal','mathML'} for m in dom['math']):
  if 'observedAt' in dom or not isinstance(dom.get('at'),str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z',dom['at']):
   raise ValueError('Unsupported reduced capture timestamp schema')
  class RendererStart(HTMLParser):
   def __init__(self):super().__init__();self.attrs=None
   def handle_starttag(self,t,attrs):
    if t!='math-renderer' or self.attrs is not None or len(attrs)!=len(dict(attrs)):raise ValueError('Unsupported actual renderer start tag')
    self.attrs=dict(attrs)
  native_slots=[slot for slot in slots if re.search(r'<math(?:\s[^>]*)?>',slot)]
  if len(native_slots)!=len(dom['math']):raise ValueError('Reduced capture native slot count mismatch')
  recovered_types=[]
  for m,slot in zip(dom['math'],native_slots):
   opening=re.match(r'<math-renderer\b[^>]*>',slot)
   if opening is None:raise ValueError('Reduced capture native slot lacks renderer')
   hp=RendererStart();hp.feed(opening.group());a=hp.attrs
   if a is None or set(a)!={'class','style','data-run-id','data-catalyst'} or a['data-catalyst']!='' or not re.fullmatch(r'[0-9a-f]+',a['data-run-id']):
    raise ValueError('Unsupported reduced capture renderer attributes')
   if a['class'] not in ['js-inline-math','js-display-math'] or a['style']!=('display: inline-block' if a['class']=='js-inline-math' else 'display: block'):
    raise ValueError('Unsupported or inconsistent actual renderer class/style')
   m['display']=a['class'];recovered_types.append(a['class'])
  dom['observedAt']=dom['at']
  capture_schema_adaptation={'schema':'D015 ordinal/mathML-only records and at timestamp','type_source':'Exact actual article math-renderer class/style attributes; independently compared to MathML display and frozen source type','original_math_record_keys':['mathML','ordinal'],'original_timestamp_key':'at','recovered_types':recovered_types}
 # v11: two additional actual captures label MathML display as inline/block.
 # Validate both that metadata and the independent article wrapper before mapping.
 if all(set(m)=={'ordinal','mathML','display'} and m['display'] in ['inline','block'] for m in dom['math']):
  if not isinstance(dom.get('observedAt'),str):raise ValueError('Unsupported inline/block capture timestamp schema')
  native_slots=[slot for slot in slots if re.search(r'<math(?:\s[^>]*)?>',slot)]
  if len(native_slots)!=len(dom['math']):raise ValueError('Inline/block capture native slot count mismatch')
  class RendererDisplayStart(HTMLParser):
   def __init__(self):super().__init__();self.attrs=None
   def handle_starttag(self,t,attrs):
    if t!='math-renderer' or self.attrs is not None or len(attrs)!=len(dict(attrs)):raise ValueError('Unsupported actual renderer start tag')
    self.attrs=dict(attrs)
  original_labels=[]
  for m,slot in zip(dom['math'],native_slots):
   ml=ET.fromstring(m['mathML'].replace('&nbsp;','&#160;'))
   if ml.attrib.get('display','inline')!=m['display']:raise ValueError('Capture display metadata differs from actual MathML')
   opening=re.match(r'<math-renderer\b[^>]*>',slot)
   if opening is None:raise ValueError('Inline/block capture native slot lacks renderer')
   hp=RendererDisplayStart();hp.feed(opening.group());a=hp.attrs
   if a is None or set(a)!={'class','style','data-run-id','data-catalyst'} or a['data-catalyst']!='' or not re.fullmatch(r'[0-9a-f]+',a['data-run-id']):raise ValueError('Unsupported inline/block capture renderer attributes')
   expected_class='js-display-math' if m['display']=='block' else 'js-inline-math'
   expected_style='display: block' if m['display']=='block' else 'display: inline-block'
   if a['class']!=expected_class or a['style']!=expected_style:raise ValueError('Capture display metadata differs from actual renderer class/style')
   original_labels.append(m['display']);m['display']=expected_class
  capture_schema_adaptation={'schema':'D015 inline/block MathML display metadata','original_display_labels':original_labels,'type_source':'Captured labels validated against actual MathML display and exact actual renderer class/style before mapping to legacy js-* labels; no source inference'}
 # A separate restricted TeX parser: no renderer is used to compute expectations.
 MAP={'int':'∫','sum':'∑','sin':'sin','cos':'cos','lim':'lim','to':'→','Delta':'Δ','pi':'π','lt':'<','le':'≤','ge':'≥','approx':'≈','gt':'>','ln':'ln','varepsilon':'ε','infty':'∞','theta':'θ','cdot':'⋅','sinh':'sinh','cosh':'cosh','tan':'tan','sec':'sec','arcsin':'arcsin','arctan':'arctan','ne':'≠','pm':'±','longrightarrow':'⟶','ll':'≪','epsilon':'ϵ','times':'×','cdots':'⋯','ell':'ℓ','Longrightarrow':'⟹','ldots':'…'}
 CHAR={'-':'−','*':'∗'}
 def sym(s): return ['symbol',CHAR.get(s,s)]
 class Tex:
  def __init__(self,s): self.s=s;self.i=0
  def skip(self):
   while self.i<len(self.s) and self.s[self.i].isspace(): self.i+=1
  def seq(self,until=None):
   out=[]
   while True:
    self.skip()
    if self.i==len(self.s):
     assert until is None, ('unclosed',until,self.s)
     return out
    if until and self.s.startswith(until,self.i): self.i+=len(until);return out
    atom=self.atom()
    while True:
     self.skip()
     if self.i>=len(self.s) or self.s[self.i] not in "_^'":break
     op=self.s[self.i];self.i+=1
     arg=[sym('′')] if op=="'" else self.atom(single=True)
     if len(atom)==1 and atom[0][0]=='scripts':
      node=atom[0]
     else: node=['scripts',atom,[],[]]
     at=2 if op=='_' else 3
     if op=="'" and node[at]==[sym('′')]:node[at]+=arg
     else:
      assert not node[at],('duplicate or unsupported script',self.s)
      node[at]=arg
     atom=[node]
    out.extend(atom)
  def atom(self,single=False):
   self.skip()
   if self.i>=len(self.s):raise ValueError('Missing TeX atom')
   c=self.s[self.i];self.i+=1
   if c=='{':return self.seq('}')
   if c=='\\':
    m=re.match(r'[a-zA-Z]+|.',self.s[self.i:])
    if m is None:raise ValueError('Incomplete TeX command')
    cmd=m.group();self.i+=len(cmd)
    if cmd in [',','qquad','quad',' ']:return []
    if cmd=='sqrt':return [['square_root',self.atom(single=True)]]
    if cmd in MAP:return [sym(MAP[cmd])]
    if cmd=='binom':return [sym('('),['binomial_stack',self.atom(single=True),self.atom(single=True)],sym(')')]
    if cmd=='tfrac':return [['textstyle_fraction',self.atom(single=True),self.atom(single=True)]]
    if cmd=='frac':return [['fraction',self.atom(single=True),self.atom(single=True)]]
    if cmd=='mathrm':
     self.skip()
     if self.i>=len(self.s) or self.s[self.i]!='{':raise ValueError('Only braced alphabetic upright runs are supported')
     end=self.s.index('}',self.i+1);raw=self.s[self.i+1:end];self.i=end+1
     if not re.fullmatch(r'[A-Za-z]+(?:/[A-Za-z]+)?',raw):raise ValueError(('Unsupported upright-group syntax',raw))
     return [sym('/') if part=='/' else ['upright_run',part] for part in re.split('(/)',raw)]
    if cmd=='hbox':
     self.skip()
     if self.i>=len(self.s) or self.s[self.i]!='{':raise ValueError('Only braced plain-text hbox forms are supported')
     end=self.s.index('}',self.i+1);raw=self.s[self.i+1:end];self.i=end+1
     if not re.fullmatch(r'[A-Za-z ]+',raw) or not raw.strip():raise ValueError(('Unsupported hbox content',raw))
     return [['hbox',raw]]
    if cmd in ['bigl','bigr']:
     self.skip();expected='(' if cmd=='bigl' else ')'
     if self.i>=len(self.s) or self.s[self.i]!=expected:raise ValueError(('Only observed bigl/bigr parentheses supported',cmd))
     self.i+=1
     return [['sized_delimiter',expected,'1.2em','OPEN' if cmd=='bigl' else 'CLOSE']]
    if cmd=='text':
     self.skip();assert self.s[self.i]=='{';end=self.s.index('}',self.i+1);t=self.s[self.i+1:end];self.i=end+1
     if any(c in t for c in '{}\\'):raise ValueError('Unsupported nested or escaped TeX text')
     return [['text',t]]
    if cmd=='left':
     self.skip();left=self.s[self.i];self.i+=1
     mid=self.seq('\\right');self.skip();right=self.s[self.i];self.i+=1
     if left not in '([|.' or right not in ')]|.':raise ValueError('Unsupported TeX delimiter')
     return ([] if left=='.' else [sym(left)])+mid+([] if right=='.' else [sym(right)])
    raise AssertionError(('unsupported command',cmd,self.s))
   if c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-=*/()[]|,.;<>!':
    raise ValueError(('Unsupported literal TeX token',c,self.s))
   if c.isdigit() and not single:
    start=self.i-1
    number=re.match(r'[0-9]+(?:\.[0-9]+)?',self.s[start:]).group()
    self.i=start+len(number)
    return [sym(v) for v in number]
   return [sym(c)]
 def tex_parse(s):
  if s.startswith('\\begin{aligned}'):
   assert s.endswith('\\end{aligned}')
   body=s[len('\\begin{aligned}'):-len('\\end{aligned}')]
   rows=body.split('\\\\')
   if any(len(row.split('&'))!=2 for row in rows):raise ValueError('Only two-column aligned rows are supported')
   return [['table',[[Tex(cell).seq() for cell in row.split('&')] for row in rows]]]
  return Tex(s).seq()
 def tag(e):return e.tag.split('}')[-1]
 MATHML_ATTRIBUTES={'mo': {'data-mjx-alternate': ['1'], 'stretchy': ['false', 'true'], 'data-mjx-texclass': ['CLOSE', 'NONE', 'OP', 'OPEN', 'ORD'], 'movablelimits': ['true'], 'accent': ['false'], 'fence': ['true'], 'symmetric': ['true']}, 'mspace': {'width': ['0.167em', '1em', '2em']}, 'mrow': {'data-mjx-texclass': ['INNER', 'ORD', 'OPEN', 'CLOSE']}, 'math': {'display': ['block']}, 'mi': {'mathvariant': ['normal']}, 'mtable': {'displaystyle': ['true'], 'columnalign': ['right left'], 'columnspacing': ['0em'], 'rowspacing': ['3pt']}, 'mtd': {'style': ['text-align: left;', 'text-align: right;']}}
 MATHML_ATTRIBUTES['mo']['minsize']=['2.047em','1.2em']
 MATHML_ATTRIBUTES['mo']['maxsize']=['2.047em','1.2em']
 MATHML_ATTRIBUTES['mfrac']={'linethickness':['0']}
 MATHML_ATTRIBUTES['mi']['data-mjx-auto-op']=['false']
 MATHML_ATTRIBUTES['mstyle']={'displaystyle':['false']}
 def validate_mathml(e):
  for node in e.iter():
   t=tag(node)
   for name,value in node.attrib.items():
    if value not in MATHML_ATTRIBUTES.get(t,{}).get(name,[]):
     raise ValueError(('Unsupported MathML attribute',t,name,value))
   arities={'mfrac':2,'msub':2,'msup':2,'msubsup':3,'munder':2,'munderover':3}
   if t in arities and len(node)!=arities[t]:raise ValueError(('Invalid MathML child count',t))
   if t in ['mi','mo','mn','mtext','mspace'] and len(node):raise ValueError(('Unexpected token children',t))
   if t=='mtable' and any(tag(c)!='mtr' for c in node):raise ValueError('Unsupported MathML table child')
   if t=='mtr' and (len(node)!=2 or any(tag(c)!='mtd' for c in node)):
    raise ValueError('Only two-cell MathML aligned rows are supported')
   if t=='mn' and not re.fullmatch(r'[0-9]+(?:\.[0-9]+)?\.?',node.text or ''):raise ValueError('Only integer/decimal MathML numeral tokens with optional terminal period are supported')
 def mparse(e):
  t=tag(e);cs=list(e);value=e.text or ''
  if t=='mstyle' and e.attrib=={'displaystyle':'false'} and len(cs)==1 and tag(cs[0])=='mfrac':
   if cs[0].attrib or len(cs[0])!=2:raise ValueError('Unsupported textstyle-fraction MathML structure')
   return [['textstyle_fraction',mparse(cs[0][0]),mparse(cs[0][1])]]
  if t=='mstyle' and e.attrib.get('displaystyle')=='false':
   if e.attrib!={'displaystyle':'false'} or len(cs)!=1 or tag(cs[0])!='mtext' or cs[0].attrib:raise ValueError('Unsupported non-hbox text-style MathML structure')
   raw=(cs[0].text or '').replace('\u00a0',' ')
   if not re.fullmatch(r'[A-Za-z ]+',raw) or not raw.strip():raise ValueError(('Unsupported actual hbox content',raw))
   return [['hbox',raw]]
  if t=='mrow' and len(cs)==1 and tag(cs[0])=='mo' and ('1.2em' in cs[0].attrib.values()):
   classification=e.attrib.get('data-mjx-texclass');value=cs[0].text
   if e.attrib!={'data-mjx-texclass':classification} or classification not in ['OPEN','CLOSE'] or value!=('(' if classification=='OPEN' else ')') or cs[0].attrib!={'minsize':'1.2em','maxsize':'1.2em'}:raise ValueError('Unsupported sized-delimiter MathML structure')
   return [['sized_delimiter',value,'1.2em',classification]]
  if t=='mo' and '1.2em' in e.attrib.values():raise ValueError('Sized delimiter lacks the observed OPEN/CLOSE wrapper')
  if t=='mi' and e.attrib.get('data-mjx-auto-op')=='false':
   if not re.fullmatch(r'[A-Za-z]+',value):raise ValueError(('Unsupported upright MathML token',value))
   if len(value)==1 and e.attrib.get('mathvariant')!='normal':raise ValueError('Single-character upright token lacks explicit normal variant')
   return [['upright_run',value]]
  if t in ['mi','mo','mn']:
   if not value or value=='\u2061':return []
   if t=='mn': return [sym(c) for c in value]
   if value=='″':return [sym('′'),sym('′')]
   return [sym(value)]
  if t=='mtext':return [] if not value.strip() else [['text',value.replace('\u00a0',' ')]]
  if t in ['math','mrow','mstyle','mtd']:return [a for c in cs for a in mparse(c)]
  if t=='mspace':return []
  if t=='msqrt':return [['square_root',[a for c in cs for a in mparse(c)]]]
  if t=='mfrac':return [[('binomial_stack' if e.attrib.get('linethickness')=='0' else 'fraction'),mparse(cs[0]),mparse(cs[1])]]
  if t in ['msub','msup','msubsup','munder','munderover']:
   base=mparse(cs[0]);sub=[];sup=[]
   if t in ['msub','munder']:sub=mparse(cs[1])
   elif t=='msup':sup=mparse(cs[1])
   else:sub=mparse(cs[1]);sup=mparse(cs[2])
   return [['scripts',base,sub,sup]]
  if t=='mtable':return [['table',[[mparse(c) for c in row] for row in cs]]]
  raise AssertionError(('unexpected mathml',t))
 def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
 def count_nodes(nodes):
  c=Counter()
  def walk(n):
   if not isinstance(n,list) or not n:return
   if isinstance(n[0],str):
    c[n[0]]+=1
    if n[0]=='scripts':
     if n[2]:c['subscript_or_lower_bound']+=1
     if n[3]:c['superscript_or_upper_bound']+=1
     if n[1]==[sym('∫')]:c['integral_with_bounds']+=1
     if n[1]==[sym('∑')]:c['sum_with_bounds']+=1
    if n[0]=='symbol' and n[1]=='∫':c['integral_symbol']+=1
    for a in n[1:]:walk(a)
   else:
    for a in n:walk(a)
  walk(nodes);return dict(c)
 records=[]
 native_index=0
 for ex,slot in zip(exprs,slots):
  native=re.search(r'<math(?:\s[^>]*)?>.*?</math>',slot,re.S)
  slot_type='display' if ('js-display-math' in slot or slot.startswith('<pre')) else 'inline'
  if native is None:
   status='render_error' if 'flash-error' in slot else 'raw_math_code_in_capture'
   raw=re.search(r'<pre[^>]*>(.*?)</pre>',slot,re.S).group(1)
   raw=html.unescape(re.sub(r'<[^>]*>','',raw)).strip()
   if status=='render_error':
    delim='$$' if slot_type=='display' else '$'
    if not(raw.startswith(delim) and raw.endswith(delim)):raise ValueError('Unexpected math error fallback format')
    raw=raw[len(delim):-len(delim)]
   if raw.strip()!=ex['source_latex'].strip():raise ValueError(('Raw math/source slot mismatch',ex['ordinal']))
   records.append({**ex,'captured_ordinal':None,'actual_type':slot_type,'mathml_type':None,'slot_type_match':slot_type==ex['type'],'types_match':False,'structural_match':False,'status':status,'source_canonical':None,'actual_canonical':None,'source_canonical_sha256':None,'actual_canonical_sha256':None,'structure_counts':{},'actual_mathml':None,'actual_slot_html':slot,'raw_source_text_match':True,'actual_raw_math':raw,'failure_reason':'No actual MathML in this captured slot. Source text surviving in an error/raw-code fallback is not rendered-math preservation.'})
   continue
  actual=dom['math'][native_index];native_index+=1
  if actual['ordinal']!=native_index or actual['mathML']!=native.group():raise ValueError('Native MathML array/slot order mismatch')
  expected=tex_parse(ex['source_latex']);xml=ET.fromstring(actual['mathML'].replace('&nbsp;','&#160;'));validate_mathml(xml);observed=mparse(xml)
  if actual['display'] not in ['js-inline-math','js-display-math']:raise ValueError('Unsupported MathML display type')
  typ='display' if actual['display']=='js-display-math' else 'inline'
  mathmltyp='display' if xml.attrib.get('display')=='block' else 'inline'
  records.append({**ex,'captured_ordinal':actual['ordinal'],'actual_type':typ,'mathml_type':mathmltyp,'types_match':ex['type']==typ==mathmltyp,'structural_match':expected==observed,'status':'preserved' if expected==observed else 'structural_mismatch','source_canonical':expected,'actual_canonical':observed,'source_canonical_sha256':digest(expected),'actual_canonical_sha256':digest(observed),'structure_counts':count_nodes(expected),'actual_mathml':actual['mathML'],'actual_slot_html':slot})
 if native_index!=len(dom['math']):raise ValueError('Not all captured native MathML was consumed')
 # Complete text comparison with stable placeholders protecting inline positions.
 # Images' alt text is separate from visible body text; anchors have no visible text.
 idx=iter(range(1,len(exprs)+1))
 source_prose=PAT.sub(lambda m:f'⟦M{next(idx):03d}⟧',source)
 source_prose=re.sub(r'</?(?:details|summary)>',' ',source_prose)
 # v6: only explicitly supported image markup is removed from whole-prose comparison.
 IMAGE_PAT=re.compile(r'!\[([^\]]*)\]\(([^)]*)\)|<img\b[^>]*>',re.S)
 class SourceImage(HTMLParser):
  def __init__(self):super().__init__(convert_charrefs=True);self.images=[]
  def handle_starttag(self,t,attrs):
   if t!='img' or len(attrs)!=len(dict(attrs)) or set(dict(attrs))!={'src','width','height','alt'}:raise ValueError('Unsupported source HTML image attributes')
   a=dict(attrs)
   if not re.fullmatch(r'figures/[A-Za-z0-9_-]+\.png',a['src']) or (a['width'],a['height']) not in {('1120','672'),('960','564'),('1120','560'),('900','500'),('900','560'),('900','600')}:raise ValueError('Unsupported source HTML image path/dimensions; only observed 1120x672, 960x564, 1120x560, 900x500, 900x560 or 900x600 figure PNG forms supported')
   self.images.append(a)
  def handle_startendtag(self,t,attrs):
   self.handle_starttag(t,attrs)
  def handle_data(self,v):
   if v.strip():raise ValueError('Unexpected text in source HTML image')
  def handle_endtag(self,t):raise ValueError('Unsupported source HTML image closing tag')
 source_image_specs=[]
 for im in IMAGE_PAT.finditer(source_prose):
  if im.group(1) is not None:source_image_specs.append({'source_form':'markdown','alt':im.group(1),'src':im.group(2)})
  else:
   ip=SourceImage();ip.feed(im.group())
   if len(ip.images)!=1:raise ValueError('Unsupported source HTML image form')
   source_image_specs.append({'source_form':'html',**ip.images[0]})
 source_alts=[(im['alt'],im['src']) for im in source_image_specs]
 source_prose=IMAGE_PAT.sub(' ',source_prose)
 source_links=re.findall(r'\[([^\]]*)\]\(([^)]*)\)',source_prose)
 source_prose=re.sub(r'\[([^\]]*)\]\(([^)]*)\)',lambda m:m.group(1),source_prose)
 source_prose=re.sub(r'<a\s+(?:name|id)="[^"]*">\s*</a>',' ',source_prose)
 class DOMProse(HTMLParser):
  def __init__(self):super().__init__(convert_charrefs=True);self.parts=[];self.mathdepth=0;self.i=0;self.link=None;self.links=[];self.alts=[];self.ol=[];self.ul=0;self.ul_items=0;self.pieces=[];self.current=[]
  def handle_starttag(self,t,attrs):
   a=dict(attrs)
   if t=='math-renderer':self.mathdepth+=1;self.i+=1;self.parts.append(f'⟦M{self.i:03d}⟧');return
   if self.mathdepth:return
   if t in ['p','ol','li','div','article','details','summary']:self.parts.append(' ')
   if t=='ul':
    if self.ul or self.ol or a!={'dir':'auto'}:raise ValueError('Only observed flat unordered-list structure supported')
    self.ul=1
   if t=='ol':
    if self.ul:raise ValueError('Nested ordered list inside unordered list unsupported')
    self.ol.append(int(a.get('start',1)))
   if t=='li' and self.ol:self.parts.append(str(self.ol[-1])+'. ');self.ol[-1]+=1
   if t=='li' and self.ul:self.parts.append('- ');self.ul_items+=1
   if t=='a' and 'href'in a:self.link={'label':'','href':a['href']}
   if t=='img':
    if len(attrs)!=len(a):raise ValueError('Duplicate actual image attributes')
    self.alts.append(a)
  def handle_endtag(self,t):
   if t=='math-renderer':self.mathdepth-=1;return
   if self.mathdepth:return
   if t in ['p','ol','li','div','article','details','summary']:self.parts.append(' ')
   if t=='ol':self.ol.pop()
   if t=='ul':
    if self.ul!=1:raise ValueError('Unbalanced unordered list')
    self.ul=0
   if t=='a' and self.link is not None:self.links.append(self.link);self.link=None
  def handle_data(self,v):
   if self.mathdepth:return
   self.parts.append(v)
   if self.link is not None:self.link['label']+=v
 slot_ids=iter(range(1,len(slots)+1))
 marked_article=SLOT_PAT.sub(lambda m:f'⟦M{next(slot_ids):03d}⟧',dom['articleHTML'])
 parser=DOMProse();parser.feed(marked_article);parser.i=len(slots)
 def norm(s):return ' '.join(s.split())
 sp=norm(source_prose);ap=norm(''.join(parser.parts))
 image_wrapper_links=[a for a in parser.links if not norm(a['label'])]
 text_links=[a for a in parser.links if norm(a['label'])]
 links=[{'ordinal':i+1,'source_label':s[0],'source_href':s[1],'actual_label':a['label'],'actual_href':a['href'],'label_match':norm(s[0])==norm(a['label']),'href_raw_match':s[1]==a['href'],'source_resolved_href':urljoin(dom['url'],s[1]),'actual_resolved_href':urljoin(dom['url'],a['href']),'href_match':urljoin(dom['url'],s[1])==urljoin(dom['url'],a['href'])} for i,(s,a) in enumerate(zip(source_links,text_links))]
 images=[]
 for i,(spec,a) in enumerate(zip(source_image_specs,parser.alts)):
  source_url=urljoin(dom['url'],spec['src'])
  if '/blob/' not in source_url:raise ValueError('Unsupported non-repository image URL')
  expected_raw_url=source_url.replace('/blob/','/raw/',1)
  actual_url=urljoin(dom['url'],a.get('src',''))
  wrapper=image_wrapper_links[i] if i<len(image_wrapper_links) else None
  wrapper_url=urljoin(dom['url'],wrapper['href']) if wrapper else None
  explicit_attributes={}
  if spec['source_form']=='html':
   if set(a)!={'src','width','height','alt','style'}:raise ValueError(('Unsupported actual HTML image attributes',sorted(a)))
   expected_style=f"max-width: 100%; height: auto; max-height: {spec['height']}px;"
   explicit_attributes={'source_width':spec['width'],'actual_width':a['width'],'width_match':spec['width']==a['width'],'source_height':spec['height'],'actual_height':a['height'],'height_match':spec['height']==a['height'],'expected_github_added_style':expected_style,'actual_github_added_style':a['style'],'github_added_style_match':expected_style==a['style']}
   if a['style']!=expected_style:raise ValueError(('Unsupported actual HTML image added style',a['style']))
  images.append({'ordinal':i+1,'source_form':spec['source_form'],'source_alt':spec['alt'],'actual_alt':a.get('alt',''),'alt_match':spec['alt']==a.get('alt',''),'source_image_path':spec['src'],'source_resolved_blob_url':source_url,'expected_raw_image_url':expected_raw_url,'actual_image_url':actual_url,'image_src_match':expected_raw_url==actual_url,'actual_wrapper_url':wrapper_url,'wrapper_href_match':source_url==wrapper_url,'explicit_attributes':explicit_attributes,'actual_attributes':a,'declared_attributes_preserved':all(v for k,v in explicit_attributes.items() if k.endswith('_match'))})
 report={'scope':'Frozen source-to-live-GitHub destination preservation only; no scientific or SASIS verdict.','source_path':str(SRC),'source_sha256':EXPECTED,'capture_path':str(DOM),'capture_sha256':hashlib.sha256(DOM.read_bytes()).hexdigest(),'live_url':dom['url'],'observed_at':dom['observedAt'],'method':'Independent restricted-TeX parser compared to actual MathML tree, one expression at a time in document order. Canonical sequences preserve all symbols and visible delimiters, fractions, script attachment and sub/sup operands, integral/sum bounds and aligned rows/cells. Normalize TeX symbol spellings, MathML wrappers, spacing, U+2061 function-application marker and empty layout cells only. Contiguous source numerals retain script attachment to the whole numeral; numeral content is stored as digit tokens on both sides. Unbraced fraction/script arguments consume one TeX atom. Prose replaces each math expression with the same ordinal marker and compares the entire ordered body after only markup and whitespace normalization; list markers recovered from ol starts; image alt text and link labels compared independently.','counts':{'source_expressions':len(exprs),'captured_expressions':len(dom['math']),'article_expressions':parser.i,'source_types':dict(Counter(e['type'] for e in exprs)),'actual_types':dict(Counter('display' if a['display']=='js-display-math' else 'inline' for a in dom['math'])),'article_slot_types':dict(Counter(r['actual_type'] for r in records)),'record_statuses':dict(Counter(r['status'] for r in records)),'matched_structures':sum(r['structural_match'] for r in records),'matched_types':sum(r['types_match'] for r in records),'source_links':len(source_links),'actual_text_links':len(text_links),'actual_image_wrapper_links':len(image_wrapper_links),'source_images':len(source_alts),'actual_images':len(parser.alts)},'math_records':records,'prose':{'match':sp==ap,'normalization':'Whitespace collapsed; Markdown/HTML markup removed; ordered-list markers reconstructed from HTML starts; math replaced by positional ordinal markers; image alt text checked separately. No case, punctuation, wording, order or typographic quote normalization.','source_normalized':sp,'actual_normalized':ap,'source_sha256':hashlib.sha256(sp.encode()).hexdigest(),'actual_sha256':hashlib.sha256(ap.encode()).hexdigest(),'diff':list(difflib.unified_diff(sp.split(),ap.split(),fromfile='source',tofile='actual',lineterm='')) if sp!=ap else []},'links':links,'image_wrapper_links':image_wrapper_links,'images':images,'limitations':'Uses root-provided actual-live DOM capture, not an independently repeated navigation. Does not establish visual geometry, clipping, link navigation or scientific correctness. Source and capture are immutable review inputs; no frozen-file modifications or GitHub writes.'}
 source_anchor_ids=re.findall(r'<a\s+(?:id|name)="([^"]+)">\s*</a>',source)
 actual_anchor_ids=re.findall(r'<a\s+(?:id|name)="([^"]+)">\s*</a>',dom['articleHTML'])
 expected_anchor_ids=['user-content-'+anchor for anchor in source_anchor_ids]
 anchor_match=expected_anchor_ids==actual_anchor_ids
 source_anchor_forms=[{'attribute':a,'value':v} for a,v in re.findall(r'<a\s+(id|name)="([^"]+)">\s*</a>',source)]
 actual_anchor_forms=[{'attribute':a,'value':v} for a,v in re.findall(r'<a\s+(id|name)="([^"]+)">\s*</a>',dom['articleHTML'])]
 expected_anchor_forms=[{'attribute':a['attribute'],'value':'user-content-'+a['value']} for a in source_anchor_forms]
 anchor_match=anchor_match and expected_anchor_forms==actual_anchor_forms
 report['anchors']={'source_ids':source_anchor_ids,'expected_github_ids':expected_anchor_ids,'actual_ids':actual_anchor_ids,'source_forms':source_anchor_forms,'expected_actual_forms':expected_anchor_forms,'actual_forms':actual_anchor_forms,'attribute_family_match':expected_anchor_forms==actual_anchor_forms,'match':anchor_match}
 report['method']+=' v3 adds only D007-demonstrated sinh/cosh/tan/sec/arcsin/arctan function tokens, ne/pm symbols and binomial notation. The binomial retains visible parentheses and a separate zero-line stack node, never an ordinary fraction. Named/id HTML anchors are markup; GitHub user-content anchor prefixes are checked explicitly. Source-relative and captured root-relative hrefs are resolved against the same immutable article URL before exact URL comparison; no navigation behavior is inferred.'
 report['method']+=' v4 adds only D008-demonstrated longrightarrow/ll/epsilon/times symbol mappings, braced alphabetic upright runs (and slash-separated units) from mathrm, and nonbreaking-space-to-space equivalence inside nonempty mtext. Upright runs are distinct from ordinary variables/function tokens; single-letter actual upright tokens require the explicit normal variant. Text words, case and boundary spaces remain preserved. Long and ordinary arrows, and epsilon versus varepsilon, remain distinct tokens. Unknown upright/group forms still fail explicitly.'
 report['article_mathml_array_check']={'embedded_mathml_count':len(embedded),'all_exact_strings_equal_to_math_array':True}
 report['method']+=' v5 adds only D013-demonstrated hbox plain alphabetic text with boundary spaces, fixed 1.2em bigl/bigr parentheses retaining OPEN/CLOSE classification, literal factorial punctuation and the centered ellipsis cdots. hbox text-style wrappers and sized delimiters remain distinct canonical nodes. Other hbox syntax, delimiters or sizes are rejected.'
 report['method']+=' v6 adds only observed ell (ℓ), Longrightarrow (⟹), and ldots (…) tokens, kept distinct from plain l, other arrows, and centered dots. It supports the observed relative figure PNG HTML img form with explicit width=1120 and height=672, compares full alt text and raw-image/wrapper destination paths, and preserves declared dimensions. Actual GitHub-added responsive style must match the witnessed exact attribute string; no geometry is inferred. Explicit anchor attribute families id/name must also match. Unsupported HTML image attributes, dimensions, paths or added styles fail explicitly.'
 report['method']+=' v7 additionally admits the actually observed 960x564 PNG dimension pair, retaining exact source-versus-capture dimensions and the height-specific GitHub responsive style. No mathematical/prose parsing change; all other dimensions/attributes/styles still fail closed.'
 report['method']+=' v8 additionally accepts the witnessed self-closing img syntax by passing it through the identical strict start-tag validator. Explicit closing tags, extra attributes and unsupported dimension pairs remain rejected.'
 report['method']+=' v9 additionally accepts literal semicolon as its own preserved symbol token, demonstrated by D008 r35 lesson expression 124 and actual <mo>;</mo>; semicolon is never dropped or equated with comma/spacing. It adds only the witnessed 1120x560 figure PNG pair, retaining exact dimensions and expected max-height: 560px responsive style. It also preserves observed tfrac as a distinct textstyle_fraction node requiring the exact displaystyle=false wrapper around an ordinary two-child mfrac; the style is never normalized to an ordinary frac. The observed flat Markdown dash lists are represented by identical dash-space markers from HTML ul/li, with exact ordered prose and item counts retained; nested unordered lists fail explicitly. All unknown literals, commands, image dimensions and styles remain explicit failures.'
 report['capture_schema_adaptation']=capture_schema_adaptation
 report['method']+=' v10 adds only the actual D015 reduced capture schema: display is extracted from each exact actual renderer class/style, never source-inferred, and the at timestamp is recorded as observedAt. Existing source versus wrapper versus MathML type comparison remains mandatory. Three witnessed figure PNG pairs, 900x500, 900x560 and 900x600, are added with exact dimension and height-specific responsive-style comparison. No math token or structure normalization is added.'
 report['method']+=' v11 additionally accepts the actually observed inline/block captured display labels only after exact agreement with actual MathML display and actual renderer class/style; the label spelling is then mapped to the legacy js-* metadata. All source-versus-actual structure and type comparisons remain unchanged.'
 source_ul_items=len(re.findall(r'^- ',source_prose,re.M))
 report['unordered_lists']={'source_flat_dash_items':source_ul_items,'actual_flat_ul_items':parser.ul_items,'match':source_ul_items==parser.ul_items,'normalization':'Flat HTML ul/li items receive literal dash-space markers for ordered whole-prose comparison; source dash markers are retained. Nested unordered lists explicitly rejected.'}
 report['counts']['source_normalized_prose_characters']=len(sp)
 report['captured_error_summary']={'capture_reported_errors':dom.get('errors'),'actual_flash_error_slots':sum(r['status']=='render_error' for r in records),'raw_math_code_slots':sum(r['status']=='raw_math_code_in_capture' for r in records)}
 report['disclosures']={'source_count':len(re.findall(r'<details>',source)),'captured_open_count':len(re.findall(r'<details\b[^>]*\bopen(?:=|\s|>)',dom['articleHTML']))}
 report['method']+=' v2 aligns every source expression to an article slot, including explicit error and raw-code slots. Missing MathML is always a failed record. Math slots are replaced by ordinal markers solely for the separate nonmath prose comparison; fallback/error text is fully recorded in the failed math records. Demonstrated v2 additions: square roots, decimal numeric tokens, double prime as two primes, gt/ln/varepsilon/infty/theta/cdot, quad and escaped-space layout, and disclosure markup. Operatorname and cases are not treated as preserved: their captured slots have no MathML, and source text is compared exactly as failed fallback evidence. Unrecognized constructs in actual mathematical rendering still fail explicitly.'
 aggregate=Counter()
 for r in records:aggregate.update(r['structure_counts'])
 report['aggregate_structure_counts']=dict(aggregate)
 checks={
  'anchors':anchor_match,
  'counts':len(exprs)==len(dom['math'])==parser.i,
  'math_structures_and_types':all(r['structural_match'] and r['types_match'] for r in records),
  'prose':sp==ap,
  'unordered_list_items':source_ul_items==parser.ul_items,
  'text_links':len(source_links)==len(text_links) and all(r['label_match'] and r['href_match'] for r in links),
  'image_alts':len(source_alts)==len(parser.alts) and all(r['alt_match'] for r in images),
  'image_destinations_and_explicit_attributes':len(source_image_specs)==len(parser.alts)==len(image_wrapper_links) and all(r['image_src_match'] and r['wrapper_href_match'] and r['declared_attributes_preserved'] for r in images)
 }
 report['checks']=checks
 report['verdict']='PASS' if all(checks.values()) else 'FAIL'
 OUT.mkdir(parents=True,exist_ok=True)
 (OUT/'math-preservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report['counts'],indent=2));print('prose',sp==ap);print('links',all(x['label_match'] and x['href_match'] for x in links));print('images',all(x['alt_match'] for x in images))
 for r in records:
  if not(r['structural_match'] and r['types_match']):print('MISMATCH',r['ordinal'],r['source_latex'],json.dumps(r['source_canonical'],ensure_ascii=False),json.dumps(r['actual_canonical'],ensure_ascii=False))
 if sp!=ap:print('\n'.join(report['prose']['diff'][:150]))

 print("PRESERVATION",report["verdict"])
 raise SystemExit(0 if all(checks.values()) else 1)
except (AssertionError,ValueError,KeyError,IndexError,TypeError) as exc:
 print(f"UNSUPPORTED OR INVALID INPUT: {exc}",file=sys.stderr)
 raise SystemExit(2)
