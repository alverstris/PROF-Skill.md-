# Restricted destination preservation comparator v12

Compare exact frozen Markdown against root-provided actual immutable GitHub DOM. This is preservation review only; it does not establish scientific correctness, SASIS acceptance, geometry, clipping or navigation behavior. No browser operation is performed.

V12 changes only the strict source HTML PNG dimension-pair whitelist by adding the four pairs witnessed in D016: 1500x600, 1500x750, 1050x600 and 1350x405. The actual DOM has the existing exact responsive-style form `max-width: 100%; height: auto; max-height: HEIGHTpx;`. The style validator itself is unchanged. Width, height, full alt text, image raw URL and wrapper destination equality remain mandatory. Unsupported dimensions, attributes and styles fail explicitly.

The mathematical parser, all token and canonical structures, expression order and type comparisons, whole-prose comparison, link and explicit-anchor equality, and every existing image equality are byte-unchanged. Reversing the three recorded description/whitelist/disclosure edits restores the complete v11 tool exactly. The initial unaltered v11 failure remains under `root-review-d016-r37/destination/main/v11-initial/attempt.json`; it is not credited as preservation coverage.

Run without optimization:

```sh
python compare_destination_preservation_v12.py --source /absolute/source.md --capture /absolute/capture.json --source-sha256 EXACT_SHA256 --output-dir /absolute/new-report-directory
```

Exit 0: all supported preservation comparisons passed. Exit 1: preservation comparison failed. Exit 2: unsupported or invalid input. Existing reports are never overwritten.

`targeted_negative_checks.py` modifies temporary synthetic copies, never actual evidence. Its checks reject unsupported source dimensions, altered actual width and height, altered responsive style, altered image alt text, and altered raw/wrapper destinations. The recorded synthetic results are separate from actual preservation reports.
