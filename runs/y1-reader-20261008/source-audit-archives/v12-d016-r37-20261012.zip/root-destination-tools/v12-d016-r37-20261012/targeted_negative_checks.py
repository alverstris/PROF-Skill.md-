#!/usr/bin/env python3
"""Synthetic image-only negative checks; never modifies actual evidence."""
from pathlib import Path
import copy,datetime,hashlib,json,re,subprocess,sys,tempfile
ROOT=Path('/workspace/scratch/f9c0b7fc7e76')
HERE=Path(__file__).resolve().parent
TOOL=HERE/'compare_destination_preservation_v12.py'
SOURCE=ROOT/'d016-clean-r37-20261012/teaching/main.md'
CAPTURE=ROOT/'root-review-d016-r37/destination/d016-main-dom.json'
OUTPUT=HERE/'targeted-negative-checks.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not OUTPUT.exists()
sb=SOURCE.read_bytes();cb=CAPTURE.read_bytes();original_source=sb.decode();original_capture=json.loads(cb)
assert sha(sb)=='ee1766a4215bd1f2753267c2ac6d2cdb825c5fe79ef3a37a84ffb134aa8ab405'
assert sha(TOOL.read_bytes())=='955e6591f2e7f94056b447028578d79b51f4afa4f8fde59f14b059bbb8097b72'
first_image=re.search(r'<img\b[^>]*>',original_capture['articleHTML']).group()
first_source_image=re.search(r'<img\b[^>]*>',original_source).group()
assert 'width="1500"' in first_image and 'height="600"' in first_image
cases=[]
def add(name,source,article,code,check=None,error=None):
 d=copy.deepcopy(original_capture);d['articleHTML']=article
 cases.append((name,source,d,code,check,error))
def image_change(old,new):
 assert first_image.count(old)==1
 return original_capture['articleHTML'].replace(first_image,first_image.replace(old,new,1),1)
add('unsupported_source_dimension_pair',original_source.replace(first_source_image,first_source_image.replace('width="1500"','width="1501"',1),1),original_capture['articleHTML'],2,error='Unsupported source HTML image path/dimensions')
add('actual_width_mismatch',original_source,image_change('width="1500"','width="1501"'),1,'image_destinations_and_explicit_attributes')
add('actual_height_mismatch',original_source,image_change('height="600"','height="601"'),1,'image_destinations_and_explicit_attributes')
add('actual_responsive_style_mismatch',original_source,image_change('max-height: 600px;','max-height: 601px;'),2,error='Unsupported actual HTML image added style')
alt=re.search(r'alt="([^"]*)"',first_image).group(1)
add('actual_alt_mismatch',original_source,image_change('alt="'+alt+'"','alt="'+alt+' SYNTHETIC-MUTATION"'),1,'image_alts')
add('actual_raw_destination_mismatch',original_source,image_change('/teaching/figures/rectangles.png','/teaching/figures/rectangles-synthetic.png'),1,'image_destinations_and_explicit_attributes')
wrapper=re.search(r'<a\b[^>]*href="[^"]*/blob/[^"]*/teaching/figures/rectangles\.png"[^>]*>',original_capture['articleHTML']).group()
article=original_capture['articleHTML'].replace(wrapper,wrapper.replace('/teaching/figures/rectangles.png','/teaching/figures/rectangles-synthetic.png'),1)
add('actual_wrapper_destination_mismatch',original_source,article,1,'image_destinations_and_explicit_attributes')
results=[]
with tempfile.TemporaryDirectory(prefix='d016-v12-synthetic-image-checks-') as td:
 for name,source,capture,expected_code,failed_check,error in cases:
  work=Path(td)/name;work.mkdir();sp=work/'synthetic-source.md';dp=work/'synthetic-capture.json';out=work/'report'
  sp.write_text(source);dp.write_text(json.dumps(capture,ensure_ascii=False)+'\n')
  p=subprocess.run([sys.executable,'-B',str(TOOL),'--source',str(sp),'--capture',str(dp),'--source-sha256',sha(sp.read_bytes()),'--output-dir',str(out)],capture_output=True,text=True)
  assert p.returncode==expected_code,(name,p.returncode,p.stderr,p.stdout)
  record={'name':name,'kind':'Synthetic modified copy; not actual destination evidence','expected_returncode':expected_code,'actual_returncode':p.returncode,'synthetic_source_sha256':sha(sp.read_bytes()),'synthetic_capture_sha256':sha(dp.read_bytes()),'stderr':p.stderr}
  if failed_check:
   report=json.loads((out/'math-preservation.json').read_bytes());assert report['verdict']=='FAIL' and report['checks'][failed_check] is False
   # These image-only mutations must never conceal a mathematical mismatch.
   assert report['checks']['math_structures_and_types'] and report['checks']['prose']
   record.update(verdict=report['verdict'],expected_failed_check=failed_check,failed_checks=[k for k,v in report['checks'].items() if not v],math_preservation_still_passes=True,whole_prose_still_passes=True)
  if error:assert error in p.stderr;record['expected_explicit_error']=error
  results.append(record)
assert SOURCE.read_bytes()==sb and CAPTURE.read_bytes()==cb
result={'scope':'Seven image-only synthetic negative checks for the narrow v12 witnessed dimension extension. No actual evidence modified.','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':sha(sb),'actual_capture_sha256':sha(cb),'tool_sha256':sha(TOOL.read_bytes()),'checks':results,'all_expected_rejections_observed':True,'actual_source_and_capture_unchanged':True,'temporary_synthetic_inputs_removed':True}
OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(results),'all_expected_rejections_observed':True,'output_sha256':sha(OUTPUT.read_bytes())}))
