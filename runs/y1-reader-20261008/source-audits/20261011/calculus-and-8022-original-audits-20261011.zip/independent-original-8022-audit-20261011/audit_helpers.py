from pathlib import Path
import json,hashlib,datetime
ROOT=Path('/workspace/scratch/f9c0b7fc7e76')
OUT=ROOT/'independent-original-8022-audit-20261011'
def report(n,coverage,checks,findings,limitations=None,research=None):
 d=f'D{n}';p=ROOT/'original-inputs'/d;i=json.load(open(p/'source-identity.json'))
 pages=[]
 for f in sorted((p/'text').glob('*.txt')):
  s=f.read_text();pn=int(f.stem[-3:]);png=p/'fullpages'/f'page-{pn:03}.png'
  pages.append({'pdf_page':pn,'text_file':str(f),'text_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'actual_read_char_range':([0,len(s)] if n<=130 else None),'actual_read_line_range':([1,len(s.splitlines())] if s else []) if n<=130 else None,'source_text_read_method':('full extracted text plus full images' if n<=130 else 'all source text/equations read visually on full-page originals; extracted text not separately consumed'),'actual_visual_read_bounds':{'pdf_pages':[pn,pn],'extent':'full page, no crop'},'text_empty':not bool(s),'image_file':str(png),'image_sha256':hashlib.sha256(png.read_bytes()).hexdigest(),'visual_extent':'entire original full-page image; both printed slide panels and figures inspected','visual_read':True})
 r={'material_id':d,'session_id':i['session_id'],'source_url':i['source_url'],'source_sha256':hashlib.sha256((p/'source.pdf').read_bytes()).hexdigest(),'identity_sha256':i['sha256'],'sha256_verified':True,'audit_kind':'independent original mathematical/physical source audit; post-freeze input only; not teaching review, SASIS, PROF acceptance, or queue authorization','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_scope':'Only original-inputs/'+d+' plus source manifest for identity; no author output, teaching skills, diagnoses or prior reviews read','pages':pages,'coverage_units':coverage,'checked_claims':checks,'findings':findings,'research':research or [],'limitations':limitations or []}
 (OUT/f'{d}.json').write_text(json.dumps(r,indent=2))
 lines=[f'{d} independent original source audit',f'Session: {i["session_id"]}',f'Source: {i["source_url"]}',f'SHA256: {r["source_sha256"]} (verified against original manifest and packet identity)',r['audit_kind'],f'Coverage: all {len(pages)} PDF pages; all source text/equations and figures read from full-page images. Extracted text additionally consumed for D126–D130 only. Exact bounded visual ranges and image hashes are in {d}.json.','\nCoverage units']
 lines += ['- '+x for x in coverage]
 lines += ['\nChecked claims']+['- '+x for x in checks]
 lines += ['\nFindings']
 lines += ['- '+x for x in findings] if findings else ['No demonstrable consequential source error found in this reading.']
 lines += ['\nResearch and limits']+['- '+x for x in (research or [])+(limitations or [])]
 (OUT/f'{d}.md').write_text('\n'.join(lines)+'\n')
 ds=sorted(f.stem for f in OUT.glob('D*.json'))
 (OUT/'progress.json').write_text(json.dumps({'completed_sessions':ds,'completed_count':len(ds),'assigned_count':22,'next_session':f'D{n+1}' if n<147 else None,'queue_advanced':False,'findings_author_visibility':'withheld until whole-generation freeze','github_writes':False},indent=2))
