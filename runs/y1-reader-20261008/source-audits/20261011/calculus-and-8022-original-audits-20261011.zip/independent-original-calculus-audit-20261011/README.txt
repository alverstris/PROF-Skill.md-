Independent original-source calculus audit: D018-D034

Completed 17 packets, 18 original PDFs, and 114 page occurrences. Each packet has an individual Dxxx.json checkpoint.

The audit is source-only. It is not SASIS, acceptance of any teaching document, or a PROF verdict. No author outputs or earlier diagnoses were read. Findings have been shared only with root and must remain withheld from fresh authors until their complete generation freeze.

Every assigned page was read as full extracted text in bounded chunks and as its full-page image. Figures and displayed equations were inspected, rather than assuming that extraction represented the page. D029 includes lec32.pdf and exam4_review.pdf.

INDEX.json provides PDF SHA-256 values, checkpoint hashes, per-page text and image hashes, exact page/printed locators, counts, and the full evidence inventory. Each Dxxx.json records content units, visual checks, classified findings, checked mathematical deductions, and external primary references where used.

Finding entries deliberately distinguish source errors from scope qualifications, ambiguous wording, ideal-model limitations, and an explicit optional proof obligation. Do not interpret the total as a count of proved defects.

The two crop images are targeted visual checks made after full-page inspection: D021 confirms the Gaussian normalization is correctly printed, and D031 confirms the activity exponent is correctly superscripted. Both are non-defect visual confirmations.

This directory contains no author-facing teaching artifact. It has not been committed or published by this auditor; root or the evidence owner handles Git-backed publication.

Packet coverage:
D018: 1 PDF(s), 5 page(s), 7 classified finding entry/entries.
D019: 1 PDF(s), 7 page(s), 4 classified finding entry/entries.
D020: 1 PDF(s), 6 page(s), 3 classified finding entry/entries.
D021: 1 PDF(s), 11 page(s), 3 classified finding entry/entries.
D022: 1 PDF(s), 6 page(s), 3 classified finding entry/entries.
D023: 1 PDF(s), 4 page(s), 3 classified finding entry/entries.
D024: 1 PDF(s), 6 page(s), 5 classified finding entry/entries.
D025: 1 PDF(s), 6 page(s), 4 classified finding entry/entries.
D026: 1 PDF(s), 4 page(s), 3 classified finding entry/entries.
D027: 1 PDF(s), 9 page(s), 4 classified finding entry/entries.
D028: 1 PDF(s), 5 page(s), 2 classified finding entry/entries.
D029: 2 PDF(s), 15 page(s), 7 classified finding entry/entries.
D030: 1 PDF(s), 5 page(s), 5 classified finding entry/entries.
D031: 1 PDF(s), 7 page(s), 7 classified finding entry/entries.
D032: 1 PDF(s), 8 page(s), 5 classified finding entry/entries.
D033: 1 PDF(s), 6 page(s), 6 classified finding entry/entries.
D034: 1 PDF(s), 4 page(s), 6 classified finding entry/entries.
