import json,hashlib,datetime
from pathlib import Path
base=Path('/workspace/scratch/f9c0b7fc7e76')
out=base/'independent-original-calculus-audit-20261011'
manifest=json.loads((base/'remaining-source-preparation-20261011/manifest.json').read_text())
packets=[]
for n in range(18,35):
 id=f'D{n:03d}'; record=out/f'{id}.json'; a=json.loads(record.read_text()); orig=base/'original-inputs'/id
 assert a['material_id']==id
 assert len(a['pages'])==a['required_pdf_pages']
 ids=[x['id'] for x in a['findings']]; assert len(set(ids))==len(ids)
 evidence=[]
 for entry in a['pages']:
  name=entry.get('asset',a['source_assets'][0]['filename'])
  pdf=orig/name; stem=pdf.stem; page=entry['pdf_page']
  txt=orig/f'{stem}-p{page:02d}.txt'; png=orig/f'{stem}-p{page:02d}.png'
  assert txt.is_file() and png.is_file()
  assert entry['units'] and entry['visual']
  evidence.append({'asset':name,'pdf_page':page,'printed_locator':entry['printed'],'text_path':str(txt),'text_sha256':hashlib.sha256(txt.read_bytes()).hexdigest(),'full_page_image_path':str(png),'full_page_image_sha256':hashlib.sha256(png.read_bytes()).hexdigest(),'full_text_read':True,'full_page_image_inspected':True})
 for asset in a['source_assets']:
  assert hashlib.sha256((orig/asset['filename']).read_bytes()).hexdigest()==asset['sha256']
  pages=[e['pdf_page'] for e in evidence if e['asset']==asset['filename']]
  assert pages==list(range(1,len(pages)+1)),(id,asset['filename'],pages)
 packets.append({'material_id':id,'record_path':str(record),'record_sha256':hashlib.sha256(record.read_bytes()).hexdigest(),'source_assets':a['source_assets'],'required_page_occurrences':a['required_pdf_pages'],'recorded_page_occurrences':len(a['pages']),'finding_entries':len(a['findings']),'finding_kinds':[x['kind'] for x in a['findings']],'page_evidence':evidence})
index={'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent original-source scientific and mathematical audit for D018-D034. Not SASIS; not teaching acceptance; not a PROF verdict.','method':'Serial packet audits in assigned order. Full extracted texts read in bounded chunks and every original full-page image inspected; consequential equations and figures checked visually. This index records file identities and evidence paths, not a replacement for the original source.','access_boundary':'Original packets and boundary manifest only, plus official primary external references when needed. No author outputs, earlier diagnoses, skills, review reports, queues, or GitHub writes. All records confined to this directory; findings sent only to root.','packet_count':len(packets),'pdf_count':sum(len(p['source_assets']) for p in packets),'page_occurrences':sum(p['recorded_page_occurrences'] for p in packets),'finding_entries':sum(p['finding_entries'] for p in packets),'finding_count_warning':'Finding entries include actual source errors, explicit ambiguities, scope qualifications, and one assigned proof obligation. They are not all mathematical errors and must not be treated as a defect tally.','packets':packets}
assert index['packet_count']==17 and index['pdf_count']==18 and index['page_occurrences']==114
(out/'INDEX.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
lines=['Independent original-source calculus audit: D018-D034','',f"Completed 17 packets, 18 original PDFs, and 114 page occurrences. Each packet has an individual Dxxx.json checkpoint.",'','The audit is source-only. It is not SASIS, acceptance of any teaching document, or a PROF verdict. No author outputs or earlier diagnoses were read. Findings have been shared only with root and must remain withheld from fresh authors until their complete generation freeze.','','Every assigned page was read as full extracted text in bounded chunks and as its full-page image. Figures and displayed equations were inspected, rather than assuming that extraction represented the page. D029 includes lec32.pdf and exam4_review.pdf.','','INDEX.json provides PDF SHA-256 values, checkpoint hashes, per-page text and image hashes, exact page/printed locators, counts, and the full evidence inventory. Each Dxxx.json records content units, visual checks, classified findings, checked mathematical deductions, and external primary references where used.','','Finding entries deliberately distinguish source errors from scope qualifications, ambiguous wording, ideal-model limitations, and an explicit optional proof obligation. Do not interpret the total as a count of proved defects.','','The two crop images are targeted visual checks made after full-page inspection: D021 confirms the Gaussian normalization is correctly printed, and D031 confirms the activity exponent is correctly superscripted. Both are non-defect visual confirmations.','','This directory contains no author-facing teaching artifact. It has not been committed or published by this auditor; root or the evidence owner handles Git-backed publication.','','Packet coverage:']
for p in packets:lines.append(f"{p['material_id']}: {len(p['source_assets'])} PDF(s), {p['recorded_page_occurrences']} page(s), {p['finding_entries']} classified finding entry/entries.")
(out/'README.txt').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:index[k] for k in ['packet_count','pdf_count','page_occurrences','finding_entries']}))
print('Source and record hashes verified; all page text/image evidence exists; per-asset page sequences complete.')
