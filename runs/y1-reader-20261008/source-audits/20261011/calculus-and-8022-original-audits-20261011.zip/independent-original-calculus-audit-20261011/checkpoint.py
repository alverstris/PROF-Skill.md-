import json,hashlib,datetime
from pathlib import Path
BASE=Path('/workspace/scratch/f9c0b7fc7e76')
OUT=BASE/'independent-original-calculus-audit-20261011'
def save(id,title,pages,findings,checks,refs=[]):
 p=BASE/'original-inputs'/id
 assets=[]
 for f in sorted(p.glob('*.pdf')):
  assets.append({'filename':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 manifest=json.loads((BASE/'remaining-source-preparation-20261011/manifest.json').read_text())
 item=next(x for x in manifest['packets'] if x['material_id']==id)
 assert {a['sha256'] for a in assets}=={s['sha256'] for s in item['sources']}
 for a in assets:a['url']=next(s['url'] for s in item['sources'] if s['sha256']==a['sha256'])
 record={'material_id':id,'title':title,'audit_date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent original-source scientific and mathematical audit only. Not SASIS; not acceptance of teaching; not a PROF verdict. No author outputs or prior diagnoses read. Findings withheld from authors until generation freeze.','source_assets':assets,'required_pdf_pages':item['required_page_occurrences'],'reading_method':'Complete assigned per-page extracted text read in bounded chunks, and every original full-page PNG inspected visually; consequential equations and figures checked against image, not inferred from extraction alone.','pages':pages,'findings':findings,'checked_deductions':checks,'external_primary_references':refs,'completion':'complete source-only audit'}
 (OUT/(id+'.json')).write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
 print(id,'checkpoint',len(pages),'pages',len(findings),'findings')
