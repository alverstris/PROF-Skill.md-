# D019 independent original-only technical preparation

Reviewer: `/root/technical_d019_prepared`. Stage: source and baseline preparation, before receipt of any current PROF or final assessment prompts. No future prompt has been solved in this packet. Source page numbers below count the cover as PDF page 1; printed lecture pages run 1–6 on PDF pages 2–7.

## Admitted source and actual reading

The sole university source is MIT 18.01 Fall 2006 Lecture 21, *Applications to Logarithms and Geometry*, `original-inputs/D019/lec21.pdf`, SHA-256 `d73cb5e6e92b0a43661aa21a43f5b8cb991962e04eada5bdc292782b2aeb20d5`. It has seven PDF pages. Every page was viewed whole and its complete literal extraction read. All seven supplied PNG files are byte-for-byte identical to a fresh 140 dpi `pdftoppm` rendering of this PDF, and all seven text files are byte-for-byte identical to a fresh per-page `pdftotext -layout` extraction. Thus the errors discussed below are confirmed in the original PDF, not inferred from extraction alone.

The entire 247840-byte student baseline was read sequentially, including all four subjects and their limits. Its SHA-256 is `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. The segment record accounts for every byte and line without relying on a heading scan. A truncated intermediate read was replaced by two complete reads and is not credited. The separate input manifest and actual-read record give the reproducible identities and coverage.

## Logarithm construction: source pages 2–3

**S01 — Fresnel context and power-rule exception.** The opening paragraph mentions the integral-defined Fresnel functions C and S and the possibility of graphs and tables. It gives neither their definitions nor a particular Fresnel calculation, so none can be reconstructed from this lecture alone. The power antiderivative x^(n+1)/(n+1)+C has derivative x^n when n != -1 on a valid real domain. At n=-1 its displayed denominator is zero. A monomial A*x^k cannot differentiate to 1/x on x>0: matching exponents forces k=0, whose derivative coefficient A*k is zero. The logarithm is therefore a different type of primitive, as claimed. The statement is about the family of powers, not a general impossibility of representing other primitives.

**S02 — Definition, domain and FTC.** Define

    L(x) = integral from 1 to x of (1/t) dt,  x>0.

For each positive x the integration path stays in a closed positive interval, where 1/t is continuous; the ordinary definite integral exists. If 0<x<1, the bounds are reversed: L(x)=-integral from x to 1 of (1/t)dt. The lecture's FTC2 is the differentiation-of-an-accumulation statement. Its application gives L'(x)=1/x; a second derivative gives L''(x)=-1/x^2. The power-law rule, constant multiples, and chain rule in the Mathematics baseline support the latter calculation. L(1)=0 because equal limits give zero. Positive first derivative makes L strictly increasing; the zero at 1 then gives L<0 on (0,1) and L>0 on (1,infinity). Negative second derivative gives concavity down throughout (0,infinity).

The source says 1/t is infinite at zero; precisely, it is undefined and unbounded there. A singularity alone would not prove divergence for every integrand. For this particular integrand the later limit proof establishes the required divergence. There is no real L defined by this ordinary integral for x<=0. The familiar baseline primitive ln|x| on an interval of negative x does not legitimise integrating through zero; FM28 requires separate one-sided convergence.

**S03 — Product law, including bounds below 1.** Let a,b>0. Additivity of oriented integrals gives

    L(ab)-L(a) = integral from a to ab of dt/t.

Put t=a*u; dt=a*du. Endpoints map a -> 1 and ab -> b, hence

    integral_a^(ab) dt/t = integral_1^b (a/(a*u))du
                         = integral_1^b du/u = L(b).

Thus L(ab)=L(a)+L(b). This works for b>1, b=1, and 0<b<1; for the last case both displayed integrals are reversed. No pre-existing logarithm product identity is used in this derivation.

**Source qualification:** page 3 writes `a<t<ab => 1<u<b`. That ordered-interval description is only useful for b>1. For 0<b<1, write `ab<t<a => b<u<1`, or use the endpoint mapping and oriented integrals above. This is a gap in the stated interval wording, not a counterexample to the product identity.

**S04 — Divergence as x grows.** Since L(2)>0, repeated product law yields L(2^n)=n*L(2) for positive integers n. An explicit induction begins at n=1 and adds L(2) at each step. The right side tends to +infinity. Given any finite target M, choose n with n*L(2)>M. For every x>=2^n, monotonicity gives L(x)>=L(2^n)>M. This justifies the passage from the powers-of-two subsequence to the full limit L(x)->+infinity as x->+infinity. It is not valid for an arbitrary nonmonotone function, but monotonicity was established here. Positivity can also be bounded without a decimal log value: on [1,2], 1/t>=1/2, so L(2)>=1/2>0.

**S05 — Reciprocal law and the limit at zero.** For x>0,

    0=L(1)=L(x*(1/x))=L(x)+L(1/x),
    L(x)=-L(1/x).

As x->0+, 1/x->+infinity, so the previously established full limit gives L(x)->-infinity. In particular, integral_epsilon^1 dt/t=-L(epsilon)->+infinity as epsilon->0+. Both the source's reciprocal statement and its claimed left endpoint behaviour are correct. The source refers to n-fold integer repetition when writing the power-of-two result; extending every real power law would require the subsequent exponential construction or a separate argument.

**S06 — Range, inverse and exponential definitions.** Differentiability supplies continuity. Strict increase plus the two endpoint limits makes L a one-to-one map from (0,infinity) onto all real numbers; intermediate-value reasoning supplies existence of each value and strict increase supplies uniqueness. Therefore there is a unique e>1 with L(e)=1 and a unique inverse E:R->(0,infinity). Defining e^x=E(x) and a^x=E(x*L(a)) requires a>0. The source leaves that restriction implicit in L(a). The case a=1 is permitted and gives the constant function 1.

The construction is consistent without importing the familiar log rules as proof: L(E(s)E(t))=s+t, so injectivity gives E(s+t)=E(s)E(t); E(0)=1 and E(1)=e. Differentiating L(E(x))=x gives E'(x)/E(x)=1 and thus E'=E. These are a check of the source's proposed definitions; the source itself states the definitions and does not print these extra derivative and exponential-law proofs.

**Figure 1.** Inspected in its entire page context: the graph is restricted to x>0, crosses (1,0), rises with decreasing slope, goes down without bound toward the vertical axis, and rises without bound to the right. The dotted vertical marker at the far right is a drawing boundary, not an additional asymptote. The arrows and the text, rather than the finite drawing extent, determine the endpoint claims.

## Areas: source pages 4–6

**S07 — General two-curve formula.** In Figure 2, f is above g between the indicated intersections a<b. A vertical rectangle has height f(x)-g(x) and width dx. Consequently

    A=integral_a^b [f(x)-g(x)]dx

is correct when the depicted ordering holds on the whole interval and the functions are sufficiently well behaved for the stated integral. Intersections alone do not establish global ordering for arbitrary curves; internal crossing points require a split, or integration of the absolute difference. If both functions are below the x-axis, the same top-minus-bottom difference still gives their positive separation.

**Figure 2.** Whole figure inspected: shaded bounded region, f/g labels, a/b vertical guides and a vertical strip with horizontal width dx agree with the formula. No new volume or horizontal-slice rule is encoded here.

**S08 — Example 1 intersections and region.** The boundaries are x=y^2 and y=x-2, equivalently x=y+2. Their intersections satisfy

    y^2=y+2,
    y^2-y-2=(y-2)(y+1)=0.

Thus y=-1 or 2; x=1 or 4 respectively, giving (1,-1) and (4,2). Both points satisfy both original equations. The parabola vertex is (0,0); the line's y-intercept is (0,-2), which is not a boundary intersection. On -1<=y<=2,

    x_right-x_left=(y+2)-y^2=(2-y)(y+1)>=0.

This establishes the line as the right boundary and the parabola as the left. Horizontal extent of the enclosed region is 0<=x<=4, not 1<=x<=4; a vertical area integral needs the part left of the first intersection's x-coordinate.

**S09 — Vertical slices.** For 0<=x<=1, the vertical segment runs from -sqrt(x) to +sqrt(x). For 1<=x<=4, it runs from x-2 to +sqrt(x). The lower boundary switches at x=1. One can check this from the two possible lower restrictions: the enclosed region requires y>=-sqrt(x) and y>=x-2, and their comparison reverses at x=1 on the relevant x-range. The upper boundary remains +sqrt(x). Hence the printed vertical setup is correct:

    A=integral_0^1 2*sqrt(x) dx
      +integral_1^4 [sqrt(x)-x+2] dx.

Independent evaluation, which the source does not finish for this vertical version:

    A1=[(4/3)x^(3/2)]_0^1=4/3.
    A2=[(2/3)x^(3/2)-x^2/2+2x]_1^4
      =16/3-(2/3-1/2+2)=16/3-13/6=19/6.
    A=A1+A2=8/6+19/6=27/6=9/2.

Only nonnegative sqrt branches on x>=0 have been used. At x=0 and x=4 the strips collapse; at x=1 the two lower descriptions agree at -1.

**S10 — Horizontal slices and the source's literal errors.** Right-minus-left gives

    A=integral_-1^2 [(y+2)-y^2] dy
     =[y^2/2+2y-y^3/3]_-1^2
     =(2+4-8/3)-(1/2-2+1/3)
     =10/3-(-7/6)=27/6=9/2.

The source page 5 contains three mutually reinforcing literal mistakes in its horizontal-slice introduction and equation:

1. The prose says to subtract the right curve from the left. For positive width, it must say to subtract the left boundary from the right.
2. The generic integrand is printed `x_left-x_right`; it must be `x_right-x_left` for the displayed increasing y bounds.
3. The specific y integral is printed with `dx`; it must use `dy` consistently with its y bounds, y integrand, primitive, and horizontal-strip thickness.

These are visible in the PDF image and reproduced in the fresh extraction. The specific algebra `(y+2)-y^2`, the y primitive, and the final 9/2 are correct. A quick interior witness is y=0: left x=0, right x=2, width=2; the printed generic left-minus-right would instead give -2. Merely replacing the generic labels while leaving dx would not fully fix the printed equation.

**Figures 3, 4 and 5.** All were inspected whole. Figure 3 identifies the sideways parabola, line, both intersections, vertex and line intercept. Figure 4 marks the vertical split at x=1 and depicts a strip in the right interval; its strip is a schematic rectangle, not a measurement to scale. Figure 5 depicts a horizontal strip with thickness dy, from the red parabola to the line. It supports right-minus-left and contradicts the reversed prose/formula. In these sketches the unlabeled horizontal reference line passes through the label (0,-2), below the labeled origin (0,0); do not interpret it as the true y=0 axis. The labeled coordinates and actual equations determine the geometry. The figures are sufficient to see the change of lower boundary but should not be treated as exact-scale diagrams.

## Volumes: source pages 6–7

**S11 — Disk construction.** For the region between y=0 and a nonnegative graph y=f(x), revolving the filled vertical segment about the x-axis produces a disk of radius f(x). Its area is pi*f(x)^2; a thin slab of thickness dx has approximate volume pi*f(x)^2*dx, and the limit of the sums gives

    V=integral_a^b pi*[f(x)]^2 dx.

The source writes dV=pi*y^2 dx. This is correct differential shorthand for the accumulation relation; an arbitrary finite-width curved slice is only approximately a cylinder. A negative graph would have radius |f| and the same squared expression when the region extends from the axis, but that extension is not depicted. A region missing the axis needs a washer difference; that is in the baseline but is not taught by this particular source example. Stating that a curve alone rotates into a solid is imprecise: rotating only the curve traces the boundary surface. The intended filled region is established by the source's radial strips and disk-area construction.

**Figure 6.** The entire three-dimensional schematic was inspected: y and z transverse directions, x rotation axis, graph f(x), a thin x-width dx, translucent solid, and radial-plane sections at different rotation angles. A full turn is 2*pi radians; the caption describes illustrated intermediate rotations by pi/4 and pi/2. Those are illustrative positions within the full rotation, not factors to apply to the disk volume. The disk radius is measured perpendicular to the x-axis, and its thickness is along x. The diagram is schematic; it does not supply a formula for f or numeric limits.

**S12 — Example 2, ball radius a.** Assume a>0. The upper semicircle is

    y=sqrt(a^2-x^2),  -a<=x<=a,

from x^2+y^2=a^2 and y>=0. Revolve its filled upper half-disk around the x-axis; at each x the disk radius is y and area pi*(a^2-x^2). The volume is

    V=integral_-a^a pi*(a^2-x^2) dx
     =[pi*a^2*x-pi*x^3/3]_-a^a
     =(2*pi*a^3/3)-(-2*pi*a^3/3)
     =4*pi*a^3/3.

The full-interval calculation on the source page is correct. Although the baseline already supplies the sphere formula, the integral derivation here does not use it as a premise. Units agree: cross-sectional area times length yields length cubed. The radius-zero degenerate case gives zero by continuation, but the normal ball example has positive a.

**S13 — Symmetry and missing pi.** The area function pi*(a^2-x^2) is even, so its integral on [-a,a] equals twice its integral on [0,a]. This comes from the change x=-u on [-a,0] or mirror symmetry of equal slices. Correctly,

    V=2*integral_0^a pi*(a^2-x^2) dx
     =2*[pi*a^2*x-pi*x^3/3]_0^a
     =2*(pi*a^3-pi*a^3/3)=4*pi*a^3/3.

The source twice prints the primitive inside this symmetry calculation as `pi*a^2*x-x^3/3`, omitting pi from the cubic term: once at the end of the first symmetry display and again at the beginning of the final display. Its derivative is pi*a^2-x^2, not pi*(a^2-x^2). The later evaluation silently reintroduces pi and its final answer is correct. Each affected primitive needs its own pi restored. Differentiation detects the error independently of knowing the sphere formula. The equality from the correctly printed symmetry integral to the incorrectly printed primitive is false as written.

**Figure 7.** The upper semicircle, dashed lower semicircle, x bounds -a and a, vertical radius a, and vertical strip with horizontal dx all match the disk setup. This is a planar generating cross-section, not already a three-dimensional picture of a ball. The endpoint radius is zero, and the central radius at x=0 is a. Symmetry is about the vertical axis in this generating diagram, producing the even slice-area function used above.

## Baseline alignment and boundaries

The complete baseline, rather than Mathematics alone, governs the available premises. The following are direct, operational starting knowledge, not newly inferred university rules:

- Mathematics has algebraic equations/intersections, principal square-root care, function/inverse definitions, graph domains, sign/concavity from derivatives, power/ln/exp derivatives, antiderivatives, definite FTC evaluation, Riemann-sum interpretation, oriented/signed area reasoning, top-minus-bottom area, consistent substitution with limits, intermediate-value root reasoning, ordinary geometry and circle/sphere formulas.
- Further Mathematics supplies induction (FM01), improper-integral one-sided rules (FM28), disk/washer volumes about coordinate axes with cross-sectional derivation and parametric changes (FM30), and explicit disk/washer cross-sectional areas again in FM63. Thus disk volume is already available in the actual combined baseline even though the Mathematics-only exclusion list would not grant it by itself. FM42's differentiable density/CDF relation is a related accumulation instance, not permission to import an unstated universal theorem solely by its name.
- Physics supplies units/dimensions, graph-area interpretations, circle/sphere geometry, logarithmic identities and sign conventions. Chemistry supplies further logarithmic/graph and quantity reasoning. Neither is needed to substitute for the lecture's calculus proofs. Their whole sections were read; this observation is a relevance judgement after the read, not a reason for selective omission.

The source's distinguishing mathematical work is its integral-first construction of logarithms, product-law proof by rescaling integration, endpoint-limit proofs and inverse construction, plus the concrete comparison of slice directions. Familiar baseline log identities can check results but must not be used circularly to prove the properties of newly defined L. Likewise familiar sphere volume is only a check, not the stated integration derivation.

The baseline's FTC paragraph directly states evaluation from a known primitive. The lecture explicitly supplies the accumulation derivative called FTC2. If a future question asks the student to establish it rather than apply it, the exact permitted proof premises must be checked then; no unprovided general proof is assumed now. Continuity and positivity conditions should accompany this use. No generic eigenvalue, multivariable calculus or advanced analysis facts are needed for this source.

## Limits of this sealed stage

This packet verifies all mathematical claims, both worked examples and all seven figures present in the seven-page original. It does not verify absent problem-set questions, the definitions of the named Fresnel functions, earlier lectures, or institutional year-of-study metadata beyond the supplied source identity. No external link was opened. No prior audit, author history, generated teaching, currently published PROF, student response, prompt packet or hidden solutions were read. Scope confinement was by instruction, not a technical filesystem barrier.

The source has genuine printing/wording defects described above. This review does not silently amend the original: each literal error is separated from the corrected computation. It offers no judgement about a future teaching packet or assessment. After a future current-PROF plus final-prompts-only packet is explicitly provided, independent prompt solutions must be completed and separately sealed before frozen teaching is inspected. Until then this preparation remains sealed and no contact with an author is authorised.
