from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json
checks={}
def poly_derivative(cs):
    return [cs[i]*i for i in range(1,len(cs))]
def poly_value(cs,x):
    return sum(c*x**i for i,c in enumerate(cs))
def vertical_primitive(x):
    r=isqrt(x)
    assert r*r==x
    return F(2,3)*x*r-F(x*x,2)+2*x
roots=[F(1-isqrt(9),2),F(1+isqrt(9),2)]
assert all(y*y-y-2==0 for y in roots)
checks["intersection_y"]=list(map(str,roots))
checks["intersection_points"]=[[str(y*y),str(y)] for y in roots]
checks["horizontal_width_polynomial_coefficients_ascending"]=["2","1","-1"]
# (2-y)(y+1) = 2+y-y^2, explicitly multiply coefficient vectors.
factor_product=[F(0)]*3
for i,c in enumerate([F(2),F(-1)]):
    for j,d in enumerate([F(1),F(1)]): factor_product[i+j]+=c*d
assert factor_product==[F(2),F(1),F(-1)]
A1=F(4,3)
A2=vertical_primitive(4)-vertical_primitive(1)
primitive=[F(0),F(2),F(1,2),F(-1,3)]
Ah=poly_value(primitive,2)-poly_value(primitive,-1)
assert poly_derivative(primitive)==factor_product
assert A1+A2==Ah==F(9,2)
checks.update(vertical_left_area=str(A1),vertical_right_area=str(A2),vertical_total=str(A1+A2),horizontal_total=str(Ah),vertical_horizontal_agree=True,printed_left_minus_right_total=str(-Ah))
# Formal monomial key is (x power, a power, pi power); coefficients are exact rational numbers.
def deriv(poly):
    return {(px-1,pa,pp):coef*px for (px,pa,pp),coef in poly.items() if px}
def endpoint(poly,sign):
    result={}
    for (px,pa,pp),coef in poly.items():
        key=(px+pa,pp)
        result[key]=result.get(key,F(0))+coef*sign**px
    return {k:v for k,v in result.items() if v}
def minus(left,right):
    result=dict(left)
    for k,v in right.items(): result[k]=result.get(k,F(0))-v
    return {k:v for k,v in result.items() if v}
def serial(poly):
    return [{"powers":list(k),"coefficient":str(v)} for k,v in sorted(poly.items())]
correct={(1,2,1):F(1),(3,0,1):F(-1,3)}
printed={(1,2,1):F(1),(3,0,0):F(-1,3)}
integrand={(0,2,1):F(1),(2,0,1):F(-1)}
assert deriv(correct)==integrand
assert deriv(printed)!=integrand
full=minus(endpoint(correct,1),endpoint(correct,-1))
half=minus(endpoint(correct,1),endpoint(correct,0))
doubled={k:2*v for k,v in half.items()}
assert full==doubled=={(3,1):F(4,3)}
checks["ball_volume_coefficient_of_pi_a_cubed"]=str(full[(3,1)])
checks["symmetric_ball_volume_coefficient_of_pi_a_cubed"]=str(doubled[(3,1)])
checks["correct_primitive_differentiates_to_integrand"]=True
checks["printed_primitive_differentiates_to_integrand"]=False
checks["printed_derivative_minus_integrand_formal_monomials"]=serial(minus(deriv(printed),integrand))
checks["formal_monomial_order"]=["x power","a power","pi power"]
assert deriv({(-1,0,0):F(1)})=={(-2,0,0):F(-1)}
checks["log_second_derivative"]="-1/x^2"
# Rescaling multiplies numerator by a and replaces t by a*u; monomial powers cancel.
rescaled_powers=(1-1,0-1)
assert rescaled_powers==(0,-1)
checks["rescaled_integrand"]="1/u for a>0 and u>0"
checks["all_exact_checks_passed"]=True
checks["runtime"]="Python standard library only; exact rational arithmetic"
Path(__file__).with_name("calculation-check.json").write_text(json.dumps(checks,indent=2)+"\n")
print(json.dumps(checks,indent=2))
