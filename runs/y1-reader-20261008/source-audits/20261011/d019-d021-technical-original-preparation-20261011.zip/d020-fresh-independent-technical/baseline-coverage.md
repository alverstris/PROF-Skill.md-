# Full baseline reading record and operational mapping

The complete student baseline was actually displayed and read, rather than searched only for relevant terms. Its byte length is 247,840 and SHA256 is `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. Eight contiguous ranges covered every byte exactly once, including cover, subject metadata, all subject explanations, tables, resource restrictions and final references. Boundaries sometimes split a sentence or heading; the immediately following range completed it. The machine-readable `read-record.json` records those ranges and the tool result identifiers.

## Mathematics: complete section read

Covered the entry scope and authority; prior arithmetic, geometry and language; proof; algebra, functions and coordinate geometry; sequences, series and binomial expansion; trigonometry; exponentials/logarithms; differentiation and applications; integration and elementary differential equations; numerical methods; vectors; statistics, data, probability and distributions; hypothesis tests and large-data-set context; mechanics; and the complete further-teaching and H240-specific exclusions.

Operational D020 premises include circle area/circumference, cylinder/prism volumes, unit and scale consistency, nonnegative square roots for radii, polynomial/exponential arithmetic, function domains, graph interpretation, differentiation, definite integration as antiderivative differences and shrinking slice sums, substitutions including differential and limit changes, and conditional modelling. Standard sum/area reasoning is available; merely labelling these university work would not make them untaught. H240 alone does not supply general density integration or a memorised volumes-of-revolution rule here, but the Further Mathematics packet explicitly supplies those methods.

## Further Mathematics: complete section read

All entries FM01-FM71 were read, not just the relevant ones:

- FM01-FM08: induction and complex arithmetic, forms, geometry, loci and roots.
- FM09-FM20: matrices, composition, transformations, invariance, determinants/inverses, simultaneous equations, lines/planes, scalar and vector products, intersections and distances.
- FM21-FM29: root/coefficient relations, partial fractions, sums, hyperbolic functions and calculus, Maclaurin series, improper integrals, inverse trigonometry and substitutions.
- FM30-FM36: volumes and means, polar curves, first/second-order equations, forcing, SHM/damping, and coupled-equation elimination.
- FM37-FM44: counting, discrete expectation, coding, uniform/geometric/Poisson models, continuous densities/distributions/moments, and standard continuous distributions.
- FM45-FM56: sums, sampling, mean tests, confidence intervals, chi-squared tests, sign/Wilcoxon tests, correlation, rank tests, and regression.
- FM57-FM68: dimensions, work/energy, elastic objects, power, momentum, restitution, centres of mass, shape resources, equilibrium, circular motion, constraint loss, and variable forces.
- FM69-FM71: excluded university formalisms, numerical resource conditions, and cross-subject combinations.

D020 directly uses FM30 disk/washer volumes and derivation from area; FM28 improper-integral limits for optional all-plane dart normalisation; FM42 density versus point probability, normalisation and CDF rules; FM43 weighted moments where appropriate; FM57 dimensional consistency; and the available one-variable weighted-volume reasoning of FM63. The baseline supplies no memorised general multivariable Jacobian or multiple-integral theorem. Annular area and radial density can nevertheless be derived explicitly from circle geometry and one-variable integration. A shell rule need not be pre-assumed: the circumference-thickness-height construction in the lecture supplies it and permitted limiting sums justify it. No general fluid dynamics, statistical mechanics or quantum formalism is imported by overlapping symbols.

## Physics: complete section read

Covered all reference data and geometry, then every numbered section:

1. Quantities, units/calculation, vectors/graphs/rates, uncertainty, experimental judgement and practical methods/competence.
2. Forces/motion, drag, equilibrium, pressure/buoyancy, work/energy/power/momentum, springs and materials.
3. Charge/circuits, waves/optics, photons and matter waves.
4. Thermal equilibrium, temperature, internal energy, heating/phase changes, gas models/kinetic theory, circular motion/SHM, gravity and orbits.
5. Stars, spectra, HR/black-body relations, distances, Doppler/Hubble and cosmology.
6. Capacitance/exponentials, electric fields/potential, magnetic forces/flux/induction and transformers.
7. Nuclear/particle rules, decay, nuclear energy, X-ray/tracer/PET/ultrasound models and calculations.
8. The complete declared assumptions and university-formalism limits.

D020-relevant premises are density=m/V; speed and displacement/time; prism/cylinder volume; units of volume, speed and energy; powered-unit conversion; temperature interval equality in kelvin and Celsius; Q=mc Delta T for specified heat capacity and conditions; phase-change Q=m latent heat; and explicit distinction between sample energy gain, input, container heating, work and losses. Combining these with permitted calculus yields a slice-by-slice sensible-heating calculation. The baseline does not itself supply a Poiseuille velocity law or prove its regime; D020 supplies the particular profile. Thermal laws do not make the source's 70-to-100 profile identical to a uniform 100-degree final state.

## Chemistry: complete section read

Read CH-META and CH-00 usage/resource conditions; CH-01 quantities, atoms/isotopes, formulae/equations and moles; CH-02 electron structure/bonds/shapes/polarity; CH-03 acids/redox, Groups 2/halogens/tests, complexes and transition reactions; CH-04 collisions, rate laws and equilibrium; CH-05 quantitative acids/bases/buffers/titrations; CH-06 heat/enthalpy, lattice/Hess/hydration cycles, entropy/Gibbs; CH-07 titration/electrochemistry; CH-08 organic language/isomerism/mechanisms; the whole CH-09 reaction table and synthesis/polymer/aromatic discussion; CH-10 tests/chromatography/IR/MS/NMR; all CH-11 practical planning, uncertainty, volumetric, heating/rate and separation methods; CH-12 scope/transfer limits; and every CH-REF entry and terminal paragraph.

D020-relevant premises include cubic-volume and energy conversions, heat-capacity units, treating a temperature difference without adding 273, CH-06.01 q=mc Delta T and the appropriate aqueous density/specific-heat approximation, and losses/vessel heat as explicit modelling limitations. Chemistry's quantitative entropy and Gibbs knowledge was read but is not needed to supply or replace the source's heat calculation. No empirical calorie-to-joule conversion is needed because the source provides its own volumetric coefficient in calories.

## Combined constraints retained

The four subject sections are one starting-knowledge input. Course completion is a competence assumption, not observed mastery. Explicitly supplied methods and clearly shown deductions are usable; names, links and assessment exclusions are not substitutes for operational premises. External references within the baseline were not opened. No reference table or missing problem-specific parameter was silently supplied. No supplemental baseline, author history, teaching, final task or assessment solution was consulted. The complete read supports the mapping above; this preparation does not certify an unseen lesson or predict student trial performance.
