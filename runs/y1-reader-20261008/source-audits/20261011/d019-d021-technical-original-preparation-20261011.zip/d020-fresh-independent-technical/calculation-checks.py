"""D020 exact-arithmetic and numerical corroboration; standard library only.

General derivations and modelling conditions are in source-calculations.md.
Polynomial calculations use exact Fraction arithmetic with pi factored out.
Exponential-integral checks corroborate numerically, not as symbolic proofs.
No external subject input is read.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import math
checks=[]
def primitive(coefficients):
    return [F(0)]+[value/F(power+1) for power,value in enumerate(coefficients)]
def value(coefficients,x):
    return sum(coefficient*x**power for power,coefficient in enumerate(coefficients))
def integral(coefficients,a,b):
    p=primitive(coefficients)
    return value(p,b)-value(p,a)
def exact(name,got,expected,condition):
    assert got==expected,(name,got,expected)
    checks.append({'name':name,'method':'exact rational arithmetic; pi factored out when applicable','calculated':str(got),'expected':str(expected),'passed':True,'condition':condition})
def numerical(name,got,expected,tolerance,condition):
    error=abs(got-expected)
    assert error<tolerance,(name,error)
    checks.append({'name':name,'method':'composite Simpson quadrature corroboration; pi factored out','calculated':got,'expected':expected,'absolute_error':error,'tolerance':tolerance,'passed':True,'condition':condition})
def simpson(f,a,b,n=20000):
    assert n%2==0
    h=(b-a)/n
    terms=[f(a),f(b)]
    terms.extend((4 if i%2 else 2)*f(a+i*h) for i in range(1,n))
    return h*math.fsum(terms)/3
exact('disk primitive coefficients',primitive([F(0),F(1)]),[F(0),F(0),F(1,2)],'integral y dy; multiply by pi')
for top_radius in [F(0),F(1,2),F(1),F(2),F(3)]:
    a=top_radius**2
    disk=integral([F(0),F(1)],F(0),a)
    shell=integral([F(0),2*a,F(0),F(-2)],F(0),top_radius)
    exact(f'disk factor a={a}',disk,a*a/2,'source numerical y=x^2; result times pi')
    exact(f'shell factor a={a}',shell,a*a/2,'bounds 0..sqrt(a); result times pi')
for kappa,top_radius in [(F(1),F(1)),(F(100),F(1,10)),(F(1,100),F(100)),(F(3,2),F(4,3))]:
    a=kappa*top_radius**2
    disk=integral([F(0),1/kappa],F(0),a)
    shell=integral([F(0),2*a,F(0),-2*kappa],F(0),top_radius)
    expected=a*a/(2*kappa)
    exact(f'physical disk kappa={kappa},a={a}',disk,expected,'Y=kappa X^2; result times pi')
    exact(f'physical shell kappa={kappa},a={a}',shell,expected,'Y=kappa X^2; result times pi')
for radius,width in [(F(0),F(1,100)),(F(2),F(1,10)),(F(3,2),F(1,1000))]:
    exact(f'finite annulus r={radius},width={width}',(radius+width)**2-radius**2,2*radius*width+width**2,'exact area divided by pi, including quadratic thickness term')
exact('large cauldron litres divided by pi',F(1,2)*1000,F(500),'metre coordinate model')
exact('small cauldron litres divided by pi',F(100**2,2)/1000,F(5),'centimetre coordinate model')
exact('same physical shape in cm, litres divided by pi',F(100**2)/(2*F(1,100))/1000,F(500),'numerical y_cm=x_cm^2/100')
profile=integral([F(0),F(100),F(-30)],F(0),F(1))
uniform=integral([F(0),F(100)],F(0),F(1))
extra=integral([F(0),F(0),F(30)],F(0),F(1))
exact('profile weighted volume divided by pi',profile,F(40),'zero to 100-30y profile')
exact('uniform weighted volume divided by pi',uniform,F(50),'zero to uniform 100 degrees C')
exact('remaining weighted volume divided by pi',extra,F(10),'profile to uniform 100 degrees C')
exact('target states add',profile+extra,uniform,'same constant volumetric heat capacity')
exact('volume-weighted mean temperature',profile/F(1,2),F(80),'source paraboloid at a=1')
exact('profile kcal divided by pi',profile*10**6/1000,F(40000),'source calorie heat capacity')
exact('profile bars divided by pi',profile*10**6/1000/250,F(160),'source 250 kcal/bar datum')
for R,c in [(F(1),F(1)),(F(2),F(1)),(F(3,2),F(5,3))]:
    Q=integral([F(0),2*c*R*R,F(0),-2*c],F(0),R)
    Q2=integral([F(0),2*c*(2*R)**2,F(0),-2*c],F(0),2*R)
    exact(f'pipe flow factor R={R},c={c}',Q,c*R**4/2,'result times pi; c fixed')
    exact(f'pipe mean speed R={R},c={c}',Q/(R*R),c*R*R/2,'divide flow by area')
    exact(f'pipe doubled radius R={R},c={c}',Q2/Q,F(16),'same nonzero c')
for r1,r2,c in [(0.,1.,1.),(1.,2.,1.),(0.3,1.7,2.5),(0.,3.,1.)]:
    got=simpson(lambda r:2*c*r*math.exp(-r*r),r1,r2)
    expected=c*(math.exp(-r1*r1)-math.exp(-r2*r2))
    numerical(f'dart annulus r1={r1},r2={r2},c={c}',got,expected,1e-11,'areal-density model; multiply by pi; independent Simpson sum')
ell=2.3;C=1.7;r1=0.4;r2=4.2
got=simpson(lambda r:2*C*r*math.exp(-(r/ell)**2),r1,r2)
expected=C*ell**2*(math.exp(-(r1/ell)**2)-math.exp(-(r2/ell)**2))
numerical('dart physical length scale',got,expected,1e-10,'ell=2.3, C=1.7; multiply by pi')
numerics={'large_cauldron_litres':500*math.pi,'small_cauldron_litres':5*math.pi,'profile_kcal':40000*math.pi,'profile_bars':160*math.pi,'uniform_kcal':50000*math.pi,'uniform_bars':200*math.pi,'extra_kcal':10000*math.pi,'extra_bars':40*math.pi,'dart_at_r_2_relative_to_c':math.exp(-4)}
result={'status':'all exact-arithmetic and numerical corroboration checks passed','check_count':len(checks),'checks':checks,'numerical_comparisons':numerics,'limits':'Parameter sampling and quadrature supplement the general derivations in source-calculations.md; they do not prove every parameter case or resolve model interpretation.','runtime_note':'SymPy unavailable in default and primary Python; final executable uses only Python standard library.'}
destination=Path(__file__).resolve().with_name('calculation-results.json')
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':True,'output':str(destination)}))
