# D020 independent original-source technical preparation

Status: original-only preparation complete; future assessment and teaching review not started.

This record was made from the six physical PDF pages of MIT 18.01 Fall 2006 Lecture 22, its six supplied full-page raster images and complete text extractions, source-identity.json, and the complete 247,840-byte four-subject student baseline. No current PROF text, final prompt packet, teaching, supplied solutions, prior audit, author history, other corpus item, or outside subject source was read. All nine figures were inspected on whole page images. Each supplied image is pixel-identical to a fresh 140 dpi render of the original PDF; every supplied page text is byte-identical to fresh PDF text extraction. These are checks of the actual supplied PDF, not a reconstruction from remembered lecture content.

The source PDF is `original-inputs/D020/lec22.pdf`, SHA256 `6a5a07e58c762c73543e6f9607bf128434d36fd441eacab54147a2f837d44077`. The baseline is `d008-clean-r30-20261011/inputs/student-baseline.txt`, SHA256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`. Physical PDF page 1 is the cover; physical pages 2-6 carry printed lecture pages 1-5.

## Example 1: the cauldron, disks, units and shells

Source: physical pages 2-4, Figures 1-4. The depicted container is a paraboloid around the y axis, capped at y=a. In the source's numerical-coordinate convention its occupied interior can be described by 0<=y<=a and 0<=r<=sqrt(y), or by 0<=r<=sqrt(a) and r^2<=y<=a. Take a>=0; a=0 is the degenerate zero-volume case. A full disk uses the nonnegative radius; rotating both x signs must not double the volume.

For a horizontal slice, r^2=y, area A(y)=pi r^2=pi y, and thickness dy. Hence

V = integral_0^a pi y dy = [pi y^2/2]_0^a = pi a^2/2.

The original disk area, differential and integration are correct in the stated numerical-coordinate convention. Figure 2 shows the vertical thickness direction and the height a; its perspective ellipse is the planar circular disk, not an additional factor in area. A derivation can regard a thin finite slice as approximately A(y) Delta y and take a sum limit. The baseline already supplies that limit-of-sums meaning and FM30 disk/washer geometry.

For a cylindrical shell, radius r=x>=0, circumference 2pi x, height a-x^2 and radial thickness dx. Thus

V = 2pi integral_0^sqrt(a) x(a-x^2) dx
  = 2pi [a x^2/2-x^4/4]_0^sqrt(a)
  = 2pi(a^2/2-a^2/4) = pi a^2/2.

All algebra in the shell calculation is correct. The bounds, height subtraction, and nonnegative radius are essential. Figure 4 shows the shell from y=x^2 up to y=a; the height is not x^2. The product circumference times thickness is the first-order annular area: pi[(x+Delta x)^2-x^2]=2pi x Delta x+pi(Delta x)^2. For a fixed-height annular cylinder the same product then gives its first-order volume; a varying-height shell is handled by the limiting sum. The shell is not a solid cylinder of volume pi x^2(a-x^2). The original source presents the differential directly rather than proving the limit.

The source's unit warning is substantive. An equation equating dimensional lengths Y=X^2 needs a dimensional coefficient. Write the physical paraboloid as

Y=kappa X^2, with kappa>0 and [kappa]=length^(-1).

At physical height A, the top radius is sqrt(A/kappa). The dimensionally complete result is

V=pi A^2/(2kappa).

Keeping the numerical equation y=x^2 while changing the coordinate length unit changes kappa and therefore changes the physical container. The source's two cauldrons are not the same physical shape with a simple unit conversion.

| Numerical coordinate convention | Physical kappa | Height | Top radius | Volume |
|---|---:|---:|---:|---:|
| x,y in metres; y=x^2 | 1 m^-1 | 1 m | 1 m | pi/2 m^3 = 500pi litres, approximately 1570.8 litres |
| x,y in centimetres; y=x^2 | 1 cm^-1 = 100 m^-1 | 100 cm | 10 cm | 5000pi cm^3 = 5pi litres, approximately 15.708 litres |

The volume ratio is 100; the top radius/diameter ratio is 10. Figure 3 explicitly labels height 100 cm and top width 20 cm, which agrees with radius 10 cm. The first cauldron has top width 2 m=200 cm. Source rounded values 1600 litres and 16 litres are consistent with these results.

To preserve the first physical shape in centimetre coordinates, use y_cm=x_cm^2/100. At y_cm=100 its radius is 100 cm and its volume remains 500pi litres. Thus the source statement that the written relation is not scale-invariant is correct for holding its numerical coefficient at one. The bare pi a^2/2 expression must be read in its coordinate convention; on its own with a dimensional height it would have area dimensions.

## Example 2: temperature-weighted volume and energy

Source: physical page 4, Figure 5. The figure has top y=a=1 metre at 70 degrees C, and bottom y=0 at 100 degrees C. Its displayed model T(y)=100-30y, with y the numerical height in metres, matches those endpoint labels. With physical height Y, this is T(Y)=100 degrees C-(30 degrees C per metre)Y. The constant temperature on each horizontal disk makes disks a suitable partition.

Using the same metre-coordinate paraboloid, the displayed weighted-volume calculation is

I=integral_0^1 (100-30y)pi y dy
 =pi[50y^2-10y^3]_0^1=40pi degree C m^3.

This integration is correct. The source calls I the total heat H, but before multiplication by volumetric heat capacity it has temperature-times-volume units, not energy units. For uniform water initially at 0 degrees C, with the source's volumetric heat capacity C_V=1 cal/(cm^3 degree C), heating it to the displayed final profile gives

Q_profile=C_V integral (T_final-T_initial)dV
         =40pi x 10^6 cal
         =40,000pi kcal, approximately 125,663.706 kcal.

The baseline supplies density m/V and Q=mc Delta T, and Chemistry CH-06.01 supplies water-like density and heat-capacity approximations. Applying the uniform-property relation to slices and summing justifies the displayed weighting without importing a general thermodynamic field formula as an unexplained premise. The source directly supplies the calorie-based volumetric coefficient used for its numerical answer. Its calculation neglects vessel heating, environmental losses, evaporation, and any work/other energy transfer; no data are supplied for them. Air at 0 degrees C alone would not establish the water's initial temperature, but the question explicitly describes raising water from 0 degrees C.

The physical wording has a consequential conflict. The question says to raise the water from 0 to 100 degrees C, while the figure and T(y) specify a final state ranging from 100 at the bottom to 70 at the top. The computed 40pi is energy from zero to that nonuniform profile. It is not the energy to make every part of the water 100 degrees C.

For comparison, deductions from the same permitted premises are:

- All water from 0 to 100 degrees C: Q_uniform=100 C_V V=50pi x 10^6 cal=50,000pi kcal.
- Additional heat to take the displayed profile to 100 degrees C everywhere: Q_extra=C_V integral_0^1 [100-(100-30y)]pi y dy=10pi x 10^6 cal=10,000pi kcal.
- The volume-weighted final temperature is I/V=(40pi)/(pi/2)=80 degrees C. The simple arithmetic mean of endpoints is 85 degrees C, which fails because the wider upper disks contain more water.

The source result does not address vaporising water: a phase-change energy needs a latent-heat term and supplied data. In the source's intended sensible-heating reading, the term “boil” also should not be used to conceal the explicit 70-degree upper-water temperature. A future prompt must identify the initial state, target state and requested quantity before one of these distinct energies is selected. This is a source ambiguity recorded now, not a ruling on an unseen future prompt.

Source arithmetic and units checked individually:

1. Cubic metres to cubic centimetres requires (100)^3=10^6; the source correctly uses a cubic conversion.
2. 40pi x 10^6 cal equals 40,000pi kcal, approximately 125.664 x 10^3 kcal. The displayed equality to 125 x 10^3 kcal is rounded and should be an approximation sign, not an exact equality.
3. Using the source's approximate 250 kcal per candy bar gives 160pi bars, approximately 502.655 bars, so approximately 500 is consistent. The line labelled “number of calories” but ending in candy bars changes quantity and should instead be read as number of bars.
4. The full 0-to-100 heating would instead correspond to 200pi bars, approximately 628.319 bars; the extra heating from the profile would be 40pi bars, approximately 125.664 bars. These comparison values are independent deductions, not numbers printed in the source.

## Example 3: pipe flow

Source: physical pages 5-6, Figures 6-8. The supplied velocity profile is v(r)=c(R^2-r^2), 0<=r<=R. R is pipe radius and r radial distance from its axis. For forward nonnegative speed take R>0 and c>=0; a signed velocity convention could instead permit signed c but then calling v “speed” would need amendment. Figure 7 explicitly shows v(0)=cR^2 and v(R)=0, in agreement with the equation. Figure 6 depicts greatest speed on the axis and slowing to the wall; Figure 8 marks radial r and the ring thickness dr.

For c>0, v'(r)=-2cr<=0, so the supplied profile decreases from axis to wall. An annulus has differential area dA=2pi r dr, obtained from the circle-area difference as above. During Delta t, material crossing area dA at axial speed v sweeps volume v Delta t dA. Hence dQ=v dA is volume flow per unit time, not just volume. This derives the required bridge from the baseline's prism volume and speed definitions. The source's phrase “area of ring times flow rate” must use local speed for the factor v; multiplying area by an already volumetric flow rate would be dimensionally wrong.

Q=integral_0^R c(R^2-r^2)2pi r dr
 =2pi c[R^2r^2/2-r^4/4]_0^R
 =2pi c(R^4/2-R^4/4)=pi cR^4/2.

The complete displayed integration and result are correct. The differential annular formula is exact at differential level, not the exact area of a finite-width ring with inner radius r. Velocity is analogous to shell height in the algebraic product, but it has different physical dimensions. With [v]=L/T and [R]=[r]=L, [c]=1/(LT), and [Q]=L^3/T, as required. The cross-sectional mean speed is Q/(pi R^2)=cR^2/2=v(0)/2, a derived consistency check.

The source's Q proportional to R^4 claim holds with c fixed. Doubling R then gives sixteen times Q. If c changes with the pipe, pressure conditions or other model parameters, the displayed algebra alone does not establish that comparison. The source gives the profile rather than deriving it and supplies no formula connecting c to pressure, viscosity, length or a fluid regime. No such fluid-dynamical law is assumed here. The source's historical claim that Poiseuille was the first person to study pipe flow is a source assertion, not something verifiable from these inputs; no historical research was performed or needed for the mathematical calculation.

## Example 4: dart board

Source: physical page 6, Figure 9. The source writes N=ce^(-r^2) and describes N as number of hits at radius r, then multiplies by ring area. For that integral to have a coherent continuous count interpretation, ce^(-r^2) must be an areal hit density at points distance r from the centre. It is not already a count in a ring or the one-variable probability density of radius. Rotational symmetry is implicit in using the same density around a complete ring. At an exact radius a continuous radial model gives zero probability, not a finite count supplied directly by the density value.

With nonnegative areal-density scale c, ring boundaries 0<=r1<r2, and the source's dimensionless/numerical radius convention, the source setup is

N_ring=c integral_r1^r2 e^(-r^2)2pi r dr.

That setup is correct for areal density. The source does not evaluate it; independently using u=r^2 and du=2r dr gives

N_ring=[-pi c e^(-r^2)]_r1^r2
      =pi c(e^(-r1^2)-e^(-r2^2)).

Differentiating -pi c e^(-r^2) returns 2pi cr e^(-r^2). The answer is nonnegative for ordered nonnegative bounds and vanishes when the bounds coincide. The one-dimensional radial count density is g(r)=2pi r c e^(-r^2), not ce^(-r^2). Equal-width rings have different areas; using integral ce^(-r^2)dr would describe a different model. The non-elementary antiderivative of e^(-r^2) alone is irrelevant to the displayed ring integral because its r factor supports the baseline substitution rule.

Figure 9 draws the vertical intercept at 1 but labels the curve y=ce^(-r^2). Its actual intercept is c, so the numerical 1 tick selects the special case c=1 or functions as a schematic normalisation. The figure by itself cannot fix arbitrary c. The plotted density decreases for r>0 and tends toward zero; at r=2 it is ce^-4, positive, so the plotted approach to the axis is schematic rather than an exact finite-radius zero. The graph is of areal density, not the radial annulus density g(r), which starts at zero.

If r represents a physical length, the exponential requires a length scale. One consistent model is rho(R)=C exp[-(R/ell)^2], ell>0 and [C]=hits/area. Then

N_ring=pi C ell^2 {exp[-(R1/ell)^2]-exp[-(R2/ell)^2]}.

Alternatively r can be the dimensionless coordinate R/ell, with c absorbing the corresponding area-scale convention. This is the same dimensionless-exponent discipline already required by the baseline. The source supplies no explicit length unit/scale or board radius, so none can be assigned a numerical value.

Conditional normalisation checks (derived, not printed source claims): if the entire plane is included, the total expected count is pi c and a unit-total probability model has c=1/pi in the numerical-coordinate convention. On a finite disk of numerical radius B, the total is pi c(1-e^(-B^2)); conditioning a probability model on that board changes its normalisation. A literal number of observed hits need not equal a continuous model's non-integer expected count. No value of c, total throws, finite board radius, or conditional-on-hitting convention is supplied in the lecture. Those limitations must remain visible when a later question asks for a numerical count or probability.

## Technical boundaries for the next stage

This preparation checks all mathematical content of the four source examples, their displayed algebra, constants, units, domains, nine figures, and consequential modelling interpretations. The cover has only source/course metadata. Source assertions about historical priority and an approximate candy bar's energy are not independently empirical facts established by this closed corpus; the latter is a supplied modelling datum usable as such.

No unseen future task has been solved or graded. No teaching quality or student success judgment follows from this source review. Await the separately authorised currently published PROF text and final prompt-only packet. Independently solve and seal that packet before seeing frozen teaching or any author solution. Preserve this preparation seal; later-stage material belongs in separately identified files. The restriction used here is instruction confinement in a shared tool/filesystem environment, not verified technical isolation or a claim that another process could not access these files.
