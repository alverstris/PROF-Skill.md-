"""D021 original-only exact arithmetic and numerical corroboration.

No task inputs or network resources are opened here. Analytic derivations and
conditions are recorded in original-only-review.md; quadrature is only a check.
"""
import json
import math
from fractions import Fraction


def simpson(f, a, b, n=40000):
    assert n > 0 and n % 2 == 0
    h = (b - a) / n
    return h / 3 * (f(a) + f(b)
                    + 4 * math.fsum(f(a + i*h) for i in range(1, n, 2))
                    + 2 * math.fsum(f(a + i*h) for i in range(2, n, 2)))


result = {}
result['constant_mean'] = 53
# Integrating the semicircle with x=sin(t) avoids endpoint derivative singularity.
result['semicircle_dx_mean_numeric'] = simpson(lambda t: math.cos(t)**2, -math.pi/2, math.pi/2)/2
result['semicircle_dx_mean_exact'] = 'pi/4'
assert abs(result['semicircle_dx_mean_numeric'] - math.pi/4) < 1e-12
result['semicircle_arc_mean_numeric'] = simpson(math.sin, 0, math.pi)/math.pi
result['semicircle_arc_mean_exact'] = '2/pi'
assert abs(result['semicircle_arc_mean_numeric'] - 2/math.pi) < 1e-12
result['cauldron_volume_over_pi'] = str(Fraction(1, 2))
result['cauldron_temperature_numerator_over_pi'] = 100*Fraction(1, 2)-30*Fraction(1, 3)
result['cauldron_temperature_numerator_over_pi'] = str(result['cauldron_temperature_numerator_over_pi'])
result['cauldron_volume_mean'] = 80
result['cauldron_height_mean'] = 85
result['printed_primitive_at_1_minus_at_0_over_pi'] = 500-10
result['correct_primitive_at_1_minus_at_0_over_pi'] = 50-10
assert result['correct_primitive_at_1_minus_at_0_over_pi'] == 40
result['cauldron_volume_mean_numeric'] = simpson(lambda y: 2*y*(100-30*y), 0, 1)
assert abs(result['cauldron_volume_mean_numeric']-80) < 1e-10
result['radial_integral_0_8_numeric'] = simpson(lambda r: r*math.exp(-r*r), 0, 8)
result['radial_integral_8_infinity_exact_tail'] = math.exp(-64)/2
assert abs(result['radial_integral_0_8_numeric']-0.5) < 1e-12
p = (Fraction(1, 16)-Fraction(1, 512))/6
result['dart_per_throw_exact'] = str(p)
result['dart_per_throw_probability'] = float(p)
result['dart_per_throw_percent'] = float(100*p)
result['dart_conditional_on_board_miss_exact'] = str(2*p)
result['dart_conditional_on_board_miss_percent'] = float(200*p)
result['dart_dropped_tail_approximation'] = str(Fraction(1, 96))
result['dart_dropped_tail_relative_error'] = str((Fraction(1, 96)-p)/p)
result['board_radius_scaled'] = math.sqrt(math.log(2))
assert p == Fraction(31, 3072)
r1 = result['board_radius_scaled']
p_numeric = simpson(lambda r: 2*r*math.exp(-r*r), 2*r1, 3*r1)/6
result['dart_per_throw_numeric_integral'] = p_numeric
assert abs(p_numeric-float(p)) < 1e-13
q = simpson(lambda x: math.exp(-x*x), -8, 8)
result['gaussian_Q_numeric_minus8_to8'] = q
result['gaussian_Q_exact'] = 'sqrt(pi)'
result['gaussian_omitted_tail_upper_bound'] = math.exp(-64)/8
assert abs(q-math.sqrt(math.pi)) < 1e-12
second = simpson(lambda x: x*x*math.exp(-x*x), -8, 8)
result['gaussian_unnormalized_second_moment_numeric'] = second
result['gaussian_unnormalized_second_moment_exact'] = 'sqrt(pi)/2'
assert abs(second-math.sqrt(math.pi)/2) < 1e-12
result['finite_shell_volume_R2_over_pi'] = 1-math.exp(-4)
for sigma in (0.5, 1.0, 2.0):
    density = lambda x: math.exp(-x*x/(2*sigma*sigma))/(sigma*math.sqrt(2*math.pi))
    norm = simpson(density, -10*sigma, 10*sigma)
    variance = simpson(lambda x: x*x*density(x), -10*sigma, 10*sigma)
    assert abs(norm-1) < 1e-12
    assert abs(variance-sigma*sigma) < 1e-11
    result[f'normal_sigma_{sigma}_finite_quadrature'] = {'normalization': norm, 'second_moment': variance}
result['checks'] = 'all assertions passed; exact proofs recorded separately'
print(json.dumps(result, indent=2, sort_keys=True))
