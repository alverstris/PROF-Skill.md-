# D021 independent technical review - original-only stage

Status: complete and sealed at the original-only boundary. This is an internal technical record, not teaching and not a student answer packet.

Material: MIT 18.01 Fall 2006, Lecture 23, *Work, Average Value, Probability*. PDF has 11 physical pages: cover plus 10 numbered lecture pages. References below use physical PDF page numbers; printed lecture page equals PDF page minus one.

## Access boundary and actual inspection

Only the contents of `original-inputs/D021/`, the entire explicitly supplied `d008-clean-r30-20261011/inputs/student-baseline.txt`, and the PDF skill instructions were read as task inputs. Every original PNG page 01-11 was displayed and inspected as a whole page. Every original per-page text file 01-11 was read. The identity JSON, PDF hash and PDF page count were checked. The original PDF's actual bytes were read for hashing and its page structure was opened with pypdf.

The entire baseline was read literally in consecutive byte ranges, not merely searched or inferred from headings. The successful, untruncated coverage was `[0,16000)`, `[16000,40000)`, `[40000,64000)`, `[64000,88000)`, `[88000,112000)`, `[112000,136000)`, `[136000,160000)`, `[160000,184000)`, `[184000,208000)`, `[208000,232000)`, `[232000,247840)`. These ranges include every actual byte exactly once in the coverage ledger. A preceding combined read was truncated by output transport; it is not used to claim baseline coverage. That initial output did expose all original text pages 01-10, and original text page 11 was then read in full separately.

No teaching, current PROF, prior audits/history, other corpus directories, previous prompts or solutions, outside subject sources, browser, GitHub writes, settings changes or author contact were accessed. Original-only mathematical cross-checking was delegated to one child agent with the same content boundary and without the baseline; its conclusions were checked against the primary reviewer's own full original inspection. This is an instruction/access boundary; no claim of technical isolation is made.

No currently published full PROF or final prompt-only packet has been supplied in this stage. No final assessment prompt has been solved or scored. A future prompt-only solution must be independently written and sealed before access to frozen new teaching.

## Verified source identities

- Original PDF: 2,272,642 bytes, SHA-256 `1463ecbf26380b9de000787155616be41e5c359102f4dae285d70c255131b182`, 11 pages.
- Student baseline: 247,840 bytes, SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5`.
- All 24 files in the D021 input directory and the one baseline file are individually hashed in `input-manifest.json`. The text files total 20,974 bytes.

## Page-complete claim and example verification

| PDF page | Complete content inspected | Technical disposition |
|---|---|---|
| 01 | OCW cover, course and year, terms/citation notice | No mathematical claims. The URLs are source text; not opened. |
| 02 | Title; averages of 2 and 3 discrete values; Figure 1; equally spaced sample construction; Riemann sum and mean-value limit | Correct with a finite interval a<b and integrable f; continuity is a sufficient familiar condition. The ordering a=x0<...<xn=b alone does not assert equal spacing, so the subsequent n Delta x=b-a must control the construction. Set xi=a+i(b-a)/n. y0 is defined but not included in the right-endpoint average; this is consistent, not an off-by-one error. |
| 03 | Figure 2 upper unit semicircle; Example 1; Example 2; Example 3 and Figure 3 weighting contrast | Mean with uniform horizontal position is pi/4. Constant mean is 53. Arc-length mean is a different averaging measure. Figures agree with these roles. |
| 04 | Completion of Example 3; Example 4 cauldron and Figure 4; disk volume; temperature weights; two averages and endpoint comparison | Arc mean 2/pi is correct. Cauldron V=pi/2, numerator 40pi, volume average 80 degrees C, height average 85 degrees C are correct. A genuine printed primitive typo is present: 500y^2 must be 50y^2. See below. |
| 05 | Explanation of lower volume-weighted temperature; dart model; Figure 5 sector geometry; part/whole ratio | Temperature interpretation is correct. Dart argument is valid as an isotropic planar density model, using weighted probability mass rather than unweighted area. The sector spans 60 degrees, radial limits 2r1 and 3r1; its angular fraction is 1/6. |
| 06 | Figure 6 annular weighting; brother-hit probability ratio; clock-angle factor; exponential warning; primitive; improper denominator; Figure 7; simplification | All algebra/integrals correct. Factor 2pi r is essential. Figure 7 is a qualitative half-Gaussian shape, not the radial density 2r exp(-r^2) nor the full denominator integrand. Its caption alone must not be used to identify radius as normally distributed. |
| 07 | General probability; half-board-hit assumption; exponential powers; approximation and per-throw conclusion | Exact probability is 31/3072, about 1.009114583%, so the reported approximately 1% per throw is sound. Dropping 1/512 is an approximation, not equality. Conditioning on a missed board gives a different probability. |
| 08 | Gaussian Q and Figure 8; volume under exp(-r^2); shell setup; finite R integration; limiting volume | Correct: r=sqrt(x^2+y^2), V_R=pi(1-exp(-R^2)), V=pi. The volume is under the radial surface over the entire plane. The claim that the full infinite integral is easier than finite endpoints is contextual; the proof supplies a closed full-domain answer without an elementary finite-endpoint primitive. |
| 09 | Figure 9 annulus; fixed-y slicing; V=integral A(y)dy; Figure 10 slice perspective | Correct thin-annulus and thin-slice limiting constructions. (2pi r)dr is differential area, not an exact finite-width ring area. A(y) is a vertical cross-sectional area, not the horizontal disk area. Perspective drawings are schematic. |
| 10 | Figure 11 top-view slice width; A(y) factorisation; exponential identity; constant extraction; Figure 12 side profile | Correct with y held fixed in the x integral: A(y)=exp(-y^2)Q. The two coordinates have distinct roles; no differentiation of y is involved. |
| 11 | V=Q^2; dummy-variable equality; positive square root; normalization; rescaling; normal distribution and sigma interpretation | Correct. Q>0 selects sqrt(pi), not a negative root. The displayed normalizing denominator is sigma sqrt(2pi), with sigma outside the radical; no normalization error is present. The exponent is -x^2/(2sigma^2). The distribution is specifically centred N(0,sigma^2). See finiteness and moment checks below. |

The lecture title includes “Work,” but this supplied PDF contains no worked work/force example or further work formula to verify. References to the preceding lecture are not permission to read it. All data needed for the cauldron and dart calculations are restated in D021.

## Calculations and conditions

### Averages and their measures

For h=(b-a)/n and right endpoints xi=a+ih, the average of sample values is

`(1/n) sum f(xi) = [1/(b-a)] sum f(xi) h -> [1/(b-a)] integral_a^b f(x) dx`.

This is uniform weighting in x. A general nonnegative integrable weight w, with positive finite integral, instead gives `integral f w / integral w`; it follows by normalizing the weighted sum. Negative weights do not in general define an ordinary average, and a zero total weight is not admissible.

For the upper unit semicircle, y=sqrt(1-x^2), horizontal width is 2 and area is pi/2, so its x-average is pi/4, approximately 0.7853981634. For constant f=53, numerator is 53(b-a), yielding 53. For uniform arc length on the upper unit circle, parameterize x=cos(theta), y=sin(theta), 0<=theta<=pi. Since circle arc length is s=R theta and R=1, ds=dtheta. The mean is integral_0^pi sin(theta)dtheta/pi=2/pi, approximately 0.6366197724. For radius R it becomes 2R/pi. The denominator is the relevant total measure: width 2 versus arc length pi.

### Cauldron

Interpret x,y as numerical coordinates in metres and the stated profile as y=x^2 with its implicit dimensional scale. At y in [0,1], radius sqrt(y), disk area w(y)=pi y and volume element dV=pi y dy. The top diameter is 2 m and height 1 m as drawn. Temperature T(y)=100-30y degrees C is constant across each horizontal slice.

`V=integral_0^1 pi y dy=pi/2 m^3`.

`integral_0^1 T(y)dV = pi integral_0^1 (100y-30y^2)dy = pi[50y^2-10y^3]_0^1 = 40pi`.

Dividing gives 80 degrees C. The printed `pi(500y^2-10y^3)` on physical page 04 is wrong: differentiating it gives pi(1000y-30y^2), a discrepancy of 900pi y from the intended integrand; evaluating it at 1 would give 490pi rather than 40pi. The image and extracted text both contain 500. Correct only this coefficient; the source's final results are already correct.

Uniform height weighting instead gives integral_0^1 (100-30y)dy=85 degrees C, equal to the average of the linear endpoint values 100 and 70. Normalizing the volume weight yields density 2y for a uniformly selected volume point; its mean height is 2/3, giving 100-30(2/3)=80. There is more volume at larger y, where T is lower. A mass or final mixed-equilibrium temperature would additionally need the appropriate density/heat-capacity assumptions; the source explicitly asks for a volume average, so no such extra assumption is needed for its stated result.

### Darts

The model is a nonnegative planar landing density proportional to exp(-r^2), r>=0, isotropic in angle. The exponential uses scaled coordinates: a physical dimensional version would use exp(-alpha r^2) with alpha>0 in inverse length squared. Normalization gives total integral c*2pi*(1/2)=c pi, hence c=1/pi when it is a probability density per unit area. The density of the radius is then 2r exp(-r^2), not c exp(-r^2).

The exact area of a ring from r to r+h is 2pi r h+pi h^2; its leading differential is 2pi r dr. Thus the brother's annular sector has weighted fraction

`P(B) = (1/6)*[integral_(2r1)^(3r1) c exp(-r^2) 2pi r dr]/[integral_0^infinity c exp(-r^2)2pi r dr]`.

The common positive c and 2pi cancel. The chain rule gives d(exp(-r^2))/dr=-2r exp(-r^2), hence

`integral_a^b r exp(-r^2)dr = (exp(-a^2)-exp(-b^2))/2`;

`integral_0^infinity r exp(-r^2)dr = lim_R [1-exp(-R^2)]/2 = 1/2`;

`P(B) = [exp(-4r1^2)-exp(-9r1^2)]/6`.

`exp(-r^2)` means exp(-(r^2)); it is not `(exp(-r))^2=exp(-2r)`. They agree at isolated radii r=0,2 but are different functions, so the source warning is appropriate.

Under the exact model calibration P(R<=r1)=1/2,

`1-exp(-r1^2)=1/2`, so `exp(-r1^2)=1/2` and `r1=sqrt(log 2)` approximately 0.8325546112 in the selected coordinate scale. Therefore

`P(B)=(2^-4-2^-9)/6=31/3072=0.0100911458333333`, or about 1.00911458333333% per throw.

The source first drops 2^-9=1/512, giving 1/96=1.0416666667%. This is an overestimate by 1/3072, or about 3.22580645% relative to the exact probability. Both round naturally to roughly 1%. “About half” in the physical assumption makes the exact calibration itself approximate. No empirical evidence about actual children or dart throwing is available in the closed input, so its real-world frequency claim is a modeling assumption/anecdote, not a verified measurement.

The concluding sentence explicitly says each dart thrown. If “stray dart” instead means a throw conditioned on missing the board, B is a subset of {R>r1}, and the conditional probability is `(31/3072)/(1/2)=31/1536`, about 2.0182291667%. Repeated-throw risks would require an additional independence/model assumption and are not claimed by the original.

### Gaussian volume calculation and standard deviation

Let `Q=integral_-infinity^infinity exp(-x^2)dx`. Positivity gives Q>0. Its finiteness can be justified before extracting it as a constant: for |x|>=1, exp(-x^2)<=exp(-|x|), whose tails have finite integrals; the middle finite interval contributes at most 2. Thus 0<Q<infinity. The original omits this convergence justification but has the correct result.

For the nonnegative surface z=exp(-(x^2+y^2)), define the volume under it. Shells of radius r, height exp(-r^2), thickness dr give

`V_R=integral_0^R 2pi r exp(-r^2)dr = pi[1-exp(-R^2)] -> pi`.

At fixed y, a vertical slice extends along x and z. Its area is

`A(y)=integral_-infinity^infinity exp(-(x^2+y^2))dx = exp(-y^2)Q`.

Integrating these areas over y yields `V=integral A(y)dy=Q integral exp(-y^2)dy=Q^2`. Renaming a bound variable does not change the integral. Since V=pi and Q>0, `Q=sqrt(pi)`. Shells and slices refer to the same solid. A rigorous measure-theoretic proof can use nonnegativity, but an elementary presentation can state and justify the slicing/limiting principle geometrically; the general Tonelli/Fubini theorem is not baseline knowledge and must not be silently required from this student.

For sigma>0, set `u=x/(sqrt(2)*sigma)` and `dx=sqrt(2)*sigma du`. Then

`integral exp[-x^2/(2sigma^2)]dx = sqrt(2)*sigma*sqrt(pi)`,

so the normalized density is `exp[-x^2/(2sigma^2)]/(sigma sqrt(2pi))`. It has mean zero by odd symmetry with finite absolute first moment. To verify the source's standard-deviation claim rather than only its normalization, integration by parts gives

`integral_-infinity^infinity u^2 exp(-u^2)du = [-u exp(-u^2)/2]_-infinity^infinity + Q/2 = Q/2`.

The boundary term vanishes. After the same rescaling, the second moment is `2sigma^2*(Q/2)/Q=sigma^2`, so the positive standard deviation is sigma. The density is N(0,sigma^2), a centred normal distribution. The page image has sigma outside the square-root radical; any text-extraction ambiguity here is not a source error.

## Full baseline relevance and boundaries

The original-only review read all four subject sections; the following mapping identifies actual usable premises rather than equating exposure with observed mastery.

| Baseline section | Relevant supplied premises | Limits retained |
|---|---|---|
| Mathematics (heading byte 2093) | Arithmetic means and frequency-weighted means; geometry of circles, sectors and standard solids; unit-circle parameterization, radians and s=r theta; exponentials/logarithms; chain rule; definite integrals as rectangle-sum limits; substitution and integration by parts; conditional probability; normal model and standardization | H240 alone does not grant density integration, normal density formula, multiple integrals, work/energy/power, general expectation or formal analysis. Combined baseline fills several of these specific gaps. |
| Further Mathematics (heading byte 50677) | FM28 improper endpoints by limits; FM30 disk/washer volumes and integral average; FM31 polar coordinates and sector area; FM38 weighted expectation; FM42 continuous density and normalization; FM43 moments and transformation via CDF; FM44 uniform/exponential/normal densities; FM57 dimensional consistency; FM58 work integrals; FM63 cross-section-weighted centres; FM64 arc centroid 2R/pi as the semicircle case | No arbitrary multivariable density integrals, general Jacobian change-of-variables formula, or general multiple-integral/Tonelli/Fubini formalism. Shell and slice constructions should be supplied or derived geometrically, as the original attempts. |
| Physics (heading byte 90025) | Dimensions and units, circle/cylinder geometry, graphical area and rate reasoning, density m/V, work/energy, thermal Q=mc Delta T, Celsius/Kelvin intervals, average versus rms quantities and probability-model judgment | Thermal equilibrium or mass-weighted temperature is not interchangeable with the requested volume-weighted average without assumptions. Qualitative Maxwell-Boltzmann exposure does not independently grant a planar Gaussian/radial density rule. |
| Chemistry (heading byte 150631) | CH01 abundance-weighted means and normalization of weights; temperature/unit handling; CH04 qualitative distribution area and model assumptions; CH06 heat/temperature distinction; CH10 integrated peak area versus height; CH11 mean/uncertainty/context interpretation | No extra statistical-mechanics density formula, microstate weighting, general probability calculus, or temperature averaging law is supplied by chemical topic names. Relevant formal probability comes from the Mathematics/Further Mathematics sections. |

All remaining baseline content was read, including its four-subject combination rules, excluded options/formalisms, reference availability, practical competence caveats and full Chemistry references. Those references were not opened. This review does not independently re-audit every baseline assertion or the contemporary OCR specifications; it treats the supplied baseline as the authorized operational starting-knowledge record. No outside curriculum claim is needed for the D021 mathematics.

## Findings, limitations and subsequent boundary

One concrete printed algebra error was confirmed: 500y^2 should be 50y^2 on physical page 04. All final numerical/closed-form mathematical answers in the original are correct under the stated model and the explicit conditions above. Significant interpretation requirements are the averaging measure, area versus radial density, per-throw versus conditional probability, exact versus rounded calibration, positivity/finiteness in the Gaussian proof, and the geometric limiting meaning of thin shells/slices.

Figures were inspected at the supplied whole-page resolution. They are adequate to read their labels and identify their mathematical roles, but are schematic and must not be treated as precise scale diagrams or empirical data. No linked source or preceding lecture was consulted. No current teaching quality, prompt sufficiency, student success, assessment coverage or PROF compliance verdict is made at this original-only stage.

`calculations.py` supplies reproducible rational and numerical cross-checks. Its numerical quadrature corroborates the analytic derivations here; it does not replace them. An attempted optional SymPy import was unavailable; no package was installed, and all completed checks use the Python standard library.

Future work must load the then-current complete published PROF and final prompt-only packet, independently solve that packet under its actual allowed premises, and seal that new stage before frozen new teaching is viewed. This original-only seal remains an immutable record of what was known before those later inputs.
