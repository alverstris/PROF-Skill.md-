# D022 — permitted baseline read and relevance map

The entire 247,840-byte UTF-8 baseline was displayed and read in contiguous byte ranges [0,30000), [30000,60000), [60000,90000), [90000,120000), [120000,150000), [150000,180000), [180000,210000), [210000,240000), [240000,247840). All cuts decoded successfully. These ranges cover every actual byte, including the cover, all four subject sections, and the chemistry reference tail. Per-range hashes and section-heading offsets are retained in `ACCESS_AND_COVERAGE.json`.

This was a full operational read, not a keyword search or an inferred catalogue. The following is a relevance map; it does not replace the full baseline and must not be substituted for it in future stages.

| Subject | Actual read scope | Direct relevance or boundary for D022 |
|---|---|---|
| Mathematics A H240 | Complete section, including arithmetic/proof, algebra/functions, sequences/series, trig, logs, differentiation/integration, numerical methods, vectors, statistics and mechanics, and exclusions | Fractions, sums and indices; trapezium area; uniform trapezoid formula; rectangle-sum interpretation; definite integral as signed quantity; FTC; polynomial integration; derivative rules and concavity; graph interpretation; principal arctan values; actual listed conditions on numerical methods. Simpson is expressly not supplied by H240. |
| Further Mathematics A H245, Pure Core plus Y542 and Y543 | All FM01–FM71, including complex quantities, matrices, vectors, expansions, inverse-function calculus, ODEs, statistics and mechanics | FM29 explicitly supplies the arctan derivative/integral required for the exact source example. FM23 sums and FM27 series are available with their stated limitations. General remainder theorems and convergence proofs are not automatically supplied. The selected options do not implicitly introduce Simpson’s rule. |
| Physics A H556 | Complete reference data and sections 1–8, through final limits | Units, graph area, strips/trapezia, approximation/model conditions, signed quantities and meaningful numerical precision can transfer. It supplies no Simpson weights or universal quadrature error law. |
| Chemistry A H432 | CH-META, CH-00 through CH-12 and CH-REF, including the complete organic/practical content | Graph area and integrated detector response, arithmetic/precision, model assumptions, and distinguishing empirical data from inference can transfer. No new quadrature theorem follows from this content. |

The combined baseline already permits most of the trapezoidal material. A legitimate new mathematical bridge for this lecture is the three-node quadratic fit and its integrated weights, followed by the alternating composite coefficients. Any claim of an explicit error bound must carry its assumptions or a derivation; merely knowing Maclaurin coefficients does not automatically grant an unprovided remainder theorem.

The original worked example is fully solvable with the source and actual baseline: the source supplies Simpson’s formula, Mathematics supplies uniform grids/trapezia and FTC, and FM29 supplies the exact primitive. The incorrect printed parentheses are a source defect, not a missing student prerequisite.

No inference of personal mastery, retention, speed, or diagnostic performance is made from the declared course completion. No unseen reference table, external source link, current PROF requirement, prior trial, author history, or new teaching was used to supply subject premises.
