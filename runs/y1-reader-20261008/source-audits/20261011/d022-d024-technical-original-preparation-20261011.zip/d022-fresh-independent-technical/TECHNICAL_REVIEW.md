# D022 — independent original-only technical review

**Phase:** prepared before any current PROF, future assessment packet, or new teaching was read. This is a reviewer record, not student teaching. The separation is an instruction boundary, not technical access isolation.

**Original:** MIT 18.01 Fall 2006, Lecture 24, *Numerical Integration*. Six physical PDF pages: OCW cover plus lecture pages 1–5. PDF SHA-256 `fb4de992b596cd707e31529a24fbe2bb2258a43e76ff5d7ce7e122b5b9c8d3da` (1,182,500 bytes). Complete allowed baseline SHA-256 `3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5` (247,840 bytes). Exact hashes for every original PNG, text file, identity file, and baseline are in `INPUT_HASHES.sha256` and `ACCESS_AND_COVERAGE.json`.

## Technical disposition

The quadrature definitions, composite coefficients, constant-function check, tabulated function values, trapezoidal result, Simpson final result, and exact integral are correct. One genuine printed mathematical error occurs in the Simpson substitution on physical page 6 / lecture page 5: its inner parentheses multiply the final endpoint by 4. Its displayed final decimal corresponds to the correct quadrature formula, not to the printed middle expression. The page-6 crop preserves the direct visual evidence.

Two qualifications matter: the opening phrase “no formula” is broader than “no elementary antiderivative”; and the fourth-order error assertion needs a smooth integrand, a fixed interval, an even uniform refinement sequence, and an interpretation as an upper-order estimate. It does not assert a guaranteed factor of 16 or an exact fourth-order asymptotic error for every integrand. No blanket superiority of Simpson over the trapezoidal rule follows from “often.”

## Page-by-page complete claim and figure coverage

Every whole supplied PNG was viewed at original detail, including margins, headings, figures, captions, mathematical displays and footer; every byte of all six extracted text files was read. Page 6 was additionally extracted directly from the PDF and its Simpson equation was rendered larger for inspection. Text extraction alone does not preserve the erroneous parentheses reliably.

| Physical / lecture page | Claim, example or object | Independent check and disposition |
|---|---|---|
| 1 / cover | MIT OCW, course 18.01 Single Variable Calculus, Fall 2006, citation/terms links | Visual and literal metadata agree with the assigned identity. Provenance links were not opened. No mathematical claim occurs on this page. |
| 2 / 1 | Numerical integration for difficult definite integrals | Correct practical description when numerical evaluation is sought. An approximation needs an accuracy criterion; the original supplies no general tolerance procedure. |
| 2 / 1 | Integrals without elementary antiderivatives; displayed integral of cos(t²) from 0 to x and exp(−x²) from 0 to 3 | The intended distinction is elementary antiderivatives versus numerical values. The stronger literal assertion that there is “no formula” is not justified. Neither the lecture nor baseline proves non-elementarity; this review does not claim an elementary proof of that negative theorem. Existence of a definite integral is not in doubt: both integrands are continuous. |
| 2 / 1 | Numerical integration yields numbers rather than analytical expressions | Appropriate for a fixed pair of limits and fixed data; at a variable upper limit it evaluates the function at chosen inputs rather than producing a general elementary primitive. Numerical outputs are generally approximations. |
| 2 / 1 | Three listed methods | Riemann sums, trapezoidal rule, Simpson’s rule are the methods actually developed. No omitted method is asserted as part of this lecture. |
| 2 / 1 | Figure 1, rectangles using left endpoints | Read as a schematic over equal-width cells. Each cell uses its left sampled height; there are n cells and n+1 endpoints. The curve increases and decreases, so the picture supplies no single global under/overestimate. The formula excludes y_n. |
| 2 / 1 | x_i−x_(i−1)=Δx, ordered a=x_0<…<x_n=b, y_i=f(x_i) | Correct with a<b and integer n≥1; summing widths gives h=Δx=(b−a)/n. L_n=h∑_(i=0)^(n−1)y_i. These conditions and index distinctions are already accessible from the baseline. |
| 3 / 2 | Trapezoid area = perpendicular separation times average of parallel sides | Correct. In Figure 2 the parallel sides are vertical lengths y_3,y_4 and the perpendicular separation is horizontal h. The word “height” refers to that separation, not either ordinate. |
| 3 / 2 | Figure 2 and its caption h(y_3+y_4)/2 | Formula and visual agree. A signed-integral reading extends the algebra beyond the positive-height illustration; unsigned geometric area needs separate care at sign changes. |
| 3 / 2 | Figure 3, chord segments and trapezoidal sum | Adjacent samples joined by straight chords; four drawn intervals are illustrative. Shared interior sample ordinates belong to two neighboring trapezoids. |
| 3 / 2 | Expanded trapezoid sum and collapsed endpoint-half-weight formula | Verified by collecting terms: T_n=h[y_0/2+∑_(i=1)^(n−1)y_i+y_n/2]. No missing factor of 2. |
| 4 / 3 | T_n gives symmetric endpoint treatment and is average of left/right sums | Verified algebraically: (L_n+R_n)/2=T_n for the same uniform partition. Both endpoints receive half weight. The “than a Riemann sum” comparison is specifically to an endpoint choice; arbitrary Riemann sums need not be asymmetric. |
| 4 / 3 | Simpson often more accurate | Reasonable qualified statement for sufficiently smooth problems/refinement; not a universal ranking. A positive polynomial counterexample to a universal ranking is recorded below. |
| 4 / 3 | Fit a quadratic rather than lines | Three distinct equally spaced sampled points determine a unique polynomial of degree at most 2. A degenerate fit can be a straight line or constant, so “parabolas” is ordinary shorthand. The quadratic is an interpolant, not necessarily the original function. |
| 4 / 3 | Even number of intervals required | Correct for this composite Simpson 1/3 construction: each panel consumes two equal-width intervals. n≥2 even. This restriction is not a claim about every quadrature called Simpson. |
| 4 / 3 | Figure 4, x_0,x_1,x_2 separated by h; y_0,y_1,y_2 | Correct schematic role of the two cells and three samples. y_1 is the midpoint ordinate; it need not be the vertex/minimum of an arbitrary interpolating quadratic. |
| 4 / 3 | Panel area (2h)(y_0+4y_1+y_2)/6 | Verified by integrating the three Lagrange basis polynomials; it is exact for the interpolant, and hence for a quadratic original. It is an approximation for a general f. |
| 4 / 3 | Composite sum of triples | Each panel has h/3 times (left+4 middle+right); panels share endpoints. Summing creates weights 1,4,2,4,…,2,4,1. |
| 4 / 3 | Staggered coefficient diagram | Three triples 1,4,1 sum to the displayed seven coefficients 1,4,2,4,2,4,1, for six intervals. All shared contributions accounted for. |
| 5 / 4 | Figure 5, four intervals and two chunks | First panel uses nodes 0,1,2; second uses 2,3,4. The common node 2 has two endpoint contributions. The drawn curves are schematic; separate quadratic pieces need only agree in value at the shared endpoint. |
| 5 / 4 | Composite Simpson display | Correct reading is S_n=(h/3)[y_0+y_n+4∑ odd interior y_i+2∑ even interior y_i]. The ellipsis denotes this index pattern; small n requires the corresponding sums, not duplicating symbols visible on both sides of the ellipsis. |
| 5 / 4 | Weight sums 6,12,18 | Correct for n=2,4,6. Exact integer checks in the calculation record also cover other even n. |
| 5 / 4 | f=1 check gives nh | Correct: 2+4(n/2)+2(n/2−1)=3n, multiplied by h/3 gives nh=b−a. Necessary normalization check, not alone a proof of general accuracy. |
| 6 / 5 | Example ∫_0^1 1/(1+x²) dx with two subintervals | h=1/2; n=2 follows from the diagram and table. Smooth positive integrand. Exactly solved below. |
| 6 / 5 | Figure 6 | It identifies the positive area on [0,1], midpoint split, and two equal widths. The curve is schematic and not a reliable plot for reading the 1,4/5,1/2 heights or inflection position; use the formula/table. |
| 6 / 5 | Table x=0,1/2,1 and y=1,4/5,1/2 | All values verified by exact substitution. |
| 6 / 5 | Trapezoidal computation 0.775 | Every printed arithmetic step agrees with T_2=31/40. |
| 6 / 5 | Simpson general formula and final decimal 0.78333… | Correct S_2=47/60. |
| 6 / 5 | Simpson middle substitution | **Incorrect as printed:** (1/6)[1+4(4/5+1/2)]=31/30, not 47/60. Correct substitution is (1/6)[1+4(4/5)+1/2]. The difference is exactly 1/4. |
| 6 / 5 | Exact primitive arctan x and π/4≈0.785 | Correct. FM29 supplies (arctan x)'=1/(1+x²), Mathematics supplies principal inverse trig values and FTC. Difference of endpoints is π/4, approximately 0.7853981633974483. |
| 6 / 5 | “Roughly speaking” Simpson error has order h⁴ | A correct standard bound for f∈C⁴ on the fixed closed interval is |I−S_n|≤(b−a)M_4 h⁴/180, derived below. The original does not state these hypotheses or constant. A literal exact h⁴ rate for this particular example is stronger than warranted; its refinements show much faster error decay. |

## Independent solution of the original example

Let h=1/2 and (y_0,y_1,y_2)=(1,4/5,1/2).

- L_2=(1/2)(1+4/5)=9/10; R_2=(1/2)(4/5+1/2)=13/20.
- T_2=(L_2+R_2)/2=31/40=0.775.
- S_2=(1/6)(1+16/5+1/2)=47/60=0.7833333333….
- I=[arctan x]_0^1=π/4=0.7853981633974483096….
- T_2−I≈−0.01039816339744831; S_2−I≈−0.002064830064114976.
- Both values underestimate this particular integral. Simpson is closer by absolute error. S_2−T_2=1/120 exactly. These directions follow the exact calculation, not a blanket curvature argument.
- The printed middle expression equals 31/30≈1.0333333333, exactly 1/4 greater than the correct Simpson estimate.

f′=−2x/(1+x²)²≤0 on [0,1], which independently establishes R_2≤I≤L_2. However, f″=(6x²−2)/(1+x²)³ changes sign at 1/√3, so a single global concavity shortcut cannot prove the trapezoidal direction. Likewise f⁽⁴⁾=24(5x⁴−10x²+1)/(1+x²)⁵ changes sign inside the interval (at √(1−2/√5)), so the fourth-derivative sign rule cannot settle the Simpson direction globally.

## Independent derivations and conditions

### Simpson weights and polynomial exactness

Use t=(x−x_1)/h on [−1,1]. The interpolant is

q(t)=y_0 t(t−1)/2+y_1(1−t²)+y_2 t(t+1)/2.

The three basis integrals are 1/3,4/3,1/3; dx=h dt gives h(y_0+4y_1+y_2)/3. Integrating an arbitrary cubic instead of its quadratic interpolant adds only an odd multiple of t(t²−1), whose integral and node samples vanish. Hence Simpson is exact through degree 3, although the source only motivates the degree-2 fit. The exact rational moment checks confirm degrees 0,1,2,3 and show failure at degree 4: on [−1,1], I(t⁴)=2/5 while S(t⁴)=2/3. Degree 5 is odd and happens to integrate exactly on this symmetric interval; that does not make the degree of exactness 5.

### Fourth-order bound, derived rather than assumed as baseline knowledge

Assume f has a continuous fourth derivative on a panel [c−h,c+h]. Four successive uses of the fundamental theorem give the integral remainder from the left endpoint. Since E(f)=I(f)−S(f) kills every cubic, only the remainder contributes. For h=1, c=0 its kernel is

K(u)=−(1−|u|)³(1+3|u|)/72, −1≤u≤1.

For u≥0 this follows directly by applying E to (t−u)_+³/6:

K(u)=(1−u)⁴/24−(1−u)³/18=−(1−u)³(1+3u)/72;

for u≤0 the extra midpoint term is −4(−u)³/18, which simplifies to the reflected formula. K≤0 and ∫K=−1/90 (the latter is also checked exactly). Rescaling gives ∫|K_h|=h⁵/90. Thus a panel error is bounded by M_4 h⁵/90. There are (b−a)/(2h) panels, so

|I−S_n|≤(b−a)M_4 h⁴/180.

This is a reviewer derivation from calculus, not a claim that the source or baseline explicitly teaches a remainder theorem. It supplies the necessary conditions for the source’s rough statement. If f⁽⁴⁾ has one sign, the kernel also establishes the opposite sign for I−S. An unqualified error statement for nonsmooth/discontinuous integrands or nonuniform samples is unsupported by this derivation.

### Refinement does not promise a universal ratio

For the original integrand the independently computed |S_n−π/4| values are approximately:

| n | h | Absolute Simpson error |
|---:|---:|---:|
| 2 | 1/2 | 2.0648300641×10⁻³ |
| 4 | 1/4 | 6.0065347032×10⁻⁶ |
| 8 | 1/8 | 3.7782771581×10⁻⁸ |
| 16 | 1/16 | 5.9124276218×10⁻¹⁰ |
| 32 | 1/32 | 9.2392397675×10⁻¹² |
| 64 | 1/64 | 1.4436416856×10⁻¹³ |
| 128 | 1/128 | 2.2556911565×10⁻¹⁵ |

Successive ratios approach 64 in this calculation, not 16. This is numerical evidence of special cancellation; no unproved sixth-order theorem is needed to conclude that an exact 16-fold promise would be inappropriate. f‴(0)=f‴(1)=0 is independently verified and relevant to that cancellation, but an Euler–Maclaurin theorem is not imported as baseline knowledge.

For an explicit check that Simpson is not always closer at a fixed grid, f(x)=1+x⁴−(9/5)x² on [−1,1] is positive (minimum 19/100). With n=2, I=T=6/5 whereas S=22/15, so Simpson’s error is 4/15. This does not contradict the original’s qualified word “often.”

### Numerical constants and reproducibility

`calculations.py` uses exact `Fraction` arithmetic for weights, polynomial moments, original sample values, all quadrature sums, the erroneous expression, derivative numerators and the kernel integral. It uses 90-digit Decimal arithmetic only when comparing to π/4. π is independently computed by 16 arctan(1/5)−4 arctan(1/239), with each small arctangent obtained from its alternating power series and an omitted term below 10⁻⁸⁰.

This numerical route need not invoke an external π lookup: the finite geometric expansion of 1/(1+t²), integrated with its bounded remainder, establishes the small arctangent series. The baseline tangent-addition formula gives tan(2a)=5/12 and tan(4a)=120/119 for a=arctan(1/5), then tan(4a−arctan(1/239))=1 on the correct principal branch, establishing the Machin identity. The tested output is saved in `calculations.json`.

## Explicit limitations

1. “No elementary antiderivative” for the two motivating functions is not proved from the permitted elementary input set. The review identifies the broader “no formula” wording as unsuitable and does not conceal the proof limitation.
2. The complete baseline was actually read, but its external OCR provenance/current-release claims were not re-researched; that would violate this original-only phase. The baseline is a declared competence assumption, not measured student mastery.
3. Page drawings are schematic and not numerical graph data. Exact values and sign conclusions above come from formulae and calculations.
4. The source is internally identified and hashed; its website was not revisited or independently authenticated.
5. No future prompt, full current PROF, newly authored teaching, solutions, or other corpus material has been read or evaluated. This packet makes no claim about an assessment that has not yet been supplied.
