#!/usr/bin/env python3
"""D022 original-only exact checks. Python standard library only; no retrieval."""
from fractions import Fraction as F
from decimal import Decimal, localcontext
import json

def text(x):
    if isinstance(x,F): return str(x)
    return x

def dec(x): return Decimal(x.numerator)/Decimal(x.denominator)
def poly_integral(coeff, a, b):
    return sum((F(c,i+1)*(F(b)**(i+1)-F(a)**(i+1)) for i,c in enumerate(coeff)),F(0))
def weighted(coeff, points, weights):
    return sum((w*sum((F(c)*x**i for i,c in enumerate(coeff)),F(0)) for x,w in zip(points,weights)),F(0))
def diff_numerator(p,k):
    d=[(i+1)*p[i+1] for i in range(len(p)-1)]
    out=[0]*(len(p)+1)
    for i,c in enumerate(d):out[i]+=c;out[i+2]+=c
    for i,c in enumerate(p):out[i+1]-=2*(k+1)*c
    while len(out)>1 and out[-1]==0:out.pop()
    return out

def arctan_small(x):
    total=Decimal(0);power=x;n=0;sign=1
    while True:
        term=power/Decimal(2*n+1)
        if abs(term)<Decimal('1e-80'):break
        total+=term*sign;power*=x*x;sign=-sign;n+=1
    return total

with localcontext() as ctx:
    ctx.prec=90
    pi=16*arctan_small(Decimal(1)/5)-4*arctan_small(Decimal(1)/239)
    I=pi/4
    lagrange=[poly_integral([0,F(-1,2),F(1,2)],-1,1),poly_integral([1,0,-1],-1,1),poly_integral([0,F(1,2),F(1,2)],-1,1)]
    assert lagrange==[F(1,3),F(4,3),F(1,3)]
    moments=[]
    for k in range(6):
        p=[0]*k+[1]
        exact=poly_integral(p,-1,1)
        approx=weighted(p,[F(-1),F(0),F(1)],lagrange)
        moments.append({'degree':k,'integral':text(exact),'Simpson':text(approx),'I_minus_S':text(exact-approx)})
        if k<=3:assert exact==approx
    sums=[]
    for n in [2,4,6,8,10,100]:
        w=[1]+[4 if k%2 else 2 for k in range(1,n)]+[1]
        assert sum(w)==3*n
        sums.append({'n':n,'weight_sum':sum(w),'expected':3*n})
    table=[];previous=None
    for n in [2,4,8,16,32,64,128]:
        h=F(1,n);y=[1/(1+(i*h)**2) for i in range(n+1)]
        L=h*sum(y[:-1]);R=h*sum(y[1:]);T=h*(y[0]/2+sum(y[1:-1])+y[-1]/2)
        S=h*sum((1 if i in (0,n) else 4 if i%2 else 2)*v for i,v in enumerate(y))/3
        assert T==(L+R)/2
        errorS=dec(S)-I;errorT=dec(T)-I
        row={'n':n,'h':str(h),'T_decimal':str(dec(T)),'S_decimal':str(dec(S)), 'T_minus_I':str(errorT),'S_minus_I':str(errorS)}
        if n==2:
            assert T==F(31,40) and S==F(47,60)
            row.update({'y_exact':list(map(str,y)),'L_exact':str(L),'R_exact':str(R),'T_exact':str(T),'S_exact':str(S),'S_minus_T_exact':str(S-T)})
        if previous is not None:row['previous_abs_S_error_over_current']=str(abs(previous/errorS))
        previous=errorS;table.append(row)
    printed=F(1,6)*(1+4*(F(4,5)+F(1,2)))
    assert printed==F(31,30)
    corrected=F(1,6)*(1+4*F(4,5)+F(1,2))
    assert corrected==F(47,60) and printed-corrected==F(1,4)
    p=[1];derivatives=[]
    for k in range(1,6):
        p=diff_numerator(p,k-1)
        derivatives.append({'order':k,'numerator_coefficients_ascending':p[:], 'denominator':'(1+x^2)^'+str(k+1),'at_zero':str(F(p[0])),'at_one':str(F(sum(p),2**(k+1)))})
    assert derivatives[1]['numerator_coefficients_ascending']==[-2,0,6]
    assert derivatives[3]['numerator_coefficients_ascending']==[24,0,-240,0,120]
    assert derivatives[4]['at_one']=='15'
    # K(u) for unit half-panel, u in [0,1], is -(1-u)^3(1+3u)/72.
    kernel=[F(-1,72),0,F(1,12),F(-1,9),F(1,24)]
    kernel_mass=2*poly_integral(kernel,0,1)
    assert kernel_mass==F(-1,90)
    # Positive polynomial counterexample to any universal ranking of rules.
    cf=[1,0,F(-9,5),0,1]
    ce=poly_integral(cf,-1,1)
    ct=weighted(cf,[F(-1),F(0),F(1)],[F(1,2),F(1),F(1,2)])
    cs=weighted(cf,[F(-1),F(0),F(1)],lagrange)
    assert ce==ct==F(6,5) and cs==F(22,15)
    data={'precision':90,'pi_construction':'Machin identity 16 arctan(1/5)-4 arctan(1/239); alternating power series, each omitted term < 1e-80','I_pi_over_4':str(I),'lagrange_integral_weights':list(map(str,lagrange)),'polynomial_exactness':moments,'weight_sums':sums,'refinement':table,'printed_middle_expression':str(printed),'corrected_middle_expression':str(corrected),'printed_minus_corrected':str(printed-corrected),'derivatives':derivatives,'Peano_kernel_unit_mass':str(kernel_mass),'non_universal_ranking_counterexample':{'f':'1+x^4-(9/5)x^2 on [-1,1], n=2','I':str(ce),'T':str(ct),'S':str(cs),'S_minus_I':str(cs-ce)}}
print(json.dumps(data,indent=2))
