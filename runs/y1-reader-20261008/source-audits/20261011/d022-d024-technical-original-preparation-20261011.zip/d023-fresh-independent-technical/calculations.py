"""D023 original-only arithmetic checks; not a student assessment or answer key.

The derivations are in technical-review.txt. This file uses only the Python
standard library and reads no source, other-corpus or network data. Synthetic
checks are verification examples and are not questions from the original.
"""
import json
import math
from fractions import Fraction as Q
from pathlib import Path

checks = []


def near(name, actual, expected, scope, tolerance=1e-10):
    residual = abs(actual-expected)
    assert residual <= tolerance, (name, actual, expected, residual)
    checks.append({'name':name, 'actual':actual, 'expected':expected,
                   'absolute_residual':residual, 'absolute_tolerance':tolerance,
                   'pass':True, 'scope':scope})


def exact(name, actual, expected, scope):
    assert actual == expected, (name,actual,expected)
    checks.append({'name':name, 'actual':str(actual), 'expected':str(expected),
                   'pass':True, 'scope':scope, 'arithmetic':'exact rational'})


def midpoint(f, left, right, n=20000):
    width=(right-left)/n
    return width*math.fsum(f(left+(j+0.5)*width) for j in range(n))


m, g, L = 2.0, 9.81, 1.7
for theta in [0,math.pi/6,math.pi/3,math.pi/2,-math.pi/3]:
    tangent=(math.cos(theta),math.sin(theta))
    near('positive tangent norm at '+str(theta),sum(v*v for v in tangent),1.0,
         'theta radians, positive tangent toward increasing theta')
    near('gravity tangent projection at '+str(theta),-m*g*tangent[1],
         -m*g*math.sin(theta),'signed force component, not downhill magnitude')

for theta0 in [0,math.pi/6,math.pi/3,math.pi/2,math.pi,-math.pi/3]:
    expected=m*g*L*(1-math.cos(theta0))
    signed=midpoint(lambda theta:-m*g*L*math.sin(theta),theta0,0)
    lecture=midpoint(lambda theta:m*g*L*math.sin(theta),0,theta0)
    near('oriented integral at '+str(theta0),signed,expected,
         'independent midpoint integration of signed tangential force; geometric prescribed arc',1e-7)
    near('lecture integral at '+str(theta0),lecture,expected,
         'reversed limits and reversed force sign',1e-7)
    r_initial=(L*math.sin(theta0),-L*math.cos(theta0))
    r_final=(0,-L)
    near('constant-force endpoint dot product at '+str(theta0),
         -m*g*(r_final[1]-r_initial[1]),expected,
         'constant Cartesian gravity from baseline FM58')
    near('closed out-and-back gravity work at '+str(theta0),
         signed+midpoint(lambda theta:-m*g*L*math.sin(theta),0,theta0),0,
         'gravity only; no extraction of net energy from a closed gravity cycle',1e-7)

for theta0, factor in [(0,0),(math.pi/3,0.5),(math.pi/2,1),(math.pi,2)]:
    near('normalised endpoint work at '+str(theta0),1-math.cos(theta0),factor,
         'pi case is an endpoint geometry check, not release from exact upright rest')

for theta0 in [0,math.pi/3,math.pi/2,2*math.pi/3]:
    initial_tension=m*g*(3*math.cos(theta0)-2*math.cos(theta0))
    near('initial taut-string tension at '+str(theta0),initial_tension,m*g*math.cos(theta0),
         'release-from-rest diagnostic; negative value cannot be sustained by a string')
assert m*g*math.cos(2*math.pi/3)<0

# The FTC witness f(t)=t, a=0 has F(x)=x^2/2 and F'(x)=x.
# t is a bound dummy symbol, and it cannot appear free on the result's RHS.
F=lambda z:z*z/2
point,step=Q(2),Q(1,1000)
exact('FTC corrected derivative witness at x=2',
      (F(point+step)-F(point-step))/(2*step),point,
      'exact symmetric difference quotient for F(x)=x^2/2 is x; source prints f(t) instead')
assert Q(2) != Q(7)
checks.append({'name':'FTC printed right-side symbol witness', 'pass':True,
               'scope':'x and an independently assigned dummy-name t cannot be equated: 2 != 7; '
                       'the mathematical error is free t on the source RHS, not an approximation error'})

# Exact one-dimensional polynomial integration and panel rules.
def mono_integral(power,left,right):
    return (right**(power+1)-left**(power+1))/Q(power+1)

for power in range(4):
    f=lambda z:z**power
    estimate=(f(Q(-1))+4*f(Q(0))+f(Q(1)))/3
    exact('Simpson panel monomial degree '+str(power),estimate,mono_integral(power,Q(-1),Q(1)),
          'derived panel rule on [-1,1]; source supplies the name only, not coefficients')
f=lambda z:z**4
exact('Simpson quartic nonexactness witness',
      (f(Q(-1))+4*f(Q(0))+f(Q(1)))/3-mono_integral(4,Q(-1),Q(1)),Q(4,15),
      'demonstrates approximation, not a general exact identity')
for power in [0,1]:
    f=lambda z:z**power
    exact('trapezoid exact monomial degree '+str(power),f(Q(-1))+f(Q(1)),
          mono_integral(power,Q(-1),Q(1)),'one panel of width two')
exact('trapezoid quadratic overestimate',Q(2)-mono_integral(2,Q(-1),Q(1)),Q(4,3),
      'convex x^2 test on [-1,1]')

radius, height, delta=Q(3),Q(5),Q(1,100)
exact('annular shell expansion without common pi factor',
      ((radius+delta)**2-radius**2)*height,
      2*radius*height*delta+height*delta**2,
      'division by delta and delta->0 yields 2*r*H, then multiply by pi')
exact('shell recovery of cylinder without common pi factor',
      2*height*mono_integral(1,Q(0),radius),height*radius**2,
      'synthetic nonoverlapping full revolution check')
exact('washer area without common pi factor',Q(5)**2-Q(2)**2,Q(21),
      'outer radius 5 >= inner radius 2 >= 0')

result={'material_id':'D023',
        'premise_scope':'original D023 plus complete supplied four-subject baseline',
        'not_a_student_trial':True,'checks_passed':len(checks),'checks':checks,
        'limits':'Numerical quadrature corroborates the analytic derivation in technical-review.txt; '
                 'it does not prove arbitrary-angle identities. Exact polynomial checks use rational arithmetic.'}
out=Path(__file__).with_name('calculations-results.json')
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks_passed':len(checks),'output':str(out)},indent=2))
