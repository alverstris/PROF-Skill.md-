"""Arithmetic corroboration for D024; uses no external subject-content input.

Analytic proofs and domains are in technical-review.md. Finite numerical tests
are deliberately labelled corroboration, rather than universal proofs.
"""
from fractions import Fraction as Q
from math import sin, cos, tan, asin, sqrt, log, pi, isclose
from pathlib import Path
import json

OUT = Path(__file__).resolve().parent
results = {
    "scope": "Original D024 equations only; no current/future assessment inputs",
    "exact_rational_identity_checks": [],
    "numerical_derivative_checks": [],
    "source_counterexamples": [],
    "area_checks": [],
}


def exact(label, left, right):
    assert left == right, (label, left, right)
    results["exact_rational_identity_checks"].append(
        {"claim": label, "left": str(left), "right": str(right), "pass": True}
    )


s, c = Q(3, 5), Q(4, 5)
t, z = s / c, 1 / c
c2, c4 = c*c - s*s, 2*(c*c - s*s)**2 - 1
exact("Pythagorean identity", s*s + c*c, Q(1))
exact("Example 1 rewritten integrand", (1-c*c)*c*c*s, s**3*c*c)
exact("Example 1 corrected primitive derivative", c*c*s-c**4*s, s**3*c*c)
exact("Example 2 primitive derivative", c*(1-s*s), c**3)
exact("Cosine-square primitive derivative", (1+c2)/2, c*c)
exact("Sine-square primitive derivative", (1-c2)/2, s*s)
exact("Example 3 first reduction", Q(1,4)-c2*c2/4, s*s*c*c)
exact("Example 3 primitive derivative", (1-c4)/8, s*s*c*c)
exact("Example 3 shortcut", (2*s*c)**2/4, s*s*c*c)
exact("Secant Pythagorean identity", 1+t*t, z*z)
exact("Secant^4 primitive derivative", z*z*(1+t*t), z**4)
exact("Tangent^3 secant primitive derivative", z*t*(z*z-1), t**3*z)
exact("Secant multiplier denominator nonzero product", (z+t)*(z-t), Q(1))
exact("Correct secant logarithmic derivative", (z*z+z*t)/(z+t), z)


def numerical(label, x, obtained, expected):
    err = abs(obtained-expected)
    assert isclose(obtained, expected, rel_tol=2e-12, abs_tol=2e-12), (
        label, x, obtained, expected
    )
    results["numerical_derivative_checks"].append(
        {"claim": label, "x_radians": x, "analytic_derivative_evaluated": obtained,
         "integrand": expected, "absolute_residual": err, "pass": True}
    )


# Positive- and negative-cosine intervals; no sample at a trigonometric pole.
for x in [-3.2, -2.4, -0.7, 0.0, 0.4, 1.1, 2.0, pi, 4.1, 6.2]:
    sx, cx = sin(x), cos(x)
    tx, zx = tan(x), 1/cx
    numerical("int sin x", x, sx, sx)
    numerical("int cos x", x, cx, cx)
    numerical("Example 1", x, cx*cx*sx-cx**4*sx, sx**3*cx**2)
    numerical("Example 2", x, cx*(1-sx*sx), cx**3)
    numerical("int cos^2 x", x, 0.5+0.5*cos(2*x), cx*cx)
    numerical("int sin^2 x", x, 0.5-0.5*cos(2*x), sx*sx)
    numerical("Example 3", x, (1-cos(4*x))/8, sx*sx*cx*cx)
    numerical("int sec^2 x", x, 1/(cx*cx), zx*zx)
    numerical("int sec x tan x", x, sx/(cx*cx), zx*tx)
    numerical("int tan x corrected log", x, sx/cx, tx)
    numerical("int sec^4 x", x, (1+tx*tx)*zx*zx, zx**4)
    numerical("int tan^3 x sec x", x, zx*tx*(zx*zx-1), tx**3*zx)
    numerical("int sec x corrected log", x, (zx*zx+zx*tx)/(tx+zx), zx)
    assert isclose((zx+tx)*(zx-tx), 1, rel_tol=2e-12, abs_tol=2e-12)
    assert log(abs(zx+tx)) == log(abs(zx+tx))


x = 0.7
literal_E1_derivative = -cos(cos(x))**2*sin(cos(x))*sin(x)-cos(x)**4*sin(x)
intended_E1 = sin(x)**3*cos(x)**2
assert not isclose(literal_E1_derivative, intended_E1, abs_tol=1e-4)
results["source_counterexamples"].append({
    "id": "E1", "interpretation": "Take retained u literally and substitute u=cos x",
    "x": x, "printed_expression_derivative": literal_E1_derivative,
    "required_integrand": intended_E1, "confirms_error": True
})
results["source_counterexamples"].append({
    "id": "E2", "sin_x": "3/5", "cos_x": "4/5",
    "printed_middle": str(c*c-(1-s*s)), "correct_cos_2x": str(c2),
    "confirms_error": c*c-(1-s*s) != c2
})
results["source_counterexamples"].append({
    "id": "E3", "cos_x": "1/2", "numerator": "1",
    "printed_denominator_cos_cubed_result": str(1/Q(1,2)**3),
    "correct_denominator_cos_squared_result": str(1/Q(1,2)**2),
    "confirms_error": True
})
for issue, argument in [("E4", cos(pi)), ("E5", tan(pi)+1/cos(pi))]:
    try:
        log(argument)
        raise AssertionError("Expected real-log domain error")
    except ValueError:
        results["source_counterexamples"].append({
            "id": issue, "x": pi, "printed_log_argument": argument,
            "printed_real_log_defined": False,
            "corrected_log_abs_value": log(abs(argument)), "confirms_domain_omission": True
        })


def area_formula(a, x):
    return a*a*asin(x/a)/2 + x*sqrt(max(0, a*a-x*x))/2


def simpson_area(a, x, n=32768):
    h = x/n
    total = sqrt(a*a) + sqrt(max(0, a*a-x*x))
    for i in range(1, n):
        t_i = i*h
        total += (4 if i % 2 else 2)*sqrt(max(0, a*a-t_i*t_i))
    return total*h/3


for a in [0.5, 2.0, 3.0]:
    for ratio in [-1.0, -0.75, 0.0, 0.25, 0.75, 0.9, 1.0]:
        x = a*ratio
        expected = area_formula(a, x)
        u = asin(ratio)
        original_final = a*a*asin(ratio)/2+(a*a/4)*2*sin(u)*cos(u)
        assert isclose(expected, original_final, rel_tol=2e-12, abs_tol=2e-12)
        quad = simpson_area(a, x)
        residual = abs(quad-expected)
        # Square-root endpoints lower quadrature convergence; this is explicitly
        # a corroborative numerical tolerance, not an exact integration claim.
        tolerance = 2e-7*max(1, a*a)
        assert residual < tolerance, (a, ratio, residual, tolerance)
        record = {"a": a, "x_over_a": ratio, "formula": expected,
                  "original_final_expression": original_final,
                  "simpson_n": 32768, "quadrature": quad,
                  "absolute_residual": residual, "tolerance": tolerance, "pass": True}
        if abs(ratio) < 1:
            radical = sqrt(a*a-x*x)
            derivative = a*a/(2*radical)+radical/2-x*x/(2*radical)
            assert isclose(derivative, radical, rel_tol=2e-12, abs_tol=2e-12)
            record["analytic_derivative"] = derivative
            record["integrand"] = radical
        results["area_checks"].append(record)
    assert area_formula(a, 0) == 0
    assert isclose(area_formula(a, a), pi*a*a/4, rel_tol=2e-12)
    assert isclose(area_formula(a, a)-area_formula(a, -a), pi*a*a/2, rel_tol=2e-12)

results["summary"] = {
    "exact_rational_checks": len(results["exact_rational_identity_checks"]),
    "numerical_derivative_checks": len(results["numerical_derivative_checks"]),
    "counterexamples": len(results["source_counterexamples"]),
    "area_checks": len(results["area_checks"]),
    "all_checks_passed": True,
    "limitations": "Analytic proofs in review; numerical sampling alone proves no universal identity."
}
(OUT / "calculation-results.json").write_text(json.dumps(results, indent=2)+"\n")
print(json.dumps(results["summary"], indent=2))
