from pathlib import Path
import hashlib
import json
import re
from decimal import Decimal, getcontext
from datetime import datetime, timezone
from PIL import Image

ROOT = Path('/workspace/scratch/f9c0b7fc7e76')
OWN = ROOT / 'd008-r31-fresh-independent-technical'
OUT = OWN / 'frozen-teaching-review'
TEACH = ROOT / 'd008-clean-r31-20261011/teaching'
PACKAGE = ROOT / 'd008-clean-r30-20261011/corrected-prof-r31-published'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

manifest_path = ROOT / 'd008-clean-r31-20261011/evidence/freeze-manifest.json'
assert sha(manifest_path) == '7bc78597ea26b3fd56ea7ab39e37f7385407215117efa6436ff54dcb9e1da060'
assert manifest_path.read_bytes() == (OUT / 'admitted-freeze-manifest.json').read_bytes()
constituents = json.loads((OUT / 'constituent-verification.json').read_text())
for entry in constituents['checks']:
    p = ROOT / 'd008-clean-r31-20261011' / entry['path']
    assert p.stat().st_size == entry['bytes'] and sha(p) == entry['sha256']

prior_seals = [
    ('PREPARATION-SEAL.json', '98945418569102068179e18f0058d640bb97d7394f55f077e91247034d038e1e'),
    ('package-preparation/PACKAGE-PREPARATION-SEAL.json', 'e44b92fd211903e95cb7ed822513e00131e59cdd38414bfbacd765334accc673'),
    ('internal-hash-audit/INTERNAL-HASH-AUDIT-SEAL.json', 'f4447181be744688fa157a7611e48595b00aac029f39fd1881d8e879a8157015'),
    ('corrected-package-admission/CORRECTED-PACKAGE-ADMISSION-SEAL.json', '74f458080256b6524340290f528fb53cc34f22808cb384719fb04297338cab40'),
    ('prompt-only-solutions/PROMPT-SOLUTION-SEAL.json', '79b8d4cdc6ffcc9af82cb2e60d9502ebd2b9bd9065ca5a7bd8776c296af69894'),
]
preserved = []
for rel, expected in prior_seals:
    p = OWN / rel
    assert sha(p) == expected
    seal = json.loads(p.read_text())
    checked = []
    for item in seal.get('artifacts', []):
        q = p.parent / item['path']
        assert sha(q) == item['sha256']
        if 'bytes' in item:
            assert q.stat().st_size == item['bytes']
        checked.append(item['path'])
    preserved.append({'seal': rel, 'sha256': expected, 'all_declared_artifacts_unchanged': True, 'artifacts_checked': checked})
final_hash_seal = OWN / 'internal-hash-audit/FINAL-INTERNAL-HASH-AUDIT-SEAL.json'
for item in json.loads(final_hash_seal.read_text())['artifacts']:
    assert sha(final_hash_seal.parent / item['path']) == item['sha256']
preserved.append({'seal': str(final_hash_seal.relative_to(OWN)), 'sha256': sha(final_hash_seal), 'all_declared_artifacts_unchanged': True})

inputs = [
    ('original-inputs/D008/lec9.pdf', 880629, 'd1b383663f7792bbdaa4d6108e17b11679d4688e413e197486941af337892320'),
    ('d008-clean-r30-20261011/inputs/student-baseline.txt', 247840, '3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5'),
    ('d008-clean-r31-20261011/author/prompts-only.md', 2903, '1ab828b05bb916c4154ca3aca73d92f097593ae1bbeec164b11da47bc388c35f'),
]
for rel, size, expected in inputs:
    assert (ROOT / rel).stat().st_size == size and sha(ROOT / rel) == expected
package_manifest = json.loads((OWN / 'corrected-package-admission/complete-package-manifest.json').read_text())
for entry in package_manifest['files']:
    p = PACKAGE / entry['path']
    assert p.stat().st_size == entry['bytes'] and sha(p) == entry['sha256']
assert len(package_manifest['files']) == 36
write('preservation-verification.json', {
    'verified_utc': datetime.now(timezone.utc).isoformat(),
    'previous_seals': preserved,
    'source_baseline_prompt_identities_unchanged': True,
    'corrected_prof_files_unchanged': 36,
    'all_frozen_teaching_constituents_unchanged': 7,
    'remote_verification_claimed': False,
})

prose = {name: (TEACH / name).read_text() for name in ['README.md', 'hints.md', 'solutions.md']}
anchors = {name: re.findall(r'<a id="([^"]+)"', data) for name, data in prose.items()}
links = []
for name, data in prose.items():
    assert len(anchors[name]) == len(set(anchors[name]))
    for m in re.finditer(r'(!?)\[([^\]]*)\]\(([^)]+)\)', data):
        target = m.group(3)
        entry = {'from': name, 'label': m.group(2), 'target': target, 'image': bool(m.group(1))}
        if target.startswith('https://'):
            entry['status'] = 'external reference present; not opened or independently verified'
        else:
            file, _, anchor = target.partition('#')
            file = file or name
            assert (TEACH / file).is_file()
            if anchor:
                assert file in anchors and anchor in anchors[file]
            entry['status'] = 'static target and explicit anchor exist'
        links.append(entry)
images = []
for name in ['tangent.png', 'basic-tangents.png', 'cosine-quadratic.png', 'clock-model.png']:
    p = TEACH / 'figures' / name
    with Image.open(p) as im:
        images.append({'path': 'figures/' + name, 'pixels': list(im.size), 'format': im.format, 'full_image_visually_inspected': True, 'sha256': sha(p)})
write('static-artifact-checks.json', {
    'scope': 'Source-level checks only; not browser or destination rendering/navigation evidence.',
    'anchors': anchors,
    'links': links,
    'images': images,
    'all_internal_link_paths_and_explicit_anchors_exist': True,
    'external_reference_count': sum(x['target'].startswith('https://') for x in links),
    'prose_line_counts': {k: len(v.splitlines()) for k, v in prose.items()},
})

getcontext().prec = 70
D = Decimal
q4 = (D(4) / D(300000)) ** 2
q6 = (D(6) / D(300000)) ** 2
write('additional-numerical-checks.json', {
    'purpose': 'Arithmetic witnesses supplement analytic review; no finite numerical sample is used as a proof of a general limit or error bound.',
    'precision_decimal_digits': 70,
    'ln_1_02': str(D('1.02').ln()),
    'ln_1_02_linear_error': str(D('.02') - D('1.02').ln()),
    'ln_1_02_quadratic_error': str(D('1.02').ln() - D('.0198')),
    'lecture_speed_clock': {'q': str(q4), 'linear_fraction': str(q4 / 2), 'quadratic_fraction': str(3 * q4 * q4 / 8), 'linear_seconds_for_T_86400': str(D(86400) * q4 / 2), 'quadratic_seconds_for_T_86400': str(D(86400) * 3 * q4 * q4 / 8)},
    'P5_clock': {'q': str(q6), 'linear_fraction': str(q6 / 2), 'quadratic_fraction': str(3 * q6 * q6 / 8), 'linear_seconds': str(D(86400) * q6 / 2), 'quadratic_seconds': str(D(86400) * 3 * q6 * q6 / 8), 'next_term_over_absolute_fractional_scale_1e_minus_12': str((3 * q6 * q6 / 8) / D('1e-12'))},
    'independent_symbolic_checks': {'F_first_derivative_at_zero': '-5/2', 'F_second_derivative_at_zero': '27/4', 'F_quadratic_coefficient': '27/8', 'P2_second_derivative_at_zero': '29', 'P2_quadratic_coefficient': '29/2', 'P6_second_derivative_at_zero': '-8', 'P6_quadratic_coefficient': '-4'},
})

packet = (OWN / 'prompt-only-solutions/prompts-only.frozen.md').read_text()
packet_prompts = re.findall(r'^P[1-6]\. .*$', packet, re.M)
teaching_prompts = re.findall(r'^P[1-6]\. .*$', prose['README.md'], re.M)
assert len(packet_prompts) == len(teaching_prompts) == 6
base_demands = json.loads((OWN / 'prompt-only-solutions/demand-coverage.json').read_text())
locators = [
    {'main': [49, 49], 'hint': [9, 13], 'solution': [9, 25], 'result': 'h=0.08; L=2+(x-4)/4; estimate 2.02; square 4.0804 proves nonidentity'},
    {'main': [123, 123], 'hint': [17, 21], 'solution': [29, 50], 'result': 'Domain excludes 1/2; |x|<1/4 is valid neighborhood; small inputs 3x,-2x; L=1+5x; omitted factor squares invalidate coefficient 6; actual coefficient 29/2'},
    {'main': [231, 231], 'hint': [25, 29], 'solution': [54, 84], 'result': 'L=ln2+(x-2)/2; Q=L-(x-2)^2/8; .71314718 and .71294718; shown discrepancies .00019737 and .00000263; rounded-comparison qualification'},
    {'main': [237, 237], 'hint': [33, 37], 'solution': [88, 106], 'result': 'Limit 1/2; R2/x^2 tends to zero; C2 sufficient condition proved before prompt; first-order remainder cannot determine square quotient'},
    {'main': [296, 296], 'hint': [41, 45], 'solution': [110, 145], 'result': 'q=4e-10; fraction 2e-10; 17.28 microseconds; next fractional 6e-20; negligible at absolute fractional scale 1e-12; speed powers 2,4; next-term comparison is not whole-remainder bound'},
    {'main': [338, 338], 'hint': [49, 53], 'solution': [149, 176], 'result': 'H=2x-4x^2+R; two nonzero quadratic contributions -2,-2; R/x^2 tends to zero; limit -4; domain x>-1/2'},
]
for i, item in enumerate(base_demands):
    item.update(locators[i])
    item['sealed_prompt_text'] = packet_prompts[i]
    item['frozen_teaching_prompt_text'] = teaching_prompts[i]
    item['manual_semantic_comparison'] = 'Same substantive demand and supplied data; only mathematical presentation changes.'
    item['independent_solution_agreement'] = True
    item['all_demands_have_reasoned_authored_answer'] = True
    item['hint_matched_and_mathematically_correct'] = True
    item['status'] = 'verified against independently sealed solution'
write('demand-coverage.json', {'prompt_count': 6, 'substantive_demands_in_prior_seal': sum(len(x['demands']) for x in base_demands), 'all_prompts_and_demands_covered': True, 'items': base_demands})

print(json.dumps({'preserved_seals': len(preserved), 'unchanged_prof_files': 36, 'frozen_teaching_files': 7, 'prompts': 6, 'substantive_demands': sum(len(x['demands']) for x in base_demands), 'internal_link_and_anchor_checks': 'pass', 'external_references_unopened': 2, 'images_fully_inspected': 4}))
