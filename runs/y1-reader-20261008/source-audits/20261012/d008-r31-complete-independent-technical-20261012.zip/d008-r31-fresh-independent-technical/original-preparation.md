# D008 independent technical preparation

Status: preparation from original source and full baseline only. No current or prior generated teaching, assessment prompt packet, answer key, report, diagnosis, trial response, author history, or raw queue has been received or inspected. This is an instruction-boundary statement, not a claim of technical isolation or inaccessible shared files.

## Input identity and coverage

Original: MIT OpenCourseWare, 18.01 Single Variable Calculus, Fall 2006, Lecture 9, Linear and Quadratic Approximations, Unit 2. The original PDF has 7 physical pages, comprising the cover and lecture pages 1-6. PDF size 880629 bytes; SHA-256 d1b383663f7792bbdaa4d6108e17b11679d4688e413e197486941af337892320. The PDF metadata reports seven letter-size pages. All seven extracted page-text files were read completely. All seven whole-page PNGs were visually inspected, including the cover, captions, figures, footnote, and final page. A separate record identifies every input file and hash. Seven fresh whole-page renders from the verified PDF were also inspected. They are not pixel-identical to the supplied PNGs; the same mathematical content is present, with rendering/layout/font/link-border differences. No claim of pixel identity is made.

Baseline: the exact 247840 bytes of d008-clean-r30-20261011/inputs/student-baseline.txt, SHA-256 3749d2e59631b7981e2dcdf3ec05225a0f375d93728b593ccef44fae916942e5, were read to EOF, not replaced by a topic list or summary. All four subject sections were consumed. One tool-output truncation in the 40000:80000 byte window was repaired by reading the complete FM17-FM19 passage (bytes 59188:60728). The supplied URLs and references were treated as provenance strings and were not followed.

## Page-by-page mathematical verification

### Physical page 1: cover

Read the MIT attribution, course title, term, and terms/citation notice. This page has no mathematical premises or assessment tasks.

### Physical page 2: lecture page 1

The tangent line at x0 is L(x)=f(x0)+f'(x0)(x-x0). It has L(x0)=f(x0) and L'(x0)=f'(x0). In the displayed point-slope form, b=f(x0) is the height at the basepoint; it is not generally the y-intercept unless x0=0. The diagram's local tangent contact is consistent with the formula.

For f(x)=ln x with x0=1, f(1)=0 and f'(1)=1, giving L(x)=x-1. Substitution x=1+u puts the new basepoint at u=0 and yields ln(1+u) approximately u. The real logarithm requires x>0, equivalently u>-1; useful local approximation requires u near zero. A change of variable does not move the physical point of approximation; it changes its coordinate.

The source says accuracy worsens when moving away from the basepoint. This describes the intended local use and pictured curve, not a proved universal monotonic-error law for every function or distance. Equality at the contact point alone would not make an arbitrary nearby model an accurate tangent approximation.

### Physical page 3: lecture page 2

The five linear models at zero check by direct derivative evaluation:

| Function | f(0) | f'(0) | Linear model |
|---|---:|---:|---|
| sin x | 0 | 1 | x |
| cos x | 1 | 0 | 1 |
| exp x | 1 | 1 | 1+x |
| ln(1+x) | 0 | 1 | x |
| (1+x)^r | 1 | r | 1+rx |

The trigonometric formulas use radians. For a general real exponent it is safe to work near zero with 1+x>0. The figures are consistent with the sine tangent y=x and cosine tangent y=1 at zero. The source's proof paragraph writes f(x)=x for f(x)=sin x, and its binomial proof writes f(x)=f(0)+f'(0)x. Those equalities are not identities for the original functions; they should be read as approximation statements or as definitions of a separately named approximating polynomial.

Example 2 starts e^(-2x)/sqrt(1+x). The exponential substitution u=-2x gives 1-2x. Its real domain is x>-1. Substituted small parameters, not merely the unscaled symbol x, must be small. For this fixed coefficient, x tending to zero ensures -2x tends to zero.

### Physical page 4: lecture page 3

The reciprocal-root factor can be obtained directly: (1+x)^(-1/2) approximately 1-x/2. Alternatively, sqrt(1+x) approximately 1+x/2 followed by (1+u)^(-1) approximately 1-u at u=x/2 gives the same linear model. Multiplication gives (1-2x)(1-x/2)=1-(5/2)x+x^2. Only the constant and linear terms are reliable from factors truncated at first order. The product's x^2 term alone is not the full quadratic coefficient. Thus the source's first-order answer 1-(5/2)x is correct.

Direct differentiation verifies f(0)=1 and f'(0)=-5/2. Specifically, f'=e^(-2x)[-2(1+x)^(-1/2)-(1/2)(1+x)^(-3/2)]. Recovering f'(0) from a polynomial coefficient is valid here because the polynomial was established as the derivative-matching local model; a bare numerical approximately sign alone would not establish an exact derivative value.

Example 3: f(x)=(1+2x)^10 has f(0)=1 and f'(0)=20. The difference quotient limit is therefore 20. An independent exact binomial check begins (1+2x)^10=1+20x+180x^2+..., a finite polynomial, so [(1+2x)^10-1]/x=20+180x+... for x nonzero and tends to 20. Replacing an arbitrary approximate numerator inside a limit needs control of the omitted terms; the derivative route and finite polynomial supply it here.

Example 4 states T'=T/sqrt(1-v^2/c^2). This is a supplied physical model, not derived from the baseline. For real finite values it requires |v|<c; the intended small parameter is z=v^2/c^2. T and T' are intervals in the same units; the ratio is dimensionless.

The footnote's reciprocal-root shortcut is mathematically correct and avoids a redundant intermediate approximation.

### Physical page 5: lecture page 4

The labels define T' as the wristwatch interval and T as the satellite interval under the source's stated model. For z=v^2/c^2, (1-z)^(-1/2) approximately 1+z/2. Therefore T'/T approximately 1+z/2, or T' approximately T(1+z/2). The displayed source line omits the factor T on the last expression while keeping T' on the left. Taken literally it equates a time with a dimensionless quantity. The bracketed template also visibly prints (1+u)^4 approximately 1+ru even though it specifies r=-1/2; the intended exponent is r, not 4. Both are source-level transcription/presentation errors, not changes in the model's valid expansion.

Using v=4 km/s and c=3*10^5 km/s, z=16/(9*10^10)=1/5625000000=1.7777777777777778*10^(-10). The linear fractional excess is z/2=1/11250000000=8.888888888888889*10^(-11). The source's 10^(-10) description is an order-of-magnitude statement. Absolute interval differences require the value of T. The GPS discussion is historical/contextual source material; it is not evidence that this one kinematic term suffices for all satellite clock corrections.

The quadratic polynomial at x0 is Q(x)=f(x0)+f'(x0)h+f''(x0)h^2/2, h=x-x0. It matches value, first derivative, and second derivative at x0. The factor 1/2 is verified because d^2(ch^2)/dx^2=2c. For a general quadratic a+bx+cx^2 at zero, its three matched coefficients are exactly a,b,c, so the construction reproduces it exactly. A derivative-matching local parabola is not automatically a least-squares fit over an interval; the phrase best-fit needs that local interpretation.

For cosine at zero, f(0)=1, f'(0)=0, f''(0)=-1; Q=1-x^2/2. This agrees with the baseline's small-angle cosine and Maclaurin expansion.

### Physical page 6: lecture page 5

The cosine parabola diagram correctly shows value and tangent matching at zero and a downward-opening quadratic; the functions differ away from contact. The quadratic table checks as follows:

| Function | f''(0) | Quadratic polynomial |
|---|---:|---|
| sin x | 0 | x |
| cos x | -1 | 1-x^2/2 |
| exp x | 1 | 1+x+x^2/2 |
| ln(1+x) | -1 | x-x^2/2 |
| (1+x)^r | r(r-1) | 1+rx+r(r-1)x^2/2 |

A quadratic approximation means keeping through degree two; the actual degree can be lower when the quadratic coefficient vanishes, as for sine at zero. For log, f'=1/(1+x) and f''=-1/(1+x)^2 give the displayed coefficients and the domain x>-1.

For the clock ratio, substitute u=-z and r=-1/2. The second coefficient is r(r-1)/2=3/8, while u^2=z^2, so the ratio is approximated by 1+z/2+3z^2/8. This is quadratic in z=v^2/c^2 (or u=-z), and its added term is fourth degree in v/c. It is not a second-degree polynomial in v/c with a new quadratic correction beyond the first expansion.

### Physical page 7: lecture page 6

For the supplied speeds, the quadratic fractional correction is (3/8)z^2=1/84375000000000000000=1.1851851851851851*10^(-20). Multiplying by T gives its contribution to a time interval. The omitted size is indeed of order 10^(-20) in the ratio. Whether that term is negligible is a decision relative to a requested tolerance and interval; the source's atomic-clock statement is a dated contextual assertion, not a fresh measurement-technology verification. No external factual premise is imported here.

Example 5: e^(-2x)=1-2x+2x^2+... and (1+x)^(-1/2)=1-x/2+3x^2/8+.... Their quadratic product coefficient is 2+(-2)(-1/2)+3/8=27/8. Therefore f(x) approximately 1-(5/2)x+(27/8)x^2, consistent with the source.

An independent derivative check uses g=e^(-2x), h=(1+x)^(-1/2). At zero, (g,g',g'')=(1,-2,4) and (h,h',h'')=(1,-1/2,3/4). Product differentiation gives f''(0)=g''h+2g'h'+gh''=4+2+3/4=27/4, so f''(0)/2=27/8. When multiplying degree-two factors, terms of total degree at most two must all be retained, including the product of the two linear terms; degree three and four terms are outside this truncation. This independent check confirms the numerical coefficient without relying on the source's final answer.

## Baseline premises and limits relevant to future review

The full baseline grants algebra, functions and domains, real powers, binomial expansion with validity restrictions, radians and small-angle formulas, logarithms, exponentials, derivative definitions, product/quotient/chain rules, tangent equations, second derivatives and concavity, graph/model interpretation, units and proportional reasoning. Mathematics alone explicitly excludes broader Taylor/Maclaurin theory; that does not remove the selected Further Mathematics grant.

Further Mathematics FM27 explicitly supplies Maclaurin coefficients and the standard expansions for exponential, sine, cosine, log and binomial functions, with real validity intervals and an explicit exclusion of a general remainder theorem. The lecture's zero-centred quadratic table is therefore available from the full baseline, not wholly new university formalism. A nonzero centre can be handled by defining g(h)=f(x0+h), using the granted chain rule to identify g'(0)=f'(x0) and g''(0)=f''(x0), and applying the supplied zero-centred construction. That transfer is a shown deduction, not a claim that arbitrary-centre Taylor theory was separately pre-taught.

FM57, the Physics units/measurement sections, and Chemistry's units/model conventions make dimensional consistency available. Physics supplies c=3.00*10^8 m/s and ordinary unit conversion, but does not supply relativistic spacetime or a time-dilation law. Thus a question can use the lecture's stated clock law, yet must not silently require an unprovided relativistic interpretation. The clock interval definitions and which ratio is approximated must remain explicit.

Chemistry was read fully, including quantitative rates, equilibrium, entropy/Gibbs calculations, spectra, practical reasoning and scope restrictions. Its exponentials, logs, tangent/rate reasoning, unit checks and conditional-approximation practices can support general transfer when premises are shown. It supplies no additional time-dilation law or universal mathematical error theorem. No unseen linked reference material was counted as a premise.

The complete baseline permits ordinary deduction across all four subjects. An assessment exclusion does not prohibit deriving a result from the displayed premises. Conversely, familiarity with a topic name does not permit unprovided university facts. A general Taylor error bound, an exact acceptance interval for a requested tolerance, or a contemporary instrument-precision claim requires an appropriate supplied premise or derivation; small x by itself is not a numerical error certificate for arbitrary functions or scales.

## Future-stage boundary

This preparation is complete before receipt of the current published PROF package or finalized prompt-only assessment packet. On later authorization, read that package as specified and solve every finalized prompt independently, recording premises, domains, conditions, ambiguity and exact solutions; seal that independent solution record before receiving the frozen teaching. No conclusions about the correctness, sufficiency or pedagogy of unseen generated teaching are possible at this stage. Preparation findings are not being sent to the author.
