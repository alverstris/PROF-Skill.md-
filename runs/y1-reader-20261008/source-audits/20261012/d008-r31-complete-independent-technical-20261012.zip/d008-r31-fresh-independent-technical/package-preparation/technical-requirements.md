# r31 technical reviewer requirements preparation

This is the independent technical-review role, not the SASIS reader, author, task designer or publication coordinator. The exact admitted local package is d008-clean-r30-20261011/release-prof/. Its 36 files were hashed; eight current instruction/profile resources were read in full, with actual ranges and recovered truncation recorded. The parent supplied GitHub pin 7cf8e4745680b2042efae1db73cb2e33665549c9 and states that it fetched and verified the publication. This reviewer makes no independent remote-verification claim.

The original D008 source and full four-subject baseline preparation remains valid and sealed unchanged. The package's complete baseline has the same 247840-byte identity already read in full. No older teaching or reports have been opened. No finalized prompts or current generated teaching have yet been received.

## Controlling workflow

1. Wait for the explicitly finalized prompt-only packet. Record its exact file identities, hashes, extent, and authorized supporting data. Do not look for the authored hints, solutions, current teaching, or old artifacts.
2. Solve every prompt and subpart independently using the inspected original source, complete operational baseline, and supplied prompt premises. Preserve domains, parameter assumptions, units, approximation variable/order, exact and approximate relationships, and any legitimate alternative results. Identify genuine ambiguity or unavailable evidence instead of inventing a premise. Do not create a mandatory new task battery.
3. Record independent solutions and meaningful discriminating checks, then seal those exact results before receiving frozen teaching. Report completion and the seal to the coordinator. Do not send answers or source-preparation findings to the author.
4. Only after the independent solution seal and subsequent admission, inspect the entire frozen current teaching, including figures, captions, exercises, hints, full answers, appendices and its ending. Compare all prompts and answers against the sealed independent record; check source coverage and important scientific claims, not only task answers.
5. Keep scientific correctness separate from chronological logical availability to the SASIS reader. The full baseline can license actual short deductions; it cannot silently supply missing university theories, empirical premises, or absent data. Introduced definitions/model laws can legitimately be new premises if their status, meaning, conditions and truth are sound. Independent expert success cannot establish that the teaching route is available to the baseline reader.
6. Report every verified material issue with exact artifact and source/baseline locator, applicable obligation ID, asserted condition, concrete counterexample or independent calculation where useful, consequence, affected dependencies, and necessary repair. Preserve uncertain concerns and valid alternatives distinctly. Check the whole document; the earliest issue orders repairs rather than ending the audit.
7. Preserve evaluated teaching and original reports unchanged. This iteration's repair target is PROF or its operative procedure, with reusable trigger, author action and observable verification. Do not patch frozen teaching, publish edits, communicate with the author, or inspect prior diagnoses. A disproved concern is not a defect and requires no invented rule. Publication, a hash or agreement is not acceptance.
8. Keep all status claims bound to exact reviewed bytes. Distinguish completed local technical inspection, source coverage, SASIS evidence, mechanical state checks, actual destination rendering/navigation, and human learning. Browser and remote writes remain prohibited to this reviewer; unperformed rendering/navigation checks are not claimed. Changes to relevant inputs invalidate affected evidence and require an explicit new stage.

## Applicable review duties from r31

T1-T3: Check meanings and consequential conditions at first use, representation/grouping/domain/units, and whether each deduction or approximation is licensed under its actual hypotheses. When a condition permits a construction, verify the implication itself rather than only defined input expressions. Preserve the distinction between a finite stage and its limit.

T4-T7: Check connected worked reasoning, meaningful application where required, prompt targets/criteria, and matched useful hints plus complete reasoned answers for every retained task. A method-selection prompt should not have its method supplied by its title. New theory introduced only in help cannot retrospectively support an earlier task.

T8-T9: Check relevant retention/transfer and baseline fit as teaching duties when they apply; do not infer a fixed quota or that changed arithmetic alone establishes transfer. Avoid redundant baseline reteaching while retaining local new connections. These are not independent learner scores.

T10: Independently verify important claims, full answers, qualitative summaries and source corrections. Use checks that discriminate plausible errors: signs, units, limits, special/admissible cases, precise substitutions, and a second derivation where material. Numerical agreement in a few examples does not validate an unconditional claim.

T11-T12: Check required content and support separation, requested format and actual verification status. The current contract prohibits bold/italic teaching prose, including destination-added emphasis, and has target-specific math/navigation requirements. A technical report can identify source-level hazards, but it cannot replace actual target rendering/click evidence. No global completion claim follows from this preparation.

The physics/mathematics domain guidance applies: preserve or explicitly map course notation, state assumptions, connect description to representation, distinguish rules/conventions/example choices, and select discriminating checks. The matrix/programming/language examples are illustrations, not D008 content requirements. No external links or historical methods reports were followed.

## Package identity observation

All 19 frozen baseline/profile payload hashes declared in profile-manifest.json match the admitted local files. The rewrite-guide.md control hash matches. Two other current control-file entries do not match actual bytes: student-role.txt and student-testing-contract.txt. Exact expected/actual hashes and normalization check are recorded in profile-hash-check.json. This is a package identity inconsistency, not a D008 teaching verdict. The coordinator was notified; no file was changed and no remote explanation is assumed. Reading current actual instructions can be recorded as complete, while package internal-manifest consistency remains failed/pending coordinator disposition.

## Ready state

Original source/full baseline preparation complete and unchanged. Current r31 local-package reading complete. Prompt-only independent solutions pending packet admission. Frozen-teaching review not started. Current teaching correctness, SASIS sufficiency, destination output and corpus acceptance remain unverified.
