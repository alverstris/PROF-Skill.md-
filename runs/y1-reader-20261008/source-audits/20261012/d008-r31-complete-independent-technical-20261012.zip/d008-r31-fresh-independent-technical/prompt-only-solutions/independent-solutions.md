# D008 r31 independent prompt-only solutions

These solutions were completed before receipt or access to current generated teaching, authored hints, authored solutions, figures, drafts or reviews. This is independent technical review, not SASIS and not a learner performance report. The exact six-prompt packet has 2903 bytes and SHA-256 1ab828b05bb916c4154ca3aca73d92f097593ae1bbeec164b11da47bc388c35f. The original lecture, full four-subject operational baseline and corrected admitted PROF package are the previously inspected inputs. No external subject source was used.

## P1

Choose f(x)=sqrt(x), a=4 and input displacement h=4.08-4=0.08. The derivative for x>0 is f'(x)=1/(2 sqrt(x)), so f(4)=2 and f'(4)=1/4.

The tangent polynomial is

L(x)=f(4)+f'(4)(x-4)=2+(x-4)/4.

Therefore sqrt(4.08) is approximately L(4.08)=2+0.08/4=2.02.

This is a local tangent estimate: it matches the value and derivative at 4, but sqrt(x) is not this straight line on a neighborhood. The arithmetic also decisively rules out exact equality: (2.02)^2=4.0804, not 4.08. Thus the positive square root of 4.08 is not exactly 2.02. A supplemental high-precision numerical check gives 2.01990098767241559..., so the tangent overestimates by about 0.0000990123; this check is not an extra datum needed by the learner's solution.

Premises: Mathematics baseline power/chain differentiation, tangent equation and ordinary arithmetic; original physical page 2 tangent construction. All requested items are supplied: displacement, derivative, tangent formula, estimate and explanation of approximation.

## P2

The real expression g(x)=exp(3x)/(1-2x) is defined for every real x except x=1/2. For example, the open neighborhood -1/2<x<1/2 contains zero and avoids the pole. This domain statement does not claim a particular numerical approximation accuracy throughout that interval.

Use the exponential small input u=3x and the reciprocal/binomial small input w=-2x:

exp(3x) approximately 1+3x,
(1-2x)^(-1)=(1+w)^(-1) approximately 1-w=1+2x.

Both small inputs tend to zero as x tends to zero. The local approximation requires |3x| and |2x| small; the nonterminating reciprocal series is valid when |2x|<1.

Multiply the linear factors:

(1+3x)(1+2x)=1+5x+6x^2.

The requested linear approximation is therefore L_g(x)=1+5x. The coefficient 6 of x^2 in this truncated-factor product is not established as g's quadratic coefficient. Both factors also possess omitted quadratic terms; each such term multiplies the other factor's constant 1 and contributes at degree two, the same degree as the retained cross-product 3x*2x.

Independent check, beyond the minimum requested explanation: exp(3x) has quadratic term (9/2)x^2 and (1-2x)^(-1) has quadratic term 4x^2. The full quadratic coefficient is 9/2+6+4=29/2. Direct product differentiation independently gives g'(0)=3+2=5 and g''(0)=9+2(3)(2)+8=29, confirming coefficient g''(0)/2=29/2. The answer does not require silently treating a product of approximate factors as an exact identity for g.

Premises: Mathematics binomial expansion and derivative rules, FM27 exponential/binomial expansions, original physical pages 3-4 order-consistent multiplication. The small-input and missing-coefficient explanation are substantive parts of the demand.

## P3

Let h=x-2. For f(x)=ln x on x>0,

f(2)=ln 2, f'(2)=1/2, f''(2)=-1/4.

Thus

L(x)=ln 2+(x-2)/2,
Q(x)=ln 2+(x-2)/2-(x-2)^2/8.

At x=2.04, h=0.04 and h^2=0.0016. Using only the supplied ln 2 approximation for the estimates gives

L(2.04) approximately 0.69314718+0.02000000=0.71314718,
Q(2.04) approximately 0.71314718-0.00020000=0.71294718.

Now compare with the separately supplied check value 0.71294981:

|L estimate - check value|=0.00019737,
|Q estimate - check value|=0.00000263.

At the shown precision, the linear estimate is above the comparison and the quadratic estimate below it. The quadratic error is about 75 times smaller in this instance. These are comparisons of displayed rounded numbers, not rigorously certified exact errors from an exact logarithm value. A high-precision independent check, ln(2.04)=0.712949807856125..., confirms the supplied rounding and error scale.

The square is the square of displacement from the actual basepoint, (x-2)^2, rather than x^2. It vanishes at x=2, and its first derivative vanishes there. It consequently preserves the matched value and first derivative while adding curvature. Its coefficient is f''(2)/2=-1/8, because the second derivative of C(x-2)^2 is 2C. Hence Q''(2)=-1/4 as required. The example shows improved accuracy for this evaluation; it does not establish that a quadratic model is always closer for every function and input.

Premises: Mathematics logarithm derivatives and chain rule; FM27 can be applied to g(h)=f(2+h) with shown shifting; original physical pages 5-6 general quadratic construction and the factor 1/2.

## P4

Write the quadratic expansion with an explicit remainder:

exp(x)=1+x+x^2/2+R(x).

A sufficient error condition is R(x)/x^2 -> 0 as x -> 0 through nonzero x. This is what R(x)=o(x^2) means. Then

[exp(x)-1-x]/x^2=1/2+R(x)/x^2 -> 1/2.

The surviving coefficient is 1/2.

The linear approximation alone does not establish that value. The term it discards can have a nonzero quadratic coefficient, which survives division by x^2. Indeed every function 1+x+Kx^2 has the same tangent 1+x at zero, while the corresponding quotient tends to K. Therefore replacing exp(x) by its tangent and declaring the numerator zero would erase precisely the order relevant to the question.

For this particular exponential, the sufficient error condition follows without importing an unprovided general Taylor remainder theorem. FM27 supplies exp(x)=sum from n=0 to infinity of x^n/n!, and the Mathematics baseline supplies the convergent geometric sum. For |x|<=1/2, the tail starting at n=3 satisfies

|R(x)| <= sum(n>=3) |x|^n/n! <= (1/6) sum(n>=3) |x|^n
= |x|^3/[6(1-|x|)] <= |x|^3/3.

The estimate uses n!>=6 for n>=3. Therefore |R(x)/x^2|<=|x|/3 -> 0. The bound holds from either side of zero and justifies the quotient limit. A stated bound |R(x)|<=C|x|^3 near zero would also be sufficient. A vague claim that the omitted term is small, with no relation to x^2, would not suffice.

Numerical checks at x=+/-10^(-3) and +/-10^(-6) approach 1/2 from the two sides. They corroborate arithmetic but are not substituted for the remainder argument.

## P5

The supplied constant-speed, gravity-free law is a model premise. No gravitational or real-orbit correction is added. The ratio v/c uses identical speed units:

v/c=6/(3*10^5)=2*10^(-5),
q=(v/c)^2=4*10^(-10).

With r=-1/2 and u=-q, the binomial coefficients give

(1-q)^(-1/2)=1+q/2+(3/8)q^2+... .

Since the desired fractional correction is (T'-T)/T=T'/T-1, its linear-in-q estimate is

(T'-T)/T approximately q/2=2*10^(-10).

This is dimensionless. Multiplying by the supplied moving-clock elapsed time T=86400 s gives

T'-T approximately 86400 s * 2*10^(-10)=1.728*10^(-5) s=17.28 microseconds.

The next, quadratic-in-q contribution to the fractional correction is

(3/8)q^2=(3/8)(4*10^(-10))^2=6*10^(-20).

If also converted to a time contribution it is 86400 s * 6*10^(-20)=5.184*10^(-15) s. The time contribution must not be substituted for the fractional term in the requested comparison.

At an absolute fractional scale of 10^(-12) in (T'-T)/T, adding 6*10^(-20) does not change the estimate at that scale: the added amount is 6*10^(-8) times the stated scale. The two-term fractional estimate would be 2.0000000006*10^(-10).

The contribution q/2=(1/2)(v/c)^2 is second degree in v/c. The contribution (3/8)q^2=(3/8)(v/c)^4 is fourth degree in v/c. Calling the latter quadratic refers to q, not to v/c.

Comparing the linear term with the next quadratic term is not by itself an upper bound on the entire omitted remainder. A full accuracy certificate would additionally need a justified bound on all remaining terms or another exact error estimate. The requested next-term comparison establishes only the size of adding that displayed term. No contemporary instrument-resolution claim is needed or made.

Interpretation note for later audit, not an established prompt defect: the preceding answer states explicitly that 10^(-12) is an absolute scale in the dimensionless fraction defined by the prompt. If a different question instead demanded 10^(-12) relative accuracy of the much smaller correction 2*10^(-10) itself, the next term divided by that correction would be 3*10^(-10), a different comparison. The present calculation keeps these denominators distinct.

Premises: stated clock law, original physical pages 4-7 binomial application, baseline binomial expansion and unit arithmetic. The source's missing-T typographical line is not adopted.

## P6

The real expression H(x)=ln(1+2x) exp(-x) is defined on x>-1/2 and hence near zero. The numerator subtracts the expected degree-one term 2x and then divides by x^2, so the quadratic coefficient is required; first-order approximations alone could omit a surviving contribution.

Using the baseline expansions with their substituted inputs gives

ln(1+2x)=2x-2x^2+r_A(x),
exp(-x)=1-x+r_B(x),

where r_A is bounded by a constant times |x|^3 and r_B by a constant times x^2 near zero. The exponential only needs its constant and linear terms here because the logarithm has zero constant term. One may instead expand both factors through degree two, but the exponential x^2/2 term contributes first at degree three after multiplication by the logarithm's leading 2x.

The products contributing at degree two are

(-2x^2)*1=-2x^2,
(2x)*(-x)=-2x^2.

There is no contribution from 0*(x^2/2). Adding the degree-one product (2x)*1 gives

H(x)=2x-4x^2+R_H(x),

so its approximation through degree two is 2x-4x^2.

An explicit remainder check supports the limit. For |x|<=1/4, the supplied log series at 2x yields

|r_A(x)| <= sum(n>=3) (2|x|)^n/n <= 8|x|^3/[3(1-2|x|)] <= (16/3)|x|^3.

The exponential series gives

|r_B(x)| <= sum(n>=2) |x|^n/n! <= |x|^2/[2(1-|x|)] <= (2/3)|x|^2.

Expanding the two polynomial parts exactly gives 2x-4x^2+2x^3. Thus

R_H=2x^3+(2x-2x^2)r_B+r_A(1-x)+r_A r_B.

Put t=|x|<=1/4. Since |2x-2x^2|<=5t/2 and |1-x|<=5/4,

|R_H| <= [2+5/3+20/3+2/9]t^3=(95/9)t^3 <= 11t^3.

The final 2/9 bound uses (32/9)t^5 <= (2/9)t^3 for t<=1/4. Consequently R_H(x)/x^2 -> 0. For x nonzero,

[H(x)-2x]/x^2=-4+R_H(x)/x^2 -> -4.

This explains why discarded terms do not affect the limit: their combined error, after division, tends to zero. Merely calling them higher powers would not by itself address an uncontrolled infinite tail.

A separate differentiation check uses A=ln(1+2x), B=exp(-x). At zero, (A,A',A'')=(0,2,-4) and (B,B',B'')=(1,-1,1). Then H(0)=0, H'(0)=2, and H''(0)=A''B+2A'B'+AB''=-4-4+0=-8. The coefficient H''(0)/2=-4 agrees with the independent product calculation. Two-sided high-precision values of the normalized quotient approach -4.

The prompt's optional break is a study suggestion. This technical solution makes no claim of an observed delayed attempt, retention or learner transfer.

## Review boundary and completeness

P1-P6 and every substantive sub-demand have been answered. All complete answers above precede inspection of any authored help or current teaching. The explicit tail bounds are technical verification witnesses, not demands that future teaching reproduce these exact proofs. Other correct, appropriately justified routes remain acceptable. The general remainder theorem was not silently assumed from the baseline; the bounds used only its supplied convergent exponential/log series, factorial arithmetic and geometric sums.

No judgement of unseen teaching is recorded. Following seal, await the root coordinator's explicit freeze admission before reading the teaching or comparing any authored solution.
