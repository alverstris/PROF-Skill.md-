# D008 r31 hints.md destination preservation

**PASS.** Every source expression is preserved in the actual captured MathML, including its inline/display type. No unsupported forms or differences were found.

| Coverage | Verified |
| --- | ---: |
| Expressions | 14/14 |
| Inline / display | 14 / 0 |
| Full normalized prose characters | 2268 |
| Textual link labels and resolved hrefs | 16 |
| Explicit anchor IDs | 7 |
| Image alt texts / wrapper hrefs | 0 / 0 |

The whole source expression/prose/link/anchor/alt inventory agrees with the inventory prepared before the captures arrived. All embedded article MathML strings agree with the capture's ordered MathML array. No error or raw-math fallback slots occur.

[Complete per-expression records, exact full prose, links, anchors and alt comparisons](math-preservation.json). Immutable destination commit: `81076b4c593fc1d685648c72892769c7a025f390`. Source SHA256: `a49e83e0ecc8df8cd3f4cd17ebd682ed09499b6397670db192829c5d4d556525`. Unchanged capture SHA256: `5a47cb4e2dd52c95c3f33b8cd92bfbcd87293c85b42b19b3e60b2183bbea8fd4`.

The unchanged v4 restricted parser compared source TeX and actual MathML structures independently. Only its documented markup, layout-space and symbol-spelling normalizations apply; it performs no algebraic simplification. Relative hrefs are resolved against the immutable article URL, and GitHub's explicit `user-content-` anchor prefix is checked. This is preservation only; it establishes no source-science/SASIS verdict, visual geometry, click success or fragment landing behavior.
