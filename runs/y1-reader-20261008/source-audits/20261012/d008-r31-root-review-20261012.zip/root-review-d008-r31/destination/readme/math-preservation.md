# D008 r31 README.md destination preservation

**PASS.** Every source expression is preserved in the actual captured MathML, including its inline/display type. No unsupported forms or differences were found.

| Coverage | Verified |
| --- | ---: |
| Expressions | 187/187 |
| Inline / display | 156 / 31 |
| Full normalized prose characters | 21304 |
| Textual link labels and resolved hrefs | 20 |
| Explicit anchor IDs | 7 |
| Image alt texts / wrapper hrefs | 4 / 4 |

The whole source expression/prose/link/anchor/alt inventory agrees with the inventory prepared before the captures arrived. All embedded article MathML strings agree with the capture's ordered MathML array. No error or raw-math fallback slots occur.

[Complete per-expression records, exact full prose, links, anchors and alt comparisons](math-preservation.json). Immutable destination commit: `81076b4c593fc1d685648c72892769c7a025f390`. Source SHA256: `f712c6a16878574c42fa80e97aa76a2afbd6ff7c33f3ac2b3fd790f9977d575f`. Unchanged capture SHA256: `397d57a8b6b07b756dace7607397e7acf879f7af23a2536d9a6e12c8eceaa3e1`.

The unchanged v4 restricted parser compared source TeX and actual MathML structures independently. Only its documented markup, layout-space and symbol-spelling normalizations apply; it performs no algebraic simplification. Relative hrefs are resolved against the immutable article URL, and GitHub's explicit `user-content-` anchor prefix is checked. This is preservation only; it establishes no source-science/SASIS verdict, visual geometry, click success or fragment landing behavior.
