# D008 r31 solutions.md destination preservation

**PASS.** Every source expression is preserved in the actual captured MathML, including its inline/display type. No unsupported forms or differences were found.

| Coverage | Verified |
| --- | ---: |
| Expressions | 51/51 |
| Inline / display | 34 / 17 |
| Full normalized prose characters | 5921 |
| Textual link labels and resolved hrefs | 15 |
| Explicit anchor IDs | 7 |
| Image alt texts / wrapper hrefs | 0 / 0 |

The whole source expression/prose/link/anchor/alt inventory agrees with the inventory prepared before the captures arrived. All embedded article MathML strings agree with the capture's ordered MathML array. No error or raw-math fallback slots occur.

[Complete per-expression records, exact full prose, links, anchors and alt comparisons](math-preservation.json). Immutable destination commit: `81076b4c593fc1d685648c72892769c7a025f390`. Source SHA256: `005b8969e89493a1ed5ef6b4dfba16068e40b73dfc37adb19e5dc78e175a004e`. Unchanged capture SHA256: `7261511b9009c7d13941bab4d25cd06fa5e4bcf08698f30c985d235cb5681906`.

The unchanged v4 restricted parser compared source TeX and actual MathML structures independently. Only its documented markup, layout-space and symbol-spelling normalizations apply; it performs no algebraic simplification. Relative hrefs are resolved against the immutable article URL, and GitHub's explicit `user-content-` anchor prefix is checked. This is preservation only; it establishes no source-science/SASIS verdict, visual geometry, click success or fragment landing behavior.
