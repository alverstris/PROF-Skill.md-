# D008 r31 independent frozen-source inventory

Verified the exact supplied manifest SHA-256 `7bc78597ea26b3fd56ea7ab39e37f7385407215117efa6436ff54dcb9e1da060`. All seven teaching-document/PNG files match their frozen byte counts and hashes. This is a source inventory, not a destination or science/SASIS verdict.

| File | Lines | Expressions | Inline / display | Text links | Anchors | Images |
|---|---:|---:|---:|---:|---:|---:|
| README | 346 | 187 | 156 / 31 | 20 | 7 | 4 |
| hints | 55 | 14 | 14 / 0 | 16 | 7 | 0 |
| solutions | 178 | 51 | 34 / 17 | 15 | 7 | 0 |
| Total | 579 | 252 | 204 / 48 | 51 | 21 | 4 |

The 51 textual links comprise 48 local navigation links and three external references.

Every expression is independently recorded with its exact source LaTeX, type, order and line. Complete normalized prose and paragraph sequences were prepared before capture comparison, preserving mathematical positions, all wording/case/punctuation and ordered-list markers. All hrefs, labels, anchor IDs, figure paths and alt texts are included. No unaccounted math/code delimiters remain.

The source's commands fall within existing v4 forms, including varepsilon distinct from epsilon and alphabetic upright units. Actual native structures still require individual comparison; a supported source spelling is not evidence of successful destination rendering. V4 is unchanged at SHA-256 `7466be19fe2073d2b8de4f8bc9e1a20209245741a466cb048ab7295eb303d6df`. Awaiting root's captures at immutable `81076b4c593fc1d685648c72892769c7a025f390`.

No browser operation, GitHub mutation or teaching/figure edit was performed.
