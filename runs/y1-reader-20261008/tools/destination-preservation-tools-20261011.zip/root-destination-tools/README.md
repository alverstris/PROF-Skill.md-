# Restricted destination-preservation QA

This tool compares a frozen Markdown source with a supplied actual-live GitHub DOM capture. It never evaluates scientific correctness, teaching quality, SASIS, browser geometry, clipping, or link navigation. It performs no browser operations or network/GitHub mutations.

`d017-r27-comparator.original.py` is the exact already-used script copied from `/tmp/d017_destination_compare.py`. Its SHA-256 is `72e1c5e9e9866724430a0a8d3f02fb75c107b0ea13b5f24726b975a1a08ab31c`. **Archive only: do not run it.** Its hardcoded paths would overwrite the original D017 JSON report. The final D017 Markdown report and final JSON metadata additions were assembled separately; this is the original comparator, not a full report reproducer.

Use the separate parameterized entry point with Python 3, without `-O`:

```sh
python compare_destination_preservation.py \
  --source /absolute/path/to/frozen/teaching.md \
  --capture /absolute/path/to/rendered-dom.json \
  --source-sha256 EXPECTED_64_CHARACTER_SHA256 \
  --output-dir /absolute/path/to/new/review-output
```

The capture schema must supply `url`, `observedAt`, full `articleHTML`, and an ordered `math` array whose objects contain `ordinal`, `display` (`js-inline-math` or `js-display-math`), and `mathML`. The URL must identify a full immutable Git commit (`/blob/<40 hex characters>/`). The embedded article MathML must exactly match the array. The tool requires an externally supplied frozen-source hash, checks all counts, and refuses to overwrite an existing output JSON. Capture authenticity and visual review remain the caller's responsibility.

Output: `math-preservation.json`, including every expression's source line, LaTeX, complete actual MathML, canonical source and actual structures, comparison hashes, full normalized prose, links and alt-text records. Exit 0 means all preservation checks pass; exit 1 means an explicit preservation mismatch; exit 2 means unsupported or invalid input. Unsupported input must be inspected rather than waived or silently normalized.

The parser intentionally supports only the D017 subset: GitHub inline math `$` followed by a backtick, then TeX, backtick and `$`; fenced `math` displays; elementary symbol commands listed in the script; fractions; one lower and one upper script; a single derivative prime; simple text; parentheses, brackets and evaluation bars; and two-column `aligned` tables. It preserves operators, visible delimiters, numeric content, base/script attachment, bounds, fraction operands, and row/cell structure. It rejects unknown TeX commands and unknown MathML tags, attributes/values or token structures. The allowlist also makes future MathJax changes visible. Prose handling is restricted to plain paragraphs, ordered-list markers, simple Markdown links/images, and named HTML anchors as used in D017. Other document markup requires inspection and deliberate extension; this is not a general Markdown or TeX renderer.

Normalization ignores only layout wrappers and spacing, equivalent TeX-to-MathML symbol spellings, the invisible function-application marker, and empty alignment cells. It does not simplify equations or accept algebraic equivalence. Contiguous numerals preserve script attachment to the full number; unbraced script/fraction arguments consume one TeX atom.

Verification: one successful replay of D017 to `/tmp/d017-preservation-replay/math-preservation.json` matched all 248 expressions (208 inline, 40 display), full prose, 35 textual links and both alt texts. A deliberately introduced unsupported `\sqrt` command exited 2 explicitly and wrote no report. `parser-provenance.json` records the exact archived and reusable script hashes and those checks. Original D017 inputs and reports were not modified by this follow-up.
