import re,json,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
from html.parser import HTMLParser
from collections import Counter
import difflib
SRC=Path('/workspace/scratch/f9c0b7fc7e76/d017-clean-r27/output/teaching.md')
DOM=Path('/workspace/scratch/f9c0b7fc7e76/root-review-d017-r27/destination/rendered-dom.json')
OUT=DOM.parent
source=SRC.read_text(); dom=json.loads(DOM.read_text())
EXPECTED='0317f26777f5285616be96713d79e1731818fea76d40954f3e21be2c6dbcb7b5'
assert hashlib.sha256(SRC.read_bytes()).hexdigest()==EXPECTED
PAT=re.compile(r'```math\s*\n(.*?)\n```|\$`(.*?)`\$',re.S)
exprs=[{'ordinal':i+1,'type':'display' if m.group(1) is not None else 'inline','source_line':source.count('\n',0,m.start())+1,'source_latex':m.group(1) if m.group(1) is not None else m.group(2)} for i,m in enumerate(PAT.finditer(source))]
# A separate restricted TeX parser: no renderer is used to compute expectations.
MAP={'int':'∫','sum':'∑','sin':'sin','cos':'cos','lim':'lim','to':'→','Delta':'Δ','pi':'π','lt':'<','le':'≤','ge':'≥','approx':'≈'}
CHAR={'-':'−','*':'∗'}
def sym(s): return ['symbol',CHAR.get(s,s)]
class Tex:
 def __init__(self,s): self.s=s;self.i=0
 def skip(self):
  while self.i<len(self.s) and self.s[self.i].isspace(): self.i+=1
 def seq(self,until=None):
  out=[]
  while True:
   self.skip()
   if self.i==len(self.s):
    assert until is None, ('unclosed',until,self.s)
    return out
   if until and self.s.startswith(until,self.i): self.i+=len(until);return out
   atom=self.atom()
   while True:
    self.skip()
    if self.i>=len(self.s) or self.s[self.i] not in "_^'":break
    op=self.s[self.i];self.i+=1
    arg=[sym('′')] if op=="'" else self.atom(single=True)
    if len(atom)==1 and atom[0][0]=='scripts':
     node=atom[0]
    else: node=['scripts',atom,[],[]]
    at=2 if op=='_' else 3
    assert not node[at],('duplicate script',self.s)
    node[at]=arg;atom=[node]
   out.extend(atom)
 def atom(self,single=False):
  self.skip();c=self.s[self.i];self.i+=1
  if c=='{':return self.seq('}')
  if c=='\\':
   m=re.match(r'[a-zA-Z]+|.',self.s[self.i:]);cmd=m.group();self.i+=len(cmd)
   if cmd in [',','qquad']:return []
   if cmd in MAP:return [sym(MAP[cmd])]
   if cmd=='frac':return [['fraction',self.atom(single=True),self.atom(single=True)]]
   if cmd=='text':
    self.skip();assert self.s[self.i]=='{';end=self.s.index('}',self.i+1);t=self.s[self.i+1:end];self.i=end+1
    return [['text',t]]
   if cmd=='left':
    self.skip();left=self.s[self.i];self.i+=1
    mid=self.seq('\\right');self.skip();right=self.s[self.i];self.i+=1
    return ([] if left=='.' else [sym(left)])+mid+([] if right=='.' else [sym(right)])
   raise AssertionError(('unsupported command',cmd,self.s))
  assert c not in '}^_',('unexpected',c,self.s)
  if c.isdigit() and not single:
   start=self.i-1
   while self.i<len(self.s) and self.s[self.i].isdigit():self.i+=1
   return [sym(v) for v in self.s[start:self.i]]
  return [sym(c)]
def tex_parse(s):
 if s.startswith('\\begin{aligned}'):
  assert s.endswith('\\end{aligned}')
  body=s[len('\\begin{aligned}'):-len('\\end{aligned}')]
  return [['table',[[Tex(cell).seq() for cell in row.split('&')] for row in body.split('\\\\')]]]
 return Tex(s).seq()
def tag(e):return e.tag.split('}')[-1]
def mparse(e):
 t=tag(e);cs=list(e);value=e.text or ''
 if t in ['mi','mo','mn']:
  if not value or value=='\u2061':return []
  if t=='mn': return [sym(c) for c in value]
  return [sym(value)]
 if t=='mtext':return [] if not value.strip() else [['text',value]]
 if t in ['math','mrow','mstyle','mtd']:return [a for c in cs for a in mparse(c)]
 if t=='mspace':return []
 if t=='mfrac':return [['fraction',mparse(cs[0]),mparse(cs[1])]]
 if t in ['msub','msup','msubsup','munder','munderover']:
  base=mparse(cs[0]);sub=[];sup=[]
  if t in ['msub','munder']:sub=mparse(cs[1])
  elif t=='msup':sup=mparse(cs[1])
  else:sub=mparse(cs[1]);sup=mparse(cs[2])
  return [['scripts',base,sub,sup]]
 if t=='mtable':return [['table',[[mparse(c) for c in row] for row in cs]]]
 raise AssertionError(('unexpected mathml',t))
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def count_nodes(nodes):
 c=Counter()
 def walk(n):
  if not isinstance(n,list) or not n:return
  if isinstance(n[0],str):
   c[n[0]]+=1
   if n[0]=='scripts':
    if n[2]:c['subscript_or_lower_bound']+=1
    if n[3]:c['superscript_or_upper_bound']+=1
    if n[1]==[sym('∫')]:c['integral_with_bounds']+=1
    if n[1]==[sym('∑')]:c['sum_with_bounds']+=1
   if n[0]=='symbol' and n[1]=='∫':c['integral_symbol']+=1
   for a in n[1:]:walk(a)
  else:
   for a in n:walk(a)
 walk(nodes);return dict(c)
records=[]
for ex,actual in zip(exprs,dom['math']):
 expected=tex_parse(ex['source_latex']);xml=ET.fromstring(actual['mathML'].replace('&nbsp;','&#160;'));observed=mparse(xml)
 typ='display' if actual['display']=='js-display-math' else 'inline'
 mathmltyp='display' if xml.attrib.get('display')=='block' else 'inline'
 records.append({**ex,'captured_ordinal':actual['ordinal'],'actual_type':typ,'mathml_type':mathmltyp,'types_match':ex['type']==typ==mathmltyp,'structural_match':expected==observed,'source_canonical':expected,'actual_canonical':observed,'source_canonical_sha256':digest(expected),'actual_canonical_sha256':digest(observed),'structure_counts':count_nodes(expected),'actual_mathml':actual['mathML']})
# Complete text comparison with stable placeholders protecting inline positions.
# Images' alt text is separate from visible body text; anchors have no visible text.
source_prose=PAT.sub(lambda m:f' ⟦M{next(source_prose.counter):03d}⟧ ',source) if False else None
idx=iter(range(1,len(exprs)+1))
source_prose=PAT.sub(lambda m:f'⟦M{next(idx):03d}⟧',source)
source_alts=re.findall(r'!\[([^\]]*)\]\(([^)]*)\)',source_prose)
source_prose=re.sub(r'!\[([^\]]*)\]\(([^)]*)\)',' ',source_prose)
source_links=re.findall(r'\[([^\]]*)\]\(([^)]*)\)',source_prose)
source_prose=re.sub(r'\[([^\]]*)\]\(([^)]*)\)',lambda m:m.group(1),source_prose)
source_prose=re.sub(r'<a\s+name="[^"]*">\s*</a>',' ',source_prose)
class DOMProse(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.parts=[];self.mathdepth=0;self.i=0;self.link=None;self.links=[];self.alts=[];self.ol=[];self.pieces=[];self.current=[]
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if t=='math-renderer':self.mathdepth+=1;self.i+=1;self.parts.append(f'⟦M{self.i:03d}⟧');return
  if self.mathdepth:return
  if t in ['p','ol','li','div','article']:self.parts.append(' ')
  if t=='ol':self.ol.append(int(a.get('start',1)))
  if t=='li' and self.ol:self.parts.append(str(self.ol[-1])+'. ');self.ol[-1]+=1
  if t=='a' and 'href'in a:self.link={'label':'','href':a['href']}
  if t=='img':self.alts.append({'alt':a.get('alt',''),'src':a.get('src','')})
 def handle_endtag(self,t):
  if t=='math-renderer':self.mathdepth-=1;return
  if self.mathdepth:return
  if t in ['p','ol','li','div','article']:self.parts.append(' ')
  if t=='ol':self.ol.pop()
  if t=='a' and self.link is not None:self.links.append(self.link);self.link=None
 def handle_data(self,v):
  if self.mathdepth:return
  self.parts.append(v)
  if self.link is not None:self.link['label']+=v
parser=DOMProse();parser.feed(dom['articleHTML'])
def norm(s):return ' '.join(s.split())
sp=norm(source_prose);ap=norm(''.join(parser.parts))
image_wrapper_links=[a for a in parser.links if not norm(a['label'])]
text_links=[a for a in parser.links if norm(a['label'])]
links=[{'ordinal':i+1,'source_label':s[0],'source_href':s[1],'actual_label':a['label'],'actual_href':a['href'],'label_match':norm(s[0])==norm(a['label']),'href_match':s[1]==a['href']} for i,(s,a) in enumerate(zip(source_links,text_links))]
images=[{'ordinal':i+1,'source_alt':s[0],'actual_alt':a['alt'],'alt_match':s[0]==a['alt']} for i,(s,a) in enumerate(zip(source_alts,parser.alts))]
report={'scope':'Frozen D017 source-to-live-GitHub destination preservation only; no scientific or SASIS verdict.','source_path':str(SRC),'source_sha256':EXPECTED,'capture_path':str(DOM),'capture_sha256':hashlib.sha256(DOM.read_bytes()).hexdigest(),'live_url':dom['url'],'observed_at':dom['observedAt'],'method':'Independent restricted-TeX parser compared to actual MathML tree, one expression at a time in document order. Canonical sequences preserve all symbols and visible delimiters, fractions, script attachment and sub/sup operands, integral/sum bounds and aligned rows/cells. Normalize TeX symbol spellings, MathML wrappers, spacing, U+2061 function-application marker and empty layout cells only. Numeric MathML tokens split into digits to mirror TeX lexical units. Prose replaces each math expression with the same ordinal marker and compares the entire ordered body after only markup and whitespace normalization; list markers recovered from ol starts; image alt text and link labels compared independently.','counts':{'source_expressions':len(exprs),'captured_expressions':len(dom['math']),'article_expressions':parser.i,'source_types':dict(Counter(e['type'] for e in exprs)),'actual_types':dict(Counter(r['actual_type'] for r in records)),'matched_structures':sum(r['structural_match'] for r in records),'matched_types':sum(r['types_match'] for r in records),'source_links':len(source_links),'actual_text_links':len(text_links),'actual_image_wrapper_links':len(image_wrapper_links),'source_images':len(source_alts),'actual_images':len(parser.alts)},'math_records':records,'prose':{'match':sp==ap,'normalization':'Whitespace collapsed; Markdown/HTML markup removed; ordered-list markers reconstructed from HTML starts; math replaced by positional ordinal markers; image alt text checked separately. No case, punctuation, wording, order or typographic quote normalization.','source_normalized':sp,'actual_normalized':ap,'source_sha256':hashlib.sha256(sp.encode()).hexdigest(),'actual_sha256':hashlib.sha256(ap.encode()).hexdigest(),'diff':list(difflib.unified_diff(sp.split(),ap.split(),fromfile='source',tofile='actual',lineterm='')) if sp!=ap else []},'links':links,'image_wrapper_links':image_wrapper_links,'images':images,'limitations':'Uses root-provided actual-live DOM capture, not an independently repeated navigation. Does not establish visual geometry, clipping, link navigation or scientific correctness. Source and capture are immutable review inputs; no frozen-file modifications or GitHub writes.'}
(OUT/'math-preservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report['counts'],indent=2));print('prose',sp==ap);print('links',all(x['label_match'] and x['href_match'] for x in links));print('images',all(x['alt_match'] for x in images))
for r in records:
 if not(r['structural_match'] and r['types_match']):print('MISMATCH',r['ordinal'],r['source_latex'],json.dumps(r['source_canonical'],ensure_ascii=False),json.dumps(r['actual_canonical'],ensure_ascii=False))
if sp!=ap:print('\n'.join(report['prose']['diff'][:150]))
