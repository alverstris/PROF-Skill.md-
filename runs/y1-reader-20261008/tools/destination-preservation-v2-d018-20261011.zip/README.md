# Restricted destination-preservation comparator v2

This is a read-only comparison of a frozen Markdown source and supplied actual-live GitHub DOM. It is never a scientific, teaching-quality or SASIS evaluator. It does not operate a browser, test navigation, judge clipping, fetch URLs or write to GitHub. The caller authenticates the capture and performs visual review.

Run with Python 3 and only its standard library; do not use `-O`:

```sh
python compare_destination_preservation_v2.py \
  --source /absolute/path/to/frozen/teaching.md \
  --capture /absolute/path/to/rendered-dom.json \
  --source-sha256 EXPECTED_64_HEX_SOURCE_HASH \
  --output-dir /absolute/path/to/new/output-directory
```

The capture requires `url`, `observedAt`, full `articleHTML`, and the ordered `math` array (`ordinal`, `display`, `mathML`). The URL must contain `/blob/<40-hex immutable Git commit>/`. Input source SHA-256 and article-versus-array MathML identity are checked. Output is `math-preservation.json`; an existing output is never overwritten. Exit 0 means all preservation checks pass, 1 means a recorded preservation failure, and 2 means unsupported/invalid input requiring inspection.

V2 extends the preserved v1 only for demonstrated D018 equivalents: square roots; decimal numeral tokens; double-prime glyphs as two primes; `gt`, `ln`, `varepsilon`, `infty`, `theta`, `cdot`; `quad`/escaped-space layout; and simple `details`/`summary` markup. It aligns every source math expression with an actual article slot. Explicit error slots and raw `pre lang="math"` blocks are recorded as failures, even when their raw text exactly matches source. Their complete HTML and raw text remain in the report. Source-slot mismatch or unknown actual rendered constructs fail explicitly.

The independent canonical structures preserve operand order, operators, visible delimiters, fractions, root operands, script bases/contents, integral/sum bounds and supported aligned cells. Only demonstrated symbol spellings, layout wrappers/spacing, the invisible function-application marker and empty layout cells are normalized. Algebraic equivalence is never substituted for preservation.

Limits remain deliberate: only the GitHub inline/fenced math syntax and plain Markdown prose/link/image/anchor/disclosure subset used by D017/D018 are supported. Unknown TeX commands, MathML tags or attributes/values are explicit errors. `operatorname` and `cases` have not been added as successful rendering equivalents: D018 supplied no native MathML for those slots. Future actual rendering of these or other new constructs must be inspected and deliberately implemented in another separately versioned extension. Do not waive a failure, infer missing math from surviving prose, or silently broaden normalization.

D018 verification: both initial and settled captures produced 271 preserved structures, one truncated rendered expression, ten explicit macro errors and six raw solution displays, across all 288 source slots. Full prose, all 26 textual links and both image alt texts matched. All six raw displays remained within open disclosures after root's actual scrolling; the settled comparison confirmed no restoration. The complete review reports are distinct artifacts. The initial capture/report and frozen source were not changed.

This archive contains the exact v2 script used for those comparisons, this README, provenance and a SHA-256 manifest. V1 and the exact original D017 comparator remain separately preserved. The original D017 archive script has hardcoded paths and must not be rerun unchanged.
